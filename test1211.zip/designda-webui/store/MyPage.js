import { setData } from './slices/serverSideSlice';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { useEffect } from 'react';

export const getServerSideProps = async () => {
  const res = await fetch('https://jsonplaceholder.typicode.com/todos/');
  const data = await res.json();

  return {
    props: {
      data
    }
  }
}

const MyPage = ({ data }) => {
const newData = useSelector(state => state.myData);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setData(data));
  }, [dispatch, data]);


  return (
    <div>
    {newData.slice(0,5).map(item => (
      
      <div key={item.id}>
        <h2>{item.title}</h2>
        <p>{item.description}</p>
      </div>
    ))}
  </div>
  )
}

export default MyPage;
