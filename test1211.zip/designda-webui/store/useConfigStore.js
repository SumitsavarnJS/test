import { create } from "zustand";
import { produce } from "immer";

const useConfigStore = create((set) => ({
  isAuthenticated: false,
  isAdminFlag: false,
  setAdminFlag: (flag) => set((state) => ({ isAdminFlag: flag })),
  setAuth: (value) => set((state) => ({ isAuthenticated: value })),

  metricProjectName: [],
  // setMetricProjectName: (newValue) => {
  //   set((state) => ({
  //     metricProjectName: Array.isArray(newValue)
  //       ? [state.metricProjectName, ...newValue] // If newValue is an array, merge it
  //       : [state.metricProjectName, newValue], // If newValue is a string, add it
  //   }));
  // },

  setMetricProjectName: (newValue) => {
    set((state) => ({
      metricProjectName: Array.isArray(newValue)
        ? newValue // If newValue is an array, merge it
        : [newValue], // If newValue is a string, add it
    }));
  },

  configData: {},
  setConfigData: (value) => set((state) => ({ configData: value })),
  authLoginUser: "",
  setAuthUserVal: (value) => set((state) => ({ authLoginUser: value })),
  theme: "light",
  userLicenseId: "",
  widLibDataSource: {
    taskData: { dataLocation: "#", bucket: "" },
    flowData: { dataLocation: "#", bucket: "" },
    customData: { dataLocation: "#", bucket: "" },
  },
  isTourFlag: true,
  setUserLicenseId: (value) => set((state) => ({ userLicenseId: value })),
  setRootLevelData: (rootKey, rootData) =>
    set(
      produce((state) => {
        state[rootKey] = rootData;
      })
    ),
  clickedJsons: [],
  addClickedJson: (jsonLink) => {
    set((state) => ({ clickedJsons: [...state.clickedJsons, jsonLink] }));
  },
  deleteClosedJson: (jsonLink) => {
    set((state) => ({
      clickedJsons: state.clickedJsons.filter((name) => name !== jsonLink),
    }));
  },
  commonString: "",
  setCommonString: (value) => set((state) => ({ commonString: value }))  
}));

export default useConfigStore;
