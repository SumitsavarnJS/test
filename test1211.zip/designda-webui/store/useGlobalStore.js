import { create } from "zustand";
import { produce } from "immer";

const useGlobalStore = create((set) => ({
  // decides the view of rptDashboard in analytics tab
  // currently supports 'tab' and 'list'
  analyticsReportView: { view: "tab", currentTab: "" },
  dataSearchVisibility: true,

  /** stores all anaytics reports config
   *  sample report -> allReports : {report1: {title : "report1",
   *                                           properties: {},
   *                                           widgets:{widget1: {
   *                                                           w: 0,h: 0,
   *                                                           config:{}
   *                                                           meta:{}
   *                                                              }
   *                                                    }
   *                                          }
   *                                  }
   */
  allReports: {},

  /**
   * stores widget setting of the widget that is copied
   * Term 'Widget Setting: -> {
   *                              w: 0,h: 0,
   *                              config:{}
   *                              meta:{}
   *                           }
   */
  copyWidget: {},

  /**
   * The report to be focused in list view of analytics
   */
  focusedRpt: { rpt: "", width: "" },

  /**
 * The report's locking (i.e. read only status)

/**
 * heading of current dashboard
 */
  dashboardHeading: "",

  /**
   * change of dashboard name on renaming
   */
  dashboardChange: "",

  /**
   * Sets the dashboardchange wile renaming dashboard
   * @param {renamed value} value
   * @returns
   */
  setDashboardChange: (value) => set((state) => ({ dashboardChange: value })),

  /**
   * setting autLoginUser/   Note: -> either this function is incorrect or not being used
   * @param {} value
   * @returns
   */
  setDashboardHeading: (value) => set((state) => ({ authLoginUser: value })),

  /**
   * Re- routes the url
   */
  reportUrlChange: "",

  /**
   * sets the new url
   * @param {new url} newValue
   * @returns
   */
  setReportUrlChange: (newValue) => set({ reportUrlChange: newValue }),

  /**
   * keeps track of the current dashboard
   */
  currentDashboard: "",

  /**
   * templateReport object similar to allReports object above
   */
  templateReport: { template: { widgets: { templateWidget: {} } } },

  /**
   * settings of a template widget
   */
  templateWidget: {
    data: {},
    uiState: {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,

      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    },
    metaData: {},
  },

  /**
   * stores dashboard object,
   * unlike anlytics allReports object which stores all active reports,
   * it stores only one currently used dasboard report
   */
  allDashbrdRpts: {
    dashboardReport: { fileName: "", config: { expanded: false }, widgets: {} },
  },

  /**
   * It stores the right pane config of dashboard like badge info to show count
   */
  dashboardRightPane: {
    savedDashbrdCount: 0,
  },

  /**
   * It stores the right pane config of Analytics tab/ rptDashboard like badge info to show count
   */
  analyticsRightPane: {
    savedRptCount: 0,
    favouriteRptCount: 0,
  },

  /**
   * It updated the dashboard report object
   * @param {new radsboard object} rptData
   * @returns
   */
  updateDashboardObject: (rptData) =>
    set((state) => ({
      allDashbrdRpts: rptData,
    })),

  /**
   * It updates the new layout of dashboard on resizing or moving or add widget in dashboard
   * @param {new layout object} layout
   * @returns
   */

  updateWidgetLayout: (layout) =>
    set((state) => {
      const newWidgets = JSON.parse(
        JSON.stringify(state.allDashbrdRpts.dashboardReport.widgets)
      );
      layout.forEach((item) => {
        const widget = newWidgets[item.i];
        if (widget) {
          widget.x = item.x;
          widget.y = item.y;
          widget.w = item.w;
          widget.h = item.h;
        }
      });
      return {
        allDashbrdRpts: {
          dashboardReport: {
            ...state.allDashbrdRpts.dashboardReport,
            widgets: newWidgets,
          },
        },
      };
    }),
  updateReportWidgetLayout: (reportName, layoutChanges) => {
    set((state) => {
      // Check if the report exists
      if (state.allReports.hasOwnProperty(reportName)) {
        // Create a copy of the report to modify
        const updatedReport = JSON.parse(JSON.stringify(state.allReports[reportName]));

        // Iterate through layout changes
        layoutChanges.forEach((change) => {
          // Find the corresponding widget in the report
          const widgetId = change.i;
          if (updatedReport.widgets.hasOwnProperty(widgetId)) {
            // Update widget's coordinates
            updatedReport.widgets[widgetId].x = change.x;
            updatedReport.widgets[widgetId].y = change.y;
            updatedReport.widgets[widgetId].w = change.w;
            updatedReport.widgets[widgetId].h = change.h;
          }
        });

        // Update the state with the modified report
        return {
          allReports: {
            ...state.allReports,
            [reportName]: updatedReport
          }
        };
      } else {
        // Return current state if the report doesn't exist
        return state;
      }
    });
  },
  /**
   * delets the widget form the dashboard report object
   * @param {*} widgetId
   * @returns
   */
  deleteDashboardWgt: (widgetId) =>
    set(
      produce((state) => {
        delete state.dashboardReport.widgets[widgetId];
      })
    ),

  /**
   *
   * Updates the allReports object of all analytical reports
   * @param {analytical report} rptName
   * @param {analytical report} rptData
   * @returns
   */
  updateGlobalObject: (rptName, rptData) =>
    set((state) => ({
      allReports: { ...state.allReports, [rptName]: rptData },
    })),

  /**
   * It can update data of any report (dashboard or analytics)
   * @param {allDashboardReports/AllReports} rptType
   * @param {*} reportName
   * @param {*} reportData
   * @returns
   */
  updateReport: (rptType, reportName, reportData) =>
    set(
      produce((state) => {
        state[rptType][reportName] = reportData;
      })
    ),

  /**
   * It sets the data of any object at root level.
   * It is a general puporse function.
   * @param {Name of the key of object at root level} rootKey
   * @param {Data of the object at root level} rootData
   * @returns
   */
  setRootLevelData: (rootKey, rootData) =>
    set(
      produce((state) => {
        state[rootKey] = rootData;
      })
    ),

  /**
   * It updates the data of the widget and not the config of widget
   * @param {*} widgetId
   * @param {*} data
   * @returns
   */
  setWidgetData: (widgetId, data) =>
    set(
      produce((state) => {
        state[widgetId].data = data;
      })
    ),

  /**
   * It can update a single attribute/ key  of widget data and does not
   * require the whole copy of the widget data to be updated
   * @param {*} widgegtId
   * @param {any single key of the widget data} key
   * @param {data of the key of widget data} data
   * @returns
   */
  setWidgetDataProp: (widgegtId, key, data) =>
    set(
      produce((state) => {
        state[widgegtId].data[key] = data;
      })
    ),

  /**
   * It sets the UI state of the widget
   * ui State controls the view of widget
   * It shows config or visual data
   * It shows messages (error/succes/info) of the widget
   * It shows loading graphics
   * @param {*} widgetId
   * @param {*} uiState
   * @returns
   */
  setWidgetUiState: (widgetId, uiState) =>
    set(
      produce((state) => {
        state[widgetId].uiState = uiState;
      })
    ),

  /**
   * It sets the widget meta data
   * Meta data contains widget description and tags
   * @param {*} widgetId
   * @param {widget description and tags} metaData
   * @returns
   */
  setWidgetMetaData: (widgetId, metaData) =>
    set(
      produce((state) => {
        state[widgetId].metaData = metaData;
      })
    ),

  /**
   * It updates the widget config of any report
   * Config differs for different widget
   * genrally it contains title and other config to visualize the content of the widget
   * @param {allReports/allDashboardReport} rptType
   * @param {reportName} report
   * @param {*} widgetId
   * @param {*} config
   * @returns
   */
  updateConfig: (rptType, report, widgetId, config) =>
    set(
      produce((state) => {
        state[rptType][report].widgets[widgetId].config = config;
      })
    ),

  /**
   * It updates a property of the widget setting.
   * Setting contains the widget height , width, config and meta data
   * @param {*} rptType
   * @param {*} report
   * @param {*} widgetId
   * @param {*} property
   * @param {*} value
   * @returns
   */
  updateSettingsProp: (rptType, report, widgetId, property, value) =>
    set(
      produce((state) => {
        state[rptType][report].widgets[widgetId][property] = value;
      })
    ),

  /**
   * It updates the widget setting.
   * Setting contains the widget height , width, config and meta data
   * @param {*} rptType
   * @param {*} report
   * @param {*} widgetId
   * @param {*} widgetSettings
   * @returns
   */
  updateWidgetSettings: (rptType, report, widgetId, widgetSettings) =>
    set(
      produce((state) => {
        state[rptType][report].widgets[widgetId] = widgetSettings;
      })
    ),
  dataPanelExpandCheck: true,
  reports: {},
  toggleLock: (reportName) => set((state) => ({
    reports: {
      ...state.reports,
      [reportName]: !state.reports[reportName] // toggle lock status
    }
  })),

  /**
   * It deletes the widget from the report
   * and widget data from store
   * @param {*} rptType
   * @param {*} report
   * @param {*} widgetId
   * @returns
   */



  deleteWgt: (rptType, report, widgetId) =>
    set(
      produce((state) => {
        delete state[rptType][report].widgets[widgetId];
        delete state[widgetId];
      })
    ),
}))



export default useGlobalStore;
