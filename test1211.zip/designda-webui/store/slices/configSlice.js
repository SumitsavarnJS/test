import { createSlice } from '@reduxjs/toolkit';

const configSlice = createSlice({
  name: 'config',
  initialState: null,
  reducers: {
    setConfig: (state, action) => {
      return action.payload;
    },
  },
});

export const { setConfig } = configSlice.actions;
export const selectConfig = (state) => state.config;

export default configSlice.reducer;
