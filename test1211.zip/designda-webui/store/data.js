import { createAsyncThunk } from '@reduxjs/toolkit';
import { useDispatch } from 'react-redux';
import { getData } from './api';

const fetchData = createAsyncThunk('data/fetchData', async () => {
  const data = await getData();
  return data;
});




// export const getServerSideProps = async (context) => {
//   const { store } = context;
//   const dispatch = useDispatch();

//   try {
//     if (typeof window === undefined) {
//     const { data } = await dispatch(fetchData());
//     return {
//       props: {
//         initialData: data,
//       },
//     };
//   }
//   } 
  
//   catch (error) {
//     return {
//       props: {
//         initialData: null,
//       },
//     };
//   }
// };


export const getSaticProps = async ({ context }) => {
  const dispatch = useDispatch();
  const { data } = await dispatch(fetchData());
return {
  props: {
    initialData: data,
  },
};

};