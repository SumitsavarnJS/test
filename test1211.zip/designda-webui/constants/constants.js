export const grid = 2;
export const borderRadius = 2;

//report types
export const dashboardReport = "dashboardReport";
export const allDashbrdRpts = "allDashbrdRpts";
export const allReports = "allReports";
export const taskReport = "taskReport";
export const flowReport = "flowReport";
export const customReport = "customReport";
export const template = "template";
export const templateWidget = "templateWidget";
export const templateReport = "templateReport";

//widgets name
export const groupBarChart = "Group Bar Chart";
export const metricsGroupBarChart = "Metrics Group Bar Chart";
export const tableView = "Table View";
export const tableViewExec = "ITable View";

export const documentView = "Document View";
export const metricsSummary = "Metrics";
export const treemap = "Treemap";
export const kdePlot = "KDE Plot";
export const multiFeatureBarPlot = "Multiple Feature Bar Chart";
export const timingPathMatrix = "Timing Path Matrix";
export const interClockMatrix = "Inter Clock Matrix";
export const bubbleChart = "Bubble Chart";
// export const logMonitor = "Log Monitor";
// export const customWorkflowManager = "Custom Workflow Manager";
// export const taskAnalysisManager = "Task Analysis Manager";
// export const flowAnalysisManager = "Flow Analysis Manager";
export const pieChart = "Pie Chart";
export const histogram = "Histogram";
export const multiBoxPlot = "Multi Box Plot";
export const boxPlot = "Box Plot";
export const timingpathSummary = "Timing Path Summary";
export const timingpathDetail = "Timing Path Details";
export const timingpathCompare = "Timing Path Compare";
export const layoutView = "Layout View";
export const layoutTableView = "Layout Table View";
export const threeDSurfaceChart = "3D Surface Chart";
export const workflowMonitorTable = "Workflow Monitor Table";
export const scatterPlot = "Scatter Plot";
export const logMonitorTable = "Log Monitor Table";
export const graphChart = "Graph Chart";
export const ganttChart = "Gantt Chart";
// export const lineChart = "Line Chart";
export const tableDetailImages = "Table Detail Images";
export const lineChart = "ILine Chart";
export const iScatterPlot = "IScatter Plot";
export const I_METRICS = "IMetrics";
export const iPieChart = "IPie Chart";
export const iGroupBarChart = "IGroupBar Chart";
export const iTreemapChart = "ITreemap";
export const iMultiFeatureBarChart = "IMultiple Feature Bar Chart";
export const iSunburstChart = "ISunburst Chart";
export const logComparator = "Log Comparator";
export const LAYOUT_VIEW_V2 = "Layout View v2";
export const GENERIC_CHARTS_V1 = "Generic Charts v1";

export const interactiveWidgetList = [
  tableViewExec,
  lineChart,
  iScatterPlot,
  I_METRICS,
];

export const widgetList = [
  "Group Bar Chart",
  "Bubble Chart",
  "Document View",
  // "Flow Analysis Manager",
  "Histogram",
  "KDE Plot",
  "Box Plot",
  // "Simple Bar Plot",
  "Multi Box Plot",
  "Layout View",
  "Layout Table View",
  "Multiple Feature Bar Chart",
  "Pie Chart",
  "Table View",
  "ITable View",
  // "Task Analysis Manager",
  "Metrics Task Monitor",
  // "Custom Workflow Manager",
  "Timing Correlation",
  "Timing Path Details",
  "Timing Path Summary",
  "Timing Path Compare",
  "Timing Path Matrix",
  "Treemap",
  "Workflow Status Summary",
  // "Log Monitor",
  "Convergence Plot",
  "Hierarchy Table",
  "Inter Clock Matrix",
  "Metrics",
  "3D Surface Chart",
  "Workflow Monitor Table",
  "Scatter Plot",
  "Log Monitor Table",
  "Graph Chart",
  "Gantt Chart",
  "Line Chart",
  "IScatter Plot",
  "IPie Chart",
  "IGroupBar Chart",
  "ITreemap",
  "IMultiple Feature Bar Chart",
  "ISunburst Chart",
  "Log Comparator",
  "Layout View V2",
  "Generic Charts v1",
];

export const LOG_STREAM_STATUS = {
  QUEUED: "queued",
  RUNNING: "running",
  FINISHED: "finished",
  FAILED: "failed",
};

export const STREAM_GROUPS = {
  LIVE: "Live",
  COMPLETED: "Completed",
};

export const filterList = [
  { title: "User", column: "user", type: "text" },
  { title: "Widget ID", column: "doc_id", type: "text" },
  { title: "Widget Title", column: "title", type: "text" },
  { title: "Widget Description", column: "description", type: "text" },
  { title: "Widget Tag", column: "tags", type: "text" },
  { title: "Widget Type", column: "widget_name", type: "select" },
  { title: "Scope", column: "scope", type: "select" },
  { title: "Stage", column: "stage", type: "select" },
  {
    title: "Data Type",
    column: "data_type",
    type: "select",
  },
  {
    title: "Category",
    column: "widget_category",
    type: "select",
  },
  { title: "Tool Name", column: "tool_name", type: "select" },
  { title: "Type", column: "type", type: "select" },
];

export const baseFilterStateObj = {
  widget_name: [],
  scope: [],
  stage: [],
  data_type: [],
  widget_category: [],
  tool_name: [],
  type: [],
  user: [],
  doc_id: [],
  title: [],
  description: [],
  tags: [],
};

export const tags = [
  { label: "Project", field: "project" },
  { label: "User", field: "user" },
  { label: "Block", field: "block" },
  { label: "Phase", field: "phase" },
  { label: "Runtag", field: "runtag" },
  { label: "User Label", field: "label" },
  { label: "Baseline Marker", field: "baselineMarker" },
];
