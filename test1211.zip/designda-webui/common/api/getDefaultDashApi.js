import axios from "axios";
import useConfigStore from "../../store/useConfigStore";
import api from "../api/api";
import getApi from "../api/getApi";

export async function makeFixedPostRequest(apiNumbers) {
  const responseProfilePref = await axios.post(
    useConfigStore.getState().configData.rest_server_url +
      "/api/get_profile_config",
    {
      user: useConfigStore.getState().authLoginUser,
    }
  );
  if (Object.keys(responseProfilePref.data.profile_config).length > 1) {
    let defaultMetricProject = responseProfilePref.data.profile_config.project;
    useConfigStore.getState().setMetricProjectName(defaultMetricProject);
  } else {
    const userProjectResponse = await axios.post(
      useConfigStore.getState().configData.rest_server_url +
        "/api/fetch_buckets",
      {
        user: useConfigStore.getState().authLoginUser,
      }
    );
    const userProjectData = userProjectResponse.data;
    let updateProjectVal = userProjectData.data[0];
    useConfigStore.getState().setMetricProjectName(updateProjectVal);
  }
  let metricProjectName = useConfigStore.getState().metricProjectName;
  const initialResponse = await axios.post(
    useConfigStore.getState().configData.rest_server_url +
      "/metrics/getDefaultMetricWidgetAtt/",
    {
      projects: metricProjectName,
      user: useConfigStore.getState().authLoginUser,
    }
  );

  const defaultQueryBody = `# Invoke the cli object to query data
# builds are stored in variable 'runs'
# pattern format = user/block/phase/runtag/checkpoint
# you can get get multiple projects by merging two cli runs. 
# Example runs1 = cli.get_metrics_data( pattern = '.*', project = 'project1', count = 10000 )
#         runs2 = cli.get_metrics_data( pattern = '.*', project = 'project2', count = 10000 )
#         runs = runs1 + runs2
# you can edit the pattern to fetch runs 
# runs = cli.get_metrics_data( pattern = 
# '(?:user1|user2)/(?:block1|block2)/(?:phase1|phase2)/(?:runtag1:runtag2)/(?:checkpoint1|checkpoint2)',
# project = 'project1',
# count = 10000 )
`;

  const configData = useConfigStore.getState().configData;
  const authLoginUser = useConfigStore.getState().authLoginUser;

  const iMetricConfig = {};

  const getDefaultQuery = async () => {
    let userDefaultQuery = "";
    let runsQuery = "\nruns = runs0";

    //set query if changes are made
    const response = await api(
      configData.rest_server_url + "/api/get_profile_config",
      {
        user: authLoginUser,
      }
    );
    if (
      response &&
      response.profile_config &&
      response.profile_config.project
    ) {
      let projectQuery = "";
      for (let i = 0; i < response.profile_config.project.length; i++) {
        projectQuery = `\nruns${i} = cli.get_metrics_data( pattern = "${authLoginUser}", project = "${response.profile_config.project[i]}")`;
        userDefaultQuery = userDefaultQuery + projectQuery;
        if (i == 0) {
          continue;
        }
        runsQuery = runsQuery + ` + runs${i}`;
      }
    }
    // add user and project related project
    let userProjectQuery = defaultQueryBody + userDefaultQuery + runsQuery;
    iMetricConfig.query = userProjectQuery;
  };

  getDefaultQuery();

  const metricsURL = configData.rest_server_url + "/metrics/";

  const responseData = await getApi(metricsURL + "getSpecInfo/");
  if (responseData && responseData.specInfoObj) {
    let reportSpec = "";
    let hierSpec = "";
    const specInfoObj = _.get(responseData, "specInfoObj", []);
    let reportSpecList = [];
    let hierSpecList = [];
    for (const [user, specList] of Object.entries(specInfoObj.Users)) {
      for (let i = 0; i < specList.length; i++) {
        if (specList[i].specType == "report_spec") {
          reportSpecList.push(specList[i].specName);
          if (
            `Users/${authLoginUser}/defaultReportSpec` == specList[i].specName
          ) {
            reportSpec = specList[i].specName;
          }
          if (specList.length - 1 == i && reportSpec == "") {
            let userRptSpecList = reportSpecList.filter(
              (spec) => spec.split("/")[1] == authLoginUser
            );
            if (userRptSpecList.length) {
              reportSpec = userRptSpecList[0];
            }
          }
        } else if (specList[i].specType == "hier_spec") {
          hierSpecList.push(specList[i].specName);
          if (
            `Users/${authLoginUser}/defaultHierSpec` == specList[i].specName
          ) {
            hierSpec = specList[i].specName;
          }
          if (specList.length - 1 == i && hierSpec == "") {
            let userHierSpecList = hierSpecList.filter(
              (spec) => spec.split("/")[1] == authLoginUser
            );
            if (userHierSpecList.length) {
              reportSpec = userHierSpecList[0];
            }
          }
        }
      }
    }
    iMetricConfig.reportSpecName = reportSpec;
    iMetricConfig.hierSpecName = hierSpec;
  }

  const getDefaultConfig = (reportClass) => {
    let reportConfig = {};
    switch (reportClass) {
      case "TableCompareReport":
        reportConfig.baselineBuilds = [];
        reportConfig.orgMode = "BCxM";
        reportConfig.displayMode = "VALUE";
        reportConfig.hierBlockMode = true;
        reportConfig.hierBuildMode = true;
        reportConfig.showEmpty = true;
        reportConfig.tablePersistence = {};
        reportConfig.tablePersistence.BCxM = {};
        reportConfig.tablePersistence.BCxM.VALUE = {
          filters: [],
          sorters: [],
        };
        break;
      case "ImageCompareReport":
        reportConfig.baselineBuilds = [];
        reportConfig.orgMode = "BCxM";
        reportConfig.hierBlockMode = true;
        reportConfig.hierBuildMode = true;
        reportConfig.tablePersistence = {};
        reportConfig.tablePersistence.BCxM = {
          filters: [],
          sorters: [],
        };
        break;
      case "FileReport":
        reportConfig.tablePersistence = {
          filters: [],
          sorters: [],
        };
        break;
      case "TableDetailReport":
        reportConfig.baselineBuild = "";
        reportConfig.displayMode = "VALUE";
        reportConfig.showEmpty = true;
        reportConfig.showDiff = false;
        reportConfig.tablePersistence = {};
        reportConfig.tablePersistence.VALUE = {
          filters: [],
          sorters: [],
        };
        break;
      case "BuildsDashboardReport":
        reportConfig.rowOrg = "None";
        reportConfig.tablePersistence = {
          filters: [],
          sorters: [],
        };
        break;
      default:
        reportConfig = null;
    }

    return reportConfig;
  };

  if (iMetricConfig.reportSpecName) {
    const reportSpecDoc = await api(metricsURL + "readSpecDoc/", {
      specType: "report_spec",
      specName: iMetricConfig.reportSpecName,
    });
    if (reportSpecDoc && reportSpecDoc.data) {
      //reading report spec for spec doc api
      const reportSpec = reportSpecDoc.data.specDoc[0].data;
      if (
        reportSpec &&
        reportSpec.reportNames &&
        Object.keys(reportSpec.reportNames).length
      ) {
        const reportConfig = getDefaultConfig(
          reportSpec.reportNames[Object.keys(reportSpec.reportNames)[0]]
            .reportInfo.reportClass
        );
        iMetricConfig.currentReport = Object.keys(reportSpec.reportNames)[0];
        iMetricConfig.currentReportName =
          reportSpec.reportNames[
            Object.keys(reportSpec.reportNames)[0]
          ].reportInfo.menuName;
        iMetricConfig.savedReportConfig = {};
        iMetricConfig.savedReportConfig[
          Object.keys(reportSpec.reportNames)[0]
        ] = reportConfig;
      }
    }
  }

  // let metricData = {};
  // if (initialResponse) {
  //   metricData = initialResponse.data;
  //   if (metricData.buildSpec) {
  //     localStorage.setItem(
  //       "4BmZVR0UmFRBXhmMZrSc-",
  //       JSON.stringify(metricData.buildSpec)
  //     );
  //   }
  // }

  try {
    // Make an initial GET request to retrieve data
    // Create the data object by combining the retrieved data and obj1
    let data = {
      data: {
        fileName: "Default-Dashboard",
        theme: "light",
        title: "Default-Dashboard",
        widgets: {
          "5BtAgeDfOuRSP3PPHL_2u": {
            config: {
              status: [
                "new",
                "success",
                "failed",
                "running",
                "queued",
                "killed",
                "awaiting_upstream",
              ],
              require_all_status: true,
              show_only_available_reports: false,
              title: "Workflow Monitor",
            },
            h: 27,
            key: "5BtAgeDfOuRSP3PPHL_2u",
            metaData: {
              description: "",
              tags: "",
            },
            name: "Workflow Monitor Table",
            w: 24,
            x: 0,
            y: 0,
          },
          "4BmZVR0UmFRBXhmMZrSc-": {
            h: 30,
            w: 24,
            y: 27,
            x: 0,
            metaData: {
              tags: "",
              description: "",
            },
            name: "IMetrics",
            config: {
              title: "Designer Level Report",
              ...iMetricConfig,
            },
            key: "4BmZVR0UmFRBXhmMZrSc-",
          },
          "3wLqAJ4BBJaxEpx0oSHFf": {
            "config": {
                "bucket": "",
                "cache_key": "",
                "columns": [],
                "data": "",
                "dataLocation": "",
                "query": "# Invoke the cli object to query data and assign required dataframe to df variable\n# List of available themes: \n# light\n# infographic\n# macarons\n# roma\n# vintage\n# essos\n# shine\n# wonderland\n# dark\n# purple-passion\n\ntasks = cli.get_tasks_with_outcomes(pattern=\"*\", workflows=[\"debug_setup\", \"debug_leakage\", \"debug_dynamic\"])\n\ndf = dd.from_dict(\n    {\"task\": tasks},\n    npartitions=3,\n)\n\ndf[\"__task\"] = df[\"task\"]\n\nsplit_cols = df[\"task\"].str.split(\"/\", expand=True, n=6)\ncustom_col_names = [\n    \"project\",\n    \"user\",\n    \"block\",\n    \"phase\",\n    \"run_tag\",\n    \"checkpoint\",\n    \"timestamp\",\n]\n\n\ndf = df.assign(**{f\"split_{i}\": split_cols[i] for i in range(split_cols.shape[1])})\ndf = df.drop(columns=[\"task\"])\ndf = df.rename(\n    columns={f\"split_{i}\": custom_col_names[i] for i in range(split_cols.shape[1])}\n)\n\ndef gen_context_menu(rows):\n  \n  tasks = [row[\"__task\"] for row in rows]\n  if len(tasks) == 1:\n    context_menu = [\n      {\n        \"label\": f\"Run extract path groups\",\n        \"action\": \"run_workflows\",\n        \"args\": {\n          \"workflows\": [\"extract_path_groups\"],\n          \"tag\": f\"{tasks[0].split('/')[4]}_extract_path_groups_viagui\",\n          \"args\": {\n            \"task\": tasks[0],\n            \"output\": f\"{tasks[0].split('/')[4]}_{tasks[0].split('/')[5]}_run_via_gui_path_group.tcl\"\n          },\n        \"project\": tasks[0].split('/')[0]\n        }\n      }\n      ]\n  if len(tasks) == 2:\n    context_menu = [\n      {\n        \"label\": f\"Run flow analysis\",\n        \"action\": \"run_workflows\",\n        \"args\": {\n          \"workflows\": [\"flow_analysis\"],\n          \"tag\": f\"{tasks[0].split('/')[4]}_flow_analysis_viagui\",\n          \"args\": {\n            \"tasks\": tasks,\n            \"report_name\": f\"{tasks[0].split('/')[4]}_{tasks[0].split('/')[5]}_VS_{tasks[1].split('/')[4]}_{tasks[1].split('/')[5]}_run_via_gui_flow\"\n          },\n        \"project\": tasks[0].split('/')[0]\n        }\n      },\n      {\n        \"label\": f\"Run extract path margin\",\n        \"action\": \"run_workflows\",\n        \"args\": {\n          \"workflows\": [\"extract_path_margin\"],\n          \"tag\": f\"{tasks[0].split('/')[4]}_extract_path_margins_viagui\",\n          \"args\": {\n            \"tasks\": tasks,\n            \"output\": f\"{tasks[0].split('/')[4]}_{tasks[0].split('/')[5]}_VS_{tasks[1].split('/')[4]}_{tasks[1].split('/')[5]}_run_via_gui_path_margin.tcl\"\n          },\n        \"project\": tasks[0].split('/')[0]\n        }\n      },\n      {\n        \"label\": f\"Run extract clock latency\",\n        \"action\": \"run_workflows\",\n        \"args\": {\n          \"workflows\": [\"extract_clock_latency\"],\n          \"tag\": f\"{tasks[0].split('/')[4]}_extract_clock_latency_viagui\",\n          \"args\": {\n            \"tasks\": tasks,\n            \"output\": f\"{tasks[0].split('/')[4]}_{tasks[0].split('/')[5]}_VS_{tasks[1].split('/')[4]}_{tasks[1].split('/')[5]}_run_via_gui_clock_latency.tcl\"\n          },\n        \"project\": tasks[0].split('/')[0]\n        }\n      }\n    ]\n  return context_menu\n  \nwidget.context_menu_func = gen_context_menu\nwidget.theme = \"purple-passion\"",
                "tableId": 1721305122946,
                "title": "Flow analysis and Prescriptive apps triggering"
            },
            "h": 27,
            "key": "3wLqAJ4BBJaxEpx0oSHFf",
            "metaData": {
                "description": "",
                "tags": ""
            },
            "name": "ITable View",
            "w": 24,
            "x": 0,
            "y": 57
        }
        },
      },
      user: useConfigStore.getState().authLoginUser,
    };

    const apiRequests = [];

    if (apiNumbers.includes(1)) {
      const request1 = axios.post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/store_dashbaord_info",
        data
      );
      apiRequests.push(request1);
    }

    if (apiNumbers.includes(2)) {
      const request2 = axios.post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/save_user_config",
        data
      );
      apiRequests.push(request2);
    }

    const responses = await Promise.all(apiRequests);

    // Extract the data from responses
    const responseDataFromPosts = responses.map((response) => response.data);

    return responseDataFromPosts;
  } catch (error) {
    console.error("Error making POST requests:", error);
    throw error;
  }
}
