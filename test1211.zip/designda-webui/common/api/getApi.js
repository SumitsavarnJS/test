import axios from 'axios'

export default async function fetchData(url, input) {
  const response = await axios
    .get(url)
    .then((response) => {
      console.log(response)
      const apiStatus = _.get(response, 'status', {})
      if (apiStatus == 200) {
        const apiData = _.get(response, 'data', {})
        return apiData
      } else {
        console.log('Something is wrong in the backend API', url)
      }
    })
    .catch((reason) => {
      console.log(reason)
      console.log(
        'Something is wrong in the Frontend API',
        url,
        JSON.stringify(input),
      )
    })
  if (response) {
    return response
  } else {
    {
      data: null
    }
  }
}
