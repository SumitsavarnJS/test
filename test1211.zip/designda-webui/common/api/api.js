import axios from "axios";

export default async function fetchData(url, input) {
  const response = await axios
    .post(url, input)
    .then((response) => {
      const apiStatus = _.get(response, "status", {});
      if (apiStatus == 200) {
        const apiData = _.get(response, "data", {});
        return apiData;
      } else {
        console.log(
          "Something is wrong in the backend API",
          url,
          JSON.stringify(input)
        );
      }
    })
    .catch((reason) => {
      console.log(reason);
      console.log(
        "Something is wrong in the Frontend API",
        url,
        JSON.stringify(input)
      );
      return {
        
          data: {},
          status: false,
          message: "Failed to fetch data.",
      };
    });
  if (response) {
    return response;
  } else {
    {
      data: null;
    }
  }
}
