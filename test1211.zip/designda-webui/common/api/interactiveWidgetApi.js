import axios from "axios";

export default async function fetchData(url, input) {
  const response = await axios
    .post(url, input)
    .then((response) => {
      const apiStatus = _.get(response, "status", {});
      if (apiStatus == 200) {
        const apiData = _.get(response, "data", {});
        return apiData;
      } else {
        console.log(
          "Something is wrong in the backend API",
          url,
          JSON.stringify(input)
        );
      }
    })
    .catch((error) => {
      console.log(error?.response?.data?.message);
      return {
          data: {},
          status: false,
          message: error?.response?.data?.message,
      };
    });
  if (response) {
    return response;
  } else {
    {
      data: null;
    }
  }
}
