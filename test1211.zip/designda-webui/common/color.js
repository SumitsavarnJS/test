import React from "react";
import { useState, useEffect, useRef } from 'react';
import _ from "lodash";


export function isNumber(value) {
    return !isNaN(value) && !isNaN(parseFloat(value));
  }
////////////////////////////////////////////////////////////////////////////////
// Default metric data structures
////////////////////////////////////////////////////////////////////////////////

export const defaultColorRule = Object.freeze({
    color: "improve_degrade",
    improves: "zero",
    lightPct: 0.005,
    medPct: 0.02,
    darkPct: 0.1,
    absThreshold: 0,
    refValue: null,
  });

  /////////////////////////////////////////////////////////
export let _colors = {
    Snps: { fg: "#5a2a82", bg: "#5a2a82" },
    Blue: { fg: "#007bff", bg: "#007bff" },
    Green: { fg: "#00ff7b", bg: "#00ff7b" },
    DarkGreen: { fg: "#008000", bg: "#008000" },
    Black: { fg: "#000000", bg: "#000000" },
    White: { fg: "#ffffff", bg: "#ffffff" },
    Red: { fg: "#ff0000", bg: "#ff0000" },
    Orange: { fg: "#e0a800", bg: "#e0a800" },
    DarkGray: { fg: "#e0e0e0", bg: "#e0e0e0" },
    LightGray: { fg: "#f0f0f0", bg: "#f0f0f0" },
    Default: { fg: "#000000", bg: "#ffffff" },
    Alt: { fg: "#000000", bg: "#e0e0e0" },
    Faded: { fg: "#c0c0c0", bg: "#ffffff" },
    ImprovedSmall: { fg: "#000000", bg: "#e0ffe0" },
    ImprovedMedium: { fg: "#000000", bg: "#b0ffb0" },
    ImprovedLarge: { fg: "#000000", bg: "#80ff80" },
    DegradedSmall: { fg: "#000000", bg: "#ffe0e0" },
    DegradedMedium: { fg: "#000000", bg: "#ffb0b0" },
    DegradedLarge: { fg: "#000000", bg: "#ff8080" },
    SmallDelta: { fg: "#404040", bg: "#ffffff" },
    None: { fg: "#000000", bg: "#ffffff" },
    DiffMiss: { fg: "#000000", bg: "#E67E22" },
    extraCheckpoint: { fg: "#000000", bg: "#F4D03F" },
    missingCheckpoint: { fg: "#000000", bg: "#E67E22" },
    tableHeader: { fg: "#000000", bg: "#E6E6E6" },
    textFile: { fg: "#000000", bg: "#ffffff" },
    imageFile: { fg: "#5a2a82", bg: "#ffffff" },
    htmlFile: { fg: "#007bff", bg: "#ffffff" },
    Error: { fg: "#ff0000", bg: "#ff0000" },
    Warning: { fg: "#ffc107", bg: "#ffc107" },
    waiveColorRule: { fg: "#000000", bg: "#808080" },
  };

export function palette(arg) {
    let color = _colors["Default"];
    if (_colors.hasOwnProperty(arg)) {
      color = _colors[arg];
    }
    return color;
  }
////////////////////////////////////////////////////////////////////////////////
// Support for table cell calculations
////////////////////////////////////////////////////////////////////////////////

export function calcCell(metricName, value, refValue, colorRules, isRefValue, displayMode) {
    // console.log("metricName, value, refValue, colorRules, isRefValue, displayMode:", metricName, value, refValue, colorRules, isRefValue, displayMode);
    let results = {};
    let colorRule = getColorRule(metricName, colorRules);
    let valueObj = calcValues(metricName, value, refValue, colorRule, isRefValue, displayMode);
    results.valueObj = valueObj;
    results.colors = calcColors(metricName, valueObj, colorRule, isRefValue);
    // console.log(results);
    return results;
  }
  
  export function getColorRule(metricName, colorRules) {
    let colorRule = _.cloneDeep(defaultColorRule);
    // console.log(colorRules, colorRule);
    if(colorRules) {
      _.merge(colorRule, colorRules);
    }
    return colorRule;
  }
  
  export function calcValues(metricName, value, refValue, colorRule, isRefValue) {
    let valueObj = {};
  
    let deltaValue = value;
    let deltaPercent = value;
    let valueNum = null;
    let valueRef = null;
    let valueNumAbs = null;
    let valueRefAbs = null;
    let deltaValueAbs = null;
    let deltaValueMag = null;
    let percentDeltaMag = null;
    let percentDeltaValue = null;
  
    let localRefValue = refValue;
    if (colorRule.refValue != null) {
      localRefValue = colorRule.refValue;
    }
  
    if (!isNumber(value)) {
      valueObj.isRefValue = isRefValue;
      valueObj.value = value;
      valueObj.refValue = localRefValue;
  
      valueObj.deltaValue = value;
      valueObj.deltaPercent = value;
      valueObj.valueNum = null;
      valueObj.valueRef = null;
      valueObj.valueNumAbs = null;
      valueObj.valueRefAbs = null;
      valueObj.deltaValueAbs = null;
      valueObj.deltaValueMag = null;
      valueObj.percentDeltaMag = null;
      valueObj.percentDeltaValue = null;
  
      return valueObj;
    }
  
    // isNumber(value) is already checked above, so no need to check again
    if (isNumber(localRefValue)) {
      valueNum = parseFloat(value);
      valueRef = parseFloat(localRefValue);
  
      valueNumAbs = Math.abs(valueNum);
      valueRefAbs = Math.abs(valueRef);
  
      deltaValue = valueNum - valueRef;
      deltaValueAbs = Math.abs(deltaValue);
      deltaValueMag = Math.abs(valueNumAbs - valueRefAbs);
  
      if (valueRefAbs == 0) {
        // denominator is zero
        if (deltaValueAbs == 0) {
          // numerator is zero; all percent values are 0
          percentDeltaValue = 0;
          percentDeltaMag = 0;
          deltaPercent = 0;
        } else {
          // numerator is non-zero; all percent values are +100 or -100
          if (deltaValue > 0) {
            percentDeltaValue = 100.0;
            percentDeltaMag = 100.0;
            deltaPercent = 100.0;
          } else {
            percentDeltaValue = 100.0;
            percentDeltaMag = 100.0;
            deltaPercent = -100.0;
          }
        }
      } else {
        // denominator is non-zero
        percentDeltaValue = deltaValueAbs / valueRefAbs; // always positive
        percentDeltaMag = deltaValueMag / valueRefAbs; // always positive
        deltaPercent = (100.0 * deltaValue) / valueRefAbs; // positive or negative
      }
  
      if (deltaValue >= 0) {
        deltaValue = "+" + deltaValue.toFixed(2);
      } else {
        deltaValue = deltaValue.toFixed(2);
      }
      if (deltaPercent >= 0) {
        deltaPercent = "+" + deltaPercent.toFixed(2) + "%";
      } else {
        deltaPercent = deltaPercent.toFixed(2) + "%";
      }
    }
  
    valueObj.isRefValue = isRefValue;
    valueObj.value = value;
    valueObj.refValue = localRefValue;
    valueObj.deltaValue = deltaValue;
    valueObj.deltaPercent = deltaPercent;
    valueObj.valueNum = valueNum;
    valueObj.valueRef = valueRef;
    valueObj.valueNumAbs = valueNumAbs;
    valueObj.valueRefAbs = valueRefAbs;
    valueObj.deltaValueAbs = deltaValueAbs;
    valueObj.deltaValueMag = deltaValueMag;
    valueObj.percentDeltaMag = percentDeltaMag;
    valueObj.percentDeltaValue = percentDeltaValue;
  
    return valueObj;
  }
  
  export function calcColors(metricName, valueObj, colorRule, isRefValue) {
    let colors = palette("Default");
  
    // Reference values are never colored
    if (isRefValue == true) {
      return colors;
    }
  
    if (colorRule.color == "improve_degrade") {
      if (isNumber(valueObj.value) && isNumber(valueObj.refValue)) {
        if (valueObj.deltaValueAbs <= colorRule.absThreshold) {
          colors = palette("SmallDelta");
        } else {
          let improved = false;
          if (colorRule.improves == "zero") {
            if (valueObj.valueNumAbs < valueObj.valueRefAbs) {
              improved = true;
            }
            colors = colorsByPercent(improved, valueObj.percentDeltaMag, colorRule);
          } else if (colorRule.improves == "larger") {
            if (valueObj.valueNum > valueObj.valueRef) {
              improved = true;
            }
            colors = colorsByPercent(improved, valueObj.percentDeltaValue, colorRule);
          } else if (colorRule.improves == "smaller") {
            if (valueObj.valueNum < valueObj.valueRef) {
              improved = true;
            }
            colors = colorsByPercent(improved, valueObj.percentDeltaValue, colorRule);
          }
        }
      } else {
        colors = palette("Default");
      }
    } else if (colorRule.color == "none") {
      colors = palette("Default");
    } else if (colorRule.color == "different" || colorRule.color == "different_or_missing" || colorRule.color == "missing") {
      let different = false;
      let missing = false;
  
      if (!isRefValue) {
        if (valueObj.value != valueObj.refValue) {
          different = true;
        }
      }
      if (valueObj.value == null) {
        missing = true;
      }
  
      if (colorRule.color == "different") {
        if (different) {
          colors = palette("DiffMiss");
        }
      } else if (colorRule.color == "different_or_missing") {
        if (different || missing) {
          colors = palette("DiffMiss");
        }
      } else if (colorRule.color == "missing") {
        if (missing) {
          colors = palette("DiffMiss");
        }
      }
    }
  
    return colors;
  }

  export function colorsByPercent(improved, percentDelta, colorRule) {
    let colors = palette("Default");
  
    if (improved) {
      if (percentDelta > colorRule.lightPct) {
        colors = palette("ImprovedSmall");
      }
      if (percentDelta > colorRule.medPct) {
        colors = palette("ImprovedMedium");
      }
      if (percentDelta > colorRule.darkPct) {
        colors = palette("ImprovedLarge");
      }
    } else {
      if (percentDelta > colorRule.lightPct) {
        colors = palette("DegradedSmall");
      }
      if (percentDelta > colorRule.medPct) {
        colors = palette("DegradedMedium");
      }
      if (percentDelta > colorRule.darkPct) {
        colors = palette("DegradedLarge");
      }
    }
    return colors;
  }