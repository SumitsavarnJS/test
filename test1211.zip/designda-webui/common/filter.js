import React from "react";
import { useState, useEffect, useRef } from "react";
import _ from "lodash";

export function customInput(cell, onRendered, success, cancel, editorParams) {
  //create and style input
  var cellValue = cell.getValue(),
    input = document.createElement("input");

  input.setAttribute("type", editorParams.search ? "search" : "text");

  input.style.padding = "4px";
  input.style.width = "100%";
  input.style.boxSizing = "border-box";

  if (
    editorParams.elementAttributes &&
    typeof editorParams.elementAttributes == "object"
  ) {
    for (let key in editorParams.elementAttributes) {
      if (key.charAt(0) == "+") {
        key = key.slice(1);
        input.setAttribute(
          key,
          input.getAttribute(key) + editorParams.elementAttributes["+" + key]
        );
      } else {
        input.setAttribute(key, editorParams.elementAttributes[key]);
      }
    }
  }

  input.value = typeof cellValue !== "undefined" ? cellValue : "";
  highlightInput(input);

  onRendered(function () {
    input.focus({ preventScroll: true });
    input.style.height = "100%";
  });

  function onChange(e) {
    if (
      ((cellValue === null || typeof cellValue === "undefined") &&
        input.value !== "") ||
      input.value !== cellValue
    ) {
      if (success(input.value)) {
        cellValue = input.value; //persist value if successfully validated incase editor is used as header filter
      }
    } else {
      cancel();
    }
  }

  //submit new value on blur or change
  input.addEventListener("change", onChange);
  input.addEventListener("blur", onChange);

  // Hack of Tabulator code to highlight non-empty filters

  function highlightListener(e) {
    highlightInput(e.target);
  }

  function highlightInput(input) {
    let text = input.value;
    let reEmpty = new RegExp("^$");
    if (text.match(reEmpty)) {
      input.style.background = "#ffffff";
    } else {
      input.style.background = "#ffffc0";
    }
  }

  input.addEventListener("input", highlightListener);

  //submit new value on enter
  input.addEventListener("keydown", function (e) {
    switch (e.keyCode) {
      // case 9:
      case 13:
        onChange(e);
        break;

      case 27:
        cancel();
        break;

      case 35:
      case 36:
        e.stopPropagation();
        break;
    }
  });

  if (editorParams.mask) {
    this.table.modules.edit.maskInput(input, editorParams);
  }

  return input;
}

export function customInputForColumn(
  cell,
  onRendered,
  success,
  cancel,
  editorParams
) {
  //create and style input
  var cellValue = cell,
    input = document.createElement("input");

  input.setAttribute("type", editorParams.search ? "search" : "text");

  input.style.padding = "4px";
  input.style.width = "100%";
  input.style.boxSizing = "border-box";

  if (
    editorParams.elementAttributes &&
    typeof editorParams.elementAttributes == "object"
  ) {
    for (let key in editorParams.elementAttributes) {
      if (key.charAt(0) == "+") {
        key = key.slice(1);
        input.setAttribute(
          key,
          input.getAttribute(key) + editorParams.elementAttributes["+" + key]
        );
      } else {
        input.setAttribute(key, editorParams.elementAttributes[key]);
      }
    }
  }

  input.value = typeof cellValue !== "undefined" ? cellValue : "";
  highlightInput(input);

  onRendered(function () {
    input.focus({ preventScroll: true });
    input.style.height = "100%";
  });

  function onChange(e) {
    if (
      ((cellValue === null || typeof cellValue === "undefined") &&
        input.value !== "") ||
      input.value !== cellValue
    ) {
      if (success(input.value)) {
        cellValue = input.value; //persist value if successfully validated incase editor is used as header filter
      }
    } else {
      cancel();
    }
  }

  //submit new value on blur or change
  input.addEventListener("change", onChange);
  input.addEventListener("blur", onChange);

  // Hack of Tabulator code to highlight non-empty filters

  function highlightListener(e) {
    highlightInput(e.target);
  }

  function highlightInput(input) {
    let text = input.value;
    let reEmpty = new RegExp("^$");
    if (text.match(reEmpty)) {
      input.style.background = "#ffffff";
    } else {
      input.style.background = "#ffffc0";
    }
  }

  input.addEventListener("input", highlightListener);

  //submit new value on enter
  input.addEventListener("keydown", function (e) {
    switch (e.keyCode) {
      // case 9:
      case 13:
        onChange(e);
        break;

      case 27:
        cancel();
        break;

      case 35:
      case 36:
        e.stopPropagation();
        break;
    }
  });

  if (editorParams.mask) {
    this.table.modules.edit.maskInput(input, editorParams);
  }

  return input;
}

export function customFilter(
  headerValue,
  rowValue,
  rowData = null,
  filterParams = {}
) {
  if (rowValue == undefined) {
    return false;
  }
  return customMatch(headerValue, rowValue.toString());
}

export function globFilterDisplayValue(headerValue, rowValue) {
  if (rowValue == undefined) {
    return false;
  }
  let pattern = headerValue;
  let cellText = rowValue;
  let options = { nocase: true };
  return globMatch(pattern, cellText.toString(), options);
}

export function customFilterDisplayValue(
  headerValue,
  rowValue,
  rowData,
  filterParams
) {
  // console.log(headerValue, rowValue, rowData);
  if (rowValue == undefined) {
    return false;
  }
  if (rowValue == undefined) {
    return false;
  }
  let strCell = rowValue.toString();
  return customMatch(headerValue, strCell);
}

// Custom filters

export function customMatch(headerValue, strCell) {
  // console.log(headerValue, strCell);
  let match = false;

  let numCell = null;

  let reMode = headerValue.startsWith(";;");
  let compareMode = headerValue.startsWith("::");

  if (reMode) {
    let headerStr = headerValue.substring(2);
    let reRegExp = /(.*)$/;

    let reMatchRegExp = reRegExp.exec(headerStr);
    let opRegExp = null;
    if (reMatchRegExp != null) {
      opRegExp = reMatchRegExp[1];
    }

    if (opRegExp == null) {
      match = false;
    } else {
      let reIsValid = true;
      try {
        new RegExp(opRegExp);
      } catch (e) {
        reIsValid = false;
      }

      if (reIsValid) {
        let regexp = new RegExp(opRegExp);
        match = regexp.test(strCell);
      } else {
        match = false;
      }
    }
  } else if (compareMode) {
    let headerStr = headerValue.substring(2);
    let reLessThan = /(<=|<)([^,\s]+)/;
    let reMoreThan = /(>=|>)([^,\s]+)/;

    let opLessThan = null;
    let opMoreThan = null;
    let strLessThan = null;
    let strMoreThan = null;
    let numLessThan = null;
    let numMoreThan = null;

    let reMatchLessThan = reLessThan.exec(headerStr);
    let reMatchMoreThan = reMoreThan.exec(headerStr);

    if (reMatchLessThan != null) {
      opLessThan = reMatchLessThan[1];
      strLessThan = reMatchLessThan[2];
    }
    if (reMatchMoreThan != null) {
      opMoreThan = reMatchMoreThan[1];
      strMoreThan = reMatchMoreThan[2];
    }

    numLessThan = parseFloat(strLessThan);
    if (Number.isNaN(numLessThan)) {
      numLessThan = null;
    }
    numMoreThan = parseFloat(strMoreThan);
    if (Number.isNaN(numMoreThan)) {
      numMoreThan = null;
    }
    numCell = parseFloat(strCell);
    if (Number.isNaN(numCell)) {
      numCell = null;
    }

    if (numCell != null) {
      let matchLessThan = true;
      let matchMoreThan = true;

      if (reMatchLessThan && numLessThan != null) {
        if (opLessThan) {
          if (opLessThan.includes("=")) {
            matchLessThan = numCell <= numLessThan;
          } else {
            matchLessThan = numCell < numLessThan;
          }
        }
      }

      if (reMatchMoreThan && numMoreThan != null) {
        if (opMoreThan) {
          if (opMoreThan.includes("=")) {
            matchMoreThan = numCell >= numMoreThan;
          } else {
            matchMoreThan = numCell > numMoreThan;
          }
        }
      }

      match = matchLessThan && matchMoreThan;
    }
  } else {
    // glob mode
    let options = { nocase: true };
    match = globMatch(headerValue, strCell, options);
  }

  return match;
}

export function timeFilter(headerValue, rowValue, rowData, filterParams) {
  let match = false;
  console.log(headerValue, rowData);
  if (rowValue == undefined) {
    return match;
  }

  let pattern = headerValue;
  let timeRow = rowValue;

  let regex;
  let re;
  let reMatch;

  let textMin = null;
  let textMax = null;

  // Check for both textMin and textMax
  regex = "^(\\d\\d\\d\\d-\\d\\d-\\d\\d),(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
  re = new RegExp(regex);
  reMatch = re.exec(pattern);
  if (reMatch) {
    textMin = reMatch[1];
    textMax = reMatch[2];
  } else {
    // Check for only textMin
    regex = "^(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
    re = new RegExp(regex);
    reMatch = re.exec(pattern);
    if (reMatch) {
      textMin = reMatch[1];
    } else {
      // Check for only textMax
      regex = "^,(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
      re = new RegExp(regex);
      reMatch = re.exec(pattern);
      if (reMatch) {
        textMax = reMatch[1];
      }
    }
  }

  let timeMin = textMin; //getSecsFromYearMonthDay(textMin);
  let timeMax = textMax; //getSecsFromYearMonthDay(textMax);

  if (timeMin && timeMax) {
    match = timeRow > timeMin && timeRow < timeMax;
  } else if (timeMin && !timeMax) {
    match = timeRow > timeMin;
  } else if (!timeMin && timeMax) {
    match = timeRow < timeMax;
  } else {
    match = true;
  }

  return match;
}

// Return date string from seconds
export function dateFromSeconds(seconds) {
  let date = new Date(seconds * 1000);

  let year = date.getFullYear();

  let month = date.getMonth() + 1;
  if (month < 10) {
    month = "0" + month;
  }

  let day = date.getDate();
  if (day < 10) {
    day = "0" + day;
  }

  let hours = date.getHours();
  if (hours < 10) {
    hours = "0" + hours;
  }

  let mins = date.getMinutes();
  if (mins < 10) {
    mins = "0" + mins;
  }

  let secs = date.getSeconds();
  if (secs < 10) {
    secs = "0" + secs;
  }

  let msg =
    year + "-" + month + "-" + day + " " + hours + ":" + mins + ":" + secs;

  return msg;
}

export function globMatch(pattern, text, options) {
  // Ensure glob pattern extends to end of text
  let globPattern = pattern;
  if (!globPattern.endsWith("$") && !globPattern.endsWith("*")) {
    globPattern = globPattern + "*";
  }

  // Convert glob to rex
  let regxPattern = "^" + globPattern.replace(/\*/g, ".*") + "$";

  let re;
  if (options.nocase == true) {
    re = new RegExp(regxPattern, "i");
  } else {
    re = new RegExp(regxPattern);
  }

  let match = re.test(text);

  return match;
}

export function globFilter(headerValue, rowValue) {
  if (rowValue == undefined) {
    return false;
  }
  return globMatch(headerValue, rowValue.toString(), { nocase: true });
}
