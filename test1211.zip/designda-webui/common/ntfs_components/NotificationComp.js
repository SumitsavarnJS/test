import React, { useState } from "react";
import { forwardRef } from "react";
import { useSnackbar, CustomContentProps, SnackbarContent } from "notistack";
import _ from "lodash";
import { Collapse, IconButton, Typography, styled } from "@mui/material";
import useConfigStore from "../../store/useConfigStore";
import CancelIcon from "@mui/icons-material/Cancel";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import * as styles from "./NotificationComp.module.css";
import dynamic from "next/dynamic";

const Markdown = dynamic(
  () => import("@uiw/react-markdown-preview").then((mod) => mod.default),
  { ssr: false }
);

function Preview(props) {
  return (
    <div data-color-mode={useConfigStore.getState().theme}>
      <Markdown disableCopy={false} source={props.text} />
    </div>
  );
}

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
  padding: "0px",
  transition: theme.transitions.create("transform", {
    duration: theme.transitions.duration.shortest,
  }),
}));

const Notification = forwardRef(function Notification(props, ref) {
  const { closeSnackbar } = useSnackbar();
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <SnackbarContent ref={ref}>
      <div id="ntfsPopUp" className={styles.ntfsPopUp}>
        <div
          id="ntfsTitle"
          style={{
            width: "300px",
            minHeight: "50px",
            backgroundColor: _.get(props, "bgColor", "red"),
            borderRadius: "5px",
            padding: "5px",
            display: "flex",
          }}
        >
          <Typography sx={{ paddingRight: "70px", color: "white" }}>
            {_.get(props, "message", "NO TITLE")}
          </Typography>
          <div id={"ntfsTitleMenu"} className={styles.titleMenu}>
            <ExpandMore
              expand={isExpanded}
              onClick={() => {
                setIsExpanded(!isExpanded);
                props.handleExpand(props);
              }}
              sx={{ color: "white" }}
            >
              <ExpandMoreIcon />
            </ExpandMore>

            <IconButton
              onClick={() => {
                closeSnackbar(_.get(props, "id"));
              }}
              sx={{ color: "white" }}
            >
              <CancelIcon />
            </IconButton>
          </div>
        </div>
        <div id="ntfsDesc" className={styles.desc}>
          <Collapse
            in={isExpanded}
            sx={{ padding: "5px" }}
            timeout="auto"
            unmountOnExit
          >
            <Preview text={_.get(props, "desc", "NO DESC")} />
            {/* <Typography>{_.get(props, "desc", "NO DESC")}</Typography> */}
          </Collapse>
        </div>
      </div>
    </SnackbarContent>
  );
});

export default Notification;
