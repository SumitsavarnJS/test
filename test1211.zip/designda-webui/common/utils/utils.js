import _ from "lodash";
import api from "../api/api";

import { toast } from "react-toastify";

import useConfigStore from "../../store/useConfigStore";
import { filterList, tags } from "../../constants/constants";
import { nanoid } from "nanoid";
import * as htmlToImage from "html-to-image";

/**
 * Creates mlbakend url from rest server url
 * @returns mlbackend Url
 */
export const getMLUrl = () => {
  let beUrl = _.get(useConfigStore.getState().configData, "rest_server_url", "")
    .split("/")
    .slice(0, -1)
    .join("/");          

  let mlUrl = beUrl + "/" + "mlbackend";
  // uncomment and assign "semantics_search_url" from "server_info.json" from .dash to mlurl for dev env
  // mlUrl = "http://panthercs25:9001"
  return mlUrl;
};

/**
 *
 * @param {Data location with cluster} dataLocation
 * @returns root level data for task and flow data
 *
 * TASK DATA Length = 7
 * FLOW DATA Length = 4
 * Scenarios will be appended/removed after length end
 */
export const getRootDirectory = (dataLocation) => {
  if (dataLocation) {
    let [cluster, location] = dataLocation.split("#");

    if (location && location.startsWith("task")) {
      return cluster + "#" + location.split("/").slice(0, 7).join("/");
    } else if (location && location.startsWith("flow")) {
      //length of flow data source will be 4
      return cluster + "#" + location.split("/").slice(0, 4).join("/");
    }
  }
  return dataLocation;
};

/**
 *
 * @param {Data location with cluster} dataLocation
 * @returns boolean if data location was till root level
 */
export const isRootDirectory = (dataLocation) => {
  if (dataLocation) {
    let [cluster, location] = dataLocation.split("#");

    if (location && location.startsWith("task")) {
      return location.split("/").length == 7;
    } else if (location && location.startsWith("flow")) {
      //length of flow data source will be 4
      return location.split("/").length == 4;
    }
  }
  return false;
};

/**
 *
 * @param {Data location with cluster} dataLocation
 * @returns scenario if scenario is given in the dataLocation
 */
export const getScenarioFromDataLoc = (dataLocation) => {
  let [cluster, location] = dataLocation ? dataLocation.split("#") : "";

  if (location && location.startsWith("task")) {
    if (location.split("/").length == 8) {
      return location.split("/")[7];
    } else {
      console.log(location + " dataLocation does not have scenario");
    }
  } else if (location && location.startsWith("flow")) {
    //length of flow data source will be 4
    if (location.split("/").length == 5) {
      return location.split("/")[4];
    } else {
      console.log(location + " dataLocation does not have scenario");
    }
  }

  return "";
};

/**
 *
 * @param {minio bucket} bucket
 * @param {Data location with cluster} dataLocation
 * @returns list of scenarios if any from a given data
 */
export const getScenarioList = async (bucket, dataLocation) => {
  // currently implemented only for task data
  const response = await api(
    _.get(useConfigStore.getState().configData, "rest_server_url", "") +
      "/api/fetch_report_attributes",
    {
      bucket: bucket,
      key: dataLocation,
    }
  );
  if (response.status) {
    const data = _.get(response, "data", {});
    if (data.scenarios && data.scenarios.length) {
      return data.scenarios;
    } else {
      return [];
    }
  } else {
    console.log("sceanrio not found for " + bucket + dataLocation);
    return [];
  }
};

/**
 *
 * @param {minio bucket} dataLocation
 * @param {Data location with cluster} bucket
 * @param {data name (ldb)} currentData
 * @returns an object which contains three attributes
 *
 * dataHelperText : what text to appear if current data(ldb) is not present in the
 *                current dataLocation
 * dataErrorFlag: boolean set to true is current data is not present in Data list
 *
 * dataList: List of all the data present in the data source level
 */
export const getDataObject = async (dataLocation, bucket, currentData) => {
  const input = { key: dataLocation, bucket: bucket };
  const response = await api(
    _.get(useConfigStore.getState().configData, "rest_server_url", "") +
      "/api/get_ldb_files",
    input
  );

  let dataHelperText = "";
  let dataErrorFlag = false;
  let dataList = [];

  if (response.status) {
    dataList = _.get(response, "data", []);
    let data = currentData;

    if (data && !dataList.includes(data)) {
      dataHelperText = "Data not present in selected Data Location";
      dataErrorFlag = true;
    }
  }
  return {
    dataList: dataList,
    dataHelperText: dataHelperText,
    dataErrorFlag: dataErrorFlag,
  };
};

/**
 *
 * @param {Data (ldb)} newData
 * @param {minio bucket} bucket
 * @param {Data location with cluster} dataLocation
 * @param {currently selected columns} currentColumns
 * @returns an object which contains three attributes
 *
 * columnHelperText : what text to appear if current columns  is not present in the
 *                current data (ldb/parquet)
 * columnErrorFlag: boolean set to true is current columns are not present in column list
 *
 * columnList: List of all the column present in the data (ldb/parquet)
 */
export const getDataColumnsObject = async (
  newData,
  bucket,
  dataLocation,
  currentColumns
) => {
  const data = {
    bucket: bucket,
    key: dataLocation,
    ldb_file: newData,
  };
  const response = await api(
    _.get(useConfigStore.getState().configData, "rest_server_url", "") +
      "/api/fetch_parquet_columns",
    data
  );

  let columnErrorFlag = false;
  let columnHelperText = "";
  let columnList = [];

  if (response.status) {
    const selectedColumns = currentColumns;
    columnList = _.get(response, "data", {});

    const inconsitentCols = selectedColumns.filter(
      (column) => !columnList.includes(column)
    );
    if (inconsitentCols.length) {
      columnHelperText = `${inconsitentCols} Columns are inconsistent`;
      columnErrorFlag = true;
    }
  }
  return {
    columnErrorFlag: columnErrorFlag,
    columnHelperText: columnHelperText,
    columnList: columnList,
  };
};

/**
 *
 * @param {Widget Id} wid
 * @returns widgetConfig
 */
export const getWidgetFromLib = async (wid) => {
  const data = { doc_id: wid };
  const response = await api(getMLUrl() + "/api/get_doc", data);
  if (response && response.status) {
    return response.data;
  }
  return null;
};

export const getClusterName = async (
  user,
  block,
  phase,
  runTag,
  checkpoint,
  timeStamp,
  project
) => {
  const data = {
    user: user,
    block: block,
    phase: phase,
    runTag: runTag,
    checkpoint: checkpoint,
    timeStamp: timeStamp,
    project: project,
  };
  const response = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/api/getClusterName/",
    data
  );
  console.log(response);
  if (response && response.status) {
    return response.name;
  }
};

/**
 *
 * @param {Name of the widget} widgetName
 * @param {config} config
 * @param {*} description
 */

export const saveWidgetInLib = async (widgetName, config, metaData) => {
  const [cluster, key] = _.get(config, "dataLocation", "").split("#");

  const configCopy = _.cloneDeep(config);
  const input = {
    doc_id: _.get(config, "doc_id", nanoid()),
    title: _.get(config, "title", ""),
    content: _.get(config, "query", ""),
    category: "widgets_library",
    tags: _.get(metaData, "tags", ""),
    description: _.get(metaData, "description", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
    widget_name: widgetName,
  };

  delete configCopy.title;
  delete configCopy.dataLocation;
  delete configCopy.query;

  // extracting radio selections
  const radioSelections = _.get(metaData, "radioSelections", {});

  const extras = {
    cluster: cluster,
    location: key,
    bucket: _.get(config, "bucket", ""),
    //reordering : radioSelections keys should overwrite configCopy keys
    ...configCopy,
    ...radioSelections,
  };

  input.extras = extras;

  const response = await api(getMLUrl() + "/api/index_document", input);

  if (response.status) {
    toast.info(`Widget added to library`, {
      position: toast.POSITION.BOTTOM_LEFT,

      style: {
        fontSize: "14px",
        padding: "8px  12px",
      },
    });
  } else {
    toast.error(response.data.message, {
      position: toast.POSITION.BOTTOM_LEFT,
      style: { backgroundColor: "red", color: "white" },
    });
  }

  return response;
};

/**
 * create settings which contain Config and metaData of the widget
 * along with height, width, x and y coordinates
 * @param {Name of the widget} widgetName
 * @param {properties of widget fetched from widget library} template
 * @returns settings: an object containing config and metaData of widget
 */
export const getWidgetSettings = (widgetName, template) => {
  let settings = { x: 0, y: -1, w: 15, h: 10, name: widgetName };

  const templateCopy = _.cloneDeep(template);

  // create dataLocation from separate keys
  let dataLocation =
    _.get(template, "cluster", "") + "#" + _.get(template, "location", "");

  //list of unneccesary properties
  const deletePropList = [
    "location",
    "cluster",
    "content",
    "description",
    "category",
    "tags",
    "chunk",
    "user",
    "created_at",
    "updated_at",
    "doc_id",
    "score",
    "widget_name",
  ];

  //delete unneccesary properties from template
  for (let index in deletePropList) {
    delete templateCopy[deletePropList[index]];
  }

  //rest of the properties are config
  const config = { ...templateCopy };

  config.dataLocation = dataLocation;
  config.query = _.get(template, "content", "");

  const metaData = {};
  metaData.description = _.get(template, "description", "");
  metaData.tags = _.get(template, "tags", "");

  // since template is a flat object, it does NOT have 'metaData' column. Hence we loose, description/tags/radioSelections keys
  // loop through known keys of filterList
  const radioSelections = {};
  const columnsToRemove = [
    "description",
    "tags",
    "user",
    "doc_id",
    "widget_name",
    "title",
  ];
  filterList
    .filter((item) => !columnsToRemove.includes(item.column))
    .forEach((item) => {
      const { column } = item;
      const valueFound = _.get(template, column, "");
      if (valueFound && valueFound.length > 0) {
        radioSelections[column] = valueFound;
      }
    });
  metaData.radioSelections = radioSelections;

  settings.metaData = metaData;
  settings.config = config;

  settings.w = _.get(templateCopy, "w", 15);
  settings.h = _.get(templateCopy, "h", 10);

  return settings;
};

/**
 *
 * @returns Widget library table data
 */
export const getWidgetLibTableData = async () => {
  let data = [];
  const enpointUrl = getMLUrl() + "/api/list_documents";
  const input = { category: "widgets_library", page: 1 };
  const response = await api(enpointUrl, input);
  if (response && response.status) {
    data = response.data;
  } else {
    console.log(response);
  }
  return data;
};

/**
 * compares to tabulator columns list with field and visible properties
 * retunrs true if both are same otherwise false
 * @param {Array} cols1
 * @param {Array} cols2
 * @returns {Boolean}
 */
export const isColOrderSame = (cols1, cols2) => {
  if (cols1.length !== cols2.length) {
    return false;
  }

  for (let i = 0; i < cols1.length; i++) {
    const column1 = cols1[i];
    const column2 = cols2[i];

    if (column1.field !== column2.field) {
      return false;
    }

    if (column1.visible !== column2.visible) {
      return false;
    }

    if (column1.columns && column2.columns) {
      if (!isColOrderSame(column1.columns, column2.columns)) {
        return false;
      }
    } else if (column1.columns || column2.columns) {
      return false;
    }
  }

  return true;
};

/**
 * returns build name with renaming configuration
 * @param {string} value // build name
 * @param {Object} buildsNomenclature // build rename config
 * @returns @String
 */
export const getBuildsNomenclature = (
  value,
  buildsNomenclature = {},
  label = ""
) => {
  let newBuildNameList = [];
  if (
    Object.keys(buildsNomenclature).length &&
    value &&
    value.split("/").length >= 5
  ) {
    for (let i = 0; i < tags.length; i++) {
      if (_.get(buildsNomenclature[tags[i].field], "show", true)) {
        if (value.split("/")[i]) {
          newBuildNameList.push(value.split("/")[i].split("###").slice(0)[0]);
        }
      }
    }

    let newValue = newBuildNameList.join("/");
    if (_.get(buildsNomenclature, ["label", "show"], false) && label) {
      newValue = newValue + " ( " + label + " ) ";
    }

    if (
      _.get(buildsNomenclature["baselineMarker"], "show", true) &&
      value.includes("###") &&
      value.split("###").length == 2
    ) {
      newValue = newValue + "###" + value.split("###")[1];
    }
    return newValue;
  }
  return value;
};

/* 
  downloads table snapshot
*/
export const downloadTableSnapshot = (referenceProvided) => {
  htmlToImage
    .toPng(referenceProvided)
    .then(function (dataUrl) {
      const link = document.createElement("a");
      link.href = dataUrl;
      link.download = "table_snapshot.png";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    })
    .catch(function (error) {
      console.error("Something went wrong in downloading image!", error);
    });
};

/**
 * This is special parsing function unlike default JS parseFloat
 * It parses if the value is a valid float unlike default where it parses the first number
 * @param {String} str
 * @returns parsed string
 */
export const parseStringToFloat = (str) => {
  //Regexp to match a valid float number
  const floatRegex = /^[+-]?(\d+(\.\d*)?|\.\d+)$/;

  // check if the entire string is a valid fload
  if (floatRegex.test(str)) {
    return parseFloat(str);
  } else {
    //If not a valid float, return the original string
    return str;
  }
};

// method used to export selected div into an HTML file
export const exportToHTML = (referenceProvided, fileName) => {
  const height = referenceProvided.scrollHeight; // height is being used to get the full report HTML for tabbed view
  htmlToImage
    .toPng(referenceProvided, { height })
    .then(function (dataUrl) {
      // logic to download HTML file
      const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${fileName}</title>
    </head>
    <body style="display:flex; justify-content: center; align-items:center">
        <img src="${dataUrl}" alt="dashboard snap">
    </body>
    </html>
    `;

      const blob = new Blob([htmlContent], { type: "text/plain" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${fileName}.html`;
      a.click();
    })
    .catch(function (error) {
      console.error("Something went wrong in exporting HTML file!", error);
    });
};
