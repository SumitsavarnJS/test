let perfStart = 0;

export function perfInit() {
    perfStart = Date.now();
}

export function perfReport(msg) {
    let perfElapsed = Date.now() - perfStart;
    perfStart = 0;
    console.log("PERF: " + msg + ": ", perfElapsed + " (ms)");
}

export function secondsSinceEpoch() {
    var d = new Date();
    var seconds = Math.round(d.getTime() / 1000);
    return seconds;
}

// Return date string from seconds
export function dateFromSeconds(seconds) {
    let date = new Date(seconds * 1000);

    let year = date.getFullYear();

    let month = date.getMonth() + 1;
    if (month < 10) {
        month = "0" + month;
    }

    let day = date.getDate();
    if (day < 10) {
        day = "0" + day;
    }

    let hours = date.getHours();
    if (hours < 10) {
        hours = "0" + hours;
    }

    let mins = date.getMinutes();
    if (mins < 10) {
        mins = "0" + mins;
    }

    let secs = date.getSeconds();
    if (secs < 10) {
        secs = "0" + secs;
    }

    let msg = year + "-" + month + "-" + day + " " + hours + ":" + mins + ":" + secs;

    return msg;
}

// Return elapsed time string from seconds
export function elapsedTimeFromSeconds(seconds) {
    let hourSecs = 60 * 60;
    let minSecs = 60;

    let hours = Math.floor(seconds / hourSecs);
    let remainingSecs = seconds - hours * hourSecs;

    let mins = Math.floor(remainingSecs / minSecs);
    remainingSecs = remainingSecs - mins * minSecs;

    let secs = remainingSecs;

    //    9 -> 0009
    //   99 -> 0099
    //  999 -> 0999
    // 9999 -> 9999

    if (hours < 10) {
        hours = "000" + hours;
    } else if (hours < 100) {
        hours = "00" + hours;
    } else if (hours < 1000) {
        hours = "0" + hours;
    }
    if (mins < 10) {
        mins = "0" + mins;
    }
    if (secs < 10) {
        secs = "0" + secs;
    }

    let msg = hours + ":" + mins + ":" + secs;
    return msg;
}

export function getSecsFromYearMonthDay(text) {
    let time = null;
  
    if (text != null) {
      let regex = "^(\\d\\d\\d\\d)-(\\d\\d)-(\\d\\d)";
      let re = new RegExp(regex);
      let reMatch = re.exec(text);
  
      let year = reMatch[1];
      let month = reMatch[2];
      let day = reMatch[3];
  
      year = parseInt(year);
      month = parseInt(month) - 1;
      day = parseInt(day);
  
      let theDate = new Date();
      theDate.setFullYear(year);
      theDate.setMonth(month);
      theDate.setDate(day);
      theDate.setHours(0);
      theDate.setMinutes(0);
      theDate.setSeconds(0);
  
      time = Math.floor(theDate.getTime() / 1000);
    }
  
    return time;
  }