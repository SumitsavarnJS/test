////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/common/Funcs.js#89 $
////////////////////////////////////////////////////////////////////////////////

import React from "react";
import _ from "lodash";
// import * as fastapi from "common/FastApi";
// import { Store } from "react-notifications-component";
import { toast } from "react-toastify";
import Cookies from "js-cookie";

////////////////////////////////////////////////////////////////////////////////
// Window resize
////////////////////////////////////////////////////////////////////////////////

export const ResizeDelay = 500;

export function getReportSize() {
  let divMetricsMainTop = document.getElementById("divMetricsMainTop");
  let divMetricsMainLeft = document.getElementById("divMetricsMainLeft");
  let divMetricsMainRight = document.getElementById("divMetricsMainRight");
  if (divMetricsMainTop == null || divMetricsMainLeft == null || divMetricsMainRight == null) {
    return null;
  }

  let windowHeight = document.documentElement.clientHeight;
  let windowWidth = document.documentElement.clientWidth;

  let topRect = divMetricsMainTop.getBoundingClientRect();
  let leftRect = divMetricsMainLeft.getBoundingClientRect();

  let topHeight = windowHeight - topRect.y;

  let adjustWidth = 10;

  let rightWidth = windowWidth - leftRect.width - adjustWidth;

  let reportSize = {
    height: topHeight,
    width: rightWidth,
  };
  return reportSize;
}

////////////////////////////////////////////////////////////////////////////////
// New doc creation
////////////////////////////////////////////////////////////////////////////////

export const SpecType = Object.freeze({
  NONE: 0,
  DIR: 1,
  REPORT: 2,
  BUILD: 3,
  HIER: 4,
});

export const DocVersion = Object.freeze({
  BLD: "2.0",
  SUM: "2.0",
  AUX: "2.0",
  USERDATA: "3.0",
  PROJDATA: "3.0",
  REPORTSPECS: "3.0",
  BUILDSPECS: "1.0",
  HIERSPECS: "2.0",
  SNAPSHOT: "1.0",
});

export function newUserDataDoc({ userName = "", userPwd = "", userEmail = "", adminFlag = false, authFlag = true } = {}) {
  let doc = {};
  doc.VERSION = DocVersion.USERDATA;
  doc.userName = userName;
  doc.userPwd = userPwd;
  doc.userEmail = userEmail;
  doc.adminFlag = adminFlag;
  doc.authFlag = authFlag;
  doc.projectsMember = [];
  doc.projectsManager = [];
  return doc;
}

export function newProjDataDoc({ projectName = "" } = {}) {
  let doc = {};
  doc.VERSION = DocVersion.PROJDATA;
  doc.projectName = projectName;
  return doc;
}

export function newReportSpecDoc({ fullName = null, data = {} } = {}) {
  let doc = {};
  doc.VERSION = DocVersion.REPORTSPECS;
  doc.fullName = fullName;
  doc.data = data;
  return doc;
}

export function newBuildSpecDoc({ fullName = null, data = [] } = {}) {
  let doc = {};
  doc.VERSION = DocVersion.BUILDSPECS;
  doc.fullName = fullName;
  doc.data = data;
  return doc;
}

const exampleHierSpec = [
  {
    blockName: "chip",
    _children: [
      { instName: "u_blockA_0", blockName: "blockA" },
      { instName: "u_blockA_1", blockName: "blockA" },
      {
        instName: "u_blockB",
        blockName: "blockB",
        _children: [
          { instName: "u_childA", blockName: "childA" },
          {
            instName: "u_childB",
            blockName: "childB",
            _children: [
              { instName: "u_grandChildA", blockName: "grandChildA" },
              { instName: "u_grandChildB", blockName: "grandChildB" },
            ],
          },
        ],
      },
    ],
  },
];

export function newHierSpecDoc({ fullName = null } = {}) {
  let doc = {};
  doc.VERSION = DocVersion.HIERSPECS;
  doc.fullName = fullName;
  doc.data = exampleHierSpec;
  doc.projectName = "";
  doc.seriesName = "";
  return doc;
}

export function newSnapshotDoc({ projectName = null, seriesName = null, snapshotName = null, data = {} } = {}) {
  let doc = {};
  doc.VERSION = DocVersion.SNAPSHOT;
  doc.projectName = projectName;
  doc.seriesName = seriesName;
  doc.snapshotName = snapshotName;
  doc.data = data;
  return doc;
}

export function specDisplayText(fullName) {
  let displayText;

  if (fullName == null) {
    displayText = "---";
  } else {
    let parts = fullName.split("/");
    if (parts[0] == "Admin") {
      parts.splice(1, 1);
      displayText = parts.join("/");
    } else {
      displayText = fullName;
    }
  }

  return displayText;
}

////////////////////////////////////////////////////////////////////////////////
// Default metric data structures
////////////////////////////////////////////////////////////////////////////////

export const defaultColorRule = Object.freeze({
  color: "improve_degrade",
  improves: "zero",
  lightPct: 0.005,
  medPct: 0.02,
  darkPct: 0.1,
  absThreshold: 0,
  refValue: null,
});

// rollup.calculate : no | yes | ifMissing
// rollup.math      : sum | avg | min | max
// rollup.incParent : no | yes | ifPresent

export const defaultRollup = Object.freeze({
  calculate: "no",
  math: "sum",
  incParent: "no",
});

export const defaultSummary = Object.freeze({
  calculate: "no",
  math: "sum",
  incParent: "no",
});

export const defaultMetricDef = Object.freeze({
  displayName: "",
  indexList: ["$buildName", "checkpoints", "$checkpointName", "sum_or_aux"],
  tooltip: "",
  groupName: "",
  hidden: false,
  colorRule: defaultColorRule,
  defaultCheckpoint: null,
  defaultRollup: defaultRollup,
  defaultSummary: defaultSummary,
});

export const TABS_HEIGHT = 30;
export const BUTTONS_HEIGHT = 40;

export const LOWER_PANE_MIN_HEIGHT = BUTTONS_HEIGHT + 10;
export const LOWER_PANE_MAX_HEIGHT = TABS_HEIGHT + 30;

////////////////////////////////////////////////////////////////////////////////
// color support
////////////////////////////////////////////////////////////////////////////////

let _colors = {
  Snps: { fg: "#5a2a82", bg: "#5a2a82" },
  Blue: { fg: "#007bff", bg: "#007bff" },
  Green: { fg: "#00ff7b", bg: "#00ff7b" },
  DarkGreen: { fg: "#008000", bg: "#008000" },
  Black: { fg: "#000000", bg: "#000000" },
  White: { fg: "#ffffff", bg: "#ffffff" },
  Red: { fg: "#ff0000", bg: "#ff0000" },
  Orange: { fg: "#e0a800", bg: "#e0a800" },
  DarkGray: { fg: "#e0e0e0", bg: "#e0e0e0" },
  LightGray: { fg: "#f0f0f0", bg: "#f0f0f0" },
  Default: { fg: "#000000", bg: "#ffffff" },
  Alt: { fg: "#000000", bg: "#e0e0e0" },
  Faded: { fg: "#c0c0c0", bg: "#ffffff" },
  ImprovedSmall: { fg: "#000000", bg: "#e0ffe0" },
  ImprovedMedium: { fg: "#000000", bg: "#b0ffb0" },
  ImprovedLarge: { fg: "#000000", bg: "#80ff80" },
  DegradedSmall: { fg: "#000000", bg: "#ffe0e0" },
  DegradedMedium: { fg: "#000000", bg: "#ffb0b0" },
  DegradedLarge: { fg: "#000000", bg: "#ff8080" },
  SmallDelta: { fg: "#404040", bg: "#ffffff" },
  None: { fg: "#000000", bg: "#ffffff" },
  DiffMiss: { fg: "#000000", bg: "#E67E22" },
  extraCheckpoint: { fg: "#000000", bg: "#F4D03F" },
  missingCheckpoint: { fg: "#000000", bg: "#E67E22" },
  tableHeader: { fg: "#000000", bg: "#E6E6E6" },
  textFile: { fg: "#000000", bg: "#ffffff" },
  imageFile: { fg: "#5a2a82", bg: "#ffffff" },
  htmlFile: { fg: "#007bff", bg: "#ffffff" },
  Error: { fg: "#ff0000", bg: "#ff0000" },
  Warning: { fg: "#ffc107", bg: "#ffc107" },
  waiveColorRule: { fg: "#000000", bg: "#808080" },
};

export function palette(arg) {
  let color = _colors["Default"];
  if (_colors.hasOwnProperty(arg)) {
    color = _colors[arg];
  }
  return color;
}

export function paletteExcel(arg) {
  let color = _colors["Default"];
  if (_colors.hasOwnProperty(arg)) {
    color = _colors[arg];
  }
  let fg = color.fg.substring(1);
  let bg = color.bg.substring(1);
  color = { fg: fg, bg: bg };
  return color;
}

// ECharts default series colors
// export const plotColorList = Object.freeze(["#5470c6", "#91cc75", "#fac858", "#ee6666", "#73c0de", "#3ba272", "#fc8452", "#9a60b4", "#ea7ccc"]);

// Qualitative series colors from https://colorbrewer2.org/
export const plotColorList = Object.freeze([
  "#e41a1c",
  "#377eb8",
  "#4daf4a",
  "#984ea3",
  "#ff7f00",
  "#ffff33",
  "#a65628",
  "#f781bf",
  "#999999",
  "#8dd3c7",
  "#ffffb3",
  "#bebada",
  "#fb8072",
  "#80b1d3",
  "#fdb462",
  "#b3de69",
  "#fccde5",
  "#d9d9d9",
]);

////////////////////////////////////////////////////////////////////////////////
// Debug functions
////////////////////////////////////////////////////////////////////////////////

// To halt execution:
// debugger;
//
// To measuring time:
// console.time('someName');
// console.timeLog('someName');
// console.timeEnd('someName');
//
// Print stuff out in table format:
// console.table(obj)

// performance.mark("begin");
//
// performance.mark("point1");
// performance.measure("point1", "begin", "point1");

export function performanceSummary() {
  for (let entry of performance.getEntriesByType("measure")) {
    console.log("PERFORMANCE: ", entry.name, entry.duration);
  }
  performance.clearMarks();
  performance.clearMeasures();
}

////////////////////////////////////////////////////////////////////////////////
// Cookie support
////////////////////////////////////////////////////////////////////////////////

export function readCookie(name) {
  let rawCookie = Cookies.get(name);
  let cookie = {};
  if (rawCookie != undefined) {
    cookie = JSON.parse(rawCookie);
  }
  return cookie;
}

export function writeCookie(name, value, options = {}) {
  let valueString = JSON.stringify(value);
  let optionsAdjusted = _.cloneDeep(options);
  optionsAdjusted["SameSite"] = "Lax";
  Cookies.set(name, valueString, optionsAdjusted);
}

////////////////////////////////////////////////////////////////////////////////
// Misc generic functions (not related to specific reports)
////////////////////////////////////////////////////////////////////////////////

export async function fetchPublicJSON(fileName) {
  const response = await fetch(fileName);
  return response.json();
}

// Check if property exists in generic object
export function propExists(obj, level, ...rest) {
  if (obj === undefined) return false;
  if (rest.length == 0 && obj.hasOwnProperty(level)) return true;
  return propExists(obj[level], ...rest);
}

// Get property value from generic object
// path.reduce( reducerMethod, initialValue );
// path.reduce( (acc, item) => {algorithm}, initialValue );
export function getPropValue(object, path = []) {
  let value = path.reduce((o, x) => (o == undefined ? o : o[x]), object);
  if (value == null) {
    // avoid returning undefined
    value = null;
  }
  return value;
}

// Check if list contains object
export function listContainsObject(obj, list) {
  for (let i = 0; i < list.length; i++) {
    let listObj = list[i];
    if (_.isEqual(obj, listObj)) {
      return true;
    }
  }
  return false;
}

// Compare objects while ignoring functions
export function isEqualSkipFuncs(o1, o2) {
  return _.isEqualWith(o1, o2, function (val1, val2) {
    if (_.isFunction(val1) && _.isFunction(val2)) {
      return true;
    }
  });
}

// Compare objects including array order
export function isEqualWithArrayOrder(o1, o2) {
  let isEqual = JSON.stringify(o1) == JSON.stringify(o2);
  return isEqual;
}

export function isNumber(value) {
  return !isNaN(value) && !isNaN(parseFloat(value));
}

export function sortCheckpointName(a, b) {
  if (a.checkpointName < b.checkpointName) {
    return -1;
  }
  if (a.checkpointName > b.checkpointName) {
    return 1;
  }
  return 0;
}

export function sortImageName(a, b) {
  if (a.imageName < b.imageName) {
    return -1;
  }
  if (a.imageName > b.imageName) {
    return 1;
  }
  return 0;
}

export function mergeLists(newList, orgList, key) {
  // Preserve order & content of orgList as much as possible

  let orgHash = {};
  for (let index in orgList) {
    let entry = orgList[index];
    let keyValue = entry[key];
    orgHash[keyValue] = _.cloneDeep(entry);
  }

  let newHash = {};
  for (let index in newList) {
    let entry = newList[index];
    let keyValue = entry[key];
    newHash[keyValue] = _.cloneDeep(entry);
  }

  let mergedList = [];

  // For each entry in orgList, if newList DOES contain entry,
  // newEntry inherits MATCHING props from orgEntry,
  // then add newEntry (with inherited props)
  for (let index in orgList) {
    let orgEntry = orgList[index];
    let keyValue = orgEntry[key];
    if (newHash.hasOwnProperty(keyValue)) {
      let newEntry = newHash[keyValue];
      for (let prop in newEntry) {
        if (orgEntry.hasOwnProperty(prop)) {
          newEntry[prop] = orgEntry[prop];
        }
      }
      mergedList.push(newEntry);
    }
  }

  // For each entry in newList, if orgList DOES NOT contain entry,
  // then add newEntry
  for (let index in newList) {
    let newEntry = newList[index];
    let keyValue = newEntry[key];
    if (!orgHash.hasOwnProperty(keyValue)) {
      mergedList.push(newEntry);
    }
  }

  return mergedList;
}

////////////////////////////////////////////////////////////////////////////////
// Time related support
////////////////////////////////////////////////////////////////////////////////

// Usage: await sleep(<duration>);
export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// XXX

let perfStart = 0;

export function perfInit() {
  perfStart = Date.now();
}

export function perfReport(msg) {
  let perfElapsed = Date.now() - perfStart;
  perfStart = 0;
  console.log("PERF: " + msg + ": ", perfElapsed + " (ms)");
}

export function secondsSinceEpoch() {
  var d = new Date();
  var seconds = Math.round(d.getTime() / 1000);
  return seconds;
}

// Return date string from seconds
export function dateFromSeconds(seconds) {
  let date = new Date(seconds * 1000);

  let year = date.getFullYear();

  let month = date.getMonth() + 1;
  if (month < 10) {
    month = "0" + month;
  }

  let day = date.getDate();
  if (day < 10) {
    day = "0" + day;
  }

  let hours = date.getHours();
  if (hours < 10) {
    hours = "0" + hours;
  }

  let mins = date.getMinutes();
  if (mins < 10) {
    mins = "0" + mins;
  }

  let secs = date.getSeconds();
  if (secs < 10) {
    secs = "0" + secs;
  }

  let msg = year + "-" + month + "-" + day + " " + hours + ":" + mins + ":" + secs;

  return msg;
}

// Return elapsed time string from seconds
export function elapsedTimeFromSeconds(seconds) {
  let hourSecs = 60 * 60;
  let minSecs = 60;

  let hours = Math.floor(seconds / hourSecs);
  let remainingSecs = seconds - hours * hourSecs;

  let mins = Math.floor(remainingSecs / minSecs);
  remainingSecs = remainingSecs - mins * minSecs;

  let secs = remainingSecs;

  //    9 -> 0009
  //   99 -> 0099
  //  999 -> 0999
  // 9999 -> 9999

  if (hours < 10) {
    hours = "000" + hours;
  } else if (hours < 100) {
    hours = "00" + hours;
  } else if (hours < 1000) {
    hours = "0" + hours;
  }
  if (mins < 10) {
    mins = "0" + mins;
  }
  if (secs < 10) {
    secs = "0" + secs;
  }

  let msg = hours + ":" + mins + ":" + secs;
  return msg;
}

export function getSecsFromYearMonthDay(text) {
  let time = null;

  if (text != null) {
    let regex = "^(\\d\\d\\d\\d)-(\\d\\d)-(\\d\\d)";
    let re = new RegExp(regex);
    let reMatch = re.exec(text);

    let year = reMatch[1];
    let month = reMatch[2];
    let day = reMatch[3];

    year = parseInt(year);
    month = parseInt(month) - 1;
    day = parseInt(day);

    let theDate = new Date();
    theDate.setFullYear(year);
    theDate.setMonth(month);
    theDate.setDate(day);
    theDate.setHours(0);
    theDate.setMinutes(0);
    theDate.setSeconds(0);

    time = Math.floor(theDate.getTime() / 1000);
  }

  return time;
}

////////////////////////////////////////////////////////////////////////////////
// Tabulator tooltip support
////////////////////////////////////////////////////////////////////////////////

export function formattedTextTooltip(text, w, h) {
  var el = document.createElement("div");
  el.style.backgroundColor = "black";
  el.style.color = "white";
  // el.style.width = w;
  // el.style.height = h;
  el.style.fontSize = "14px";
  el.style.paddingLeft = "10px";
  el.style.paddingTop = "10px";
  el.style.borderRadius = "6px";
  el.style.position = "sticky";
  // el.style.zIndex = 1000;
  el.innerText = text;
  return el;
}

////////////////////////////////////////////////////////////////////////////////
// Tabulator sort support
////////////////////////////////////////////////////////////////////////////////

export function customSorterDisplayValue(a, b, aRow, bRow, column, dir, sorterParams) {
  let aValue = a.displayValue == null ? "" : a.displayValue;
  let bValue = b.displayValue == null ? "" : b.displayValue;

  let aIsNumber = isNumber(aValue);
  let bIsNumber = isNumber(bValue);
  if (aIsNumber && bIsNumber) {
    let aNumber = parseFloat(aValue);
    let bNumber = parseFloat(bValue);
    return aNumber - bNumber;
  } else {
    let aString = String(aValue);
    let bString = String(bValue);
    if (aString > bString) {
      return Number.POSITIVE_INFINITY;
    } else {
      return Number.NEGATIVE_INFINITY;
    }
  }
}

////////////////////////////////////////////////////////////////////////////////
// Tabulator filter support
////////////////////////////////////////////////////////////////////////////////

// Glob filters

export function globMatch(pattern, text, options) {
  // Ensure glob pattern extends to end of text
  let globPattern = pattern;
  if (!globPattern.endsWith("$") && !globPattern.endsWith("*")) {
    globPattern = globPattern + "*";
  }

  // Convert glob to rex
  let regxPattern = "^" + globPattern.replace(/\*/g, ".*") + "$";

  let re;
  if (options.nocase == true) {
    re = new RegExp(regxPattern, "i");
  } else {
    re = new RegExp(regxPattern);
  }

  let match = re.test(text);

  return match;
}

export function globFilter(headerValue, rowValue) {
  if (rowValue == undefined) {
    return false;
  }
  return globMatch(headerValue, rowValue.toString(), { nocase: true });
}

export function epochGlobFilter(headerValue, rowValue) {
  if (rowValue == undefined) {
    return false;
  }
  return globMatch(headerValue, dateFromSeconds(rowValue), {});
}

export function globFilterDisplayValue(headerValue, rowValue) {
  if (rowValue == undefined) {
    return false;
  }
  let pattern = headerValue;
  let cellText = rowValue.displayValue;
  let options = { nocase: true };
  return globMatch(pattern, cellText.toString(), options);
}

export function globFilterDisplayValueTooltip(e, cell, onRendered) {
  let msg = "This is a glob-style filter.";
  return formattedTextTooltip(msg, "300px", "50px");
}

// Custom filters

export function customMatch(headerValue, strCell) {
  let match = false;

  let numCell = null;

  let reMode = headerValue.startsWith(";;");
  let compareMode = headerValue.startsWith("::");

  if (reMode) {
    let headerStr = headerValue.substring(2);
    let reRegExp = /(.*)$/;

    let reMatchRegExp = reRegExp.exec(headerStr);
    let opRegExp = null;
    if (reMatchRegExp != null) {
      opRegExp = reMatchRegExp[1];
    }

    if (opRegExp == null) {
      match = false;
    } else {
      let reIsValid = true;
      try {
        new RegExp(opRegExp);
      } catch (e) {
        reIsValid = false;
      }

      if (reIsValid) {
        let regexp = new RegExp(opRegExp);
        match = regexp.test(strCell);
      } else {
        match = false;
      }
    }
  } else if (compareMode) {
    let headerStr = headerValue.substring(2);
    let reLessThan = /(<=|<)([^,\s]+)/;
    let reMoreThan = /(>=|>)([^,\s]+)/;

    let opLessThan = null;
    let opMoreThan = null;
    let strLessThan = null;
    let strMoreThan = null;
    let numLessThan = null;
    let numMoreThan = null;

    let reMatchLessThan = reLessThan.exec(headerStr);
    let reMatchMoreThan = reMoreThan.exec(headerStr);

    if (reMatchLessThan != null) {
      opLessThan = reMatchLessThan[1];
      strLessThan = reMatchLessThan[2];
    }
    if (reMatchMoreThan != null) {
      opMoreThan = reMatchMoreThan[1];
      strMoreThan = reMatchMoreThan[2];
    }

    numLessThan = parseFloat(strLessThan);
    if (Number.isNaN(numLessThan)) {
      numLessThan = null;
    }
    numMoreThan = parseFloat(strMoreThan);
    if (Number.isNaN(numMoreThan)) {
      numMoreThan = null;
    }
    numCell = parseFloat(strCell);
    if (Number.isNaN(numCell)) {
      numCell = null;
    }

    if (numCell != null) {
      let matchLessThan = true;
      let matchMoreThan = true;

      if (reMatchLessThan && numLessThan != null) {
        if (opLessThan) {
          if (opLessThan.includes("=")) {
            matchLessThan = numCell <= numLessThan;
          } else {
            matchLessThan = numCell < numLessThan;
          }
        }
      }

      if (reMatchMoreThan && numMoreThan != null) {
        if (opMoreThan) {
          if (opMoreThan.includes("=")) {
            matchMoreThan = numCell >= numMoreThan;
          } else {
            matchMoreThan = numCell > numMoreThan;
          }
        }
      }

      match = matchLessThan && matchMoreThan;
    }
  } else {
    // glob mode
    let options = { nocase: true };
    match = globMatch(headerValue, strCell, options);
  }

  return match;
}

export function customFilter(headerValue, rowValue) {
  if (rowValue == undefined) {
    return false;
  }
  return customMatch(headerValue, rowValue.toString());
}

export function customFilterDisplayValue(headerValue, rowValue, rowData, filterParams) {
  if (rowValue == undefined) {
    return false;
  }
  if (rowValue.displayValue == undefined) {
    return false;
  }
  let strCell = rowValue.displayValue.toString();
  return customMatch(headerValue, strCell);
}

export function customFilterDisplayValueTooltip(e, cell, onRendered) {
  let msg = "This is a custom filter.";

  msg += "\nIf the value starts with ';;',";
  msg += "\nthe remaining chars are used as a regular expression.";
  msg += "\n";
  msg += "\nIf the value starts with '::',";
  msg += "\nand the remaining chars contain comparison operators:";
  msg += "\n'<MAX'      - Filter shows: cells < MAX.";
  msg += "\n'<=MAX'     - Filter shows: cells <= MAX.";
  msg += "\n'>MIN'      - Filter shows: cells > MIN.";
  msg += "\n'>=MIN'     - Filter shows: cells >= MIN.";
  msg += "\n'<MAX,>MIN' - Filter shows: MIN < cells < MAX.";
  msg += "\n'>MIN,<MAX' - Filter shows: MIN < cells < MAX.";
  msg += "\n'>MIN,<MAX' - Filter shows: MIN < cells < MAX.";
  msg += "\n";
  msg += "\nIf the value does not start with either ';;' or '::',";
  msg += "\nthis is a glob-style filter.";

  return formattedTextTooltip(msg, "300px", "460px");
}

// Time filters

export function timeFilter(headerValue, rowValue, rowData, filterParams) {
  let match = false;

  if (rowValue == undefined) {
    return match;
  }

  let pattern = headerValue;
  let timeRow = rowValue;

  let regex;
  let re;
  let reMatch;

  let textMin = null;
  let textMax = null;

  // Check for both textMin and textMax
  regex = "^(\\d\\d\\d\\d-\\d\\d-\\d\\d),(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
  re = new RegExp(regex);
  reMatch = re.exec(pattern);
  if (reMatch) {
    textMin = reMatch[1];
    textMax = reMatch[2];
  } else {
    // Check for only textMin
    regex = "^(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
    re = new RegExp(regex);
    reMatch = re.exec(pattern);
    if (reMatch) {
      textMin = reMatch[1];
    } else {
      // Check for only textMax
      regex = "^,(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
      re = new RegExp(regex);
      reMatch = re.exec(pattern);
      if (reMatch) {
        textMax = reMatch[1];
      }
    }
  }

  let timeMin = getSecsFromYearMonthDay(textMin);
  let timeMax = getSecsFromYearMonthDay(textMax);

  if (timeMin && timeMax) {
    match = timeRow > timeMin && timeRow < timeMax;
  } else if (timeMin && !timeMax) {
    match = timeRow > timeMin;
  } else if (!timeMin && timeMax) {
    match = timeRow < timeMax;
  } else {
    match = true;
  }

  return match;
};

export function timeFilterTooltip(e, cell, onRendered) {
  let msg = "This is a custom filter.";
  msg += "\n";
  msg += "\nThe formats are:";
  msg += "\n";
  msg += "\nYYYY-MM-DD";
  msg += "\nThis specifies a MIN date.";
  msg += "\nFilter shows: cells > MIN date.";
  msg += "\n";
  msg += "\n,YYYY-MM-DD";
  msg += "\nThis specifies a MAX date.";
  msg += "\nFilter shows: cells < MAX date.";
  msg += "\n";
  msg += "\nYYYY-MM-DD,YYYY-MM-DD";
  msg += "\nThis specifies both a MIN date and a MAX date.";
  msg += "\nFilter shows: MIN date < cells < MAX date.";

  return formattedTextTooltip(msg, "280px", "460px");
}

////////////////////////////////////////////////////////////////////////////////
// Tabulator filter input support
////////////////////////////////////////////////////////////////////////////////

export function customInput(cell, onRendered, success, cancel, editorParams) {
  //create and style input
  var cellValue = cell.getValue(),
    input = document.createElement("input");

  input.setAttribute("type", editorParams.search ? "search" : "text");

  input.style.padding = "4px";
  input.style.width = "100%";
  input.style.boxSizing = "border-box";

  if (editorParams.elementAttributes && typeof editorParams.elementAttributes == "object") {
    for (let key in editorParams.elementAttributes) {
      if (key.charAt(0) == "+") {
        key = key.slice(1);
        input.setAttribute(key, input.getAttribute(key) + editorParams.elementAttributes["+" + key]);
      } else {
        input.setAttribute(key, editorParams.elementAttributes[key]);
      }
    }
  }

  input.value = typeof cellValue !== "undefined" ? cellValue : "";
  highlightInput(input);

  onRendered(function () {
    input.focus({ preventScroll: true });
    input.style.height = "100%";
  });

  function onChange(e) {
    if (((cellValue === null || typeof cellValue === "undefined") && input.value !== "") || input.value !== cellValue) {
      if (success(input.value)) {
        cellValue = input.value; //persist value if successfully validated incase editor is used as header filter
      }
    } else {
      cancel();
    }
  }

  //submit new value on blur or change
  input.addEventListener("change", onChange);
  input.addEventListener("blur", onChange);

  // Hack of Tabulator code to highlight non-empty filters

  function highlightListener(e) {
    highlightInput(e.target);
  }

  function highlightInput(input) {
    let text = input.value;
    let reEmpty = new RegExp("^$");
    if (text.match(reEmpty)) {
      input.style.background = "#ffffff";
    } else {
      input.style.background = "#ffffc0";
    }
  }

  input.addEventListener("input", highlightListener);

  //submit new value on enter
  input.addEventListener("keydown", function (e) {
    switch (e.keyCode) {
      // case 9:
      case 13:
        onChange(e);
        break;

      case 27:
        cancel();
        break;

      case 35:
      case 36:
        e.stopPropagation();
        break;
    }
  });

  if (editorParams.mask) {
    this.table.modules.edit.maskInput(input, editorParams);
  }

  return input;
}

////////////////////////////////////////////////////////////////////////////////
// Support for popup notifications
////////////////////////////////////////////////////////////////////////////////

export function showNotification(message = "", persistent = false, type = "awesome", container = "center", error = false) {

  if (error) {
    toast.error(message, {
      position: toast.POSITION.BOTTOM_LEFT,
      style: {
        fontSize: "14px",
        padding: "8px  12px",
      },
    });
  } else {
    toast.success(message, {
      position: toast.POSITION.BOTTOM_LEFT,
      style: {
        fontSize: "14px",
        padding: "8px  12px",
      },
    });
  }

  // alert(message)
  // let id = Store.addNotification(options);
  return 123;//id;
}

export function clearNotification(id = "") {
  // Store.removeNotification(id);
}

////////////////////////////////////////////////////////////////////////////////
// Support for accessing metrics
////////////////////////////////////////////////////////////////////////////////

export function getMetricDef(metricsObjs, metricName) {
  let metricDef = _.cloneDeep(defaultMetricDef);
  for (let metricsObj of metricsObjs) {
    if (metricsObj != null && metricsObj.hasOwnProperty(metricName)) {
      _.merge(metricDef, metricsObj[metricName]);
    }
  }
  return metricDef;
}

export function getMetricRaw(mongoData, metricsObjs, buildName, checkpointName, metricName) {
  let metricDef = getMetricDef(metricsObjs, metricName);
  let indexList = metricDef.indexList ? metricDef.indexList : [];
  let pathList = [];
  for (let index of indexList) {
    if (index.match(/^\$buildName/)) {
      pathList.push(buildName);
    } else if (index.match(/^\$checkpointName/)) {
      pathList.push(checkpointName);
    } else {
      pathList.push(index);
    }
  }

  let metricRaw = getPropValue(mongoData, pathList);
  return metricRaw;
}

export function getMetricValue(mongoData, metricsObjs, buildName, checkpointName, metricName) {
  let metricRaw = getMetricRaw(mongoData, metricsObjs, buildName, checkpointName, metricName);
  let metricValue = metricRaw2value(metricRaw);
  return metricValue;
}

export function getMetricLinkObj(mongoData, metricsObjs, buildName, checkpointName, metricName) {
  let metricRaw = getMetricRaw(mongoData, metricsObjs, buildName, checkpointName, metricName);
  let linkObj = metricRaw2linkObj(metricRaw);
  return linkObj;
}

export function metricRaw2value(metricRaw) {
  let metricValue = null;

  if (typeof metricRaw == "string") {
    let metricParts = metricRaw.split(/\|\|\|/);
    metricValue = metricParts[0];
  } else {
    metricValue = metricRaw;
  }

  return metricValue;
}

export function metricRaw2linkObj(metricRaw) {
  let linkObj = {
    fileName: null,
    lineNumber: 1,
  };

  if (typeof metricRaw == "string") {
    let metricParts = metricRaw.split(/\|\|\|/);

    let match;
    for (let i = 1; i < metricParts.length; i++) {
      let metricPart = metricParts[i];
      match = metricPart.match(/^F:(\S+)$/);
      if (match) {
        linkObj.fileName = match[1];
        continue;
      }
      match = metricPart.match(/^L:(\d+)$/);
      if (match) {
        linkObj.lineNumber = match[1];
        continue;
      }
    }
  }

  return linkObj;
}

export function isSpecialMetric(name) {
  let specialMetrics = [];
  specialMetrics.push("__latestCheckpointName");
  specialMetrics.push("__latestCheckpointUser");
  specialMetrics.push("__latestCheckpointDate");

  let match = false;
  for (let specialMetric of specialMetrics) {
    if (name == specialMetric) {
      match = true;
    }
  }
  return match;
}

// export async function getFileInfo(dataServer, systemConfig, fileData) {
//   let fname = fileData.fname;
//   let ftype = fileData.ftype;
//   let fid = fileData.fid;

//   let fstatus; // Values: OK, ERROR_FTYPE, ERROR_FNAME, ERROR_ACCESS
//   let fcontents = null;

//   let r = null;
//   if (ftype == "TEXT" || ftype == "IMAGE" || ftype == "HTML") {
//     if (fname != "") {
//       if (fid == null) {
//         r = await fastapi.readFileDisk(dataServer, systemConfig, fileData);
//       } else {
//         r = await fastapi.readFileMongo(dataServer, systemConfig, fileData);
//       }

//       if (r.success) {
//         fstatus = "OK";
//       } else {
//         fstatus = "ERROR_ACCESS";
//       }
//     } else {
//       fstatus = "ERROR_FNAME";
//     }
//   } else {
//     fstatus = "ERROR_FTYPE";
//   }

//   if (fstatus == "OK") {
//     let fileContents = r.fileContents;
//     if (ftype == "TEXT") {
//       // content is ASCII
//       fcontents = fileContents;
//     } else if (ftype == "IMAGE") {
//       // content is base64 encoded
//       fcontents = "data:image/jpeg;base64, " + fileContents;
//     } else if (ftype == "HTML") {
//       // content is not needed; a new fileName is returned
//       fcontents = null;
//       fname = r.fileName;
//     }
//   }

//   let fileInfo = _.cloneDeep(fileData);
//   fileInfo.fname = fname;
//   fileInfo.ftype = ftype;
//   fileInfo.fstatus = fstatus;
//   fileInfo.fcontents = fcontents;

//   return fileInfo;
// }

////////////////////////////////////////////////////////////////////////////////
// Support for table cell calculations
////////////////////////////////////////////////////////////////////////////////

export function calcCell(metricName, value, refValue, colorRules, isRefValue, displayMode) {
  let results = {};
  let colorRule = getColorRule(metricName, colorRules);
  let valueObj = calcValues(metricName, value, refValue, colorRule, isRefValue, displayMode);
  results.valueObj = valueObj;
  results.colors = calcColors(metricName, valueObj, colorRule, isRefValue);
  return results;
}

export function getColorRule(metricName, colorRules) {
  let colorRule = _.cloneDeep(defaultColorRule);
  for (let rule of colorRules) {
    _.merge(colorRule, rule);
  }
  return colorRule;
}

export function calcValues(metricName, value, refValue, colorRule, isRefValue) {
  let valueObj = {};

  let deltaValue = value;
  let deltaPercent = value;
  let valueNum = null;
  let valueRef = null;
  let valueNumAbs = null;
  let valueRefAbs = null;
  let deltaValueAbs = null;
  let deltaValueMag = null;
  let percentDeltaMag = null;
  let percentDeltaValue = null;

  let localRefValue = refValue;
  if (colorRule.refValue != null) {
    localRefValue = colorRule.refValue;
  }

  if (!isNumber(value)) {
    valueObj.isRefValue = isRefValue;
    valueObj.value = value;
    valueObj.refValue = localRefValue;

    valueObj.deltaValue = value;
    valueObj.deltaPercent = value;
    valueObj.valueNum = null;
    valueObj.valueRef = null;
    valueObj.valueNumAbs = null;
    valueObj.valueRefAbs = null;
    valueObj.deltaValueAbs = null;
    valueObj.deltaValueMag = null;
    valueObj.percentDeltaMag = null;
    valueObj.percentDeltaValue = null;

    return valueObj;
  }

  // isNumber(value) is already checked above, so no need to check again
  if (isNumber(localRefValue)) {
    valueNum = parseFloat(value);
    valueRef = parseFloat(localRefValue);

    valueNumAbs = Math.abs(valueNum);
    valueRefAbs = Math.abs(valueRef);

    deltaValue = valueNum - valueRef;
    deltaValueAbs = Math.abs(deltaValue);
    deltaValueMag = Math.abs(valueNumAbs - valueRefAbs);

    if (valueRefAbs == 0) {
      // denominator is zero
      if (deltaValueAbs == 0) {
        // numerator is zero; all percent values are 0
        percentDeltaValue = 0;
        percentDeltaMag = 0;
        deltaPercent = 0;
      } else {
        // numerator is non-zero; all percent values are +100 or -100
        if (deltaValue > 0) {
          percentDeltaValue = 100.0;
          percentDeltaMag = 100.0;
          deltaPercent = 100.0;
        } else {
          percentDeltaValue = 100.0;
          percentDeltaMag = 100.0;
          deltaPercent = -100.0;
        }
      }
    } else {
      // denominator is non-zero
      percentDeltaValue = deltaValueAbs / valueRefAbs; // always positive
      percentDeltaMag = deltaValueMag / valueRefAbs; // always positive
      deltaPercent = (100.0 * deltaValue) / valueRefAbs; // positive or negative
    }

    if (deltaValue >= 0) {
      deltaValue = "+" + deltaValue.toFixed(2);
    } else {
      deltaValue = deltaValue.toFixed(2);
    }
    if (deltaPercent >= 0) {
      deltaPercent = "+" + deltaPercent.toFixed(2) + "%";
    } else {
      deltaPercent = deltaPercent.toFixed(2) + "%";
    }
  }

  valueObj.isRefValue = isRefValue;
  valueObj.value = value;
  valueObj.refValue = localRefValue;
  valueObj.deltaValue = deltaValue;
  valueObj.deltaPercent = deltaPercent;
  valueObj.valueNum = valueNum;
  valueObj.valueRef = valueRef;
  valueObj.valueNumAbs = valueNumAbs;
  valueObj.valueRefAbs = valueRefAbs;
  valueObj.deltaValueAbs = deltaValueAbs;
  valueObj.deltaValueMag = deltaValueMag;
  valueObj.percentDeltaMag = percentDeltaMag;
  valueObj.percentDeltaValue = percentDeltaValue;

  return valueObj;
}

export function calcColors(metricName, valueObj, colorRule, isRefValue) {
  let colors = palette("Default");

  // Reference values are never colored
  if (isRefValue == true) {
    return colors;
  }

  if (colorRule.color == "improve_degrade") {
    if (isNumber(valueObj.value) && isNumber(valueObj.refValue)) {
      if (valueObj.deltaValueAbs <= colorRule.absThreshold) {
        colors = palette("SmallDelta");
      } else {
        let improved = false;
        if (colorRule.improves == "zero") {
          if (valueObj.valueNumAbs < valueObj.valueRefAbs) {
            improved = true;
          }
          colors = colorsByPercent(improved, valueObj.percentDeltaMag, colorRule);
        } else if (colorRule.improves == "larger") {
          if (valueObj.valueNum > valueObj.valueRef) {
            improved = true;
          }
          colors = colorsByPercent(improved, valueObj.percentDeltaValue, colorRule);
        } else if (colorRule.improves == "smaller") {
          if (valueObj.valueNum < valueObj.valueRef) {
            improved = true;
          }
          colors = colorsByPercent(improved, valueObj.percentDeltaValue, colorRule);
        }
      }
    } else {
      colors = palette("Default");
    }
  } else if (colorRule.color == "none") {
    colors = palette("Default");
  } else if (colorRule.color == "different" || colorRule.color == "different_or_missing" || colorRule.color == "missing") {
    let different = false;
    let missing = false;

    if (!isRefValue) {
      if (valueObj.value != valueObj.refValue) {
        different = true;
      }
    }
    if (valueObj.value == null) {
      missing = true;
    }

    if (colorRule.color == "different") {
      if (different) {
        colors = palette("DiffMiss");
      }
    } else if (colorRule.color == "different_or_missing") {
      if (different || missing) {
        colors = palette("DiffMiss");
      }
    } else if (colorRule.color == "missing") {
      if (missing) {
        colors = palette("DiffMiss");
      }
    }
  }

  return colors;
}

export function colorsByPercent(improved, percentDelta, colorRule) {
  let colors = palette("Default");

  if (improved) {
    if (percentDelta > colorRule.lightPct) {
      colors = palette("ImprovedSmall");
    }
    if (percentDelta > colorRule.medPct) {
      colors = palette("ImprovedMedium");
    }
    if (percentDelta > colorRule.darkPct) {
      colors = palette("ImprovedLarge");
    }
  } else {
    if (percentDelta > colorRule.lightPct) {
      colors = palette("DegradedSmall");
    }
    if (percentDelta > colorRule.medPct) {
      colors = palette("DegradedMedium");
    }
    if (percentDelta > colorRule.darkPct) {
      colors = palette("DegradedLarge");
    }
  }
  return colors;
}

////////////////////////////////////////////////////////////////////////////////
// Support for misc
////////////////////////////////////////////////////////////////////////////////

export function parseParms(parms) {
  let r = parms.indexOf("reportId");
  let e = parms.indexOf("=");
  if (e < r) {
    console.error("Cannot find reportId where expected in " + parms);
    return "";
  }
  let id = parms.substring(e + 1);
  return id;
}

////////////////////////////////////////////////////////////////////////////////
// Download
////////////////////////////////////////////////////////////////////////////////

export function downloadCsvFile(docName, data) {
  if (data != null) {
    let fileName = docName + ".csv";
    let media_type = "text/csv";

    const url = window.URL.createObjectURL(new Blob([data], { type: media_type }));

    var link = document.createElement("a");
    link.href = url;
    link.download = fileName;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } else {
    let message = "Unable to create CSV download";
    showNotification("Download", message);
  }
}

export function downloadXlsFile(docName, data) {
  if (data != null) {
    let fileName = docName + ".xlsx";
    let media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    var byteChars = atob(data);
    var byteNumbers = new Array(byteChars.length);
    for (var i = 0; i < byteChars.length; i++) {
      byteNumbers[i] = byteChars.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);

    var blob = new Blob([byteArray], { type: media_type });
    const url = window.URL.createObjectURL(blob);

    var link = document.createElement("a");
    link.href = url;
    link.download = fileName;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } else {
    let message = "Unable to create XLS download";
    showNotification("Download", message);
  }
}

export function createCell(row, col, val, fg, bg) {
  let safeVal = val ? val : "";

  let cell = {
    row: row,
    col: col,
    val: safeVal,
    fg: fg,
    bg: bg,
  };

  return cell;
}

export function noDots(text) {
  let noDotsText = text.replace(/\./g, "^");
  return noDotsText;
}

////////////////////////////////////////////////////////////////////////////////////
// Browser information (Returns browser name and version as space separated string)
////////////////////////////////////////////////////////////////////////////////////

export function getBrowserInfo() {
  let ua = navigator.userAgent,
    tem,
    M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
  if (/trident/i.test(M[1])) {
    tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
    return "IE " + (tem[1] || "");
  }
  if (M[1] === "Chrome") {
    tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
    if (tem != null) return tem.slice(1).join(" ").replace("OPR", "Opera");
  }
  M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, "-?"];
  if ((tem = ua.match(/version\/(\d+)/i)) != null) M.splice(1, 1, tem[1]);
  return M.join(" ");
}

////////////////////////////////////////////////////////////////////////////////
// Tabulator support
////////////////////////////////////////////////////////////////////////////////

export function headerFilterPlaceholderText() {
  return "...";
}

export function addColumn({ rootGroupObj = {}, col = {}, groupEnable = false, groupNames = [], groupContextMenu = [], headerAttrObj = {} } = {}) {
  let nextRootGroupObj = _.cloneDeep(rootGroupObj);

  let headerTooltip = col.headerTooltip;

  if (groupEnable == false || groupNames.length == 0) {
    // Group processing NOT needed.
    nextRootGroupObj.columns.push(col);
  } else {
    // Group processing needed.
    let parentGroupObj = nextRootGroupObj;
    let lastGroupObj;

    for (let i = 0; i < groupNames.length; i++) {
      let groupName = groupNames[i];

      let newGroupObj = {
        title: groupName,
        columns: [],
        headerTooltip: headerTooltip,
      };

      if (groupContextMenu.length != 0) {
        newGroupObj.headerContextMenu = groupContextMenu;
      }

      for (let attr in headerAttrObj) {
        newGroupObj[attr] = headerAttrObj[attr];
      }

      if (parentGroupObj.columns.length == 0) {
        parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
      }
      lastGroupObj = parentGroupObj.columns[parentGroupObj.columns.length - 1];

      if (i != groupNames.length - 1) {
        // This is NOT the last groupName
        if (lastGroupObj.title == groupName && lastGroupObj.hasOwnProperty("columns")) {
        } else {
          parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
          lastGroupObj = parentGroupObj.columns[parentGroupObj.columns.length - 1];
        }
        parentGroupObj = lastGroupObj;
      } else {
        // This is the last groupName
        if (lastGroupObj.title == groupName && lastGroupObj.hasOwnProperty("columns")) {
        } else {
          parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
          lastGroupObj = parentGroupObj.columns[parentGroupObj.columns.length - 1];
        }
        lastGroupObj.columns.push(col);
      }
    }
  }

  return nextRootGroupObj;
}

export function getGroupNames(groupName) {
  let groupNames;
  if (groupName == null || groupName == "") {
    groupNames = [];
  } else {
    let textToSplit = groupName;
    groupNames = [];
    // Note: "^" is the separator char
    // Note: "`" is the blank char
    for (let name of textToSplit.split("^")) {
      if (name == "`") {
        name = "";
      }
      groupNames.push(name);
    }
  }
  return groupNames;
}

export function getTheme(reportStates) {
  let darkMode = getPropValue(reportStates, ["globalFormatData", "darkMode"]);
  if (darkMode == null) {
    darkMode = true;
  }
  let theme = darkMode ? "dark" : "light";
  return theme;
}

// export async function saveReportStateMain(systemConfig, userData, reportSpecDoc, reportId, reportStates) {
//   // console.log("XXX: saveReportStateMain: #####################################");

//   let fullName = reportSpecDoc.fullName;
//   let parts = fullName.split("/");
//   let mainFolderName = parts[0];
//   let userOrProject = parts[1];

//   let readOnly = true;
//   if (mainFolderName == "Admin") {
//     if (userData.adminFlag == true) {
//       readOnly = false;
//     }
//   } else if (mainFolderName == "Users") {
//     if (userData.userName == userOrProject) {
//       readOnly = false;
//     }
//   } else if (mainFolderName == "Projects") {
//     if (userData.projectsManager.includes(userOrProject)) {
//       readOnly = false;
//     }
//   }

//   if (readOnly) {
//     let message = "You do not have write permissions for this reportSpec";
//     showNotification("Save Format", message);
//     return;
//   }

//   let newReportSpecDoc = _.cloneDeep(reportSpecDoc);
//   if (!newReportSpecDoc.hasOwnProperty("savedReportStates")) {
//     newReportSpecDoc["savedReportStates"] = {};
//   }

//   let oldSavedReportStates = reportSpecDoc["savedReportStates"] ? reportSpecDoc["savedReportStates"] : {};
//   let newSavedReportStates = _.cloneDeep(oldSavedReportStates);

//   let reportState = _.cloneDeep(reportStates[reportId]);
//   let configBuilds = _.cloneDeep(reportStates.configBuilds);
//   let configCheckpoints = _.cloneDeep(reportStates.configCheckpoints);

//   newSavedReportStates[reportId] = reportState;
//   newSavedReportStates.configBuilds = configBuilds;
//   newSavedReportStates.configCheckpoints = configCheckpoints;

//   newReportSpecDoc["savedReportStates"] = newSavedReportStates;

//   // console.log("XXX: saveReportStateMain: reportSpecDoc", reportSpecDoc);
//   // console.log("XXX: saveReportStateMain: newReportSpecDoc", newReportSpecDoc);

//   // console.log("XXX: saveReportStateMain: reportStates: OLD", Object.keys(oldSavedReportStates));
//   // console.log("XXX: saveReportStateMain: reportStates: NEW", Object.keys(newSavedReportStates));

//   // console.log("XXX: saveReportStateMain: reportState: OLD", reportId, oldSavedReportStates[reportId]);
//   // console.log("XXX: saveReportStateMain: reportState: NEW", reportId, newSavedReportStates[reportId]);

//   // Write the specDoc
//   let r = await fastapi.writeSpecDoc(systemConfig.dataServer, SpecType.REPORT, newReportSpecDoc);
//   if (!r.success) {
//     showNotification("Config Specs", r.message);
//   }

//   return newReportSpecDoc;
// }

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
