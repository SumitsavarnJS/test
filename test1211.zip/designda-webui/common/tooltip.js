import React from "react";
import { useState, useEffect, useRef } from 'react';
import _ from "lodash";

////////////////////////////////////////////////////////////////////////////////
// Tabulator tooltip support
////////////////////////////////////////////////////////////////////////////////

export function formattedTextTooltip(text, w, h) {
    var el = document.createElement("div");
    el.style.backgroundColor = "black";
    el.style.color = "white";
    el.style.borderRadius = "6px";
    el.style.fontSize = "14px";
    el.innerText = text;

    return el;
}

export function globFilterDisplayValueTooltip(e, cell, onRendered) {
    let msg = "This is a glob-style filter.";
    return formattedTextTooltip(msg, "300px", "50px");
}

export function customFilterDisplayValueTooltip(e, cell, onRendered) {
    let msg = "This is a custom filter.";

    msg += "\nIf the value starts with ';;',";
    msg += "\nthe remaining chars are used as a regular expression.";
    msg += "\n";
    msg += "\nIf the value starts with '::',";
    msg += "\nand the remaining chars contain comparison operators:";
    msg += "\n'<MAX'      - Filter shows: cells < MAX.";
    msg += "\n'<=MAX'     - Filter shows: cells <= MAX.";
    msg += "\n'>MIN'      - Filter shows: cells > MIN.";
    msg += "\n'>=MIN'     - Filter shows: cells >= MIN.";
    msg += "\n'<MAX,>MIN' - Filter shows: MIN < cells < MAX.";
    msg += "\n'>MIN,<MAX' - Filter shows: MIN < cells < MAX.";
    msg += "\n'>MIN,<MAX' - Filter shows: MIN < cells < MAX.";
    msg += "\n";
    // msg += "\nIf the value does not start with either ';;' or '::',";
    // msg += "\nthis is a glob-style filter.";

    return formattedTextTooltip(msg, "300px", "460px");
}

export function timeFilterTooltip(e, cell, onRendered) {
    let msg = "This is a custom filter.";
    msg += "\n";
    msg += "\nThe formats are:";
    msg += "\n";
    msg += "\nYYYY-MM-DD";
    msg += "\nThis specifies a MIN date.";
    msg += "\nFilter shows: cells > MIN date.";
    msg += "\n";
    msg += "\n,YYYY-MM-DD";
    msg += "\nThis specifies a MAX date.";
    msg += "\nFilter shows: cells < MAX date.";
    msg += "\n";
    msg += "\nYYYY-MM-DD,YYYY-MM-DD";
    msg += "\nThis specifies both a MIN date and a MAX date.";
    msg += "\nFilter shows: MIN date < cells < MAX date.";

    return formattedTextTooltip(msg, "280px", "460px");
}