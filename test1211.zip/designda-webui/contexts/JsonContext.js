import { createContext, useState } from 'react'

const JsonContext = createContext({
  clickedJsons: [],
  addClickedJson: () => {},
  deleteClosedJson: () => {},
})

export function JsonProvider({ children }) {
  const [clickedJsons, setClickedJsons] = useState([])

  const addClickedJson = (jsonLink) => {
    setClickedJsons((prevClickedJsons) => [...prevClickedJsons, jsonLink])
  }
  const deleteClosedJson = (jsonLink) => {
    setClickedJsons((prevClickedJsons) =>
      prevClickedJsons.filter((link) => link !== jsonLink),
    )
  }
  return (
    <JsonContext.Provider
      value={{ clickedJsons, addClickedJson, deleteClosedJson }}
    >
      {children}
    </JsonContext.Provider>
  )
}

export default JsonContext
