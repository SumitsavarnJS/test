const nextConfig = {
  reactStrictMode: false,
  staticPageGenerationTimeout: 100,
  basePath: "/v1",
  assetPrefix: "/v1/",
  publicRuntimeConfig: {
    basePath: "/v1",
  },

  output: "standalone",
  compiler: {
    // Enables the styled-components SWC transform
    styledComponents: true,
  },
  eslint: {
    // disable eslint during production builds
    ignoreDuringBuilds: true,
  }
};

const removeImports = require("next-remove-imports")({
  packages: ["react-markdown-editor"],
});

const withBundleAnalyzer = require("@next/bundle-analyzer")({
  enabled: process.env.ANALYZE === "true",
});
module.exports = withBundleAnalyzer(removeImports(nextConfig));
