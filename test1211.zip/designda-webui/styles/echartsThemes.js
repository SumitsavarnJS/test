export const echartsTheme = {
  infographic: {
    version: 1,
    themeName: "infographic",
    theme: {
      color: [
        "#c1232b",
        "#27727b",
        "#fcce10",
        "#e87c25",
        "#b5c334",
        "#fe8463",
        "#9bca63",
        "#fad860",
        "#f3a43b",
        "#60c0dd",
        "#d7504b",
        "#c6e579",
        "#f4e001",
        "#f0805a",
        "#26c0c0",
        "#898541",
        "#c1dbee",
        "#620707",
        "#25e785",
        "#e67a48",
      ],
      backgroundColor: "rgba(0,0,0,0)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#27727b",
        },
        subtextStyle: {
          color: "#aaaaaa",
        },
      },
      line: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: "3",
        },
        symbolSize: "5",
        symbol: "emptyCircle",
        smooth: false,
      },
      radar: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: "3",
        },
        symbolSize: "5",
        symbol: "emptyCircle",
        smooth: false,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#c1232b",
          color0: "#b5c334",
          borderColor: "#c1232b",
          borderColor0: "#b5c334",
          borderWidth: 1,
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: 1,
          color: "#aaaaaa",
        },
        symbolSize: "5",
        symbol: "emptyCircle",
        smooth: false,
        color: [
          "#c1232b",
          "#27727b",
          "#fcce10",
          "#e87c25",
          "#b5c334",
          "#fe8463",
          "#9bca63",
          "#fad860",
          "#f3a43b",
          "#60c0dd",
          "#d7504b",
          "#c6e579",
          "#f4e001",
          "#f0805a",
          "#26c0c0",
        ],
        label: {
          color: "#eeeeee",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#dddddd",
          borderColor: "#eeeeee",
          borderWidth: 0.5,
        },
        label: {
          color: "#c1232b",
        },
        emphasis: {
          itemStyle: {
            areaColor: "#fe994e",
            borderColor: "#444",
            borderWidth: 1,
          },
          label: {
            color: "rgb(100,0,0)",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#dddddd",
          borderColor: "#eeeeee",
          borderWidth: 0.5,
        },
        label: {
          color: "#c1232b",
        },
        emphasis: {
          itemStyle: {
            areaColor: "#fe994e",
            borderColor: "#444",
            borderWidth: 1,
          },
          label: {
            color: "rgb(100,0,0)",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#27727b",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#27727b",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#27727b",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#27727b",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#c1232b",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#e87c25",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#333333",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#27727b",
            width: 1,
          },
          crossStyle: {
            color: "#27727b",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#293c55",
          width: 1,
        },
        itemStyle: {
          color: "#27727b",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#27727b",
          borderColor: "#27727b",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#c1232b",
          borderColor: "#c23531",
        },
        label: {
          color: "#293c55",
        },
        emphasis: {
          itemStyle: {
            color: "#72d4e0",
          },
          controlStyle: {
            color: "#27727b",
            borderColor: "#27727b",
            borderWidth: 0.5,
          },
          label: {
            color: "#293c55",
          },
        },
      },
      visualMap: {
        color: ["#c1232b", "#fcce10"],
      },
      dataZoom: {
        backgroundColor: "rgba(0,0,0,0)",
        dataBackgroundColor: "rgba(181,195,52,0.3)",
        fillerColor: "rgba(181,195,52,0.2)",
        handleColor: "#27727b",
        handleSize: "100%",
        textStyle: {
          color: "#999999",
        },
      },
      markPoint: {
        label: {
          color: "#eeeeee",
        },
        emphasis: {
          label: {
            color: "#eeeeee",
          },
        },
      },
    },
  },
  macarons: {
    version: 1,
    themeName: "macarons",
    theme: {
      color: [
        "#2ec7c9",
        "#b6a2de",
        "#5ab1ef",
        "#ffb980",
        "#d87a80",
        "#8d98b3",
        "#e5cf0d",
        "#97b552",
        "#95706d",
        "#dc69aa",
        "#07a2a4",
        "#9a7fd1",
        "#588dd5",
        "#f5994e",
        "#c05050",
        "#59678c",
        "#c9ab00",
        "#7eb00a",
        "#6f5553",
        "#c14089",
      ],
      backgroundColor: "rgba(0,0,0,0)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#008acd",
        },
        subtextStyle: {
          color: "#aaaaaa",
        },
      },
      line: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: 2,
        },
        symbolSize: 3,
        symbol: "emptyCircle",
        smooth: true,
      },
      radar: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: 2,
        },
        symbolSize: 3,
        symbol: "emptyCircle",
        smooth: true,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#d87a80",
          color0: "#2ec7c9",
          borderColor: "#d87a80",
          borderColor0: "#2ec7c9",
          borderWidth: 1,
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: 1,
          color: "#aaaaaa",
        },
        symbolSize: 3,
        symbol: "emptyCircle",
        smooth: true,
        color: [
          "#2ec7c9",
          "#b6a2de",
          "#5ab1ef",
          "#ffb980",
          "#d87a80",
          "#8d98b3",
          "#e5cf0d",
          "#97b552",
          "#95706d",
          "#dc69aa",
          "#07a2a4",
          "#9a7fd1",
          "#588dd5",
          "#f5994e",
          "#c05050",
          "#59678c",
          "#c9ab00",
          "#7eb00a",
          "#6f5553",
          "#c14089",
        ],
        label: {
          color: "#eeeeee",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#dddddd",
          borderColor: "#eeeeee",
          borderWidth: 0.5,
        },
        label: {
          color: "#d87a80",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(254,153,78,1)",
            borderColor: "#444",
            borderWidth: 1,
          },
          label: {
            color: "rgb(100,0,0)",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#dddddd",
          borderColor: "#eeeeee",
          borderWidth: 0.5,
        },
        label: {
          color: "#d87a80",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(254,153,78,1)",
            borderColor: "#444",
            borderWidth: 1,
          },
          label: {
            color: "rgb(100,0,0)",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#008acd",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#eee"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#008acd",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#eee"],
          },
        },
        splitArea: {
          show: true,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#008acd",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#eee"],
          },
        },
        splitArea: {
          show: true,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#008acd",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#eee"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#2ec7c9",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#18a4a6",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#333333",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#008acd",
            width: "1",
          },
          crossStyle: {
            color: "#008acd",
            width: "1",
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#008acd",
          width: 1,
        },
        itemStyle: {
          color: "#008acd",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#008acd",
          borderColor: "#008acd",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#2ec7c9",
          borderColor: "#2ec7c9",
        },
        label: {
          color: "#008acd",
        },
        emphasis: {
          itemStyle: {
            color: "#a9334c",
          },
          controlStyle: {
            color: "#008acd",
            borderColor: "#008acd",
            borderWidth: 0.5,
          },
          label: {
            color: "#008acd",
          },
        },
      },
      visualMap: {
        color: ["#5ab1ef", "#e0ffff"],
      },
      dataZoom: {
        backgroundColor: "rgba(47,69,84,0)",
        dataBackgroundColor: "#efefff",
        fillerColor: "rgba(182,162,222,0.2)",
        handleColor: "#008acd",
        handleSize: "100%",
        textStyle: {
          color: "#333333",
        },
      },
      markPoint: {
        label: {
          color: "#eeeeee",
        },
        emphasis: {
          label: {
            color: "#eeeeee",
          },
        },
      },
    },
  },
  roma: {
    version: 1,
    themeName: "roma",
    theme: {
      color: [
        "#e01f54",
        "#001852",
        "#f5e8c8",
        "#b8d2c7",
        "#c6b38e",
        "#a4d8c2",
        "#f3d999",
        "#d3758f",
        "#dcc392",
        "#2e4783",
        "#82b6e9",
        "#ff6347",
        "#a092f1",
        "#0a915d",
        "#eaf889",
        "#6699ff",
        "#ff6666",
        "#3cb371",
        "#d5b158",
        "#38b6b6",
      ],
      backgroundColor: "rgba(0,0,0,0)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#333333",
        },
        subtextStyle: {
          color: "#aaaaaa",
        },
      },
      line: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: 2,
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
      },
      radar: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: 2,
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#e01f54",
          color0: "#001852",
          borderColor: "#f5e8c8",
          borderColor0: "#b8d2c7",
          borderWidth: 1,
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: 1,
          color: "#aaaaaa",
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
        color: [
          "#e01f54",
          "#001852",
          "#f5e8c8",
          "#b8d2c7",
          "#c6b38e",
          "#a4d8c2",
          "#f3d999",
          "#d3758f",
          "#dcc392",
          "#2e4783",
          "#82b6e9",
          "#ff6347",
          "#a092f1",
          "#0a915d",
          "#eaf889",
          "#6699ff",
          "#ff6666",
          "#3cb371",
          "#d5b158",
          "#38b6b6",
        ],
        label: {
          color: "#eeeeee",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#eeeeee",
          borderColor: "#444444",
          borderWidth: 0.5,
        },
        label: {
          color: "#000000",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(255,215,0,0.8)",
            borderColor: "#444",
            borderWidth: 1,
          },
          label: {
            color: "rgb(100,0,0)",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#eeeeee",
          borderColor: "#444444",
          borderWidth: 0.5,
        },
        label: {
          color: "#000000",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(255,215,0,0.8)",
            borderColor: "#444",
            borderWidth: 1,
          },
          label: {
            color: "rgb(100,0,0)",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#999999",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#666666",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#333333",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#cccccc",
            width: 1,
          },
          crossStyle: {
            color: "#cccccc",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#293c55",
          width: 1,
        },
        itemStyle: {
          color: "#293c55",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#293c55",
          borderColor: "#293c55",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#e43c59",
          borderColor: "#c23531",
        },
        label: {
          color: "#293c55",
        },
        emphasis: {
          itemStyle: {
            color: "#a9334c",
          },
          controlStyle: {
            color: "#293c55",
            borderColor: "#293c55",
            borderWidth: 0.5,
          },
          label: {
            color: "#293c55",
          },
        },
      },
      visualMap: {
        color: ["#e01f54", "#e7dbc3"],
      },
      dataZoom: {
        backgroundColor: "rgba(47,69,84,0)",
        dataBackgroundColor: "rgba(47,69,84,0.3)",
        fillerColor: "rgba(167,183,204,0.4)",
        handleColor: "#a7b7cc",
        handleSize: "100%",
        textStyle: {
          color: "#333333",
        },
      },
      markPoint: {
        label: {
          color: "#eeeeee",
        },
        emphasis: {
          label: {
            color: "#eeeeee",
          },
        },
      },
    },
  },
  vintage: {
    version: 1,
    themeName: "vintage",
    theme: {
      color: [
        "#d87c7c",
        "#919e8b",
        "#d7ab82",
        "#6e7074",
        "#61a0a8",
        "#efa18d",
        "#787464",
        "#cc7e63",
        "#724e58",
        "#4b565b",
        "#ff9f7f",
        "#fb7293",
        "#e062ae",
        "#e690d1",
        "#9d96f5",
        "#8378ea",
        "#96bfff",
        "#d2f261",
        "#ffb0a9",
        "#e062ae",
        "#e690d1",
        "#e7bcf3",
      ],
      backgroundColor: "rgba(254,248,239,1)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#333333",
        },
        subtextStyle: {
          color: "#aaaaaa",
        },
      },
      line: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: 2,
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
      },
      radar: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: 2,
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#c23531",
          color0: "#314656",
          borderColor: "#c23531",
          borderColor0: "#314656",
          borderWidth: 1,
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: 1,
          color: "#aaaaaa",
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
        color: [
          "#d87c7c",
          "#919e8b",
          "#d7ab82",
          "#6e7074",
          "#61a0a8",
          "#efa18d",
          "#787464",
          "#cc7e63",
          "#724e58",
          "#4b565b",
        ],
        label: {
          color: "#eeeeee",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#eeeeee",
          borderColor: "#444444",
          borderWidth: 0.5,
        },
        label: {
          color: "#000000",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(255,215,0,0.8)",
            borderColor: "#444444",
            borderWidth: 1,
          },
          label: {
            color: "rgb(100,0,0)",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#eeeeee",
          borderColor: "#444444",
          borderWidth: 0.5,
        },
        label: {
          color: "#000000",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(255,215,0,0.8)",
            borderColor: "#444444",
            borderWidth: 1,
          },
          label: {
            color: "rgb(100,0,0)",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#999999",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#666666",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#333333",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#cccccc",
            width: 1,
          },
          crossStyle: {
            color: "#cccccc",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#293c55",
          width: 1,
        },
        itemStyle: {
          color: "#293c55",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#293c55",
          borderColor: "#293c55",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#e43c59",
          borderColor: "#c23531",
        },
        label: {
          color: "#293c55",
        },
        emphasis: {
          itemStyle: {
            color: "#a9334c",
          },
          controlStyle: {
            color: "#293c55",
            borderColor: "#293c55",
            borderWidth: 0.5,
          },
          label: {
            color: "#293c55",
          },
        },
      },
      visualMap: {
        color: ["#bf444c", "#d88273", "#f6efa6"],
      },
      dataZoom: {
        backgroundColor: "rgba(47,69,84,0)",
        dataBackgroundColor: "rgba(47,69,84,0.3)",
        fillerColor: "rgba(167,183,204,0.4)",
        handleColor: "#a7b7cc",
        handleSize: "100%",
        textStyle: {
          color: "#333333",
        },
      },
      markPoint: {
        label: {
          color: "#eeeeee",
        },
        emphasis: {
          label: {
            color: "#eeeeee",
          },
        },
      },
    },
  },
  essos: {
    version: 1,
    themeName: "essos",
    theme: {
      color: [
        "#893448",
        "#d95850",
        "#eb8146",
        "#ffb248",
        "#f2d643",
        "#ebdba4",
        "#61b4cf",
        "#91c7ae",
        "#e0d68a",
        "#e7a97e",
        "#bda29a",
        "#6e7074",
        "#546570",
        "#c4ccd3",
        "#61b4cf",
        "#91c7ae",
        "#e0d68a",
        "#e7a97e",
        "#bda29a",
        "#6e7074",
        "#546570",
        "#c4ccd3",
      ],
      backgroundColor: "rgba(242,234,191,0.15)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#893448",
        },
        subtextStyle: {
          color: "#d95850",
        },
      },
      line: {
        itemStyle: {
          borderWidth: "2",
        },
        lineStyle: {
          width: "2",
        },
        symbolSize: "6",
        symbol: "emptyCircle",
        smooth: true,
      },
      radar: {
        itemStyle: {
          borderWidth: "2",
        },
        lineStyle: {
          width: "2",
        },
        symbolSize: "6",
        symbol: "emptyCircle",
        smooth: true,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#eb8146",
          color0: "transparent",
          borderColor: "#d95850",
          borderColor0: "#58c470",
          borderWidth: "2",
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: 1,
          color: "#aaaaaa",
        },
        symbolSize: "6",
        symbol: "emptyCircle",
        smooth: true,
        color: [
          "#893448",
          "#d95850",
          "#eb8146",
          "#ffb248",
          "#f2d643",
          "#ebdba4",
        ],
        label: {
          color: "#ffffff",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#f3f3f3",
          borderColor: "#999999",
          borderWidth: 0.5,
        },
        label: {
          color: "#893448",
        },
        emphasis: {
          itemStyle: {
            areaColor: "#ffb248",
            borderColor: "#eb8146",
            borderWidth: 1,
          },
          label: {
            color: "#893448",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#f3f3f3",
          borderColor: "#999999",
          borderWidth: 0.5,
        },
        label: {
          color: "#893448",
        },
        emphasis: {
          itemStyle: {
            areaColor: "#ffb248",
            borderColor: "#eb8146",
            borderWidth: 1,
          },
          label: {
            color: "#893448",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#aaaaaa",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#999999",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#aaaaaa",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#999999",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#aaaaaa",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#999999",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#aaaaaa",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#999999",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#999999",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#666666",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#999999",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#cccccc",
            width: 1,
          },
          crossStyle: {
            color: "#cccccc",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#893448",
          width: 1,
        },
        itemStyle: {
          color: "#893448",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#893448",
          borderColor: "#893448",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#eb8146",
          borderColor: "#ffb248",
        },
        label: {
          color: "#893448",
        },
        emphasis: {
          itemStyle: {
            color: "#ffb248",
          },
          controlStyle: {
            color: "#893448",
            borderColor: "#893448",
            borderWidth: 0.5,
          },
          label: {
            color: "#893448",
          },
        },
      },
      visualMap: {
        color: [
          "#893448",
          "#d95850",
          "#eb8146",
          "#ffb248",
          "#f2d643",
          "rgb(247,238,173)",
        ],
      },
      dataZoom: {
        backgroundColor: "rgba(255,255,255,0)",
        dataBackgroundColor: "rgba(255,178,72,0.5)",
        fillerColor: "rgba(255,178,72,0.15)",
        handleColor: "#ffb248",
        handleSize: "100%",
        textStyle: {
          color: "#333",
        },
      },
      markPoint: {
        label: {
          color: "#ffffff",
        },
        emphasis: {
          label: {
            color: "#ffffff",
          },
        },
      },
    },
  },
  shine: {
    version: 1,
    themeName: "shine",
    theme: {
      color: [
        "#c12e34",
        "#e6b600",
        "#0098d9",
        "#2b821d",
        "#005eaa",
        "#339ca8",
        "#cda819",
        "#32a487",
        "#646464",
        "#749f83",
        "#333333",
        "#dd6b66",
        "#759aa0",
        "#e69d87",
        "#8dc1a9",
        "#ea7e53",
        "#eedd78",
        "#73a373",
        "#73b9bc",
        "#7289ab",
        "#91ca8c",
        "#f49f42",
        "#616981",
        "#9fbab0",
        "#e098c7",
        "#8fd3e8",
        "#71669e",
        "#cc70af",
        "#7cb4cc",
        "#72b362",
      ],
      backgroundColor: "rgba(0,0,0,0)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#333333",
        },
        subtextStyle: {
          color: "#aaaaaa",
        },
      },
      line: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: 2,
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
      },
      radar: {
        itemStyle: {
          borderWidth: 1,
        },
        lineStyle: {
          width: 2,
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#c12e34",
          color0: "#2b821d",
          borderColor: "#c12e34",
          borderColor0: "#2b821d",
          borderWidth: 1,
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: 1,
          color: "#aaaaaa",
        },
        symbolSize: 4,
        symbol: "emptyCircle",
        smooth: false,
        color: [
          "#c12e34",
          "#e6b600",
          "#0098d9",
          "#2b821d",
          "#005eaa",
          "#339ca8",
          "#cda819",
          "#32a487",
        ],
        label: {
          color: "#eeeeee",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#ddd",
          borderColor: "#eee",
          borderWidth: 0.5,
        },
        label: {
          color: "#c12e34",
        },
        emphasis: {
          itemStyle: {
            areaColor: "#e6b600",
            borderColor: "#ddd",
            borderWidth: 1,
          },
          label: {
            color: "#c12e34",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#ddd",
          borderColor: "#eee",
          borderWidth: 0.5,
        },
        label: {
          color: "#c12e34",
        },
        emphasis: {
          itemStyle: {
            areaColor: "#e6b600",
            borderColor: "#ddd",
            borderWidth: 1,
          },
          label: {
            color: "#c12e34",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisTick: {
          show: true,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#333",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#ccc"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#06467c",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#4187c2",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#333333",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#cccccc",
            width: 1,
          },
          crossStyle: {
            color: "#cccccc",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#005eaa",
          width: 1,
        },
        itemStyle: {
          color: "#005eaa",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#005eaa",
          borderColor: "#005eaa",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#005eaa",
          borderColor: "#316bc2",
        },
        label: {
          color: "#005eaa",
        },
        emphasis: {
          itemStyle: {
            color: "#005eaa",
          },
          controlStyle: {
            color: "#005eaa",
            borderColor: "#005eaa",
            borderWidth: 0.5,
          },
          label: {
            color: "#005eaa",
          },
        },
      },
      visualMap: {
        color: ["#1790cf", "#a2d4e6"],
      },
      dataZoom: {
        backgroundColor: "rgba(47,69,84,0)",
        dataBackgroundColor: "rgba(47,69,84,0.3)",
        fillerColor: "rgba(167,183,204,0.4)",
        handleColor: "#a7b7cc",
        handleSize: "100%",
        textStyle: {
          color: "#333333",
        },
      },
      markPoint: {
        label: {
          color: "#eeeeee",
        },
        emphasis: {
          label: {
            color: "#eeeeee",
          },
        },
      },
    },
  },
  wonderland: {
    version: 1,
    themeName: "wonderland",
    theme: {
      color: [
        "#4ea397",
        "#22c3aa",
        "#7bd9a5",
        "#d0648a",
        "#f58db2",
        "#f2b3c9",
        "#4ea397",
        "#22c3aa",
        "#7bd9a5",
        "#d0648a",
        "#f58db2",
        "#a34ea3",
        "#c322c3",
        "#a57bd9",
        "#8ad064",
        "#b28df5",
        "#39764e",
        "#22a2c3",
        "#5a9b80",
        "#d9a57b",
        "#ffcc00",
        "#e8a8e8",
        "#964545",
        "#666699",
        "#dbdb70",
        "#7fffd4",
      ],
      backgroundColor: "rgba(255,255,255,0)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#666666",
        },
        subtextStyle: {
          color: "#999999",
        },
      },
      line: {
        itemStyle: {
          borderWidth: "2",
        },
        lineStyle: {
          width: "3",
        },
        symbolSize: "8",
        symbol: "emptyCircle",
        smooth: false,
      },
      radar: {
        itemStyle: {
          borderWidth: "2",
        },
        lineStyle: {
          width: "3",
        },
        symbolSize: "8",
        symbol: "emptyCircle",
        smooth: false,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#d0648a",
          color0: "transparent",
          borderColor: "#d0648a",
          borderColor0: "#22c3aa",
          borderWidth: "1",
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: "1",
          color: "#cccccc",
        },
        symbolSize: "8",
        symbol: "emptyCircle",
        smooth: false,
        color: [
          "#4ea397",
          "#22c3aa",
          "#7bd9a5",
          "#d0648a",
          "#f58db2",
          "#f2b3c9",
        ],
        label: {
          color: "#ffffff",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#eeeeee",
          borderColor: "#999999",
          borderWidth: 0.5,
        },
        label: {
          color: "#28544e",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(34,195,170,0.25)",
            borderColor: "#22c3aa",
            borderWidth: 1,
          },
          label: {
            color: "#349e8e",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#eeeeee",
          borderColor: "#999999",
          borderWidth: 0.5,
        },
        label: {
          color: "#28544e",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(34,195,170,0.25)",
            borderColor: "#22c3aa",
            borderWidth: 1,
          },
          label: {
            color: "#349e8e",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#cccccc",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#999999",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#eeeeee"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#cccccc",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#999999",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#eeeeee"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#cccccc",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#999999",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#eeeeee"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#cccccc",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#999999",
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ["#eeeeee"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#999999",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#666666",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#999999",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#cccccc",
            width: 1,
          },
          crossStyle: {
            color: "#cccccc",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#4ea397",
          width: 1,
        },
        itemStyle: {
          color: "#4ea397",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#4ea397",
          borderColor: "#4ea397",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#4ea397",
          borderColor: "#3cebd2",
        },
        label: {
          color: "#4ea397",
        },
        emphasis: {
          itemStyle: {
            color: "#4ea397",
          },
          controlStyle: {
            color: "#4ea397",
            borderColor: "#4ea397",
            borderWidth: 0.5,
          },
          label: {
            color: "#4ea397",
          },
        },
      },
      visualMap: {
        color: ["#d0648a", "#22c3aa", "#adfff1"],
      },
      dataZoom: {
        backgroundColor: "rgba(255,255,255,0)",
        dataBackgroundColor: "rgba(222,222,222,1)",
        fillerColor: "rgba(114,230,212,0.25)",
        handleColor: "#cccccc",
        handleSize: "100%",
        textStyle: {
          color: "#999999",
        },
      },
      markPoint: {
        label: {
          color: "#ffffff",
        },
        emphasis: {
          label: {
            color: "#ffffff",
          },
        },
      },
    },
  },
  dark: {
    version: 1,
    themeName: "dark",
    theme: {
      color: [
        "#fc97af",
        "#87f7cf",
        "#f7f494",
        "#72ccff",
        "#f7c5a0",
        "#d4a4eb",
        "#d2f5a6",
        "#76f2f2",
        "#e09997",
        "#71d6ff",
        "#f0ce9c",
        "#8ff792",
        "#b3b6fd",
        "#6af7a3",
        "#d592f7",
        "#92f5d1",
        "#f192a5",
        "#77d9ff",
        "#e1db93",
        "#6ffcb9",
        "#8cf7a7",
        "#fdaec2",
        "#9df7c8",
      ],
      backgroundColor: "rgba(41,52,65,1)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#ffffff",
        },
        subtextStyle: {
          color: "#dddddd",
        },
      },
      line: {
        itemStyle: {
          borderWidth: "4",
        },
        lineStyle: {
          width: "3",
        },
        symbolSize: "0",
        symbol: "circle",
        smooth: true,
      },
      radar: {
        itemStyle: {
          borderWidth: "4",
        },
        lineStyle: {
          width: "3",
        },
        symbolSize: "0",
        symbol: "circle",
        smooth: true,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#fc97af",
          color0: "transparent",
          borderColor: "#fc97af",
          borderColor0: "#87f7cf",
          borderWidth: "2",
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: "1",
          color: "#ffffff",
        },
        symbolSize: "0",
        symbol: "circle",
        smooth: true,
        color: [
          "#fc97af",
          "#87f7cf",
          "#f7f494",
          "#72ccff",
          "#f7c5a0",
          "#d4a4eb",
          "#d2f5a6",
          "#76f2f2",
        ],
        label: {
          color: "#293441",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#f3f3f3",
          borderColor: "#999999",
          borderWidth: 0.5,
        },
        label: {
          color: "#893448",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(255,178,72,1)",
            borderColor: "#eb8146",
            borderWidth: 1,
          },
          label: {
            color: "rgb(137,52,72)",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#f3f3f3",
          borderColor: "#999999",
          borderWidth: 0.5,
        },
        label: {
          color: "#893448",
        },
        emphasis: {
          itemStyle: {
            areaColor: "rgba(255,178,72,1)",
            borderColor: "#eb8146",
            borderWidth: 1,
          },
          label: {
            color: "rgb(137,52,72)",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#666666",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#aaaaaa",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#666666",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#aaaaaa",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#666666",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#aaaaaa",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#666666",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#aaaaaa",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#999999",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#666666",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#999999",
        },
        pageTextStyle: {
          color: "#fff",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#cccccc",
            width: 1,
          },
          crossStyle: {
            color: "#cccccc",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#87f7cf",
          width: 1,
        },
        itemStyle: {
          color: "#87f7cf",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#87f7cf",
          borderColor: "#87f7cf",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#fc97af",
          borderColor: "#fc97af",
        },
        label: {
          color: "#87f7cf",
        },
        emphasis: {
          itemStyle: {
            color: "#f7f494",
          },
          controlStyle: {
            color: "#87f7cf",
            borderColor: "#87f7cf",
            borderWidth: 0.5,
          },
          label: {
            color: "#87f7cf",
          },
        },
      },
      visualMap: {
        color: ["#fc97af", "#87f7cf"],
      },
      dataZoom: {
        backgroundColor: "rgba(255,255,255,0)",
        dataBackgroundColor: "rgba(114,204,255,1)",
        fillerColor: "rgba(114,204,255,0.2)",
        handleColor: "#72ccff",
        handleSize: "100%",
        textStyle: {
          color: "#333333",
        },
      },
      markPoint: {
        label: {
          color: "#293441",
        },
        emphasis: {
          label: {
            color: "#293441",
          },
        },
      },
    },
  },
  light: {
    version: 1,
    themeName: "light",
    theme: {
      color: [
        "#fc97af",
        "#87f7cf",
        "#f7f494",
        "#72ccff",
        "#f7c5a0",
        "#d4a4eb",
        "#d2f5a6",
        "#76f2f2",
        "#e09997",
        "#71d6ff",
        "#f0ce9c",
        "#8ff792",
        "#b3b6fd",
        "#6af7a3",
        "#d592f7",
        "#92f5d1",
        "#f192a5",
        "#77d9ff",
        "#e1db93",
        "#6ffcb9",
        "#8cf7a7",
        "#fdaec2",
        "#9df7c8",
      ],
      backgroundColor: "rgba(255,255,255,1)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#ffffff",
        },
        subtextStyle: {
          color: "#dddddd",
        },
      },
      line: {
        itemStyle: {
          normal: {
            borderWidth: "4",
          },
        },
        lineStyle: {
          normal: {
            width: "3",
          },
        },
        symbolSize: "0",
        symbol: "circle",
        smooth: true,
      },
      radar: {
        itemStyle: {
          normal: {
            borderWidth: "4",
          },
        },
        lineStyle: {
          normal: {
            width: "3",
          },
        },
        symbolSize: "0",
        symbol: "circle",
        smooth: true,
      },
      bar: {
        itemStyle: {
          normal: {
            barBorderWidth: 0,
            barBorderColor: "#ccc",
            barBorderRadius: "30px",
          },
          emphasis: {
            barBorderWidth: 0,
            barBorderColor: "#ccc",
            barBorderRadius: "30px",
          },
        },
      },
      pie: {
        itemStyle: {
          normal: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
          emphasis: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
        },
      },
      scatter: {
        itemStyle: {
          normal: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
          emphasis: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
        },
      },
      boxplot: {
        itemStyle: {
          normal: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
          emphasis: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
        },
      },
      parallel: {
        itemStyle: {
          normal: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
          emphasis: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
        },
      },
      sankey: {
        itemStyle: {
          normal: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
          emphasis: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
        },
      },
      funnel: {
        itemStyle: {
          normal: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
          emphasis: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
        },
      },
      gauge: {
        itemStyle: {
          normal: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
          emphasis: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
        },
      },
      candlestick: {
        itemStyle: {
          normal: {
            color: "#fc97af",
            color0: "transparent",
            borderColor: "#fc97af",
            borderColor0: "#87f7cf",
            borderWidth: "2",
          },
        },
      },
      graph: {
        itemStyle: {
          normal: {
            borderWidth: 0,
            borderColor: "#ccc",
          },
        },
        lineStyle: {
          normal: {
            width: "1",
            color: "#ffffff",
          },
        },
        symbolSize: "0",
        symbol: "circle",
        smooth: true,
        color: [
          "#fc97af",
          "#87f7cf",
          "#f7f494",
          "#72ccff",
          "#f7c5a0",
          "#d4a4eb",
          "#d2f5a6",
          "#76f2f2",
        ],
        label: {
          normal: {
            textStyle: {
              color: "#293441",
            },
          },
        },
      },
      map: {
        itemStyle: {
          normal: {
            areaColor: "#f3f3f3",
            borderColor: "#999999",
            borderWidth: 0.5,
          },
          emphasis: {
            areaColor: "rgba(255,178,72,1)",
            borderColor: "#eb8146",
            borderWidth: 1,
          },
        },
        label: {
          normal: {
            textStyle: {
              color: "#893448",
            },
          },
          emphasis: {
            textStyle: {
              color: "rgb(137,52,72)",
            },
          },
        },
      },
      geo: {
        itemStyle: {
          normal: {
            areaColor: "#f3f3f3",
            borderColor: "#999999",
            borderWidth: 0.5,
          },
          emphasis: {
            areaColor: "rgba(255,178,72,1)",
            borderColor: "#eb8146",
            borderWidth: 1,
          },
        },
        label: {
          normal: {
            textStyle: {
              color: "#893448",
            },
          },
          emphasis: {
            textStyle: {
              color: "rgb(137,52,72)",
            },
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#666666",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          textStyle: {
            color: "#aaaaaa",
          },
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#666666",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          textStyle: {
            color: "#aaaaaa",
          },
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#666666",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          textStyle: {
            color: "#aaaaaa",
          },
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#666666",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          textStyle: {
            color: "#aaaaaa",
          },
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#e6e6e6"],
          },
        },
        splitArea: {
          show: false,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          normal: {
            borderColor: "#999999",
          },
          emphasis: {
            borderColor: "#666666",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#999999",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#cccccc",
            width: 1,
          },
          crossStyle: {
            color: "#cccccc",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#87f7cf",
          width: 1,
        },
        itemStyle: {
          normal: {
            color: "#87f7cf",
            borderWidth: 1,
          },
          emphasis: {
            color: "#f7f494",
          },
        },
        controlStyle: {
          normal: {
            color: "#87f7cf",
            borderColor: "#87f7cf",
            borderWidth: 0.5,
          },
          emphasis: {
            color: "#87f7cf",
            borderColor: "#87f7cf",
            borderWidth: 0.5,
          },
        },
        checkpointStyle: {
          color: "#fc97af",
          borderColor: "rgba(252,151,175,0.3)",
        },
        label: {
          normal: {
            textStyle: {
              color: "#87f7cf",
            },
          },
          emphasis: {
            textStyle: {
              color: "#87f7cf",
            },
          },
        },
      },
      visualMap: {
        color: ["#fc97af", "#87f7cf"],
      },
      dataZoom: {
        backgroundColor: "rgba(255,255,255,0)",
        dataBackgroundColor: "rgba(114,204,255,1)",
        fillerColor: "rgba(114,204,255,0.2)",
        handleColor: "#72ccff",
        handleSize: "100%",
        textStyle: {
          color: "#333333",
        },
      },
      markPoint: {
        label: {
          normal: {
            textStyle: {
              color: "#293441",
            },
          },
          emphasis: {
            textStyle: {
              color: "#293441",
            },
          },
        },
      },
    },
  },
  "purple-passion": {
    version: 1,
    themeName: "purple-passion",
    theme: {
      seriesCnt: "3",
      backgroundColor: "rgba(91,92,110,1)",
      titleColor: "#fff",
      subtitleColor: "#fff",
      textColorShow: false,
      textColor: "#333",
      markTextColor: "#eeeeee",
      color: [
        "#9b8bba",
        "#e098c7",
        "#a4e8fc",
        "#71669e",
        "#cc70af",
        "#7cb4cc",
        "#d21111",
        "#f0ac22",
        "#33cbcd",
        "#8332c8",
        "#cabf35",
        "#bb511e",
        "#4dca7a",
        "#1b92ca",
        "#5823be",
        "#e8c1c1",
        "#b2dbc2",
        "#a9a9e0",
        "#e3798b",
        "#d7d69a",
        "#e188b6",
        "#bcdf9d",
        "#b54768",
        "#6273ad",
        "#a36152",
        "#92d16b",
        "#6d61b0",
      ],
      backgroundColor: "rgba(91,92,110,1)",
      textStyle: {},
      title: {
        textStyle: {
          color: "#ffffff",
        },
        subtextStyle: {
          color: "#ffffff",
        },
      },
      line: {
        itemStyle: {
          borderWidth: "2",
        },
        lineStyle: {
          width: "3",
        },
        symbolSize: "7",
        symbol: "circle",
        smooth: true,
      },
      radar: {
        itemStyle: {
          borderWidth: "2",
        },
        lineStyle: {
          width: "3",
        },
        symbolSize: "7",
        symbol: "circle",
        smooth: true,
      },
      bar: {
        itemStyle: {
          barBorderWidth: 0,
          barBorderColor: "#ccc",
        },
      },
      pie: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      scatter: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      boxplot: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      parallel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      sankey: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      funnel: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      gauge: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
      },
      candlestick: {
        itemStyle: {
          color: "#e098c7",
          color0: "transparent",
          borderColor: "#e098c7",
          borderColor0: "#a4e8fc",
          borderWidth: "2",
        },
      },
      graph: {
        itemStyle: {
          borderWidth: 0,
          borderColor: "#ccc",
        },
        lineStyle: {
          width: 1,
          color: "#aaa",
        },
        symbolSize: "7",
        symbol: "circle",
        smooth: true,
        color: [
          "#9b8bba",
          "#e098c7",
          "#a4e8fc",
          "#71669e",
          "#cc70af",
          "#7cb4cc",
        ],
        label: {
          color: "#fff",
        },
      },
      map: {
        itemStyle: {
          areaColor: "#eee",
          borderColor: "#444",
          borderWidth: 0.5,
        },
        label: {
          color: "#000",
        },
        emphasis: {
          itemStyle: {
            areaColor: "#e098c7",
            borderColor: "#444",
            borderWidth: 1,
          },
          label: {
            color: "#ffffff",
          },
        },
      },
      geo: {
        itemStyle: {
          areaColor: "#eee",
          borderColor: "#444",
          borderWidth: 0.5,
        },
        label: {
          color: "#000",
        },
        emphasis: {
          itemStyle: {
            areaColor: "#e098c7",
            borderColor: "#444",
            borderWidth: 1,
          },
          label: {
            color: "#ffffff",
          },
        },
      },
      categoryAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#cccccc",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#ffffff",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#eeeeee", "#333333"],
          },
        },
        splitArea: {
          show: true,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      valueAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#ffffff",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#ffffff",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#eeeeee", "#333333"],
          },
        },
        splitArea: {
          show: true,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      logAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#ffffff",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#333",
          },
        },
        axisLabel: {
          show: true,
          color: "#ffffff",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#eeeeee", "#333333"],
          },
        },
        splitArea: {
          show: true,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      timeAxis: {
        axisLine: {
          show: true,
          lineStyle: {
            color: "#ffffff",
          },
        },
        axisTick: {
          show: false,
          lineStyle: {
            color: "#fff",
          },
        },
        axisLabel: {
          show: true,
          color: "#ffffff",
        },
        splitLine: {
          show: false,
          lineStyle: {
            color: ["#eeeeee", "#333333"],
          },
        },
        splitArea: {
          show: true,
          areaStyle: {
            color: ["rgba(250,250,250,0.05)", "rgba(200,200,200,0.02)"],
          },
        },
      },
      toolbox: {
        iconStyle: {
          borderColor: "#fff",
        },
        emphasis: {
          iconStyle: {
            borderColor: "#fff",
          },
        },
      },
      legend: {
        textStyle: {
          color: "#ffffff",
        },
        pageTextStyle: {
          color: "#fff",
        },
      },
      tooltip: {
        axisPointer: {
          lineStyle: {
            color: "#fff",
            width: 1,
          },
          crossStyle: {
            color: "#fff",
            width: 1,
          },
        },
      },
      timeline: {
        lineStyle: {
          color: "#a4e8fc",
          width: 1,
        },
        itemStyle: {
          color: "#a4e8fc",
          borderWidth: 1,
        },
        controlStyle: {
          color: "#a4e8fc",
          borderColor: "#a4e8fc",
          borderWidth: 0.5,
        },
        checkpointStyle: {
          color: "#a4e8fc",
          borderColor: "#8a7ca8",
        },
        label: {
          color: "#a4e8fc",
        },
        emphasis: {
          itemStyle: {
            color: "#a4e8fc",
          },
          controlStyle: {
            color: "#a4e8fc",
            borderColor: "#a4e8fc",
            borderWidth: 0.5,
          },
          label: {
            color: "#a4e8fc",
          },
        },
      },
      visualMap: {
        color: ["#8a7ca8", "#e098c7", "#cceffa"],
      },
      dataZoom: {
        backgroundColor: "rgba(0,0,0,0)",
        dataBackgroundColor: "rgba(255,255,255,0.3)",
        fillerColor: "rgba(167,183,204,0.4)",
        handleColor: "#a7b7cc",
        handleSize: "100%",
        textStyle: {
          color: "#333",
        },
      },
      markPoint: {
        label: {
          color: "#eee",
        },
        emphasis: {
          label: {
            color: "#eee",
          },
        },
      },
    },
  },
};
