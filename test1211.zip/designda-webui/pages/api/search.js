import { useState, useEffect, useRef } from 'react'
import axios from 'axios'
const SearchBox = (props) => {
  const [post, setPost] = useState([])

  const users = ['phase', 'run_tag', 'test1', 'test2', 'test3']
  const symbols = ['=', '!=']
  const [names, setNames] = useState([])
  const operators = ['AND', 'OR', '(', ')']

  const [selectedItems, setSelectedItems] = useState([])
  const [currentStep, setCurrentStep] = useState(1)
  const [searchValue, setSearchValue] = useState('')

  const searchInputRef = useRef(null)

let endpointUrl= 'http://' + window.location.hostname+':' + props.data.react_server_port

  useEffect(() => {
    if (currentStep === 3 && selectedItems.length > 0) {
      const { user, symbol } = selectedItems[selectedItems.length - 1]
      // fetch(`https://jsonplaceholder.typicode.com/todos/`)
      //   .then((response) => response.json())
      //   .then((data) => setNames(data))
      //   .catch((error) => console.log(error));

      axios
        //.post('http://10.192.196.216:20934/api/tag_autocomplete', {
                  .post(endpointUrl+'/api/tag_autocomplete', {

          
          tag_name: user,
        })
        .then((response) => setNames(response.data.data))
      // .then((response) => console.log('My Names' +JSON.stringify(response.data.data)))
      //.then((data) => setNames(data));
    }
  }, [currentStep, selectedItems])

  const handleItemClick = (item) => {
    setSelectedItems((prevSelectedItems) => {
      let updatedSelectedItems = [...prevSelectedItems]
      const lastIndex = updatedSelectedItems.length - 1

      switch (currentStep) {
        case 1:
          updatedSelectedItems = [...updatedSelectedItems, { user: item }]
          setCurrentStep(2)
          break
        case 2:
          updatedSelectedItems[lastIndex].symbol = item
          if (updatedSelectedItems[lastIndex].user) {
            setCurrentStep(3)
          }
          break
        case 3:
          updatedSelectedItems[lastIndex].name = item
          setCurrentStep(4)
          break
        case 4:
          updatedSelectedItems[lastIndex].operator = item
          setCurrentStep(1)
          break
        default:
          break
      }

      return updatedSelectedItems
    })
    setSearchValue('')
  }

  const handleRemoveItem = (index) => {
    setSelectedItems((prevSelectedItems) => {
      let updatedSelectedItems = [...prevSelectedItems]
      updatedSelectedItems.splice(index, 1)
      return updatedSelectedItems
    })
  }

  const handleSearch = () => {
    // perform search based on selectedItems

    axios
      .post('http://10.192.196.216:20934/api/fetch_docs', {
        //"text" :"username = 'girjeshs' OR username = 'kramesh'"
        text: "phase = '0809' AND run_tag = '1007-N_SP5'",
      })
      .then((response) => setPost(response.data.data))

    //
  }

  const handleKeyDown = (event) => {
    if (event.key === 'Backspace') {
      if (searchValue === '') {
        event.preventDefault()
        const lastIndex = selectedItems.length - 1
        setSelectedItems((prevSelectedItems) => {
          let updatedSelectedItems = [...prevSelectedItems]
          const lastItem = updatedSelectedItems[lastIndex]
          if (lastItem) {
            const { user, symbol, name, operator } = lastItem
            const currentItem = { user, symbol, name, operator }
            if (currentItem.operator) {
              currentItem.operator = currentItem.operator.slice(0, -1)
            } else if (currentItem.name) {
              currentItem.name = currentItem.name.slice(0, -1)
            } else if (currentItem.symbol) {
              currentItem.symbol = currentItem.symbol.slice(0, -1)
            } else if (currentItem.user) {
              currentItem.user = currentItem.user.slice(0, -1)
            }
            if (
              currentItem.user ||
              currentItem.symbol ||
              currentItem.name ||
              currentItem.operator
            ) {
              updatedSelectedItems[lastIndex] = currentItem
            } else {
              updatedSelectedItems.splice(lastIndex, 1)
              setCurrentStep(lastIndex === 0 ? 1 : lastIndex)
            }
          }
          return updatedSelectedItems
        })
      } else {
        setSearchValue(searchValue.slice(0, -1))
      }
    }
  }

  const getSuggestions = () => {
    switch (currentStep) {
      case 1:
        return users.filter((user) => user.includes(searchValue))
      case 2:
        return symbols.filter((symbol) => symbol.includes(searchValue))
      case 3:
        if (selectedItems.length > 0) {
          const { user, symbol } = selectedItems[selectedItems.length - 1]
          return user && symbol
            ? names.filter((name) => name.includes(searchValue))
            : []
        }
        return []
      case 4:
        return operators.filter((operator) => operator.includes(searchValue))
      default:
        return []
    }
  }

  const suggestions = getSuggestions();
  console.log(props.data);
  return (
    <div className="search-box">
      <input
        style={{ width: '2000px' }}
        type="text"
        className="search-input"
        value={selectedItems
          .map((item, index) => {
            const { user, symbol, name, operator } = item
            return `${user || ''} ${symbol || ''} ${name || ''} ${
              operator || ''
            }`
          })
          .join(' ')}
        onChange={(e) => setSearchValue(e.target.value)}
        onKeyDown={handleKeyDown} // new line
        ref={searchInputRef} // new line
      />

      <button className="search-button" onClick={handleSearch}>
        Search
      </button>

      <ul className="suggestions-list">
        {suggestions.map((item) => (
          <li key={item} onClick={() => handleItemClick(item)}>
            {item}
          </li>
        ))}
      </ul>

      <div style={{ border: '1px solid #ccc' }}></div>
      {post.map((item, index) => {
        return (
          <ul>
            <li key={item.key}> {item.key} </li>
          </ul>
        )
      })}
    </div>
  )
}

export default SearchBox
