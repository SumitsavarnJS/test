import React, { useState, useCallback, useEffect } from 'react'
import useWebSocket, { ReadyState } from 'react-use-websocket'
import { styled } from '@mui/material/styles'
import Box from '@mui/material/Box'
import Checkbox from '@mui/material/Checkbox'
import Divider from '@mui/material/Divider'
import FormControlLabel from '@mui/material/FormControlLabel'
import Typography from '@mui/material/Typography'
import { createTheme } from '@mui/material/styles'
import { Skeleton } from '@mui/material'
import Stack from '@mui/material/Stack'


const theme = createTheme({
  palette: {
    primary: {
      main: '#00ff00', // green
    },
    secondary: {
      main: '#ff0000', // red
    },
  },
})

const Container = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  padding: theme.spacing(0.1),
}))

const ClusterLabel = styled(Typography)(({ theme }) => ({
  marginRight: theme.spacing(0.5),
  fontSize:'1.2em'
}))

const KeyValueDivider = styled(Divider)(({ theme }) => ({
  flexGrow: 1,
  height:'0.05em',
  backgroundColor:'black',
  color:'black',
  marginLeft: theme.spacing(0.5),
  marginRight: theme.spacing(0.5),
}))

const KeyValueContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  
}))

function WebSocketCompute({ socketUrl }) {
  const [messageHistory, setMessageHistory] = useState('')
  const [showLine, setShowLine] = useState(false)
  const { sendMessage, lastMessage, readyState } = useWebSocket(socketUrl)

  useEffect(() => {
    sendMessage(JSON.stringify({ endpoints: ['compute_cluster'] }))
  }, [])

  useEffect(() => {
    if (lastMessage !== null) {
      // setMessageHistory((prev) => prev.concat(lastMessage.data))
      setShowLine(true)
      setMessageHistory(JSON.parse(lastMessage.data))
    }
  }, [lastMessage, readyState])

  return (
    <div style={{ overflowY: 'auto'}}>
      {showLine ? (
        <>
          {messageHistory.data.map((item, index) => {
            return (
              <>
                {/* <LinearProgress
                  variant="determinate"
                  value={(item.filled_storage / item.total_storage) * 100}
                /> */}

                {/* <Container>
                  <KeyValueContainer>
                    <ClusterLabel>compute_cluster</ClusterLabel>
                    <Typography>{item.active}</Typography>
                  </KeyValueContainer>
                  <KeyValueDivider />
                  <ClusterLabel>Running Workers</ClusterLabel>
                  <Typography>{item.runningWorkers}</Typography>
                  <ClusterLabel>Queued Workers</ClusterLabel>
                  <Typography>{item.queuedWorkers}</Typography>

                  <KeyValueDivider />

                  <KeyValueDivider />
                </Container> */}

                {item.active ? (
                  <Container>
                    <KeyValueContainer sx={{height:'40px'}}>
                      <ClusterLabel sx={{marginRight: '8px'}}> Compute: </ClusterLabel>
                      <FormControlLabel 
                        sx={{fontSize:'1em'}}
                        control={
                          <Checkbox
                            checked={true} // or false, depending on whether the checkbox should be checked
                            icon={
                              <span
                                style={{
                                  borderRadius: '50%',
                                  width: 16,
                                  height: 16,
                                  backgroundColor: theme.palette.primary.main,
                                  display: 'block',
                                  marginRight: '0.1%',
                                  marginLeft: '0.2%',

                                }}
                              />
                            }
                            checkedIcon={
                              <span
                                style={{
                                  borderRadius: '50%',
                                  width: 16,
                                  height: 16,
                                  backgroundColor: '#708008',
                                  display: 'block',
                                  
                                }}
                              />
                            }
                          />
                        }
                        label="Active"
                        
                      />
                    </KeyValueContainer>
                    <KeyValueDivider 
                    />

                    <KeyValueContainer sx={{height:'40px'}}>
                      <ClusterLabel>
                        {' '}
                        Running Workers: {item.runningWorkers}{' '}
                      </ClusterLabel>
                    </KeyValueContainer>

                    <KeyValueDivider />

                    <KeyValueContainer sx={{height:'40px'}}>
                      <ClusterLabel>
                        {' '}
                        Queued Workers: {item.queuedWorkers}
                      </ClusterLabel>
                    </KeyValueContainer>
                  </Container>
                ) : (
                  <p>Inactive </p>
                )}
              </>
            )
          })}
        </>
      ) : (
        <Stack spacing={1}>
          {/* For variant="text", adjust the height via font-size */}
          <Skeleton variant="text" sx={{ fontSize: '1rem' }} />

          {/* For other variants, adjust the size with `width` and `height` */}
          <Skeleton variant="circular" width={40} height={20} />
          <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
        </Stack>
      )}
    </div>
  )
}

export default function ComputeCluster() {
  const [config, setConfig] = useState(null)

  useEffect(() => {
    async function loadConfig() {
      const response = await fetch('/v1/config.json')
      const data = await response.json()
      setConfig(data)
    }
    loadConfig()
  }, [])

  if (!config || !config.websocket_url) {
    return null
  }

  const socketUrl = `${config.websocket_url}`

  return <WebSocketCompute socketUrl={socketUrl} />
}
