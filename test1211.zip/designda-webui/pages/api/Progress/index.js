import React, { useState, useCallback, useEffect } from "react";
import useWebSocket, { ReadyState } from "react-use-websocket";
import LinearProgress from "@mui/material/LinearProgress";
import Stack from "@mui/material/Stack";
import FormLabel from "@mui/material/FormLabel";
import { Typography, Box } from "@mui/material";
import { Skeleton } from "@mui/material";

function WebSocketConnection({ socketUrl }) {
  const [messageHistory, setMessageHistory] = useState("");
  const [showLine, setShowLine] = useState(false);
  const { sendMessage, lastMessage, readyState } = useWebSocket(socketUrl);
  const [clusterData, setClusterData] = useState([]);
  const [storageData, setStorageData] = useState([]);

  useEffect(() => {
    sendMessage(
      JSON.stringify({
        endpoints: ["analytics_data_storage", "compute_cluster"],
      })
    );
  }, []);

  useEffect(() => {
    if (lastMessage !== null) {
      setShowLine(true);
      // console.log(lastMessage.data)
      setMessageHistory(JSON.parse(lastMessage.data));
      if (messageHistory.source === "compute_cluster") {
        setClusterData(messageHistory.data);
      }
      if (messageHistory.source === "analytics_data_storage") {
        setStorageData(messageHistory.data);
      }
    }
  }, [lastMessage, readyState]);
  return (
    <div style={{ overflowY: "auto" }}>
      {showLine ? (
        <>
          {storageData.map((item, index) => {
            return (
              <div>
                {/* <LinearProgress

                  variant="determinate"

                  value={(item.filled_storage / item.total_storage) * 100}

                /> */}

                <Stack
                  sx={{
                    width: "100%",
                    marginBottom: 1,
                    overflowY: "auto",
                    position: "relative",
                  }}
                >
                  {/* <FormLabel style={{ float: 'left', left: '0' }}>
                    {(item.filled_storage / item.total_storage).toFixed(2) *
                      100}
                    %
                    <Typography
                      style={{
                        // position: 'absolute',
                        // right: '0',
                        float: 'right',
                        right: '0',
                        color: 'black',
                        fontSize: '12px',
                      }}
                    >
                      {item.project}/ {item.total_storage.toFixed(2)}GB /
                      {item.available_storage.toFixed(2)}GB
                    </Typography>
                  </FormLabel> */}

                  <Box
                    sx={{
                      fontSize: "0.95em",
                      fontFamily: "Arial",
                      color: "black",
                      left: "0",
                      top: "0",
                      overflowY: "auto",
                      overflowX: "auto",
                    }}
                  >
                    <div
                      style={{
                        float: "left",
                        top: "0",
                        fontWeight: "bold",
                        fontSize: "1em",
                        textTransform: "capitalize",
                      }}
                    >
                      {" "}
                      {item.project}{" "}
                    </div>
                    <div
                      style={{
                        float: "right",
                        fontSize: "1em",
                      }}
                    >
                      {(item.available_storage / 1000).toFixed(2)}TB free of{" "}
                      {(item.total_storage / 1000).toFixed(2)}TB
                    </div>
                  </Box>

                  <Box sx={{ width: "100%", overflowY: "auto" }}>
                    <LinearProgress
                      variant="determinate"
                      value={(item.filled_storage / item.total_storage) * 100}
                      sx={{
                        backgroundColor: `rgb(90, 42, 130,0.4)`,

                        "& .MuiLinearProgress-bar": {
                          backgroundColor: `rgb(90, 42, 130)`,
                        },

                        height: 10, // increase the height here
                      }}
                    />
                  </Box>
                </Stack>
              </div>
            );
          })}
        </>
      ) : (
        <Box pacing={2}>
          <Skeleton />
          <Skeleton animation="wave" />
          <Skeleton animation={false} />
          <Skeleton />
        </Box>
      )}
    </div>
  );
}

export default function WebSocketDemo() {
  const [config, setConfig] = useState(null);

  useEffect(() => {
    async function loadConfig() {
      const response = await fetch("/v1/config.json");
      const data = await response.json();
      // console.log('My Data')
      setConfig(data);
    }
    loadConfig();
  }, []);

  if (!config || !config.websocket_url) {
    return null;
  }

  const socketUrl = `${config.websocket_url}`;

  return <WebSocketConnection socketUrl={socketUrl} />;
}
