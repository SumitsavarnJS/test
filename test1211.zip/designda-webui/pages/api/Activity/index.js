import ActivityGraph from "./Activity";
import Stack from '@mui/material/Stack'
import getConfig from 'next/config'
import { styled } from '@mui/material/styles'
import Paper from '@mui/material/Paper'
import { Typography, Box ,Grid} from '@mui/material'


const Item = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  textAlign: 'center',
  flexGrow: 1,
}))

const activity = [
  // { date: "2022-01-01", count: 0 },
  // { date: "2022-01-02", count: 1 },
  // { date: "2022-01-03", count: 3 },

];
const { publicRuntimeConfig } = getConfig()
const imageUrl = publicRuntimeConfig.basePath

const HomePage = () => {
  return (
    <Box id="userSummarayStack" sx={{padding:'16px 25px 16px 16px',height:'36vh'}}>

        <Box
          sx={{
            fontSize: '3vh',
            fontFamily: 'Montserrat',
            color: '#5a2d84',
            left: '0',
            top: '0',
            fontWeight: 'bold',
            height:'25%'
          }}
        >
          <div
            style={{
              float: 'left',
              top: '0',
            }}
          >
            User Summary
          </div>
          <div
            style={{
              float: 'right',
            }}
          >
            <img
              src={`${imageUrl}/unlock.png`}
              alt="Compute Icon"
            />
          </div>
        </Box>
        <div style={{height:'50%'}}>
          <ActivityGraph activity={activity} />
        </div>
      
        <Grid sx={{ marginTop: '10px' }} container spacing={3}>
          <Grid
            style={{
              width: '33%',
              float: 'left',
              textAlign: 'center',
              fontFamily: 'Montserrat',
              fontSize: '2vh',
              color: '#5a2a82',
            }}
            item
            xs={4}
          >
            Total Users
            <br></br>
            122
          </Grid>
          <Grid
            item
            style={{
              width: '33%',
              float: 'left',
              textAlign: 'center',
              fontFamily: 'Montserrat',
              fontSize: '2vh',
              color: '#5a2a82',
            }}
            xs={4}
          >
            Active Users
            <br></br>5
          </Grid>
          <Grid
            item
            style={{
              width: '33%',
              float: 'left',
              textAlign: 'center',
              fontFamily: 'Montserrat',
              fontSize: '2vh',
              color: '#5a2a82',
            }}
            xs={4}
          >
            New Users
            <br></br>0
          </Grid>
        </Grid>
    </Box>
  );  
};

export default HomePage;
