import CalendarHeatmap from 'react-calendar-heatmap'
import 'react-calendar-heatmap/dist/styles.css'

const dailyActivityData = [
  { date: '2022-12-01', count: 3 },
  { date: '2022-12-02', count: 7 },
  { date: '2022-12-03', count: 1 },
  { date: '2023-05-01', count: 3 },

  { date: '2023-05-02', count: 7 },

  { date: '2023-05-03', count: 1 },

  { date: '2023-05-04', count: 9 },

  { date: '2023-05-05', count: 3 },

  { date: '2023-05-05', count: 7 },

  { date: '2023-05-07', count: 1 },

  { date: '2023-05-08', count: 9 },

  { date: '2023-05-11', count: 3 },

  { date: '2023-05-12', count: 7 },

  { date: '2023-05-13', count: 1 },

  { date: '2023-05-14', count: 9 },

  { date: '2023-05-15', count: 3 },

  { date: '2023-05-26', count: 7 },

  { date: '2023-05-27', count: 1 },

  { date: '2023-05-28', count: 9 },
  { date: '2023-04-01', count: 3 },

  { date: '2023-04-02', count: 7 },

  { date: '2023-04-03', count: 1 },

  { date: '2023-04-04', count: 9 },

  { date: '2023-04-04', count: 3 },

  { date: '2023-04-04', count: 7 },

  { date: '2023-04-07', count: 1 },

  { date: '2023-04-08', count: 9 },

  { date: '2023-04-11', count: 3 },

  { date: '2023-04-12', count: 7 },

  { date: '2023-04-13', count: 1 },

  { date: '2023-04-14', count: 9 },

  { date: '2023-04-15', count: 3 },

  { date: '2023-04-26', count: 7 },

  { date: '2023-04-27', count: 1 },

  { date: '2023-04-28', count: 9 },
  { date: '2023-03-01', count: 3 },

  { date: '2023-03-02', count: 7 },

  { date: '2023-03-03', count: 1 },

  { date: '2023-03-03', count: 9 },

  { date: '2023-03-03', count: 3 },

  { date: '2023-03-03', count: 7 },

  { date: '2023-03-07', count: 1 },

  { date: '2023-03-08', count: 9 },

  { date: '2023-03-11', count: 3 },

  { date: '2023-03-12', count: 7 },

  { date: '2023-03-13', count: 1 },

  { date: '2023-03-14', count: 9 },

  { date: '2023-03-15', count: 3 },

  { date: '2023-03-26', count: 7 },

  { date: '2023-03-27', count: 1 },

  { date: '2023-03-28', count: 9 },
  { date: '2023-02-01', count: 3 },

  { date: '2023-02-08', count: 7 },

  { date: '2023-02-22', count: 1 },

  { date: '2023-02-20', count: 9 },

  { date: '2023-02-02', count: 3 },

  { date: '2023-02-12', count: 7 },

  { date: '2023-02-07', count: 1 },

  { date: '2023-02-08', count: 9 },

  { date: '2023-02-11', count: 3 },

  { date: '2023-02-12', count: 7 },

  { date: '2023-02-13', count: 1 },

  { date: '2023-02-14', count: 9 },

  { date: '2023-02-15', count: 3 },

  { date: '2023-02-26', count: 7 },

  { date: '2023-02-27', count: 1 },

  { date: '2023-02-28', count: 9 },
  { date: '2023-01-01', count: 3 },

  { date: '2023-01-08', count: 7 },

  { date: '2023-01-22', count: 1 },

  { date: '2023-01-20', count: 9 },

  { date: '2023-01-01', count: 3 },

  { date: '2023-01-12', count: 7 },

  { date: '2023-01-07', count: 1 },

  { date: '2023-01-08', count: 9 },

  { date: '2023-01-11', count: 3 },

  { date: '2023-01-12', count: 7 },

  { date: '2023-01-13', count: 1 },

  { date: '2023-01-14', count: 9 },

  { date: '2023-01-15', count: 3 },

  { date: '2023-01-26', count: 7 },

  { date: '2023-01-27', count: 1 },

  { date: '2023-01-28', count: 9 },

  // ...etc.
  { date: '2023-06-01', count: 3 },
  { date: '2023-06-02', count: 7 },
  { date: '2023-06-03', count: 1 },
  { date: '2023-06-04', count: 9 },
  { date: '2023-06-05', count: 3 },
  { date: '2023-06-06', count: 7 },
  { date: '2023-06-07', count: 1 },
  { date: '2023-06-08', count: 9 },
  { date: '2023-06-11', count: 3 },
  { date: '2023-06-12', count: 7 },
  { date: '2023-06-13', count: 1 },
  { date: '2023-06-14', count: 9 },
  { date: '2023-06-15', count: 3 },
  { date: '2023-06-26', count: 7 },
  { date: '2023-06-27', count: 1 },
  { date: '2023-06-28', count: 9 },
  // ...etc.
]

const DailyActivityHeatmap = () => {
  return (
    <div className="daily-activity-heatmap">
      <CalendarHeatmap
        startDate={new Date('2023-01-01')}
        endDate={new Date('2023-12-31')}
        values={dailyActivityData}
        showMonthLabels={true}
        monthSpacing={20}
      />
    </div>
  )
}

export default DailyActivityHeatmap
