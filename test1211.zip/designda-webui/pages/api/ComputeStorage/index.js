import React, { useState, useCallback, useEffect } from "react";
import useWebSocket, { ReadyState } from "react-use-websocket";
import LinearProgress from "@mui/material/LinearProgress";
import Stack from "@mui/material/Stack";
import FormLabel from "@mui/material/FormLabel";
import { Typography, Box } from "@mui/material";
import { Skeleton } from "@mui/material";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import { styled } from "@mui/material/styles";
import getConfig from "next/config";
import Checkbox from "@mui/material/Checkbox";
import Divider from "@mui/material/Divider";
import FormControlLabel from "@mui/material/FormControlLabel";
import { createTheme } from "@mui/material/styles";
import styles from "./ComputeStorage.module.css";

const { publicRuntimeConfig } = getConfig();
const imageUrl = publicRuntimeConfig.basePath;

const Item = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  textAlign: "center",
  flexGrow: 1,
}));
const theme = createTheme({
  palette: {
    primary: {
      main: "#00ff00", // green
    },
    secondary: {
      main: "#ff0000", // red
    },
  },
});

const Container = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  padding: theme.spacing(0.1),
}));

const ClusterLabel = styled(Typography)(({ theme }) => ({
  marginRight: theme.spacing(0.5),
  fontSize: "1.2em",
}));

const KeyValueDivider = styled(Divider)(({ theme }) => ({
  flexGrow: 1,
  height: "0.05em",
  backgroundColor: "black",
  color: "black",
  marginLeft: theme.spacing(0.5),
  marginRight: theme.spacing(0.5),
}));

const KeyValueContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
}));

function WebSocketConnection({ socketUrl }) {
  const [messageHistory, setMessageHistory] = useState("");
  const [showLine, setShowLine] = useState(false);
  const { sendMessage, lastMessage, readyState } = useWebSocket(socketUrl);
  const [clusterData, setClusterData] = useState([]);
  const [storageData, setStorageData] = useState([]);

  useEffect(() => {
    sendMessage(
      JSON.stringify({
        endpoints: ["analytics_data_storage", "compute_cluster"],
      })
    );
  }, []);

  useEffect(() => {
    if (lastMessage !== null) {
      setShowLine(true);
      setMessageHistory(JSON.parse(lastMessage.data));
    }
  }, [lastMessage, readyState]);

  useEffect(() => {
    if (messageHistory !== null) {
      if (messageHistory.source === "compute_cluster") {
        console.log("clusters Data", messageHistory.data);
        setClusterData(messageHistory.data);
      }

      if (messageHistory.source === "analytics_data_storage") {
        console.log("Storage Data", messageHistory.data);
        setStorageData(messageHistory.data);
      }
    }
  }, [messageHistory]);


  return (
    <Stack sx={{ height: "35%" }} direction={"row"} spacing={"2%"}>
      <Item
        id="computeClusterItem"
        sx={{
          width: "70%",
          border: `1px solid #b3b0b0`,
          boxShadow: `0px 2px 4px rgba(0, 0, 0, 0.25)`,
          borderRadius: `12px`,
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <Box
          sx={{
            fontSize: "3vh",
            fontFamily: "Montserrat",
            color: "#5a2d84",
            left: "0",
            top: "0",
            fontWeight: "bold",
            height: "30%",
          }}
        >
          <div
            style={{
              float: "left",
              top: "0",
            }}
          >
            Compute Cluster
          </div>
          <div
            style={{
              float: "right",
            }}
          >
            <img src={`${imageUrl}/compute_icon.png`} alt="Compute Icon" />
          </div>
        </Box>
        <div style={{ overflowY: "auto", overflowX: "auto" }}>
          {showLine ? (
            <>
              {clusterData.map((item, index) => {
                return (
                  <>
                    {item.active ? (
                      <Container>
                        <KeyValueContainer sx={{ height: "40px" }}>
                          <ClusterLabel sx={{ marginRight: "8px" }}>
                            {" "}
                            Compute:{" "}
                          </ClusterLabel>
                          <FormControlLabel
                            control={
                              <Checkbox
                                checked={true} // or false, depending on whether the checkbox should be checked
                                icon={
                                  <span
                                    style={{
                                      borderRadius: "50%",
                                      width: 16,
                                      height: 16,
                                      backgroundColor:
                                        theme.palette.primary.main,
                                      display: "block",
                                      marginRight: "0.1%",
                                      marginLeft: "0.2%",
                                      fontSize: "1.2em",
                                    }}
                                  />
                                }
                                checkedIcon={
                                  <span
                                    style={{
                                      borderRadius: "50%",
                                      width: 16,
                                      height: 16,
                                      backgroundColor: "#708008",
                                      display: "block",
                                      fontSize: "1.2em",
                                    }}
                                  />
                                }
                              />
                            }
                            label={
                              <Typography sx={{ fontSize: "1.2em" }}>
                                Active
                              </Typography>
                            }
                          />
                        </KeyValueContainer>
                        <KeyValueDivider />

                        <KeyValueContainer sx={{ height: "40px" }}>
                          <ClusterLabel>
                            {" "}
                            Running Workers: {item.runningWorkers}{" "}
                          </ClusterLabel>
                        </KeyValueContainer>

                        <KeyValueDivider />

                        <KeyValueContainer sx={{ height: "40px" }}>
                          <ClusterLabel>
                            {" "}
                            Queued Workers: {item.queuedWorkers}
                          </ClusterLabel>
                        </KeyValueContainer>
                      </Container>
                    ) : (
                      <Typography sx={{ fontSize: "1.2em" }}>
                        Inactive
                      </Typography>
                    )}
                  </>
                );
              })}
            </>
          ) : (
            <Stack spacing={1}>
              {/* For variant="text", adjust the height via font-size */}
              <Skeleton variant="text" sx={{ fontSize: "1.2em" }} />

              {/* For other variants, adjust the size with `width` and `height` */}
              <Skeleton variant="circular" width={40} height={20} />
              <Skeleton variant="text" />
            </Stack>
          )}
        </div>
      </Item>
      <Item
        id="StorageItem"
        sx={{
          width: "70%",
          border: `1px solid #b3b0b0`,
          boxShadow: `0px 2px 4px rgba(0, 0, 0, 0.25)`,
          borderRadius: `12px`,
          overflowY: "auto",
          overflowX: "auto",
        }}
      >
        <Box
          sx={{
            fontSize: "3vh",
            fontFamily: "Montserrat",
            color: "#5a2d84",
            left: "0",
            top: "0",
            fontWeight: "bold",
            height: "30%",
          }}
        >
          <div
            style={{
              float: "left",
              top: "0",
            }}
          >
            {" "}
            Storage
          </div>
          <div
            style={{
              float: "right",
            }}
          >
            <img src={`${imageUrl}/inbox.png`} alt="Storage Icon" />
          </div>
        </Box>
        <div style={{ overflowY: "auto", overflowX: "auto" }}>
          {showLine ? (
            <>
              {storageData.map((item, index) => {
                return (
                  <div>
                    {/* <LinearProgress

                            variant="determinate"

                            value={(item.filled_storage / item.total_storage) * 100}

                            /> */}

                    <Stack
                      sx={{
                        width: "100%",
                        marginBottom: 1,
                        overflowY: "auto",
                        overflowX: "auto",
                        position: "relative",
                      }}
                    >
                      <Box
                        sx={{
                          fontSize: "0.9em",
                          fontFamily: "Montserrat",
                          color: "black",
                          left: "0",
                          top: "0",
                          overflowY: "auto",
                          overflowX: "auto",
                        }}
                      >
                        <div
                          style={{
                            float: "left",
                            top: "0",
                            // fontWeight: 'bold',
                            fontSize: "0.9em",
                            width: "30%",
                            textAlign: "left",
                          }}
                        >
                          <Typography noWrap={true} sx={{ width: "100%" }}>
                            {" "}
                            {item.project}{" "}
                          </Typography>
                        </div>
                        <div
                          style={{
                            float: "right",
                            fontSize: "0.9em",
                          }}
                        >
                          {(item.available_storage / 1000).toFixed(2)}TB free of{" "}
                          {(item.total_storage / 1000).toFixed(2)}TB
                        </div>
                      </Box>

                      <Box
                        sx={{
                          width: "100%",
                          overflowY: "auto",
                          overflowX: "auto",
                        }}
                      >
                        <LinearProgress
                          variant="determinate"
                          value={
                            (item.filled_storage / item.total_storage) * 100
                          }
                          sx={{
                            backgroundColor: `rgb(90, 42, 130,0.4)`,

                            "& .MuiLinearProgress-bar": {
                              backgroundColor: `rgb(90, 42, 130)`,
                            },

                            height: 10, // increase the height here
                          }}
                        />
                      </Box>
                    </Stack>
                  </div>
                );
              })}
            </>
          ) : (
            <Box pacing={2}>
              <Skeleton />
              <Skeleton animation="wave" />
              <Skeleton animation={false} />
              <Skeleton />
            </Box>
          )}
        </div>
      </Item>
    </Stack>
  );
}
export default function WebSocketDemo() {
  const [config, setConfig] = useState(null);

  useEffect(() => {
    async function loadConfig() {
      const response = await fetch("/v1/config.json");
      const data = await response.json();
      // console.log('My Data')
      setConfig(data);
    }
    loadConfig();
  }, []);

  if (!config || !config.websocket_url) {
    return null;
  }

  const socketUrl = `${config.websocket_url}`;

  return <WebSocketConnection socketUrl={socketUrl} />;
}
