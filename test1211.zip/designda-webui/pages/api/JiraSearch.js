import React, { useState } from 'react';
import Autosuggest from 'react-autosuggest';
import axios from 'axios';

const SearchPage = () => {
  const [value, setValue] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedSymbol, setSelectedSymbol] = useState(null);
  const [selectedName, setSelectedName] = useState(null);
  const [searchTerms, setSearchTerms] = useState([]);

  const users = ['Reporter', 'User', 'Requester'];
  const symbols = ['=', '!='];
  const operators = ['AND', 'OR'];

  const fetchNames = async () => {
    // Make a dummy API call to fetch the list of names based on the selected user and symbol
    //const res = await axios.get(`/api/names?user=${selectedUser}&symbol=${selectedSymbol}`);
    const data = ['Peter','John','Albert'];
    return data;
  };

  const getSuggestions = async (value) => {
    let results = [];
    if (!selectedUser) {
      results = users.filter((user) => user.toLowerCase().includes(value.toLowerCase()));
    } else if (selectedUser && !selectedSymbol) {
      results = symbols.filter((symbol) => symbol.toLowerCase().includes(value.toLowerCase()));
    } else if (selectedUser && selectedSymbol && !selectedName) {
      const names = await fetchNames();
      results = names.filter((name) => name.toLowerCase().includes(value.toLowerCase()));
    } else {
      results = operators.filter((operator) => operator.toLowerCase().includes(value.toLowerCase()));
    }
    setSuggestions(results);
  };

  const onSuggestionsFetchRequested = ({ value }) => {
    getSuggestions(value);
  };

  const onSuggestionsClearRequested = () => {
    setSuggestions([]);
  };

  const onSuggestionSelected = (event, { suggestion }) => {
    if (users.includes(suggestion)) {
      setSelectedUser(suggestion);
      setSearchTerms([...searchTerms, suggestion]);
      setValue('');
    } else if (symbols.includes(suggestion)) {
      setSelectedSymbol(suggestion);
      setSearchTerms([...searchTerms, suggestion]);
      setValue('');
    } else if (selectedUser && selectedSymbol && !selectedName) {
      setSelectedName(suggestion);
      setSearchTerms([...searchTerms, suggestion]);
      setValue('');
    } else {
      setSearchTerms([...searchTerms, suggestion]);
      setSelectedUser(null);
      setSelectedSymbol(null);
      setSelectedName(null);
      setValue('');
    }
  };

  const inputProps = {
    value,
    onChange: (event, { newValue }) => {
      setValue(newValue);
    },
  };

  return (
    <div>
      <Autosuggest
        suggestions={suggestions}
        onSuggestionsFetchRequested={onSuggestionsFetchRequested}
        onSuggestionsClearRequested={onSuggestionsClearRequested}
        onSuggestionSelected={onSuggestionSelected}
        getSuggestionValue={(suggestion) => suggestion}
        renderSuggestion={(suggestion) => <div>{suggestion}</div>}
        inputProps={inputProps}
      />
      <div>
        {searchTerms.map((term) => (
          <span key={term}>{term} </span>
        ))}
      </div>
    </div>
  );
};

export default SearchPage;
