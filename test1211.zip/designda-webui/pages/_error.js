// pages/_error.js
import Link from 'next/link';

function ErrorPage({ statusCode }) {
  return (
    <div>
      <h1>{statusCode} - Error</h1>
      {statusCode === 404 ? (
        <p>The page you requested could not be found</p>
      ) : (
        <p>An error occurred on the server</p>
      )}
      <Link href="/">
        Go back home
      </Link>
    </div>
  );
}

ErrorPage.getInitialProps = ({ res, err }) => {
  const statusCode = res ? res.statusCode : err ? err.statusCode : 404;
  return { statusCode };
};

export default ErrorPage;
