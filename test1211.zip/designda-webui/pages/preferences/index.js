import React from "react";
import ProfilePreferences from "../../components/ModalComponent/ProfilePreferences";

export default function Preference() {
  return <ProfilePreferences />;
}
