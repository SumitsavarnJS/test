import "../styles/globals.css";
import { NextUIProvider } from "@nextui-org/react";
import ErrorBoundary from "./ErrorBoundary";
import "react-calendar-heatmap/dist/styles.css";
import Layout from "../components/layouts";
import { ToastContainer } from "react-toastify";
import { SnackbarProvider } from "notistack";
import "react-toastify/dist/ReactToastify.css";
import * as echarts from "echarts";
// import dark from "../styles/echartsDarkTheme";
// import light from "../styles/echartsLightTheme";
import { echartsTheme } from "../styles/echartsThemes";
import AppLayout from "../components/layouts/AppLayout";

// import 'react-tabulator/lib/styles.css';
// import 'react-tabulator/lib/css/tabulator.min.css';
// import "react-tabulator/css/tabulator_simple.min.css";
import "tabulator-tables/dist/css/tabulator.min.css";
import "tabulator-tables/dist/css/tabulator_bootstrap4.min.css";
import { JsonProvider } from "../contexts/JsonContext";
import Loading from "./Loading";
import MsalProviderComponent from "../common/lib/MsalProviderComponent";

import "bootstrap/dist/css/bootstrap.min.css";

import "@fontsource/roboto"; // Defaults to weight 400
import "@fontsource/roboto/400.css";
import "@fontsource/roboto/400-italic.css";

// The content below is messing up table functionality!
// import "tabulator-tables/dist/css/tabulator.min.css";
// import "tabulator-tables-test/dist/css/tabulator.min.css";

import "./../styles/Tabulator_bootstrap4.min.css"; // Its related to Analytics and it does not harm matrix
import { ThemeProvider, createTheme } from "@mui/material/";
import useConfigStore from "../store/useConfigStore";

import Notification from "../common/ntfs_components/NotificationComp";
import BrowserCheck from "../components/layouts/browser_compatability/BrowserCompatability";

echarts.registerTheme("light", echartsTheme.light.theme);
echarts.registerTheme("infographic", echartsTheme.infographic.theme);
echarts.registerTheme("macarons", echartsTheme.macarons.theme);
echarts.registerTheme("roma", echartsTheme.roma.theme);
echarts.registerTheme("vintage", echartsTheme.vintage.theme);
echarts.registerTheme("essos", echartsTheme.essos.theme);
echarts.registerTheme("shine", echartsTheme.shine.theme);
echarts.registerTheme("wonderland", echartsTheme.wonderland.theme);
echarts.registerTheme("dark", echartsTheme.dark.theme);
echarts.registerTheme("purple-passion", echartsTheme["purple-passion"].theme);

const THEME = createTheme({
  palette: {
    mode: useConfigStore.getState().theme,
    primary: { light: "#e7d9f3", main: "#5A2A82" },
  },
  typography: {
    fontFamily: `"Roboto", "Arial", sans-serif`,
    fontSize: 14,
    fontWeightLight: 300,
    fontWeightRegular: 400,
    fontWeightMedium: 500,
  },

  components: {
    MuiTooltip: {
      styleOverrides: {
        // tooltip: {
        //   color: "white",
        //   backgroundColor: "#5B2C84",
        // },
      },
    },
  },
});

function MyApp({ Component,pageProps }) {
  return (<>
    <BrowserCheck />
    <MsalProviderComponent>
    <AppLayout>
        <ErrorBoundary>
            <ThemeProvider theme={THEME}>
              <SnackbarProvider Components={{ ntfs: Notification }}>
                <Layout>
                  <JsonProvider>
                    <ToastContainer />

                    <Loading />
                    <Component {...pageProps} />
                  </JsonProvider>
                </Layout>
              </SnackbarProvider>
            </ThemeProvider>
        </ErrorBoundary>
        </AppLayout>
      </MsalProviderComponent>
      </>

  );
}

export default MyApp;
