import   React , {useState} from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import CloseIcon from "@mui/icons-material/Close";
import IconButton from "@mui/material/IconButton";
import { flex, justifyContent } from "@xstyled/styled-components";
import PrimarySearchAppBar from "../../components/datacard/datacard";
import Divider from "@mui/material/Divider";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { styled, alpha } from "@mui/material/styles";
import Grid from "@mui/material/Grid";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import MenuIcon from "@mui/icons-material/Menu";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";

const KeyValueDivider = styled(Divider)(({ theme }) => ({
  borderWidth: 2,
  backgroundColor: "#5A2A82",
}));
const KeyValueDivide = styled(Divider)(({ theme }) => ({
  borderWidth: 1,
  backgroundColor: "#B3B4B3",
  marginBottom: "1%",
  marginTop: "1%",
}));

const style = {
  height: "100%",
  overflow: "auto",
  //paddingRight: "10px", // might require on resize
  borderTop: "3px solid #5a2a82",
  borderRight: '1px solid #dcdcdc',
};

export default function BasicModal(props) {
  const { searchString, resizePanel,keyProp } = props;
  return (   
    <>
    <Box sx={style}>
      {
        <PrimarySearchAppBar
        keyProp={keyProp}
          dataInput={searchString}
          resizePanel={resizePanel}
        />
      }
    </Box>
    </>
  );
}
