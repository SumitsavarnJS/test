import Head from "next/head";
import useConfigStore from "../store/useConfigStore";
import { useRouter } from "next/router";

import React, { useState, useEffect } from "react";
import { useMsal } from '@azure/msal-react';

export default function Home() {
  const router = useRouter();
  const { accounts } = useMsal();

  const [config, setConfig] = useState(null);
  const {
    setConfigData,
    theme,
  } = useConfigStore();

  useEffect(() => {
    async function loadConfig() {
      const response = await fetch("/v1/config.json");
      const data = await response.json();
      setConfig(data);
      setConfigData(data);
      //dispatch(setConfig(data));
    }
    loadConfig();
  }, []);
  return (
    <div style={{ color: theme == "light" ? "black" : "white" }}>
        <div>
    </div>

      <Head>
        <title className="text-transparent">Design.da</title>
        <meta name="description" content="Update Widgets with Comments" />
        <link rel="icon" href="Tab_icon_BW.svg" />
      </Head>

    </div>
  );
}
