import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Checkbox from '@mui/material/Checkbox';
import Divider from '@mui/material/Divider';
import FormControlLabel from '@mui/material/FormControlLabel';
import Typography from '@mui/material/Typography';

const Container = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  padding: theme.spacing(2),
  borderRadius: theme.shape.borderRadius,
  boxShadow: theme.shadows[1],
  border: `1px solid ${theme.palette.primary.main}`,
}));

const ClusterLabel = styled(Typography)(({ theme }) => ({
  marginRight: theme.spacing(2),
}));

const KeyValueDivider = styled(Divider)(({ theme }) => ({
  flexGrow: 1,
  marginLeft: theme.spacing(2),
  marginRight: theme.spacing(2),
}));

const KeyValueContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  marginTop: theme.spacing(1),
  marginBottom: theme.spacing(1),
}));

const ClusterBox = () => {
  return (
    <Container>
      <Typography variant="h6">Compte Cluster</Typography>

      <KeyValueContainer>
        <ClusterLabel>Cluster 1</ClusterLabel>
        <FormControlLabel
          control={<Checkbox defaultChecked sx={{ color: 'green' }} />}
          label="Active"
        />
       
      </KeyValueContainer>
      <KeyValueDivider />

      <KeyValueContainer>
        <ClusterLabel>Cluster 2</ClusterLabel>
        <FormControlLabel
          control={<Checkbox defaultChecked sx={{ color: 'red' }} />}
          label="Inactive"
        />
       
      </KeyValueContainer>
      <KeyValueDivider />
    </Container>
  );
};

export default ClusterBox;
