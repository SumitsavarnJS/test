import { useState, useEffect } from "react";
import { css } from "@emotion/react";
import { PulseLoader } from "react-spinners";
import { useRouter } from "next/router";
import useConfigStore from "../store/useConfigStore";

const override = css`
  display: block;
  margin: 0 auto;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;

function Loader() {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const { theme } = useConfigStore();

  useEffect(() => {
    const handleStart = () => setLoading(true);
    const handleComplete = () => setLoading(false);

    router.events.on("routeChangeStart", handleStart);
    router.events.on("routeChangeComplete", handleComplete);
    router.events.on("routeChangeError", handleComplete);

    return () => {
      router.events.off("routeChangeStart", handleStart);
      router.events.off("routeChangeComplete", handleComplete);
      router.events.off("routeChangeError", handleComplete);
    };
  }, [router]);

  if (!loading) {
    return null;
  }

  return (
    <div className="loader-container" style={{ position: "relative" }}>
      <div
        style={{
          position: "fixed",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: theme == "light" ? "#fff" : "rgb(25,25,25)",
          height: "100vh",
          width: "100vw",
          zIndex: 9999,
          top: '64px', // height of header component, so loader starts after the header
        }}
      >
        <PulseLoader
          css={override}
          size={15}
          color={"#8A2BE2"}
          loading={true}
        />
      </div>
    </div>
  );
}

export default Loader;
