import * as constants from "../../../constants/constants";
import useConfigStore from "../../../store/useConfigStore";
//widget refresh data import
import refreshTableView from "../widgets/tableView/TableViewApis";
import refreshInteractiveTableView from "../../../components/widgets/i_table_view/TableViewApis";

// import refreshBarChart from "../widgets/bar_chart/BarChartApis";
import refreshTimingPathMatrix from "../widgets/timing_path_matrix/TimingPathMatrixApi";
import refreshInterClockMatrix from "../widgets/interClockMatrix/InterClockMatrixApi";
import refreshTreemap from "../widgets/treemap/TreemapApi";
import refreshMultiFeatureBarPlot from "../widgets/multifeature_bar_chart/MultifeatureBarPlotApi";
import refreshKdePlot from "../widgets/kdeplot/KdePlotApi";
import refreshBubbleChart from "../widgets/bubble_chart/BubbleChartApi";
// import refreshTaskAnalysis from "../widgets/task_manager/TaskAnalysisManagerApi";
// import refreshcustomWorkFlow from "../widgets/flow_manager/custom_workflow_manager/CustomWorkflowManagerApi";
// import refreshflowManager from "../widgets/flow_manager/FlowManagerApi";
import refreshPieChart from "../widgets/pie_chart/PieChartApi";
import refreshHistogramPlotData from "../widgets/histogram/HistogramPlotApi";
import refreshBoxPlot from "../widgets/box_plot/BoxPlotApi";
import refreshMultiBoxPlotData from "../widgets/multi_boxplot/MultiBoxPlotApi";
import refreshLayoutViewData from "../../../components/layout_view/LayoutViewApis";
// import refreshMetrics from "../../metrics/MetricsApi";
import refreshLayoutTableView from "../../../components/layout_view/layoutTableView/TableLayoutApis";
// newly created widget APIs
import refreshThreeDSurfaceChart from "../../../components/widgets/three_d_surface_chart/ThreeDSurfaceChartApi";
import refreshWorkflowMonitorTable from "../../../components/widgets/workflow_monitor_table/WorkflowMonitorTableApi";
import refreshGroupBarChart from "../../../components/widgets/group_bar_chart/GroupBarChartApi";
import refershScatterPlot from "../../../components/widgets/scatter_plot/ScatterPlotApi";
import refreshLogMonitorTable from "../../../components/widgets/log_monitor_table/LogMonitorTableApi";
import refreshGraphChart from "../../../components/widgets/graph_chart/GraphChartApi";
import refreshGanttChart from "../../../components/widgets/gantt_chart/GanttChartApi";
import refreshIMetrics from "../../../components/widgets/i_metrics/IMetricsApi";
import refreshInteractiveWidget from "../../../components/widgets/generic_interactive_widget/iWidgetApi";
import refreshLogComparator from "../../../components/widgets/log_comparator/LogComparatorApi";
import refreshGenericChartV1 from "../../../components/widgets/generic_charts_v1/GenericChartsV1Apis";

const refreshWidgetContent = (
  props = {
    widgetId: "",
    widgetName: "",
    config: {},
    reportKey: "",
    rptType: "",
    variables: {},
  }
) => {
  const { widgetId, widgetName, config, reportKey, rptType, variables } = props;
  switch (widgetName) {
    // case constants.metricsSummary:
    //   refreshMetrics(widgetId, config, reportKey, rptType);
    //   break;
    case constants.tableView:
      refreshTableView(widgetId, config);
      break;
    case constants.tableViewExec:
      refreshInteractiveTableView(widgetId, config, variables);
      break;
    case constants.groupBarChart:
      refreshGroupBarChart(widgetId, config);
      break;
    case constants.timingPathMatrix:
      refreshTimingPathMatrix(widgetId, config);
      break;
    case constants.interClockMatrix:
      refreshInterClockMatrix(widgetId, config);
      break;
    case constants.treemap:
      refreshTreemap(widgetId, config);
      break;
    case constants.multiFeatureBarPlot:
      refreshMultiFeatureBarPlot(widgetId, config);
      break;
    case constants.kdePlot:
      refreshKdePlot(widgetId, config);
      break;
    case constants.bubbleChart:
      refreshBubbleChart(widgetId, config);
      break;
    case constants.histogram:
      refreshHistogramPlotData(widgetId, config);
      break;
    // Below Widgets merged to Workflow Monitor widget
    // case constants.taskAnalysisManager:
    //   refreshTaskAnalysis(widgetId, config);
    //   break;

    // case constants.customWorkflowManager:
    //   refreshcustomWorkFlow(widgetId, config);
    //   break;

    // case constants.flowAnalysisManager:
    //   refreshflowManager(widgetId, config);
    //   break;

    case constants.pieChart:
      refreshPieChart(widgetId, config);
      break;
    case constants.boxPlot:
      refreshBoxPlot(widgetId, config);
      break;
    case constants.multiBoxPlot:
      refreshMultiBoxPlotData(widgetId, config);
      break;
    case constants.layoutView:
      refreshLayoutViewData(widgetId, config);
      break;
    case constants.layoutTableView:
      refreshLayoutTableView(widgetId, config);
      break;
    case constants.threeDSurfaceChart:
      refreshThreeDSurfaceChart(widgetId, config);
      break;
    case constants.workflowMonitorTable:
      const wmtPayload = useConfigStore.getState()[`wmtPayload_${widgetId}`];
      const wmtPayloadExists = wmtPayload && Object.keys(wmtPayload).length > 0;
      refreshWorkflowMonitorTable(
        widgetId,
        wmtPayloadExists ? wmtPayload : {},
        config
      );
      break;
    case constants.scatterPlot:
      refershScatterPlot(widgetId, config);
      break;
    case constants.logMonitorTable:
      refreshLogMonitorTable(widgetId);
      break;
    case constants.graphChart:
      refreshGraphChart(widgetId, config);
      break;
    case constants.ganttChart:
      refreshGanttChart(widgetId, config);
      break;
    case constants.lineChart:
      refreshInteractiveWidget(widgetId, config, "line", variables);
      break;
    case constants.iScatterPlot:
      refreshInteractiveWidget(widgetId, config, "scatter", variables);
      break;
    case constants.iPieChart:
      refreshInteractiveWidget(widgetId, config, "pie", variables);
      break;
    case constants.iGroupBarChart:
      refreshInteractiveWidget(widgetId, config, "group_bar", variables);
      break;
    case constants.iTreemapChart:
      refreshInteractiveWidget(widgetId, config, "treemap", variables);
      break;
    case constants.iMultiFeatureBarChart:
      refreshInteractiveWidget(widgetId, config, "multifeature_bar", variables);
      break;
    case constants.iSunburstChart:
      refreshInteractiveWidget(widgetId, config, "sunburst", variables);
      break;
    case constants.I_METRICS:
      refreshIMetrics(widgetId);
      break;
    case constants.logComparator:
      refreshLogComparator(widgetId, config);
      break;
    case constants.GENERIC_CHARTS_V1:
      refreshGenericChartV1(widgetId, config, variables);
      break;
    default:
      console.log(
        `No API written for ${widgetName} widget or missing break statement in refresh switch`
      );
  }
};

export default refreshWidgetContent;
