import React, { useState } from "react";
import { styled } from "@mui/material/styles";
import Collapse from "@mui/material/Collapse";
import IconButton from "@mui/material/IconButton";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";

import DocumentView from "../widgets/document/DocumentView";

import { shallow } from "zustand/shallow";
import useGlobalStore from "../../../store/useGlobalStore";
import * as constants from "./../../../constants/constants";

import _ from "lodash";
import * as widgetFooterStyles from "./widgetFooter.module.css";
import { TextField, Typography } from "@mui/material";

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
  marginLeft: "auto",
  position: "absolute",
  bottom: "0px",
  right: "12px",
  padding: "0px",
  transition: theme.transitions.create("transform", {
    duration: theme.transitions.duration.shortest,
  }),
}));

function WidgetFooter(props) {
  const [expandDescription, setExpandDescription] = useState(true);
  const [editDescription, setEditDescription] = useState(false);
  const [tags, setTags] = useState(
    _.get(props.widgetProps.metaData, "tags", "")
  );
  const [description, setDescription] = useState(
    _.get(props.widgetProps.metaData, "description", "")
  );

  const { updateSettingsProp } = useGlobalStore(
    (state) => ({
      updateSettingsProp: state.updateSettingsProp,
    }),
    shallow
  );

  const handleExpandClick = () => {
    setExpandDescription(!expandDescription);
  };

  const updateDescriptionAndTagsInStore = (descriptionValue, tagsValue) => {
    updateSettingsProp(
      constants.allReports,
      props.reportKey,
      props.id,
      "metaData",
      {
        description: descriptionValue,
        tags: tagsValue,
      }
    );
  };

  const onEditButtonClick = () => {
    setEditDescription(true);
  };

  const onSaveButtonClick = () => {
    console.log("saved")
    updateDescriptionAndTagsInStore(description, tags);
    setEditDescription(false);
  }

  const onChangeDescription = (descText) => {
    setDescription(descText);
  };

  const onChangeTags = (newTags) => {
    setTags(newTags);
  };

  return (
    <div id="widgetFooter" className={widgetFooterStyles.widgetFooter}>
      <Collapse in={expandDescription} timeout="auto" unmountOnExit>
        <div>
          {editDescription ? (
            <IconButton
              onClick={onSaveButtonClick}
              aria-label="save note"
              className={widgetFooterStyles.editIcon}
            >
              <SaveIcon />
            </IconButton>
          ) : (
            <IconButton
              onClick={onEditButtonClick}
              aria-label="edit note"
              className={widgetFooterStyles.editIcon}
            >
              <EditIcon />
            </IconButton>
          )}
        </div>
        <div>
          <div style={{ flexGrow: "1", padding: "5px" }}>
            <DocumentView
              text={description}
              editMode={editDescription}
              handleEdit={onChangeDescription}
            />
          </div>
          {editDescription ? (
            <div>
              <Typography>Tags</Typography>
              <TextField
                value={tags}
                fullWidth
                onChange={(e) => {
                  onChangeTags(e.target.value);
                }}
                size="small"
              ></TextField>
            </div>
          ) : null}
        </div>
      </Collapse>

      <div id={"widgetTags"} className={widgetFooterStyles.widgetTags}>
        {tags && tags.length > 0 ? tags : ""}
      </div>
      <ExpandMore
        expand={expandDescription}
        onClick={handleExpandClick}
        aria-expanded={expandDescription}
        aria-label="show more"
      >
        <ExpandMoreIcon />
      </ExpandMore>
    </div>
  );
}

WidgetFooter.defaultProps = {
  widgetProps: { name: "", config: { tags: "#TNS #WNS" } },
};

export default WidgetFooter;
