import React, { useRef, useState, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import AppBar from "@mui/material/AppBar";
import Typography from "@mui/material/Typography";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Slide from "@mui/material/Slide";
import FullscreenIcon from "@mui/icons-material/Fullscreen";
import { styled } from "@mui/system";
import CachedIcon from "@mui/icons-material/Cached";
import SettingsIcon from "@mui/icons-material/Settings";
import Tooltip from "@mui/material/Tooltip";
import _ from "lodash";

const RotateIconButton = styled(IconButton)({
  padding: "0px 3px",
  color: "inherit",
  transition: "transform 0.7s ease-in-out",
  "&:hover": { transform: "rotate(360deg)" },
});

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function FullScreenDialog(props) {
  const ref = useRef(null);

  const [fullScreenMonitor, setFullScreenMonitor] = useState(false);

  React.useEffect(() => {
    function onFullscreenChange() {
      setFullScreenMonitor(Boolean(document.fullscreenElement));
    }

    document.addEventListener("fullscreenchange", onFullscreenChange);

    return () =>
      document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);

  const handleClose = () => {
    props.handleFullScreen(false);
  };

  const handleFullMonitorScreen = () => {
    setFullScreenMonitor(!fullScreenMonitor);
    const elem = ref.current;

    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.webkitRequestFullscreen) {
      /* Safari */
      elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) {
      /* IE11 */
      elem.msRequestFullscreen();
    }
  };

  return (
    <div>
      <Dialog
        fullScreen
        open={props.isFullScreen}
        onClose={handleClose}
        TransitionComponent={Transition}
      >
        <AppBar sx={{ position: "relative", backgroundColor: "#5a2a82" }}>
          <Toolbar sx={{ backgroundColor: "#5a2a82" }}>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <CloseIcon color="inherit" />
            </IconButton>
            <Typography
              sx={{ ml: 2, flex: 1, fontWeight: "bold" }}
              variant="h6"
              component="div"
            >
              {props.title}
            </Typography>
            <Tooltip title="Refresh">
              <RotateIconButton
                aria-label="refresh"
                id="long-button2"
                aria-haspopup="true"
                sx={{ padding: "0px 3px", fontSize: "2px" }}
                onClick={() => props.refreshWidget("Refresh")}
              >
                <CachedIcon color="inherit" fontSize={"small"} />
              </RotateIconButton>
            </Tooltip>
            <Tooltip title="Full Screen">
              <IconButton
                edge="start"
                color="inherit"
                onClick={handleFullMonitorScreen}
                aria-label="full screen"
                sx={{ marginLeft: "3px" }}
              >
                <FullscreenIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Settings">
              <RotateIconButton
                aria-label="more"
                id="long-button4"
                aria-haspopup="true"
                // sx={{ padding: "0px 3px" }}
                onClick={() =>
                  props.updateUiState({
                    isLoading: false,
                    showConfig: !_.get(props.uiState, "showConfig", false),
                    isToastOpen: false,
                    toastSeverity: "info",
                    toastMessage: "",
                    cirlularLoading: false,
                  })
                }
              >
                <SettingsIcon fontSize={"small"} />
              </RotateIconButton>
            </Tooltip>
          </Toolbar>
        </AppBar>

        <div
          ref={ref}
          style={{
            width: "100%",
            height: "calc(100% - 64px)",
            // display: fullScreenMonitor ? "inherit" : "none",
            backgroundColor: "white",
            justifyContent: "center",
          }}
        >
          {props.childComponent}
          {/* {fullScreenMonitor ? props.childComponent : null} */}
        </div>
        {/* {fullScreenMonitor ? null : props.childComponent} */}
      </Dialog>
    </div>
  );
}

FullScreenDialog.defaultProps = {
  childComponent: null,
  title: "",
  isFullScreen: false,
};
