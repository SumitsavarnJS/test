import React from "react";
import ListView2 from "./views/ListView2";
import * as dashboardStyles from "./Dashboard.module.css";

import TabbedRpt from "./views/TabbedRpt";
// Material UI

import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";

class Dashboard extends React.Component {
  state = {
    rptView: "tab",
    rest_server_url: "",
    rest_server_url1: "",
    rptName: "a2",
  };

  loadConfig = async () => {
    const response = await fetch("/v1/config.json");
    const data = await response.json();
    this.setState(data);
    //dispatch(setConfig(data));
  };

  componentDidMount() {}

  getView = () => {
    if (useGlobalStore.getState().analyticsReportView.view === "list") {
      return <ListView2 />;
    } else if (useGlobalStore.getState().analyticsReportView.view === "tab") {
      return <TabbedRpt />;
    }
  };

  render() {
    {
      return (
        <div
          id="dashboard"
          className={dashboardStyles.dashboard}
          style={{
            backgroundColor:
              useConfigStore.getState().theme == "dark"
                ? "rgb(30,30,30)"
                : "white",
            color:
              useConfigStore.getState().theme == "dark" ? "white" : "black",
              marginTop:'10px'
          }}
        >
          {this.getView()}
        </div>
      );
    }
  }
}

export default Dashboard;
