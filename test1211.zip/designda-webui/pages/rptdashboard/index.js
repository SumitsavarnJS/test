import React, { useState, useRef, useEffect } from "react";
// import Dashboard from "./Dashboard";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import { useRouter } from "next/router";
import {
  Box,
  Drawer,
  Toolbar,
  Typography,
  IconButton,
  Tooltip,
  Badge,
} from "@mui/material";
import Divider from "@mui/material/Divider";
import { shallow } from "zustand/shallow";
// import ModalComponent from "../../components/ModalComponent/ModalComponent";
import getConfig from "next/config";
import Dialog from "@mui/material/Dialog";
import AppBar from "@mui/material/AppBar";
import CloseIcon from "@mui/icons-material/Close";
import CloseFullscreenRoundedIcon from '@mui/icons-material/CloseFullscreenRounded';
import OpenInFullRoundedIcon from '@mui/icons-material/OpenInFullRounded';
import Slide from "@mui/material/Slide";
// import WidgetLibManager from "../../components/wgt_library_manager/wgtLibManager";
// import EventLibManager from "../../components/event_library_manager/eventLibManager";
import DataSearch from "../../pages/datasearch";
import api from "../../common/api/api";
import * as analyticsStyles from "./Dashboard.module.css";
import _ from "lodash";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const { publicRuntimeConfig } = getConfig();
const imageUrl = publicRuntimeConfig.basePath;
export default function Component1() {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const [toggleApi, setToggleApi] = useState(false);
  const [parameter, setParameter] = useState("");
  const [formattedValue, setFormattedValue] = useState("");
  const [widgetLib, setWidgetLib] = useState({ open: false });
  const [eventLib, setEventLib] = useState({ open: false });

  const [resizableWidth, setResizableWidth] = useState("40rem");
  const queryFromDataSearch = router?.query?.queryParams
  const queryChange = router?.query?.keyProp

  const { analyticsReportView, setRootLevelData, analyticsRightPane, dataSearchVisibility } =
    useGlobalStore(
      (state) => ({
        analyticsReportView: state.analyticsReportView,
        setRootLevelData: state.setRootLevelData,
        analyticsRightPane: state.analyticsRightPane,
        dataSearchVisibility: state.dataSearchVisibility,


      }),
      shallow
    );

  const { configData, authLoginUser } = useConfigStore(
    (state) => ({
      configData: state.configData,
      authLoginUser: state.authLoginUser,
    }),
    shallow
  );

  const setRightPaneCount = async () => {
    const SavedReportsResponse = await api(
      configData.rest_server_url + "/api/get_gui_reports_tags",
      {
        user: authLoginUser,
      }
    );
    if (
      SavedReportsResponse &&
      SavedReportsResponse.hasOwnProperty("gui_reports")
    ) {
      const favResponse = await api(
        `${configData.rest_server_url}/api/fetch_recent_docs`,
        {
          user: authLoginUser,
          data_card: true,
        }
      );
      if (favResponse && favResponse.status) {
        const rightPane = _.cloneDeep(analyticsRightPane);
        rightPane.savedRptCount = SavedReportsResponse.gui_reports.length;
        rightPane.favouriteRptCount = favResponse.data.length;
        setRootLevelData("analyticsRightPane", rightPane);
      }
    }
  };

  useEffect(() => {
    setRightPaneCount();
  }, []);

  useEffect(() => {
    setRootLevelData("dataSearchVisibility", true);

  }, [router.query.keyProp]);


  const toggleDataSearchComponent = () => {
    setRootLevelData("dataSearchVisibility", !dataSearchVisibility);
  };


  const handleWgtLibrary = () => {
    setWidgetLib({ open: true });
  };

  const handleCloseWidgetLib = () => {
    setWidgetLib({ open: false });
  };

  const OpenEventLibrary = () => {
    setEventLib({ open: true });
  };

  const CloseEventLib = () => {
    setEventLib({ open: false });
  };

  const handleModalClick = (param) => {
    setIsOpen(true);
    if (param) {
      setToggleApi((prevState) => !prevState);
      setParameter(param);
      if (param === "Profile") {
        setAnchorEl(null);
      }
    } else {
      setParameter(param);
    }
  };
  const drawerWidth = "65px";

  const changeView = () => {
    const view = analyticsReportView.view;
    const allReports = useGlobalStore.getState().allReports;
    const reports = _.cloneDeep(allReports);

    //open a report in Tabbed view on change of Views
    const currentReport =
      reports && Object.keys(reports).length > 0 ? Object.keys(reports)[0] : "";
    if (view == "tab") {
      setRootLevelData("analyticsReportView", {
        view: "list",
        currentTab: "",
      });
    } else if (view == "list") {
      setRootLevelData("analyticsReportView", {
        view: "tab",
        currentTab: currentReport,
      });
    }
  };

  const resizePanel = (panelExpandedBool) => {
    setResizableWidth(panelExpandedBool ? "40rem" : "22rem");
  };
  return (
    <div style={{ margin: "0px 64px", padding: queryFromDataSearch ? 0 : 20, scrollBehavior: "smooth" }}>
      {/* {console.log(
        "calling dashboard from index.js/rptdashboard",
        queryFromDataSearch, queryChange
      )} */}
      {/* changes for accordion view */}
      {/* if rendered through data-search, switch to new layout else older layout */}
      <Tooltip placement={"top-end"} title="Toggle Between Full Screen & Data Search View">

        <IconButton
          color="inherit"
          aria-label={dataSearchVisibility ? 'collapse' : 'expand'}
          onClick={toggleDataSearchComponent}
          sx={{
            position: 'fixed',
            zIndex: 999,
            top: '50%',
            left: '56px', // Position the icon to the top-left when drawer is open
            transition: 'transform 0.3s',
            marginRight: (1),
            marginLeft: 1,
            marginBottom: 1,
            fontSize: '1rem',
            borderRadius: '20%', // Make it round
            backgroundColor: '#e7d9f3', // Fill color
            padding: 1,
            '&:hover': { backgroundColor: '#5b2c84', color: '#ffffff' },
            opacity: 0.9
          }}
        >
          {dataSearchVisibility ? <CloseFullscreenRoundedIcon sx={{ left: '91px' }} /> : <OpenInFullRoundedIcon />}
        </IconButton>
      </Tooltip>
      {dataSearchVisibility ? <>
        {queryFromDataSearch ? (
          <>
            <h4 className={analyticsStyles.ml10}>Data Search Results</h4>
            <div className={analyticsStyles.layoutParent}>
              <div
                className={analyticsStyles.resizableContainer}
                style={{ width: resizableWidth }}
              >
                <DataSearch
                  searchString={queryFromDataSearch}
                  resizePanel={resizePanel}
                  keyProp={queryChange}
                />
              </div>
              {/* <div className={analyticsStyles.reportContainer}>
                <Dashboard />
              </div> */}
            </div>
          </>
        ) : (
          // this is how older layout was rendered
        <>  </>
        )}
      </> : <div className={analyticsStyles.reportContainer}>   </div>}

      <Box sx={{ display: "flex" }}>
        <Drawer
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            "& .MuiDrawer-paper": {
              width: drawerWidth,
              boxSizing: "border-box",
              backgroundColor: "#E7D9F3",
              top: "65px",
              height: "100%",
            },
          }}
          variant="permanent"
          anchor="right"
        >
          <Divider />

          {/* <ListItemIcon> */}

          <Tooltip placement="left" title="Add a new Report">
            <IconButton
              onClick={() => handleModalClick("Newrpt")}
              sx={{
                "&:hover": {
                  backgroundColor: "transparent",
                },
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                p: "2px 0px",
              }}
            >
              {/* <AddIcon
                  sx={{
                    fontSize: "1.5rem",
                  }}
                />  */}
              <img
                width="30px"
                // src={`${imageUrl}/IC_New_AddReports_7.svg`}
                alt="Add Report"
              />
              <Typography fontSize={10}>New Report</Typography>
            </IconButton>
          </Tooltip>

          {/* </ListItemIcon> */}

          <Divider />
          {/* <ListItemIcon> */}

          <Tooltip placement="left" title="Open a Saved Report">
            <IconButton
              sx={{
                "&:hover": {
                  backgroundColor: "transparent",
                },
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                p: "2px 0px",
              }}
              onClick={() => handleModalClick("Sav")}
            >
              {/* <BookmarkBorderIcon />  */}

              <Badge
                badgeContent={_.get(analyticsRightPane, "savedRptCount", 0)}
                sx={{
                  "& .MuiBadge-badge": {
                    fontSize: "10px",
                    height: "auto",
                    padding: "2px 0px",
                    backgroundColor: "yellowgreen",
                  },
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_SavedReports_Files_7.svg`}
                  alt="Saved Reports"
                />
              </Badge>
              <Typography fontSize={10}>Saved Report</Typography>
            </IconButton>
          </Tooltip>
          <Divider />

          <Tooltip
            placement="left"
            title="Collection of pre configured widgets"
          >
            <IconButton
              onClick={handleWgtLibrary}
              sx={{
                "&:hover": {
                  backgroundColor: "transparent",
                },
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                p: "2px 0px",
              }}
            >
              {/* <LocalLibraryIcon
                  sx={{
                    fontSize: "1.5rem",
                  }}
                /> */}
              <img
                width="30px"
                // src={`${imageUrl}/IC_Widget_Library_7.svg`}
                alt="Widget Library"
              />
              <Typography fontSize={10}>Widget Library</Typography>
            </IconButton>
          </Tooltip>
          <Divider />
          <Tooltip placement="left" title="Event Library">
            <IconButton
              onClick={OpenEventLibrary}
              sx={{
                "&:hover": {
                  backgroundColor: "transparent",
                },
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                p: "2px 0px",
              }}
            >
              <img
                width="30px"
                // src={`${imageUrl}/event_library/eventlibrary.svg`}
                alt="Event Library"
              />
              <Typography fontSize={10}>Event Library</Typography>
            </IconButton>
          </Tooltip>
          <Divider />

          <Tooltip placement="left" title="Open a favorite report">
            <IconButton
              sx={{
                "&:hover": {
                  backgroundColor: "transparent",
                },
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                p: "2px 0px",
              }}
              onClick={() => handleModalClick("Fav")}
            >
              {/* <FavoriteBorderIcon />  */}
              <Badge
                badgeContent={_.get(analyticsRightPane, "favouriteRptCount", 0)}
                sx={{
                  "& .MuiBadge-badge": {
                    fontSize: "10px",
                    height: "auto",
                    padding: "2px 0px",
                    backgroundColor: "yellowgreen",
                  },
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_Favourite_Reports_7.svg`}
                  alt="Pinned"
                />
              </Badge>
              <Typography fontSize={10}>Favorite</Typography>
            </IconButton>
          </Tooltip>

          {/* </ListItemIcon> */}
          <Divider />
          {/* <ListItemIcon> */}

          <Tooltip placement="left" title="Open a Recent">
            <IconButton
              sx={{
                "&:hover": {
                  backgroundColor: "transparent",
                },
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                p: "2px 0px",
              }}
              onClick={() => handleModalClick("Rec")}
            >
              {/* <HistoryIcon />  */}
              <img
                width="30px"
                // src={`${imageUrl}/IC_Recent_Reports_7.svg`}
                alt="Recent"
              />
              <Typography fontSize={10}>Recent</Typography>
            </IconButton>
          </Tooltip>

          {/* </ListItemIcon> */}
          <Divider />
          {/* <ListItemIcon> */}

          <Tooltip
            placement={"left"}
            title={
              "Switch the view of reports to see all reports at once or one report at at time"
            }
          >
            <IconButton
              onClick={changeView}
              sx={{
                "&:hover": {
                  backgroundColor: "transparent",
                },
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                p: "2px 0px",
              }}
            >
              {analyticsReportView.view == "tab" ? (
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_ChangeView_7.svg`}
                  alt="View 1"
                />
              ) : (
                <img
                  width="30px"
                  // src={`${imageUrl}/ChangeViewHover2.svg`}
                  alt="View 2"
                />
              )}
              <Typography fontSize={10}>Switch View</Typography>
            </IconButton>
          </Tooltip>

          {/* </ListItemIcon> */}
        </Drawer>
      </Box>
      {/* drawer of report-widget-library */}

      {
        widgetLib.open ?
          <Drawer
            open={widgetLib.open}
            variant="persistent"
            anchor="right"
            sx={{
              width: 780,
              flexShrink: 0,
              "& .MuiDrawer-paper": {
                width: 780,
                boxSizing: "border-box",
              },
            }}
          >
            <AppBar sx={{ position: "relative", backgroundColor: "#5a2a82" }}>
              <Toolbar>
                <IconButton
                  edge="start"
                  color="inherit"
                  onClick={handleCloseWidgetLib}
                  aria-label="close"
                >
                  <ChevronRightIcon color="inherit" />
                </IconButton>
                <Typography sx={{ flexGrow: 1 }}>Widget Library</Typography>
              </Toolbar>
            </AppBar>
            <Box>
              {/* <WidgetLibManager parent="analytics" /> */}
            </Box>
          </Drawer>
          :
          null
      }

      <Dialog
        fullScreen
        open={eventLib.open}
        onClose={CloseEventLib}
        TransitionComponent={Transition}
      >
        <AppBar sx={{ position: "relative", backgroundColor: "#5a2a82" }}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={CloseEventLib}
              aria-label="close"
            >
              <CloseIcon color="inherit" />
            </IconButton>
            <Typography sx={{ flexGrow: 1 }}>Event Library</Typography>
          </Toolbar>
        </AppBar>
        <Box>
          {/* <EventLibManager parent="analytics" /> */}
        </Box>
      </Dialog>
      <>
        <div>
          {/* <ModalComponent
            isOpen={isOpen}
            onClose={() => setIsOpen(false)}
            param={parameter}
            toggleApi={toggleApi}
            searchString={formattedValue}
          /> */}
        </div>
      </>
    </div>
  );
}
