/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/jsx-props-no-spreading */
import React, { useState } from "react";
import styled from "@xstyled/styled-components";
import { Droppable, Draggable } from "react-beautiful-dnd";
// import QuoteItem from "./item";
import { grid } from "../../../../../constants/constants";
import useConfigStore from "../../../../../store/useConfigStore";

import WidgetError from "../../../../../components/widgetError/widgetError";

import { shallow } from "zustand/shallow";

//widget import

export const getBackgroundColor = (isDraggingOver, isDraggingFrom) => {
  if (isDraggingOver) {
    return "#FFEBE6";
  }
  if (isDraggingFrom) {
    return "#E6FCFF";
  }
  return "";
};

const Wrapper = styled.div`
  background-color: ${(props) =>
    getBackgroundColor(props.isDraggingOver, props.isDraggingFrom)};
  display: flex;
  flex-direction: column;
  opacity: ${({ isDropDisabled }) => (isDropDisabled ? 0.5 : "inherit")};
  padding: ${grid}px;
  border: ${grid}px;
  width: auto;
  padding-bottom: 0;
  user-select: none;
  width: auto;
`;

const scrollContainerHeight = 2500;

const DropZone = styled.div`
  /* stop the list collapsing when empty */
  height: auto;
  width: auto;
  /*
    not relying on the items for a margin-bottom
    as it will collapse when the list is empty
  */
  padding-bottom: ${grid}px;
`;

const ScrollContainer = styled.div`
  overflow-x: hidden;
  overflow-y: auto;
  height: auto;
`;

/* stylelint-disable block-no-empty */
const Container = styled.div``;
/* stylelint-enable */

const getItemStyle = (isDragging, draggableStyle) => ({
  // some basic styles to make the items look a bit nicer
  userSelect: "none",
  borderRadius: "15px",
  padding: "10px 10px",
  margin: `2px ${8}px 0 0`,
  // resize: "horizontal",
  // overflow: "auto",
  height: "auto",
  // change background colour if dragging
  background:
    useConfigStore.getState().theme == "dark" ? "rgb(18,18,18)" : "white",

  // styles we need to apply on draggables
  ...draggableStyle,
});

function WidgetList(props) {
  return props && props.report
    ? Object.keys(props.report.widgets).map((widget, index) => (
        <Draggable
          key={widget}
          draggableId={widget}
          index={index}
          disableInteractiveElementBlocking={false}
        >
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.draggableProps}
              style={getItemStyle(
                snapshot.isDragging,
                provided.draggableProps.style
              )}
            >
              <WidgetError
                widgetProps={props.report.widgets[widget]}
                id={widget}
                handleProps={provided.dragHandleProps}
                index={index}
                reportKey={props.reportKey}
                report={props.report.title}
                deleteWidget={props.deleteWidget}
                endPointUrl={props.endPointUrl}
              />
            </div>
          )}
        </Draggable>
      ))
    : null;
}

function ReportList(props) {
  const { reports, dropProvided, reportKey, endPointUrl } = props;
  return (
    <Container>
      <DropZone ref={dropProvided.innerRef}>
        <WidgetList
          report={reports}
          reportKey={reportKey}
          deleteWidget={props.deleteWidget}
          endPointUrl={endPointUrl}
        />
        {dropProvided.placeholder}
      </DropZone>
    </Container>
  );
}

export default function ReportPane(props) {
  const {
    ignoreContainerClipping,
    internalScroll,
    scrollContainerStyle,
    isDropDisabled,
    isCombineEnabled,
    listId = "LIST",
    listType,
    style,
    reports,
    title,
    useClone,
    endPointUrl,
  } = props;

  return reports ? (
    <Droppable
      droppableId={listId}
      type={listType}
      ignoreContainerClipping={ignoreContainerClipping}
      isDropDisabled={isDropDisabled}
      // mode="virtual"
      isCombineEnabled={isCombineEnabled}
      renderClone={
        useClone
          ? (provided, snapshot, descriptor) => (
              <div provided={provided} isDragging={snapshot.isDragging}>
                ABC
              </div>
            )
          : null
      }
    >
      {(dropProvided, dropSnapshot) => (
        <Wrapper
          style={style}
          isDraggingOver={dropSnapshot.isDraggingOver}
          isDropDisabled={isDropDisabled}
          isDraggingFrom={Boolean(dropSnapshot.draggingFromThisWith)}
          {...dropProvided.droppableProps}
        >
          {internalScroll ? (
            <ScrollContainer style={scrollContainerStyle}>
              <ReportList
                reports={reports}
                title={title}
                reportKey={listId}
                dropProvided={dropProvided}
                deleteWidget={props.deleteWidget}
                endPointUrl={endPointUrl}
              />
            </ScrollContainer>
          ) : (
            <ReportList
              reports={reports}
              title={title}
              reportKey={listId}
              dropProvided={dropProvided}
              deleteWidget={props.deleteWidget}
              endPointUrl={endPointUrl}
            />
          )}
        </Wrapper>
      )}
    </Droppable>
  ) : null;
}
