import React, { useState, useEffect } from "react";
import { styled, alpha } from "@mui/material/styles";
import styles from "../../../../search/search.module.css";

import {
  Dialog,
  DialogTitle,
  DialogContent,
  Select,
  Button,
  MenuItem,
  FormControl,
  Box,
  InputLabel,
} from "@mui/material";
import Modal from "@mui/material/Modal";

import useConfigStore from "../../../../../store/useConfigStore";

import axios from "axios";

function MyModal({
  isOpen,
  onClose,
  onSubmit,
  selectedItem,
  mainComponentData,
  onSelectedItemChange,
}) {
  const [data, setData] = useState([]);

  const style = {
    position: "absolute",

    top: "50%",

    left: "50%",

    transform: "translate(-50%, -50%)",

    width: "50%",

    height: "70%",

    bgcolor: "white",

    border: "2px solid #000",

    boxShadow: 24,

    p: 4,

    backgroundColor: "white",

    overflow: "auto",
  };

  useEffect(() => {
    // Fetch data from your API when the modal opens

    if (isOpen) {
      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/user_manager/getUsersAndProjects",
          {
            usersFlag: true,
            projectsFlag: false,
          }
        )
        .then((response) => {
          response = response.data;
          if (response.status) {
            let allProjectUsers = Object.keys(response.userDataObj).sort();
            setData(allProjectUsers);
          } else {
            // Show Failure toast message
            // this.setToastMessage({
            //   message: "Failed to save analytics report",
            //   success: false,
            // });
            console.log("Failed to save analytics report");
          }
        })
        .catch((error) => {
          // show network error message
          // Show Failure toast message
          // this.setToastMessage({
          //   message: "Failed to reach Server",
          //   success: false,
          console.log("Failed to reach Server");
          // });
        });
    }
  }, [isOpen]);

  const handleSelectChange = (event) => {
    onSelectedItemChange(event.target.value);
  };

  const handleButtonClick = () => {
    // Make a POST request with the selected value and mainComponentData

    onSubmit(selectedItem);
    onClose();
  };

  return (
    <>
      <Modal
        open={isOpen}
        onClose={onClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          {/* <DialogContent> */}

          {/* <Select

          value={selectedItem}

          onChange={handleSelectChange}

          label="Select an option"

        >

          {data.map(item => (

              <MenuItem key={item} value={item}>
              {item}
            </MenuItem>
            

          ))}

        </Select> */}

          <>
            <InputLabel>Select Username</InputLabel>
            <Select
              value={selectedItem}
              onChange={handleSelectChange}
              //   sx={{width:1000}}
              fullWidth
              // placeholder="Select Project"
              MenuProps={{
                PaperProps: {
                  style: {
                    maxHeight: 300,
                  },
                },
              }}
            >
              {data.map((item) => (
                <MenuItem sx={{ overflow: "auto" }} key={item} value={item}>
                  {item}
                </MenuItem>
              ))}
            </Select>
          </>
          <>
            <Button
              onClick={handleButtonClick}
              variant="contained"
              color="primary"
            >
              Share
            </Button>
          </>

          {/* </DialogContent> */}
        </Box>
      </Modal>
    </>
  );
}

export default MyModal;
