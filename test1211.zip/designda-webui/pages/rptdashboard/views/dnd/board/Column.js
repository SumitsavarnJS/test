/* eslint-disable react/no-unknown-property */

import React, { useState } from "react";
import styled from "@xstyled/styled-components";
import { borderRadius } from "../../../../../constants/constants";
import { Draggable } from "react-beautiful-dnd";
import ReportPane from "../styles/list";
import ReportGrid from "../../../../../components/report_grid_view/reportGrid";

import AssessmentOutlinedIcon from "@mui/icons-material/AssessmentOutlined";
import MoreHorizOutlinedIcon from "@mui/icons-material/MoreHorizOutlined";
import * as columnStyles from "./Column.module.css";
import axios from "axios";
import Tooltip from "@mui/material/Tooltip";
import ShareReportModal from "./ShareReportModal";
import EditReportModal from "./EditReportModal";
import IconButton from "@mui/material/IconButton";
import { Lock, LockOpen } from "@mui/icons-material";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import Typography from "@mui/material/Typography";
import refreshWidgetContent from "./../../../wigetWrapper/widgetRefreshData";
import { shallow } from "zustand/shallow";
import useGlobalStore from "../../../../../store/useGlobalStore";
import useConfigStore from "../../../../../store/useConfigStore";
import AddWidgets, { addWidgetsToReport } from "../../../addWidget/addWidget";
import { toast } from "react-toastify";
import api from "../../../../../common/api/api";
import * as utils from "../../../../../common/utils/utils";
import _ from "lodash";
import { nanoid } from "nanoid";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import ReportGlobalVariables from "../../../../../components/variables/ReportGlobalVariables";
import ExportToHTMLModal from "../../../../../components/ModalComponent/ExportToHTMLModal";

import {
  Box,
  Button,
  Autocomplete,
  TextField,
  ClickAwayListener,
  Modal,
} from "@mui/material";
import styles from "../../../../Dashboards/Dashboard.module.css";
import DataSource from "../../../../../pages/rptdashboard/data_source/DataSource";
// import MoreVertIcon from "@mui/icons-material/MoreVert";
import DeleteComponent from "../../../../../components/DeleteDashboardModal/DeleteComponent";
import clipboardCopy from "clipboard-copy";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import AddIcon from "@mui/icons-material/Add";
import { inputLabelClasses } from "@mui/material/InputLabel";
import { styled as styling } from "@mui/material/styles";

const StyledTextField = styling(TextField)`
  & .MuiInputBase-root {
    font-size: 0.8rem; 
  }
`;

const Container = styled.div`
  display: flex;
  flex-direction: column;
  background-color: ${useConfigStore.getState().theme == "dark"
    ? "rgb(25,25,25)"
    : "#fff"};
  border-radius: 15px;
  height: fit-content;
  width: ${(props) => props.reportWidth}%;
  transition: width 2s ease;
`;
const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  border-top-left-radius: ${borderRadius}px;
  border-top-right-radius: ${borderRadius}px;
  // background-color: ${({ isDragging }) => (isDragging ? "#7F8DE1" : "")};
  // &:hover {
  //   background-color: "#00AEA9";
  // }
`;
function ReportMenu(props) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [value, setValue] = useState(0);
  const [tempConfig, setTempConfig] = useState([]);
  const [widgetForm, setWidgetForm] = useState([]);
  const [scenariosSelect, setScenariosSelect] = useState("");
  const [isPrefModalOpen, setIsPrefModalOpen] = useState(false);

  const [propbucket, setbucket] = useState("");
  const [showDataSource, setShowDataSource] = useState(false);
  const open = Boolean(anchorEl);
  const [openAddWidget, setOpenAddWidget] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState("");
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editSelectedItem, setEditSelectedItem] = useState("");
  const [openDeleteModal, setOpenDeleteModal] = useState(false);
  const commonString = useConfigStore.getState().commonString;
  const [openExportModal, setOpenExportModal] = useState(false);

  // Modal State handler
  const modalStateHandler = (modalState) => setOpenDeleteModal(modalState);
  const mainComponentData = {};
  const editmainComponentData = {};
  const handleCloseModal = () => {
    setIsModalOpen(false);
  };
  const handleEditCloseModal = () => {
    setIsEditModalOpen(false);
  };
  const handleDataLocationChange = (newDataLocation, bucket) => {
    dataLocationChanged(utils.getRootDirectory(newDataLocation), bucket);
  };

  const dataLocationChanged = async (rootDataLocation, bucket) => {
    const scenarioList = await getScenarioList(bucket, rootDataLocation);
    let scenarioErrorFlag = false;
    let scenarioHelperText = "";
    let newDataLocation = rootDataLocation;
    //if scneario exists but not present in current location
    if (!scenarioList?.includes(widgetForm) && widgetForm) {
      /* eslint-disable-next-line no-unused-vars  */
      scenarioErrorFlag = true;
      /* eslint-disable-next-line no-unused-vars  */
      scenarioHelperText = "Invalid scenario for the selected Data Source";
    } else if (widgetForm) {
      //if scenario exists and present in current root level
      newDataLocation = rootDataLocation + "/" + widgetForm;
    }
    //if only root level data is present but not scenario
    else {
      /* eslint-disable-next-line no-unused-vars  */
      newDataLocation = rootDataLocation;
    }
  };

  const getScenarioList = async (bucket, dataLocation) => {
    setTempConfig(utils.getRootDirectory(dataLocation));
    setbucket(bucket);
    const response = await api(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/fetch_report_attributes",
      {
        bucket: bucket,
        key: utils.getRootDirectory(dataLocation),
      }
    );
    if (response.status) {
      const data = _.get(response, "data", {});
      if (data.scenarios && data.scenarios.length) {
        // return data.scenarios;
        setWidgetForm(data.scenarios);
      } else {
        setWidgetForm([]);
        setScenariosSelect("");
        return [];
      }
    } else {
      console.log("sceanrio not found for " + bucket + dataLocation);
      return [];
    }
  };
  const handleScenarioChange = (scenario) => {
    if (scenario) {
      setScenariosSelect(scenario);
      setTempConfig(utils.getRootDirectory(tempConfig) + "/" + scenario);
    } else {
      setTempConfig(tempConfig);
    }
  };
  // const scenarioChanged = async (scenarioDataSource, bucket) => {
  //   const newConfig = {
  //     ...tempConfig,
  //     dataLocation: scenarioDataSource,
  //     scenario: utils.getScenarioFromDataLoc(scenarioDataSource),
  //     scenarioErrorFlag: false,
  //     scenarioHelperText: "",
  //   };
  // }

  const handleTemplateEditModalSubmit = (selectedValue) => {
    // check if report already exists if location is being changed
    const reportInfo = _.cloneDeep(allReports[props.report]);
    reportInfo["title"] = selectedValue;
    reportInfo["theme"] = allReports[props.report].theme;
    reportInfo["fileName"] = selectedValue;

    for (const widgetName in reportInfo.widgets) {
      if ("data" in reportInfo.widgets[widgetName]) {
        delete reportInfo.widgets[widgetName].data;
      }
    }
    delete reportInfo.widgetsOrder;

    const widgetsOrder = Object.keys(reportInfo.widgets);
    const widgets = {};

    for (let i = 0; i < widgetsOrder.length; i++) {
      widgets[widgetsOrder[i]] = _.cloneDeep(
        reportInfo.widgets[widgetsOrder[i]]
      );
      widgets[widgetsOrder[i]]["y"] = i;
    }
    reportInfo["widgets"] = widgets;
    reportInfo["widgetsOrder"] = widgetsOrder;

    let newData = {
      fileName: reportInfo.fileName,
      theme: "light",
      title: reportInfo.fileName,
      widgets: widgets,
      widgetsOrder: widgetsOrder,
    };

    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/update_gui_report",
        {
          file_name: allReports[props.report].title,
          data: newData,
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          props.closeReport(props.report);
          let rpt = reportInfo.fileName;
          let rptData = reportInfo;
          const tempregex = /(template|templates)/i;
          if (tempregex.test(rpt) && rptData.widgetsOrder) {
            const widgetsOrder = Object.keys(rptData.widgets);
            //clone rpt data to set new order
            let rptDataClone = _.cloneDeep(rptData);
            delete rptDataClone.widgets;
            rptDataClone["widgets"] = {};
            //add widgets according to the new order given
            for (let index = 0; index < widgetsOrder.length; index++) {
              rptDataClone["widgets"][widgetsOrder[index]] =
                rptData["widgets"][widgetsOrder[index]];
            }
            // set the new ordered data report
            rptData = rptDataClone;
          }
          useGlobalStore.getState().updateGlobalObject(rpt, rptData);
          if (Object.hasOwn(rptData, "widgets")) {
            for (const Wkey in rptData.widgets) {
              let WkeyObj = {
                data: {},
                uiState: {
                  isLoading: false,
                  showConfig: false,
                  isToastOpen: false,
                  toastSeverity: "info",
                  toastMessage: "",
                  cirlularLoading: false,
                },
              };
              useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
            }
          }
          toast.info(response.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        }
      })
      .catch((error) => {
        toast.error(error, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "#fff" },
        });
      });
  };
  const handleEditModalSubmit = (selectedValue) => {
    // check if report already exists if location is being changed

    const regex = /(template|templates)/i;
    if (regex.test(selectedValue)) {
      handleTemplateEditModalSubmit(selectedValue);
    } else {
      const reportInfo = _.cloneDeep(allReports[props.report]);
      reportInfo["title"] = selectedValue;
      reportInfo["theme"] = allReports[props.report].theme;
      reportInfo["fileName"] = selectedValue;
      // save edited report in s3
      // remove data from all widgets
      for (const widgetName in reportInfo.widgets) {
        if ("data" in reportInfo.widgets[widgetName]) {
          delete reportInfo.widgets[widgetName].data;
        }
      }

      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/update_gui_report",
          {
            file_name: allReports[props.report].title,
            data: reportInfo,
            user: useConfigStore.getState().authLoginUser,
          }
        )
        .then((response) => {
          response = response.data;
          if (response.success) {
            props.closeReport(props.report);
            let rpt = reportInfo.fileName;
            let rptData = reportInfo;

            const tempregex = /(template|templates)/i;
            if (tempregex.test(rpt) && rptData.widgetsOrder) {
              const widgetsOrder = rptData.widgetsOrder;
              let rptDataClone = _.cloneDeep(rptData);
              delete rptDataClone.widgets;
              rptDataClone["widgets"] = {};
              //add widgets according to the new order given
              for (let index = 0; index < widgetsOrder.length; index++) {
                rptDataClone["widgets"][widgetsOrder[index]] =
                  rptData["widgets"][widgetsOrder[index]];
              }
              // set the new ordered data report
              rptData = rptDataClone;
            }
            useGlobalStore.getState().updateGlobalObject(rpt, rptData);
            if (Object.hasOwn(rptData, "widgets")) {
              for (const Wkey in rptData.widgets) {
                let WkeyObj = {
                  data: {},
                  uiState: {
                    isLoading: false,
                    showConfig: false,
                    isToastOpen: false,
                    toastSeverity: "info",
                    toastMessage: "",
                    cirlularLoading: false,
                  },
                };
                useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
              }
            }
            const widgetArray = Object.keys(rptData.widgets);
            if (!tempregex.test(rpt)) {
              for (let i = 0; i < widgetArray.length; i++) {
                const widgetId = widgetArray[i];
                const config = rptData.widgets[widgetId].config;
                const name = rptData.widgets[widgetId].name;
                const rptType = rptData.widgets[widgetId]?.rptType
                  ? rptData.widgets[widgetId]?.rptType
                  : "";
                const reportKey = rptData.widgets[widgetId]?.reportKey
                  ? rptData.widgets[widgetId]?.reportKey
                  : "";
                const rptDataVariablesCheck =
                  Object.hasOwn(rptData, "variables") && rptData?.variables
                    ? rptData.variables
                    : {};
                const widgetVariables =
                  Object.keys(rptDataVariablesCheck).length > 0
                    ? rptDataVariablesCheck
                    : {};

                refreshWidgetContent({
                  widgetId: widgetId,
                  config: config,
                  widgetName: name,
                  reportKey: reportKey,
                  rptType: rptType,
                  variables: widgetVariables ? widgetVariables : {},
                });
              }
            }
            toast.info(response.message, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: {
                fontSize: "14px",
                padding: "8px  12px",
              },
            });
          } else {
            toast.error("error", {
              position: toast.POSITION.BOTTOM_LEFT,
              style: { backgroundColor: "red", color: "#fff" },
            });
          }
        })
        .catch((error) => {
          toast.error(error, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "#fff" },
          });
        });
    }
  };
  const handleModalSubmit = (selectedValue) => {
    let shareRptFileName = allReports[props.report].fileName;
    let shareRptWidgets = allReports[props.report].widgets;
    let reportShareFrom = useConfigStore.getState().authLoginUser;
    const rptDataVariablesCheck =
      Object.hasOwn(allReports[props.report], "variables") &&
      allReports[props.report].variables
        ? allReports[props.report].variables
        : {};
    const widgetVariables =
      Object.keys(rptDataVariablesCheck).length > 0
        ? rptDataVariablesCheck
        : {};
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/share_report",
        {
          user: selectedValue,
          file_name: `${shareRptFileName} (from ${reportShareFrom})`,
          report: {
            fileName: `${shareRptFileName} (from ${reportShareFrom})`,
            theme: "light",
            dataLocation: tempConfig,
            default_scenario: scenariosSelect ? scenariosSelect : "",
            title: `${shareRptFileName} (from ${reportShareFrom})`,
            widgets: shareRptWidgets,
            variables: widgetVariables ? widgetVariables : {},
          },
        }
      )
      .then((response) => {
        console.log(response.status);
      })
      .catch((error) => {
        console.error("Error posting data:", error);
      });
  };
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const { allReports, setRootLevelData, focusedRpt, copyWidget } =
    useGlobalStore(
      (state) => ({
        allReports: state.allReports,
        setRootLevelData: state.setRootLevelData,
        focusedRpt: state.focusedRpt,
        copyWidget: state.copyWidget,
        analyticsRightPane: state.analyticsRightPane,
      }),
      shallow
    );
  const handlePropInfo = () => {
    if (allReports[props.report].dataLocation) {
      setTempConfig(allReports[props.report].dataLocation);
    } else {
      setTempConfig("");
    }
    if (allReports[props.report]?.default_scenario) {
      setScenariosSelect(allReports[props.report].default_scenario);
    }
    setIsPrefModalOpen(true);
  };
  const savePropertyInfo = () => {
    // Make a POST request with the selected value and mainComponentData
    const reportInfo = _.cloneDeep(allReports[props.report]);
    const rptDataVariablesCheck =
      Object.hasOwn(allReports[props.report], "variables") &&
      allReports[props.report].variables
        ? allReports[props.report].variables
        : {};
    const widgetVariables =
      Object.keys(rptDataVariablesCheck).length > 0
        ? rptDataVariablesCheck
        : {};
    let newData = {
      fileName: reportInfo.fileName,
      dataLocation: tempConfig,
      default_scenario: scenariosSelect ? scenariosSelect : "",
      bucket: propbucket,
      theme: "light",
      title: reportInfo.fileName,
      widgets: reportInfo.widgets,
      widgetsOrder: reportInfo?.widgetsOrder,
      variables: widgetVariables ? widgetVariables : {},
    };
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/store_gui_report_info",
        {
          data: newData,
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          updateRecents(newData);
          useGlobalStore
            .getState()
            .updateGlobalObject(reportInfo.fileName, newData);
          toast.info(`Property Added to the Report!`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        }
      })
      .catch((error) => {
        console.log(error);
      })
      .finally(() => {
        setIsPrefModalOpen(false);
      });
  };
  const handleRefresh = () => {
    const widgetArray = Object.keys(allReports[props.report].widgets);
    for (let i = 0; i < widgetArray.length; i++) {
      const widgetId = widgetArray[i];
      const config = allReports[props.report].widgets[widgetArray[i]].config;
      const name = allReports[props.report].widgets[widgetArray[i]].name;
      const rptDataVariablesCheck =
        Object.hasOwn(allReports[props.report], "variables") &&
        allReports[props.report]?.variables
          ? allReports[props.report].variables
          : {};
      const widgetVariables =
        Object.keys(rptDataVariablesCheck).length > 0
          ? rptDataVariablesCheck
          : {};
      refreshWidgetContent({
        widgetId: widgetId,
        config: config,
        widgetName: name,
        variables: widgetVariables ? widgetVariables : {},
      });
    }
  };
  const handleAddWidget = () => {
    setOpenAddWidget(!openAddWidget);
  };
  const shareReportInfo = () => {
    setIsModalOpen(true);
  };
  const editReportInfo = () => {
    setIsEditModalOpen(true);
  };

  const handlePasteWidget = (name, copy) => {
    if (name && copy) {
      addWidgetsToReport(name, copy);
    }
  };

  const handleCopyAndOpenOutlook = async (textToCopy) => {
    const regex = /(template|templates)/i;

    if (regex.test(allReports[props.report].fileName)) {
      saveReportTemplate();
    } else {
      saveReportInfo();
    }

    const stringWithUnderscores = textToCopy.replace(/[\s-]/g, "_");
    const resultString = stringWithUnderscores.toLowerCase();

    let urlPrefix = window.location.href.split("/v1")[0];
    let shareReportText = `${urlPrefix}/v1/reporturl?reportName=${
      useConfigStore.getState().authLoginUser
    }/gui_reports/${resultString}`;

    try {
      await clipboardCopy(shareReportText);
      console.log("Text copied to clipboard:", shareReportText);
    } catch (err) {
      console.error("Unable to copy text to clipboard:", err);
    }
  };

  const updateRecents = (reportInfo) => {
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/update_reports_info",
        {
          data: reportInfo,
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        console.log(response?.data);
      })
      .catch((error, response) => {
        // Handle error here, e.g. show error message
        console.error(error);
        toast.error(response.data.message, {
          position: toast.POSITION.BOTTOM_LEFT,

          style: { backgroundColor: "red", color: "#fff" },
        });
      });
  };

  const saveReportInfo = async () => {
    const reportInfo = allReports[props.report];
    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/store_gui_report_info",
        {
          data: reportInfo,
          user: `${useConfigStore.getState().authLoginUser}`,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          updateRecents(reportInfo);
          toast.info(`Reports saved successfully`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        } else {
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        console.log("Failed to reach Server", error);
      });
  };

  const saveAsReportInfo = () => {
    const regex = /(template|templates)/i;
    if (regex.test(allReports[props.report].fileName)) {
      saveDuplicateReportTemplate("(1)");
    } else {
      let title = allReports[props.report].fileName;
      const reportInfo = _.cloneDeep(allReports[props.report]);
      // remove data from all widgets and create new key
      const widgets = {};
      for (const widgetKey in reportInfo.widgets) {
        if ("data" in reportInfo.widgets[widgetKey]) {
          delete allReports.widgets[widgetKey].data;
        }
        const newWidgetKey = nanoid();
        widgets[newWidgetKey] = reportInfo.widgets[widgetKey];
        widgets[newWidgetKey].key = newWidgetKey;
      }
      // delete old widgets and put new
      reportInfo["widgets"] = widgets;
      reportInfo["title"] = title + "(1)";
      reportInfo["fileName"] = title + "(1)";
      // this.props.updateReport({ report: reportInfo });
      if (reportInfo.widgetsOrder) {
        const widgetsOrder = Object.keys(reportInfo.widgets);
        const widgets = {};
        for (let i = 0; i < widgetsOrder.length; i++) {
          widgets[widgetsOrder[i]] = _.cloneDeep(
            reportInfo.widgets[widgetsOrder[i]]
          );
          widgets[widgetsOrder[i]]["y"] = i;
        }

        let newData = {
          fileName: reportInfo.fileName,
          dataLocation: reportInfo?.dataLocation,
          default_scenario: reportInfo?.default_scenario,
          bucket: reportInfo?.bucket,
          theme: reportInfo.theme,
          title: reportInfo.fileName,
          widgets: widgets,
          widgetsOrder: widgetsOrder,
        };
        axios
          .post(
            useConfigStore.getState().configData.rest_server_url +
              "/api/store_gui_report_info",
            {
              data: newData,
              user: useConfigStore.getState().authLoginUser,
            }
          )
          .then((response) => {
            response = response.data;
            if (response.success) {
              toast.info(`Duplicate Report Created !`, {
                position: toast.POSITION.BOTTOM_LEFT,
                style: {
                  fontSize: "14px",
                  padding: "8px  12px",
                },
              });
            }
          })
          .catch((error) => {
            console.log(error);
          });
      } else {
        axios
          .post(
            useConfigStore.getState().configData.rest_server_url +
              "/api/store_gui_report_info",
            {
              data: reportInfo,
              user: useConfigStore.getState().authLoginUser,
            }
          )
          .then((response) => {
            response = response.data;
            if (response.success) {
              toast.info(`Duplicate Report Created !`, {
                position: toast.POSITION.BOTTOM_LEFT,
                style: {
                  fontSize: "14px",
                  padding: "8px  12px",
                },
              });
            }
          })
          .catch((error) => {
            console.error("Error encountered", error);
          });
        // this.handleSettingsMenuClose();
      }
    }
  };
  const saveReportTemplate = () => {
    const reportInfo = allReports[props.report];
    if (reportInfo.widgetsOrder) {
      const widgetsOrder = Object.keys(reportInfo.widgets);
      const widgets = {};
      for (let i = 0; i < widgetsOrder.length; i++) {
        widgets[widgetsOrder[i]] = _.cloneDeep(
          reportInfo.widgets[widgetsOrder[i]]
        );
        widgets[widgetsOrder[i]]["y"] = i;
      }
      let newData = {
        fileName: reportInfo.fileName,
        theme: "light",
        title: reportInfo.fileName,
        widgets: widgets,
        widgetsOrder: widgetsOrder,
      };
      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/save_template",
          {
            data: newData,
            user: `${useConfigStore.getState().authLoginUser}`,
          }
        )
        .then((response) => {
          response = response.data;
          if (response.status === true) {
            toast.info(`Template Created Successfully!`, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: {
                fontSize: "14px",
                padding: "8px  12px",
              },
            });
          } else {
            toast.error(response.message, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: { backgroundColor: "red", color: "#fff" },
            });
          }
        })
        .catch((error) => {
          console.log("Failed to reach Server", error);
        });
    } else {
      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/save_template",
          {
            data: reportInfo,
            user: `${useConfigStore.getState().authLoginUser}`,
          }
        )
        .then((response) => {
          response = response.data;
          if (response.status === true) {
            toast.info(`Success`, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: {
                fontSize: "14px",
                padding: "8px  12px",
              },
            });
          } else {
            toast.error(response.message, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: { backgroundColor: "red", color: "#fff" },
            });
          }
        })
        .catch((error) => {
          console.log("Failed to reach Server", error);
        });
    }
  };

  const saveDuplicateReportTemplate = (dupCheck) => {
    const reportInfo = _.cloneDeep(allReports[props.report]);

    let title;
    if (dupCheck) {
      title = reportInfo.fileName + dupCheck;
    } else {
      title = reportInfo.fileName;
    }

    // remove data from all widgets and create new key
    const widgets = {};
    for (const widgetKey in reportInfo.widgets) {
      if ("data" in reportInfo.widgets[widgetKey]) {
        delete allReports.widgets[widgetKey].data;
      }
      const newWidgetKey = nanoid();
      widgets[newWidgetKey] = reportInfo.widgets[widgetKey];
      widgets[newWidgetKey].key = newWidgetKey;
    }
    // delete old widgets and put new
    reportInfo["widgets"] = widgets;
    reportInfo["title"] = title;
    reportInfo["fileName"] = title;
    // this.props.updateReport({ report: reportInfo });
    if (reportInfo.widgetsOrder) {
      const widgetsOrder = Object.keys(reportInfo.widgets);
      const widgets = {};
      for (let i = 0; i < widgetsOrder.length; i++) {
        widgets[widgetsOrder[i]] = _.cloneDeep(
          reportInfo.widgets[widgetsOrder[i]]
        );
        widgets[widgetsOrder[i]]["y"] = i;
      }

      let newData = {
        fileName: reportInfo.fileName,
        dataLocation: reportInfo?.dataLocation,
        default_scenario: reportInfo?.default_scenario,
        bucket: reportInfo?.bucket,
        theme: reportInfo.theme,
        title: reportInfo.fileName,
        widgets: widgets,
        widgetsOrder: widgetsOrder,
      };
      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/save_template",
          {
            data: newData,
            user: useConfigStore.getState().authLoginUser,
          }
        )
        .then((response) => {
          response = response.data;
          if (response.success) {
            toast.info(`Duplicate Report Created !`, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: {
                fontSize: "14px",
                padding: "8px  12px",
              },
            });
          }
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      let newData = {
        fileName: title,
        theme: "light",
        title: title,
        widgets: reportInfo.widgets,
      };
      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/save_template",
          {
            data: newData,
            user: `${useConfigStore.getState().authLoginUser}`,
          }
        )
        .then((response) => {
          response = response.data;
          if (response.status === true) {
            toast.info(`Success`, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: {
                fontSize: "14px",
                padding: "8px  12px",
              },
            });
          } else {
            toast.error(response.message, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: { backgroundColor: "red", color: "#fff" },
            });
          }
        })
        .catch((error) => {
          console.log("Failed to reach Server", error);
        });
    }
  };

  const saveAsLocalCopy = () => {
    let title = allReports[props.report].fileName;
    title = title.replace("Global", "Local");
    const reportInfo = _.cloneDeep(allReports[props.report]);
    // remove data from all widgets and create new key
    const widgets = {};
    for (const widgetKey in reportInfo.widgets) {
      if ("data" in reportInfo.widgets[widgetKey]) {
        delete allReports.widgets[widgetKey].data;
      }
      const newWidgetKey = nanoid();
      widgets[newWidgetKey] = reportInfo.widgets[widgetKey];
      widgets[newWidgetKey].key = newWidgetKey;
    }
    // delete old widgets and put new
    reportInfo["widgets"] = widgets;
    reportInfo["title"] = title;
    reportInfo["fileName"] = title;
    // this.props.updateReport({ report: reportInfo });
    if (reportInfo.widgetsOrder) {
      const widgetsOrder = Object.keys(reportInfo.widgets);
      const widgets = {};
      for (let i = 0; i < widgetsOrder.length; i++) {
        widgets[widgetsOrder[i]] = _.cloneDeep(
          reportInfo.widgets[widgetsOrder[i]]
        );
        widgets[widgetsOrder[i]]["y"] = i;
      }

      let newData = {
        fileName: reportInfo.fileName,
        dataLocation: reportInfo?.dataLocation,
        default_scenario: reportInfo?.default_scenario,
        bucket: reportInfo?.bucket,
        theme: reportInfo.theme,
        title: reportInfo.fileName,
        widgets: widgets,
        widgetsOrder: widgetsOrder,
      };
      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/store_gui_report_info",
          {
            data: newData,
            user: useConfigStore.getState().authLoginUser,
          }
        )
        .then((response) => {
          response = response.data;
          if (response.success) {
            toast.info(`Local Copy Created !`, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: {
                fontSize: "14px",
                padding: "8px  12px",
              },
            });
          }
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/store_gui_report_info",
          {
            data: reportInfo,
            user: useConfigStore.getState().authLoginUser,
          }
        )
        .then((response) => {
          response = response.data;
          if (response.success) {
            toast.info(`Local Copy Created !`, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: {
                fontSize: "14px",
                padding: "8px  12px",
              },
            });
          }
        })
        .catch((error) => {
          console.log(error);
        });
      // this.handleSettingsMenuClose();
    }
  };
  // calling function

  const deleteModal = () => {
    setOpenDeleteModal(true);
  };
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box sx={{ paddingY: 1, paddingX: 2 }}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }

  CustomTabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
  };

  function a11yProps(index) {
    return {
      id: `simple-tab-${index}`,
      "aria-controls": `simple-tabpanel-${index}`,
    };
  }
  const StyledTabs = styled((props) => (
    <Tabs
      {...props}
      TabIndicatorProps={{
        children: <span className="MuiTabs-indicatorSpan" />,
      }}
    />
  ))({
    "& .MuiTabs-indicator": {
      display: "flex",
      justifyContent: "center",
      backgroundColor: "#dadada",
    },
    "& .MuiTabs-indicatorSpan": {
      width: "100%",
      backgroundColor: "#5b2c84",
    },
  });

  const StyledTab = styled((props) => <Tab disableRipple {...props} />)(() => ({
    fontSize: "0.9rem",
    color: "black",
    padding: "0px",
    marginRight: "10px",
    "&.Mui-selected": {
      color: "#5b2c84",
      fontWeight: "600",
    },
  }));

  const onExportActionClick = () => {
    // scrolling the window to the bottom of the page
    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: "smooth",
    });
    // open the dialog
    setOpenExportModal(!openExportModal);
  };

  const handleMenuClick = (option) => {
    switch (option) {
      case "Property":
        handlePropInfo();
        break;
      case "Close":
        props.closeReport(props.report);
        break;
      case "Close All":
        props.closeAllReport(props.report);
        break;
      case "Refresh":
        handleRefresh();
        break;
      case "Add Widget":
        handleAddWidget();
        break;
      case "Focus":
        setRootLevelData("focusedRpt", { rpt: props.report, width: "" });
        break;
      case "Overview":
        setRootLevelData("focusedRpt", { rpt: "", width: "" });
        break;
      case "Save":
        saveReportInfo();
        break;
      case "Duplicate":
        saveAsReportInfo();
        break;
      case "Share":
        shareReportInfo();
        break;
      case "Save Template":
        saveReportTemplate();
        break;
      case "Create Local Copy":
        saveAsLocalCopy();
        break;
      case "Rename":
        editReportInfo();
        break;
      case "Delete":
        deleteModal();
        break;

      case "Copy Link":
        handleCopyAndOpenOutlook(props.report);
        break;
      case "Paste":
        handlePasteWidget(allReports[props.report].fileName, copyWidget);

        break;
      case "Export to HTML":
        onExportActionClick();
        break;

      default:
        console.log(`${option} Operation not implemented yet`);
    }
    handleClose();
  };

  let options = [
    "Property",
    "Save",
    "Close",
    "Duplicate",
    "Refresh",
    "Add Widget",
    "Share",
    "Rename",
    "Copy Link",
    "Delete",
    "Export to HTML",
  ];
  const modifiedOptions = [
    "Save Template",
    "Property",
    "Rename",
    "Add Widget",
    "Delete",
    "Share",
    "Duplicate",
  ];

  if (Object.keys(copyWidget).length > 0) {
    options.push("Paste");
  }
  const regex = /(template|templates|global)/i;

  if (Object.keys(allReports).length > 0) {
    if (regex.test(allReports[props.report].fileName)) {
      const indexToReplace = options.indexOf("Save");
      if (indexToReplace !== -1) {
        options.splice(indexToReplace, 1, "Save Template");
      }
      // if (allReports[props.report].fileName.includes("/Global/"))
      if (
        allReports[props.report].fileName.includes("/Global/") ||
        allReports[props.report].fileName.includes("/global/")
      ) {
        options.push("Create Local Copy");
        if (!useConfigStore.getState().isAdminFlag) {
          let newArr = options.filter(
            (arrItem) => !modifiedOptions.includes(arrItem)
          );
          options = newArr;
        }
      }
    }
  }

  if (props.numberOfReports > 1) {
    let closeIndex = options.indexOf("Close");
    if (closeIndex !== -1) {
      options.splice(closeIndex + 1, 0, "Close All");
    }

    // options.push("Focus", "Close All");
  }
  if (
    focusedRpt.rpt != "" &&
    focusedRpt.rpt == props.report &&
    options.length == 8
  ) {
    options.splice(7, 1, "Overview");
  }
  let currentSelectedView = useGlobalStore.getState().analyticsReportView.view;
  let tabbedReportLockStatus = props.isLocked;
  let showReportMenuIcon = false;

  if (currentSelectedView === "tab" && !tabbedReportLockStatus) {
    const reportInfo = _.cloneDeep(allReports[props.report]);
    let widgets = reportInfo && Object.keys(reportInfo.widgets);
    if (widgets.length > 0) {
      showReportMenuIcon = true;
    } else {
      props.toggleLock(reportInfo.fileName);
    }
  }

  const selectorValue =
    useGlobalStore.getState().analyticsReportView.view === "tab"
      ? "board"
      : props.report;
  const elementRef = document.querySelectorAll(
    `[data-rbd-droppable-id='${selectorValue}']`
  )[0];
  return (
    <div className={columnStyles.reportMenuIcon}>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
        disabled={showReportMenuIcon}
      >
        <MoreHorizOutlinedIcon fontSize="large" />
        {/* <MoreVertIcon /> */}
      </IconButton>
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            // maxHeight: ITEM_HEIGHT * 4.5,
            width: "auto",
            borderRadius: "10px",
          },
        }}
      >
        {options.map((option) => (
          <MenuItem
            key={option}
            // selected={option === "Pyxis"}
            onClick={() => {
              handleMenuClick(option);
            }}
          >
            {option}
          </MenuItem>
        ))}
      </Menu>
      <ExportToHTMLModal
        open={openExportModal}
        onCloseExportDialog={onExportActionClick}
        interestedElementRef={elementRef}
        fileName="Report"
      />
      <AddWidgets
        open={openAddWidget}
        handleClose={handleAddWidget}
        report={props.report}
      />
      <div>
        <ShareReportModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          onSubmit={handleModalSubmit}
          selectedItem={selectedItem}
          mainComponentData={mainComponentData}
          onSelectedItemChange={setSelectedItem}
        />
      </div>
      <div>
        <EditReportModal
          isOpen={isEditModalOpen}
          onClose={handleEditCloseModal}
          onSubmit={handleEditModalSubmit}
          selectedItem={editSelectedItem}
          mainComponentData={editmainComponentData}
          onSelectedItemChange={setEditSelectedItem}
          reportTitle={
            Object.keys(allReports).length > 0 &&
            allReports[props.report].fileName
          }
        />
      </div>
      <div>
        <>
          <Modal
            open={isPrefModalOpen}
            onClose={() => setIsPrefModalOpen(false)}
          >
            <Box className={styles.propertyModal}>
              <div className={styles.modalHeading}>
                <Typography className={styles.modalHeadingText}>
                  Property
                </Typography>
                <div>
                  <CloseRoundedIcon
                    onClick={() => setIsPrefModalOpen(false)}
                    className={styles.closeIcon}
                  />
                </div>
              </div>
              <Box className={styles.tabs}>
                <StyledTabs
                  value={value}
                  onChange={handleChange}
                  initialSelectedIndex={value}
                >
                  <StyledTab
                    value={0}
                    onClick={() => handleClick("default")}
                    label="Set Default Data Location"
                    {...a11yProps(0)}
                    style={{ textTransform: "capitalize" }}
                  />

                  <StyledTab
                    value={1}
                    onClick={() => handleClick("declare")}
                    label="Declare Variables"
                    {...a11yProps(1)}
                    style={{ textTransform: "capitalize" }}
                  />
                </StyledTabs>
              </Box>
              <CustomTabPanel
                value={value}
                index={0}
                className={styles.customTab1}
              >
                <div className={styles.tab1Flex}>
                  <Typography className={styles.defaultLocation}>
                    Set Your Default Data Locations
                  </Typography>
                  <Box className={styles.addLocation}>
                    <AddIcon
                      className={styles.addIcon}
                      onClick={() => setShowDataSource(true)}
                    />
                    <Typography
                      className={styles.addText}
                      onClick={() => setShowDataSource(true)}
                    >
                      Add Default Data Location
                    </Typography>
                  </Box>
                </div>
                <Box className={styles.flex}>
                  <Box className={styles.defaultLocationSource}>
                    <Box
                      className={styles.boxDefaultLocation}
                      onClick={() => setShowDataSource(true)}
                    >
                      Default Data Source
                    </Box>
                    <Tooltip title={tempConfig} arrow>
                      <Typography className={styles.defaultLocationText}>
                        {tempConfig}
                      </Typography>
                    </Tooltip>
                  </Box>

                  {showDataSource ? (
                    <ClickAwayListener
                      onClickAway={() => {
                        setShowDataSource(false);
                      }}
                    >
                      <Box className={styles.dataSource}>
                        <DataSource
                          dataLocationChanged={handleDataLocationChange}
                          dataLocation={tempConfig.dataLocation}
                          close={() => {
                            setShowDataSource(false);
                          }}
                        />
                      </Box>
                    </ClickAwayListener>
                  ) : null}
                </Box>

                <Box>
                  <Box className={styles.defaultScenarioText}>
                    Default Scenario is
                  </Box>
                  <Autocomplete
                    id="scenario-input"
                    style={{ marginTop: "10px" }}
                    value={scenariosSelect}
                    onChange={(event, newValue) => {
                      handleScenarioChange(newValue);
                    }}
                    size="small"
                    options={widgetForm}
                    renderOption={(props, option) => (
                      <li key={option} {...props}>
                        <Typography style={{ fontSize: "0.75rem" }}>
                          {option}
                        </Typography>
                      </li>
                    )}
                    getOptionLabel={(option) => {
                      if (option.includes("#")) {
                        let opt = option.split("#");
                        return opt[1];
                      } else return option;
                    }}
                    fullWidth
                    renderInput={(params) => (
                      <StyledTextField
                        {...params}
                        error={tempConfig.scenarioErrorFlag}
                        helperText={tempConfig.scenarioHelperText}
                        label="Default Scenario"
                        fullWidth
                        variant="outlined"
                        InputLabelProps={{
                          sx: {
                            fontSize: "0.75rem",
                            [`&.${inputLabelClasses.shrink}`]: {
                              background: "#fff",
                            },
                          },
                        }}
                      />
                    )}
                  />
                </Box>
                <Box className={styles.dataSourceFooter}>
                  <b>Default Data Source is :</b>
                  <Tooltip title={tempConfig} arrow>
                    <p className={styles.dataSourceFooterText}>{tempConfig}</p>
                  </Tooltip>
                </Box>
                <div className={styles.button}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={savePropertyInfo}
                    className={styles.saveButton}
                  >
                    Save{" "}
                  </Button>
                </div>
              </CustomTabPanel>

              <CustomTabPanel
                value={value}
                index={1}
                className={styles.customTab2}
              >
                <ReportGlobalVariables
                  reportInfo={_.cloneDeep(allReports[props.report])}
                  saveReportInfo={saveReportInfo}
                />
              </CustomTabPanel>
            </Box>
          </Modal>
        </>
      </div>
      {openDeleteModal ? (
        <DeleteComponent
          modalStateHandler={modalStateHandler}
          modalState={openDeleteModal}
          allReports={allReports}
          report={props.report}
          closeReport={props.closeReport}
          closeAllReport={props.closeAllReport}
          reportTitle={allReports[props.report].fileName}
          file_name={commonString + allReports[props.report].fileName + ".json"}
        />
      ) : (
        <></>
      )}
    </div>
  );
}

const Column = (props) => {
  const { focusedRpt } = useGlobalStore();
  // const reportName = allReports[analyticsReportView.currentTab].fileName
  const isLocked = useGlobalStore((state) => state.reports[props.title]);
  const toggleLock = useGlobalStore((state) => state.toggleLock);

  const title = props.title;
  const reports = props.reports;
  const index = props.index;
  let reportWidth = 100 / props.numberOfReports;
  if (
    focusedRpt &&
    Object.keys(focusedRpt).length &&
    focusedRpt.rpt == props.title
  ) {
    reportWidth = 100;
  }

  return props && props.title ? (
    <>
      <Draggable draggableId={title} index={index}>
        {(provided, snapshot) =>
          provided ? (
            <Container
              ref={provided.innerRef}
              {...provided.draggableProps}
              reportWidth={reportWidth}
            >
              <Header
                isDragging={snapshot.isDragging}
                className={columnStyles.rptTitleBar}
              >
                <div
                  isDragging={snapshot.isDragging}
                  {...provided.dragHandleProps}
                  aria-label={`${title} quote list`}
                  className={columnStyles.flex}
                >
                  <AssessmentOutlinedIcon sx={{ margin: "5px" }} />
                  <Breadcrumbs
                    separator={<Typography variant="h6">/</Typography>}
                    itemsAfterCollapse={10}
                    itemsBeforeCollapse={0}
                    maxItems={5}
                    sx={{ paddingRight: "35px" }}
                  >
                    {title.split("/").map((value, index) => {
                      return (
                        <Typography variant="h6" key={index}>
                          {value}
                        </Typography>
                      );
                    })}
                  </Breadcrumbs>
                  {useGlobalStore.getState().analyticsReportView.view ===
                  "tab" ? (
                    <div className={columnStyles.reportLockIcon}>
                      <IconButton>
                        {!isLocked ? (
                          <Lock
                            className={columnStyles.locked}
                            onClick={() => toggleLock(title)}
                          />
                        ) : (
                          <LockOpen
                            className={columnStyles.unlocked}
                            onClick={() => toggleLock(title)}
                          />
                        )}
                      </IconButton>
                    </div>
                  ) : (
                    <></>
                  )}
                  <ReportMenu
                    report={props.title}
                    closeReport={props.closeReport}
                    closeAllReport={props.closeAllReport}
                    numberOfReports={props.numberOfReports}
                    isLocked={isLocked}
                    toggleLock={toggleLock}
                    parentRef={props.parentRef}
                  />
                </div>
              </Header>

              {useGlobalStore.getState().analyticsReportView.view === "tab" ? (
                <ReportGrid />
              ) : (
                <ReportPane
                  listId={title}
                  listType="QUOTE"
                  style={{
                    backgroundColor: snapshot.isDragging
                      ? "#44D8BE"
                      : useConfigStore.getState().theme == "dark"
                      ? "rgb(25,25,25)"
                      : "#fff",
                  }}
                  reports={reports}
                  internalScroll={props.isScrollable}
                  isCombineEnabled={Boolean(props.isCombineEnabled)}
                  useClone={Boolean(props.useClone)}
                  deleteWidget={props.deleteWidget}
                  endPointUrl={props.endPointUrl}
                />
              )}
            </Container>
          ) : null
        }
      </Draggable>
    </>
  ) : null;
};
export default Column;
