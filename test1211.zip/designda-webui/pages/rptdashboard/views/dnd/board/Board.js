// @flow
import React, { useState, useRef, useContext, useEffect } from "react";
import styled from "@xstyled/styled-components";
// import { colors } from "@atlaskit/theme";
import PropTypes from "prop-types";
import Column from "./Column";
import reorder, { reorderReportMap } from "../reorder";
import { DragDropContext, Droppable } from "react-beautiful-dnd";
import useGlobalStore from "../../../../../store/useGlobalStore";
import useConfigStore from "../../../../../store/useConfigStore";
import JsonContext from "../../../../../contexts/JsonContext";

import { useSnackbar } from "notistack";

import { shallow } from "zustand/shallow";

// import useSound from "use-sound";

// import fluteSound from "./../../../../../public/sounds/NtfsSound.mp3";

import _ from "lodash";

const Container = styled.div`
  background-color: ${useConfigStore.getState().theme == "dark"
    ? "rgb(50,50,50)"
    : "white"};
  /* like display:flex but will allow bleeding over the window width */
  width: calc(100% - 20px);
  height: calc(100vh - 72px);
  overflow: auto;
  display: inline-flex;
`;

const NotfsAction = (snackbarId) => (
  <>
    <button
      onClick={() => {
        alert(`I belong to snackbar with id ${snackbarId}`);
      }}
    >
      Undo
    </button>
    <button
      onClick={() => {
        closeSnackbar(snackbarId);
      }}
    >
      Dismiss
    </button>
  </>
);

const Board = ({
  isCombineEnabled,
  initial,
  useClone,
  containerHeight,
  withScrollableColumns,
  endPointUrl,
  rptName,
}) => {
  const { enqueueSnackbar } = useSnackbar();
  const { deleteClosedJson } = useConfigStore();

  const allReports = useGlobalStore((state) => state.allReports, shallow);

  const setRootLevelData = useGlobalStore((state) => state.setRootLevelData);

  const [ordered, setOrdered] = useState(Object.keys(allReports));

  useEffect(() => {
    setOrdered(Object.keys(allReports))

  }, [allReports])

  const closeReport = (report) => {
    [...ordered.splice(ordered.indexOf(report), 1)];
    setOrdered(ordered);
    const reports = _.cloneDeep(allReports);
    delete reports[report];
    setRootLevelData("allReports", reports);
    deleteClosedJson(report);
  };
  // function to close All Reports
  const closeAllReport = (report) => {
    // [...ordered.splice(ordered.indexOf(report), 1)];
    // setOrdered(ordered);
    const reports = _.cloneDeep(allReports);
    Object.keys(reports).map((report) => {
      delete reports[report]
    })
    setRootLevelData("allReports", reports);
  };


  const deleteWidget = (widgetId, report) => {
    const reports = _.cloneDeep(allReports);
    let widOrder = Object.keys(reports);
    widOrder.splice(widOrder.indexOf(widgetId), 1)
    delete reports[report].widgets[widgetId];
    reports[report]["widgetsOrder"] = widOrder;
    setRootLevelData("allReports", reports);
  };

  // const [playFluteSound] = useSound("./../../../../../public/sounds/error.mp3");

  const onDragEnd = (result) => {
    if (result.combine) {
      if (result.type === "COLUMN") {
        const shallow = [...ordered];
        shallow.splice(result.source.index, 1);
        setOrdered(shallow);
        return;
      }

      const column = allReports[result.source.droppableId];
      const withWidgetRemoved = [...column];

      withWidgetRemoved.splice(result.source.index, 1);

      const orderedColumns = {
        ...allReports,
        [result.source.droppableId]: withWidgetRemoved,
      };
      setRootLevelData("allReports", reports);
      return;
    }

    // dropped nowhere
    if (!result.destination) {
      return;
    }

    const source = result.source;
    const destination = result.destination;

    // did not move anywhere - can bail early
    if (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    ) {
      return;
    }

    // reordering column or you can call them reports
    if (result.type === "COLUMN") {
      const reorderedorder = reorder(ordered, source.index, destination.index);

      setOrdered(reorderedorder);

      return;
    }

    const data = reorderReportMap({
      allReports: allReports,
      source,
      destination,
    });

    setRootLevelData("allReports", data.allReports);

    enqueueSnackbar("Widget Moved", {
      variant: "info",
      anchorOrigin: { horizontal: "right", vertical: "bottom" },
      NotfsAction,
    });

    // playFluteSound();
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <Droppable
        droppableId="board"
        type="COLUMN"
        // mode="virtual"
        direction="horizontal"
        ignoreContainerClipping={Boolean(containerHeight)}
        isCombineEnabled={isCombineEnabled}
      >
        {(provided) => (
          <Container ref={provided.innerRef} {...provided.droppableProps}>
            {ordered.map((key, index) => (
              <Column
                key={key}
                numberOfReports={ordered.length}
                index={index}
                title={key}
                reports={allReports[key]}
                isScrollable={withScrollableColumns}
                isCombineEnabled={isCombineEnabled}
                useClone={useClone}
                closeReport={closeReport}
                closeAllReport={closeAllReport}
                deleteWidget={deleteWidget}
                endPointUrl={endPointUrl}
              />
            ))}
            {provided.placeholder}
          </Container>
        )}
      </Droppable>
    </DragDropContext>
  );
};

Board.defaultProps = {
  isCombineEnabled: false,
  initial: {},
  rptName: "a2",
};

Board.propTypes = {
  isCombineEnabled: PropTypes.bool,
};

export default Board;
