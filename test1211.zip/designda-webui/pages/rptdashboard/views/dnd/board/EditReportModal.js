import React, { useState, useEffect } from "react";
import { styled, alpha } from "@mui/material/styles";
import styles from "../../../../search/search.module.css";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Select,
  Button,
  MenuItem,
  FormControl,
  Box,
  InputLabel,
  Input,
} from "@mui/material";
import Modal from "@mui/material/Modal";
import useConfigStore from "../../../../../store/useConfigStore";
import axios from "axios";
import { toast } from "react-toastify";

function EditModal({
  isOpen,
  onClose,
  onSubmit,
  selectedItem,
  mainComponentData,
  onSelectedItemChange,
  reportTitle,
}) {
  const [data, setData] = useState([]);
  const style = {
    position: "absolute",

    top: "50%",

    left: "50%",

    transform: "translate(-50%, -50%)",

    width: "50%",

    height: "70%",

    bgcolor: "white",

    border: "2px solid #000",

    boxShadow: 24,

    p: 4,

    backgroundColor: "white",

    overflow: "auto",
  };
  useEffect(() => {
    // Fetch data from your API when the modal opens
    if (isOpen) {
      onSelectedItemChange(reportTitle);

      axios
        .post(
          useConfigStore.getState().configData.rest_server_url +
            "/api/get_gui_reports_tags",
          {
            user: useConfigStore.getState().authLoginUser,
          }
        )
        .then((response) => {
          if (response.status) {
            response = response.data;
            console.log(response.gui_reports);
            setData(response.gui_reports);
          } else {
            // Show Failure toast message
            // this.setToastMessage({
            //   message: "Failed to save analytics report",
            //   success: false,
            // });
            console.log("Failed to save analytics report");
          }
        })
        .catch((error) => {
          // show network error message
          // Show Failure toast message
          // this.setToastMessage({
          //   message: "Failed to reach Server",
          //   success: false,
          console.log("Failed to reach Server");
          // });
        });
    }
  }, [isOpen]);
  const handleSelectChange = (event) => {
    onSelectedItemChange(event.target.value);
  };
  const handleButtonClick = () => {
    // Make a POST request with the selected value and mainComponentData

    const allFileNames = data.map((fileName) => fileName.replace(".json", ""));
    if (selectedItem === reportTitle || selectedItem in allFileNames) {
      toast.info(`Report name already Exists!`, {
        position: toast.POSITION.BOTTOM_LEFT,

        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
      return false;
    } else {
      onSubmit(selectedItem);
      onClose();
    }
  };
  return (
    <>
      <Modal
        open={isOpen}
        onClose={onClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <>
            <InputLabel>New Report Name</InputLabel>
            <Input
              value={selectedItem}
              onChange={handleSelectChange}
              placeholder="Ex - hier1/hier2/new_report_name"
              //   sx={{width:1000}}
              fullWidth
              // placeholder="Select Project"
            />
          </>
          {/* <p>{selectedItem} TEST {reportTitle}</p>

          <br/>
          {data} */}
          <>
            <Button
              onClick={handleButtonClick}
              variant="contained"
              color="primary"
            >
              Rename
            </Button>
          </>
          {/* </DialogContent> */}
        </Box>
      </Modal>
    </>
  );
}
export default EditModal;
