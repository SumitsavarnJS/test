import * as utils from "../../../../common/utils/utils";
import _ from "lodash";

// a little function to help us with reordering the result
const reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);

  return result;
};

export default reorder;

export const reorderReportMap = ({ allReports, source, destination }) => {
  const current = Object.keys(allReports[source.droppableId].widgets);
  const next = Object.keys(allReports[destination.droppableId].widgets);
  const target = current[source.index];

  const allReportsClone = _.cloneDeep(allReports);
  delete allReportsClone[destination.droppableId].widgets;
  allReportsClone[destination.droppableId]["widgets"] = {};

  // moving to same report
  if (source.droppableId === destination.droppableId) {
    const reordered = reorder(current, source.index, destination.index);

    for (let index = 0; index < reordered.length; index++) {
      allReportsClone[source.droppableId]["widgets"][reordered[index]] =
        allReports[source.droppableId]["widgets"][reordered[index]];
    }

    return {
      allReports: allReportsClone,
    };
  }

  // insert into different report
  next.splice(destination.index, 0, target);

  for (let index = 0; index < next.length; index++) {
    if (next[index] == target) {
      allReportsClone[destination.droppableId].widgets[next[index]] =
        _.cloneDeep(allReports[source.droppableId].widgets[next[index]]);
    } else {
      allReportsClone[destination.droppableId].widgets[next[index]] =
        allReports[destination.droppableId].widgets[next[index]];
    }
  }

  delete allReportsClone[source.droppableId].widgets[current[source.index]];

  //if dataLocation exits for a moving widget
  if (
    allReportsClone[destination.droppableId].widgets[
      target
    ].config.hasOwnProperty("dataLocation")
  ) {
    // if data loc of widget is till time stamp
    if (
      utils.isRootDirectory(
        allReportsClone[destination.droppableId].widgets[target].config
          .dataLocation
      )
    ) {
      allReportsClone[destination.droppableId].widgets[
        target
      ].config.dataLocation = utils.getRootDirectory(
        _.get(allReportsClone[destination.droppableId], "dataLocation", "")
      );
    }
    // otherwise add whatever data destination of the target report
    else {
      allReportsClone[destination.droppableId].widgets[
        target
      ].config.dataLocation = _.get(
        allReportsClone[destination.droppableId],
        "dataLocation",
        ""
      );
    }

    allReportsClone[destination.droppableId].widgets[target].config.bucket =
      _.get(allReportsClone[destination.droppableId], "bucket", "");
  }

  return {
    allReports: allReportsClone,
  };
};

export function addWidget({ reportName, widget, index }) {}

export function deleteWidget({ reportName, widget, index }) {}

export function deleteReport({ allReports, reportName }) {}

export function closeReport({ allReports, reportName }) {
  delete allReports[reportName];

  return allReports;
}

export function moveBetween({ list1, list2, source, destination }) {
  const newFirst = Array.from(list1.values);
  const newSecond = Array.from(list2.values);

  const moveFrom = source.droppableId === list1.id ? newFirst : newSecond;
  const moveTo = moveFrom === newFirst ? newSecond : newFirst;

  const [moved] = moveFrom.splice(source.index, 1);
  moveTo.splice(destination.index, 0, moved);

  return {
    list1: {
      ...list1,
      values: newFirst,
    },
    list2: {
      ...list2,
      values: newSecond,
    },
  };
}
