import React, { useState, useEffect } from "react";
import Column from "./dnd/board/Column";
import reorder, { reorderReportMap } from "../views/dnd/reorder";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import CloseIcon from "@mui/icons-material/Close";
import IconButton from "@mui/material/IconButton";
import styled from "@xstyled/styled-components";
import { shallow } from "zustand/shallow";
import _ from "lodash";
import { Tooltip, Typography } from "@mui/material";
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';
// import CloseAllIcon from '@mui/icons-material/ChevronDoubleDown';

const Container = styled.div`
  background-color: ${useConfigStore.getState().theme == "dark"
    ? "rgb(50,50,50)"
    : "6D9EB5"};
  /* like display:flex but will allow bleeding over the window width */
  width: 100%;
  height: 100%;
  overflow: auto;
  display: inline-flex;
`;

const Tab = styled.div`
  background-color: ${(props) => (props.active ? "#eee6ff" : "#5A2A82")};
  color: ${(props) => (props.active ? "black" : "white")};
  padding: 2px 5px;
  height: 1.8rem;
  min-width: 20px;
  width: auto;
  display: flex;
  justify-content: flex-end;
  overflow: hidden;
  border-radius: 10px;
  position: sticky;
  top: 0px;
`;

const TabbedRpt = (props) => {
  const { deleteClosedJson } = useConfigStore();

  const { setRootLevelData, allReports } = useGlobalStore(
    (state) => ({
      setRootLevelData: state.setRootLevelData,
      allReports: state.allReports,
    }),
    shallow
  );

  const [ordered, setOrdered] = useState(Object.keys(allReports));
  const [openDialog, setOpenDialog] = useState(false);

  useEffect(() => {
    setOrdered(Object.keys(allReports));
  }, [allReports]);

  const closeReport = (report) => {
    [...ordered.splice(ordered.indexOf(report), 1)];
    setOrdered(ordered);
    const reports = _.cloneDeep(allReports);
    delete reports[report];
    setRootLevelData("allReports", reports);
    deleteClosedJson(report);
  };
  //function to close all the reports
  const closeAllReport = (report) => {
    [...ordered.splice(ordered.indexOf(report), 1)];
    setOrdered(ordered);
    const reports = _.cloneDeep(allReports);
    Object.keys(reports).map((report) => {
      delete reports[report];
    });
    setRootLevelData("allReports", reports);
  };

  const handleConfirmCloseAll = () => {
    const reports = _.cloneDeep(allReports);
    Object.keys(reports).map((report) => {
      delete reports[report];
    });
    setRootLevelData("allReports", reports);
    setOpenDialog(false);
  };



  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };
  const deleteWidget = (widgetId, report) => {
    const reports = _.cloneDeep(allReports);
    let widOrder = Object.keys(reports);
    widOrder.splice(widOrder.indexOf(widgetId), 1);
    delete reports[report].widgets[widgetId];
    reports[report]["widgetsOrder"] = widOrder;
    setRootLevelData("allReports", reports);
  };

  const onDragEnd = (result) => {
    if (result.combine) {
      if (result.type === "COLUMN") {
        const shallow = [...ordered];
        shallow.splice(result.source.index, 1);
        setOrdered(shallow);
        return;
      }

      const column = allReports[result.source.droppableId];
      const withWidgetRemoved = [...column];
      withWidgetRemoved.splice(result.source.index, 1);

      const orderedColumns = {
        ...allReports,
        [result.source.droppableId]: withWidgetRemoved,
      };
      setRootLevelData("allReports", reports);
      return;
    }

    // dropped nowhere
    if (!result.destination) {
      return;
    }

    const source = result.source;
    const destination = result.destination;

    // did not move anywhere - can bail early
    if (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    ) {
      return;
    }

    // reordering column or you can call them reports
    if (result.type === "COLUMN") {
      const reorderedList = reorder(
        Object.keys(allReports),
        source.index,
        destination.index
      );
      const allReportsClone = {};

      for (let i = 0; i < reorderedList.length; i++) {
        allReportsClone[reorderedList[i]] = allReports[reorderedList[i]];
      }

      setRootLevelData("allReports", allReportsClone);
      return;
    }
    const data = reorderReportMap({
      allReports: allReports,
      source,
      destination,
    });
    setRootLevelData("allReports", data.allReports);
  };

  return (
    <div id="tabbedView">
      <div>
        <DragDropContext onDragEnd={onDragEnd}>
          <Droppable
            droppableId="droppable"
            type="COLUMN"
            direction="horizontal"
            ignoreContainerClipping={true}
            isCombineEnabled={false}
          >
            {(provided, snapshot) => (
              <Container
                ref={provided.innerRef}
                {...provided.droppableProps}
              >
                {Object.keys(allReports).map((item, index) => (
                  <Draggable key={item} draggableId={item} index={index}>
                    {(provided, snapshot) => (
                      <Tooltip title={item}>
                        <Tab
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          active={
                            item ==
                            useGlobalStore.getState().analyticsReportView
                              .currentTab
                          }
                          onClick={() => {
                            useGlobalStore
                              .getState()
                              .setRootLevelData("analyticsReportView", {
                                view: "tab",
                                currentTab: item,
                              });
                          }}
                        >
                          {item.split("/").join(" / ")}
                          <Tooltip placement={"top-end"} title="Close Report">
                            <IconButton
                              edge="start"
                              color="inherit"
                              onClick={(e) => {
                                e.stopPropagation();
                                closeReport(item);
                              }}
                              aria-label="close"
                              sx={{ ml: "2px" }}
                            >
                              <CloseIcon
                                sx={{ fontSize: 14 }}
                                color="inherit"
                              />
                            </IconButton>
                          </Tooltip>


                        </Tab>


                      </Tooltip>



                    )}

                  </Draggable>
                ))}


                <>

                  {(Object.keys(allReports).length > 1) &&
                    <Tooltip placement={"top-end"} title="Close All Reports">
                      <IconButton
                        sx={{
                          borderRadius: '50%',
                          marginRight: (1),
                          marginLeft: 2,
                          marginBottom: 1,
                          fontSize: '1rem',
                          borderRadius: '50%', // Make it round
                          backgroundColor: '#e7d9f3', // Fill color
                          padding: 1,
                          '&:hover': { backgroundColor: '#5b2c84', color: '#ffffff' }
                        }}
                        edge="start"
                        color="inherit"
                        onClick={handleOpenDialog}
                        aria-label="close"
                      >
                        <CloseIcon
                          sx={{ fontSize: 21 }}


                        />
                      </IconButton>
                    </Tooltip>
                  }

                  <Dialog open={openDialog} onClose={handleCloseDialog}>
                    <DialogTitle>Confirmation</DialogTitle>
                    <DialogContent>
                      <p>Are you sure you want to close all the Reports?</p>
                    </DialogContent>
                    <DialogActions>
                      <Button onClick={handleCloseDialog} color="primary">Cancel</Button>
                      <Button onClick={handleConfirmCloseAll} color="primary" autoFocus>Confirm</Button>
                    </DialogActions>
                  </Dialog>
                </>
              </Container>
            )}
          </Droppable>
        </DragDropContext>
      </div>
      {useGlobalStore.getState().analyticsReportView.currentTab &&
        Object.keys(allReports).includes(
          useGlobalStore.getState().analyticsReportView.currentTab
        ) ? (
        <div id="reportArea" style={{ height: "calc(100vh - 101px)" }}>
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable
              droppableId="board"
              type="COLUMN"
              // mode="virtual"
              direction="horizontal"
              ignoreContainerClipping={true}
              isCombineEnabled={false}
            >
              {(provided) => (
                <Container ref={provided.innerRef} {...provided.droppableProps}>
                  {["currentTab"].map((key, index) => (
                    <Column
                      key={
                        useGlobalStore.getState().analyticsReportView.currentTab
                      }
                      numberOfReports={1}
                      index={0}
                      title={
                        useGlobalStore.getState().analyticsReportView.currentTab
                      }
                      reports={
                        allReports[
                        useGlobalStore.getState().analyticsReportView
                          .currentTab
                        ]
                      }
                      isScrollable={true}
                      isCombineEnabled={false}
                      useClone={false}
                      closeReport={closeReport}
                      closeAllReport={closeAllReport}
                      deleteWidget={deleteWidget}
                    />
                  ))}

                  {provided.placeholder}
                </Container>
              )}
            </Droppable>
          </DragDropContext>
        </div>
      ) : Object.keys(allReports).length ? (
        <div
          id="noRptSelect"
          style={{ margin: "200px auto", height: "100%", width: "fit-content" }}
        >
          <Typography variant={"h3"}> Please select a report</Typography>
        </div>
      ) : (
        <div
          id="noRptOpened"
          style={{ margin: "200px auto", height: "100%", width: "fit-content" }}
        >
          <Typography variant={"h3"}> Please open a report</Typography>
        </div>
      )}
    </div>
  );
};

export default TabbedRpt;
