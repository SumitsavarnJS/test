import React from "react";

import "bootstrap/dist/css/bootstrap.min.css";


import Board from "./dnd/board/Board";


// const getData = (rptName = "a2") => {
//   let Data = { allReports: {} };

//   const reports = Object.keys(data.allReports);

//   let rptsToAdd;
//   switch (rptName) {
//     case "a1":
//       rptsToAdd = reports.slice(0, 1);
//       break;
//     case "a2":
//       rptsToAdd = reports.slice(0, 2);
//       break;
//     case "m1":
//       rptsToAdd = reports.slice(2, 3);
//       break;
//     case "m2":
//       rptsToAdd = reports.slice(2, 4);
//       break;
//     default:
//       rptsToAdd = reports.slice(0, 2);
//       break;
//   }

//   for (let i = 0; i < rptsToAdd.length; i++) {
//     Data.allReports[rptsToAdd[i]] = data.allReports[rptsToAdd[i]];
//   }

//   return Data;
// };

export default function ListView2(props) {


  // console.log(allReports)
  return (
    <>
      <Board
        withScrollableColumns
        useClone={false}
      />
    </>
  );
}
