import * as React from "react";

import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import Modal from "@mui/material/Modal";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";

import { toast } from "react-toastify";
import { nanoid } from "nanoid";
import useGlobalStore from "../../../store/useGlobalStore";
import { shallow } from "zustand/shallow";
import * as constants from "../../../constants/constants";
import * as styles from "./addWidget.module.css";
import _ from "lodash";
import { Button, Typography } from "@mui/material";
import * as utils from "../../../common/utils/utils";

import Tooltip from "@mui/material/Tooltip";

// import GraphPic from "images/Graph1.PNG";

function WidgetSelect(props) {
  const widgetOptions = Object.keys(widgets).sort();

  return (
    <Autocomplete
      id="widgets-select"
      sx={{ width: "100%" }}
      options={widgetOptions}
      ListboxProps={{
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          rowGap: "1em",
        },
      }}
      autoHighlight
      getOptionLabel={(option) => option}
      renderOption={(props, option) => (
        <Box
          component="li"
          sx={{ "& > img": { mr: 2, flexShrink: 0 } }}
          {...props}
        >
          <img
            loading="lazy"
            width="50"
            height="35"
            src={widgets[option].imageUrl}
            srcSet={widgets[option].imageUrl}
            alt=""
          />

          {option}
        </Box>
      )}
      onChange={props.handleWidgetSelect}
      renderInput={(params) => (
        <TextField
          {...params}
          label="Choose a widget"

          //   inputProps={{.
        />
      )}
    />
  );
}

export const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "60%",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  borderRadius: "15px",
  p: 4,
};

export const styleTemplate = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "60%",
  display: "block",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  borderRadius: "15px",
  height: "60%",
  padding: "20px",
};

// valid widgets with default dimensions

export const widgets = {
  Metrics: {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Metrics.svg",
  },
  IMetrics: {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/IMetrics.svg",
  },
  "Table View": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Table View.svg",
  },
  "ITable View": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/ITable View.svg",
  },
  // "Log Monitor": {
  //   width: 20,
  //   height: 12,
  //   imageUrl: "widget_library_icons/LiveLogMonitor.svg",
  // },
  "Convergence Plot": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Convergence Plot.svg",
  },
  "Group Bar Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Group Bar Chart.svg",
  },
  "Pie Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Pie Chart.svg",
  },
  Treemap: {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Treemap.svg",
  },
  "Bubble Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Bubble Chart.svg",
  },

  "Workflow Status Summary": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Workflow Status Summary.svg",
  },
  "Document View": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Document View.svg",
  },
  Histogram: {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Histogram.svg",
  },
  "KDE Plot": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/KDE Plot.svg",
  },
  "Box Plot": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Box Plot.svg",
  },
  "Multi Box Plot": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Multi Box Plot.svg",
  },
  "Multiple Feature Bar Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Multiple Feature Bar Chart.svg",
  },
  "Layout View": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Layout View.svg",
  },
  "Timing Correlation": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Timing Correlation.svg",
  },
  "Timing Path Matrix": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Timing Path Matrix.svg",
  },
  "Hierarchy Table": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Hierarchy Table.svg",
  },
  "Inter Clock Matrix": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Inter Clock Matrix.svg",
  },
  "3D Surface Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/3D Surface Chart.svg",
  },
  "Workflow Monitor Table": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Workflow Monitor Table.svg",
  },
  "Scatter Plot": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Scatter Plot.svg",
  },
  "Log Monitor Table": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Log Monitor Table.svg",
  },
  "Gantt Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Gantt Chart.svg",
  },
  "ILine Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/ILine Chart.svg",
  },
  "IScatter Plot": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/IScatter Plot.svg",
  },
  "IPie Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/IPie Chart.svg",
  },
  "IGroupBar Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/IGroupBar Chart.svg",
  },
  ITreemap: {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/ITreemap.svg",
  },
  "IMultiple Feature Bar Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/IMultiple Feature Bar Chart.svg",
  },
  "ISunburst Chart": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/ISunburst Chart.svg",
  },
  "Log Comparator": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/Log Comparator.svg",
  },
  "Layout View v2": {
    width: 24,
    height: 12,
    imageUrl: "widget_library_icons/Layout View.svg",
  },
  "Generic Charts v1": {
    width: 20,
    height: 12,
    imageUrl: "widget_library_icons/IMultiple Feature Bar Chart.svg",
  },
};

export const showConfigUiState = {
  isLoading: false,
  showConfig: true,
  isToastOpen: false,
  toastSeverity: "info",
  toastMessage: "",
  cirlularLoading: false,
};

export const showWidgetDataUiState = {
  isLoading: false,
  showConfig: false,
  isToastOpen: false,
  toastSeverity: "info",
  toastMessage: "",
  cirlularLoading: false,
};

export const addWidgetCommonFunction = (
  rptType,
  reportKey,
  widgetSettings,
  data = {},
  uiState = showConfigUiState,
  index = -1
) => {
  if (rptType == constants.allReports) {
    return addWidgetsToReport(reportKey, widgetSettings, index, data, uiState);
  } else if (rptType == constants.allDashbrdRpts) {
    return addWidgetToDashboard(widgetSettings, data, uiState);
  }
};

/**
 *
 * @param {string} reportName
 * @param {Arrary of objects or Object} widgetSettingsArray
 * @param {integer} index
 */
export const addWidgetsToReport = (
  reportName,
  widgetSettings,
  index = -1,
  data = {},
  uiState = showConfigUiState
) => {
  const allReports = useGlobalStore.getState().allReports;

  const reports = _.cloneDeep(allReports);

  let widgetList = Object.keys(allReports[reportName].widgets);

  let widgetSettingsCopy = _.cloneDeep(widgetSettings);

  //if settings are object then handle it

  if (!Array.isArray(widgetSettings)) {
    widgetSettingsCopy = [widgetSettingsCopy];
  }

  const noOfWidgetsToAdd = widgetSettingsCopy.length;
  let newWidgetId = [];
  // adding new ids in widget list at given index

  for (let i = 0; i < noOfWidgetsToAdd; i++) {
    let newWId = nanoid();
    newWidgetId.push(newWId);
    widgetList.splice(index + 1, 0, newWId);
  }

  // empty widgets object to later add new order of the widgets

  reports[reportName].widgets = {};

  //adding new order of widgets settigs

  for (let widgetId of widgetList) {
    // keep index/count of new widgets that are added

    let newWidgetIndex = 0;

    //add widget settings for existing widgets

    if (allReports[reportName].widgets.hasOwnProperty(widgetId)) {
      reports[reportName].widgets[widgetId] =
        allReports[reportName].widgets[widgetId];
    }

    // add widget settings for new widgets
    else {
      //add key to widget settings

      const newWidgetSettings = _.cloneDeep(widgetSettingsCopy[newWidgetIndex]);

      newWidgetSettings.key = widgetId;

      // add data and uiState to gloabal store

      const WkeyObj = {
        data: data,
        uiState: uiState,
      };
      useGlobalStore.getState().setRootLevelData(widgetId, WkeyObj);

      //add settings to the report

      reports[reportName].widgets[widgetId] = newWidgetSettings;

      newWidgetIndex = newWidgetIndex + 1;
    }
  }

  useGlobalStore

    .getState()

    .updateReport(constants.allReports, reportName, reports[reportName]);

  return newWidgetId;
};

export const addWidgetToDashboard = (
  widgetSettings,
  data = {},
  uiState = showConfigUiState
) => {
  let dashboardReportClone = _.cloneDeep(
    useGlobalStore.getState()[constants.allDashbrdRpts][
      constants.dashboardReport
    ]
  );

  const widgetId = nanoid();

  dashboardReportClone.widgets[widgetId] = _.cloneDeep(widgetSettings);

  dashboardReportClone.widgets[widgetId].key = widgetId;

  // add data and uiState to gloabal store

  const WkeyObj = {
    data: data,
    uiState: uiState,
  };

  useGlobalStore.getState().setRootLevelData(widgetId, WkeyObj);

  useGlobalStore.getState().setRootLevelData(constants.allDashbrdRpts, {
    [constants.dashboardReport]: dashboardReportClone,
  });

  return [widgetId];
};

export const nonDataSpecificWidgets = [
  "Document View",
  // "Custom Workflow Manager",
  // "Flow Analysis Manager",
  // "Task Analysis Manager",
  "Metrics Task Monitor",
  "Workflow Status Summary",
];

export default function AddWidgets(props) {
  const { allReports, allDashbrdRpts } = useGlobalStore(
    (state) => ({
      allReports: state.allReports,
      allDashbrdRpts: state.allDashbrdRpts,
    }),
    shallow
  );

  const handleAddWidgetClick = (event, widgetName) => {
    const config = {};

    let defaultDataLocation = "";
    let defaultBucket = "";
    if (props.reportType && props.reportType == constants.dashboardReport) {
      defaultDataLocation = _.get(
        allDashbrdRpts[constants.dashboardReport],
        "dataLocation",
        ""
      );
      defaultBucket = _.get(
        allDashbrdRpts[constants.dashboardReport],
        "bucket",
        ""
      );
    } else {
      defaultDataLocation = _.get(allReports[props.report], "dataLocation", "");
      defaultBucket = _.get(allReports[props.report], "bucket", "");
    }

    if (!nonDataSpecificWidgets.includes(widgetName)) {
      config.dataLocation = defaultDataLocation;
      config.bucket = defaultBucket;
    }
    const widgetSettings = {
      h: _.get(widgets[widgetName], "height", 8),

      w: _.get(widgets[widgetName], "width", 10),

      y: _.get(props, "y", -1),

      x: 0,

      metaData: { tags: "", description: "" },

      name: widgetName,

      config: config,
    };

    if (props.reportType && props.reportType == constants.dashboardReport) {
      addWidgetToDashboard(widgetSettings);
    } else {
      if (props.index != undefined) {
        addWidgetsToReport(props.report, [widgetSettings], props.index);
      } else {
        addWidgetsToReport(props.report, [widgetSettings]);
      }
    }

    props.handleClose();
  };

  return (
    <div>
      <Modal
        open={props.open}
        onClose={props.handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <WidgetSelect handleWidgetSelect={handleAddWidgetClick} />

          {/* <Button onClick={props.handleClose}>Close</Button> */}
        </Box>
      </Modal>
    </div>
  );
}

export const AddTemplateWgtToRpt = (props) => {
  const { allReports } = useGlobalStore(
    (state) => ({
      allReports: state.allReports,
    }),

    shallow
  );

  const [state, setState] = React.useState({});

  const handleChange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.checked,
    });
  };

  const allReportKeys = Object.keys(allReports);

  const getSeletedRpts = () => {
    const selectedRpts = [];

    for (const key in state) {
      if (state[key] === true) {
        selectedRpts.push(key);
      }
    }
    return selectedRpts;
  };

  const handleAddToRtp = () => {
    const selectedRpts = getSeletedRpts();

    const widgetSettings = props.widgetSettings;
    for (let i = 0; i < selectedRpts.length; i++) {
      const index = Object.keys(allReports[selectedRpts[i]].widgets).length;
      for (let j = 0; j < widgetSettings.length; j++) {
        const setting = { ...widgetSettings[j] };
        //if widget has datalocation
        if (setting.config && setting.config && setting.config.dataLocation) {
          const isScenarioSpecific = utils.getScenarioFromDataLoc(
            setting.config.dataLocation
          );
          //if data location of widget is till scenario then add same dataLoc of rpt
          if (isScenarioSpecific) {
            setting.config.dataLocation = _.get(
              allReports[selectedRpts[i]],
              "dataLocation",
              ""
            );
          }
          //if data location of widget is till timestamp then add dataloc till timestamp of rpt
          else {
            setting.config.dataLocation = utils.getRootDirectory(
              _.get(allReports[selectedRpts[i]], "dataLocation", "")
            );
          }

          //set bucket of rpt to widget
          setting.config.bucket = _.get(
            allReports[selectedRpts[i]],
            "bucket",
            ""
          );
        }

        addWidgetsToReport(
          selectedRpts[i],
          setting,
          index,
          {},
          showConfigUiState
        );

        toast.success(`Widget added to Report`, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    }

    props.routeToRpt();
  };

  return (
    <Modal
      open={props.open}
      onClose={() => {
        props.handleClose(false);
      }}
      aria-labelledby="Add to Report"
      aria-describedby="Add to Report"
    >
      <Box id="addToReports" className={styles.addToReports}>
        <Typography
          sx={{
            fontSize: "28px",
            borderBottom: "2px solid #ccc",
            paddingBottom: "0.25%",
            marginTop: "0.25%",
          }}
        >
          Opened Reports
        </Typography>

        <div id="reports" className={styles.reports}>
          <div id="heading" className={styles.heading}>
            <Typography
              sx={{
                fontSize: "24px",
                textAlign: "center",
              }}
            >
              All Queued Reports
            </Typography>
          </div>
          <FormGroup>
            {allReportKeys.map((key) => (
              <div id="itemMapping" className={styles.itemMapping}>
                <Tooltip placement="top" title={key}>
                  <FormControlLabel
                    sx={{
                      width: "100%",
                    }}
                    control={
                      <Checkbox
                        sx={{
                          borderRadius: "0",
                          borderRight: "1px solid #ccc",
                          marginRight: "1%",
                        }}
                      />
                    }
                    onChange={handleChange}
                    label={key}
                    name={key}
                  />
                </Tooltip>
              </div>
            ))}
          </FormGroup>
        </div>
        <Button
          variant="raised"
          className={
            getSeletedRpts().length == 0
              ? styles.addToReportsBtnDisabled
              : styles.addToReportsBtn
          }
          onClick={handleAddToRtp}
          disabled={getSeletedRpts().length == 0}
        >
          Add To Reports
        </Button>
      </Box>
    </Modal>
  );
};
