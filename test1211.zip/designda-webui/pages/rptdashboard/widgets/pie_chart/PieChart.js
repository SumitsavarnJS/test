// react imports

import React from "react";
import ReactEcharts from "echarts-for-react";
import Typography from "@mui/material/Typography";
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";
import Config from "./Config";

// utility imprts

import _ from "lodash";

// css imports
const theme = useConfigStore.getState().theme;

import styles from "./PieChart.module.css";
class PieChart extends React.Component {
  // consturctor

  constructor(props) {
    super(props);

    this.chart = React.createRef();
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      // to set previous session legend selected settings

      if (this.props.config.legend && this.chart && this.chart.current) {
        let unSelected = [];

        Object.keys(this.props.config.legend).forEach((key) => {
          if (this.props.config.legend[key] == false) {
            unSelected.push(key);
          }
        });

        for (let i = 0; i < unSelected.length; i++) {
          this.chart.current.getEchartsInstance().dispatchAction({
            type: "legendUnSelect",

            name: unSelected[i],
          });
        }
      }
    }
  }

  //to store legend information

  onLegendChanged = (params) => {
    const config = { ...this.props.config };

    config["legend"] = params.selected;

    this.props.setConfig({
      reportName: this.props.currentReportName,

      widgetId: this.props.id,

      config: config,
    });
  };

  // Function to update config

  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
    // if (save) {
    //   this.props.setConfig({
    //     reportName: this.props.currentReportName,

    //     widgetId: this.props.id,

    //     config: config,
    //   });
    // }

    // this.props.toggleShowConfig({
    //   reportName: this.props.currentReportName,

    //   widgetId: this.props.id,
    // });
  };

  // render method

  render() {
    // define event dict

    const eventDict = {
      legendselectchanged: this.onLegendChanged,
    };

    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (uiState.showConfig) {
      return (
        <Config updateConfig={this.updateConfig} config={this.props.config} />
      );

      return null;
    } else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <ReactEcharts
          ref={this.chart}
          onEvents={eventDict}
          style={{ height: "90%" }}
          option={data}
          theme={this.props.theme}
          notMerge={true}
        />
      );
    }
  }
}

PieChart.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
export default PieChart;
