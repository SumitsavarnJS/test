import React from "react";
import { connect } from "react-redux";
// import FormControlLabel from '@mui/material/FormControlLabel';
// import Checkbox from '@mui/material/Checkbox';
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
// import AceEditor from "react-ace";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Popup from "reactjs-popup";
import dynamic from "next/dynamic";
import { ClickAwayListener } from "@mui/base";
// utility imprts
import _ from "lodash";
import axios from "axios";

// data source table
import DataSource from "../../data_source/DataSource";

// import "ace-builds/src-noconflict/mode-python";
// import "ace-builds/src-noconflict/theme-xcode";
// import "brace/ext/language_tools";

import styles from "./Config.module.css";
import useConfigStore from "../../../../store/useConfigStore";
import { Box } from "@mui/material";

const AceEditor = dynamic(
  () => import("react-ace").then((mod) => mod.default),
  { ssr: false }
);

const pythonTheme = dynamic(
  () =>
    import("../../../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);

const defaultQueryBody = `# Data has been loaded in df variable
# Please modify the df variable to contain data needed for the plot
# All columns (numerical) of the 1st row are used for the Pie Chart
`;

class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      dataLocation: _.get(this.props.config, "dataLocation", ""),
      data: _.get(this.props.config, "data", ""),
      columns: _.get(this.props.config, "columns", []),
      groupingAxis: _.get(this.props.config, "groupingAxis", "Y"),

      bucket: _.get(this.props.config, "bucket", ""),
      dataList: [],
      columnList: [],
    };

    this.query = _.get(this.props.config, "query", defaultQueryBody);
  }

  componentDidMount() {
    // refresh data list if data location is present
    if (this.state.dataLocation) {
      this.dataLocationChanged(this.state.dataLocation, this.state.bucket);
    }
  }

  dataLocationChanged = (newDataLocation, bucket) => {
    const data = {
      bucket: bucket,
      key: newDataLocation,
    };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_ldb_files",
        data
      )
      .then((response) => {
        const dataList = _.get(response.data, "data", {});
        let data = this.state.data;
        if (data && !dataList.includes(data)) {
          data = "";
        }
        this.setState({
          dataLocation: newDataLocation,
          dataList: dataList,
          bucket: bucket,
          data: data,
        });
        if (this.state.data) {
          this.dataChanged(this.state.dataLocation, this.state.data);
        } else {
          this.setState({
            columns: [],
            columnList: [],
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // Data changed handler. This will fetch the list of columns for this data
  dataChanged = (location, newData) => {
    const data = {
      bucket: this.state.bucket,
      key: location,
      ldb_file: newData,
    };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_parquet_columns",
        data
      )
      .then((response) => {
        let columns = [];
        const selectedColumns = this.state.columns;
        const columnList = _.get(response.data, "data", {});
        for (const rowIdx in selectedColumns) {
          if (columnList.includes(selectedColumns[rowIdx])) {
            columns.push(selectedColumns[rowIdx]);
          }
        }
        this.setState({
          data: newData,
          columnList: columnList,
          columns: columns,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  onQueryChange = (newQuery) => {
    this.query = newQuery;
  };

  onSave = () => {
    console.log("Click kiya");
    const config = {};
    config["dataLocation"] = this.state.dataLocation;
    config["groupingAxis"] = this.state.groupingAxis;

    config["data"] = this.state.data;
    config["columns"] = this.state.columns;
    config["query"] = this.query;
    config["bucket"] = this.state.bucket;

    // add title only if user has provided it
    if (this.state.title.length > 0) {
      config["title"] = this.state.title;
    }
    this.props.updateConfig(config, true);
  };
  toggleGroupingAxis = (event) => {
    this.setState({
      groupingAxis: event.target.value,
    });
  };
  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Select Data Source */}
        {/* <div className={styles.inline}> */}
        {/* <Popup
            trigger={
              <Button size="small" classes={{ root: styles.add_button }}>
                Data Source
              </Button>
            }
            modal
            contentStyle={{
              paddingTop: "25px",
              overflow: "scroll",
              position: "relative",
              width: this.props.fullScreenWidget.open ? "95%" : "100%",
              height: this.props.fullScreenWidget.open ? "92%" : "100%",
            }}
          >
            {(close) => {
              return (
                <DataSource
                  dataLocationChanged={this.dataLocationChanged}
                  dataLocation={this.state.dataLocation}
                  bucket={this.state.bucket}
                  close={close}
                />
              );
            }}
          </Popup> */}

        {/* <Typography
            variant="body2"
            style={{ marginTop: "15px", marginLeft: "15px" }}
          >
            {this.state.dataLocation.split("#")[1]}
          </Typography>
        </div> */}

        <div className={styles.inline}>
          <Button
            size="small"
            classes={{ root: styles.add_button }}
            onClick={() => this.setState({ showDataSource: true })}
          >
            Data Source
          </Button>
          {this.state.showDataSource ? (
            <ClickAwayListener
              onClickAway={() => {
                this.setState({ showDataSource: false });
              }}
            >
              <Box
                sx={{
                  zIndex: "5",
                  position: "absolute",
                  top: "0px",
                  left: "0px",
                  width: "100%",
                  height: "fit-content",
                  backgroundColor: "white",
                  padding: "5px",
                  boxShadow: "grey 5px 5px 5px",
                }}
              >
                <DataSource
                  dataLocationChanged={this.dataLocationChanged}
                  dataLocation={this.state.dataLocation}
                  bucket={this.state.bucket}
                  close={() => {
                    this.setState({ showDataSource: false });
                  }}
                />
              </Box>
            </ClickAwayListener>
          ) : null}
          <Typography
            variant="body2"
            style={{ marginTop: "15px", marginLeft: "15px" }}
          >
            {this.state.dataLocation.split("#")[1]}
          </Typography>
        </div>

        {/* Select Dataframe */}
        <Autocomplete
          id="data-input"
          style={{ marginTop: "10px" }}
          value={this.state.data}
          onChange={(event, newValue) => {
            this.dataChanged(this.state.dataLocation, newValue);
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.dataList}
          getOptionLabel={(option) => {
            if (option.includes("#")) {
              let opt = option.split("#");
              return opt[1];
            } else return option;
          }}
          renderInput={(params) => (
            <TextField {...params} label="Data" variant="outlined" />
          )}
        />

        {/* Select Columns */}
        <Autocomplete
          id="columns-input"
          multiple
          filterSelectedOptions
          style={{ marginTop: "10px" }}
          value={this.state.columns}
          onChange={(event, newValue) => {
            this.setState({ columns: newValue });
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.columnList}
          renderInput={(params) => (
            <TextField {...params} label="Columns" variant="outlined" />
          )}
        />

        {/* Code editor */}
        <Typography variant="subtitle1" className={styles.label}>
          Query Editor
        </Typography>

        <AceEditor
          placeholder="Please modify df object depending on the query."
          mode="python"
          theme="xcode"
          name="code_editor"
          width="100%"
          // onLoad={this.onLoad}
          onChange={(value, event) => {
            this.onQueryChange(value);
          }}
          fontSize={16}
          maxLines={Infinity}
          showPrintMargin={true}
          showGutter={true}
          highlightActiveLine={true}
          value={this.query}
          setOptions={{
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: true,
            enableSnippets: false,
            showLineNumbers: true,
            tabSize: 2,
          }}
        />

        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={this.onSave}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={() => {
            this.props.updateConfig({}, false);
          }}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}

// const mapStateToProps = (state) => {
//   return {
//     analyticsBackendUrl: state.config.analyticsBackendUrl,
//     fullScreenWidget: state.fullScreenWidget,
//   };
// };

export default Config;
