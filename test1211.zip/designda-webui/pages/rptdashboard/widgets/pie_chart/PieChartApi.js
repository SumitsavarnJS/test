import useGlobalStore from "../../../../store/useGlobalStore";
import useConfigStore from "../../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import api from "../../../../common/api/api";

const getPieChartInput = (config) => {
  //Input Json
  const input = {
    bucket: _.get(config, "bucket", ""),
    chart_type: "pie_doughnut",
    key: _.get(config, "dataLocation", ""),
    ldb_file: _.get(config, "data", ""),
    raw_query: _.get(config, "query", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
  };
  const columns = _.get(config, "columns", []);
  if (columns.length > 0) {
    input["columns"] = config.columns;
  }
  return input;
};

// // add columns if provided

// const input=
// {"bucket":"arm-esa","chart_type":"pie_doughnut","key":"c1#task_reports/mup/dhm/vth_constraints/for_vth_constraints_no_l/route_opt/1688358515/mode_test.OC_LEAK.RC_TYP","ldb_file":"das_design_components_data_power.ldb","raw_query":"# Data has been loaded in df variable\n# Please modify the df variable to contain data needed for the plot\n# All columns (numerical) of the 1st row are used for the Pie Chart\ndf = df.compute()","user":"admin","columns":["channel_length","x","y"]}
//   return input;
// };

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url + "/api/run_query",
    input
  );

  console.log(fetchData, input);

  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }

  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
};

const refreshPieChart = (widgetId, config) => {
  fetchWidgetData(widgetId, getPieChartInput(config));
};

export default refreshPieChart;
