// react imports
import React from "react";
import ReactEcharts from "echarts-for-react";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import useGlobalStore from "../../../../store/useGlobalStore";

// utility imprts
import _ from "lodash";
// import axios from "axios";
import Config from "./Config";

import styles from "./MultifeatureBarPlot.module.css";

class MultifeatureBarPlot extends React.Component {
  // consturctor
  constructor(props) {
    super(props);
    this.state = {
      contextMenuOpen: false,
      mousePos: {
        x: null,
        y: null,
      },
      contextMenuInfo: {
        xAxisKey: null,
        xAxisValue: null,
      },
    };
    this.chart = React.createRef();
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      // to set previous session zoom settings
      if (
        this.props.config.zoom &&
        this.props.config.zoom.batch[0] &&
        this.chart &&
        this.chart.current
      ) {
        this.chart.current.getEchartsInstance().dispatchAction({
          type: "dataZoom",
          batch: [
            {
              startValue: this.props.config.zoom.batch[0].startValue,
              endValue: this.props.config.zoom.batch[0].endValue,
            },
          ],
        });
      }
      // to set previous session legend selected settings
      if (this.props.config.legend && this.chart && this.chart.current) {
        let unSelected = [];
        Object.keys(this.props.config.legend).forEach((key) => {
          if (this.props.config.legend[key] == false) {
            unSelected.push(key);
          }
        });
        for (let i = 0; i < unSelected.length; i++) {
          this.chart.current.getEchartsInstance().dispatchAction({
            type: "legendUnSelect",
            name: unSelected[i],
          });
        }
      }
    }
  }
  onChartClick = (params) => {
    const mousePos = {
      x: params.event.event.pageX,
      y: params.event.event.pageY,
    };
    this.setState({
      mousePos: mousePos,
      contextMenuOpen: true,
      xAxisKey: this.props.data.xAxis.name,
      xAxisValue: params.name,
    });
  };
  //to store zoom config
  onZoom = (params) => {
    const config = { ...this.props.config };
    config["zoom"] = params;
    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };
  handleMenuClose = () => {
    this.setState({
      contextMenuOpen: false,
    });
  };
  showDataHandler = () => {
    this.props.showToast({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      severity: "info",
      message: "Work in progress",
    });
    this.handleMenuClose();
  };
  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
    // this.props.toggleShowConfig({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    // });
  };
  //to store legend information
  onLegendChanged = (params) => {
    const config = { ...this.props.config };
    config["legend"] = params.selected;
    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };
  //to store magic type
  onMagictypechanged = (params) => {
    const config = { ...this.props.config };
    if (params.currentType !== "stack") {
      config["series_type"] = params.currentType;
    } else {
      if (
        params.newOption &&
        params.newOption.series[0] &&
        params.newOption.series[0].hasOwnProperty("stack") &&
        params.newOption.series[0].stack !== ""
      ) {
        config["stack"] = params.currentType;
      } else {
        delete config.stack;
      }
    }
    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };
  // render method
  render() {
    // define event dict
    const eventDict = {
      click: this.onChartClick,
      dataZoom: this.onZoom,
      magictypechanged: this.onMagictypechanged,
      legendselectchanged: this.onLegendChanged,
    };

    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (uiState.showConfig) {
      return (
        <Config updateConfig={this.updateConfig} config={this.props.config} />
      );
    } 
    else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <React.Fragment>
          <ReactEcharts
            ref={this.chart}
            style={{ height: "90%" }}
            option={data}
            theme={this.props.theme}
            onEvents={eventDict}
            notMerge={true}
          />
          <Menu
            anchorReference="anchorPosition"
            anchorPosition={{ top: this.state.mousePos.y, left: this.state.mousePos.x }}
            keepMounted
            open={this.state.contextMenuOpen}
            onClose={this.handleMenuClose}
          >
            <MenuItem onClick={this.showDataHandler}>Show Data</MenuItem>
          </Menu>
        </React.Fragment>
      );
    }
  }
}


export default (MultifeatureBarPlot);