import React from "react";

import MarkDownEditor from "./MarkDownEditor";

class DocumentView extends React.Component {
  render() {
    return (
      <div id="documentView" style={{ height: "100%" }}>
        <MarkDownEditor
          text={this.props.text}
          editMode={this.props.editMode}
          handleEdit={this.props.handleEdit}
        />
      </div>
    );
  }
}

DocumentView.defaultProps = {
  text:  "" ,
  editMode: false,
};

export default DocumentView;
