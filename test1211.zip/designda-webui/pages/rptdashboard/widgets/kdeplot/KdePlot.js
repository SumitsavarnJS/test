// react imports
import React from "react";
// import { connect } from "react-redux";
import ReactEcharts from "echarts-for-react";
import Typography from "@mui/material/Typography";

// utility imprts
import _ from "lodash";

 import Config from "./Config";
// import echarts from 'echarts/lib/echarts';

// import actions
// import { setConfig } from "./KdePlotSlice";
// import { toggleShowConfig } from "../../analytics_widget/AnalyticsWidgetSlice";
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";
const theme = useConfigStore.getState().theme;

// css imports
import styles from "./KdePlot.module.css";

class KdePlot extends React.Component {

  // consturctor
  constructor(props) {
    super(props);
    this.state = {};

    this.chart = React.createRef();
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      // to set previous session zoom settings
      if (
        this.props.config.zoom &&
        this.props.config.zoom.batch[0] &&
        this.chart &&
        this.chart.current
      ) {
        this.chart.current.getEchartsInstance().dispatchAction({
          type: "dataZoom",
          batch: [
            {
              startValue: this.props.config.zoom.batch[0].startValue,
              endValue: this.props.config.zoom.batch[0].endValue,
            },
          ],
        });
      }

      // to set previous session legend selected settings
      if (this.props.config.legend && this.chart && this.chart.current) {
        let unSelected = [];
        Object.keys(this.props.config.legend).forEach((key) => {
          if (this.props.config.legend[key] == false) {
            unSelected.push(key);
          }
        });

        for (let i = 0; i < unSelected.length; i++) {
          this.chart.current.getEchartsInstance().dispatchAction({
            type: "legendUnSelect",
            name: unSelected[i],
          });
        }
      }
    }
  }

  //to store legend information
  onLegendChanged = (params) => {
    const config = { ...this.props.config };
    config["legend"] = params.selected;

    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };

  //to store zoom config
  onZoom = (params) => {
    const config = { ...this.props.config };
    config["zoom"] = params;

    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
    // this.props.toggleShowConfig({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    // });
  };

  // render method
  render() {
    // define event dict

    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    const eventDict = {
      dataZoom: this.onZoom,
      legendselectchanged: this.onLegendChanged,
    };

    if (uiState.showConfig) {
      return (
        <Config updateConfig={this.updateConfig} config={this.props.config} />
      );
    }else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <ReactEcharts
          ref={this.chart}
          style={{ height: "90%" }}
          onEvents={eventDict}
          option={data}
          // theme={this.props.theme}
          theme={theme}

          notMerge={true}
        />
      );
    }
  }
}

// const mapDispatchToProps = (dispatch) => {
//   return {
//     setConfig: (payload) => dispatch(setConfig(payload)),
//     toggleShowConfig: (payload) => dispatch(toggleShowConfig(payload)),
//   };
// };

// const mapStateToProps = (state, props) => {
//   return {
//     currentReportName: state.currentReportName,
//     config: state.allReports[state.currentReportName].widgets[props.id].config,
//     data: _.get(state["KDE Plot"], props.id, {}),
//     theme: _.get(state.allReports[state.currentReportName], "theme", "light"),
//     uiState: _.get(state.allReports[state.currentReportName].widgets[props.id], "uiState", {
//       isLoading: false,
//       showConfig: false,
//       isToastOpen: false,
//       toastSeverity: "info",
//       toastMessage: "",
//     }),
//   };
// };

KdePlot.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};

export default KdePlot;
