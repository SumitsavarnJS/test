import React from "react";

import useGlobalStore from "../../../../store/useGlobalStore";
import useConfigStore from "../../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import api from "../../../../common/api/api";
import * as utils from "../../../../common/utils/utils";

const getTableInput = (config) => {
  const input = {
    bucket: _.get(config, "bucket", ""),
    cache_key: _.get(config, "cache_key", ""),
    chart_type: "table",
    key: _.get(config, "dataLocation", ""),
    ldb_file: _.get(config, "data", ""),
    raw_query: _.get(config, "query", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
  };

  // add columns if provided
  const columns = _.get(config, "columns", []);
  if (columns.length > 0) {
    input["columns"] = config.columns;
  }
  const scenario = utils.getScenarioFromDataLoc(
    _.get(config, "dataLocation", "")
  );

  const tempregex = /(__disable_cache = True)/i;
  if (tempregex.test(input.raw_query)) {
    input.cache_key = Date.now().toString()
  }
  input.raw_query =
    `__scenario, __columns, __data = '${scenario}', ${JSON.stringify(_.get(
      config,
      "columns",
      []
    ))}, '${_.get(config, "data", "")}'\n` + input.raw_query;

  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url + "/api/run_query",
    input
  );

  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }

  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }
};

const refreshTableView = (widgetId, config) => {
  fetchWidgetData(widgetId, getTableInput(config));
};

export default refreshTableView;
