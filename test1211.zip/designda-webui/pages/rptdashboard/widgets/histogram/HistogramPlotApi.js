import useGlobalStore from "../../../../store/useGlobalStore";
import useConfigStore from "../../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import api from "../../../../common/api/api";

const getHistogramInput = (config) => {
  const input = {
    bucket: _.get(config, "bucket", ""),
    chart_type: "histogram",
    key: _.get(config, "dataLocation", ""),
    ldb_file: _.get(config, "data", ""),
    raw_query: _.get(config, "query", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
  };

  // const input={"bucket":"TEST_1_projecT","chart_type":"histogram","key":"c0#task_reports/dhrisyk/dhm/2022.12-SP5/pt_vs_pt_20230703-1_tv_0413/route_opt/1602738226/mode_norm.OC_LEAK.RC_TYP","ldb_file":"das_cell_power_data.ldb","raw_query":"# Data has been loaded in df variable\n# Please modify the df variable to contain data needed for the plot\n# 1st column represent the numerical values of a feature.\n# 2nd column represent the points to be highlighted\n# Histogram bin width selection: Scott estimators.\n# KDE estimation: Gaussian\ndf =df.compute()","user":"dhrisyk","columns":["total_dynamic_power"]}

  // add columns if provided
  const columns = _.get(config, "columns", []);
  if (columns.length > 0) {
    input["columns"] = config.columns;
  }

  //   // if data was stacked
  //   if (config.stack) {
  //     input["stack"] = _.get(config, "stack", "");
  //   }

  //   // get series type
  //   input["series_type"] = _.get(config, "series_type", "bar");

  //   if (_.get(config, "groupingAxis", "Y") === "Y") {
  //     input["chart_type"] = "bar_line";
  //   } else {
  //     input["chart_type"] = "bar_stack";
  //   }

  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url + "/api/run_query",
    input
  );

  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }

  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
};

const refreshHistogramPlotData = (widgetId, config) => {
  fetchWidgetData(widgetId, getHistogramInput(config));
};

export default refreshHistogramPlotData;
