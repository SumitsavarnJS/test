import useGlobalStore from "../../../../store/useGlobalStore";
import useConfigStore from "../../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import api from "../../../../common/api/api";

export const getValueFromObj = (obj, path, defaultValue) => {
  const value = _.get(obj, path, defaultValue);
  return value.length === 0 ? defaultValue : value;
}

const getTimingPathMatrixInput = (config) => {
  const input = {
    bucket: _.get(config, "bucket", ""),
    key: _.get(config, "dataLocation", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
    feature: getValueFromObj(config, "feature", "TNS"), // adding default value TNS (temp solution)
    level: getValueFromObj(config, "level", 1), // adding default value 1 (temp solution)
    pathCategory: getValueFromObj(config, "pathCategory", "All"), // adding default value All (temp solution)
    skipLevel: _.get(config, "skipLevel", 0),
    sp_inst: _.get(config, "sp_inst", ""),
    ep_inst: _.get(config, "ep_inst", ""),
    query: _.get(config, "query", "df = df.compute()"),
  };
  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/api/fetch_timing_path_matrix",
    input
  );

  const newUiState = produce(uiState, (uiStateDraft) => {
    if (!fetchData.data.status) {
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    }
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (
    fetchData &&
    fetchData.data &&
    Object.keys(fetchData.data).length &&
    fetchData.data.status
  ) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }
};

const refreshTimingPathMatrix = (widgetId, config) => {
  fetchWidgetData(widgetId, getTimingPathMatrixInput(config));
};

export default refreshTimingPathMatrix;
