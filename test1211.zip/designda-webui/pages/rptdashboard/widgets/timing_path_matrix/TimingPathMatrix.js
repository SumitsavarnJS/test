// react imports
import React from "react";
import Typography from "@mui/material/Typography";
import ReactEcharts from "echarts-for-react";
import { produce } from "immer";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import axios from "axios";

// utility imports
import _ from "lodash";
import Config from "./Config";

import useGlobalStore from "../../../../store/useGlobalStore";
import useConfigStore from "../../../../store/useConfigStore";

import {
  addWidgetCommonFunction,
  showWidgetDataUiState,
} from "../../addWidget/addWidget";

// css imports
import styles from "./TimingPathMatrix.module.css";
import { Stack } from "@mui/material";

class TimingPathMatrix extends React.Component {
  // constructor
  constructor(props) {
    super(props);
    this.state = {
      contextMenuOpen: false,
      mousePos: {
        x: 0,
        y: 0,
      },
    };
  }

    // as component mounts, find the parent div for the inter-clock-matrix widget and
  // disable right click on that div
  componentDidMount() {
    const widgetDiv = document.getElementById("timingPathMatrixId");
    if (widgetDiv) {
      widgetDiv.addEventListener("contextmenu", (e) => {
        e.preventDefault();
      });
    }
  }

  showToast = (toast) => {
    const uiState = produce(
      useGlobalStore.getState()[this.props.id].uiState,
      (uiStateDraft) => {
        uiStateDraft.isToastOpen = true;
        uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
        uiStateDraft.toastMessage = _.get(toast, "message", "");
      }
    );
    useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  setLoading = (loadingProps) => {
    const uiState = produce(
      useGlobalStore.getState()[this.props.id].uiState,
      (uiStateDraft) => {
        uiStateDraft.cirlularLoading = _.get(
          loadingProps,
          "cirlularLoading",
          false
        );
      }
    );
    useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  addWidgets = (props) => {
    for (let i = 0; i < props.widgets.length; i++) {
      const widgetsSettings = produce(props.widgets[i], (settingsDraft) => {
        delete settingsDraft.currentReportName;
        delete settingsDraft.data;
      });

      const data = _.get(props.widgets[i], "data", {});

      console.log(
        this.props.rptType,
        this.props.reportKey,
        widgetsSettings,
        data,
        showWidgetDataUiState,
        this.props.index
      );
      addWidgetCommonFunction(
        this.props.rptType,
        this.props.reportKey,
        widgetsSettings,
        data,
        showWidgetDataUiState,
        this.props.index
      );
    }
  };

  showTimingPaths = () => {
    this.setState({ isLoading: true });
    const config = this.props.widgetProps.config;

    const request = {
      startPoint: this.state.sp,
      endPoint: this.state.ep,
      bucket: _.get(config, "bucket"),
      key: _.get(config, "dataLocation", ""),
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_timing_paths_from_matrix",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", {});
        const dataLocation = _.get(response, "dataLocation", {});
        const data = _.get(response, "file", {});
        const query = _.get(response, "query", "");
        const bucket = _.get(response, "bucket", {});
        const col = _.get(response, "columns", []);
        const initCol = _.get(response, "initCol", []);
        const rows = _.get(response, "rows", []);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          console.log("from matrix:", dataLocation);
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 13,
                y: yCoord + 1,
                config: {
                  title: dataLocation.includes("task_reports")
                    ? `Degrading Timing Paths from ${this.state.sp} to ${this.state.ep}`
                    : `Timing Paths from ${this.state.sp} to ${this.state.ep}`,
                  dataLocation: dataLocation,
                  data: data,
                  bucket: bucket,
                  query: "df = df.sort_values('slack', ascending = True)", //query,
                  columns: initCol,
                  cache_key: cache_key,
                },
                data: { columns: col },
              },
            ],
          });
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Timing Paths",
        });
        this.setState({ isLoading: false });
      });
    this.handleMenuClose();
  };

  //Function to add Layout
  addInstanceLayout = () => {
    this.setState({ isLoading: true });
    this.handleMenuClose();
    let object = null;
    const config = this.props.widgetProps.config;
    let sp = this.state.sp;
    let ep = this.state.ep;
    sp = sp.replace("/--", "");
    ep = ep.replace("/--", "");
    if (sp.localeCompare(ep) == 0) {
      object = [sp];
    } else {
      object = [sp, ep];
    }

    if (object.length == 0) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Please select instance value to fetch Layout View",
      });
      this.setState({ isLoading: false });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros", "blockages"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: "das_hier_inst_power_data.ldb",
                  title: object[1]
                    ? `{Instance Layout for ${object[0]} and ${object[1]}}`
                    : `{Instance Layout for ${object[0]}}`,
                  bucket: _.get(config, "bucket", ""),
                  instance_value: object,
                  // ttype: row.data.__ttype,
                  dataLocation: _.get(config, "dataLocation", ""),
                  // scenario: row.data.__object.split("/")[0],
                  instanceContainer: true,
                  activeZoom: true,
                },
              },
            ],
          });
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setState({ isLoading: false });
      });
  };
  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  formatTooltip = (params) => {
    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    return `<div style="font-weight: bold">
    <span style="color:blue">From:</span> ${
      data.sp_list[params.data[1]]
    }<br />
            <span style="color:green">To:</span> ${
              data.ep_list[params.data[0]]
            }<br />
            <span style="color: red">${
              this.props.widgetProps.config.feature
            }: </span>${params.data[2]}</div>`;
  };

  showGridTileLabel = () => {
    // const dimensions = _.get(this.props, "dimensions", { w: 0, h: 0 });
    // const ep_list = _.get(this.props.data, "ep_list", []);
    // if (dimensions.w / ep_list.length > 1.2) {
    return true;
    // }
    // return false;
  };

  showDiagnosticSummary = () => {
    this.setState({ isLoading: true });
    const config = this.props.widgetProps.config;

    const bucket = _.get(config, "bucket", "");
    const dataLocation = _.get(config, "dataLocation", "");
    const request = {
      bucket: bucket,
      key: dataLocation,
      feature: _.get(config, "feature", ""),
      level: _.get(config, "level", 1) + 1,
      skipLevel: _.get(config, "level", 0),
      pathCategory: _.get(config, "pathCategory", ""),
      sp_inst: this.state.sp,
      ep_inst: this.state.ep,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_diagnostic_summary",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        const data = _.get(response, "data", {});
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Group Bar Chart",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                config: {
                  title: `Timing Path Diagnostics Summary : From {${this.state.sp}} to {${this.state.ep}}`,
                  dataLocation: dataLocation,
                  bucket: bucket,
                  data: "das_timing_path_data.ldb",
                  columns: _.get(data, "columns"),
                  // query: _.get(data, "query", defaultQueryBody),
                  groupingAxis: "X",
                },
                data: _.get(data, "data", {}),
              },
            ],
          });
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to show diagnostic summary",
        });
        this.setState({ isLoading: false });
      });
    this.handleMenuClose();
  };

  onContextMenu = (params, e) => {
    // show context menu for task data only
    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});

    const mousePos = {
      x: params.event.event.pageX,
      y: params.event.event.pageY,
    };
    this.setState({
      mousePos: mousePos,
      contextMenuOpen: true,
      sp: data.sp_list[params.data[1]],
      ep: data.ep_list[params.data[0]],
    });
  };

  exapandMatrix = () => {
    this.setState({ isLoading: true });
    const config = this.props.widgetProps.config;

    const bucket = _.get(config, "bucket", "");
    const dataLocation = _.get(config, "dataLocation", "");
    const request = {
      bucket: bucket,
      key: dataLocation,
      feature: _.get(config, "feature", ""),
      level: _.get(config, "level", 1) + 1,
      skipLevel: _.get(config, "level", 0),
      pathCategory: _.get(config, "pathCategory", ""),
      sp_inst: this.state.sp,
      ep_inst: this.state.ep,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_timing_path_matrix",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        const data = _.get(response, "data", {});
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Timing Path Matrix",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                config: {
                  title: `Timing Path Matrix for start point instance {${this.state.sp}} and end point instance {${this.state.ep}} `,
                  dataLocation: dataLocation,
                  bucket: bucket,
                  // query: _.get(config, "query", defaultQueryBody),
                  sp_inst: this.state.sp,
                  ep_inst: this.state.ep,
                  level: _.get(config, "level", 1) + 1,
                  levelList: _.get(config, "levelList"),
                  feature: _.get(config, "feature", ""),
                  pathCategory: _.get(config, "pathCategory", ""),
                },
                data: data,
              },
            ],
          });
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Timing Paths",
        });
        this.setState({ isLoading: false });
      });
    this.handleMenuClose();
  };

  /**
   *
   */
  handleMenuClose = () => {
    this.setState({
      contextMenuOpen: false,
    });
  };

  render() {
    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (!this.chart) {
      this.chart = React.createRef();
    }
    // define event dict
    const eventDict = {
      contextmenu: this.onContextMenu,
    };
    if (Object.keys(data).length > 0) {
      console.log(data);
      var option = produce(data.option, (optionDraft) => {
        optionDraft["tooltip"]["formatter"] = this.formatTooltip;
        optionDraft["tooltip"]["position"] = "top";
        optionDraft["tooltip"]["confine"] = true;
        optionDraft["lazyUpdate"] = true;
        optionDraft["series"][0]["label"]["show"] = this.showGridTileLabel();
      });
    }
    console.log(data);
    

    if (uiState.showConfig) {
      return (
        <Config
          updateConfig={this.updateConfig}
          config={this.props.widgetProps.config}
        />
      );
    } else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No Data. Please refresh this widget!
        </Typography>
      ) : (
        <React.Fragment>
          <div id="timingPathMatrixId" className={styles.matrixDiv}>
            <ReactEcharts
              ref={this.chart}
              onEvents={eventDict}
              style={{ height: "100%" }}
              option={option}
              // theme={this.props.theme}
              notMerge={true}
            />

            <Menu
              anchorReference="anchorPosition"
              anchorPosition={{
                top: this.state.mousePos.y,
                left: this.state.mousePos.x,
              }}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              variant="menu"
              keepMounted
              open={this.state.contextMenuOpen}
              style={{ display: "block" }}
              onClose={this.handleMenuClose}
            >
              <Stack>
                <MenuItem onClick={this.showTimingPaths}>
                  Show Timing Paths
                </MenuItem>
                {_.get(this.props.widgetProps.config, "dataLocation", "#")
                  .split("#")[1]
                  .startsWith("task") ? (
                  <MenuItem onClick={this.addInstanceLayout}>
                    Show in layout
                  </MenuItem>
                ) : null}
                {!_.get(this.state, "ep", "").endsWith("--") ||
                !_.get(this.state, "ep", "").endsWith("--") ? (
                  <MenuItem
                    style={{ width: "100%" }}
                    onClick={this.exapandMatrix}
                  >
                    Expand
                  </MenuItem>
                ) : null}
                {_.get(this.props.widgetProps.config, "dataLocation", "#")
                  .split("#")[1]
                  .startsWith("task") ? (
                  <MenuItem onClick={this.showDiagnosticSummary}>
                    Show Diagnostics Summary
                  </MenuItem>
                ) : null}
              </Stack>
            </Menu>
            <div className={styles.footer}>
              Feature: {_.get(this.props.widgetProps.config, "feature", "")}{" "}
              &ensp; Level:
              {_.get(this.props.widgetProps.config, "level", "")} &ensp; Path
              category:
              {_.get(this.props.widgetProps.config, "pathCategory", "")}
            </div>
          </div>
        </React.Fragment>
      );
    }
  }
}

TimingPathMatrix.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};

export default TimingPathMatrix;
