import React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import dynamic from "next/dynamic";

// utility imports
import _ from "lodash";
import axios from "axios";

// data source table
import DataSource from "../../data_source/DataSource";
import useConfigStore from "../../../../store/useConfigStore";
import { Box } from "@mui/material";
import { ClickAwayListener } from "@mui/base";
import { getValueFromObj } from "./TimingPathMatrixApi";
const AceEditor = dynamic(
    () => import("react-ace").then((mod) => mod.default),
    { ssr: false }
  );

import styles from "./Config.module.css";

const defaultQueryBody = `# Query will be executed before filtering the resultant data with the above selected config.
# Data has been loaded in df variable
# All columns are loaded in the df and listed below according to the Data source
# Don't modify/drop the names of the columns
# task_columns = ["start_point_instance", "end_point_instance", "WNS", "TNS", "NVP", "path_count", "violating_paths", "path_category"]
# flow_columns = ["start_point_instance","end_point_instance", "delta_tns","delta_wns", "delta_nvp","delta_path_count"]
df = df.compute()`;


class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      dataLocation: _.get(this.props.config, "dataLocation", ""),
      bucket: _.get(this.props.config, "bucket", ""),
      feature: getValueFromObj(this.props.config, "feature", "TNS"), // adding default value TNS (temp solution)
      level: getValueFromObj(this.props.config, "level", 1), // adding default value 1 (temp solution)
      pathCategory: getValueFromObj(this.props.config, "pathCategory", "All"), // adding default value All (temp solution)
      levelList: _.get(this.props.config, "levelList", []),
      sp_inst: _.get(this.props.config, "sp_inst", ""),
      ep_inst: _.get(this.props.config, "ep_inst", ""),
    };
    this.query = _.get(this.props.config, "query", defaultQueryBody);
  }
  componentDidMount() {
    const config = _.get(this.props, "config", {});
    const bucket = _.get(config, "bucket", "");
    const key = _.get(config, "dataLocation", "");
    if (bucket && key) {
      this.setLevelList(bucket, key);
    }
  }
  
  dataLocationChanged = (newDataLocation, bucket) => {
    this.setState({
      bucket: bucket,
      dataLocation: newDataLocation,
    });
    this.setLevelList(bucket, newDataLocation);
  };
  setLevelList = (bucket, newDataLocation) => {
    const data = { bucket: bucket, key: newDataLocation };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") + "/api/fetch_max_matrix_level",data)
      .then((response) => {
        const data = _.get(response.data, "data", {});
        if (!_.get(response.data, "status", true)) {
          this.props.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message:
              "Required files are not avaiable for the selected data source",
          });
        }
        this.setState({ levelList: _.get(data, "levels", []) });
        const config = _.get(this.props, "config", {});
        if (_.get(config, "dataLocation", "") !== newDataLocation) {
          this.setState({ level: "" });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };
  onQueryChange = (newQuery) => {
    this.query = newQuery;
  };
  onSave = () => {
    const config = {};
    config["dataLocation"] = this.state.dataLocation;
    config["query"] = this.query;
    config["feature"] = this.state.feature;
    config["pathCategory"] = this.state.pathCategory;
    config["level"] = this.state.level;
    config["bucket"] = this.state.bucket;
    config["levelList"] = this.state.levelList;
    config["sp_inst"] = this.state.sp_inst;
    config["ep_inst"] = this.state.ep_inst;
    // add title only if user has provided it
    if (this.state.title.length > 0) {
      config["title"] = this.state.title;
    }
    this.props.updateConfig(config, true);
  };
  //disable Ok button if required fileds are not selected
  disableOk = () => {
    const config = this.state;
    if (
      config.dataLocation &&
      config.dataLocation.split("#")[1].startsWith("flow") &&
      config.level &&
      config.feature
    ) {
      return false;
    } else if (
      config.dataLocation &&
      config.dataLocation.split("#")[1].startsWith("task") &&
      config.level &&
      config.feature &&
      config.pathCategory
    ) {
      return false;
    }
    return true;
  };
  helperText = (property) => {
    if (!this.state[property]) {
      return "Entry required";
    }
  };
  showErrorInput = (property) => {
    if (!this.state[property]) {
      return true;
    }
    return false;
  };

  
  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Select Data Source if it is not derived*/}
        
          <div className={styles.inline}>           
            <Button
                size="small"
                classes={{ root: styles.add_button }}
                onClick={() => this.setState({ showDataSource: true })}
            >
                Data Source
            </Button>
            {this.state.showDataSource ? (
                <ClickAwayListener
                onClickAway={() => {
                    this.setState({ showDataSource: false });
                }}
                >
                <Box
                    sx={{
                    zIndex: "5",
                    position: "absolute",
                    top: "0px",
                    left: "0px",
                    width: "100%",
                    height: "fit-content",
                    backgroundColor: "white",
                    padding: "5px",
                    boxShadow: "grey 5px 5px 5px",
                    }}
                >
                    <DataSource
                    dataLocationChanged={this.dataLocationChanged}
                    dataLocation={this.state.dataLocation}
                    bucket={this.state.bucket}
                    close={() => {
                        this.setState({ showDataSource: false });
                    }}
                    />
                </Box>
                </ClickAwayListener>
            ) : null}
            <Typography
                variant="body2"
                style={{ marginTop: "15px", marginLeft: "15px" }}
            >
                {this.state.dataLocation.split("#")[1]}
            </Typography>
          </div>
        

        {/* Select Feature */}
        <Autocomplete
          id="data-input"
          style={{ marginTop: "10px" }}
          value={this.state.feature}
          onChange={(event, newValue) => {
            this.setState({ feature: newValue });
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={
            this.state.dataLocation &&
            this.state.dataLocation.split("#")[1].startsWith("flow")
              ? ["delta_tns", "delta_wns", "delta_nvp", "delta_path_count"]
              : ["TNS", "WNS", "NVP", "path_count"]
          }
          renderInput={(params) => (
            <TextField
              {...params}
              required
              error={this.showErrorInput("feature")}
              helperText={this.helperText("feature")}
              label="Feature"
              variant="outlined"
            />
          )}
        />
        {/* Select Path category */}
        {this.state.dataLocation &&
        this.state.dataLocation.split("#")[1].startsWith("flow") ? null : (
          <Autocomplete
            id="data-input"
            style={{ marginTop: "10px" }}
            value={this.state.pathCategory}
            onChange={(event, newValue) => {
              this.setState({ pathCategory: newValue });
            }}
            classes={{
              option: styles.option,
            }}
            size="small"
            options={[
              "All",
              "Reg2Reg",
              "Reg2Icg",
              "Macro2Reg",
              "Reg2Macro",
              "Macro2Icg",
              "Reg2Out",
              "In2Reg",
              "In2Icg",
              "In2Macro",
              "Macro2Macro",
              "In2Out",
            ]}
            renderInput={(params) => (
              <TextField
                {...params}
                required
                error={this.showErrorInput("pathCategory")}
                helperText={this.helperText("pathCategory")}
                label="Path category"
                variant="outlined"
              />
            )}
          />
        )}
        {/* Select level */}
        <Autocomplete
          id="data-input"
          style={{ marginTop: "10px" }}
          value={this.state.level}
          onChange={(event, newValue) => {
            this.setState({ level: newValue });
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.levelList}
          getOptionLabel={(option) => option.toString()}
          renderInput={(params) => (
            <TextField
              {...params}
              required
              error={this.showErrorInput("level")}
              helperText={this.helperText("level")}
              label="level"
              variant="outlined"
            />
          )}
        />
        {/* Code editor */}
        <Typography variant="subtitle1" className={styles.label}>
          Query Editor
        </Typography>

        <AceEditor
          placeholder="Please modify df object depending on the query."
          mode="python"
          theme="xcode"
          name="code_editor"
          width="100%"
          // onLoad={this.onLoad}
          onChange={(value, event) => {
            this.onQueryChange(value);
          }}
          fontSize={16}
          maxLines={Infinity}
          showPrintMargin={true}
          showGutter={true}
          highlightActiveLine={true}
          value={this.query}
          setOptions={{
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: true,
            enableSnippets: false,
            showLineNumbers: true,
            tabSize: 2,
          }}
        />

        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={this.onSave}
          classes={false ? { root: styles.save_button_disabled } : { root: styles.save_button }}
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={() => {
            this.props.updateConfig({}, false);
          }}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}

export default (Config);
