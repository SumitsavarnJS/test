import useGlobalStore from "../../../../store/useGlobalStore";
import useConfigStore from "../../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import api from "../../../../common/api/api";

const getPieChartInput = (config) => {
  //   const input = {
  //     bucket: _.get(config, "bucket", ""),
  //     key: _.get(config, "dataLocation", ""),
  //     ldb_file: _.get(config, "data", ""),
  //     raw_query: _.get(config, "query", ""),
  //     user: "girjeshs",
  //   };

  //   // add columns if provided
  //   const columns = _.get(config, "columns", []);
  //   if (columns.length > 0) {
  //     input["columns"] = config.columns;
  //   }

  //   const input = {
  //     bucket: _.get(config, "bucket", ""),
  //     chart_type: "pie_doughnut",
  //     key: _.get(config, "dataLocation", ""),
  //     ldb_file: _.get(config, "data", ""),
  //     raw_query: _.get(config, "query", ""),
  //     user: 'girjeshs',
  //   };

  const input = {
    bucket: _.get(config, "bucket", ""),
    chart_type: "multi_boxplot",
    key: _.get(config, "dataLocation", ""),
    ldb_file: _.get(config, "data", ""),
    raw_query: _.get(config, "query", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
  };

  // add columns if provided
  const columns = _.get(config, "columns", []);
  if (columns.length > 0) {
    input["columns"] = config.columns;
  }

  //   // if data was stacked
  //   if (config.stack) {
  //     input["stack"] = _.get(config, "stack", "");
  //   }

  //   // get series type
  //   input["series_type"] = _.get(config, "series_type", "bar");

  //   if (_.get(config, "groupingAxis", "Y") === "Y") {
  //     input["chart_type"] = "bar_line";
  //   } else {
  //     input["chart_type"] = "bar_stack";
  //   }

  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url + "/api/run_query",
    input
  );

  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }

  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
};

const refreshMultiBoxPlotData = (widgetId, config) => {
  fetchWidgetData(widgetId, getPieChartInput(config));
};

export default refreshMultiBoxPlotData;
