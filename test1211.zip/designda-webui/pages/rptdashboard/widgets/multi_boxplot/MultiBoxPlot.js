// react imports
import React from "react";
import { connect } from "react-redux";
import ReactEcharts from "echarts-for-react";
import Typography from "@mui/material/Typography";

// utility imprts
import _ from "lodash";

// import Config from "./Config";
// import echarts from 'echarts/lib/echarts';

// import actions
// import { setConfig } from "./MultiBoxPlotSlice";
// import { toggleShowConfig } from "../../analytics_widget/AnalyticsWidgetSlice";

// css imports
import styles from "./MultiBoxPlot.module.css";

class MultiBoxPlot extends React.Component {
  // constructor
  constructor(props) {
    super(props);
    this.state = {};
    this.chart = React.createRef();
  }

  // Function to get option
  getEchartsOption(option) {
    function renderItem(params, api) {
      var yValue = api.value(1);
      var start = api.coord([api.value(0), yValue]);
      var size = api.size([api.value(2) - api.value(0), yValue]);
      var style = api.style();
      return {
        type: "rect",
        shape: {
          x: start[0] + 1,
          y: start[1],
          width: size[0] - 2,
          height: size[1],
        },
        style: style,
      };
    }
    option["renderItem"] = renderItem;
    return option;
  }

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      this.props.setConfig({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        config: config,
      });
    }

    this.props.toggleShowConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
    });
  };

  // render method
  render() {
    if (this.props.uiState.showConfig) {
      // return (
      //   <Config updateConfig={this.updateConfig} config={this.props.config} />
      // );
      return null;
    } else {
      return Object.keys(this.props.data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <ReactEcharts
          ref={this.chart}
          style={{ height: "90%" }}
          option={this.getEchartsOption({ ...this.props.data })}
          theme={this.props.theme}
          notMerge={true}
        />
      );
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    setConfig: (payload) => dispatch(setConfig(payload)),
    toggleShowConfig: (payload) => dispatch(toggleShowConfig(payload)),
  };
};

const mapStateToProps = (state, props) => {
  return {
    currentReportName: state.currentReportName,
    config: state.allReports[state.currentReportName].widgets[props.id].config,
    data: _.get(state["Multi Box Plot"], props.id, {}),
    theme: _.get(state.allReports[state.currentReportName], "theme", "light"),
    uiState: _.get(
      state.allReports[state.currentReportName].widgets[props.id],
      "uiState",
      {
        isLoading: false,
        showConfig: false,
        isToastOpen: false,
        toastSeverity: "info",
        toastMessage: "",
      }
    ),
  };
};

// };
MultiBoxPlot.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};

export default MultiBoxPlot;
