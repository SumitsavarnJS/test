// react imports
import React from "react";
// import { connect } from "react-redux";
import ReactEcharts from "echarts-for-react";
import Typography from "@mui/material/Typography";

// utility imprts
import _ from "lodash";
// import axios from "axios";

// import Config from "./Config";
// // import echarts from 'echarts/lib/echarts';

// // import actions
// import { setConfig } from "./TreemapSlice";
// import { toggleShowConfig } from "../../analytics_widget/AnalyticsWidgetSlice";

// css imports
import styles from "./Treemap.module.css";
import Config from "./Config";
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";
const theme = useConfigStore.getState().theme;


class Treemap extends React.Component {
  // consturctor
  constructor(props) {
    super(props);
  }

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
    // this.props.toggleShowConfig({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    // });
  };
  // render method
  render() {
    // define event dict
    // const eventDict = {
    //   'click': this.onChartClick
    // }

    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });


    if (uiState.showConfig) {
      return (
        <Config updateConfig={this.updateConfig} config={this.props.config} />
      );
    }  else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <React.Fragment>
          {/* Chart widget */}
          <ReactEcharts
            style={{ height: "100%" }}
            option={data}
            // theme={this.props.theme}
            notMerge={true}
          />
        </React.Fragment>
      );
    }
  }
}

// const mapDispatchToProps = (dispatch) => {
//   return {
//     setConfig: (payload) => dispatch(setConfig(payload)),
//     toggleShowConfig: (payload) => dispatch(toggleShowConfig(payload)),
//   };
// };

// const mapStateToProps = (state, props) => {
//   return {
//     currentReportName: state.currentReportName,
//     config: state.allReports[state.currentReportName].widgets[props.id].config,
//     data: _.get(state["Treemap"], props.id, {}),
//     theme: _.get(state.allReports[state.currentReportName], "theme", "light"),
//     uiState: _.get(state.allReports[state.currentReportName].widgets[props.id], "uiState", {
//       isLoading: false,
//       showConfig: false,
//       isToastOpen: false,
//       toastSeverity: "info",
//       toastMessage: "",
//     }),
//   };
// };

Treemap.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};

export default Treemap;
