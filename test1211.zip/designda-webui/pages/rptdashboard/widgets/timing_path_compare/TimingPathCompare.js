// react imports
import React from "react";
import { connect } from "react-redux";
import Typography from "@mui/material/Typography";
import { ReactTabulator } from "react-tabulator";

// utility imports
import _ from "lodash";

import Config from "./Config";
//import stores
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";

// // import actions
// import { setConfig } from "./TimingPathCompareSlice";
// import { showToast,toggleShowConfig } from "../../analytics_widget/AnalyticsWidgetSlice";

// css imports
import styles from "./TimingPathCompare.module.css";

var theme = useConfigStore.getState().theme;

class TimingPathCompare extends React.Component {
  // constructor
  constructor(props) {
    super(props);
    this.state = {};
  }

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  enable_filter = () => {
    let col = _.cloneDeep(
      _.get(useGlobalStore.getState()[this.props.id], "data", {}).columns
    );
    for (let x = 0; x < col.length; x++) {
      if (
        col[x].field === "__object" ||
        col[x].field === "__obtype" ||
        col[x].field === "__ttype"
      ) {
        col[x].visible = false;
      }
      if (col[x].columns) {
        let len = col[x].columns.length;
        for (let y = 0; y < len; y++) {
          if (
            col[x].columns[y].field === "__object" ||
            col[x].columns[y].field === "__obtype" ||
            col[x].columns[y].field === "__ttype"
          ) {
            col[x].columns[y].visible = false;
          }
        }
      }
    }
    return col;
  };

  enable_rows = () => {
    let rows = _.cloneDeep(
      _.get(useGlobalStore.getState()[this.props.id], "data", {}).rows
    );

    return rows;
  };
  applyTheme = (theme) => {
    if (theme == "dark") {
      return "table-sm table-dark table-striped table-bordered";
    } else {
      return "table-sm table-striped table-bordered";
    }
  };

  render() {
    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (uiState.showConfig) {
      return (
        <Config updateConfig={this.updateConfig} config={this.props.config} />
      );
    } else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          Sorry! This widget is currently not designed to reload data
        </Typography>
      ) : (
        <div id="analytics">
          <ReactTabulator
            key={theme} // Do not remove this, otherwise it breaks theme functionalities
            className={this.applyTheme(theme)}
            layout="fitColumns"
            autoResize={false}
            columns={data.columns ? this.enable_filter() : []}
            data={data.rows? this.enable_rows() :[]}
            options={{
              maxHeight: "80%",
              columnDefaults: {
                headerFilter: true,
                headerFilterLiveFilter: false,
                headerFilterPlaceholder: "...",
                tooltip: true,
              },
              persistenceID: _.get(this.props.config, "tableId", this.props.id),
              persistentLayout: false,
              persistence: {
                sort: true, //persist column sorting
                filter: true, //persist filter sorting
                page: true, //persist page
                columns: true, //persist columns
              },
              pagination: "local",
              paginationSize: "10",
              paginationInitialPage: 1,
            }}
            initialSort={[{ column: "sort_identifier", dir: "desc" }]}
          />
        </div>
      );
    }
  }
}

export default TimingPathCompare;
