// react imports
import React from "react";
// import { connect } from "react-redux";
import Typography from "@mui/material/Typography";
import { ReactTabulator } from "react-tabulator";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";

// utility imports
import _ from "lodash";

import Config from "./Config";

// import actions
// import { setConfig } from "./TimingPathSummarySlice";
// import { showToast, toggleShowConfig } from "../../analytics_widget/AnalyticsWidgetSlice";

// css imports
import styles from "./TimingPathSummary.module.css";

var theme = useConfigStore.getState().theme;

class TimingPathSummary extends React.Component {
  // constructor
  constructor(props) {
    super(props);
    this.state = {};
    this.dominantNetsRef = React.createRef();
    this.timingPathSummaryRef = React.createRef();
    this.dominantCellsRef = React.createRef();
  }

  dominantCellsColumn = [{ title: "Dominant Cells", field: "dominant_cells" }];
  dominantNetsColumn = [{ title: "Dominant Nets", field: "dominant_nets" }];
  timingPathSummaryColumns = [
    { title: "Attribute", field: "attribute" },
    { title: "Value", field: "value", formatter: "textarea" },
  ];

  componentDidMount() {
    this.dominantNetsTable = new Tabulator(this.dominantNetsRef.current, {
      pagination: "local",
      paginationSize: "10",
      columnDefaults: {
        tooltip: true,
      },
      layout: "fitColumns",
      autoResize: false,
      columns: this.dominantNetsColumn,
    });

    this.tableSumTable = new Tabulator(this.timingPathSummaryRef.current, {
      pagination: "local",
      paginationSize: "10",
      columnDefaults: {
        tooltip: true,
      },
      layout: "fitColumns",
      autoResize: false,
      columns: this.timingPathSummaryColumns,
      data: _.cloneDeep(
        useGlobalStore.getState()[this.props.id].data.timing_path_summary
      ),
    });

    this.dominantCellsTable = new Tabulator(this.dominantCellsRef.current, {
      pagination: "local",
      paginationSize: "10",
      columnDefaults: {
        tooltip: true,
      },
      layout: "fitColumns",
      autoResize: false,
      columns: this.dominantCellsColumn,
      data: _.cloneDeep(
        useGlobalStore.getState()[this.props.id].data.dominant_cells
      ),
    });
  }

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  applyTheme = (theme) => {
    if (theme == "dark") {
      return "table-sm table-dark table-striped table-bordered";
    } else {
      return "table-sm table-striped table-bordered";
    }
  };

  render() {
    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (uiState.showConfig) {
      return (
        <Config
          updateConfig={this.updateConfig}
          config={this.props.config}
          columnList={data.column_list}
        />
      );
    } else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          Sorry! This widget is currently not designed to reload data
        </Typography>
      ) : (
        <div id="analytics">
          <div
            key={theme}
            className={this.applyTheme(theme)}
            ref={(ref) => (this.timingPathSummaryRef.current = ref)}
          />
          {/* <ReactTabulator
            key={theme} // Do not remove this, otherwise it breaks theme functionalities
            className={this.applyTheme(theme)}
            layout="fitColumns"
            autoResize={false}
            onRef={(ref) => (this.timingPathSummaryRef = ref)}
            columns={this.timingPathSummaryColumns}
            data={data.timing_path_summary}
            // tooltips={true}
            options={{
              headerVisible: false,
              columnDefaults: {
                tooltip: true,
              },
            }}
          /> */}

          {data && data.dominant_cells && data.dominant_cells.length > 0 ? (
            <div
              key={theme}
              className={this.applyTheme(theme)}
              style={{ marginTop: "10px" }}
              ref={(ref) => (this.dominantCellsRef.current = ref)}
            />
          ) : // <ReactTabulator
          //   key={theme} // Do not remove this, otherwise it breaks theme functionalities
          //   className={this.applyTheme(theme)}
          //   style={{ marginTop: "10px" }}
          //   layout="fitColumns"
          //   autoResize={false}
          //   onRef={(ref) => (this.dominantCellsRef = ref)}
          //   columns={this.dominantCellsColumn}
          //   data={data.dominant_cells}
          //   // tooltips={true}
          //   options={{
          //     pagination: "local",
          //     paginationSize: "10",
          //     columnDefaults: {
          //       tooltip: true,
          //     },
          //   }}
          // />
          null}

          {data && data.dominant_cells && data.dominant_cells.length > 0  ? (
            <div
              key={theme}
              className={this.applyTheme(theme)}
              style={{ marginTop: "10px" }}
              ref={(ref) => (this.dominantNetsRef.current = ref)}
            />
          ) : // <ReactTabulator
          //   key={theme} // Do not remove this, otherwise it breaks theme functionalities
          //   className={this.applyTheme(theme)}
          //   style={{ marginTop: "10px" }}
          //   layout="fitColumns"
          //   autoResize={false}
          //   onRef={(ref) => (this.dominantNetsRef = ref)}
          //   columns={this.dominantNetsColumn}
          //   // data={data.dominant_nets}
          //   // tooltips={true}
          //   options={{
          //     pagination: "local",
          //     paginationSize: "10",
          //     columnDefaults: {
          //       tooltip: true,
          //     },
          //   }}
          // />
          null}
        </div>
      );
    }
  }
}

export default TimingPathSummary;
