import useGlobalStore from "../../../../store/useGlobalStore";
import React, { Component } from "react";
import { ReactTabulator, reactFormatter } from "react-tabulator";
// import { globFilter } from "common/Funcs";
import ProgressBar from "react-bootstrap/ProgressBar";
import useConfigStore from "../../../../store/useConfigStore";

// utility imports
import axios from "axios";
import _ from "lodash";


var theme = useConfigStore.getState().theme;

function TaskProgressBar(props) {
    const rowData = props.cell._cell.row.data;
    const status = rowData.status;
    let variant = "primary";
    if (status === "success") {
        variant = "success";
    } else if (status === "failed") {
        variant = "danger";
    }



    return (

        <React.Fragment>

            <ProgressBar

                now={rowData.progress}

                variant={variant}

                label={`${rowData.progress}%`}

            />

        </React.Fragment>

    );

}



class TaskManager extends Component {

    constructor(props) {

        super(props);



        this.state = {

            contextMenuOpen: false,

            mousePos: {

                x: 0,

                y: 0,

            },

            rightClickedRow: null,

        };



        this.columns = [

            {

                title: "Project",

                field: "project",

                headerFilter: "input",

                // headerFilterFunc: globFilter,

            },

            {

                title: "User",

                field: "user",

                headerFilter: "input",

                // headerFilterFunc: globFilter,

            },

            {

                title: "Block",

                field: "block",

                headerFilter: "input",

                // headerFilterFunc: globFilter,

            },

            {

                title: "Phase",

                field: "phase",

                headerFilter: "input",

                // headerFilterFunc: globFilter,

            },

            {

                title: "Runtag",

                field: "run_tag",

                headerFilter: "input",

                // headerFilterFunc: globFilter,

            },

            {

                title: "Checkpoint",

                field: "checkpoint",

                headerFilter: "input",

                // headerFilterFunc: globFilter,

            },

            {

                title: "Tool Name",

                field: "tool_name",

                headerFilter: "input",

                // headerFilterFunc: globFilter,

            },

            {

                title: "Date",

                field: "date",

                sorter: "date",

                sorterParams: { format: "DD-MM-YYYY" },

                headerFilter: "input",

            },

            { title: "Time", field: "time", headerFilter: "input" },

            {

                title: "Progress",

                field: "progress",

                hozAlign: "left",

                formatter: reactFormatter(<TaskProgressBar />),

                sorter: "number",

            },

            {

                title: "Status",

                field: "status",

                formatter: this.getTaskStatus,

                headerFilter: "input",

                // headerFilterFunc: globFilter,

                width: 110,

            },

        ];

    }



    componentDidMount() {

        // create axios instance to query workflow manager

        this.workflowManager = axios.create({

            baseURL: useConfigStore.getState().configData.rest_server_url +"/workflow_manager",

        });



        // refresh table

        this.refreshTaskManagerData(this.props.reportName, this.props.id);



        // manage autorefresh

        this.manageAutoRefresh();

    }



    componentDidUpdate(nextProps, nextState) {

        // manage autorefresh

        this.manageAutoRefresh();



        // table related updates

        if (!this.tableRef.current) {

            return;

        }

        const table = this.tableRef.current;

        if (!table) {

            return;

        }



        // get selected rows

        const selectedRows = table.getSelectedRows();

        const selectedIds = [];

        selectedRows.forEach((value, index, array) => {

            selectedIds.push(value._row.data.id);

        });



        // update table data

        table.replaceData(this.state.data);
        console.log("sandms.dmslm",table)


        // re-select all previously selected rows

        if (selectedIds.length > 0) {

            table.selectRow(selectedIds);

        }

    }



    componentWillUnmount = () => {

        if (this.websocket) {

            this.websocket.close();

            this.websocket = null;

        }

    };



    getRowContextMenu = (e, position) => {

        const validStatesToKill = ["pending", "queued", "running"];

        const validStatesToReRun = ["failed", "killed"];

        const validStatesToRetry = ["failed"];

        const validStatesToDelete = ["new", "success", "failed", "killed"];

        let status = "";

        let reportName = "";

        let row_data = {};

        if (e._row) {

            status = e._row.data.status;

            reportName = e._row.data.report_name;

            row_data = e._row.data;

        }



        let userAuth = false;

        if (row_data.user === this.props.user.userid || this.props.user.adminFlag) {

            userAuth = true;

        }

        let ret = [

            {

                label: "<i class='fas fa-user'></i> View Log",

                action: () => {

                    this.handleViewLog(reportName);

                },

            },

        ]



        if (status === "new" && userAuth) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Run",

                    action: () => {

                        this.handleRunTask(row_data);

                    },

                },

            )

        }

        if (validStatesToReRun.includes(status) && userAuth) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Re-Run",

                    action: () => {

                        this.handleRunTask(row_data);

                    },

                },

            )

        }

        if (validStatesToRetry.includes(status) && userAuth && row_data.progress > 0) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Retry",

                    action: () => {

                        this.handleRetryTask(row_data);

                    },

                },

            )

        }

        if (validStatesToKill.includes(status) && userAuth) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Kill",

                    action: () => {

                        this.handleKillTask(row_data);

                    },

                },

            )

        }

        if (validStatesToDelete.includes(status) && userAuth) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Delete",

                    action: () => {

                        this.handleDeleteTask(row_data);

                    },

                },

            )

        }

        return ret

    };



    getTaskStatus = (cell, formatterParams) => {

        const taskStatus = cell.getValue();



        let bgColor = "black";

        if (taskStatus === "running") {

            bgColor = "#03c03c";

        } else if (taskStatus === "queued") {

            bgColor = "#e67e00";

        } else if (taskStatus === "pending") {

            bgColor = "#003366";

        } else if (taskStatus === "success") {

            bgColor = "#177245";

        } else if (taskStatus === "failed") {

            bgColor = "#DC143C";

        } else if (taskStatus === "killing") {

            bgColor = "#800000";

        } else if (taskStatus === "deleting") {

            bgColor = "#800000";

        } else if (taskStatus === "killed") {

            bgColor = "#454545";

        } else if (taskStatus === "new") {

            bgColor = "#0d98ba";

        }



        const element = cell.getElement();

        element.style.color = "white";

        element.style["font-weight"] = "bold";

        element.style["text-align"] = "center";

        element.style["background-color"] = bgColor;



        return taskStatus;

    };



    handleViewLog = (reportName) => {

        const link = useConfigStore.getState().configData.rest_server_url +`/api/workflow_manager/log_viewer/task/${reportName}`;

        window.open(link, "_blank");

        // close context menu

        // this.handleMenuClose();

    };



    handleDeleteTask = (row) => {

        // refresh data

        this.props.refreshTaskManagerData(this.props.reportName, this.props.id);



        const task_info = {

            report_name: row.report_name,

            user: row.user,

        };



        this.workflowManager

            .post("/delete_task", task_info)

            .then((response) => {

                response = response.data;

                const success = _.get(response, "success", false);



                if (!success) {

                    //   this.props.showToast({

                    //     reportName: this.props.currentReportName,

                    //     widgetId: this.props.id,

                    //     severity: "error",

                    //     message: `Failed to delete task - ${row.report_name}`,

                    //   });

                } else {

                    const table = this.tableRef.current;

                    table.updateData([{ id: row.id, status: "deleting" }]);

                }

            })

            .catch((error) => {

                // this.props.showToast({

                //   reportName: this.props.currentReportName,

                //   widgetId: this.props.id,

                //   severity: "error",

                //   message: "Failed to connect to Server",

                // });

                console.log(error);

            });



        // close context menu

        // this.handleMenuClose();

    };



    handleKillTask = (row) => {

        // refresh data

        this.props.refreshTaskManagerData(this.props.reportName, this.props.id);



        const task_info = {

            report_name: row.report_name,

            user: row.user,

        };



        this.workflowManager

            .post("/kill_task", task_info)

            .then((response) => {

                response = response.data;

                const success = _.get(response, "success", false);



                if (!success) {

                    //   this.props.showToast({

                    //     reportName: this.props.currentReportName,

                    //     widgetId: this.props.id,

                    //     severity: "error",

                    //     message: `Failed to kill task - ${row.report_name}`,

                    //   });

                } else {

                    const table = this.tableRef.current;

                    table.updateData([{ id: row.id, status: "killing" }]);

                }

            })

            .catch((error) => {

                // this.props.showToast({

                //   reportName: this.props.currentReportName,

                //   widgetId: this.props.id,

                //   severity: "error",

                //   message: "Failed to connect to Server",

                // });

                console.log(error);

            });



        // close context menu


        // this.handleMenuClose();

    };



    // handleMenuClose = () => {

    //   this.setState({

    //     contextMenuOpen: false,

    //   });

    // };



    // handleRowContextEvent = (event, row) => {

    //   event.preventDefault();

    //   const mousePos = {

    //     x: event.pageX,

    //     y: event.pageY,

    //   };



    //   this.setState({

    //     mousePos: mousePos,

    //     contextMenuOpen: true,

    //     rightClickedRow: row,

    //   });

    // };



    handleRunTask = (row) => {

        // refresh data

        this.props.refreshTaskManagerData(this.props.reportName, this.props.id);



        const task_info = {

            report_name: row.report_name,

            user: row.user,

            new_task: false,

            summary_data_gen_only: row.summary_data_gen_only,

            skip_eda_data_extraction: row.skip_eda_data_extraction,

            update_task_analysis: row.update_task_analysis,

        };



        this.workflowManager

            .post("/run_task", task_info)

            .then((response) => {

                response = response.data;

                const success = _.get(response, "success", false);



                if (!success) {

                    const message = _.get(response, "message", "Unknown error");

                    //   this.props.showToast({

                    //     reportName: this.props.currentReportName,

                    //     widgetId: this.props.id,

                    //     severity: "error",

                    //     message: `Failed to run task - ${message}`,

                    //   });

                } else {

                    const table = this.tableRef.current;

                    table.updateData([{ id: row.id, status: "pending" }]);

                }

            })

            .catch((error) => {

                // this.props.showToast({

                //   reportName: this.props.currentReportName,

                //   widgetId: this.props.id,

                //   severity: "error",

                //   message: "Failed to connect to Server",

                // });

                console.log(error);

            });



        // close context menu

        // this.handleMenuClose();

    };



    handleRetryTask = (row) => {

        // refresh data

        this.props.refreshTaskManagerData(this.props.reportName, this.props.id);



        const task_info = {

            report_name: row.report_name,

            user: row.user,

        };



        this.workflowManager

            .post("/retry_failed_task", task_info)

            .then((response) => {

                response = response.data;

                const success = _.get(response, "success", false);



                if (!success) {

                    const message = _.get(response, "message", "Unknown error");

                    //   this.props.showToast({

                    //     reportName: this.props.currentReportName,

                    //     widgetId: this.props.id,

                    //     severity: "error",

                    //     message: `Failed to retry task - ${message}`,

                    //   });

                } else {

                    const table = this.tableRef.current;

                    table.updateData([{ id: row.id, status: "pending" }]);

                }

            })

            .catch((error) => {

                // this.props.showToast({

                //   reportName: this.props.currentReportName,

                //   widgetId: this.props.id,

                //   severity: "error",

                //   message: "Failed to connect to Server",

                // });

                console.log(error);

            });



        // close context menu

        // this.handleMenuClose();

    };




    //   setData= (state, action) => {

    //     Object.assign(state["Task Analysis Manager"][action.payload.widgetId], action.payload.data);

    //   }
    // Function to manage auto refresh
    manageAutoRefresh = () => {

        const autoRefresh = _.get(this.props.config, "autoRefresh", false);

        if (!this.websocket && autoRefresh) {

            this.startAutoRefresh();

        } else if (this.websocket && !autoRefresh) {

            this.stopAutoRefresh();

        }

    };

    refreshTaskManagerData = (reportName, widgetId) => {

        // const state = getState();

        const endpoint =  useConfigStore.getState().configData.rest_server_url  +"/api/workflow_manager/get_tasks";

        axios.get(endpoint).then((response) => {
                response = response.data;
                const requestStatus = _.get(response, "success", false);
                const tasks = _.get(response, "tasks", {});
                console.log('Tasks' + JSON.stringify(tasks))
                const message = _.get(response, "message", "No valid response from server");

                if (!requestStatus) {
                } else {

                    // console.log("tasks", tasks)
                    this.setState({ data: tasks })

                }

            })
            .catch((error) => {

                console.log(error);

            });

    };



    // Function to create websocket connection for auto-refresh

    startAutoRefresh = () => {
    const websocketUrl = "ws://10.194.161.176:24565/socket_service"

        this.websocket = new WebSocket(
            websocketUrl + "/api/workflow_manager/get_tasks_ws"
        );



        this.websocket.onopen = () => {

            try {

                // this.websocket.send(`import os;os.environ["ANALYTICS_USER"]="${this.context.user.userid}";`);

                // get response

                this.websocket.onmessage = (event) => {

                    const data = JSON.parse(event.data);

                    if (data.success === true) {

                        this.setData({

                            widgetId: this.props.id,

                            data: { tasks: data.tasks },

                        });

                    } else {

                        // this.props.showToast({

                        //   reportName: this.props.currentReportName,

                        //   widgetId: this.props.id,

                        //   severity: "error",

                        //   message: data.message,

                        // });

                    }

                };

            } catch (error) {

                // this.props.showToast({

                //   reportName: this.props.currentReportName,

                //   widgetId: this.props.id,

                //   severity: "error",

                //   message: "Failed to connect to Server",

                // });

                console.log(error); // catch error

            }

        };



        this.websocket.onclose = (event) => {

            // re-establish the connection on abnormal closure

            if (event.code == 1006) {

                console.warn(

                    "Task Analysis Manager websocket connection broken. Reconnecting ..."

                );

                this.startAutoRefresh();

            }

        };

    };



    // Function to destroy existing websocket connection for auto-refresh

    stopAutoRefresh = () => {

        this.websocket.close();

        this.websocket = null;

    };



    // Function to update config

    updateConfig = (config, save) => {

        if (save) {

            this.props.setConfig({

                reportName: this.props.currentReportName,

                widgetId: this.props.id,

                config: config,

            });

        }



        this.props.toggleShowConfig({

            reportName: this.props.currentReportName,

            widgetId: this.props.id,

        });



        // refresh table data

        this.props.refreshTaskManagerData(this.props.reportName, this.props.id);

    };



    applyTheme = (theme) => {

        if (theme == "dark") {

            return "table-sm table-dark table-striped table-bordered";

        } else {

            return "table-sm table-striped table-bordered";

        }

    };



    render() {

        if (!this.tableRef) {

            this.tableRef = React.createRef();

        }



        // Render config editor if requested

        if (this.props.uiState.showConfig) {

            return (

                <Config updateConfig={this.updateConfig} config={this.props.config} />

            );

        }



        const options = {

            columnDefaults: {

                headerFilter: true,

                headerFilterLiveFilter: false,

                headerFilterPlaceholder: "...",

                tooltip: true,

            },

            selectable: true,

            rowContextMenu: this.getRowContextMenu,

            pagination: "local",

            paginationSize: "10",

            persistenceID: _.get(this.props.config, "tableId", this.props.id),

            persistenceMode: true,

            persistence: {

                columns: true, //persist changes to the width, visible and frozen properties

            },

        };



        return (

            <div id="analytics">

                <ReactTabulator

                    key={this.props.theme} // Do not remove this, otherwise it breaks theme functionalities
                    className={this.applyTheme(this.props.theme)}
                    style={{ marginTop: "10px" }}
                    layout="fitColumns"
                    autoResize={false}
                    onRef={(ref) => (this.tableRef = ref)}
                    columns={this.columns}
                    // data={[]}
                    options={options}
                />
            </div>

        );

    }

}


TaskManager.defaultProps = {
    widgetProps: {},
    data: {},
    uiState: {
        isLoading: false,
        showConfig: false,
        isToastOpen: false,
        toastSeverity: "info",
        toastMessage: "",
    },
};

export default (TaskManager);