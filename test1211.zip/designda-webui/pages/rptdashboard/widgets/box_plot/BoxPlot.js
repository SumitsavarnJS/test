// react imports

import React from "react";

// import { connect } from "react-redux";

import ReactEcharts from "echarts-for-react";

import Typography from "@mui/material/Typography";

// utility imprts

import _ from "lodash";

// import Config from "./Config";

// import echarts from 'echarts/lib/echarts';

// import actions

// import { setConfig } from "./BoxPlotSlice";

// import { toggleShowConfig } from "../../analytics_widget/AnalyticsWidgetSlice";

// css imports

import styles from "./BoxPlot.module.css";

class BoxPlot extends React.Component {
  // consturctor

  constructor(props) {
    super(props);

    this.state = {};

    this.chart = React.createRef();
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      // to set previous session zoom settings

      if (this.props.config.zoom && this.props.config.zoom.batch[0]) {
        if (this.chart && this.chart.current) {
          this.chart.current.getEchartsInstance().dispatchAction({
            type: "dataZoom",

            batch: [
              {
                startValue: this.props.config.zoom.batch[0].startValue,

                endValue: this.props.config.zoom.batch[0].endValue,
              },
            ],
          });
        }
      }
    }
  }

  // Function to update config

  updateConfig = (config, save) => {
    if (save) {
      this.props.setConfig({
        reportName: this.props.currentReportName,

        widgetId: this.props.id,

        config: config,
      });
    }

    this.props.toggleShowConfig({
      reportName: this.props.currentReportName,

      widgetId: this.props.id,
    });
  };

  //to store zoom config

  onZoom = (params) => {
    const config = { ...this.props.config };

    config["zoom"] = params;

    this.props.setConfig({
      reportName: this.props.currentReportName,

      widgetId: this.props.id,

      config: config,
    });
  };

  // render method

  render() {
    // define event dict

    const eventDict = {
      dataZoom: this.onZoom,
    };

    if (this.props.uiState.showConfig) {
      // return <Config updateConfig={this.updateConfig} config={this.props.config} />;
      return null;
    } else {
      return Object.keys(this.props.data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <ReactEcharts
          ref={this.chart}
          style={{ height: "90%" }}
          option={this.props.data}
          onEvents={eventDict}
          theme={this.props.theme}
          notMerge={true}
        />
      );
    }
  }
}

// const mapDispatchToProps = (dispatch) => {

//   return {

//     setConfig: (payload) => dispatch(setConfig(payload)),

//     toggleShowConfig: (payload) => dispatch(toggleShowConfig(payload)),

//   };

// };

// const mapStateToProps = (state, props) => {

//   return {

//     currentReportName: state.currentReportName,

//     config: state.allReports[state.currentReportName].widgets[props.id].config,

//     data: _.get(state["Box Plot"], props.id, {}),

//     theme: _.get(state.allReports[state.currentReportName], "theme", "light"),

//     uiState: _.get(state.allReports[state.currentReportName].widgets[props.id], "uiState", {

//       isLoading: false,

//       showConfig: false,

//       isToastOpen: false,

//       toastSeverity: "info",

//       toastMessage: "",

//     }),

//   };

// };
BoxPlot.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};

export default BoxPlot;
