import React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import Button from "@mui/material/Button";

// utility imprts
import _ from "lodash";

// css imports
import styles from "./Config.module.css";

class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      columns: _.get(this.props.config, "columns", []),
      columnList: _.get(this.props, "columnList", []),
    };
  }

  // on save handler
  onSave = () => {
    let config = Object.assign({}, this.props.config);
    config["columns"] = this.state.columns;

    // add title only if user has provided it
    if (this.state.title.length > 0) {
      config["title"] = this.state.title;
    }
    this.props.updateConfig(config, true);
  };

  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Select Columns */}
        <Autocomplete
          id="columns-input"
          multiple
          filterSelectedOptions
          style={{ marginTop: "10px" }}
          defaultValue={this.state.columns}
          onChange={(event, newValue) => {
            this.setState({ columns: newValue });
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.columnList}
          renderInput={(params) => (
            <TextField {...params} label="Columns" variant="outlined" />
          )}
        />

        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={this.onSave}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={() => {
            this.props.updateConfig({}, false);
          }}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}

export default Config;
