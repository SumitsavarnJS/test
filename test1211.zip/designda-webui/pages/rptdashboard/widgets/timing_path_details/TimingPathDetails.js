// react imports
import React from "react";
// import { connect } from "react-redux";
import Typography from "@mui/material/Typography";

// utility imprts
import _ from "lodash";
import axios from "axios";

import Config from "./Config";
import Table from "./Table";

//impport stores
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";
// import actions
// import { setConfig } from "./TimingPathDetailsSlice";
// import { toggleShowConfig, showToast, setLoading } from "../../analytics_widget/AnalyticsWidgetSlice";
// import { addWidgetsToCurrentReport } from "../../analytics_main_view/AnalyticsMainViewSlice"

// css imports
import styles from "./TimingPathDetails.module.css";

import {
  addWidgetCommonFunction,
  showWidgetDataUiState,
} from "../../addWidget/addWidget";

import { produce } from "immer";

var theme = useConfigStore.getState().theme;

class TimingPathDetails extends React.Component {
  // consturctor
  constructor(props) {
    super(props);
    // this.state = {
    //   isLoading: false,
    // };
  }

  showToast = (toast) => {
    const uiState = produce(
      useGlobalStore.getState()[this.props.id].uiState,
      (uiStateDraft) => {
        uiStateDraft.isToastOpen = true;
        uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
        uiStateDraft.toastMessage = _.get(toast, "message", "");
      }
    );
    useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  setLoading = (loadingProps) => {
    const uiState = produce(
      useGlobalStore.getState()[this.props.id].uiState,
      (uiStateDraft) => {
        uiStateDraft.cirlularLoading = _.get(
          loadingProps,
          "cirlularLoading",
          false
        );
      }
    );
    useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  addWidgets = (props) => {
    for (let i = 0; i < props.widgets.length; i++) {
      const widgetsSettings = produce(props.widgets[i], (settingsDraft) => {
        delete settingsDraft.currentReportName;
        delete settingsDraft.data;
      });

      const data = _.get(props.widgets[i], "data", {});

      addWidgetCommonFunction(
        this.props.rptType,
        this.props.reportKey,
        widgetsSettings,
        data,
        showWidgetDataUiState,
        this.props.index
      );
    }
  };

  enable_filter = (columns) => {
    let col = _.cloneDeep(columns);
    // console.log(columns);
    for (let x = 0; x < col.length; x++) {
      col[x]["cellContext"] = (event, cell) => {
        localStorage.setItem("cell", JSON.stringify(cell._cell.initialValue));
      };
      if (col[x].columns) {
        let len = col[x].columns.length;
        for (let y = 0; y < len; y++) {
          col[x].columns[y]["cellContext"] = (event, cell) => {
            localStorage.setItem("cell", JSON.stringify(cell._cell.value));
          };
        }
      }
    }
    // console.log(col);
    return col;
  };

  // Function to get columns to display
  getColumns = (columns) => {
    const tableColumns = [];
    for (let index = 0; index < columns.length; index++) {
      const columnName = columns[index];
      const columnTitle = _.startCase(_.toLower(columnName.replace("_", " ")));

      tableColumns.push({
        title: columnTitle,
        field: columnName,
      });
    }
    return this.enable_filter(tableColumns);
  };

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  //-----------------------------ContextMenuFunctions-------------
  // to copy to clipboard
  copyToClipboard = () => {
    // this.handleMenuClose();
    const copyStr = localStorage.getItem("cell")
      ? JSON.parse(localStorage.getItem("cell"))
      : {};
    // if it is a secured connection (https) then it will write it to sytem clipboard directly
    if (window.isSecureContext && navigator.clipboard !== undefined) {
      navigator.clipboard.writeText(copyStr);
    }

    //otherwise it will copy to web ui clipboard
    else {
      var textarea = document.createElement("textarea");
      textarea.textContent = copyStr;
      document.body.appendChild(textarea);

      var selection = document.getSelection();
      var range = document.createRange();

      range.selectNode(textarea);
      selection.removeAllRanges();
      selection.addRange(range);

      document.execCommand("copy");
      selection.removeAllRanges();

      document.body.removeChild(textarea);
    }
  };

  addNetLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.obj_type == "net") && !(row.data.obj_type == "clock/net")) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Missing net value to fetch Layout View",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros", "blockages"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
          this.setLoading({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            cirlularLoading: false,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${row.data.obj_name}}`,
                  bucket: _.get(config, "bucket", ""),
                  net_value: row.data.obj_name,
                  ttype: row.data.__ttype,
                  dataLocation: _.get(config, "dataLocation", ""),
                  scenario: row.data.__object.split("/")[0],
                  netContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addNetTimingPaths = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.obj_type == "net") || row.data.obj_type == null) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Net meta-data not found in the table data",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    try {
      var request = {
        bucket: config.bucket,
        key: config.dataLocation,
        net: row.data.obj_name,
        ttype: row.data.__ttype,
        scenario: row.data.__object.split("/")[0],
      };
    } catch {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Please add meta data in query",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
    }

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_net_timing_paths",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", "");
        const dataLocation = _.get(response, "dataLocation", "");
        const data = _.get(response, "file", "");
        const bucket = _.get(response, "bucket", "");
        const col = _.get(response, "columns", []);
        const rows = _.get(response, "rows", [[]]);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
          this.setLoading({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            cirlularLoading: false,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Net Timing Paths for ${row.data.obj_name}`,
                  dataLocation: dataLocation,
                  data: data,
                  bucket: bucket,
                  query: "df = df.sort_values('slack', ascending = True)",
                  columns: [
                    "path_category",
                    "start_point",
                    "end_point",
                    "slack",
                    "cause",
                    "timing_path",
                  ],
                  cache_key: cache_key,
                },
                data: { rows: [[]], columns: col, cache_key: cache_key },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Net Timing Paths",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addCellLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (
      !(row.data.obj_type == "cell") &&
      !(row.data.obj_type == "clock/cell")
    ) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Missing cell value to fetch Layout View",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros", "blockages"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
          this.setLoading({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            cirlularLoading: false,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${row.data.obj_name}}`,
                  bucket: _.get(config, "bucket", ""),
                  cell_name: row.data.obj_name,
                  ttype: row.data.__ttype,
                  scenario: row.data.__object.split("/")[0],
                  dataLocation: _.get(config, "dataLocation", ""),
                  cellContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.error(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addCellTimingPaths = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.obj_type == "cell") || row.data.obj_type == null) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Cell meta-data not found in the table data",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    try {
      var request = {
        bucket: config.bucket,
        key: config.dataLocation,
        cell: row.data.obj_name,
        ttype: row.data.__ttype,
        scenario: row.data.__object.split("/")[0],
      };
    } catch {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Please add meta data in query",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
    }

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_cell_timing_paths",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", "");
        const dataLocation = _.get(response, "dataLocation", "");
        const data = _.get(response, "file", "");
        const query = _.get(response, "query", "");
        const bucket = _.get(response, "bucket", "");
        const col = _.get(response, "columns", []);
        // const rows = _.get(response, "rows", [[]]);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
          this.setLoading({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            cirlularLoading: false,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Cell Timing Paths for ${row.data.obj_name}`,
                  dataLocation: dataLocation,
                  data: data,
                  // row.data.obj_type === "min"
                  //   ? "das_timing_path_min_data.ldb"
                  //   : "das_timing_path_data.ldb",
                  bucket: bucket,
                  query: "df = df.sort_values('slack', ascending = True)", //query,
                  columns: [
                    "path_category",
                    "start_point",
                    "end_point",
                    "slack",
                    "cause",
                    "timing_path",
                  ],
                  cache_key: cache_key,
                },
                data: { rows: [[]], columns: col },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Cell Timing Paths",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addPortLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (
      !(
        row.data.obj_type === "clock/port" ||
        row.data.obj_type === "port" ||
        row.data.obj_type === "clock/in" ||
        row.data.obj_type === "clock/out"
      ) ||
      row.data.obj_type === null
    ) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "PORT meta-data not found",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros", "blockages"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
          this.setLoading({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            cirlularLoading: false,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${row.data.obj_name}}`,
                  bucket: _.get(config, "bucket", ""),
                  port: row.data.obj_name,
                  ttype: row.data.__ttype,
                  scenario: row.data.__object.split("/")[0],
                  dataLocation: _.get(config, "dataLocation", ""),
                  portContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.error(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  //-----------------------------ContextMenuFunctions^^^^^^^^^^^^^^^^^^^^^^

  render() {
    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (uiState.showConfig) {
      return (
        <Config
          updateConfig={this.updateConfig}
          config={this.props.widgetProps.config}
          columnList={_.get(this.props.widgetProps.config, "column_list", [])}
        />
      );
    } else {
      return _.get(this.props.widgetProps.config, "cache_key", "") === "" ? (
        <Typography variant="h5" className={styles.text} align="center">
          Sorry! This widget is currently not designed to reload data
        </Typography>
      ) : (
        <React.Fragment>
          {/* Tabulator table */}
          <Table
            theme={theme}
            columns={this.getColumns(this.props.widgetProps.config.columns)}
            data={data.rows ? data.rows : []}
            colors={
              this.props.widgetProps.config.colors
                ? this.props.widgetProps.config.colors
                : []
            }
            analyticsBackendUrl={_.get(
              useConfigStore.getState().configData,
              "rest_server_url",
              ""
            )}
            config={this.props.widgetProps.config}
            copyToClipboard={this.copyToClipboard}
            addNetLayoutWidget={this.addNetLayoutWidget}
            addNetTimingPaths={this.addNetTimingPaths}
            addCellLayoutWidget={this.addCellLayoutWidget}
            addCellTimingPaths={this.addCellTimingPaths}
            addPortLayoutWidget={this.addPortLayoutWidget}

            // config={this.props.widgetProps.config}
          />
          {/* <CircularIndeterminate
            // ref="loading"
            // id={this.props.id}
            isLoading = {this.state.isLoading}
          /> */}
        </React.Fragment>
      );
    }
  }
}

TimingPathDetails.defaultProps = { widgetProps: { config: { columns: [] } } };

export default TimingPathDetails;
