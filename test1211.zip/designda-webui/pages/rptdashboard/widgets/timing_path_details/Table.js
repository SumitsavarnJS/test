// react imports
import React from "react";
import { ReactTabulator } from "react-tabulator";

import { TabulatorFull as Tabulator } from "tabulator-tables";
import useConfigStore from "../../../../store/useConfigStore";

// utility imprts
import _ from "lodash";
import styles from "./TimingPathDetails.module.css";
import axios from "axios";

var theme = useConfigStore.getState().theme;
let tableInst = null;
class Table extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isDownloadingCSV: false,
    };
    this.tableRef = React.createRef();
    // this.tableInst = null;
  }

  componentDidMount() {
    tableInst = new Tabulator(this.tableRef.current, {
      layout: "fitColumns",
      autoResize: false,
      height: "85%",
      columns: this.props.columns,
      placeholder: "Sorry! No table data to show",
      rowFormatter: (row) => {
        if (row.getData().color === "red") {
          row.getElement().style.color = "red";
          row.getElement().style.fontWeight = "bold";
        } else if (this.props.colors[row.getData().idx] === "magenta") {
          row.getElement().style.color = "magenta";
          row.getElement().style.fontWeight = "bold";
        }
      },
      rowContextMenu: this.getRowContextMenu,
      pagination: true, //enable pagination
      paginationMode: "remote", //enable remote pagination
      sortMode: "remote",
      filterMode: "remote",
      popupContainer: true,
      ajaxURL: this.props.analyticsBackendUrl + "/api/remote_pagination2", //set url for ajax request
      ajaxContentType: "json",
      ajaxParams: {
        cacheKey: this.props.config.cache_key
          ? this.props.config.cache_key
          : this.props.data.cache_key,
        key: this.props.config.dataLocation,
        columns: this.props.config.columns,
        bucket: this.props.config.bucket,
      },
      ajaxResponse: (url, params, responseData) => {
        const tabulatorLoreFormat = {
          data: responseData.data ? responseData.data : [],
          last_page: responseData.last_page ? responseData.last_page : 0,
        };
        return tabulatorLoreFormat;
      },
      columnDefaults: {
        headerFilter: true,
        headerFilterLiveFilter: false,
        headerFilterPlaceholder: "...",
        tooltip: true,
      },
      ajaxConfig: "POST",
      paginationSize: "10",
      paginationSizeSelector: [20],
    });
  }

  shouldComponentUpdate = (prevProps, prevState) => {
    if (theme != prevProps.theme) {
      return true;
    }
    return false;
  };

  applyTheme = (theme) => {
    if (theme == "dark") {
      return "table-sm table-dark table-striped table-bordered";
    } else {
      return "table-sm table-striped table-bordered";
    }
  };
  getRowContextMenu = (_event, _e) => {
    if (_e._row.data.obj_type === "net") {
      return this.getNetContextMenu();
    } else if (_e._row.data.obj_type === "cell") {
      return this.getCellContextMenu();
    } else if (_e._row.data.obj_type === "port") {
      return this.getPortContextMenu();
    } else if (_e._row.data.obj_type === "clock/cell") {
      return this.getClockCellContextMenu();
    } else if (_e._row.data.obj_type === "clock/net") {
      return this.getClockNetContextMenu();
    } else if (
      _e._row.data.obj_type === "clock/port" ||
      _e._row.data.obj_type === "clock/in" ||
      _e._row.data.obj_type === "clock/out"
    ) {
      return this.getPortContextMenu();
    } else {
      return this.defaultConextMenu();
    }
  };

  //-----------------------------ContextMenuOptions---------------
  defaultConextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          console.log("Copied");
          this.props.copyToClipboard();
        },
      },
    ];
  };

  getClockCellContextMenu = () => {
    return [
      // {
      //   label: "<i class='fas fa-user'></i> Show Timing Paths",
      //   action: (e, row) => {
      //     this.props.addCellTimingPaths(e, row);
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.props.addCellLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          console.log("Copied");
          this.props.copyToClipboard();
        },
      },
    ];
  };

  getClockNetContextMenu = () => {
    return [
      // {
      //   label: "<i class='fas fa-user'></i> Show Timing Paths",
      //   action: (e, row) => {
      //     this.props.addNetTimingPaths(e, row);
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.props.addNetLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          console.log("Copied");
          this.props.copyToClipboard();
        },
      },
    ];
  };

  getPortContextMenu = () => {
    return [
      // {
      //   label: "<i class='fas fa-user'></i> Show Timing Paths",
      //   action: (e, row) => {
      //     this.props.addNetTimingPaths(e, row);
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.props.addPortLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          console.log("Copied");
          this.props.copyToClipboard();
        },
      },
    ];
  };

  getCellContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show Timing Paths",
        action: (e, row) => {
          this.props.addCellTimingPaths(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.props.addCellLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          console.log("Copied");
          this.props.copyToClipboard();
        },
      },
    ];
  };

  getNetContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show Timing Paths",
        action: (e, row) => {
          this.props.addNetTimingPaths(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.props.addNetLayoutWidget(e, row);
        },
      },
      // {
      //   label: "<i class='fas fa-user'></i> Net summary",
      //   action: (e, row) => {
      //     this.copyToClipboard(); // yet to be implemented
      //   },
      // },
      // {
      //   label: "<i class='fas fa-user'></i> Scalability Metrics",
      //   action: (e, row) => {
      //     this.copyToClipboard(); // yet to be implemented
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          console.log("Copied");
          this.props.copyToClipboard();
        },
      },
    ];
  };

  //-----------------------------ContextMenuOptions^^^^^^^^^^^^^^^

  downloadFile = (data, fileName) => {
    const url = window.URL.createObjectURL(new Blob([data])) 
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', fileName)
    document.body.appendChild(link)
    link.click()
    link.remove()
  }

  onDownloadTableData = () => {
    // set state to downloading
    this.setState({isDownloadingCSV: true});
    const filters = tableInst.getHeaderFilters()
    const config = this.props.config;
    const request = {
      cacheKey: config.cache_key ? config.cache_key : this.props.data.cache_key,
      filter: filters,
      mode: 2,
      file_format: "csv",
      scenario: _.get(config, "dataLocation", "").split("/").slice(-1).toString() ? _.get(config, "dataLocation", "").split("/").slice(-1).toString() : null
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/download_cached_table",
        request
      )
      .then((response) => {
       const dataFromResponse = response.data;
       if(dataFromResponse) {
        const fileName = `${config.title ? config.title : 'dd_file'}_${this.props.name ? this.props.name.split(' ').join('_'): '_'}.csv`;
        this.downloadFile(dataFromResponse, fileName ? fileName : 'file.csv');
       }
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to download table data",
        });
      })
      .finally(() => {
        this.setState({isDownloadingCSV: false});
      })
  }

  render() {
    console.log(this.props);
    return (
      <div id="analytics" className={styles.tableParent}>
        <button
          className={styles.downloadButton}
          onClick={this.onDownloadTableData}
          disabled={this.state.isDownloadingCSV}
        >
          {this.state.isDownloadingCSV ? "Downloading ..." : "Download CSV"}
        </button>
        <div
          key={theme}
          className={this.applyTheme(theme)}
          ref={(ref) => (this.tableRef.current = ref)}
        />
        {/* <ReactTabulator
          key={theme} // Do not remove this, otherwise it breaks theme functionalities
          className={this.applyTheme(theme)}
          layout="fitColumns"
          autoResize={false}
          height="85%"
          columns={this.props.columns}
          placeholder="Sorry! No table data to show"
          rowFormatter={(row) => {
            if (row.getData().color === "red") {
              row.getElement().style.color = "red";
              row.getElement().style.fontWeight = "bold";
            } else if (this.props.colors[row.getData().idx] === "magenta") {
              row.getElement().style.color = "magenta";
              row.getElement().style.fontWeight = "bold";
            }
          }}
          events={{
            cellContext: (event, cell) => {
              localStorage.setItem("cell", JSON.stringify(cell._cell.value));
            },
            ajaxError: (error) => {
              console.log(error);
            },
          }}
          options={{
            rowContextMenu: this.getRowContextMenu,
            pagination: true, //enable pagination
            paginationMode: "remote", //enable remote pagination
            sortMode: "remote",
            filterMode: "remote",
            popupContainer: true,
            ajaxURL: this.props.analyticsBackendUrl + "/api/remote_pagination2", //set url for ajax request
            ajaxContentType: "json",
            ajaxParams: {
              cacheKey: this.props.config.cache_key
                ? this.props.config.cache_key
                : this.props.data.cache_key,
              key: this.props.config.dataLocation,
              columns: this.props.config.columns,
              bucket: this.props.config.bucket,
            },
            ajaxResponse: (url, params, responseData) => {
              const tabulatorLoreFormat = {
                data: responseData.data ? responseData.data : [],
                last_page: responseData.last_page ? responseData.last_page : 0,
              };
              return tabulatorLoreFormat;
            },
            columnDefaults: {
              headerFilter: true,
              headerFilterLiveFilter: false,
              headerFilterPlaceholder: "...",
              tooltip: true,
            },
            ajaxConfig: "POST",
            paginationSize: "10",
            paginationSizeSelector: [20],
          }}
        /> */}
      </div>
    );
  }
}

Table.defaultProps = { config: {} };

export default Table;
