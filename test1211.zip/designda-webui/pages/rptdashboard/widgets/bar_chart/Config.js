import React from "react";
// import { connect } from "react-redux";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
// import AceEditor from "react-ace";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
// import Popup from "reactjs-popup";
// utility imprts
import _ from "lodash";
import axios from "axios";
// data source table
import DataSource from "../../data_source/DataSource";
import dynamic from "next/dynamic";
import styles from "./Config.module.css";
import * as utils from "../../../../common/utils/utils";

import useConfigStore from "../../../../store/useConfigStore";
import { Box } from "@mui/material";
import { ClickAwayListener } from "@mui/base";
const AceEditor = dynamic(
  () =>
    import("../../../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);
const defaultQueryBody = `# Data has been loaded in df variable
# Please modify the df variable to contain data needed for the plot
#
# Grouping axis X -
#   * First 2 columns plot X axis
#   * The last column (numerical) plots Y axis
#
# Grouping axis Y -
#   * 1st column plots X axis
#   * Rest all columns (numerical) plot Y axis
`;
class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      dataLocation: _.get(this.props.config, "dataLocation", ""),
      data: _.get(this.props.config, "data", ""),
      columns: _.get(this.props.config, "columns", []),
      groupingAxis: _.get(this.props.config, "groupingAxis", "Y"),
      bucket: _.get(this.props.config, "bucket", ""),
      dataList: [],
      columnList: [],
      // showDataSource: false,
      scenarioList: [],
      rootDataLocation: "",
      scenario: utils.getScenarioFromDataLoc(
        _.get(this.props.config, "dataLocation", "")
      ),
      dataHelperText: "",
      dataErrorFlag: false,
      columnHelperText: "",
      columnErrorFlag: false,
      scenarioHelperText: "",
      scenarioErrorFlag: false,
    };
    this.query = _.get(this.props.config, "query", defaultQueryBody);
  }
  componentDidMount() {
    // refresh data list if data location is present
    if (this.state.dataLocation) {
      this.dataLocationChanged(this.state.dataLocation, this.state.bucket);
    }
  }
  // dataLocationChanged = (newDataLocation, bucket) => {
  //   const data = {
  //     bucket: bucket,
  //     key: newDataLocation,
  //   };
  //   axios
  //     .post(
  //       _.get(useConfigStore.getState().configData, "rest_server_url", "") +
  //         "/api/get_ldb_files",
  //       data
  //     )
  //     .then((response) => {
  //       const dataList = _.get(response.data, "data", {});
  //       let data = this.state.data;
  //       if (data && !dataList.includes(data)) {
  //         data = "";
  //       }
  //       this.setState({
  //         dataLocation: newDataLocation,
  //         dataList: dataList,
  //         bucket: bucket,
  //         data: data,
  //       });
  //       if (this.state.data) {
  //         this.dataChanged(this.state.dataLocation, this.state.data);
  //       } else {
  //         this.setState({
  //           columns: [],
  //           columnList: [],
  //         });
  //       }
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };
  dataLocationChanged = async (dataLocation, bucket) => {
    const rootDataLocation = utils.getRootDirectory(dataLocation);
    const scenarioList = await utils.getScenarioList(bucket, rootDataLocation);
    let scenarioErrorFlag = false;
    let scenarioHelperText = "";
    let newDataLocation = dataLocation;
    //if scneario exists but not present in current location
    if (!scenarioList.includes(this.state.scenario) && this.state.scenario) {
      scenarioErrorFlag = true;
      scenarioHelperText = "Invalid scenario for the selected Data Source";
    } else if (this.state.scenario) {
      //if scenario exists and present in current root level
      newDataLocation = rootDataLocation + "/" + this.state.scenario;
    }
    //if only root level data is present but not scenario
    else {
      newDataLocation = rootDataLocation;
    }
    const newConfig = {
      dataLocation: newDataLocation,
      rootDataLocation: rootDataLocation,
      bucket: bucket,
      scenarioList: scenarioList,
      scenarioErrorFlag: scenarioErrorFlag,
      scenarioHelperText: scenarioHelperText,
    };
    const dataObject = await utils.getDataObject(
      newDataLocation,
      bucket,
      this.state.data
    );
    newConfig.dataErrorFlag = dataObject.dataErrorFlag;
    newConfig.dataHelperText = dataObject.dataHelperText;
    newConfig.dataList = dataObject.dataList;
    this.setState(newConfig);
    if (this.state.data) {
      this.dataChanged(this.state.data, newConfig);
    } else {
      this.setState(newConfig);
    }
  };
  scenarioChanged = async (dataSource, bucket) => {
    const newConfig = {
      bucket: bucket,
      dataLocation: dataSource,
      scenario: utils.getScenarioFromDataLoc(dataSource),
      scenarioErrorFlag: false,
      scenarioHelperText: "",
    };
    const dataObject = await utils.getDataObject(dataSource, bucket);
    newConfig.dataErrorFlag = dataObject.dataErrorFlag;
    newConfig.dataHelperText = dataObject.dataHelperText;
    newConfig.dataList = dataObject.dataList;
    this.setState(newConfig);
    if (this.state.data) {
      this.dataChanged(this.state.data, newConfig);
    }
  };

  // Data changed handler. This will fetch the list of columns for this data

  // dataChanged = (location, newData) => {
  //   const data = {
  //     bucket: this.state.bucket,
  //     key: location,
  //     ldb_file: newData,
  //   };
  //   axios
  //     .post(
  //       _.get(useConfigStore.getState().configData, "rest_server_url", "") +
  //         "/api/fetch_parquet_columns",
  //       data
  //     )
  //     .then((response) => {
  //       let columns = [];
  //       const selectedColumns = this.state.columns;
  //       const columnList = _.get(response.data, "data", {});
  //       for (const rowIdx in selectedColumns) {
  //         if (columnList.includes(selectedColumns[rowIdx])) {
  //           columns.push(selectedColumns[rowIdx]);
  //         }
  //       }
  //       this.setState({
  //         data: newData,
  //         columnList: columnList,
  //         columns: columns,
  //       });
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };
  dataChanged = async (newData, newConfig = this.state) => {
    const columnObject = await utils.getDataColumnsObject(
      newData,
      newConfig.bucket,
      newConfig.dataLocation,
      this.state.columns
    );
    this.setState({
      columnList: columnObject.columnList,
      columnHelperText: columnObject.columnHelperText,
      columnErrorFlag: columnObject.columnErrorFlag,
      data: newData,
      columns: this.state.columns,
    });
  };
  handleScenarioChange = (scenario) => {
    //if scenario is selected
    if (scenario) {
      this.scenarioChanged(
        this.state.rootDataLocation + "/" + scenario,
        this.state.bucket
      );
    }
    //if scenario is cleared
    else {
      this.scenarioChanged(this.state.rootDataLocation, this.state.bucket);
    }
  };
  handleDataLocationChange = (newDataLocation, bucket) => {
    this.dataLocationChanged(utils.getRootDirectory(newDataLocation), bucket);
  };
  handleColsChange = (newColumns) => {
    let columnErrorFlag = false;
    let columnHelperText = "";
    let columnList = this.state.columnList;
    const inconsitentCols = newColumns.filter(
      (column) => !columnList.includes(column)
    );
    if (inconsitentCols.length) {
      if (inconsitentCols.length) {
        columnHelperText = `${inconsitentCols} Columns are inconsistent`;
        columnErrorFlag = true;
      }
    }
    this.setState({
      columns: newColumns,
      columnErrorFlag: columnErrorFlag,
      columnHelperText: columnHelperText,
    });
  };
  handleDataChange = (newData) => {
    if (newData) {
      this.setState({
        dataHelperText: "",
        dataErrorFlag: false,
      });
      this.dataChanged(newData);
    }
  };
  onQueryChange = (newQuery) => {
    this.query = newQuery;
  };
  onQueryChange = (newQuery) => {
    this.query = newQuery;
  };
  onSave = () => {
    const config = {};
    config["dataLocation"] = this.state.dataLocation;
    config["groupingAxis"] = this.state.groupingAxis;
    config["data"] = this.state.data;
    config["columns"] = this.state.columns;
    config["query"] = this.query;
    config["bucket"] = this.state.bucket;
    // add title only if user has provided it
    if (this.state.title.length > 0) {
      config["title"] = this.state.title;
    }
    this.props.updateConfig(config, true);
  };
  toggleGroupingAxis = (event) => {
    this.setState({
      groupingAxis: event.target.value,
    });
  };
  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>
        {/* Select Data Source */}
        <div className={styles.inline}>
          <Button
            size="small"
            classes={{ root: styles.add_button }}
            onClick={() => this.setState({ showDataSource: true })}
          >
            Data Source
          </Button>
          {this.state.showDataSource ? (
            <ClickAwayListener
              onClickAway={() => {
                this.setState({ showDataSource: false });
              }}
            >
              <Box
                sx={{
                  zIndex: "5",
                  position: "absolute",
                  top: "0px",
                  left: "0px",
                  width: "100%",
                  height: "fit-content",
                  backgroundColor: "white",
                  padding: "5px",
                  boxShadow: "grey 5px 5px 5px",
                }}
              >
                <DataSource
                  dataLocationChanged={this.handleDataLocationChange}
                  dataLocation={this.state.dataLocation}
                  bucket={this.state.bucket}
                  close={() => {
                    this.setState({ showDataSource: false });
                  }}
                />
              </Box>
            </ClickAwayListener>
          ) : null}
          <Typography
            variant="body2"
            style={{ marginTop: "15px", marginLeft: "15px" }}
          >
            {this.state.dataLocation.split("#")[1]}
          </Typography>
        </div>
        <Autocomplete
          id="scenario-input"
          style={{ marginTop: "10px" }}
          value={this.state.scenario}
          onChange={(event, newValue) => {
            this.handleScenarioChange(newValue);
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.scenarioList}
          getOptionLabel={(option) => {
            if (option.includes("#")) {
              let opt = option.split("#");
              return opt[1];
            } else return option;
          }}
          renderInput={(params) => (
            <TextField
              {...params}
              error={this.state.scenarioErrorFlag}
              helperText={this.state.scenarioHelperText}
              label="Scenario"
              variant="outlined"
            />
          )}
        />
        {/* Select Dataframe */}
        <Autocomplete
          id="data-input"
          style={{ marginTop: "10px" }}
          value={this.state.data}
          onChange={(event, newValue) => {
            this.handleDataChange(newValue);
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.dataList}
          getOptionLabel={(option) => {
            if (option.includes("#")) {
              let opt = option.split("#");
              return opt[1];
            } else return option;
          }}
          renderInput={(params) => (
            <TextField
              {...params}
              error={this.state.dataErrorFlag}
              helperText={this.state.dataHelperText}
              label="Data"
              variant="outlined"
            />
          )}
        />
        {/* Select Columns */}
        <Autocomplete
          id="columns-input"
          multiple
          filterSelectedOptions
          style={{ marginTop: "10px" }}
          value={this.state.columns}
          onChange={(event, newValue) => {
            this.setState({ columns: newValue });
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.columnList}
          renderInput={(params) => (
            <TextField {...params} label="Columns" variant="outlined" />
          )}
        />
        <FormControl component="fieldset">
          <FormLabel component="legend" style={{ marginTop: "10px" }}>
            Grouping axis
          </FormLabel>
          <RadioGroup
            row
            aria-label="grouping_axis"
            name="grouping_axis"
            value={this.state.groupingAxis}
            onChange={this.toggleGroupingAxis}
          >
            <FormControlLabel
              value="X"
              control={<Radio color="primary" />}
              label="X"
            />
            <FormControlLabel
              value="Y"
              control={<Radio color="primary" />}
              label="Y"
            />
          </RadioGroup>
        </FormControl>
        {/* Code editor */}
        <Typography variant="subtitle1" className={styles.label}>
          Query Editor
        </Typography>
        <AceEditor
          placeholder="Please modify df object depending on the query."
          mode="python"
          theme="xcode"
          name="code_editor"
          width="100%"
          // onLoad={this.onLoad}
          onChange={(value, event) => {
            this.onQueryChange(value);
          }}
          fontSize={16}
          maxLines={Infinity}
          showPrintMargin={true}
          showGutter={true}
          highlightActiveLine={true}
          value={this.query}
          setOptions={{
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: true,
            enableSnippets: false,
            showLineNumbers: true,
            tabSize: 2,
          }}
        />
        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={this.onSave}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={() => {
            this.props.updateConfig({}, false);
          }}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}
export default Config;
