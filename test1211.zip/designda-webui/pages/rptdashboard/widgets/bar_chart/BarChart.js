// react imports
import React from "react";
import { connect } from "react-redux";
import { produce } from "immer";
import ReactEcharts from "echarts-for-react";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";

// utility imprts
import _ from "lodash";
// import axios from "axios";

import Config from "./Config";
// import echarts from 'echarts/lib/echarts';

// import actions
// import { setConfig } from "./BarChartSlice";
// import {
//   toggleShowConfig,
//   showToast,
// } from "../../analytics_widget/AnalyticsWidgetSlice";

// css imports
import styles from "./BarChart.module.css";

var theme = useConfigStore.getState().theme;

class BarChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      contextMenuOpen: false,
      mousePos: {
        x: 0,
        y: 0,
      },
      contextMenuInfo: {
        xAxisKey: null,
        xAxisValue: null,
      },
    };

    this.chart = React.createRef();
  }

  componentDidMount() {
    // this.chart = React.createRef();
    if (this.props.config !== undefined) {
      // to set previous session zoom settings
      if (
        this.props.config.zoom &&
        this.props.config.zoom.batch[0] &&
        this.chart &&
        this.chart.current
      ) {
        this.chart.current.getEchartsInstance().dispatchAction({
          type: "dataZoom",
          batch: [
            {
              startValue: this.props.config.zoom.batch[0].startValue,
              endValue: this.props.config.zoom.batch[0].endValue,
            },
          ],
        });
      }

      // to set previous session legend selected settings
      if (this.props.config.legend && this.chart && this.chart.current) {
        let unSelected = [];
        Object.keys(this.props.config.legend).forEach((key) => {
          if (this.props.config.legend[key] == false) {
            unSelected.push(key);
          }
        });

        for (let i = 0; i < unSelected.length; i++) {
          this.chart.current.getEchartsInstance().dispatchAction({
            type: "legendUnSelect",
            name: unSelected[i],
          });
        }
      }
    }
  }

  //to store legend information
  onLegendChanged = (params) => {
    const config = { ...this.props.config };
    config["legend"] = params.selected;

    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };

  //to store zoom config
  onZoom = (params) => {
    const config = { ...this.props.config };
    config["zoom"] = params;

    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };

  //to store magic type
  onMagictypechanged = (params) => {
    const config = { ...this.props.config };

    if (params.currentType !== "stack") {
      config["series_type"] = params.currentType;
    } else {
      if (
        params.newOption &&
        params.newOption.series[0] &&
        params.newOption.series[0].hasOwnProperty("stack") &&
        params.newOption.series[0].stack !== ""
      ) {
        config["stack"] = params.currentType;
      } else {
        delete config.stack;
      }
    }
    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };

  onChartClick = (params) => {
    const mousePos = {
      x: params.event.event.pageX,
      y: params.event.event.pageY,
    };
    this.setState({
      mousePos: mousePos,
      contextMenuOpen: true,
      xAxisKey: _.get(useGlobalStore.getState()[this.props.id], "data", {})
        .xAxis.name,
      xAxisValue: params.name,
    });
  };

  handleMenuClose = () => {
    this.setState({
      contextMenuOpen: false,
    });
  };

  showDataHandler = () => {
    this.props.showToast({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      severity: "info",
      message: "Work in progress",
    });

    this.handleMenuClose();
    // get config
    // const config = this.context.allReports[this.context.currentReportName].widgets[this.props.id]
    //   .config;

    // this.handleMenuClose();
    // const request = {
    //   bucket: config.bucket,
    //   key: config.dataLocation,
    //   ldb_file: config.data,
    //   columns: _.get(config, "columns", []),
    //   x_key: this.state.xAxisKey,
    //   x_value: this.state.xAxisValue,
    //   stack: config.stack,
    //   series_type: config.series_type,
    // };

    // axios
    //   .post(this.context.analyticsBackendUrl + "/api/fetch_widget_details", request)
    //   .then((response) => {
    //     response = response.data;
    //     const requestStatus = _.get(response, "status", false);
    //     const plotData = _.get(response, "data", {});
    //     const message = _.get(response, "message", "No valid response from server");
    //     if (!requestStatus) {
    //       this.setState({
    //         isToastOpen: true,
    //         toastMessage: message,
    //         toastSeverity: "error",
    //       });
    //     } else {
    //       // get y coord and height of current widget
    //       const yCoord = this.context.allReports[this.context.currentReportName].widgets[
    //         this.props.id
    //       ].y;

    //       const tableConfig = {
    //         dataLocation: config.dataLocation,
    //         data: config.data,
    //         columns: config.columns,
    //       };

    //       // add table view widget below
    //       this.context.addWidgets([
    //         {
    //           name: "Table View",
    //           width: 15,
    //           height: 9,
    //           y: yCoord + 1,
    //           config: tableConfig,
    //           data: plotData,
    //         },
    //       ]);
    //     }
    //   })
    //   .catch((error) => {
    //     console.log(error);

    //     this.setState({
    //       isToastOpen: true,
    //       toastMessage: error.message,
    //       toastSeverity: "error",
    //     });
    //   });
  };

  // Function to get update option
  getEchartsOption(option) {
    const updatedOption = produce(option, (optionDraft) => {
      if (
        "min_value" in optionDraft &&
        "max_value" in optionDraft &&
        (optionDraft.min_value > 1000 || optionDraft.max_value > 10000)
      ) {
        let multiplier = optionDraft.min_value.toString().length - 1;
        if (multiplier < 3) {
          multiplier = optionDraft.max_value.toString().length - 1;
        }
        optionDraft["yAxis"]["axisLabel"] = {
          formatter: function (value, index) {
            return value / Math.pow(10, multiplier);
          },
        };
        optionDraft["yAxis"]["name"] =
          optionDraft["yAxis"]["name"] + " (10^" + multiplier + ")";
        // optionDraft["height"] = "100%";
        // optionDraft["width"] = "100%";
        optionDraft["backgroundColor"] = theme == "dark" ? "rgb(50,50,50)" : "";
      }
    });
    return updatedOption;
  }

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
    // this.props.toggleShowConfig({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    // });
  };

  // render method
  render() {
    // define event dict
    // const eventDict = {
    //   click: this.onChartClick,
    //   dataZoom: this.onZoom,
    //   legendselectchanged: this.onLegendChanged,
    //   magictypechanged: this.onMagictypechanged,
    // };

    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (uiState.showConfig) {
      return (
        <Config updateConfig={this.updateConfig} config={this.props.config} />
      );
    } else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <div style={{ height: "100%", width: "100%", position: "relative" }}>
          <ReactEcharts
            ref={this.chart}
            style={{
              height: "100%",
              width: "100%",
              backgroundColor: theme == "dark" ? "rgb(50,50,50)" : "",
            }}
            // height={"100%"}
            option={this.getEchartsOption(data)}
            theme={theme}
            // onEvents={eventDict}
            notMerge={true}
          />

          <Menu
            anchorReference="anchorPosition"
            anchorPosition={{
              top: this.state.mousePos.y,
              left: this.state.mousePos.x,
            }}
            keepMounted
            open={this.state.contextMenuOpen}
            onClose={this.handleMenuClose}
          >
            <MenuItem onClick={this.showDataHandler}>Show Data</MenuItem>
          </Menu>
        </div>
      );
    }
  }
}

// const mapDispatchToProps = (dispatch) => {
//   return {
//     setConfig: (payload) => dispatch(setConfig(payload)),
//     showToast: (payload) => dispatch(showToast(payload)),
//     toggleShowConfig: (payload) => dispatch(toggleShowConfig(payload)),
//   };
// };

// const mapStateToProps = (state, props) => {
//   return {
//     currentReportName: state.currentReportName,
//     config: state.allReports[state.currentReportName].widgets[props.id].config,
//     data: _.get(state["Group Bar Chart"], props.id, {}),
//     theme: _.get(state.allReports[state.currentReportName], "theme", "light"),
//     uiState: _.get(
//       state.allReports[state.currentReportName].widgets[props.id],
//       "uiState",
//       {
//         isLoading: false,
//         showConfig: false,
//         isToastOpen: false,
//         toastSeverity: "info",
//         toastMessage: "",
//       }
//     ),
//   };
// };

// export default connect(mapStateToProps, mapDispatchToProps)(BarChart);

BarChart.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};

export default BarChart;
