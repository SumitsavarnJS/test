import useGlobalStore from "../../../../store/useGlobalStore";
import useConfigStore from "../../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import api from "../../../../common/api/api";

const getInterClockMatrixInput = (config) => {
  const input = {
    bucket: _.get(config, "bucket", ""),
    key: `${_.get(config, "dataLocation", "")}/${_.get(
      config,
      "scenario",
      ""
    )}`,
    user: `${useConfigStore.getState().authLoginUser}`,
    feature: _.get(config, "feature", ""),
    scenario: _.get(config, "scenario", ""),
  };

  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/api/fetch_clock_path_matrix",
    input
  );

  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }
};

const refreshInterClockMatrix = (widgetId, config) => {
  fetchWidgetData(widgetId, getInterClockMatrixInput(config));
};

export default refreshInterClockMatrix;
