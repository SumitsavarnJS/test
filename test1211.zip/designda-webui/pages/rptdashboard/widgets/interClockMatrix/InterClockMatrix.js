// react imports
import React from "react";
import Typography from "@mui/material/Typography";
import ReactEcharts from "echarts-for-react";
import { produce } from "immer";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import axios from "axios";
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";

// utility imports
import _ from "lodash";

import Config from "./Config";
import refreshTableView from "../tableView/TableViewApis";
import refreshGroupBarChart from "../../../../components/widgets/group_bar_chart/GroupBarChartApi";

import { toast } from "react-toastify";

// css imports
import styles from "./InterClockMatrix.module.css";

const theme = useConfigStore.getState().theme;

import { Stack } from "@mui/material";
import * as addWidgets from "../../addWidget/addWidget";

class InterClockMatrix extends React.Component {
  // constructor
  constructor(props) {
    super(props);
    this.state = {
      contextMenuOpen: false,
      mousePos: {
        x: 0,
        y: 0,
      },
      data: _.get(useGlobalStore.getState()[this.props.id], "data", {}),
      sp: null,
      ep: null,
    };
  }

  // as component mounts, find the parent div for the inter-clock-matrix widget and
  // disable right click on that div
  componentDidMount() {
    const widgetDiv = document.getElementById("interClockMatrixChart");
    if (widgetDiv) {
      widgetDiv.addEventListener("contextmenu", (e) => {
        e.preventDefault();
      });
    }
  }

  showTimingPaths = () => {
    this.setState({ isLoading: true });
    const config = this.props.widgetProps.config;

    const request = {
      startPoint: this.state.sp,
      endPoint: this.state.ep,
      bucket: _.get(config, "bucket"),
      key: `${_.get(config, "dataLocation", "")}/${_.get(
        config,
        "scenario",
        ""
      )}`,
      filterType: "clock",
    };

    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/get_timing_paths_from_matrix",
        request
      )
      .then((response) => {
        console.log(response);
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", {});
        const dataLocation = `${_.get(config, "dataLocation", "")}/${_.get(
          config,
          "scenario",
          ""
        )}`;
        const data = _.get(response, "file", {});
        const query = _.get(response, "query", "");
        const bucket = _.get(response, "bucket", {});
        const col = _.get(response, "columns", []);
        const initCol = _.get(response, "initCol", []);
        const rows = _.get(response, "rows", []);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
        } else {
          // add table view widget below
          const configTableView = {
            title: dataLocation.includes("task_reports")
              ? `Degrading Timing Paths from ${this.state.sp} to ${this.state.ep}`
              : `Timing Paths from ${this.state.sp} to ${this.state.ep}`,
            dataLocation: dataLocation,
            data: data,
            bucket: bucket,
            query: "df = df.sort_values('slack', ascending = True)", //query,
            columns: initCol,
            cache_key: cache_key,
          };
          const { h, w, x, y } = this.props.widgetProps;
          const tableViewWidgetSettings = {
            name: "Table View",
            h: h,
            w: w,
            y: y,
            x: x,
            config: configTableView,
          };
          const addedWidgetIdList = addWidgets.addWidgetCommonFunction(
            this.props.rptType,
            this.props.reportKey,
            tableViewWidgetSettings,
            {},
            addWidgets.showWidgetDataUiState,
            this.props.index,
          );
        refreshTableView(addedWidgetIdList[0], configTableView);
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        console.log(error);
        this.setState({ isLoading: false });
      });
    this.handleMenuClose();
  };

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  formatTooltip = (params) => {
    return `<div style="font-weight: bold">
    <span style="color:blue">From:</span> ${
      this.state.data.sp_list[params.data[1]]
    }<br />
            <span style="color:green">To:</span> ${
              this.state.data.ep_list[params.data[0]]
            }<br />
            <span style="color: red">${
              this.props.widgetProps.config.feature
            }: </span>${params.data[2]}</div>`;
  };

  showGridTileLabel = () => {
    const dimensions = _.get(this.props, "dimensions", { w: 0, h: 0 });
    const ep_list = _.get(this.state.data, "ep_list", []);
    if (dimensions.w / ep_list.length > 1.2) {
      return true;
    }
    return false;
  };

  showDiagnosticSummary = () => {
    this.setState({ isLoading: true });
    const config = this.props.widgetProps.config;

    const bucket = _.get(config, "bucket", "");
    const dataLocation = `${_.get(config, "dataLocation", "")}/${_.get(
      config,
      "scenario",
      ""
    )}`;
    const request = {
      bucket: bucket,
      key: `${_.get(config, "dataLocation", "")}/${_.get(
        config,
        "scenario",
        ""
      )}`,
      feature: _.get(config, "feature", ""),
      sp_inst: this.state.sp,
      ep_inst: this.state.ep,
      filterType: "clock",
    };

    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/fetch_diagnostic_summary",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        const data = _.get(response, "data", {});
        const defaultQueryBody = `# Data has been loaded in df variable
# Please modify the df variable to contain data needed for the plot
#
# Grouping axis X -
#   * First 2 columns plot X axis
#   * The last column (numerical) plots Y axis
#
# Grouping axis Y -
#   * 1st column plots X axis
#   * Rest all columns (numerical) plot Y axis
df = df.compute()
`;
        if (!requestStatus) {
        } else {
          const configGroupBarChart = {
            title: `Timing Path Diagnostics Summary : From {${this.state.sp}} to {${this.state.ep}}`,
            dataLocation: dataLocation,
            bucket: bucket,
            data: "das_timing_path_data.ldb",
            columns: _.get(data, "columns"),
            // either get query from response OR use defaultQueryBody
            // some issues occur if response-query is used
            query: defaultQueryBody,
            groupingAxis: "X",
          };
          const { h, w, x, y } = this.props.widgetProps;
          const groupBarChartWidgetSettings = {
            name: "Group Bar Chart",
            h: h,
            w: w,
            y: y,
            x: x,
            config: configGroupBarChart,
          };
          const addedWidgetIdList = addWidgets.addWidgetCommonFunction(
            this.props.rptType,
            this.props.reportKey,
            groupBarChartWidgetSettings,
            {},
            addWidgets.showWidgetDataUiState,
            this.props.index
          );
          // const addedWidgetId = addWidgets.addWidgetToDashboard({
          //   name: "Group Bar Chart",
          //   h: h,
          //   w: w,
          //   y: y,
          //   x: x,
          //   config: configGroupBarChart,
          // });

          refreshGroupBarChart(addedWidgetIdList[0], configGroupBarChart);
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        this.setState({ isLoading: false });
      });
    this.handleMenuClose();
  };

  onContextMenu = (params, echarts) => {
    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    // show context menu for task data only
    const mousePos = {
      x: params.event.event.pageX,
      y: params.event.event.pageY,
    };
    this.setState({
      mousePos: mousePos,
      contextMenuOpen: true,
      sp: data.sp_list[params.data[1]],
      ep: data.ep_list[params.data[0]],
    });
  };

  handleMenuClose = () => {
    this.setState({
      contextMenuOpen: false,
    });
  };

  render() {
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (!this.chart) {
      this.chart = React.createRef();
    }
    // define event dict
    const eventDict = {
      contextmenu: this.onContextMenu,
    };
    if (Object.keys(this.state.data).length > 0) {
      var option = produce(this.state.data.option, (optionDraft) => {
        optionDraft["tooltip"]["formatter"] = this.formatTooltip;
        optionDraft["tooltip"]["position"] = "top";
        optionDraft["tooltip"]["confine"] = true;
        optionDraft["lazyUpdate"] = true;
        optionDraft["series"][0]["label"]["show"] = this.showGridTileLabel();
      });
    }
    if (uiState.showConfig) {
      return (
        <Config
          updateConfig={this.updateConfig}
          config={this.props.widgetProps.config}
        />
      );
    } else {
      return Object.keys(this.state.data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No Data. Please refresh this widget!
        </Typography>
      ) : (
        <React.Fragment>
          <div id="interClockMatrixChart" className={styles.matrixDiv}>
            <ReactEcharts
              ref={this.chart}
              onEvents={eventDict}
              style={{ height: "100%" }}
              option={option}
              theme={theme}
              notMerge={true}
            />

            <Menu
              anchorReference="anchorPosition"
              anchorPosition={{
                top: this.state.mousePos.y,
                left: this.state.mousePos.x,
              }}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              variant="menu"
              keepMounted
              open={this.state.contextMenuOpen}
              style={{ display: "block" }}
              onClose={this.handleMenuClose}
            >
              <Stack>
                <MenuItem onClick={this.showTimingPaths}>
                  Show Timing Paths
                </MenuItem>
                {_.get(this.props.widgetProps.config, "dataLocation", "#")
                  .split("#")[1]
                  .startsWith("task") ? (
                  <MenuItem onClick={this.showDiagnosticSummary}>
                    Show Diagnostics Summary
                  </MenuItem>
                ) : null}
              </Stack>
            </Menu>
            <div className={styles.footer}>
              Feature: {_.get(this.props.widgetProps.config, "feature", "")}
              &ensp;
              Scenario: {_.get(this.props.widgetProps.config, "scenario", "")}
            </div>
          </div>
        </React.Fragment>
      );
    }
  }
}

InterClockMatrix.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};

export default InterClockMatrix;
