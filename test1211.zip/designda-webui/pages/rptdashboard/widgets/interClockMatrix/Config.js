import React from "react";
import { connect } from "react-redux";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Popup from "reactjs-popup";

// utility imprts
import _ from "lodash";
import axios from "axios";

// data source table
import DataSource from "../../data_source/DataSource";

// import { showToast } from "../../analytics_widget/AnalyticsWidgetSlice";

// import "ace-builds/src-noconflict/mode-python";
// import "ace-builds/src-noconflict/theme-xcode";
// import "brace/ext/language_tools";
import dynamic from "next/dynamic";

import styles from "./Config.module.css";

import useConfigStore from "../../../../store/useConfigStore";
import { Box } from "@mui/material";
import { ClickAwayListener } from "@mui/base";

const AceEditor = dynamic(
  () =>
    import("../../../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);


class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      dataLocation: _.get(this.props.config, "dataLocation", ""),
      bucket: _.get(this.props.config, "bucket", ""),
      feature: _.get(this.props.config, "feature", ""),
      setupScenarioList: _.get(this.props.config, "setupScenarioList", []),
      scenario: _.get(this.props.config, "scenario", ""),
    };
  }

  componentDidMount() {
    const config = _.get(this.props, "config", {});
    const bucket = _.get(config, "bucket", "");
    const key = _.get(config, "dataLocation", "");
    if (bucket && key) {
      this.getSetupScenarioList(bucket, key);
    }
  }

  dataLocationChanged = (newDataLocation, bucket) => {
    this.setState({
      bucket: bucket,
      dataLocation: newDataLocation.split("/").slice(0, -1).join("/"),
    });
    this.getSetupScenarioList(
      bucket,
      newDataLocation.split("/").slice(0, -1).join("/")
    );
  };

  getSetupScenarioList = (bucket, newDataLocation) => {
    const data = { bucket: bucket, key: newDataLocation };
    axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") + "/api/fetch_setup_scenario_list",
        data
      )
      .then((response) => {
        const data = _.get(response.data, "data", {});
        if (!_.get(response.data, "status", true)) {
          this.props.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message:
              "Required files are not avaiable for the selected data source",
          });
        } else {
          this.setState({
            setupScenarioList: data,
          });
          const config = _.get(this.props, "config", {});
          if (_.get(config, "dataLocation", "") !== newDataLocation) {
            this.setState({ scenario: "" });
          }
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  onSave = () => {
    const config = {};
    config["dataLocation"] = this.state.dataLocation;
    config["feature"] = this.state.feature;
    config["bucket"] = this.state.bucket;
    config["scenario"] = this.state.scenario;

    // add title only if user has provided it
    if (this.state.title.length > 0) {
      config["title"] = this.state.title;
    }
    this.props.updateConfig(config, true);
  };

  //disable Ok button if required fileds are not selected

  disableOk = () => {
    const config = this.state;
    if (
      config.dataLocation &&
      config.dataLocation.split("#")[1].startsWith("flow") &&
      config.feature &&
      config.scenario
    ) {
      return false;
    } else if (
      config.dataLocation &&
      config.dataLocation.split("#")[1].startsWith("task") &&
      config.feature &&
      config.scenario
    ) {
      return false;
    }
    return true;
  };

  helperText = (property) => {
    if (!this.state[property]) {
      return "Entry required";
    }
  };

  showErrorInput = (property) => {
    if (!this.state[property]) {
      return true;
    }
    return false;
  };

  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Select Data Source if it is not derived*/}
        {this.state.sp_inst || this.state.ep_inst ? null : (
       <div className={styles.inline}>
       <Button
         size="small"
         classes={{ root: styles.add_button }}
         onClick={() => this.setState({ showDataSource: true })}
       >
         Data Source
       </Button>
       {this.state.showDataSource ? (
         <ClickAwayListener
           onClickAway={() => {
             this.setState({ showDataSource: false });
           }}
         >
           <Box
             sx={{
               zIndex: "5",
               position: "absolute",
               top: "0px",
               left: "0px",
               width: "100%",
               height: "fit-content",
               backgroundColor: "white",
               padding: "5px",
               boxShadow: "grey 5px 5px 5px",
             }}
           >
             <DataSource
               dataLocationChanged={this.dataLocationChanged}
               dataLocation={this.state.dataLocation}
               bucket={this.state.bucket}
               close={() => {
                 this.setState({ showDataSource: false });
               }}
             />
           </Box>
         </ClickAwayListener>
       ) : null}
       <Typography
         variant="body2"
         style={{ marginTop: "15px", marginLeft: "15px" }}
       >
         {this.state.dataLocation.split("#")[1]}
       </Typography>
     </div>

        )}

        {/* Select level */}
        <Autocomplete
          id="data-input"
          style={{ marginTop: "10px" }}
          value={this.state.scenario}
          onChange={(event, newValue) => {
            this.setState({ scenario: newValue });
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.setupScenarioList}
          getOptionLabel={(option) => option.toString()}
          renderInput={(params) => (
            <TextField
              {...params}
              required
              error={this.showErrorInput("scenario")}
              helperText={this.helperText("scenario")}
              label="Scenario"
              variant="outlined"
            />
          )}
        />

        {/* Select Feature */}
        <Autocomplete
          id="data-input"
          style={{ marginTop: "10px" }}
          value={this.state.feature}
          onChange={(event, newValue) => {
            this.setState({ feature: newValue });
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={
            this.state.dataLocation &&
            this.state.dataLocation.split("#")[1].startsWith("flow")
              ? []
              : ["TNS", "WNS", "NVP", "path_count"]
          }
          renderInput={(params) => (
            <TextField
              {...params}
              required
              error={this.showErrorInput("feature")}
              helperText={this.helperText("feature")}
              label="Feature"
              variant="outlined"
            />
          )}
        />

<Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={this.onSave}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={() => {
            this.props.updateConfig({}, false);
          }}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}

// const mapDispatchToProps = (dispatch) => {
//   return {
//     showToast: (payload) => dispatch(showToast(payload)),
//   };
// };

// const mapStateToProps = (state) => {
//   return {
//     currentReportName: state.currentReportName,
//     analyticsBackendUrl: state.config.analyticsBackendUrl,
//     fullScreenWidget: state.fullScreenWidget,
//   };
// };

export default (Config);
