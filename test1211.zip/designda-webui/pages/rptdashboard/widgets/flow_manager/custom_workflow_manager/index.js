import React, { Component } from "react";

import { connect } from "react-redux";

import { ReactTabulator, reactFormatter } from "react-tabulator";

//import { globFilter } from "common/Funcs";

import useConfigStore from "../../../../../store/useConfigStore";






// utility imports

import axios from "axios";

import _ from "lodash";



 //import Config from '../../../widgets/flow_manager/Config'



// import actions

// import {

//     showToast,

//     toggleShowConfig,

// } from "../../../analytics_widget/AnalyticsWidgetSlice";

// import {

//     setConfig,

//     setData,

//     refreshCustomWorkflowData,

// } from "./CustomWorkflowManagerSlice";

import { Stack } from "@mui/material";



// css imports

// import styles from "./CustomWorkflowManager.module.css";



class CustomWorkflowManager extends Component {
  


    constructor(props) {

        super(props);



        this.state = {

            contextMenuOpen: false,

            mousePos: {

                x: 0,

                y: 0,

            },

            rightClickedRow: null,

        };



        this.columns = [

            {

                title: "User",

                field: "user",

                //headerFilterFunc: globFilter,

            },

            {

                title: "Workflow",

                field: "workflow",

                //headerFilterFunc: globFilter,

            },

            {

                title: "Workflow Name",

                field: "workflow_title",

                //headerFilterFunc: globFilter,

            },

            {

                title: "Date",

                field: "date",

                sorter: "date",

                sorterParams: { format: "DD-MM-YYYY" },

            },

            { title: "Time", field: "time", },

            {

                title: "Status",

                field: "status",

                formatter: this.getWorkflowStatus,

                //headerFilterFunc: globFilter,

                // width: 50,

            },

        ];

    }



    componentDidMount() {

        // create axios instance to query workflow manager

        this.workflowManager = axios.create({

            baseURL: 'http://us01odc-sc5-1-faa001:24565/backend' + "/api/workflow_manager",

        });



        // refresh table

        this.refreshCustomWorkflowData(this.props.reportName, this.props.id);



        // manage autorefresh

        this.manageAutoRefresh();

    }



    componentDidUpdate(nextProps, nextState) {

        // manage autorefresh

        this.manageAutoRefresh();



        // table related updates

        if (!this.tableRef.current) {

            return;

        }

        const table = this.tableRef.current;

        if (!table) {

            return;

        }



        // get selected rows

        const selectedRows = table.getSelectedRows();

        const selectedIds = [];

        selectedRows.forEach((value, index, array) => {

            selectedIds.push(value._row.data.id);

        });



        // update table data

        // table.replaceData(_.get(this.props.data, "workflows", []));
        table.replaceData(this.state.data);




        // re-select all previously selected rows

        if (selectedIds.length > 0) {

            table.selectRow(selectedIds);

        }

    }



    componentWillUnmount = () => {

        if (this.websocket) {

            this.websocket.close();

            this.websocket = null;

        }

    };



    getRowContextMenu = (e, position) => {

        const validStatesToKill = ["pending", "queued", "running"];

        const validStatesToReRun = ["failed", "killed"];

        const validStatesToDelete = ["new", "success", "failed", "killed"];

        let status = "";

        let reportName = "";

        let row_data = {};

        if (e._row) {

            status = e._row.data.status;

            reportName = e._row.data.workflow_name;

            row_data = e._row.data;

        }



        let userAuth = false;

        if (row_data.user === this.props.user.userid || this.props.user.adminFlag) {

            userAuth = true;

        }

        let ret = [

            {

                label: "<i class='fas fa-user'></i> View Log",

                action: () => {

                    this.handleViewLog(reportName);

                },

            },

        ]



        if (status === "new" && userAuth) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Run",

                    action: () => {

                        this.handleRunWorkflow(row_data);

                    },

                },

            )

        }

        if (validStatesToReRun.includes(status) && userAuth) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Run",

                    action: () => {

                        this.handleRunWorkflow(row_data);

                    },

                },

            )

        }

        if (validStatesToKill.includes(status) && userAuth) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Kill",

                    action: () => {

                        this.handleKillWorkflow(row_data);

                    },

                },

            )

        }

        if (validStatesToDelete.includes(status) && userAuth) {

            ret.push(

                {

                    label: "<i class='fas fa-user'></i> Delete",

                    action: () => {

                        this.handleDeleteWorkflow(row_data);

                    },

                },

            )

        }

        return ret

    };



    getWorkflowStatus = (cell, formatterParams) => {

        const workflowStatus = cell.getValue();



        let bgColor = "black";

        if (workflowStatus === "running") {

            bgColor = "#03c03c";

        } else if (workflowStatus === "queued") {

            bgColor = "#e67e00";

        } else if (workflowStatus === "pending") {

            bgColor = "#003366";

        } else if (workflowStatus === "success") {

            bgColor = "#177245";

        } else if (workflowStatus === "failed") {

            bgColor = "#DC143C";

        } else if (workflowStatus === "killing") {

            bgColor = "#800000";

        } else if (workflowStatus === "deleting") {

            bgColor = "#800000";

        } else if (workflowStatus === "killed") {

            bgColor = "#454545";

        } else if (workflowStatus === "new") {

            bgColor = "#0d98ba";

        }



        const element = cell.getElement();

        element.style.color = "white";

        element.style["font-weight"] = "bold";

        element.style["text-align"] = "center";

        element.style["background-color"] = bgColor;



        return workflowStatus;

    };



    handleViewLog = (workflowName) => {

        const link = `${'http://us01odc-sc5-1-faa001:24565/backend'}/api/workflow_manager/log_viewer/custom/${workflowName}`;

        window.open(link, "_blank");

        // close context menu

        // this.handleMenuClose();

    };



    handleDeleteWorkflow = (row) => {

        // refresh data

        this.props.refreshCustomWorkflowData(this.props.reportName, this.props.id);



        const flow_info = {

            workflow_name: row.workflow_name,

            user: row.user,

        };



        this.workflowManager

            .post("/delete_custom_workflow", flow_info)

            .then((response) => {

                response = response.data;

                const success = _.get(response, "success", false);



                if (!success) {

                    this.props.showToast({

                        reportName: this.props.currentReportName,

                        widgetId: this.props.id,

                        severity: "error",

                        message: `Failed to delete workflow - ${row.workflow_name}`,

                    });

                } else {

                    const table = this.tableRef.current;

                    table.updateData([{ id: row.id, status: "deleting" }]);

                }

            })

            .catch((error) => {

                this.props.showToast({

                    reportName: this.props.currentReportName,

                    widgetId: this.props.id,

                    severity: "error",

                    message: "Failed to connect to Server",

                });

                console.log(error);

            });



        // close context menu

        // this.handleMenuClose();

    };



    handleKillWorkflow = (row) => {

        // refresh data

        this.props.refreshCustomWorkflowData(this.props.reportName, this.props.id);



        const flow_info = {

            workflow_name: row.workflow_name,

            user: row.user,

        };



        this.workflowManager

            .post("/kill_custom_workflow", flow_info)

            .then((response) => {

                response = response.data;

                const success = _.get(response, "success", false);



                if (!success) {

                    this.props.showToast({

                        reportName: this.props.currentReportName,

                        widgetId: this.props.id,

                        severity: "error",

                        message: `Failed to kill workflow - ${row.workflow_name}`,

                    });

                } else {

                    const table = this.tableRef.current;

                    table.updateData([{ id: row.id, status: "killing" }]);

                }

            })

            .catch((error) => {

                this.props.showToast({

                    reportName: this.props.currentReportName,

                    widgetId: this.props.id,

                    severity: "error",

                    message: "Failed to connect to Server",

                });

                console.log(error);

            });



        // close context menu

        // this.handleMenuClose();

    };



    // handleMenuClose = () => {

    //   this.setState({

    //     contextMenuOpen: false,

    //   });

    // };



    // handleRowContextEvent = (event, row) => {

    //   event.preventDefault();

    //   const mousePos = {

    //     x: event.pageX,

    //     y: event.pageY,

    //   };



    //   this.setState({

    //     mousePos: mousePos,

    //     contextMenuOpen: true,

    //     rightClickedRow: row,

    //   });

    // };



    handleRunWorkflow = (row) => {

        // refresh data

        this.props.refreshCustomWorkflowData(this.props.reportName, this.props.id);



        const workflow_info = {

            workflow_name: row.workflow_name,

            user: row.user,

            new_workflow: false,

        };



        this.workflowManager

            .post("/run_custom_workflow", workflow_info)

            .then((response) => {

                response = response.data;

                const success = _.get(response, "success", false);



                if (!success) {

                    const message = _.get(response, "message", "Unknown error");

                    this.props.showToast({

                        reportName: this.props.currentReportName,

                        widgetId: this.props.id,

                        severity: "error",

                        message: `Failed to run workflow - ${message}`,

                    });

                } else {

                    const table = this.tableRef.current;

                    table.updateData([{ id: row.id, status: "pending" }]);

                }

            })

            .catch((error) => {

                this.props.showToast({

                    reportName: this.props.currentReportName,

                    widgetId: this.props.id,

                    severity: "error",

                    message: "Failed to connect to Server",

                });

                console.log(error);

            });



        // close context menu

        // this.handleMenuClose();

    };



    // Function to manage auto refresh

    manageAutoRefresh = () => {

        const autoRefresh = _.get(this.props.config, "autoRefresh", false);

        if (!this.websocket && autoRefresh) {

            this.startAutoRefresh();

        } else if (this.websocket && !autoRefresh) {

            this.stopAutoRefresh();

        }

    };

  refreshCustomWorkflowData = (reportName, widgetId) =>  {

        // const state = getState();
      
        const endpoint = 'http://us01odc-sc5-1-faa001:24565/backend' + "/api/workflow_manager/get_custom_workflows";
      
        axios
      
          .get(endpoint)
      
          .then((response) => {
      
            response = response.data;
      
            const requestStatus = _.get(response, "success", false);
      
            const workflows = _.get(response, "workflows", {});
      
            const message = _.get(response, "message", "No valid response from server");
      
            if (!requestStatus) {
      
              // show toast
      
            //   dispatch(
      
            //     showToast({
      
            //       reportName: reportName,
      
            //       widgetId: widgetId,
      
            //       severity: "error",
      
            //       message: message,
      
            //     })
      
            //   );
      
            } else {
                this.setState({ data: workflows });
      
              // set data
      
            //   dispatch(
      
            //     setData({
      
            //       widgetId: widgetId,
      
            //       data: { workflows: workflows },
      
            //     })
      
            //   );
      
            }
      
          })
      
          .catch((error) => {
      
            console.log(error);
      
            // show toast
      
            // dispatch(
      
            //   showToast({
      
            //     reportName: reportName,
      
            //     widgetId: widgetId,
      
            //     severity: "error",
      
            //     message: "Internal server error",
      
            //   })
      
            // );
      
          });
      
      };
      



    // Function to create websocket connection for auto-refresh

    startAutoRefresh = () => {

        // create websocket

        // replace http with ws or https with wss

        const websocketUrl = 'http://us01odc-sc5-1-faa001:24565/backend'.replace("http", "ws");

        this.websocket = new WebSocket(

            websocketUrl + "/api/workflow_manager/get_custom_workflows_ws"

        );



        this.websocket.onopen = () => {

            try {

                // this.websocket.send(`import os;os.environ["ANALYTICS_USER"]="${this.context.user.userid}";`);

                // get response

                this.websocket.onmessage = (event) => {

                    const data = JSON.parse(event.data);

                    if (data.success === true) {

                        this.props.setData({

                            widgetId: this.props.id,

                            data: { workflows: data.workflows },

                        });

                    } else {

                        this.props.showToast({

                            reportName: this.props.currentReportName,

                            widgetId: this.props.id,

                            severity: "error",

                            message: data.message,

                        });

                    }

                };

            } catch (error) {

                this.props.showToast({

                    reportName: this.props.currentReportName,

                    widgetId: this.props.id,

                    severity: "error",

                    message: "Failed to connect to Server",

                });

                console.log(error); // catch error

            }

        };



        this.websocket.onclose = (event) => {

            // re-establish the connection on abnormal closure

            if (event.code == 1006) {

                console.warn(

                    "Custom Workflow Manager websocket connection broken. Reconnecting ..."

                );

                this.startAutoRefresh();

            }

        };

    };



    // Function to destroy existing websocket connection for auto-refresh

    stopAutoRefresh = () => {

        this.websocket.close();

        this.websocket = null;

    };



    // Function to update config

    updateConfig = (config, save) => {

        if (save) {

            this.props.setConfig({

                reportName: this.props.currentReportName,

                widgetId: this.props.id,

                config: config,

            });

        }



        this.props.toggleShowConfig({

            reportName: this.props.currentReportName,

            widgetId: this.props.id,

        });



        // refresh table data

        this.props.refreshCustomWorkflowData(this.props.reportName, this.props.id);

    };



    applyTheme = (theme) => {

        if (theme == "dark") {

            return "table-sm table-dark table-striped table-bordered";

        } else {

            return "table-sm table-striped table-bordered";

        }

    };



    render() {

        if (!this.tableRef) {

            this.tableRef = React.createRef();

        }



        // Render config editor if requested

        // if (this.props.uiState.showConfig) {

        //     return (

        //         <Config updateConfig={this.updateConfig} config={this.props.config} />

        //     );

        // }



        const options = {

            selectable: true,

            pagination: true, //enable pagination

            paginationMode: "local",

            paginationSize: "10",

            persistenceID: _.get(this.props.config, "tableId", this.props.id),

            persistenceMode: true,

            rowContextMenu: this.getRowContextMenu,

            persistence: {

                columns: true, //persist changes to the width, visible and frozen properties

            },

            columnDefaults: {

                headerFilter: true,

                headerFilterLiveFilter: false,

                headerFilterPlaceholder: "...",

                tooltip: true,

            },

        };



        return (

            <div id="analytics">

                <ReactTabulator

                    key={this.props.theme}

                    className={this.applyTheme(this.props.theme)}

                    style={{ marginTop: "10px" }}

                    layout="fitColumns"

                    autoResize={false}

                    onRef={(ref) => (this.tableRef = ref)}

                    columns={this.columns}

                    // data={[]}

                    options={options}

                // events={{

                //   rowContext: (event, row) => {

                //     this.handleRowContextEvent(event, row);

                //   },

                // }}

                />



                {/* Get row context menu */}

                {/* {this.getRowContextMenu()} */}

            </div>

        );

    }

}



const mapDispatchToProps = (dispatch) => {

    return {

        refreshCustomWorkflowData: (reportName, widgetId) =>

            dispatch(refreshCustomWorkflowData(reportName, widgetId)),

        setConfig: (payload) => dispatch(setConfig(payload)),

        setData: (payload) => dispatch(setData(payload)),

        showToast: (payload) => dispatch(showToast(payload)),

        toggleShowConfig: (payload) => dispatch(toggleShowConfig(payload)),

    };

};



const mapStateToProps = (state, props) => {

    return {

        data: _.cloneDeep(_.get(state["Custom Workflow Manager"], props.id, {})),

        theme: _.get(state.allReports[state.currentReportName], "theme", "light"),

        endPointUrl: state.config.endPointUrl,

        currentReportName: state.currentReportName,

        config: state.allReports[state.currentReportName].widgets[props.id].config,

        user: state.config.user,

        uiState: _.get(

            state.allReports[state.currentReportName].widgets[props.id],

            "uiState",

            {

                isLoading: false,

                showConfig: false,

                isToastOpen: false,

                toastSeverity: "info",

                toastMessage: "",

            }

        ),

    };

};



export default (CustomWorkflowManager);

