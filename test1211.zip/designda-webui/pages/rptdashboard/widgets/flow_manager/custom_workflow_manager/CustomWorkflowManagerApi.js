import useGlobalStore from "../../../../../store/useGlobalStore";
import useConfigStore from "../../../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import getApi from "../../../../../common/api/getApi";

const getcustomWorkFlowInput = (config) => {
  return null;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await getApi(
    useConfigStore.getState().configData.rest_server_url +
      "/api/workflow_manager/get_custom_workflows"
  );

  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }

  if (fetchData.success === true) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
};

const refreshcustomWorkFlow = (widgetId, config) => {
  fetchWidgetData(widgetId, getcustomWorkFlowInput(config));
};

export default refreshcustomWorkFlow;
