import React, { Component } from 'react'
import { connect } from 'react-redux'
import { ReactTabulator, reactFormatter } from 'react-tabulator'
// import { globFilter } from "common/Funcs";
import ProgressBar from 'react-bootstrap/ProgressBar'
import Menu from '@mui/material/Menu'
import MenuItem from '@mui/material/MenuItem'
import useConfigStore from '../../../../store/useConfigStore'

import axios from 'axios'
import _ from 'lodash'

// import Config from "./Config";

// import actions
// import {
//   showToast,
//   toggleShowConfig,
// } from "../../../analytics_widget/AnalyticsWidgetSlice";
// import { setConfig, setData, refreshFlowManagerData } from "./FlowManagerSlice";
import { Stack } from '@mui/material'

// css imports
// import styles from "./FlowManager.module.css";

var theme = useConfigStore.getState().theme

function FlowProgressBar(props) {
  const rowData = props.cell._cell.row.data
  const status = rowData.status
  let variant = 'primary'

  if (status === 'success') {
    variant = 'success'
  } else if (status === 'failed') {
    variant = 'danger'
  }

  return (
    <React.Fragment>
      <ProgressBar
        now={rowData.progress}
        variant={variant}
        label={`${rowData.progress}%`}
      />
    </React.Fragment>
  )
}

class FlowManager extends Component {
  constructor(props) {
    super(props)

    this.state = {
      contextMenuOpen: false,
      mousePos: {
        x: 0,
        y: 0,
      },
      rightClickedRow: null,
    }

    this.columns = [
      {
        title: 'Project',
        field: 'project',
        // headerFilterFunc: globFilter,
      },
      {
        title: 'User',
        field: 'user',
        // headerFilterFunc: globFilter,
      },
      {
        title: 'Report Name',
        field: 'report_title',
        // headerFilterFunc: globFilter,
      },
      {
        title: 'Date',
        field: 'date',
        sorter: 'date',
        sorterParams: { format: 'DD-MM-YYYY' },
      },
      { title: 'Time', field: 'time', headerFilter: 'input' },
      {
        title: 'Progress',
        field: 'progress',
        hozAlign: 'left',
        formatter: reactFormatter(<FlowProgressBar />),
        sorter: 'number',
      },
      {
        title: 'Status',
        field: 'status',
        formatter: this.getFlowStatus,
        // headerFilterFunc: globFilter,
        width: 110,
      },
    ]
  }

  componentDidMount() {
    // create axios instance to query workflow manager
    this.workflowManager = axios.create({
      baseURL:
          useConfigStore.getState().configData.rest_server_url +  '/api/workflow_manager',
    })

    // refresh table
    this.refreshFlowManagerData(this.props.reportName, this.props.id)

    // manage autorefresh
    this.manageAutoRefresh()
  }

  componentDidUpdate(nextProps, nextState) {
    // manage autorefresh
    this.manageAutoRefresh()

    // table related updates
    if (!this.tableRef.current) {
      return
    }
    const table = this.tableRef.current
    if (!table) {
      return
    }

    // get selected rows
    const selectedRows = table.getSelectedRows()
    const selectedIds = []
    selectedRows.forEach((value, index, array) => {
      selectedIds.push(value._row.data.id)
    })

    // update table data
    // table.replaceData(_.get(this.props.data, 'flows', []))
    table.replaceData(this.state.data);

    // re-select all previously selected rows
    if (selectedIds.length > 0) {
      table.selectRow(selectedIds)
    }
  }

  componentWillUnmount = () => {
    if (this.websocket) {
      this.websocket.close()
      this.websocket = null
    }
  }

  getRowContextMenu = (e, position) => {
    const validStatesToKill = ['pending', 'queued', 'running']
    const validStatesToReRun = ['failed', 'killed']
    const validStatesToRetry = ['failed']
    const validStatesToDelete = ['new', 'success', 'failed', 'killed']
    let status = ''
    let reportName = ''
    let row_data = {}
    if (e._row) {
      status = e._row.data.status
      reportName = e._row.data.report_name
      row_data = e._row.data
    }

    let userAuth = false
    if (row_data.user === this.props.user.userid || this.props.user.adminFlag) {
      userAuth = true
    }
    let ret = [
      {
        label: "<i class='fas fa-user'></i> View Log",
        action: () => {
          this.handleViewLog(reportName)
        },
      },
    ]

    if (status === 'new' && userAuth) {
      ret.push({
        label: "<i class='fas fa-user'></i> Run",
        action: () => {
          this.handleRunFlow(row_data)
        },
      })
    }
    if (validStatesToReRun.includes(status) && userAuth) {
      ret.push({
        label: "<i class='fas fa-user'></i> Re-Run",
        action: () => {
          this.handleRunFlow(row_data)
        },
      })
    }
    if (
      validStatesToRetry.includes(status) &&
      userAuth &&
      row_data.progress > 0
    ) {
      ret.push({
        label: "<i class='fas fa-user'></i> Retry",
        action: () => {
          this.handleRetryFlow(row_data)
        },
      })
    }
    if (validStatesToKill.includes(status) && userAuth) {
      ret.push({
        label: "<i class='fas fa-user'></i> Kill",
        action: () => {
          this.handleKillFlow(row_data)
        },
      })
    }
    if (validStatesToDelete.includes(status) && userAuth) {
      ret.push({
        label: "<i class='fas fa-user'></i> Delete",
        action: () => {
          this.handleDeleteFlow(row_data)
        },
      })
    }
    return ret
  }

  getFlowStatus = (cell, formatterParams) => {
    const flowStatus = cell.getValue()

    let bgColor = 'black'
    if (flowStatus === 'running') {
      bgColor = '#03c03c'
    } else if (flowStatus === 'queued') {
      bgColor = '#e67e00'
    } else if (flowStatus === 'pending') {
      bgColor = '#003366'
    } else if (flowStatus === 'success') {
      bgColor = '#177245'
    } else if (flowStatus === 'failed') {
      bgColor = '#DC143C'
    } else if (flowStatus === 'killing') {
      bgColor = '#800000'
    } else if (flowStatus === 'deleting') {
      bgColor = '#800000'
    } else if (flowStatus === 'killed') {
      bgColor = '#454545'
    } else if (flowStatus === 'new') {
      bgColor = '#0d98ba'
    }

    const element = cell.getElement()
    element.style.color = 'white'
    element.style['font-weight'] = 'bold'
    element.style['text-align'] = 'center'
    element.style['background-color'] = bgColor

    return flowStatus
  }

  handleViewLog = (reportName) => {
    const link = useConfigStore.getState().configData.rest_server_url  +`/api/workflow_manager/log_viewer/flow/${reportName}`
    window.open(link, '_blank')
    // close context menu
    // this.handleMenuClose();
  }

  handleDeleteFlow = (row) => {
    // refresh data
    this.refreshFlowManagerData(this.props.reportName, this.props.id)

    const flow_info = {
      report_name: row.report_name,
      user: row.user,
    }

    this.workflowManager
      .post('/delete_flow', flow_info)
      .then((response) => {
        response = response.data
        const success = _.get(response, 'success', false)

        if (!success) {
          this.props.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: 'error',
            message: `Failed to delete flow - ${row.report_name}`,
          })
        } else {
          const table = this.tableRef.current
          table.updateData([{ id: row.id, status: 'deleting' }])
        }
      })
      .catch((error) => {
        this.props.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: 'error',
          message: 'Failed to connect to Server',
        })
        console.log(error)
      })

    // close context menu
    // this.handleMenuClose();
  }

  handleKillFlow = (row) => {
    // refresh data
    this.refreshFlowManagerData(this.props.reportName, this.props.id)

    const flow_info = {
      report_name: row.report_name,
      user: row.user,
    }

    this.workflowManager
      .post('/kill_flow', flow_info)
      .then((response) => {
        response = response.data
        const success = _.get(response, 'success', false)

        if (!success) {
          this.props.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: 'error',
            message: `Failed to kill flow - ${row.report_name}`,
          })
        } else {
          const table = this.tableRef.current
          table.updateData([{ id: row.id, status: 'killing' }])
        }
      })
      .catch((error) => {
        this.props.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: 'error',
          message: 'Failed to connect to Server',
        })
        console.log(error)
      })

    // close context menu
    // this.handleMenuClose();
  }

  // handleMenuClose = () => {
  //   this.setState({
  //     contextMenuOpen: false,
  //   });
  // };

  // handleRowContextEvent = (event, row) => {
  //   event.preventDefault();
  //   const mousePos = {
  //     x: event.pageX,
  //     y: event.pageY,
  //   };

  //   this.setState({
  //     mousePos: mousePos,
  //     contextMenuOpen: true,
  //     rightClickedRow: row,
  //   });
  // };

  handleRetryFlow = (row) => {
    // refresh data
    this.refreshFlowManagerData(this.props.reportName, this.props.id)

    const flow_info = {
      report_name: row.report_name,
      user: row.user,
    }

    this.workflowManager
      .post('/retry_failed_flow', flow_info)
      .then((response) => {
        response = response.data
        const success = _.get(response, 'success', false)

        if (!success) {
          const message = _.get(response, 'message', 'Unknown error')
          this.props.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: 'error',
            message: `Failed to retry flow - ${message}`,
          })
        } else {
          const table = this.tableRef.current
          table.updateData([{ id: row.id, status: 'pending' }])
        }
      })
      .catch((error) => {
        this.props.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: 'error',
          message: 'Failed to connect to Server',
        })
        console.log(error)
      })

    // close context menu
    // this.handleMenuClose();
  }

  handleRunFlow = (row) => {
    // refresh data
    this.refreshFlowManagerData(this.props.reportName, this.props.id)

    const flow_info = {
      report_name: row.report_name,
      user: row.user,
      new_flow: false,
      summary_data_gen_only: row.summary_data_gen_only,
      is_compare_report: row.is_compare_report,
      skip_eda_data_extraction: row.skip_eda_data_extraction,
      update_flow_analysis: row.update_flow_analysis,
    }

    this.workflowManager
      .post('/run_flow', flow_info)
      .then((response) => {
        response = response.data
        const success = _.get(response, 'success', false)

        if (!success) {
          const message = _.get(response, 'message', 'Unknown error')
          this.props.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: 'error',
            message: `Failed to run flow - ${message}`,
          })
        } else {
          const table = this.tableRef.current
          table.updateData([{ id: row.id, status: 'pending' }])
        }
      })
      .catch((error) => {
        this.props.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: 'error',
          message: 'Failed to connect to Server',
        })
        console.log(error)
      })

    // close context menu
    // this.handleMenuClose();
  }

  // Function to manage auto refresh
  manageAutoRefresh = () => {
    const autoRefresh = _.get(this.props.config, 'autoRefresh', false)
    if (!this.websocket && autoRefresh) {
      this.startAutoRefresh()
    } else if (this.websocket && !autoRefresh) {
      this.stopAutoRefresh()
    }
  }

  refreshFlowManagerData = (reportName, widgetId) => {
    // const state = getState();
    const endpoint =
        useConfigStore.getState().configData.rest_server_url + 
      '/api/workflow_manager/get_flows'
    axios
      .get(endpoint)
      .then((response) => {
        response = response.data
        const requestStatus = _.get(response, 'success', false)
        const flows = _.get(response, 'flows', {})
        const message = _.get(
          response,
          'message',
          'No valid response from server',
        )
        if (!requestStatus) {
     
          
        } else {
          // set data
          this.setState({ data: flows })
          // dispatch(
          // setData({
          //   widgetId: widgetId,
          //   data: { flows: flows },
          // })
          // );
        }
      })
      .catch((error) => {
        console.log(error)
        // show toast
        // dispatch(
        //   showToast({
        //     reportName: reportName,
        //     widgetId: widgetId,
        //     severity: "error",
        //     message: "Internal server error",
        //   })
        // );
      })
  }

  // Function to create websocket connection for auto-refresh
  startAutoRefresh = () => {
    // create websocket
    // replace http with ws or https with wss
    const websocketUrl = 'ws://10.194.161.176:24565/socket_service'
    this.websocket = new WebSocket(
      websocketUrl + '/api/workflow_manager/get_flows_ws',
    )

    this.websocket.onopen = () => {
      try {
        // this.websocket.send(`import os;os.environ["ANALYTICS_USER"]="${this.context.user.userid}";`);
        // get response
        this.websocket.onmessage = (event) => {
          const data = JSON.parse(event.data)
          if (data.success === true) {
            this.props.setData({
              widgetId: this.props.id,
              data: { flows: data.flows },
            })
          } else {
            this.props.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: 'error',
              message: data.message,
            })
          }
        }
      } catch (error) {
        this.props.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: 'error',
          message: 'Failed to connect to Server',
        })
        console.log(error) // catch error
      }
    }

    this.websocket.onclose = (event) => {
      // re-establish the connection on abnormal closure
      if (event.code == 1006) {
        console.warn(
          'Flow Analysis Manager websocket connection broken. Reconnecting ...',
        )
        this.startAutoRefresh()
      }
    }
  }

  // Function to destroy existing websocket connection for auto-refresh
  stopAutoRefresh = () => {
    this.websocket.close()
    this.websocket = null
  }

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      this.props.setConfig({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        config: config,
      })
    }

    this.props.toggleShowConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
    })

    // refresh table data
    this.refreshFlowManagerData(this.props.reportName, this.props.id)
  }

  applyTheme = (theme) => {
    if (theme == 'dark') {
      return 'table-sm table-dark table-striped table-bordered'
    } else {
      return 'table-sm table-striped table-bordered'
    }
  }

  render() {
    if (!this.tableRef) {
      this.tableRef = React.createRef()
    }

    // Render config editor if requested
    if (this.props.uiState.showConfig) {
      return (
        // <Config updateConfig={this.updateConfig} config={this.props.config} />
        null
      )
    }

    const options = {
      selectable: true,
      pagination: true, //enable pagination
      paginationMode: 'local',
      paginationSize: '10',
      persistenceID: _.get(this.props.config, 'tableId', this.props.id),
      persistenceMode: true,
      rowContextMenu: this.getRowContextMenu,
      persistence: {
        columns: true, //persist changes to the width, visible and frozen properties
      },
      columnDefaults: {
        headerFilter: true,
        headerFilterLiveFilter: false,
        headerFilterPlaceholder: '...',
        tooltip: true,
      },
    }

    return (
      <div id="analytics">
        <ReactTabulator
          key={this.props.theme}
          className={this.applyTheme(this.props.theme)}
          style={{ marginTop: '10px' }}
          layout="fitColumns"
          autoResize={false}
          onRef={(ref) => (this.tableRef = ref)}
          columns={this.columns}
          // data={[]}
          options={options}
        />
      </div>
    )
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    refreshFlowManagerData: (reportName, widgetId) =>
      dispatch(refreshFlowManagerData(reportName, widgetId)),
    setConfig: (payload) => dispatch(setConfig(payload)),
    setData: (payload) => dispatch(setData(payload)),
    showToast: (payload) => dispatch(showToast(payload)),
    toggleShowConfig: (payload) => dispatch(toggleShowConfig(payload)),
  }
}

// const mapStateToProps = (state, props) => {
//   return {
//     data: _.cloneDeep(_.get(state["Flow Analysis Manager"], props.id, {})),
//     theme: _.get(state.allReports[state.currentReportName], "theme", "light"),
//     analyticsBackendUrl: state.config.analyticsBackendUrl,
//     currentReportName: state.currentReportName,
//     config: state.allReports[state.currentReportName].widgets[props.id].config,
//     user: state.config.user,
//     uiState: _.get(
//       state.allReports[state.currentReportName].widgets[props.id],
//       "uiState",
//       {
//         isLoading: false,
//         showConfig: false,
//         isToastOpen: false,
//         toastSeverity: "info",
//         toastMessage: "",
//       }
//     ),
//   };
// };

FlowManager.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: 'info',
    toastMessage: '',
  },
}

export default FlowManager
