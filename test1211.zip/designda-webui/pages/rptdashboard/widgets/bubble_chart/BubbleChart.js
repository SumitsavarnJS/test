// react imports
import React from "react";
// import { connect } from "react-redux";
import { produce } from "immer";
import ReactEcharts from "echarts-for-react";
import Typography from "@mui/material/Typography";
import useConfigStore from "../../../../store/useConfigStore";
import useGlobalStore from "../../../../store/useGlobalStore";

// utility imprts
import _ from "lodash";

import Config from "./Config";
// import echarts from 'echarts/lib/echarts';

// import actions
// import { setConfig } from "./BubbleChartSlice";
// import { toggleShowConfig } from "../../analytics_widget/AnalyticsWidgetSlice";

// css imports
import styles from "./BubbleChart.module.css";

class BubbleChart extends React.Component {
  // consturctor
  constructor(props) {
    super(props);
    this.state = {};

    this.chart = React.createRef();
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      // to set previous session legend selected settings
      if (this.props.config.legend && this.chart && this.chart.current) {
        let unSelected = [];
        Object.keys(this.props.config.legend).forEach((key) => {
          if (this.props.config.legend[key] == false) {
            unSelected.push(key);
          }
        });

        for (let i = 0; i < unSelected.length; i++) {
          this.chart.current.getEchartsInstance().dispatchAction({
            type: "legendUnSelect",
            name: unSelected[i],
          });
        }
      }
    }
  }

  //to store legend information
  onLegendChanged = (params) => {
    const config = { ...this.props.config };
    config["legend"] = params.selected;
    this.props.setConfig({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      config: config,
    });
  };

  // Function to get option
  getEchartsOption(option) {
    const updatedOption = produce(option, (optionDraft) => {
      optionDraft.tooltip["formatter"] = function (param) {
        let tooltip_text = "";
        for (const index in param) {
          tooltip_text +=
            param[index].data[4] + ": " + param[index].data[2] + "<br/>";
        }
        return tooltip_text;
      };

      for (const index in optionDraft["series"]) {
        optionDraft["series"][index].symbolSize = function (data) {
          return data[2];
        };
        optionDraft["series"][index].emphasis = {
          label: {
            show: true,
            formatter: function (param) {
              return param.data[3];
            },
            position: "top",
          },
        };
      }
    });

    return updatedOption;
  }

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
    // this.props.toggleShowConfig({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    // });
  };
  // render method
  render() {
    // define event dict
    const eventDict = {
      legendselectchanged: this.onLegendChanged,
    };

    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (uiState.showConfig) {
      return (
        <Config updateConfig={this.updateConfig} config={this.props.config} />
      );
    } else {
      return Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <ReactEcharts
          ref={this.chart}
          onEvents={eventDict}
          style={{ height: "100%" }}
          // theme={this.props.theme}
          option={this.getEchartsOption(data)}
          notMerge={true}
        />
      );
    }
  }
}

// const mapDispatchToProps = (dispatch) => {
//   return {
//     setConfig: (payload) => dispatch(setConfig(payload)),
//     toggleShowConfig: (payload) => dispatch(toggleShowConfig(payload)),
//   };
// };

// const mapStateToProps = (state, props) => {
//   return {
//     currentReportName: state.currentReportName,
//     config: state.allReports[state.currentReportName].widgets[props.id].config,
//     data: _.get(state["Bubble Chart"], props.id, {}),
//     theme: _.get(state.allReports[state.currentReportName], "theme", "light"),
//     uiState: _.get(state.allReports[state.currentReportName].widgets[props.id], "uiState", {
//       isLoading: false,
//       showConfig: false,
//       isToastOpen: false,
//       toastSeverity: "info",
//       toastMessage: "",
//     }),
//   };
// };

BubbleChart.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};

export default BubbleChart;
