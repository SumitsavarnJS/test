import React from "react";
// import { connect } from "react-redux";
import { ReactTabulator } from "react-tabulator";
import Button from "@mui/material/Button";
import FormControlLabel from "@mui/material/FormControlLabel";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControl from "@mui/material/FormControl";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";
import { Typography } from "@mui/material";
import { styled } from "@mui/material/styles";
//utility imports
import axios from "axios";
import _ from "lodash";


// import css
import DataSourceStyles from "./DataSource.module.css";
import useConfigStore from "../../../store/useConfigStore";

const GrayRadio = styled(Radio)({
  color: "#5A2A82",
  "&.Mui-checked": {
    color: "#7E45AF",
  },
  padding: "10px",
});

class DataSource extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      source: this.props.onlyFlowReport ? "flow" : "task",
      tableData: { rows: [], columns: [] },
      loading: true
    };
  }

  componentDidMount() {
    // get data source dataframe
    const url = this.props.isScenario
      ? "/api/scenarios_table"
      : "/api/data_source_table";
    axios
      .post(useConfigStore.getState().configData.rest_server_url + url, {
        user: useConfigStore.getState().authLoginUser,
        source: this.state.source,
      })
      .then((response) => {
        const dataSource = _.get(response.data, "data", {});
        this.setState({
          tableData: dataSource, loading: false
        });
      })
      .catch((error) => {
        console.log(error);
        this.setState({
          loading: false
        });
      });
  }

  onSave = () => {
    const sourceName= this.props.sourceName || ""
    let selectedData = [];
    if (this.ref && this.ref.current) {
      selectedData = this.ref.current.getSelectedRows();
    }
    if (selectedData && selectedData.length == 1) {
      const rowData = selectedData[0].getData();
      this.props.dataLocationChanged(rowData["key"], rowData["project_name"], sourceName);
      this.props.close();
    } else {
      // this.props.showMainToast({
      //   open: true,
      //   severity: "error",
      //   message: "Invalid selection: Please select data source.",
      // });
    }
  };

  toggleSourceType = (event) => {
    this.setState({
      tableData: { rows: [], columns: [] },
      source: event.target.value,
    });
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/data_source_table",
        {
          user: useConfigStore.getState().authLoginUser,
          source: event.target.value,
        }
      )
      .then((response) => {
        const dataSource = _.get(response.data, "data", {});
        this.setState({
          tableData: dataSource,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  rowFormatter = (row) => {
    const dataLocation = row.getData()["key"];
    if (dataLocation == this.props.dataLocation) {
      row.getElement().classList.add("tabulator-selected");
    }
  };

  applyTheme = (theme) => {
    if (theme == "dark") {
      return "table-sm table-dark table-striped table-bordered";
    } else {
      return "table-sm table-striped table-bordered";
    }
  };

  render() {
    return (
      <div className={DataSourceStyles.container}>
        {!(this.props.isScenario || this.props.onlyFlowReport) ? (
          <FormControl component="fieldset" className={DataSourceStyles.formControl}>
            <RadioGroup
              row
              aria-label="source"
              name="source"
              style={{ padding: "10px" }}
              value={this.state.source}
              onChange={this.toggleSourceType}
            >
              <FormControlLabel
                value="task"
                control={<GrayRadio />}
                // label="Task Reports"
                label={
                  <Typography className={DataSourceStyles.formControlLabel}>
                    Task Reports
                  </Typography>
                }
              />
              <FormControlLabel
                value="flow"
                control={<GrayRadio />}
                // label="Flow Reports"
                label={
                  <Typography className={DataSourceStyles.formControlLabel}>
                    Flow Reports
                  </Typography>
                }
              />
              <FormControlLabel
                value="custom"
                control={<GrayRadio />}
                label={
                  <Typography className={DataSourceStyles.formControlLabel}>
                    Custom Reports
                  </Typography>
                }
              />
              <FormControlLabel
                value="user"
                control={<GrayRadio />}
                // label="User Reports"
                label={
                  <Typography className={DataSourceStyles.formControlLabel}>
                    User Reports
                  </Typography>
                }
              />
              {/* Tech Lib Selection added */}
              <FormControlLabel
                value="techlib"
                control={<GrayRadio />}
                // label="User Reports"
                label={
                  <Typography className={DataSourceStyles.formControlLabel}>
                    Techlib Reports
                  </Typography>
                }
              />
            </RadioGroup>
          </FormControl>
        ) : null}

        {this.state.loading ? (<Box display="flex" justifyContent="center">
          <CircularProgress />
        </Box>)
          : <>
            <div id="analytics">
              {this.state.tableData["rows"].length > 0 ? (
                <ReactTabulator
                  key={useConfigStore.getState().theme} // Do not remove this, otherwise it breaks theme functionalities
                  className={this.applyTheme(useConfigStore.getState().theme)}
                  onRef={(ref) => (this.ref = ref)}
                  layout="fitColumns"
                  columns={this.state.tableData["columns"]}
                  data={this.state.tableData["rows"]}
                  rowFormatter={this.rowFormatter}
                  autoResize={false}
                  options={{
                    pagination: true, //enable pagination
                    paginationMode: "local",
                    paginationSize: 10,
                    selectable: 1,
                    // groupBy: "project_name",
                    ajaxURL:
                      useConfigStore.getState().configData.rest_server_url +
                      "/api/data_source_filter",
                    ajaxContentType: "json",
                    ajaxConfig: "POST",
                    filterMode: "remote",
                    ajaxParams: {
                      source: this.state.source,
                      user: useConfigStore.getState().authLoginUser,
                      uniqueTaskReports: this.props.isScenario ? true : false,
                    },
                    ajaxResponse: (url, params, responseData) => {
                      if (responseData.status) {
                        return responseData.data.rows;
                      }
                      return [];
                    },
                    columnDefaults: {
                      tooltip: true,
                      headerFilterPlaceholder: "...",
                    },
                  }}
                  events={{
                    ajaxError: (error) => {
                      console.log(error);
                    },
                  }}
                />
              ) : (
                <Box display="flex" justifyContent="center">
                  {/* <CircularProgress /> */}
                  <p>Data Not Present</p>
                </Box>
              )}
            </div>
          </>
        }

        <div className={DataSourceStyles.button} >
          <Button
            variant="contained"
            size="small"
            disabled={false}
            onClick={this.onSave}
            classes={{ root: DataSourceStyles.add_button }}
          >
            Select
          </Button>
          <Button
            variant="contained"
            size="small"
            onClick={() => {
              this.props.close();
            }}
            classes={{ root: DataSourceStyles.cancel_button }}
          >
            Cancel
          </Button>
        </div>
      </div>
    );
  }
}

export default DataSource;
