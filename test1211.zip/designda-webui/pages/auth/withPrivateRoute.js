import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { useMsal } from "@azure/msal-react";
import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";
import api from "../../common/api/api";
import axios from "axios";
import { toast } from "react-toastify";
import { dashboardCheck } from '../Login/Loginform'


const withPrivateRoute = (WrappedComponent) => {
    return function WithPrivateRoute(props) {
        const router = useRouter();
        const { accounts, instance } = useMsal();
        const isAuthenticated = useConfigStore((state) => state.isAuthenticated);
        const reportHeading = useGlobalStore.getState().reportUrlChange;
        const isDynamicRoute = router.asPath;
        const [queryChange, setQueryChange] = useState(true);
        const [dataInputValue, setdataInputValue] = useState("");
        const [licenseProcured, setLicenseProcured] = useState(false);

        const procureLicense = async () => {
            try {
                if (instance && instance.getAllAccounts()[0] && instance.getAllAccounts()[0].hasOwnProperty('idTokenClaims')) {
                    let userName = instance.getAllAccounts()[0]?.idTokenClaims?.IDSID
                    // setSsoAuthUserName(userName)
                    useConfigStore.getState().setAuthUserVal(userName)
                }
                const configResponse = await fetch("/v1/config.json");
                const data = await configResponse.json();
                useConfigStore.getState().setConfigData(data);

                const response = await axios.post(
                    `${data.rest_server_url}/license/licenseRequest/`,
                    {
                        userName: instance.getAllAccounts()[0]?.idTokenClaims?.IDSID,
                        featureList: "DDash-Base",
                        comment: "Login license",
                    }
                );
                if (response.data.success === 200) {
                    try {
                        useConfigStore.getState().setAuthUserVal(instance.getAllAccounts()[0]?.idTokenClaims?.IDSID);
                        useConfigStore.getState().setUserLicenseId(response.data.licenseId);
                        useConfigStore.getState().setAdminFlag(true)
                        setLicenseProcured(true)
                        // router.push("/"); // or redirect to any other page
                        dashboardCheck();
                        toast.info(response.data.message, {
                            position: toast.POSITION.BOTTOM_LEFT,

                            style: {
                                fontSize: "14px",
                                padding: "8px  12px",
                            },
                        });
                    } catch (e) {
                        console.log(e)
                    }

                }
            } catch (error) {
                console.error("Error procuring license:", error);
            }
        };

        const getProfile = async () => {
            const url = useConfigStore.getState().configData.rest_server_url + "/api/get_profile_config";
            let userName = ''
            if (instance && instance.getAllAccounts()[0] && instance.getAllAccounts()[0].hasOwnProperty('idTokenClaims')) {
                userName = instance.getAllAccounts()[0]?.idTokenClaims?.IDSID
            }

            const input = { user: userName || useConfigStore.getState().authLoginUser };
            const response = await api(url, input);

            if (response && response?.profile_config && Object.keys(response?.profile_config).length > 1) {
                let defaultMetricProject = response?.profile_config.project;
                useConfigStore.getState().setMetricProjectName(defaultMetricProject);
            } else {
                let userName = ''
                if (instance && instance.getAllAccounts()[0] && instance.getAllAccounts()[0].hasOwnProperty('idTokenClaims')) {
                    userName = instance.getAllAccounts()[0]?.idTokenClaims?.IDSID
                }
                const userProjectResponse = await axios.post(useConfigStore.getState().configData.rest_server_url + "/api/fetch_buckets", { user: userName || useConfigStore.getState().authLoginUser });
                const userProjectData = userProjectResponse?.data;
                let updateProjectVal = userProjectData.data[0];
                useConfigStore.getState().setMetricProjectName(updateProjectVal);
            }
        };

        const projectQueryValidation = (projects) => {
            if (projects.length === 1) {
                return `project = '${projects[0]}'`;
            } else {
                return projects.map(item => `project = '${item}'`).join(' OR ');
            }
        };
        const handleRptClick = () => {
            useConfigStore.getState().setRootLevelData("activeRouteMenu", 'Analytics');
            setQueryChange(!queryChange);

            let queryParams;
            if (dataInputValue) {
                queryParams = dataInputValue;
                router.push({
                    pathname: "/rptdashboard",
                    query: { queryParams: queryParams, keyProp: queryChange },
                }, "/rptdashboard");
            } else {
                useConfigStore.getState().setRootLevelData("dataSearchActive", false);
                let localQueryString = localStorage.getItem('savedQuery');
                if (localQueryString) {
                    queryParams = localQueryString;
                } else {
                    let projectsQuery = projectQueryValidation(useConfigStore.getState().metricProjectName);
                    if (projectsQuery) {
                        let userName = ''
                        if (instance && instance.getAllAccounts()[0] && instance.getAllAccounts()[0].hasOwnProperty('idTokenClaims')) {
                            userName = instance.getAllAccounts()[0]?.idTokenClaims?.IDSID
                        }
                        let formedQuery = `username = '${userName || useConfigStore.getState().authLoginUser}' AND (${projectsQuery})`;
                        localStorage.setItem('savedQuery', formedQuery);
                        queryParams = formedQuery;
                    }
                }
                router.push({
                    pathname: "/rptdashboard",
                    query: { queryParams: queryParams },
                }, "/rptdashboard");
            }
        };

        useEffect(() => {
            const isMsalAuthenticated = accounts.length > 0;
            //when both sso and ddash users are not logged in
            if (!isAuthenticated && !isMsalAuthenticated) {
                //if user is not logged in and report copy link exists in url.
                // store the report path to local zustand and redirect to Login
                if (isDynamicRoute.includes("reporturl")) {
                    useGlobalStore.getState().setReportUrlChange(`${isDynamicRoute}`);
                }
                router.push("/Login");
            }
            //either of the Login User Exists
            else if (isAuthenticated || isMsalAuthenticated) {
                // if SSO User has logged in
                if (!isAuthenticated && isMsalAuthenticated) {// Restore authentication state
                    useConfigStore.getState().setAuth(true)
                    if (!licenseProcured) {
                        try { // Only procure license if it hasn't been procured yet
                            procureLicense();
                        } catch (e) {
                            console.log(e)
                        }
                    }
                }
                // for copy link redirection to reporturl component
                if (reportHeading.includes("reporturl")) {
                    if (reportHeading.includes("dashboards")) {
                        useConfigStore.getState().setRootLevelData("activeRouteMenu", 'Dashboard');
                    } else {
                        useConfigStore.getState().setRootLevelData("activeRouteMenu", 'Analytics');
                    }
                    // redirection to Report Load component
                    router.push(
                        {
                            pathname: "/reporturl",
                            query: { reportHeading },
                        },
                        "/reporturl"
                    );
                }
                //application specific api fetch when user has logged in
                else {
                    if (isAuthenticated) {
                        (async () => {
                            if(!Object.hasOwn(useConfigStore.getState().configData, 'rest_server_url')){
                                const configResponse = await fetch("/v1/config.json");
                                      const data = await configResponse.json();
                                      useConfigStore.getState().setConfigData(data);
                              }
                            await getProfile();
                            handleRptClick();
                        })();
                    }
                }
            }
        }, [isAuthenticated, accounts]);

        return (

            <><WrappedComponent {...props} />
            </>);

    };
};

export default withPrivateRoute;
