import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";

import useGlobalStore from "../../store/useGlobalStore";
import refreshWidgetContent from "../rptdashboard/wigetWrapper/widgetRefreshData";
import axios from "axios";
import { toast } from "react-toastify";
import useConfigStore from "../../store/useConfigStore";

function Index() {
  const router = useRouter();
  const [reportName, setReportName] = useState("");

  useEffect(() => {
    setReportName(router.query.reportHeading);

    // }
  }, [router.query]);

  useEffect(() => {
    const handleNodeSelect = async () => {
      if (reportName) {
        if (reportName.includes("/dashboards")) {
          let reportKey = `${reportName.split("=")[1]}.json`;

          router.push(
            {
              pathname: "/Dashboards",
              query: { reportKey },
            },
            "/Dashboards"
          );
        }
        else if
          (reportName.includes("published_dashboards/")) {
          let reportKey = `${reportName.split("=")[1]}.json`;


          router.push(
            {
              pathname: "/Dashboards",
              query: { reportKey },
            },
            "/Dashboards"
          );
        }
        else {
          let reportKey = `${reportName.split("=")[1]}.json`;
          console.log("reportName", reportKey);
          const selectedLink = reportKey;
          await axios
            .post(
              useConfigStore.getState().configData.rest_server_url +
              "/api/read_json_from_path",
              {
                path: selectedLink,
              }
            )
            .then((response) => {
              if (response.data) {
                let rpt = response.data.data.title;
                let rptData = response.data.data;
                // setRptObjectValue(rptData);
                const tempregex = /(template|templates)/i;
                if (tempregex.test(rpt) && rptData.widgetsOrder) {
                  const widgetsOrder = rptData.widgetsOrder;
                  console.log("widgetsOrder", widgetsOrder);
                  let rptDataClone = _.cloneDeep(rptData);
                  delete rptDataClone.widgets;
                  rptDataClone["widgets"] = {};

                  //add widgets according to the new order given
                  for (let index = 0; index < widgetsOrder.length; index++) {
                    rptDataClone["widgets"][widgetsOrder[index]] =
                      rptData["widgets"][widgetsOrder[index]];
                  }

                  // set the new ordered data report
                  rptData = rptDataClone;
                }
                useGlobalStore
                  .getState()
                  .updateGlobalObject(rptData.fileName, rptData);
                if (rptData.hasOwnProperty("widgets")) {
                  for (const Wkey in rptData.widgets) {
                    let WkeyObj = {
                      data: {},
                      uiState: {
                        isLoading: false,
                        showConfig: false,
                        isToastOpen: false,
                        toastSeverity: "info",
                        toastMessage: "",
                        cirlularLoading: false,
                      },
                    };
                    useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
                  }
                }

                const widgetArray = Object.keys(rptData.widgets);
                if (!tempregex.test(rpt)) {
                  for (let i = 0; i < widgetArray.length; i++) {
                    const widgetId = widgetArray[i];
                    const config = rptData.widgets[widgetId].config;
                    const name = rptData.widgets[widgetId].name;
                    const rptType = rptData.widgets[widgetId]?.rptType
                      ? rptData.widgets[widgetId]?.rptType
                      : "";
                    const reportKey = rptData.widgets[widgetId]?.reportKey
                      ? rptData.widgets[widgetId]?.reportKey
                      : "";
                    const rptDataVariablesCheck = rptData.hasOwnProperty('variables') && rptData?.variables ? rptData.variables : {}
                    const widgetVariables = Object.keys(rptDataVariablesCheck).length > 0 ? rptDataVariablesCheck : {}
                    refreshWidgetContent({
                      widgetId: widgetId,
                      config: config,
                      widgetName: name,
                      reportKey: reportKey,
                      rptType: rptType,
                      variables: widgetVariables ? widgetVariables : {}

                    });
                  }
                }
                router.push("rptdashboard");
              } else {
                toast.error(response.data.message, {
                  position: toast.POSITION.BOTTOM_LEFT,
                  style: { backgroundColor: "red", color: "white" },
                });
              }
            });
        }
      }
    };

    handleNodeSelect();
  }, [reportName]);

  return (
    <div style={{ marginLeft: "200px" }}>
      <p>Report Path :: {reportName}</p>
    </div>
  );
}

export default Index;
