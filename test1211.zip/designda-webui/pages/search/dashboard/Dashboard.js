import React, { useState, useRef, useEffect } from "react";

import GridLayout, { WidthProvider } from "react-grid-layout";
import "/node_modules/react-grid-layout/css/styles.css";
import "/node_modules/react-resizable/css/styles.css";
import _ from "lodash";

import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import IconButton from "@mui/material/IconButton";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import Typography from "@mui/material/Typography";
import getConfig from "next/config";
import Box from "@mui/material/Box";
import { styled } from "@mui/material/styles";
import axios from "axios";
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";

import styles from "./Dashboard.module.css";


import AddWidgets from "../../rptdashboard/addWidget/addWidget";
import * as constants from "../../../constants/constants";
import refreshWidgetContent from "../../rptdashboard/wigetWrapper/widgetRefreshData";

import WidgetWrapper from "./DashboardWidgets";
import { Collapse, inputAdornmentClasses, Stack, Input } from "@mui/material";
import {
  ArrowDropUp,
  BarChartOutlined,
  DonutLarge,
  TableChart,
  TrendingUp,
} from "@mui/icons-material";
import Image from "next/image";

const ReactGridLayout = WidthProvider(GridLayout);
const { publicRuntimeConfig } = getConfig();

const imageUrl = publicRuntimeConfig.basePath;

const Dashboard = (props) => {
  const { allDashbrdRpts } = useGlobalStore();
  const updateLayout = useGlobalStore((state) => state.updateWidgetLayout);

  const IconButtonRef = useRef();

  const [expandDashbrd, setExpandDashbrd] = useState(true);
  const [menuOpen, setMenu] = useState(false);
  const [openAddWidget, setOpenAddWidget] = useState(false);
  const [dashboardName, setDashboardName] = useState(
    useGlobalStore
      .getState()
      .allDashbrdRpts?.dashboardReport?.fileName.toString()
  );

  const [typographyItem, setTypographyItem] = useState(true);
  const [enableDashboardRename, setEnableDashboardRename] = useState(false);

  const { configData, authLoginUser, theme } = useConfigStore();

  useEffect(() => {
    let specData = {}
    async function loadConfig() {
      const response = await fetch("/v1/defaultReportSpec.json");
      specData = await response.json();
      // console.log(specData);
    }
    const loadRptData = async () => {
      await loadConfig();
      let userauth = authLoginUser;
      // await axios
      //   .post(configData.rest_server_url + "/api/get_dashboards_info", {
      //     user: userauth,
      //   })
      //   .then((reportResponse) => {
      //     const response = reportResponse.data.gui;
      //     // setRptObject(response);
      //     console.log(response);
      //   });

      await axios
        .post(configData.rest_server_url + "/api/get_user_config", {
          user: userauth,
          metricSpec: specData,
        })
        .then((reportResponse) => {
          const response =
            reportResponse.data.user_config[
              Object.keys(reportResponse.data.user_config)
            ];

          if (Object.keys(reportResponse.data.user_config).length != 0) {
            let rptData = {
              dashboardReport: response,
            };
            //setDashboardName(Object.keys(reportResponse.data.user_config));
            setDashboardName(rptData.dashboardReport.fileName);

            // console.log("rptData" + JSON.stringify(rptData));

            // useGlobalStore.getState().updateDashboardObject(rptData);
            // if (rptData.dashboardReport.hasOwnProperty("widgets")) {
            //   for (const Wkey in rptData.dashboardReport.widgets) {
            //     let WkeyObj = {
            //       data: {},
            //       uiState: {
            //         isLoading: false,
            //         showConfig: false,
            //         isToastOpen: false,
            //         toastSeverity: "info",
            //         toastMessage: "",
            //         cirlularLoading: false,
            //       },
            //     };
            //     useGlobalStore.getState().setRootLevelData(WkeyObj);
            //   }
            // }

            useGlobalStore.getState().updateDashboardObject(rptData);
            if (rptData.dashboardReport.hasOwnProperty("widgets")) {
              for (const Wkey in rptData.dashboardReport.widgets) {
                let WkeyObj = {
                  data: {},
                  uiState: {
                    isLoading: false,
                    showConfig: false,
                    isToastOpen: false,
                    toastSeverity: "info",
                    toastMessage: "",
                    cirlularLoading: false,
                  },
                };
                useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
              }
            }

            const widgetArray = Object.keys(rptData.dashboardReport.widgets);

            for (let i = 0; i < widgetArray.length; i++) {
              const widgetId = widgetArray[i];
              const config = rptData?.dashboardReport?.widgets[widgetId].config;
              const name = rptData?.dashboardReport?.widgets[widgetId].name;
              // const rptType = rptData?.dashboardReport?.widgets[widgetId]?.rptType ? rptData?.dashboardReport.widgets[widgetId]?.rptType : "allDashbrdRpts";
              // const reportKey = rptData?.dashboardReport?.widgets[widgetId]?.reportKey ? rptData?.dashboardReport.widgets[widgetId]?.reportKey : "dashboardReport";

              const rptType = rptData?.dashboardReport?.widgets[widgetId]
                ?.rptType
                ? rptData?.dashboardReport.widgets[widgetId]?.rptType
                : constants.allDashbrdRpts;
              const reportKey = rptData?.dashboardReport?.widgets[widgetId]
                ?.reportKey
                ? rptData?.dashboardReport.widgets[widgetId]?.reportKey
                : constants.dashboardReport;
              refreshWidgetContent({
                widgetId: widgetId,
                config: config,
                widgetName: name,
                reportKey: reportKey,
                rptType: rptType,
              });
            }
          } else {
            let rptData = {
              dashboardReport: {
                fileName: "Dashboard-Untitled",
                theme: "light",
                title: "Dashboard-Untitled",
                widgets: {
                  // "VJRjqL-LR8FjX1Z0vB5fy": {
                  //   h: 12,
                  //   w: 20,
                  //   y: -1,
                  //   x: 0,
                  //   name: "Log Monitor",
                  //   config: {
                  //     streams: [],
                  //     kpis: [],
                  //   },
                  //   description: "",
                  //   category: "",
                  //   tags: "",
                  //   key: "VJRjqL-LR8FjX1Z0vB5fy",
                  // },
                  "nL4b-e6d5X7q1EXqWXJx1": {
                    h: 12,
                    w: 20,
                    y: -1,
                    x: 0,
                    name: "Group Bar Chart",
                    config: {},
                    description: "",
                    category: "",
                    tags: "",
                    key: "nL4b-e6d5X7q1EXqWXJx1",
                  },
                },
              },
            };
            setDashboardName(rptData.dashboardReport.fileName);

            useGlobalStore.getState().updateDashboardObject(rptData);
            if (rptData.dashboardReport.hasOwnProperty("widgets")) {
              for (const Wkey in rptData.dashboardReport.widgets) {
                let WkeyObj = {
                  data: {},
                  uiState: {
                    isLoading: false,
                    showConfig: false,
                    isToastOpen: false,
                    toastSeverity: "info",
                    toastMessage: "",
                    cirlularLoading: false,
                  },
                };
                useGlobalStore.getState().setRootLevelData(WkeyObj);
              }
            }
          }
        });
    };

    loadRptData();
  }, []);

  useEffect(() => {
    setTypographyItem(true);
    setDashboardName(allDashbrdRpts?.dashboardReport?.fileName.toString());
  }, [allDashbrdRpts?.dashboardReport?.fileName]);

  // const onLayoutChange = (newLayout) => {
  //   console.log(newLayout);
  // };
  const onLayoutChange = (newLayout) => {
    if (Object.keys(allDashbrdRpts.dashboardReport.widgets).length != 0) {
      updateLayout(newLayout);
    }

    console.log(newLayout);
  };

  const ExpandMore = styled((props) => {
    const { expand, ...other } = props;
    return <IconButton {...other} />;
  })(({ theme, expand }) => ({
    transform: !expand ? "rotate(180deg)" : "rotate(0deg)",
    margin: "auto",
    padding: "0px",
    transition: theme.transitions.create("transform", {
      duration: "5s",
    }),
  }));

  function EditableTypography(props) {
    return (
      <Typography
        sx={{
          marginLeft: "15px",
          color: "black",
        }}
        variant="h4"
        // component="div"
        contentEditable
        suppressContentEditableWarning
        {...props}
        // onChange={(e) => setDashboardName(e.target.value)}
        // value={dashboardName}
      />
    );
  }

  const getWidget = (widget) => {
    return (
      <div
        // className={styles.widgetContainer}
        // style={{
        //   backgroundColor: theme == "light" ? "white" : "rgb(25,25,25)",
        // }}
        data-grid={{
          i: widget.key,
          x: widget.x,
          y: widget.y,
          w: widget.w,
          h: widget.h,
          minW: 2,
          minH: 3,
        }}
        key={widget.key}
      >
        <WidgetWrapper widgetProps={widget} id={widget.key} />
      </div>
    );
  };

  const handleCloseMenu = () => {
    setMenu(false);
  };

  const handleMenuOpen = () => {
    setMenu(true);
  };

  const MenuOptions = ["Add widget", "Save"];

  const handleMenuOption = (option) => {
    handleCloseMenu();
    switch (option) {
      case "Add widget":
        handleAddWidgetOpen();
        break;

      case "Save":
        saveReportInfo();
        break;

      default:
        console.log(
          `Action not implemented for ${option} or break statement is missing`
        );
    }
  };

  const saveConfig = () => {
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/save_user_config",
        {
          data: {
            fileName: dashboardName,
            theme: "light",
            title: dashboardName,
            widgets:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
          },
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          console.log(response.success);
        } else {
          // Show Failure toast message
          // this.setToastMessage({
          //   message: "Failed to save analytics report",
          //   success: false,
          // });
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        // show network error message
        // Show Failure toast message
        // this.setToastMessage({
        //   message: "Failed to reach Server",
        //   success: false,
        console.log("Failed to reach Server");
        // });
      });
    // }
    // this.handleSettingsMenuClose();
  };

  const saveReportInfo = async () => {
    // const reportInfo = allReports[props.report];

    // console.log(props.report);

    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/store_dashbaord_info",
        {
          data: {
            fileName: dashboardName,
            theme: "light",
            title: dashboardName,
            widgets:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
          },
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        // saveConfig();
        if (response.success) {
          console.log(response.success);
        } else {
          // Show Failure toast message
          // this.setToastMessage({
          //   message: "Failed to save analytics report",
          //   success: false,
          // });
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        // show network error message
        // Show Failure toast message
        // this.setToastMessage({
        //   message: "Failed to reach Server",
        //   success: false,
        console.log("Failed to reach Server");
        // });
      });
    // }
    // this.handleSettingsMenuClose();

    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/save_user_config",
        {
          data: {
            fileName: dashboardName,
            theme: "light",
            title: dashboardName,
            widgets:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
          },
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          console.log(response.success);
        } else {
          // Show Failure toast message
          // this.setToastMessage({
          //   message: "Failed to save analytics report",
          //   success: false,
          // });
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        // show network error message
        // Show Failure toast message
        // this.setToastMessage({
        //   message: "Failed to reach Server",
        //   success: false,
        console.log("Failed to reach Server");
        // });
      });
  };

  const handleAddWidgetOpen = () => {
    setOpenAddWidget(true);
  };

  const closeAddWidget = () => {
    setOpenAddWidget(false);
  };

  // const renameReportInfo = (e) => {
  //   // setEnableDashboardRename(true);
  //   // setDashboardName(e.target.value);
  // };

  return (
    <div
      id="wtegxsheg4tge"
      className={styles.dashboardParent}
      // style={{
      //   backgroundColor:
      //     theme == "light" ? "rgb(218 199 255)" : "rgb(18,18,18)",
      // }}
    >
      <div id="gridHeader" className={styles.gridHeader}>
        <Box
          sx={{ display: "flex" }}
          // onClick={() => setExpandDashbrd(!expandDashbrd)}
        >
          <Box>
            <Stack direction={"row"}>
              <Stack direction={"column"}>
                <TrendingUp fontSize={"12px"} />
                <DonutLarge fontSize={"12px"} />
              </Stack>
              <Stack direction={"column"}>
                <BarChartOutlined fontSize={"12px"} />
                <TableChart fontSize={"12px"} />
              </Stack>
            </Stack>
            {/* <Image src={`${imageUrl}/dashboard.png`} height={60} width={70}/> */}
          </Box>
          {/* <Typography
            sx={{
              marginLeft: "15px",
              color: "black",
            }}
            variant="h4"
            contentEditable
            suppressContentEditableWarning
            onChange={(e) => {
              console.log("onChange" + e.target.value);
              console.log(e.target.textContent);

              setDashboardName(e.target.innerText);
            }}
          />
          {dashboardName} */}

          {typographyItem ? (
            <Typography
              sx={{
                marginLeft: "15px",
                color: "black",
                fontSize: "20px",
              }}
              onClick={() => {
                setTypographyItem(false);
              }}
            >
              {
                useGlobalStore.getState().allDashbrdRpts.dashboardReport
                  .fileName
              }
            </Typography>
          ) : (
            <Input
              sx={{
                marginLeft: "15px",
                color: "black",
                fontSize: "20px",
              }}
              // variant="h4"
              value={dashboardName}
              onChange={(event) => setDashboardName(event.target.value)}
            />
          )}
          <></>
          {/* <Typography>{dashboardName} </Typography> */}

          {/* <input
            onChange={(e) => {
              console.log("onChange" + e.target.value);
              console.log(e.target.textContent);

              setDashboardName(e.target.value);
            }}
          />
          {dashboardName} */}
        </Box>

        <IconButton
          sx={{ position: "absolute", top: "0px", right: "0px" }}
          color="inherit"
          onClick={handleMenuOpen}
          ref={IconButtonRef}
        >
          <MoreHorizIcon sx={{ fontSize: "2rem" }} />
        </IconButton>

        <Menu
          open={menuOpen}
          anchorEl={IconButtonRef.current}
          onClose={handleCloseMenu}
          transformOrigin={{
            vertical: "top",
            horizontal: "center",
          }}
          PaperProps={{
            style: {
              width: "auto",
              borderRadius: "10px",
            },
          }}
        >
          {MenuOptions.map((option) => (
            <MenuItem onClick={() => handleMenuOption(option)}>
              {option}
            </MenuItem>
          ))}
        </Menu>

        <AddWidgets
          open={openAddWidget}
          reportType={constants.dashboardReport}
          handleClose={closeAddWidget}
        />
      </div>
      <Collapse
        sx={{
          backgroundColor: theme == "light" ? "white" : "rgb(30,30,30)",
        }}
        in={expandDashbrd}
        timeout="auto"
        collapsedSize={300}
      >
        {Object.keys(allDashbrdRpts[constants.dashboardReport].widgets)
          .length == 0 ? (
          <Box
            sx={{
              justifyContent: "center",
              backgroundColor: theme == "light" ? "white" : "rgb(30,30,30)",
              display: "flex",
              position: "relative",
              height: "70vh",
            }}
          >
            <Box sx={{ position: "relative", top: "auto", left: "auto" }}>
              {/* <Typography variant={"h5"} sx={{ color: "darkgrey" }}>
                Add widget from here 👉
              </Typography> */}
            </Box>
            {/* <Box sx={{ position: "absolute", right: "5px", top: "0px" }}>
              <img
                width="30%"
                // height="180"
                src={"images/upRightArrow.svg"}
                srcSet={"images/upRightArrow.svg"}
                alt=""
              />
            </Box> */}
          </Box>
        ) : (
          <ReactGridLayout
            className={styles.grid}
            style={{
              backgroundColor: theme == "light" ? "white" : "rgb(30,30,30)",
            }}
            rowHeight={30}
            cols={24}
            draggableHandle={".draggable"}
            draggableCancel={".non-draggable"}
            onLayoutChange={onLayoutChange}
            resizeHandle={
              <div className={styles.main}>
                <div
                  className={styles.quarter + " " + styles.quarter4}
                  style={{
                    backgroundColor: theme == "light" ? "grey" : "white",
                  }}
                ></div>
                <div
                  className={styles.cutout}
                  style={{
                    backgroundColor:
                      theme == "light" ? "white" : "rgb(18,18,18)",
                  }}
                ></div>
              </div>
            }
          >
            {_.map(
              allDashbrdRpts[constants.dashboardReport].widgets,
              (widget) => getWidget(widget)
            )}
          </ReactGridLayout>
        )}
      </Collapse>
      <Box
        sx={{ justifyContent: "center", padding: "auto" }}
        // onClick={() => setExpandDashbrd(!expandDashbrd)}
      >
        <Typography
          sx={{
            // margin: "auto",
            width: "fit-content",
            color: "white",
            fontSize: "20px",
          }}
        >
          DD
          {/* {expandDashbrd ? "Collapse" : "Expand"} Dashboard{" "}
          <ExpandMore expand={expandDashbrd}>
            <ArrowDropUp />
          </ExpandMore> */}
        </Typography>{" "}
      </Box>
    </div>
  );
};

export default Dashboard;
