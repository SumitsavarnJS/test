import React, { useState } from "react";
import { styled } from "@mui/material/styles";
import { Collapse, Typography, TextField } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";

import DocumentView from "../../rptdashboard/widgets/document/DocumentView";

import { shallow } from "zustand/shallow";
import useGlobalStore from "../../../store/useGlobalStore";

import _ from "lodash";
import * as widgetFooterStyles from "./DashboardWidgetFooter.module.css";

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
  marginLeft: "auto",
  position: "absolute",
  bottom: "0px",
  right: "12px",
  padding: "0px",
  transition: theme.transitions.create("transform", {
    duration: theme.transitions.duration.shortest,
  }),
}));

function WidgetFooter(props) {
  const [expandDescription, setExpandDescription] = useState(true);
  const [editDescription, setEditDescription] = useState(false);
  // const description =
  //   _.get(
  //     props.widgetProps.metaData,
  //     "description",
  //     "Classify Timing paths into different classes as per path violation causes and path category. For each of such class calculate aggregated TNS, WNS and NVP.Use this widget to get overview timing violation causation of the design."
  // );
  // const tags = _.get(props.widgetProps.metaData, "tags", "");

  const [tags, setTags] = useState(
    _.get(props.widgetProps.metaData, "tags", "")
  );
  const [description, setDescription] = useState(
    _.get(
      props.widgetProps.metaData,
      "description",
      ""
    )
  );

  const { updateWidgetSettings } = useGlobalStore(
    (state) => ({
      updateWidgetSettings: state.updateWidgetSettings,
    }),
    shallow
  );

  const handleExpandClick = () => {
    setExpandDescription(!expandDescription);
  };

  const updateDescriptionAndTagsInStore = (descriptionValue, tagsValue) => {
    const newWidgetSettings = _.cloneDeep(props.widgetProps);
    const metaData = {};
    metaData.description = descriptionValue;
    metaData.tags = tagsValue;
    newWidgetSettings.metaData = metaData;

    updateWidgetSettings(
      props.rptType,
      props.report,
      props.id,
      newWidgetSettings
    );
  };
  const onEditButtonClick = () => {
    setEditDescription(!editDescription);
  };

  const onChangeDescription = (descText) => {
    setDescription(descText);
  };

  const onChangeTags = (newTags) => {
    setTags(newTags);
  };

  const onSaveButtonClick = () => {
    updateDescriptionAndTagsInStore(description, tags);
    setEditDescription(false);
  };

  return (
    <div id="widgetFooter" className={widgetFooterStyles.widgetFooter}>
      <Collapse
        in={expandDescription}
        timeout="auto"
        unmountOnExit
      >
        <div className={widgetFooterStyles.actionContainer}>
          <IconButton
            onClick={editDescription ? onSaveButtonClick : onEditButtonClick}
            aria-label={editDescription ? "save note" : "edit note"}
            // className={widgetFooterStyles.editIcon}
            title={
              editDescription
                ? "Save Widget Description/Tags"
                : "Edit Widget Description/Tags"
            }
          >
            {editDescription ? <SaveIcon /> : <EditIcon />}
          </IconButton>
        </div>
        <div className={widgetFooterStyles.editingContainer}>
          <DocumentView
            text={description}
            editMode={editDescription}
            handleEdit={onChangeDescription}
          />
          {editDescription ? (
            <div className={widgetFooterStyles.tagsContainer}>
              <Typography>Tags</Typography>
              <TextField
                value={tags}
                fullWidth
                onChange={(e) => {
                  onChangeTags(e.target.value);
                }}
                size="small"
              ></TextField>
            </div>
          ) : (
          <div id={"widgetTags"} className={widgetFooterStyles.widgetTags}>
            {tags}
          </div>
          )}
        </div>
        <br />
      </Collapse>

      <ExpandMore
        expand={expandDescription}
        onClick={handleExpandClick}
        aria-expanded={expandDescription}
        aria-label="show more"
      >
        <ExpandMoreIcon />
      </ExpandMore>
    </div>
  );
}

WidgetFooter.defaultProps = {
  widgetProps: { name: "", config: { tags: "#TNS #WNS" } },
};

export default WidgetFooter;
