import React from "react";
import AddWidgets, {
  addWidgetToDashboard,
} from "../../rptdashboard/addWidget/addWidget";
import CropLandscapeIcon from "@mui/icons-material/CropLandscape";
import CachedIcon from "@mui/icons-material/Cached";
import SettingsIcon from "@mui/icons-material/Settings";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/system";

//styles
import * as widgetTitleStyles from "./DashboardWidgetTitleBar.module.css";

import IconButton from "@mui/material/IconButton";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";

import { shallow } from "zustand/shallow";
import useGlobalStore from "../../../store/useGlobalStore";
import * as constants from "../../../constants/constants";
import _ from "lodash";
import { widgets } from "../../rptdashboard/addWidget/addWidget";


const RotateIconButton = styled(IconButton)({
  padding: "0px 3px",
  transition: "transform 0.7s ease-in-out",
  "&:hover": { transform: "rotate(360deg)" },
});

const ScaleIconButton = styled(IconButton)({
  padding: "0px 3px",
  transition: "transform 0.7s ease-in-out",
  "&:hover": { transform: "scale(1.5)" },
});

function WidgetMenu(props) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const { copyWidget, updateSettingsProp } = useGlobalStore(
    (state) => ({
      copyWidget: state.copyWidget,
      updateSettingsProp: state.updateSettingsProp,
    }),
    shallow
  );

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  var options = ["Add Widget", "Copy", "Delete"];

  if (Object.keys(copyWidget).length) {
    options.push("Paste");
  }

  if (_.get(props.widgetSettings, "minimize", false)) {
    options.push("Maximize");
  } else {
    options.push("Minimize");
  }

  const handleMenuClick = (option) => {
    handleClose();
    props.handleMenuClick(option);
  };

  return (
    <div id="widgetTitleDropdown">
      <Tooltip title="More options">
        <IconButton
          aria-label="more"
          id="long-button"
          aria-controls={open ? "long-menu" : undefined}
          aria-expanded={open ? "true" : undefined}
          aria-haspopup="true"
          onClick={handleClick}
          sx={{ padding: "0px 3px" }}
        >
          <ExpandMoreIcon fontSize={"small"} />
        </IconButton>
      </Tooltip>
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            // maxHeight: ITEM_HEIGHT * 4.5,
            width: "auto",
            borderRadius: "10px",
          },
        }}
      >
        {options.map((option) => (
          <MenuItem
            key={option}
            // selected={option === "Pyxis"}
            onClick={(e) => {
              handleMenuClick(option);
            }}
          >
            {option}
          </MenuItem>
        ))}
      </Menu>
    </div>
  );
}

class WidgetTitle extends React.Component {
  state = {
    openAddWidget: false,
  };

  handleAddWidget = () => {
    this.setState({ openAddWidget: !this.state.openAddWidget });
  };

  handleDelete = (widgetId) => {
    useGlobalStore
      .getState()
      .deleteWgt(constants.allDashbrdRpts, constants.dashboardReport, widgetId);
  };

  handleMenuClick = (option) => {
    switch (option) {
      case "Delete":
        this.handleDelete(this.props.widgetId);
        break;
      case "Expand":
        this.props.handleFullScreen(true);
        break;
      case "Refresh":
        this.props.refreshWidget();
        break;

      case "Minimize":
        this.props.minimizeWidget(true);
        break;

      case "Maximize":
        this.props.minimizeWidget(false);
        break;

      case "Settings":
        this.props.updateUiState({
          isLoading: false,
          showConfig: !this.props.uiState.showConfig,
          isToastOpen: false,
          toastSeverity: "info",
          toastMessage: "",
          cirlularLoading: false,
        });
        break;
      case "Add Widget":
        this.handleAddWidget();
        break;
      case "Paste":
        const nxtLineWgt = _.cloneDeep(useGlobalStore.getState().copyWidget);
        nxtLineWgt.y =
          this.props.widgetSettings.y + this.props.widgetSettings.h + 1;
        nxtLineWgt.x = this.props.widgetSettings.x;
        addWidgetToDashboard(nxtLineWgt);
        break;
      case "Copy":
        useGlobalStore
          .getState()
          .setRootLevelData("copyWidget", this.props.widgetSettings);
        break;
      default:
        console.log(
          `Menu event ${option} not is implemented or break statement is missing`
        );
    }
  };
  render() {
    return (
      <div
        {...this.props.handleProps}
        id="widgetTitle"
        className={widgetTitleStyles.titleBar}
      >
        {/* adding widget image for dashboard widget title */}
        {this.props &&
        this.props.widgetSettings &&
        this.props.widgetSettings.name &&
        this.props.widgetSettings.name.length > 0 ? (
          <img
            loading="lazy"
            width="50"
            height="20"
            src={
              widgets[this.props.widgetSettings.name]
                ? widgets[this.props.widgetSettings.name].imageUrl
                : ""
            }
            srcSet={
              widgets[this.props.widgetSettings.name]
                ? widgets[this.props.widgetSettings.name].imageUrl
                : ""
            }
            alt="widget-icon"
            borderRadius={"10px"}
            title={this.props.widgetSettings.name}
            onError={(e) =>
              e.currentTarget.src = "widget_library_icons/placeholder.svg"
            }
          />
        ) : (
          <></>
        )}
        <Typography className={"draggable " + widgetTitleStyles.title}>
          {this.props.title}
        </Typography>
        <div
          id="widgetMenuIconArea"
          className={widgetTitleStyles.widgetMenuIcon}
        >
          <WidgetMenu
            deleteWidget={this.props.deleteWidget}
            widgetId={this.props.widgetId}
            reportKey={this.props.reportKey}
            handleFullScreen={this.props.handleFullScreen}
            refreshWidget={this.props.refreshWidget}
            updateUiState={this.props.updateUiState}
            uiState={this.props.uiState}
            handleMenuClick={this.handleMenuClick}
            widgetName={this.props.widgetName}
            widgetSettings={this.props.widgetSettings}
            index={this.props.index}
          />

          <Tooltip title="Refresh">
            <RotateIconButton
              aria-label="refresh"
              id="long-button2"
              aria-haspopup="true"
              sx={{ padding: "0px 3px", fontSize: "2px" }}
              // disabled={this.props.widgetName == "Document View"}
              disabled={["Document View", "Metrics Group Bar Chart"].includes(
                this.props.widgetName
              )}
              onClick={() => this.handleMenuClick("Refresh")}
            >
              <CachedIcon
                fontSize={"small"}
                className={widgetTitleStyles.widgetIcon}
              />
            </RotateIconButton>
          </Tooltip>
          <Tooltip title="Expand">
            <ScaleIconButton
              aria-label="more"
              id="long-button3"
              aria-haspopup="true"
              sx={{ padding: "0px 3px" }}
              disabled={this.props.widgetName == "Document View"}
              onClick={() => this.handleMenuClick("Expand")}
            >
              <CropLandscapeIcon
                fontSize={"small"}
                // className={widgetTitleStyles.widgetIconExpand}
              />
            </ScaleIconButton>
            {/* <IconButton
             
            >
             
            </IconButton> */}
          </Tooltip>
          <Tooltip title="Settings">
            <RotateIconButton
              aria-label="more"
              id="long-button4"
              aria-haspopup="true"
              // sx={{ padding: "0px 3px" }}
              onClick={() => this.handleMenuClick("Settings")}
            >
              <SettingsIcon
                fontSize={"small"}
                className={widgetTitleStyles.widgetIcon}
              />
            </RotateIconButton>
          </Tooltip>
          <AddWidgets
            open={this.state.openAddWidget}
            handleClose={this.handleAddWidget}
            reportType={constants.dashboardReport}
            y={_.get(this.props.widgetSettings, "y", -2) + 1}
          />
        </div>
      </div>
    );
  }
}

WidgetTitle.defaultProps = {
  text: "",
  widgetId: "",
  reportKey: "",
  widgetName: "",
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  },
};

export default WidgetTitle;
