import React, { useState, useRef, useEffect } from "react";
import styled from "@xstyled/styled-components";
import _ from "lodash";
import { produce } from "immer";
import dynamic from "next/dynamic";

import FullScreenDialog from "../../rptdashboard/wigetWrapper/FullScreenWidget";
// import { TextareaAutosize } from "@mui/material";
import Skeleton from "@mui/material/Skeleton";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert from "@mui/material/Alert";
import CircularProgres from "@mui/material/CircularProgress";
import HistogramPlot from "../../rptdashboard/widgets/histogram/HistogramPlot";
import ThreeDSurfaceChart from "../../../components/widgets/three_d_surface_chart/ThreeDSurfaceChart";
import WorkflowMonitorTable from "../../../components/widgets/workflow_monitor_table/WorkflowMonitorTable";
import GroupBarChart from "../../../components/widgets/group_bar_chart/GroupBarChart";
import ScatterPlot from "../../../components/widgets/scatter_plot/ScatterPlot";
import MetricsGroupBarChart from "../../../components/widgets/group_bar_chart/MetricsGroupBarChart";
import LogMonitorTable from "../../../components/widgets/log_monitor_table/LogMonitorTable";
import GraphChart from "../../../components/widgets/graph_chart/GraphChart";
import GanttChart from "../../../components/widgets/gantt_chart/GanttChart";
import TableDetailImages from "../../../components/widgets/table_detail_images/TableDetailImages";
import IMetrics from "../../../components/widgets/i_metrics/IMetrics";
import IWidget from "../../../components/widgets/generic_interactive_widget/iWidget";
import TableViewExec from "../../../components/widgets/i_table_view/TableView";
import LogComparator from "../../../components/widgets/log_comparator/LogComparator";

// import ClickAwayListener from "@mui/base/ClickAwayListener";

//widgets
const LayoutView = dynamic(
  () =>
    import("../../../components/layout_view/LayoutView").then(
      (mod) => mod.default
    ),
  { ssr: false }
);
const LayoutTableView = dynamic(
  () =>
    import(
      "../../../components/layout_view/layoutTableView/LayoutTableView"
    ).then((mod) => mod.default),
  { ssr: false }
);
import Metrics from "../../metrics/index";
import TableView from "../../rptdashboard/widgets/tableView/TableView";

import DocumentView from "../../rptdashboard/widgets/document/DocumentView";
import InterClockMatrix from "../../rptdashboard/widgets/interClockMatrix/InterClockMatrix";
import TimingPathMatrix from "../../rptdashboard/widgets/timing_path_matrix/TimingPathMatrix";
import Treemap from "../../rptdashboard/widgets/treemap/Treemap";
import MultifeatureBarPlot from "../../rptdashboard/widgets/multifeature_bar_chart/MultifeatureBarPlot";
import KdePlot from "../../rptdashboard/widgets/kdeplot/KdePlot";
import BubbleChart from "../../rptdashboard/widgets/bubble_chart/BubbleChart";
// import LogMonitor from "../../logmonitor/index";

import MultiBoxPlot from "../../rptdashboard/widgets/multi_boxplot/MultiBoxPlot";
import BoxPlot from "../../rptdashboard/widgets/box_plot/BoxPlot";

import WidgetTitle from "./DashboardWidgetTitleBar";
import WidgetFooter from "./DashboardWidgetFooter";
import PieChart from "../../rptdashboard/widgets/pie_chart/PieChart";

import TaskManager from "../../rptdashboard/widgets/task_manager";
import CustomWorkflowManager from "../../rptdashboard//widgets/flow_manager/custom_workflow_manager";
import FlowManager from "../../rptdashboard/widgets/flow_manager";

import TimingPathDetails from "../../rptdashboard/widgets/timing_path_details/TimingPathDetails";
import TimingPathSummary from "../../rptdashboard/widgets/timing_path_summary/TimingPathSummary";
import TimingPathCompare from "../../rptdashboard/widgets/timing_path_compare/TimingPathCompare";

//styles
import * as widgetWrapperStyles from "./DashboardWidgets.module.css";

import * as constants from "../../../constants/constants";

import { shallow } from "zustand/shallow";
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";

export const widgetWrapperDiv = styled.div`
  box-shadow: 2px 2px 5px 2px #c6c6e9;
  border-radius: 10px;
  padding: 5px 5px;
  width: 90vw;
`;

import refreshWidgetContent from "../../rptdashboard/wigetWrapper/widgetRefreshData";
import LayoutViewV2 from "../../../components/widgets/layout_view_v2/LayoutViewV2";
import GenericChartsV1 from "../../../components/widgets/generic_charts_v1/GenericChartsV1";

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function WidgetWrapper(props) {
  const [isFullScreen, setFullScreen] = useState(false);

  const [docViewText, setDocViewText] = useState(
    _.get(props.widgetProps.config, "text", "")
  );

  let resizeTimeout = null;

  const contentRef = useRef(null);

  useEffect(() => {
    const resizeObserver = new ResizeObserver((entries) =>
      handleResize(entries)
    );

    if (contentRef.current) {
      resizeObserver.observe(contentRef.current);
    }

    return () => {
      resizeObserver.disconnect();
      clearTimeout(resizeTimeout);
    };
  }, []);

  const {
    data,
    uiState,
    updateConfig,
    setWidgetUiState,
    updateWidgetSettings,
  } = useGlobalStore(
    (state) => ({
      data: state[props.id] ? state[props.id].data : {},
      uiState: state[props.id]
        ? state[props.id].uiState
        : {
            isLoading: false,
            showConfig: false,
            isToastOpen: false,
            toastSeverity: "info",
            toastMessage: "",
            cirlularLoading: false,
          },
      updateConfig: state.updateConfig,
      setWidgetUiState: state.setWidgetUiState,
      updateWidgetSettings: state.updateWidgetSettings,
    }),
    shallow
  );
  const { theme } = useConfigStore(
    (state) => ({
      theme: state.theme,
    }),
    shallow
  );

  const handleDocumentEdit = (text) => {
    setDocViewText(text);
  };

  const refreshWidget = () => {
    const variables =
      useGlobalStore.getState()[constants.allDashbrdRpts][
        constants.dashboardReport
      ]?.variables;

    const config = props.widgetProps.config;
    refreshWidgetContent({
      widgetId: props.id,
      config: config,
      widgetName: props.widgetProps.name,
      reportKey: constants.dashboardReport,
      rptType: constants.allDashbrdRpts,
      variables: variables ? variables : {},
    });
  };

  const handleResize = (entries) => {
    const resizeTimeout = setTimeout(() => {
      // console.log("Div resized", entries);
    }, 500);

    clearTimeout(resizeTimeout);
  };

  const handleCloseToast = () => {
    const newUiState = {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    };
    setWidgetUiState(props.id, newUiState);
  };

  const getWidgetContent = () => {
    let widgetContent;

    if (uiState.isLoading) {
      return <Skeleton variant="rounded" height={"100%"} animation={"wave"} />;
    }
    // const data = {}
    //return the widget on the basis of widget name
    switch (props.widgetProps.name) {
      case constants.tableView:
        widgetContent = (
          <TableView
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;

      case constants.tableViewExec:
        widgetContent = (
          <TableViewExec
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;

      case constants.documentView:
        widgetContent = (
          <DocumentView
            text={docViewText}
            editMode={uiState.showConfig}
            handleEdit={handleDocumentEdit}
          />
        );
        break;

      case constants.metricsSummary:
        widgetContent = (
          <Metrics
            id={props.id}
            config={props.widgetProps.config}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      case constants.interClockMatrix:
        widgetContent = (
          <InterClockMatrix
            id={props.id}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            widgetProps={props.widgetProps}
          />
        );
        break;

      case constants.treemap:
        widgetContent = (
          <Treemap
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;
      case constants.timingPathMatrix:
        widgetContent = (
          <TimingPathMatrix
            widgetProps={props.widgetProps}
            id={props.id}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;
      case constants.groupBarChart:
        widgetContent = (
          <GroupBarChart
            id={props.id}
            // config={props.widgetProps.config}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      case constants.metricsGroupBarChart:
        widgetContent = (
          <MetricsGroupBarChart
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      case constants.histogram:
        widgetContent = (
          <HistogramPlot
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;
      case constants.boxPlot:
        widgetContent = (
          <BoxPlot
            id={props.id}
            endPointUrl={props.endPointUrl}
            widgetProps={props.widgetProps}
            uiState={uiState}
            data={data}
            config={props.widgetProps.config}
          />
        );
        break;

      case constants.multiBoxPlot:
        widgetContent = (
          <MultiBoxPlot
            id={props.id}
            endPointUrl={props.endPointUrl}
            widgetProps={props.widgetProps}
            uiState={uiState}
            data={data}
            config={props.widgetProps.config}
          />
        );
        break;

      case constants.pieChart:
        widgetContent = (
          <PieChart
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;
      case constants.kdePlot:
        widgetContent = (
          <KdePlot
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      case constants.bubbleChart:
        widgetContent = (
          <BubbleChart
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      // case constants.logMonitor:
      //   widgetContent = (
      //     <LogMonitor
      //       id={props.id}
      //       widgetProps={props.widgetProps}
      //       parentRef={contentRef}
      //       rptType={constants.allDashbrdRpts}
      //       reportKey={constants.dashboardReport}
      //     />
      //   );
      //   break;
      //Below  Widets Merged into WorkFlow Monitor Widget

      // case constants.taskAnalysisManager:
      //   widgetContent = <TaskManager />;
      //   break;

      // case constants.customWorkflowManager:
      //   widgetContent = (
      //     <CustomWorkflowManager
      //       id={props.id}
      //       endPointUrl={props.endPointUrl}
      //     />
      //   );
      //   break;

      // case constants.flowAnalysisManager:
      //   widgetContent = (
      //     <FlowManager id={props.id} endPointUrl={props.endPointUrl} />
      //   );
      //   break;

      case constants.multiFeatureBarPlot:
        widgetContent = (
          <MultifeatureBarPlot
            widgetProps={props.widgetProps}
            uiState={uiState}
            data={data}
            config={props.widgetProps.config}
            id={props.id}
            endPointUrl={props.endPointUrl}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      case constants.bubbleChart:
        widgetContent = (
          <BubbleChart
            widgetProps={props.widgetProps}
            uiState={uiState}
            data={data}
            id={props.id}
            endPointUrl={props.endPointUrl}
          />
        );
        break;

      case constants.timingpathSummary:
        widgetContent = (
          <TimingPathSummary
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      case constants.timingpathCompare:
        widgetContent = (
          <TimingPathCompare
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      case constants.timingpathDetail:
        widgetContent = (
          <TimingPathDetails
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
          />
        );
        break;

      case constants.layoutView:
        widgetContent = (
          <LayoutView
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;

      case constants.layoutTableView:
        widgetContent = (
          <LayoutTableView
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      // for 3D surface chart
      case constants.threeDSurfaceChart:
        widgetContent = (
          <ThreeDSurfaceChart
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      // for workflow monitor table widget
      case constants.workflowMonitorTable:
        widgetContent = (
          <WorkflowMonitorTable
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      // for scatter plot widget
      case constants.scatterPlot:
        widgetContent = (
          <ScatterPlot
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      // for log monitor table widget
      case constants.logMonitorTable:
        widgetContent = (
          <LogMonitorTable
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      // for graph chart widget
      case constants.graphChart:
        widgetContent = (
          <GraphChart
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      // for gantt chart widget
      case constants.ganttChart:
        widgetContent = (
          <GanttChart
            id={props.id}
            config={props.widgetProps.config}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      // for log analysis line chart
      case constants.lineChart:
        widgetContent = (
          <IWidget
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
            chartType="line"
          />
        );
        break;
      case constants.tableDetailImages:
        widgetContent = (
          <TableDetailImages
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      // for interactive scatter plot
      case constants.iScatterPlot:
        widgetContent = (
          <IWidget
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
            chartType="scatter"
          />
        );
        break;
      case constants.I_METRICS:
        widgetContent = (
          <IMetrics
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;

      case constants.iPieChart:
        widgetContent = (
          <IWidget
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
            chartType="pie"
          />
        );
        break;
      case constants.iGroupBarChart:
        widgetContent = (
          <IWidget
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
            chartType="group_bar"
          />
        );
        break;
      case constants.iTreemapChart:
        widgetContent = (
          <IWidget
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
            chartType="treemap"
          />
        );
        break;
      case constants.iMultiFeatureBarChart:
        widgetContent = (
          <IWidget
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
            chartType="multifeature_bar"
          />
        );
        break;
      case constants.iSunburstChart:
        widgetContent = (
          <IWidget
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
            chartType="sunburst"
          />
        );
        break;
      case constants.logComparator:
        widgetContent = (
          <LogComparator
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
            chartType="log_comparator"
          />
        );
        break;
      case constants.LAYOUT_VIEW_V2:
        widgetContent = (
          <LayoutViewV2
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      case constants.GENERIC_CHARTS_V1:
        widgetContent = (
          <GenericChartsV1
            id={props.id}
            widgetProps={props.widgetProps}
            rptType={constants.allDashbrdRpts}
            reportKey={constants.dashboardReport}
            index={props.index}
          />
        );
        break;
      default:
        widgetContent = getEmptyContentDisplay();
    }

    // return widgetContent;

    return (
      <div
        id="theContent"
        style={{ height: "100%", position: "relative", padding: "10px 5px" }}
      >
        {widgetContent}
        {uiState.cirlularLoading ? (
          <CircularProgres
            sx={{
              margin: "auto",
              position: "absolute",
              top: "50%",
              left: "50%",
            }}
          />
        ) : null}
        <Snackbar
          open={uiState.isToastOpen}
          autoHideDuration={6000}
          onClose={handleCloseToast}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
          sx={{ position: "absolute" }}
        >
          <Alert
            onClose={handleCloseToast}
            severity={uiState.toastSeverity}
            sx={{ width: "100%" }}
          >
            {uiState.toastMessage}
          </Alert>
        </Snackbar>
      </div>
    );
  };

  const getWidgetTitle = () => {
    if (props.widgetProps) {
      return props.widgetProps.config.title
        ? props.widgetProps.config.title
        : props.widgetProps.name;
    }
    return "";
  };

  const getEmptyContentDisplay = () => {
    return <div>NO WIDGET SELECTED</div>;
    // <TextareaAutosize defaultValue={getWidgetTitle()} />;
  };

  const handleFullScreen = (isFullScreen) => {
    setFullScreen(isFullScreen);
  };

  // const updateUiState = (newUiState) => {
  //   if (props.widgetProps.name == constants.documentView) {
  //     const config = props.widgetProps.config;
  //     const newConfig = produce(config, (configDraft) => {
  //       configDraft.text = docViewText;
  //     });
  //     // updateConfig(props.id, newConfig);
  //     updateConfig(constants.allDashbrdRpts, props.reportKey, props.id, newConfig);

  //   }
  //   setWidgetUiState(props.id, newUiState);
  // };

  const updateUiState = (newUiState) => {
    if (props.widgetProps.name == constants.documentView) {
      const config = props.widgetProps.config;
      const newConfig = produce(config, (configDraft) => {
        configDraft.text = docViewText;
      });

      updateConfig(
        constants.allDashbrdRpts,
        constants.dashboardReport,
        props.id,
        newConfig
      );
    }
    setWidgetUiState(props.id, newUiState);
  };

  const minimizeWidget = (flag) => {
    const newWidgetSettings = _.cloneDeep(props.widgetProps);
    if (flag) {
      //minimize
      newWidgetSettings.minimize = flag;
      newWidgetSettings.prevHeight = newWidgetSettings.h;
    } else {
      newWidgetSettings.minimize = flag;
      newWidgetSettings.h = newWidgetSettings.prevHeight;
    }
    updateWidgetSettings(
      constants.allDashbrdRpts,
      constants.dashboardReport,
      props.id,
      newWidgetSettings
    );
  };

  return (
    // <ClickAwayListener onClickAway={handleClickAway}>
    <div
      id="parentWrapper"
      className={widgetWrapperStyles.widgetWrapper}
      style={{ backgroundColor: theme == "dark" ? "#121212" : "white" }}
    >
      <WidgetTitle
        handleProps={props.handleProps}
        title={getWidgetTitle()}
        widgetId={props.id}
        handleFullScreen={handleFullScreen}
        refreshWidget={refreshWidget}
        updateUiState={updateUiState}
        widgetSettings={props.widgetProps}
        uiState={uiState}
        widgetName={props.widgetProps.name}
        minimizeWidget={minimizeWidget}
      />
      <hr
        style={{
          backgroundColor: theme == "dark" ? "white" : "#121212",
          opacity: 1,
          height: "1px",
          margin: "0px",
        }}
      />
      <div
        id="widgetContent"
        ref={contentRef}
        className={widgetWrapperStyles.content}
      >
        <FullScreenDialog
          childComponent={getWidgetContent()}
          isFullScreen={isFullScreen}
          handleFullScreen={handleFullScreen}
          title={getWidgetTitle()}
          refreshWidget={refreshWidget}
          uiState={uiState}
          updateUiState={updateUiState}
        />
        {getWidgetContent()}
      </div>
      {props.widgetProps.name != constants.documentView &&
      props.widgetProps.h != 1 ? (
        <hr
          style={{
            backgroundColor: theme == "dark" ? "white" : "#121212",
            opacity: 1,
            height: "1px",
            margin: "0px",
          }}
        />
      ) : null}
      {props.widgetProps.name != constants.documentView &&
      props.widgetProps.h != 1 ? (
        <div id="widgetWrapperFooter">
          <WidgetFooter
            widgetProps={props.widgetProps}
            id={props.id}
            rptType={constants.allDashbrdRpts}
            report={constants.dashboardReport}
          />
        </div>
      ) : null}
    </div>
    // {/* </ClickAwayListener> */}
  );
}

WidgetWrapper.defaultProps = {
  widgetProps: {
    name: "",
    config: { w: 10, h: 8, title: "" },
    handleProps: {},
  },
};

export default WidgetWrapper;
