import React, { useState, useRef, useEffect } from "react";
import GridLayout, { WidthProvider } from "react-grid-layout";
import "/node_modules/react-grid-layout/css/styles.css";
import "/node_modules/react-resizable/css/styles.css";
import _ from "lodash";
import { useRouter } from "next/router";
import IconButton from "@mui/material/IconButton";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import clipboardCopy from "clipboard-copy";
import Typography from "@mui/material/Typography";
import getConfig from "next/config";
import Box from "@mui/material/Box";
import { styled } from "@mui/material/styles";
import CircularProgress from "@mui/material/CircularProgress";
import axios from "axios";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import * as styles from "./Dashboard.module.css";
import AddWidgets from "../rptdashboard/addWidget/addWidget";
import * as constants from "../../constants/constants";
import refreshWidgetContent from "../rptdashboard/wigetWrapper/widgetRefreshData";
import ModalComponent from "../../components/ModalComponent/ModalComponent";
import ShareReportModal from "../../pages/rptdashboard/views/dnd/board/ShareReportModal";
import DataSource from "../../pages/rptdashboard/data_source/DataSource";
import api from "../../common/api/api";
import * as utils from "../../common/utils/utils";
// import DashboardWidgetError from "../../components/widgetError/dashboardWidgetError";
import Tooltip from "@mui/material/Tooltip";
import { makeFixedPostRequest } from "../../common/api/getDefaultDashApi";
import DeleteDashboard from "../../components/DeleteDashboardModal/DeleteDashboard";
import PublishComponent from "./PublishComponent";
// import VariableComponent from "../../components/VariableComponent";
import {
  Button,
  Autocomplete,
  TextField,
  ClickAwayListener,
  Modal,
  inputClasses,
  Badge,
  Paper,
  DialogTitle,
} from "@mui/material";
import { Collapse, inputAdornmentClasses, Stack, Input } from "@mui/material";
import {
  ArrowDropUp,
  BarChartOutlined,
  DonutLarge,
  TableChart,
  TrendingUp,
} from "@mui/icons-material";
import { inputLabelClasses } from "@mui/material/InputLabel";
import Toolbar from "@mui/material/Toolbar";
import LocalLibraryIcon from "@mui/icons-material/LocalLibrary";
import Drawer from "@mui/material/Drawer";
import NewReleasesIcon from "@mui/icons-material/NewReleases";
import ClassIcon from "@mui/icons-material/Class";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import SaveIcon from "@mui/icons-material/Save";
import GradeIcon from "@mui/icons-material/Grade";
import ShareIcon from "@mui/icons-material/Share";
import WidgetsIcon from "@mui/icons-material/Widgets";
import Divider from "@mui/material/Divider";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import AppBar from "@mui/material/AppBar";
import CloseIcon from "@mui/icons-material/Close";
import Slide from "@mui/material/Slide";
import WidgetLibManager from "../../components/wgt_library_manager/wgtLibManager";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ExportToHTMLModal from "../../components/ModalComponent/ExportToHTMLModal";
// import Draggable from "react-draggable";

// function PaperComponent(props) {
//   return (
//     <Draggable
//       handle="#draggable-dialog-title"
//       cancel={'[class*="MuiDialogContent-root"]'}
//     >
//       <Paper {...props} />
//     </Draggable>
//   );
// }
const StyledTextField = styled(TextField)`
  & .MuiInputBase-root {
    font-size: 0.8rem;
  }
`;

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ paddingY: 1, paddingX: 2 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}
const StyledTabs = styled((props) => (
  <Tabs
    {...props}
    TabIndicatorProps={{ children: <span className="MuiTabs-indicatorSpan" /> }}
  />
))({
  "& .MuiTabs-indicator": {
    display: "flex",
    justifyContent: "center",
    backgroundColor: "#dadada",
  },
  "& .MuiTabs-indicatorSpan": {
    width: "100%",
    backgroundColor: "#5b2c84",
  },
});

const StyledTab = styled((props) => <Tab disableRipple {...props} />)(
  ({ theme }) => ({
    fontSize: "0.9rem",
    textTransform: "capitalize !important",
    color: "black",
    padding: "0px",

    marginRight: theme.spacing(2),
    "&.Mui-selected": {
      color: "#5b2c84",
      fontWeight: "600",
    },
  })
);

const ReactGridLayout = WidthProvider(GridLayout);
const { publicRuntimeConfig } = getConfig();
const imageUrl = publicRuntimeConfig.basePath;
const Dashboard = (props) => {
  const router = useRouter();
  const { allDashbrdRpts, dashboardRightPane, setRootLevelData } =
    useGlobalStore();
  const updateLayout = useGlobalStore((state) => state.updateWidgetLayout);
  const dashboardChange = useGlobalStore.getState().dashboardChange;
  const IconButtonRef = useRef();
  const dashboardContainerRef = useRef(null);
  const [projectMember, setProjectMember] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [parameter, setParameter] = useState("");
  const [toggleApi, setToggleApi] = useState(false);
  const [reportQueryVal, setReportQueryVal] = useState("");
  const [showDataSource, setShowDataSource] = useState(false);
  const [defaultload, setDefaultLoad] = useState(false);
  const [isPropModalOpen, setIsPropModalOpen] = useState(false);
  const [expandDashbrd, setExpandDashbrd] = useState(true);
  const [newLoading, setnewloading] = useState(true);
  const [menuOpen, setMenu] = useState(false);
  const [openAddWidget, setOpenAddWidget] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState("");
  const [mainComponentData, setMainComponentData] = useState({});
  const [tempConfig, setTempConfig] = useState([]);
  const [publishProjectList, setPublishProjectList] = useState([]);
  const [widgetForm, setWidgetForm] = useState([]);
  const [scenariosSelect, setScenariosSelect] = useState("");
  const [isPrefModalOpen, setIsPrefModalOpen] = useState(false);
  const [propDataLocation, setPropDataLocation] = useState("");
  const [propbucket, setbucket] = useState("");
  const [value, setValue] = useState("");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const [selectedButton, setSelectedButton] = useState(null);
  const handleButtonClick = (buttonId) => {
    setSelectedButton(buttonId);
  };
  const [dataValue, setDataValue] = useState("");
  const [dashboardName, setDashboardName] = useState(
    useGlobalStore
      .getState()
      .allDashbrdRpts?.dashboardReport?.fileName.toString()
  );
  const [projectName, setProjectName] = useState("");
  const [typographyItem, setTypographyItem] = useState(true);
  const [enableDashboardRename, setEnableDashboardRename] = useState(false);
  const [widgetLib, setWidgetLib] = useState({ open: false });
  const [openExportModal, setOpenExportModal] = useState(false);

  // delete dashboard modal
  const [openDeleteModal, setOpenDeleteModal] = useState(false);

  const { configData, authLoginUser, theme } = useConfigStore();

  const setRightpane = async () => {
    const response = await api(
      configData.rest_server_url + "/api/get_dashboards",
      {
        user: authLoginUser,
      }
    );
    if (response && response.status) {
      const rightPane = _.cloneDeep(dashboardRightPane);
      rightPane.savedDashbrdCount =
        response.local_dashboards.length + response.published_dashboards.length;
      setRootLevelData("dashboardRightPane", rightPane);
    }
  };

  useEffect(() => {
    setRightpane();
  }, []);

  useEffect(() => {
    if (router.query.reportKey) {
      setReportQueryVal(router.query.reportKey);
    } else {
      let specData = {};
      setTypographyItem(true);
      async function loadConfig() {
        const response = await fetch("/v1/defaultReportSpec.json");
        specData = await response.json();
      }
      //dashboardChange
      async function loadRptData() {
        await loadConfig();
        try {
          let userauth = authLoginUser;
          const reportResponse = await axios.post(
            configData.rest_server_url + "/api/get_user_config",
            {
              user: userauth,
              metricSpec: specData,
            }
          );

          const response =
            reportResponse.data.user_config[
            Object.keys(reportResponse.data.user_config)
            ];
          if (Object.keys(reportResponse.data.user_config).length != 0) {
            let rptData = {
              dashboardReport: response,
            };
            setDashboardName(rptData.dashboardReport.fileName);
            useGlobalStore.getState().updateDashboardObject(rptData);
            if (rptData?.dashboardReport?.dataLocation) {
              setTempConfig(rptData?.dashboardReport?.dataLocation);
            }
            if (rptData?.dashboardReport?.projects) {
              setPublishProjectList(rptData?.dashboardReport?.projects);
            }
            if (rptData.dashboardReport.hasOwnProperty("widgets")) {
              for (const Wkey in rptData.dashboardReport.widgets) {
                let WkeyObj = {
                  data: {},
                  uiState: {
                    isLoading: false,
                    showConfig: false,
                    isToastOpen: false,
                    toastSeverity: "info",
                    toastMessage: "",
                    cirlularLoading: false,
                  },
                };
                useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
              }
            }
            const widgetArray = Object.keys(rptData.dashboardReport.widgets);
            for (let i = 0; i < widgetArray.length; i++) {
              const widgetId = widgetArray[i];
              const config = rptData?.dashboardReport?.widgets[widgetId].config;
              const name = rptData?.dashboardReport?.widgets[widgetId].name;
              const rptType = rptData?.dashboardReport?.widgets[widgetId]
                ?.rptType
                ? rptData?.dashboardReport.widgets[widgetId]?.rptType
                : constants.allDashbrdRpts;
              const reportKey = rptData?.dashboardReport?.widgets[widgetId]
                ?.reportKey
                ? rptData?.dashboardReport.widgets[widgetId]?.reportKey
                : constants.dashboardReport;
              const rptDataVariablesCheck =
                rptData.dashboardReport.hasOwnProperty("variables") &&
                  rptData.dashboardReport?.variables
                  ? rptData.dashboardReport.variables
                  : {};
              const dashboardVariables =
                Object.keys(rptDataVariablesCheck).length > 0
                  ? rptDataVariablesCheck
                  : {};
              refreshWidgetContent({
                widgetId: widgetId,
                config: config,
                widgetName: name,
                reportKey: reportKey,
                rptType: rptType,
                variables: dashboardVariables,
              });
            }
          }

          const responseProfilePref = await axios.post(
            configData.rest_server_url + "/api/get_profile_config",
            {
              user: userauth,
            }
          );
          if (Object.keys(responseProfilePref.data.profile_config).length > 1) {
            let defaultMetricProject =
              responseProfilePref.data.profile_config.project;

            useConfigStore
              .getState()
              .setMetricProjectName(defaultMetricProject);
          } else {
            const userProjectResponse = await axios.post(
              configData.rest_server_url + "/api/fetch_buckets",
              {
                user: authLoginUser,
              }
            );
            const userProjectData = userProjectResponse.data;
            let updateProjectVal = userProjectData.data[0];
            useConfigStore.getState().setMetricProjectName(updateProjectVal);
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      }
      loadRptData();
    }
  }, [router.query]);

  useEffect(() => {
    let specData = {};
    setTypographyItem(true);
    async function loadConfig() {
      const response = await fetch("/v1/defaultReportSpec.json");
      specData = await response.json();
    }
    async function loadRptData() {
      await loadConfig();
      let userauth = authLoginUser;
      axios
        .post(configData.rest_server_url + "/api/get_user_config", {
          user: userauth,
          metricSpec: specData,
        })
        .then((reportResponse) => {
          const response =
            reportResponse.data.user_config[
            Object.keys(reportResponse.data.user_config)
            ];
          if (Object.keys(reportResponse.data.user_config).length != 0) {
            let rptData = {
              dashboardReport: response,
            };
            //setDashboardName(Object.keys(reportResponse.data.user_config));
            setDashboardName(rptData.dashboardReport.fileName);
            if (dashboardChange === rptData.dashboardReport.fileName) {
              useGlobalStore.getState().updateDashboardObject(rptData);
              if (rptData.dashboardReport.hasOwnProperty("widgets")) {
                for (const Wkey in rptData.dashboardReport.widgets) {
                  let WkeyObj = {
                    data: {},
                    uiState: {
                      isLoading: false,
                      showConfig: false,
                      isToastOpen: false,
                      toastSeverity: "info",
                      toastMessage: "",
                      cirlularLoading: false,
                    },
                  };
                  useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
                }
              }
              const widgetArray = Object.keys(rptData.dashboardReport.widgets);
              for (let i = 0; i < widgetArray.length; i++) {
                const widgetId = widgetArray[i];
                const config =
                  rptData?.dashboardReport?.widgets[widgetId].config;
                const name = rptData?.dashboardReport?.widgets[widgetId].name;
                const rptType = rptData?.dashboardReport?.widgets[widgetId]
                  ?.rptType
                  ? rptData?.dashboardReport.widgets[widgetId]?.rptType
                  : constants.allDashbrdRpts;
                const reportKey = rptData?.dashboardReport?.widgets[widgetId]
                  ?.reportKey
                  ? rptData?.dashboardReport.widgets[widgetId]?.reportKey
                  : constants.dashboardReport;
                const rptDataVariablesCheck =
                  rptData.dashboardReport.hasOwnProperty("variables") &&
                    rptData.dashboardReport?.variables
                    ? rptData.dashboardReport.variables
                    : {};
                const dashboardVariables =
                  Object.keys(rptDataVariablesCheck).length > 0
                    ? rptDataVariablesCheck
                    : {};
                refreshWidgetContent({
                  widgetId: widgetId,
                  config: config,
                  widgetName: name,
                  reportKey: reportKey,
                  rptType: rptType,
                  variables: dashboardVariables,
                });
              }
            }
          }
        });
    }
    // loadConfig();
    loadRptData();
    useGlobalStore.getState().setDashboardChange("D$!!)012K@");
  }, [dashboardChange]);

  useEffect(() => {
    if (reportQueryVal) {
      let specData = {};
      setTypographyItem(true);
      async function loadConfig() {
        const response = await fetch("/v1/defaultReportSpec.json");
        specData = await response.json();

        const responseProfilePref = await axios.post(
          configData.rest_server_url + "/api/get_profile_config",
          {
            user: authLoginUser,
          }
        );
        if (Object.keys(responseProfilePref.data.profile_config).length > 1) {
          let defaultMetricProject =
            responseProfilePref.data.profile_config.project;

          useConfigStore.getState().setMetricProjectName(defaultMetricProject);
        } else {
          const userProjectResponse = await axios.post(
            configData.rest_server_url + "/api/fetch_buckets",
            {
              user: authLoginUser,
            }
          );
          const userProjectData = userProjectResponse.data;
          let updateProjectVal = userProjectData.data[0];
          useConfigStore.getState().setMetricProjectName(updateProjectVal);
        }
      }
      async function loadRptData() {
        await loadConfig();
        try {
          let userauth = authLoginUser;
          const reportResponse = await axios.post(
            configData.rest_server_url + "/api/read_json_from_path",
            {
              path: reportQueryVal,
            }
          );

          const response = reportResponse.data.data;
          if (Object.keys(reportResponse.data.data).length != 0) {
            let rptData = {
              dashboardReport: response,
            };
            //setDashboardName(Object.keys(reportResponse.data.user_config));
            setDashboardName(rptData.dashboardReport.fileName);
            useGlobalStore.getState().updateDashboardObject(rptData);
            if (rptData?.dashboardReport?.dataLocation) {
              setTempConfig(rptData?.dashboardReport?.dataLocation);
            }
            if (rptData?.dashboardReport?.projects) {
              setPublishProjectList(rptData?.dashboardReport?.projects);
            }
            if (rptData.dashboardReport.hasOwnProperty("widgets")) {
              for (const Wkey in rptData.dashboardReport.widgets) {
                let WkeyObj = {
                  data: {},
                  uiState: {
                    isLoading: false,
                    showConfig: false,
                    isToastOpen: false,
                    toastSeverity: "info",
                    toastMessage: "",
                    cirlularLoading: false,
                  },
                };
                useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
              }
            }
            const widgetArray = Object.keys(rptData.dashboardReport.widgets);
            for (let i = 0; i < widgetArray.length; i++) {
              const widgetId = widgetArray[i];
              const config = rptData?.dashboardReport?.widgets[widgetId].config;
              const name = rptData?.dashboardReport?.widgets[widgetId].name;
              const rptType = rptData?.dashboardReport?.widgets[widgetId]
                ?.rptType
                ? rptData?.dashboardReport.widgets[widgetId]?.rptType
                : constants.allDashbrdRpts;
              const reportKey = rptData?.dashboardReport?.widgets[widgetId]
                ?.reportKey
                ? rptData?.dashboardReport.widgets[widgetId]?.reportKey
                : constants.dashboardReport;
              const rptDataVariablesCheck =
                rptData.dashboardReport.hasOwnProperty("variables") &&
                  rptData.dashboardReport?.variables
                  ? rptData.dashboardReport.variables
                  : {};
              const dashboardVariables =
                Object.keys(rptDataVariablesCheck).length > 0
                  ? rptDataVariablesCheck
                  : {};
              refreshWidgetContent({
                widgetId: widgetId,
                config: config,
                widgetName: name,
                reportKey: reportKey,
                rptType: rptType,
                variables: dashboardVariables,
              });
            }
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      }
      loadRptData();
    }
  }, [reportQueryVal]);

  const onLayoutChange = (newLayout) => {
    updateLayout(newLayout);
  };
  const ExpandMore = styled((props) => {
    const { expand, ...other } = props;
    return <IconButton {...other} />;
  })(({ theme, expand }) => ({
    transform: !expand ? "rotate(180deg)" : "rotate(0deg)",
    margin: "auto",
    padding: "0px",
    transition: theme.transitions.create("transform", {
      duration: "5s",
    }),
  }));
  const getWidget = (widget) => {
    return (
      <div
        // data-grid={{
        //   i: widget.key,
        //   x: _.get(widget, "x", 0),
        //   y: _.get(widget, "y", 0),
        //   w: _.get(widget, "w", _.get(widget, "width", 15)),
        //   h: _.get(widget, "h", _.get(widget, "height", 10)),
        //   minW: 2,
        //   minH: 3,
        // }}
        key={widget.key}
      >
        {/* <DashboardWidgetError widgetProps={widget} id={widget.key} /> */}
      </div>
    );
  };

  const getLayout = () => {
    if (allDashbrdRpts[constants.dashboardReport].hasOwnProperty("widgets")) {
      let layout = [];
      for (let [widgegtId, widget] of Object.entries(
        allDashbrdRpts[constants.dashboardReport].widgets
      )) {
        layout.push({
          i: widgegtId,
          x: _.get(widget, "x", 0),
          y: _.get(widget, "y", 0),
          w: _.get(widget, "w", _.get(widget, "width", 15)),
          h: _.get(widget, "minimize", false)
            ? 1
            : _.get(widget, "h", _.get(widget, "height", 10)),
          minW: 2,
          minH: 1,
        });
      }
      return layout;
    }
  };

  const handleCloseMenu = () => {
    setMenu(false);
  };

  const handleRefreshDashboard = async () => {
    try {
      setDefaultLoad(true);
      if (dashboardName === "Default-Dashboard") {
        const response1 = await handleDeleteDashboard();
        const responseDash = await makeFixedPostRequest([1, 2]);
        useGlobalStore.getState().setDashboardChange("Default-Dashboard");
      } else {
        let rptData = {
          dashboardReport:
            useGlobalStore.getState().allDashbrdRpts.dashboardReport,
        };
        useGlobalStore.getState().updateDashboardObject(rptData);
        if (rptData.dashboardReport.hasOwnProperty("widgets")) {
          for (const Wkey in rptData.dashboardReport.widgets) {
            let WkeyObj = {
              data: {},
              uiState: {
                isLoading: false,
                showConfig: false,
                isToastOpen: false,
                toastSeverity: "info",
                toastMessage: "",
                cirlularLoading: false,
              },
            };
            useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
          }
        }
        const widgetArray = Object.keys(rptData.dashboardReport.widgets);
        for (let i = 0; i < widgetArray.length; i++) {
          const widgetId = widgetArray[i];
          const config = rptData?.dashboardReport?.widgets[widgetId].config;
          const name = rptData?.dashboardReport?.widgets[widgetId].name;
          const rptType = rptData?.dashboardReport?.widgets[widgetId]?.rptType
            ? rptData?.dashboardReport.widgets[widgetId]?.rptType
            : constants.allDashbrdRpts;
          const reportKey = rptData?.dashboardReport?.widgets[widgetId]
            ?.reportKey
            ? rptData?.dashboardReport.widgets[widgetId]?.reportKey
            : constants.dashboardReport;

          const rptDataVariablesCheck =
            rptData.dashboardReport.hasOwnProperty("variables") &&
              rptData.dashboardReport?.variables
              ? rptData.dashboardReport.variables
              : {};
          const dashboardVariables =
            Object.keys(rptDataVariablesCheck).length > 0
              ? rptDataVariablesCheck
              : {};

          refreshWidgetContent({
            widgetId: widgetId,
            config: config,
            widgetName: name,
            reportKey: reportKey,
            rptType: rptType,
            variables: dashboardVariables,
          });
        }
      }
    } catch (e) {
      console.log(e);
    } finally {
      setDefaultLoad(false);
    }
  };

  const handleMenuOpen = () => {
    setMenu(true);
  };
  const handleDataLocationChange = (newDataLocation, bucket) => {
    dataLocationChanged(utils.getRootDirectory(newDataLocation), bucket);
  };

  const dataLocationChanged = async (rootDataLocation, bucket) => {
    const scenarioList = await getScenarioList(bucket, rootDataLocation);

    let scenarioErrorFlag = false;
    let scenarioHelperText = "";
    let newDataLocation = rootDataLocation;

    if (!scenarioList?.includes(widgetForm) && widgetForm) {
      scenarioErrorFlag = true;
      scenarioHelperText = "Invalid scenario for the selected Data Source";
    } else if (widgetForm) {
      //if scenario exists and present in current root level
      newDataLocation = rootDataLocation + "/" + widgetForm;
    }
    //if only root level data is present but not scenario
    else {
      newDataLocation = rootDataLocation;
    }

    const dataObject = await getDataObject(newDataLocation, bucket);
    if (widgetForm.data) {
    } else {
    }
  };

  const getScenarioList = async (bucket, dataLocation) => {
    setTempConfig(utils.getRootDirectory(dataLocation));
    setbucket(bucket);
    const response = await api(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
      "/api/fetch_report_attributes",
      {
        bucket: bucket,
        key: utils.getRootDirectory(dataLocation),
      }
    );
    if (response.status) {
      const data = _.get(response, "data", {});
      if (data.scenarios && data.scenarios.length) {
        // return data.scenarios;
        setWidgetForm(data.scenarios);
      } else {
        setWidgetForm([]);
        setScenariosSelect("");
      }
    } else {
      console.log("sceanrio not found for " + bucket + dataLocation);
      return [];
    }
  };

  const getDataObject = async (dataLocation, bucket) => {
    const input = { key: dataLocation, bucket: bucket };
    const response = await api(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
      "/api/get_ldb_files",
      input
    );

    let dataHelperText = "";
    let dataErrorFlag = false;
    let dataList = [];

    if (response.status) {
      dataList = _.get(response, "data", []);
      let data = widgetForm.data;

      if (data && !dataList.includes(data)) {
        dataHelperText = "Data not present in selected Data Location";
        dataErrorFlag = true;
      }
    }

    return {
      dataList: dataList,
      dataHelperText: dataHelperText,
      dataErrorFlag: dataErrorFlag,
    };
  };

  const handleScenarioChange = (scenario) => {
    if (scenario) {
      setScenariosSelect(scenario);
      setTempConfig(utils.getRootDirectory(tempConfig) + "/" + scenario);
    } else {
      setTempConfig(tempConfig);
    }
  };

  const handlePropInfo = () => {
    let dashboardInfo =
      useGlobalStore.getState().allDashbrdRpts.dashboardReport;
    if (dashboardInfo.dataLocation) {
      setTempConfig(dashboardInfo.dataLocation);
    } else {
      setTempConfig("");
    }
    if (dashboardInfo?.default_scenario) {
      setScenariosSelect(dashboardInfo?.default_scenario);
    }
    setIsPropModalOpen(true);
  };

  const savePropertyInfo = async () => {
    const reportInfo = _.cloneDeep(
      useGlobalStore.getState().allDashbrdRpts.dashboardReport
    );
    setIsPrefModalOpen(false);

    let propRptData = {
      dashboardReport: {
        fileName: dashboardName,
        dataLocation: tempConfig,
        default_scenario: scenariosSelect ? scenariosSelect : "",
        bucket: propbucket,
        projects:
          useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects,
        theme: "light",
        title: dashboardName,
        widgets:
          useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
        variables: useGlobalStore.getState().allDashbrdRpts.dashboardReport
          .variables
          ? useGlobalStore.getState().allDashbrdRpts.dashboardReport
            .variables
          : {}
      },
    };

    useGlobalStore.getState().updateDashboardObject(propRptData);

    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/store_dashbaord_info",
        {
          data: {
            fileName: dashboardName,
            dataLocation: tempConfig,
            default_scenario: scenariosSelect,
            bucket: propbucket,
            theme: "light",
            title: dashboardName,
            projects:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects,
            widgets:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
          },
          user: useConfigStore.getState().authLoginUser,
          projects: useGlobalStore.getState().allDashbrdRpts.dashboardReport
            .projects
            ? useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects
            : [],
          variables: useGlobalStore.getState().allDashbrdRpts.dashboardReport
            .variables
            ? useGlobalStore.getState().allDashbrdRpts.dashboardReport
              .variables
            : {}
        }
      )
      .then((response) => {
        response = response.data;
        // saveConfig();
        if (response.status) {
          toast.info("Property Added to the Dashboard!", {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        } else {
          toast.error(response.message, {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        }
      })
      .catch((error) => {
        toast.error(response.message, {
          position: toast.POSITION.BOTTOM_LEFT,
        });
      });
    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/save_user_config",
        {
          data: {
            fileName: dashboardName,
            dataLocation: tempConfig,
            default_scenario: scenariosSelect,
            bucket: propbucket,
            projects:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects,
            theme: "light",
            title: dashboardName,
            widgets:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
          },
          variables: useGlobalStore.getState().allDashbrdRpts.dashboardReport
          .variables
          ? useGlobalStore.getState().allDashbrdRpts.dashboardReport
            .variables
          : {},
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          console.log(response.success);
        } else {
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        console.log("Failed to reach Server");
      });
  };
  const saveReportInfo = async () => {
    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/store_dashbaord_info",
        {
          data: {
            fileName: dashboardName,
            dataLocation:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport
                ?.dataLocation,
            default_scenario:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport
                ?.default_scenario,
            bucket:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport?.bucket,
            projects:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects,
            theme: "light",
            title: dashboardName,
            widgets:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
            variables: useGlobalStore.getState().allDashbrdRpts.dashboardReport
              .variables
              ? useGlobalStore.getState().allDashbrdRpts.dashboardReport
                .variables
              : {},
          },

          user: useConfigStore.getState().authLoginUser,
          projects: useGlobalStore.getState().allDashbrdRpts.dashboardReport
            .projects
            ? useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects
            : [],
        }
      )
      .then((response) => {
        response = response.data;
        // saveConfig();
        if (response.status) {
          toast.info(response.message, {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        } else {
          toast.error(response.message, {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        }
      })
      .catch((error) => {
        toast.error("Dashboard not saved", {
          position: toast.POSITION.BOTTOM_LEFT,
        });
      });
    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/save_user_config",
        {
          data: {
            fileName: dashboardName,
            dataLocation:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport
                ?.dataLocation,
            default_scenario:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport
                ?.default_scenario,
            bucket:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport?.bucket,
            theme: "light",
            title: dashboardName,
            projects:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects,
            widgets:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
            variables:
              useGlobalStore.getState().allDashbrdRpts.dashboardReport
                .variables,
          },
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          console.log(response.success);
        } else {
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        console.log("Failed to reach Server");
        // });
      });
  };
  const handleWgtLibrary = () => {
    setWidgetLib({ open: true });
  };
  const handleCloseWidgetLib = () => {
    setWidgetLib({ open: false });
  };
  const shareReportInfo = () => {
    setIsModalOpen(true);
  };
  const handleDeleteDashboard = async () => {
    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/delete_dashboard_report",
        {
          user: useConfigStore.getState().authLoginUser,
          file_name: dashboardName,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.status) {
          toast.info(response.message, {
            position: toast.POSITION.BOTTOM_LEFT,
          });

          axios
            .post(
              useConfigStore.getState().configData.rest_server_url +
              "/api/save_user_config",
              {
                data: {
                  fileName: "Untitled-Dashboard",
                  theme: "light",
                  title: "Untitled-Dashboard",
                  widgets: {},
                },
                user: useConfigStore.getState().authLoginUser,
              }
            )
            .then((response) => {
              response = response.data;
              if (response.success) {
                let rptData = {
                  dashboardReport: {
                    fileName: "",
                    config: { expanded: false },
                    widgets: {},
                  },
                };
                useGlobalStore.getState().updateDashboardObject(rptData);
                toast.info(response.message, {
                  position: toast.POSITION.BOTTOM_LEFT,
                });
              } else {
                toast.info(response.message, {
                  position: toast.POSITION.BOTTOM_LEFT,
                });
              }
            })
            .catch((error) => {
              toast.info(error, {
                position: toast.POSITION.BOTTOM_LEFT,
              });
            });
        } else {
          toast.info(response.message, {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        }
      })
      .catch((error) => {
        toast.info(response.error, {
          position: toast.POSITION.BOTTOM_LEFT,
        });
      });
  };
  const handleAddWidgetOpen = () => {
    setOpenAddWidget(true);
  };
  const handleAddDashboard = () => {
    let rptData = {
      dashboardReport: {
        fileName: "Untitled-Dashboard",
        config: { expanded: false },
        widgets: {},
      },
    };
    useGlobalStore.getState().updateDashboardObject(rptData);
    setDashboardName("Untitled-Dashboard");
  };
  const closeAddWidget = () => {
    setOpenAddWidget(false);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleModalClick = (param) => {
    setIsOpen(true);
    if (param) {
      setToggleApi((prevState) => !prevState);
      setParameter(param);
      if (param === "Profile") {
        setAnchorEl(null);
      }
    } else {
      setParameter(param);
    }
  };

  const handleCopyLink = async (textToCopy) => {
    saveReportInfo();

    const stringWithUnderscores = textToCopy.replace(/[\s-]/g, "_");
    const resultString = stringWithUnderscores.toLowerCase();

    let urlPrefix = window.location.href.split("/v1")[0];
    console.log({ resultString });

    let shareReportText;
    if (resultString.includes("published_dashboards/")) {
      shareReportText = `${urlPrefix}/v1/reporturl?reportName=${resultString}`;
    } else {
      shareReportText = `${urlPrefix}/v1/reporturl?reportName=${useConfigStore.getState().authLoginUser
        }/dashboards/${resultString}`;
    }
    try {
      await clipboardCopy(shareReportText);
      console.log("Text copied to clipboard:", shareReportText);
    } catch (err) {
      console.error("Unable to copy text to clipboard:", err);
    }
  };

  const modalStateHandler = (modalState) => setOpenDeleteModal(modalState);

  const handleModalSubmit = (selectedValue) => {
    let shareRptFileName = dashboardName;
    const dashboardObject =
      useGlobalStore.getState().allDashbrdRpts.dashboardReport;
    let shareRptWidgets =
      useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets;
    let reportShareFrom = useConfigStore.getState().authLoginUser;
    const rptDataVariablesCheck =
      dashboardObject.hasOwnProperty("variables") && dashboardObject.variables
        ? dashboardObject.variables
        : {};
    const widgetVariables =
      Object.keys(rptDataVariablesCheck).length > 0
        ? rptDataVariablesCheck
        : {};
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/share_dashboard",
        {
          user: selectedValue,
          file_name: `${shareRptFileName} (from ${reportShareFrom})`,
          report: {
            fileName: `${shareRptFileName} (from ${reportShareFrom})`,
            theme: "light",
            title: `${shareRptFileName} (from ${reportShareFrom})`,
            widgets: shareRptWidgets,
            dataLocation: tempConfig,
            default_scenario: scenariosSelect ? scenariosSelect : "",
            variables: widgetVariables ? widgetVariables : {},
          },
        }
      )
      .then((response) => {
        toast.success("Report Shared with " + selectedValue, {
          position: toast.POSITION.BOTTOM_LEFT,
        });
      })
      .catch((error) => {
        console.error("Error posting data:", error);
        toast.warning("Report Not Shared");
      });
  };

  const drawerWidth = "65px";

  const handleClick = (param) => {
    if (param) {
      setToggleApi((prevState) => !prevState);
      setParameter(param);
    } else {
      setParameter(param);
    }
  };
  useEffect(() => {
    setValue(0);
  }, [isPropModalOpen]);

  const inputClasses = {
    root: {
      backgroundColor: "red",
    },
  };

  const onExportActionClick = () => {
    const divElement = document.getElementById('designDaDashboardContainer');
    divElement.scrollTop = divElement.scrollHeight;
    setOpenExportModal(!openExportModal);
  };
  return (
    <>
      <div id="dashBoardGrid" className={styles.backgroundGrid}>
        <div id="designDaDashboardContainer" className={styles.dashboardParent}>
          <div id="gridHeader" className={styles.gridHeader}>
            <Box
              display="flex"
              justifyContent="space-between"
              flexDirection="row"
            >
              <Box display="flex">
                <Box>
                  <Stack direction={"row"}>
                    <Stack direction={"column"}>
                      <TrendingUp fontSize={"12px"} />
                      <DonutLarge fontSize={"12px"} />
                    </Stack>
                    <Stack direction={"column"}>
                      <BarChartOutlined fontSize={"12px"} />
                      <TableChart fontSize={"12px"} />
                    </Stack>
                  </Stack>
                </Box>
                {typographyItem ? (
                  <Typography
                    display="flex"
                    flexWrap="wrap"
                    alignContent="center"
                    sx={{
                      marginLeft: "15px",
                      color: "black",
                      fontSize: "20px",
                    }}
                    onClick={() => {
                      setTypographyItem(false);
                    }}
                  >
                    {
                      useGlobalStore.getState().allDashbrdRpts.dashboardReport
                        .fileName
                    }
                  </Typography>
                ) : (
                  <Input
                    sx={{
                      marginLeft: "15px",
                      color: "black",
                      fontSize: "20px",
                      width: "270px",
                    }}
                    // variant="h4"
                    value={dashboardName}
                    onChange={(event) => setDashboardName(event.target.value)}
                  />
                )}
              </Box>
              <Button
                variant="outlined"
                onClick={onExportActionClick}
                sx={{ textTransform: "none" }}
              >
                Export to HTML
              </Button>
            </Box>
            <AddWidgets
              open={openAddWidget}
              reportType={constants.dashboardReport}
              handleClose={closeAddWidget}
            />
            <div>
              <ShareReportModal
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSubmit={handleModalSubmit}
                selectedItem={selectedItem}
                mainComponentData={mainComponentData}
                onSelectedItemChange={setSelectedItem}
              />
            </div>
          </div>
          <ExportToHTMLModal
            open={openExportModal}
            onCloseExportDialog={onExportActionClick}
            interestedElementRef={dashboardContainerRef}
            fileName="Dashboard"
          />
          <>
            <Modal
              open={isPropModalOpen}
              onClose={() => setIsPropModalOpen(false)}
            >
              <Box className={styles.propertyModal}>
                <div className={styles.modalHeading}>
                  <Typography className={styles.modalHeadingText}>
                    Property
                  </Typography>
                  <div>
                    <CloseRoundedIcon
                      onClick={() => setIsPropModalOpen(false)}
                      className={styles.closeIcon}
                    />
                  </div>
                </div>
                <Box className={styles.tabs}>
                  <StyledTabs
                    value={value}
                    onChange={handleChange}
                    initialSelectedIndex={value}
                  >
                    <StyledTab
                      value={0}
                      onClick={() => handleClick("default")}
                      label="Set Default Data Location"
                      {...a11yProps(0)}
                      style={{ textTransform: "capitalize" }}
                    />
                    <StyledTab
                      value={1}
                      onClick={() => handleClick("publish")}
                      label="Publish Projects"
                      {...a11yProps(1)}
                      style={{ textTransform: "capitalize" }}
                    />
                    <StyledTab
                      value={2}
                      onClick={() => handleClick("declare")}
                      label="Declare Variables"
                      {...a11yProps(2)}
                      style={{ textTransform: "capitalize" }}
                    />
                  </StyledTabs>
                </Box>
                <CustomTabPanel
                  value={value}
                  index={0}
                  className={styles.customTab1}
                >
                  <div className={styles.tab1Flex}>
                    <Typography className={styles.defaultLocation}>
                      Set Your Default Data Locations
                    </Typography>
                    <Box className={styles.addLocation}>
                      <AddIcon
                        className={styles.addIcon}
                        onClick={() => setShowDataSource(true)}
                      />
                      <Typography
                        className={styles.addText}
                        onClick={() => setShowDataSource(true)}
                      >
                        Add Default Data Location
                      </Typography>
                    </Box>
                  </div>
                  <Box className={styles.flex}>
                    <Box className={styles.defaultLocationSource}>
                      <Box
                        className={styles.boxDefaultLocation}
                        onClick={() => setShowDataSource(true)}
                      >
                        Default Data Source
                      </Box>
                      <Tooltip title={tempConfig} arrow>
                        <Typography className={styles.defaultLocationText}>
                          {tempConfig}
                        </Typography>
                      </Tooltip>
                    </Box>

                    {showDataSource ? (
                      <ClickAwayListener
                        onClickAway={() => {
                          setShowDataSource(false);
                        }}
                      >
                        <Box className={styles.dataSource}>
                          <DataSource
                            dataLocationChanged={handleDataLocationChange}
                            dataLocation={tempConfig.dataLocation}
                            close={() => {
                              setShowDataSource(false);
                            }}
                          />
                        </Box>
                      </ClickAwayListener>
                    ) : null}
                  </Box>

                  <Box>
                    <Box className={styles.defaultScenarioText}>
                      Default Scenario is
                    </Box>
                    <Autocomplete
                      id="scenario-input"
                      style={{ marginTop: "2px" }}
                      value={scenariosSelect}
                      onChange={(event, newValue) => {
                        handleScenarioChange(newValue);
                      }}
                      size="small"
                      options={widgetForm}
                      renderOption={(props, option) => (
                        <li key={option} {...props}>
                          <Typography style={{ fontSize: "0.75rem" }}>
                            {option}
                          </Typography>
                        </li>
                      )}
                      getOptionLabel={(option) => {
                        if (option.includes("#")) {
                          let opt = option.split("#");
                          return opt[1];
                        } else return option;
                      }}
                      fullWidth
                      renderInput={(params) => (
                        <StyledTextField
                          {...params}
                          error={tempConfig.scenarioErrorFlag}
                          helperText={tempConfig.scenarioHelperText}
                          label="Default Scenario"
                          fullWidth
                          variant="outlined"
                          InputLabelProps={{
                            sx: {
                              fontSize: "0.75rem",
                              [`&.${inputLabelClasses.shrink}`]: {
                                background: "white",
                              },
                            },
                          }}
                        />
                      )}
                    />
                  </Box>
                  <Box className={styles.dataSourceFooter}>
                    <b>Default Data Source is :</b>
                    <Tooltip title={tempConfig} arrow>
                      <p className={styles.dataSourceFooterText}>
                        {tempConfig}
                      </p>
                    </Tooltip>
                  </Box>
                  <div className={styles.button}>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={savePropertyInfo}
                      className={styles.saveButton}
                    >
                      Save{" "}
                    </Button>
                  </div>
                </CustomTabPanel>
                <CustomTabPanel
                  value={value}
                  index={1}
                  className={styles.customTab2}
                >
                  <PublishComponent
                    reportInfo={
                      useGlobalStore.getState().allDashbrdRpts.dashboardReport
                    }
                    publishProjectList={publishProjectList}
                    dashboardName={dashboardName}
                    saveReportInfo={saveReportInfo}
                  />
                </CustomTabPanel>

                {/* <CustomTabPanel
                  value={value}
                  index={2}
                  className={styles.customTab2}
                >
                  <VariableComponent
                    reportInfo={
                      useGlobalStore.getState().allDashbrdRpts.dashboardReport
                    }
                    dashboardName={dashboardName}
                    saveReportInfo={saveReportInfo}
                  />
                </CustomTabPanel> */}
              </Box>
            </Modal>
          </>

          {allDashbrdRpts[constants.dashboardReport].hasOwnProperty(
            "widgets"
          ) &&
            Object.keys(allDashbrdRpts[constants.dashboardReport]?.widgets)
              .length == 0 ? (
            <Box
              sx={{
                justifyContent: "center",
                backgroundColor: theme == "light" ? "white" : "rgb(30,30,30)",
                display: "flex",
                position: "relative",
                height: "70vh",
              }}
            >
              <Box
                sx={{ position: "relative", top: "auto", left: "auto" }}
              ></Box>
            </Box>
          ) : (
            <ReactGridLayout
              ref={dashboardContainerRef}
              className={styles.grid}
              style={{
                backgroundColor: theme == "light" ? "white" : "rgb(30,30,30)",
              }}
              rowHeight={30}
              cols={24}
              draggableHandle={".draggable"}
              draggableCancel={".non-draggable"}
              onLayoutChange={onLayoutChange}
              resizeHandle={
                <div className={styles.main}>
                  <div
                    className={styles.quarter + " " + styles.quarter4}
                    style={{
                      backgroundColor: theme == "light" ? "grey" : "white",
                    }}
                  ></div>
                  <div
                    className={styles.cutout}
                    style={{
                      backgroundColor:
                        theme == "light" ? "white" : "rgb(18,18,18)",
                    }}
                  ></div>
                </div>
              }
              layout={getLayout()}
            >
              {_.map(
                allDashbrdRpts[constants.dashboardReport].widgets,
                (widget) => getWidget(widget)
              )}
            </ReactGridLayout>
          )}
          {/* </Collapse> */}
          <Box sx={{ justifyContent: "center", padding: "auto" }}>
            <Typography
              sx={{
                // margin: "auto",
                width: "fit-content",
                color: "white",
                fontSize: "20px",
              }}
            >
              DD
            </Typography>{" "}
          </Box>
        </div>

        <Box sx={{ display: "flex", width: "fit-content" }}>
          <Drawer
            sx={{
              width: drawerWidth,
              // flexShrink: 0,
              "& .MuiDrawer-paper": {
                width: drawerWidth,
                backgroundColor: "#E7D9F3",
                marginTop: "64px",
                height: "100%",
              },
            }}
            variant="permanent"
            anchor="right"
          >
            <Divider />

            <Tooltip placement="left" title="Add a New Dashboard">
              <IconButton
                onClick={handleAddDashboard}
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_Add_New_Dashboard_7.svg`}
                  alt="New Dashboard"
                />
                <Typography fontSize={10}>New</Typography>
              </IconButton>
            </Tooltip>

            <Divider />

            <Tooltip placement="left" title="Open a saved Dashboards">
              <IconButton
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
                onClick={() => handleModalClick("SavDash")}
              >
                <Badge
                  badgeContent={_.get(
                    dashboardRightPane,
                    "savedDashbrdCount",
                    0
                  )}
                  sx={{
                    "& .MuiBadge-badge": {
                      fontSize: "10px",
                      height: "auto",
                      padding: "2px 0px",
                      backgroundColor: "yellowgreen",
                    },
                  }}
                >
                  <img
                    width="30px"
                    // src={`${imageUrl}/IC_Save_Dashboard_7.svg`}
                    alt="Saved Dashboards"
                  />
                </Badge>
                <Typography fontSize={10}>Saved</Typography>
              </IconButton>
            </Tooltip>

            <Divider />
            <Tooltip
              placement="left"
              title="Collection of pre configured widgets"
            >
              <IconButton
                onClick={handleWgtLibrary}
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_Widget_Library_7.svg`}
                  alt="Widget Library"
                />
                <Typography fontSize={10}>Widget Library</Typography>
              </IconButton>
            </Tooltip>

            <Divider />

            <Tooltip
              placement="left"
              title="Add a new widget at the top of the dashboard"
            >
              <IconButton
                onClick={handleAddWidgetOpen}
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_AddWidget_7.svg`}
                  alt="Add Widget"
                />
                <Typography fontSize={10}>Add Widget</Typography>
              </IconButton>
            </Tooltip>

            <Divider />

            <Tooltip
              placement="left"
              title="Configure dashboard variables,  data location and publish dashboard to project members"
            >
              <IconButton
                onClick={handlePropInfo}
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_Dashboard_Properties_7.svg`}
                  alt="Property"
                />
                <Typography fontSize={10}>Property</Typography>
              </IconButton>
            </Tooltip>
            <Divider />

            <Tooltip placement="left" title="Save the dashboard">
              <IconButton
                onClick={saveReportInfo}
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_Save_7.svg`}
                  alt="Save"
                />
                <Typography fontSize={10}>Save</Typography>
              </IconButton>
            </Tooltip>

            <Divider />

            <Tooltip placement="left" title="Delete the dashboard">
              <IconButton
                onClick={() => modalStateHandler(true)}
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_Delete_7.svg`}
                  alt="Delete"
                />
                <Typography fontSize={10}>Delete</Typography>
              </IconButton>
            </Tooltip>
            {openDeleteModal ? (
              <DeleteDashboard
                dashboardfileName={dashboardName}
                modalStateHandler={modalStateHandler}
                modalState={openDeleteModal}
              />
            ) : (
              <></>
            )}

            <Divider />

            <Tooltip
              placement="left"
              title="Share dashboard with your team members"
            >
              <IconButton
                onClick={shareReportInfo}
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_Share_7.svg`}
                  alt="Share"
                />
                <Typography fontSize={10}>Share</Typography>
              </IconButton>
            </Tooltip>
            <Divider />
            <Tooltip placement="left" title="Copy Link of the dashboard">
              <IconButton
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
                onClick={() => handleCopyLink(dashboardName)}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_copylink_7.svg`}
                  alt="Copy Link"
                />
                <Typography fontSize={10}>Copy Link</Typography>
              </IconButton>
            </Tooltip>

            <Tooltip
              placement="left"
              title="Refresh all widgets of the dashboard"
            >
              <IconButton
                sx={{
                  "&:hover": {
                    backgroundColor: "transparent",
                  },
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  p: "2px 0px",
                }}
                onClick={() => {
                  handleRefreshDashboard();
                }}
              >
                <img
                  width="30px"
                  // src={`${imageUrl}/IC_Refresh_7.svg`}
                  alt="Refresh"
                />
                <Typography fontSize={10}>Refresh</Typography>
              </IconButton>
            </Tooltip>
          </Drawer>
        </Box>

        {/* drawer of dashboard-widget-library */}
        {widgetLib.open ? (
          <Drawer
            open={widgetLib.open}
            variant="persistent"
            anchor="right"
            sx={{
              width: 780,
              flexShrink: 0,
              "& .MuiDrawer-paper": {
                width: 780,
                boxSizing: "border-box",
              },
            }}
          >
            <AppBar sx={{ position: "relative", backgroundColor: "#5a2a82" }}>
              <Toolbar>
                <IconButton
                  edge="start"
                  color="inherit"
                  onClick={handleCloseWidgetLib}
                  aria-label="close"
                >
                  <ChevronRightIcon color="inherit" />
                </IconButton>
                <Typography>Widget Library</Typography>
              </Toolbar>
            </AppBar>
            <Box>
              <WidgetLibManager parent="dashboard" />
            </Box>
          </Drawer>
        ) : null}
        {/* <Dialog
          fullScreen
          open={widgetLib.open}
          onClose={handleCloseWidgetLib}
          TransitionComponent={Transition}
          // PaperComponent={PaperComponent}
          // aria-labelledby="draggable-dialog-title"

        >
           <DialogTitle style={{ cursor: 'move' }} id="draggable-dialog-title">
            Subscribe
          </DialogTitle> 
        
          <AppBar sx={{ position: "relative", backgroundColor: "#5a2a82" }}>
            <Toolbar>
              <IconButton
                edge="start"
                color="inherit"
                onClick={handleCloseWidgetLib}
                aria-label="close"
              >
                <CloseIcon color="inherit" />
              </IconButton>
              <Typography sx={{ flexGrow: 1 }}>Widget Library</Typography>
            </Toolbar>
          </AppBar>
          <Box>
            <WidgetLibManager parent="dashboard" />
          </Box>
        </Dialog> */}
        <>
          <div>
            <ModalComponent
              isOpen={isOpen}
              onClose={() => setIsOpen(false)}
              param={parameter}
              toggleApi={toggleApi}
            // searchString={formattedValue}
            />
          </div>
        </>
      </div>
      <>
        <div style={{ position: "relative" }}>
          <div
            style={{
              display: "flex",
              position: "absolute",
              top: 0,
              left: 0,
              justifyContent: "center",
              alignItems: "center",
              width: "100%",
              height: "100%",
            }}
          >
            {defaultload && <CircularProgress color="primary" />}
          </div>
        </div>
      </>
    </>
  );
};

export default Dashboard;
