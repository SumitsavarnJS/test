import React, { useState, useEffect } from 'react';
import { Chip, Button } from '@mui/material';
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Checkbox,{ checkboxClasses } from '@mui/material/Checkbox';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Typography from "@mui/material/Typography";
import Grid from '@mui/material/Grid';
import styles from "./Dashboard.module.css"

// import { getProjects, getSelectedProjects, saveSelectedProjects } from 'api'; // replace with your actual API functions

const ProjectChipsComponent = ({ reportInfo, publishProjectList, dashboardName, saveReportInfo }) => {
  const [projects, setProjects] = useState([]);
  const [selectedProjects, setSelectedProjects] = useState([]);
  const { configData, authLoginUser, theme, setRootLevelData } =
    useConfigStore();

  useEffect(() => {
    // Load projects from the API on component mount
    const loadProjects = async () => {
      try {
        const response = await axios.post(
          configData.rest_server_url + "/api/fetch_buckets",
          {
            user: authLoginUser,
          }
        );
        setProjects(response.data.data);


        if (useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects) {
          setSelectedProjects(useGlobalStore.getState().allDashbrdRpts.dashboardReport.projects);
        }
      } catch (error) {
        console.error("Error fetching items:", error);
      }


    };

    loadProjects();
  }, []);
  const handleChipClicks=(event)=>{
    event.preventDefault();
    event.stopPropagation();
    const linkVal = event.currentTarget.getAttribute("valueId");
    if(linkVal==='all'){
      const isSelected = selectedProjects===projects;
      const updatedSelectedProjects=isSelected?[]:projects
      setSelectedProjects(updatedSelectedProjects);
    }
    else{
      const isSelected = selectedProjects.includes(linkVal);
      const updatedSelectedProjects = isSelected
        ? selectedProjects.filter(id => id !== linkVal)
        : [...selectedProjects, linkVal];
      setSelectedProjects(updatedSelectedProjects);
    }
  }

  const handleSave = async () => {


    const reportInfo = _.cloneDeep(
      useGlobalStore.getState().allDashbrdRpts.dashboardReport
    );

    let propRptData = {
      dashboardReport: {
        fileName: dashboardName,
        dataLocation: reportInfo.dataLocation ? reportInfo.dataLocation : '',
        default_scenario: reportInfo.default_scenario ? reportInfo.default_scenario : '',
        bucket: reportInfo.bucket ? reportInfo.bucket : '',
        projects: selectedProjects ? selectedProjects : '',
        variables:reportInfo.variables? reportInfo.variables:{},
        theme: "light",
        title: dashboardName,
        widgets: useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
      },
      projects: selectedProjects ? selectedProjects : '',
      user: useConfigStore.getState().authLoginUser,
    };
    useGlobalStore.getState().updateDashboardObject(propRptData);
    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/publish_dashboard",
        {
          data: propRptData.dashboardReport,
          projects: selectedProjects ? selectedProjects : '',
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;

        if (response.status) {
          //API Call to Save the Latest Changes in Current and Saved Dashboard
          saveReportInfo()
          toast.info(response.message, {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        } else {
          let modPropRptData = {
            dashboardReport: {
              fileName: dashboardName,
              dataLocation: reportInfo.dataLocation ? reportInfo.dataLocation : '',
              default_scenario: reportInfo.default_scenario ? reportInfo.default_scenario : '',
              bucket: reportInfo.bucket ? reportInfo.bucket : '',
              projects: '',
              theme: "light",
              title: dashboardName,
              widgets: useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets,
            },
            projects: '',
            user: useConfigStore.getState().authLoginUser,
          };

          useGlobalStore.getState().updateDashboardObject(modPropRptData);

          toast.error(response.message, {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        }
      })
      .catch((error) => {
        console.log("Failed to reach Server");
        toast.error(error, {
          position: toast.POSITION.BOTTOM_LEFT,
        });
      })
  };

  return (
    <div>
      <Typography className={styles.publishHeading}>
          Select the Projects to Publish
      </Typography>

      <FormGroup className={styles.publishFormGroup}>
        <FormControlLabel 
          value="all" 
          valueId="all"
          control={<Checkbox sx={{color: "dcdfe6",}} size="small" checked={selectedProjects===projects}/>} 
          label={<span style={{ fontSize: '0.8rem' }}>Select all Projects</span>}
          onClick={handleChipClicks}
          
          />
          
      </FormGroup>  
      <Box className={styles.boxGrid}>
        <Grid container spacing={2}>
          {projects.map(project => (
            <Grid item lg={3} spacing={2} sx={{width:"13vw"}}>
              <FormControlLabel
                  value={project}
                  valueId={project}
                  control={<Checkbox checked={selectedProjects.includes(project)} 
                                      sx={{color: "dcdfe6"}} 
                                      size="small"/>
                          }
                  label={project}
                  labelPlacement="end"
                  onClick={handleChipClicks}
                  sx={{
                    
                      border:selectedProjects.includes(project)?"2px solid #5a2a82":"1px solid #dcdfe6",
                      width:"100%",
                      '& .MuiFormControlLabel-label': 
                        { fontSize:'0.8rem',color:selectedProjects.includes(project)?"#5a2a82":"black",
                          fontWeight:selectedProjects.includes(project)?"600":"500",textTransform:"capitalize"
                        }}}
              />
          </Grid>
        ))}
          
      </Grid>
    </Box>    
    <div className={styles.publishbutton}>
      <Button
        variant="contained"
        color="primary"
        onClick={handleSave}
        className={styles.publishSave}
      >
        Publish{" "}
      </Button>
    </div>
    </div>
  );
};

export default ProjectChipsComponent;
