import React, { useState } from "react";
import { toast } from "react-toastify";
import CryptoJS from "crypto-js";
import { makeFixedPostRequest } from "../../common/api/getDefaultDashApi";
import CircularProgress from "@mui/material/CircularProgress";
import { Box, TextField } from "@mui/material";
import styles from "./login.module.css";
import axios from "axios";
import { useRouter } from "next/router";
import getConfig from "next/config";
import useConfigStore from "../../store/useConfigStore";
import SignInButton from "../../components/msal-signin/SignInComponent";
import { useMsal } from "@azure/msal-react";
const { publicRuntimeConfig } = getConfig();
const imageUrl = publicRuntimeConfig.basePath;

export const dashboardCheck = async () => {
  try {
    const reportResponse = await axios.post(
      useConfigStore.getState().configData.rest_server_url + "/api/get_dashboards",
      {
        user: useConfigStore.getState().authLoginUser,
      }
    );
    const response = reportResponse.data?.local_dashboards;
    let defaultDashboardsExists = response.some((path) =>
      path.endsWith("/default_dashboard.json")
    );
    if (!defaultDashboardsExists) {
      //Create and save default dashboard as current dashboard
      const responseDash = await makeFixedPostRequest([1, 2]);
      // Handle the response data as needed
    } else {
      console.log("User LoggedIn");
    }
  } catch (error) {
    console.log(error);
  }
};

const LoginForm = (props) => {
  const {
    configData,
    setAuth,
    setAuthUserVal,
    setUserLicenseId,
    setAdminFlag,
  } = useConfigStore();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const iv = CryptoJS.lib.WordArray.random(16);
  const key = CryptoJS.enc.Base64.parse("sP1i7EefwlPNVkvTHwfs3x==");
  const encrypted = CryptoJS.AES.encrypt(password, key, { iv: iv });
  const joinedData = iv.clone().concat(encrypted.ciphertext); // Concat IV and Ciphertext
  const joinedDataB64 = CryptoJS.enc.Base64.stringify(joinedData);

  // Create Default Dashboard on first login/ in its non-existence
 


  const {instance, accounts} = useMsal()

  function handleLogin(e) {
    e.preventDefault();
    e.stopPropagation()
    setLoading(true);
    const user = email;
    axios
      .post(`${configData.rest_server_url}/api/user_manager/login`, {
        userName: user,
        userPwd: joinedDataB64,
      })
      .then((response) => {
        // check response for success or failure
        if (response.data.success) {
          setAdminFlag(_.get(response.data, "is_pm", false));
          axios
            .post(`${configData.rest_server_url}/license/licenseRequest/`, {
              userName: email,
              featureList: "DDash-Base",
              comment: "Login license",
            })
            .then((response) => {
              if (response.data.success === true) {
                try {
                  setAuth(true);
                  setAuthUserVal(email);
                  setUserLicenseId(response.data.licenseId);
                  // router.push("/"); // or redirect to any other page
                  dashboardCheck();

                  toast.info(response.data.message, {
                    position: toast.POSITION.BOTTOM_LEFT,

                    style: {
                      fontSize: "14px",
                      padding: "8px  12px",
                    },
                  });
                } catch (e) {
                  console.group(e);
                } finally {
                  setLoading(false);
                }
              } else {
                setLoading(false);
                toast.info(response.data.message, {
                  position: toast.POSITION.BOTTOM_LEFT,

                  style: {
                    fontSize: "14px",
                    padding: "8px  12px",
                  },
                });
              }
            });
        } else {
          // login failed
          setLoading(false);
          toast.error(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
          setAuth(false);
          setAuthUserVal("");
        }
      })
      .catch((error) => {
        console.log(error);
        toast.error("Api Request Timed Out", {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
        setAuth(false);
        setAuthUserVal("");
        setLoading(false);
      });
  }
  

  return (
    <div
      style={{
        width: "40vw",
        position: "absolute",
        top: "44%",
        left: "50%",
        transform: "translate(-50%, -50%)",
      }}
    >
      <Box className={styles.dd_outer}>
        <div>
          <form className={styles.dd_Form}>
            <div className={styles.dd_logo_img}>
              <span>
                <img
                  src={`${imageUrl}/New_Sign_in_Logo_7.svg`}
                  alt="DesignDash"
                />
              </span>
            </div>

            <div id="title_heading">
              <p className={styles.dd_Para_p}>Sign In</p>
              <p className={styles.dd_app_p}> {configData.app_version}</p>
            </div>

            <div style={{ marginBottom: "2vh" }}>
              <TextField
                label="Username"
                fullWidth
                className={styles.placeholder}
                margin="normal"
                type="text"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                borderRadius="10px"
              />
            </div>

            <TextField
              label="Password"
              fontFamily="Montserrat"
              className={styles.placeholder}
              fullWidth
              margin="normal"
              type="password"
              onChange={(e) => setPassword(e.target.value)}
              required
              borderRadius="10px"
              value={password}
            />

            <div>
              <button
                type="submit"
                className={styles.loginBtn}
                onClick={handleLogin}
                disabled={loading}
              >
                {loading ? (
                  <CircularProgress
                    size={24}
                    className={styles.loginBtnLoader}
                  />
                ) : (
                  "Login"
                )}
              </button>
            </div>
          </form>
          { Object.hasOwn(configData, 'sso_azure') && <SignInButton />}</div>
      </Box>
    </div>
  );
};

export default LoginForm;
