import React, { useState, useEffect } from "react";
import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import { styled } from "@mui/material/styles";

import LoginForm from "../Login/Loginform";
// import ComputeStorage from "../api/ComputeStorage";
// import Counter from "../counter";
import useConfigStore from "../../store/useConfigStore";
import Head from "next/head" 

// import YouTube from "react-youtube";

import getConfig from "next/config";
const { publicRuntimeConfig } = getConfig();
const imageUrl = publicRuntimeConfig.basePath;

const Item = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  textAlign: "center",
  flexGrow: 1,
}));
const Topbar = () => {
  return (
    <div>
      <img
        style={{
          float: "left",
          marginLeft: "-20px",
          height: "4em",
        }}
        src={`${imageUrl}/Synopsyslogo.png`}
        alt="design.da"
      />
    </div>
  );
};

export default function FlexboxGapStack() {
  const {
    configData,
    setConfigData,
    isAuthenticated,
    setAuth,
    authLoginUser,
    setAuthUserVal,
    theme,
  } = useConfigStore();

  const helpLink = `https://spdocs.synopsys.com/dow_retrieve/latest/dg/design_da/olh_design_da/olh_design_da/landing_page.html`;

  useEffect(() => {
    async function loadConfig() {
      const response = await fetch("/v1/config.json");
      const data = await response.json();
      // setConfig(data);
      setConfigData(data);
      //dispatch(setConfig(data));
    }
    loadConfig();
  }, []);

  return (
    <div style={{ width: "100vw", height: "100vh" }}>
      <Head>
          <title className="text-transparent">design.da</title>
          <meta name="description" content="Update Widgets with Comments" />
          <link rel="icon" href="Tab_icon_BW.svg" />
        </Head>
      <Stack style={{ height: "100%" }} spacing={"1%"} direction={"column"}>
        <Topbar />
        <LoginForm />
      </Stack>
      <Box
        id="footer"
        sx={{
          fontSize: "13px",
          fontFamily: "Montserrat",
          background: "#5a2d84",
          color: "#fff",
          padding: "5px",
          bottom: 0,
          position: "fixed",
          width: "100%",
          left: "0",
        }}
      >
        <div
          style={{
            float: "right",
            textAlign: "right",
            marginRight: "2%",
          }}
        >
          <a href={helpLink} target="_blank" rel="noopener noreferrer">Help</a> | <a href="#">Contact Us</a>
        </div>
        <div>&copy; All rights reserved {new Date().getFullYear()}</div>
      </Box>
    </div>
  );
}
