# Design.Da Web UI


This is a [Next.js](https://nextjs.org/) project.

<br/>

**#Technologies**
<ol>
<li>Next JS 13.3</li>
<li>Zustand</li>
<li>Material UI (mui/material)</li>
</ol>

## Getting Started
First, install the dependencies
```bash
npm i
npm run prepare
```

Second, run the development server:

```bash
npm run dev
# or
yarn dev
```
## ESLint
run ES-Lint on your folder/files using the following command
```bash
eslint {path-to-your-file}
```


