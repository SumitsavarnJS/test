////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/dialogs/AddBuildsPopup.js#13 $
////////////////////////////////////////////////////////////////////////////////

import React from "react";
import { shallow } from "zustand/shallow";
import { useState, useEffect, useRef, memo } from "react";
import { produce } from "immer";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import _ from "lodash";
import axios from "axios";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Switch from "@mui/material/Switch";
import FormControlLabel from "@mui/material/FormControlLabel";
import { styled, lighten, darken } from "@mui/system";
import useGlobalStore from "../../store/useGlobalStore";
import styles from "../../pages/metrics/dialogs/AddBuildPopup.module.css";
import useConfigStore from "../../store/useConfigStore";
import dynamic from "next/dynamic";
import Popup from "reactjs-popup";
import PreviewBuildSelection from "../../pages/metrics/dialogs//PreviewBuildSelection";
import FormatPopup from "../../pages/metrics/dialogs/FormatPopup";
import refreshWidgetContent from "../../pages/rptdashboard/wigetWrapper/widgetRefreshData";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";
import {
  customInput,
  customFilter,
  timeFilter,
  dateFromSeconds,
} from "../../common/filter";
import {
  customFilterDisplayValueTooltip,
  timeFilterTooltip,
} from "../../common/tooltip";

const switchStyle = {
  borderRadius: 2,
  "& .MuiSwitch-switchBase": {
    color: "rgb(91, 44, 132)",
  },
  "& .MuiSwitch-switchBase.Mui-checked": {
    color: "rgb(91, 44, 132)",
  },
  // "& .MuiSwitch-switchBase.Mui-checked+.MuiSwitch-track": {
  //   backgroundColor: 'lightgreen'
  // },
  // "&:hover .MuiSwitch-switchBase": {
  //   color: 'brown'
  // },
};

const AceEditor = dynamic(
  () =>
    import("../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);

const defaultQueryBody = `# Data has been loaded in df variable
# Please modify the df variable as needed for the table view
#  df["__context_menu"] = [
#  {"label" : "Chart-WNS/Checkpoint", "action" : "plot", "args" : {"type": "MultiFeatureBarChart", "Y" : "WNS", "X" : "checkpoints"}},
#  {"label" : "Chart-TNS/Build", "action" : "plot", "args" :  {"type": "MultiFeatureBarChart", "Y" : "TNS", "X" : "builds"}}
#  ]
`;

let shouldComponentUpdate = (prevProps, nextProps) => {
  return false;
};

const AddBuildsPopup = memo(function AddBuildsPopup(props) {
  let [hierSpecSelectedByUser, setHierSpecSelectedByUser] = useState(false);
  let tableRef = React.createRef();
  let [reportFlag, setReportFlag] = useState(true);
  let tableInst = null;
  let [selRows, setSelRows] = useState([]);
  let [titleDirty, setTitleDirty] = useState(false);
  let preview = [];
  let [hidden, setHidden] = useState(true);
  const [checked, setChecked] = useState(true);
  let tableColumns = [];
  let [buildSpecSelectionNote, setBuildSpecSelectionNote] = useState("");
  let [modalEditFormat, setModalEditFormat] = useState(false);
  const metricsURL =
    useConfigStore.getState().configData.rest_server_url + "/metrics/";
  const reportFallback = {
    "Please select a report": {
      reportInfo: {
        menuGroup: "",
        menuName: "",
        reportClass: " ",
      },
    },
  };
  const { metricProjectName, setMetricProjectName } = useConfigStore();
  const { data, uiState, updateConfig, setWidgetUiState } = useGlobalStore(
    (state) => ({
      data: state[props.id] ? state[props.id].data : {},
      uiState: state[props.id]
        ? state[props.id].uiState
        : {
          isLoading: false,
          showConfig: false,
          isToastOpen: false,
          toastSeverity: "info",
          toastMessage: "",
          cirlularLoading: false,
        },
      updateConfig: state.updateConfig,
      // setWidgetUiState: state.setWidgetUiState,
    }),
    shallow
  );

  let orgMode = () => {
    console.log(props.config.orgMode);
    return props.config?.orgMode;
  };

  let displayMode = () => {
    console.log(props.config.displayMode);
    return props.config?.displayMode;
  };

  let useMetricRefMode = () => {
    console.log(props.config?.useMetricRefMode);
    return props.config?.useMetricRefMode;
  };

  let hierBlockMode = () => {
    console.log(props.config?.hierBlockMode);
    return props.config?.hierBlockMode;
  };

  let hierBuildMode = () => {
    console.log(props.config?.hierBuildMode);
    return props.config?.hierBuildMode;
  };

  let handleAcceptEditFormat = (reportFormatData) => {
    handleConfigSettings(reportFormatData);
    setModalEditFormat(false);
  };

  let dateFormatter = (cell, formatterParams, onRendered) => {
    let seconds = cell.getValue();
    return dateFromSeconds(seconds);
  };
  let persistenceSerialized =
    typeof window !== "undefined"
      ? localStorage.getItem(`addBuilds${props.id}`)
      : null;
  let persistence = persistenceSerialized
    ? JSON.parse(persistenceSerialized)
    : { sort: [] };

  const getPersistSort = (col) => {
    const filteredSort = persistence.sort.filter(
      (column) => column.field == col
    );
    if (filteredSort.length) {
      return filteredSort[0].dir;
    }
    return "";
  };
  // tableColumns.push({ formatter: "rowSelection", width: 100, titleFormatter: "rowSelection", align: "center", headerSort: false })
  tableColumns.push({
    title: "Project",
    field: "PROJECT",
    sorter: "string",
    headerSort: true,
    headerSortTristate: true,
    headerFilter: customInput,
    headerSortStartingDir: getPersistSort("PROJECT"),
    // headerFilterFunc: customFilter,
    headerTooltip: "Support RegEx Filtering",
  });
  tableColumns.push({
    title: "Phase",
    field: "PHASE",
    sorter: "string",
    headerSort: true,
    headerSortTristate: true,
    headerFilter: customInput,
    headerSortStartingDir: getPersistSort("PHASE"),
    // headerFilterFunc: customFilter,
    headerTooltip: "Support RegEx Filtering",
  });
  tableColumns.push({
    title: "Run Tag",
    field: "RUNTAG",
    sorter: "string",
    headerSort: true,
    headerSortTristate: true,
    headerFilter: customInput,
    headerSortStartingDir: getPersistSort("RUNTAG"),
    // headerFilterFunc: customFilter,
    headerTooltip: "Support RegEx Filtering",
  });
  tableColumns.push({
    title: "Block",
    field: "BLOCK",
    sorter: "string",
    headerSort: true,
    headerSortTristate: true,
    headerFilter: customInput,
    // headerSortStartingDir: getPersistSort("BLOCK"),
    // headerFilterFunc: customFilter,
    headerTooltip: "Support RegEx Filtering",
  });
  tableColumns.push({
    title: "User",
    field: "USER",
    sorter: "string",
    headerSort: true,
    headerSortTristate: true,
    headerFilter: customInput,
    // headerSortStartingDir: getPersistSort("USER"),
    // headerFilterFunc: customFilter,
    headerTooltip: "Support RegEx Filtering",
  });
  tableColumns.push({
    title: "User Label",
    field: "LABEL",
    sorter: "string",
    headerSort: true,
    headerSortTristate: true,
    headerFilter: customInput,
    // headerSortStartingDir: getPersistSort("LABEL"),
    // headerFilterFunc: customFilter,
    headerTooltip: "Support RegEx Filtering",
  });
  tableColumns.push({
    title: "Checkpoint",
    field: "checkpoint",
    headerSort: true,
    // sorter: "string",
    // headerSortTristate: true,
    // headerSortStartingDir: getPersistSort("checkpoint"),
    headerFilter: customInput,
    // headerFilterEmptyCheck: function (value) {
    //   return !value; //only filter when the value is true
    // },
    // headerFilterFunc: (headerValue, rowValue, rowData, filterParams) => {
    //   return filterTree(headerValue, rowValue, rowData, filterParams);
    // },
  });

  tableColumns.push({
    title: "Time Start",
    field: "timeStart",
    sorter: "string",
    headerSort: true,
    // headerSortStartingDir: getPersistSort("timeStart"),
    sorterParams: {
      format: "yyyy-MM-dd HH:mm:ss",
      alignEmptyValues: "top",
    },
    // headerFilter: customInput,
    // headerFilterFunc: timeFilter,
    // headerTooltip: timeFilterTooltip,
    formatter: dateFormatter,
    // formatter: function (cell, formatterParams, onRendered) {
    //   try {
    //     let dt = DateTime.fromSeconds(cell.getValue());
    //     return dt.toFormat(formatterParams.outputFormat);
    //   } catch (error) {
    //     console.log(error);
    //     return formatterParams.invalidPlaceholder;
    //   }
    // },
    // formatterParams: {
    //   outputFormat: "yyyy-MM-dd HH:mm:ss",
    //   invalidPlaceholder: "(invalid date)",
    // },
    headerSortTristate: true,
    // headerFilter: true,
  });
  tableColumns.push({
    title: "Time Stop",
    field: "timeStop",
    sorter: "string",
    headerSort: true,
    // headerSortStartingDir: getPersistSort("timeStop"),
    // sorterParams: {
    //   format: "yyyy-MM-dd HH:mm:ss",
    //   alignEmptyValues: "top",
    // },
    // headerFilter: customInput,
    // headerFilterFunc: timeFilter,
    // headerTooltip: timeFilterTooltip,
    formatter: dateFormatter,
    // formatter: function (cell, formatterParams, onRendered) {
    //   try {
    //     let dt = luxon.DateTime.fromSeconds(cell.getValue());
    //     return dt.toFormat(formatterParams.outputFormat);
    //   } catch (error) {
    //     console.log(error);
    //     return formatterParams.invalidPlaceholder;
    //   }
    // },
    // formatterParams: {
    //   outputFormat: "yyyy-MM-dd HH:mm:ss",
    //   invalidPlaceholder: "(invalid date)",
    // },
    headerSortTristate: true,
    // headerFilter: true,
  });

  //Custom Filter function for checkpoint
  var filterTree = (headerValue, rowValue, rowData, filterParams) => {
    console.log("Filtering checkpoint");
    if (rowData["_children"] && rowData["_children"].length > 0) {
      for (var i in rowData["_children"]) {
        return (
          customFilter(headerValue, rowData["checkpoint"]) ||
          filterTree(headerValue, null, rowData["_children"][i], {})
        );
      }
    }

    return customFilter(headerValue, rowData["checkpoint"]);
  };

  const GroupHeader = styled("div")(({ theme }) => ({
    position: "sticky",
    top: "-8px",
    padding: "4px 10px",
    color: "black",
    fontWeight: "700",
    backgroundColor:
      theme.palette.mode === "light"
        ? lighten("rgb(244, 208, 63)", 0.85)
        : darken(theme.palette.primary.main, 0.8),
  }));

  const GroupItems = styled("ul")({
    padding: 0,
  });

  let createListOfReportSpecAndHierSpec = (reportSpecs) => {
    let repSpecList = [];
    let hierSpecList = [];
    Object.keys(reportSpecs["Users"]).forEach(function (key) {
      // console.log(key + " " + reportSpecs["Users"][key]);
      for (let rep of reportSpecs["Users"][key]) {
        if (rep.specType == "report_spec") {
          let specName = rep.specName;
          let newSpecName = specName;
          rep["specName"] = newSpecName;
          // console.log(rep);
          repSpecList.push(rep);
        } else if (rep.specType == "hier_spec") {
          let specName = rep.specName;
          let newSpecName = specName;
          rep["specName"] = newSpecName;
          // console.log(rep);
          hierSpecList.push(rep);
        }
      }
    });
    handleConfigSettings({
      reportSpecList: repSpecList,
      hierSpecList: hierSpecList,
    });
    // setReportSpecs(specList)
  };

  let afterTableBuilt = () => {
    // let ret = formatSelectedBuilds(selRows);
    let selectedRows = [];
    try {
      selectedRows = localStorage.getItem(props.id)
        ? JSON.parse(localStorage.getItem(props.id))
        : [];
    } catch (err) {
      selectedRows = [];
      console.log(err);
    }
    // console.log(selectedRows, props.config);
    let buildSpec =
      selectedRows.length > 0 ? selectedRows : props.config.buildSpec;
    if (buildSpec != undefined && buildSpec.length > 0) {
      for (let selRow of buildSpec) {
        var cloned = JSON.parse(JSON.stringify(selRow));
        tableInst.selectRow(
          tableInst.getRows().filter((row) => {
            let temp1 = _.cloneDeep(row.getData());
            // delete temp1.LABEL;
            // delete cloned.LABEL;
            // delete temp1._children;
            // delete cloned._children;
            if (hashBuild(temp1) == hashBuild(cloned)) {
              return true;
            }
            // Selecting child rows
            var children = row.getTreeChildren();
            if (children) {
              tableInst.selectRow(
                children.filter((cRow) => {
                  let temp1 = cRow.getData();
                  // delete temp1.LABEL;
                  // delete cloned.LABEL;
                  if (hashBuild(temp1) == hashBuild(cloned)) {
                    row.getElement().style.borderColor = "rgb(91, 44, 132)";
                    row.getElement().style.borderWidth = "3px";
                    return true;
                  }
                  return false;
                })
              );
            }
          })
        );
      }
    }
  };

  let validateBuildSpecSelection = (rowData, rows) => {
    // if (rows[0] != undefined) {
    //   preview = rowData;
    //   console.log(preview);
    // }
    // console.log(rowData, rows);
    for (let i in rowData) {
      if (!("_children" in rowData) && rows != undefined) {
        let parentRow = rows[i].getTreeParent();
        if (parentRow) {
          console.log("Deselecting");
          parentRow.deselect();
        }
      }
    }
  };

  // let removeDuplicates = (list_of_obj) => {
  //   let jsonObject = list_of_obj.map(JSON.stringify);
  //   let uniqueSet = new Set(jsonObject);
  //   let uniqueArray = Array.from(uniqueSet).map(JSON.parse);

  //   return uniqueArray;
  // };

  function hashBuild(item) {
    return JSON.stringify({
      PROJECT: item.PROJECT,
      PHASE: item.PHASE,
      BLOCK: item.BLOCK,
      USER: item.USER,
      RUNTAG: item.RUNTAG,
      checkpoint: item.checkpoint,
      timeStart: item.timeStart,
      timeStop: item.timeStop,
    });
  }

  function removeDuplicates(arr) {
    const seen = new Set();
    const uniqueArray = [];

    for (const item of arr) {
      const key = hashBuild(item);

      if (!seen.has(key)) {
        seen.add(key);
        uniqueArray.push(item);
      }
    }

    return uniqueArray;
  }

  let objectExistInList = (obj, list_of_obj) => {
    let ret = list_of_obj.map((x) => JSON.stringify(x) === JSON.stringify(obj));
    return ret;
  };

  let rowSelect = (row) => {
    console.log("row", row)
    if (tableInst == null) {
      return;
    }
    let tempSelRow = props.config?.buildSpec
      ? _.cloneDeep(props.config?.buildSpec)
      : [];
    let localSelRowCache = localStorage.getItem(props.id)
      ? JSON.parse(localStorage.getItem(props.id))
      : [];
    if (!_.isEmpty(localSelRowCache)) {
      // Array.prototype.push.apply(tempSelRow, localSelRowCache);
      tempSelRow = localSelRowCache;
    }
    // tempSelRow = removeDuplicates(tempSelRow);
    let r = row.getData();
    if (!objectExistInList(r, tempSelRow).includes(true)) {
      tempSelRow.push(r);
    }
    row.select();
    tempSelRow = removeDuplicates(tempSelRow);
    localStorage.setItem(props.id, JSON.stringify(tempSelRow));
  };

  let rowDeselect = (row) => {
    if (tableInst == null) {
      return;
    }
    let tempSelRow = props.config?.buildSpec
      ? _.cloneDeep(props.config?.buildSpec)
      : [];
    let localSelRowCache = localStorage.getItem(props.id)
      ? JSON.parse(localStorage.getItem(props.id))
      : [];
    if (!_.isEmpty(localSelRowCache)) {
      // Array.prototype.push.apply(tempSelRow, localSelRowCache);
      tempSelRow = localSelRowCache;
    }
    tempSelRow = removeDuplicates(tempSelRow);
    let r = row.getData();
    row.deselect();
    tempSelRow = tempSelRow.filter((x) => hashBuild(x) != hashBuild(r));
    tempSelRow = removeDuplicates(tempSelRow);
    localStorage.setItem(props.id, JSON.stringify(tempSelRow));
  };

  useEffect(() => {
    const initTable = () => {
      // let headerFilters = [{ field: "USER", value: _.get(useConfigStore.getState(), "authLoginUser", "") }];
      if (!tableInst) {
        let defaultsetup = {
          pageNo: 1,
          size: 10,
          filter: [],
          sort: [
            {
              column: "PROJECT",
              dir: "desc",
            },
            { column: "USER", dir: "desc" },
            { column: "BLOCK", dir: "desc" },
            {
              column: "PHASE",
              dir: "desc",
            },
            {
              column: "RUNTAG",
              dir: "desc",
            },
            {
              column: "timeStop",
              dir: "desc",
            },
          ],
        };
        console.log(tableColumns);
        const fetchPersistence = localStorage.getItem(`addBuilds${props.id}`);
        if (fetchPersistence) {
          const oldSetup = JSON.parse(fetchPersistence);
          defaultsetup = {
            pageNo: _.get(oldSetup, "pageNo", 1),
            size: _.get(oldSetup, "size", 10),
            filter: _.get(oldSetup, "filter", []),
            sort: _.get(oldSetup, "sort", [
              {
                column: "PROJECT",
                dir: "desc",
              },
              { column: "USER", dir: "desc" },
              { column: "BLOCK", dir: "desc" },
              {
                column: "PHASE",
                dir: "desc",
              },
              {
                column: "RUNTAG",
                dir: "desc",
              },
              {
                column: "timeStop",
                dir: "desc",
              },
            ]),
          };
          if (defaultsetup.sort.length) {
            for (let i = 0; i < defaultsetup.sort.length; i++) {
              if (defaultsetup.sort[i].hasOwnProperty("field")) {
                defaultsetup.sort[i].column = _.cloneDeep(
                  defaultsetup.sort[i].field
                );
                delete defaultsetup.sort[i].field;
              }
            }
          }
        }
        console.log(defaultsetup.sort);
        tableInst = new Tabulator(tableRef, {
          // className: "table-sm table-striped table-bordered",
          columns: tableColumns,
          layout: "fitDataStretch",
          selectableRows: true,
          initialHeaderFilter: defaultsetup.filter,
          initialSort: defaultsetup.sort,
          pagination: true, //enable pagination
          paginationMode: "remote", //enable remote pagination
          sortMode: "remote",
          height: "500px",
          filterMode: "remote",
          ajaxConfig: "POST",
          paginationSize: defaultsetup.size,
          paginationInitialPage: defaultsetup.pageNo,
          paginationButtonCount: 5,
          ajaxURL: metricsURL + "getBuilds/",
          ajaxContentType: "json",
          ajaxParams: {
            projects: metricProjectName,
          },
          ajaxResponse: (url, params, responseData) => {
            const persistance = {
              pageNo: _.get(params, "page", 1),
              size: _.get(params, "size", 10),
              filter: _.get(params, "filter", []),
              sort: _.get(params, "sort", []),
            };
            localStorage.setItem(
              `addBuilds${props.id}`,
              JSON.stringify(persistance)
            );
            const tabulatorLoreFormat = {
              data: responseData.blds ? responseData.blds : [],
              last_page: responseData.lastPage ? responseData.lastPage : 0,
            };
            return tabulatorLoreFormat;
          },

          dataTree: true,
          dataTreeChildIndent: 25,
          // dataTreeSelectPropagate: true,
          paginationSizeSelector: [10, 15, 20, 25, 50, 100, 200],
          // dataTreeFilter: true,
          dataTreeSort: false, //disable child row sorting
          // groupBy: ["BLOCK"],
          // paginationCounter: "rows",
          // data: rows,
          maxHeight: "1000px",
          movableRows: false,
          columnDefaults: {
            headerFilterPlaceholder: "...",
            headerFilterLiveFilter: false,
            // tooltip: true,
            headerTooltip: true,
          },
        });
        // if (getReportClass() && getReportClass() != "HierTimeDashboardReport") {
        tableInst.on("rowSelectionChanged", validateBuildSpecSelection);
        tableInst.on("rowSelected", rowSelect);
        tableInst.on("rowDeselected", rowDeselect);
        tableInst.on("dataProcessed", afterTableBuilt);
      }
      // } 
      // else {
      //   console.log("replace data");
      //   tableInst.replaceData(rows);
      // }
    };

    initTable();
  });

  // useEffect(() => {
  //   const fetchData = async () => {
  //     axios
  //       // .get(metricsURL+'newGetUsersAndProjects/',)
  //       .get(metricsURL + "getSpecInfo/") // Peeyush new API
  //       .then((response) => {
  //         let status = _.get(response.data, "status", false);
  //         if (status) {
  //           let allSpecs = _.get(response.data, "specInfoObj", []);
  //           createListOfReportSpecAndHierSpec(allSpecs);
  //         } else {
  //           let message = _.get(response.data, "message", "");
  //           console.log(message);
  //         }
  //       })
  //       .catch((error) => {
  //         console.log(error);
  //       });
  //   };

  //   fetchData();
  // }, []);

  const handleConfigSettings = (obj) => {

    const config = props.config;
    // console.log(config);
    const newConfig = produce(config, (configDraft) => {
      Object.entries(obj).forEach(function ([key, value]) {
        configDraft[key] = value;
      });
    });
    // updateConfig(props.rptType, props.reportKey, props.id, newConfig);
  };

  let onQueryChange = (newQuery) => {
    handleConfigSettings({ query: newQuery });
  };

  const setUiState = (load, message, widgetId) => {
    if (!load) {
      const newUiState = produce(uiState, (uiStateDraft) => {
        uiStateDraft.isLoading = false;
        uiStateDraft.showConfig = false;
      });
      // setWidgetUiState(widgetId, newUiState);
    } else if (load) {
      const newUiState = produce(uiState, (uiStateDraft) => {
        uiStateDraft.isLoading = true;
      });
      // setWidgetUiState(widgetId, newUiState);
    } else {
      const newUiState = produce(uiState, (uiStateDraft) => {
        uiStateDraft.isLoading = false;
        uiStateDraft.isToastOpen = true;
        uiStateDraft.toastMessage = message;
        uiStateDraft.toastSeverity = "error";
      });
      // setWidgetUiState(widgetId, newUiState);
    }
  };

  const fetchTableRows = (selBld, baselineBuildFound) => {
    let c = [];
    let r = [];
    setUiState(true, "", props.id);
    let message = "";

    if (!baselineBuildFound) {
      handleConfigSettings({
        buildSpec: selBld,
        baselineBuild: "",
      });
    } else {
      handleConfigSettings({ buildSpec: selBld });
    }
    setUiState(false, "", props.id);
  };

  const fetchDetailTableRows = (selBld, baselineBuildFound) => {
    let keys = [];
    let r = [];
    let message = "";
    setUiState(true, "", props.id);

    axios
      .post(metricsURL + "getDetailReportData/", {
        selectedBuilds: selBld,
        report: props.config?.report,
        auth: {
          user: _.get(useConfigStore.getState(), "authLoginUser", ""),
        },
      })
      .then((response) => {
        let status = _.get(response.data, "status", false);
        if (status) {
          r = _.get(response.data, "rows", []);
          keys = _.get(response.data, "keys", []);
          if (!baselineBuildFound) {
            handleConfigSettings({
              rows: r,
              buildSpec: selBld,
              keys: keys,
              baselineBuild: "",
            });
          } else {
            handleConfigSettings({ rows: r, buildSpec: selBld, keys: keys });
          }
        } else {
          handleConfigSettings({ rows: [], buildSpec: selBld, keys: [] });
          message = _.get(response.data, "message", "");
          console.log(message);
        }
        setUiState(false, message, props.id);
      })
      .catch((error) => {
        console.log(error);
        handleConfigSettings({ buildSpec: selBld });
        setUiState(false, error, props.id);
      });
  };

  let formatSelectedBuilds = (selectedRows) => {
    let selBld = [];
    let baselineBuildFound = false;
    for (let row of selectedRows) {
      // let row = key._row.data;
      if (
        row["PROJECT"] +
        "/" +
        row["USER"] +
        "/" +
        row["BLOCK"] +
        "/" +
        row["PHASE"] +
        "/" +
        row["RUNTAG"] ==
        props.config.baselineBuild
      ) {
        console.log("baseline build exist in buildSpec");
        baselineBuildFound = true;
      }
      if (row["LABEL"] == null) {
        row["LABEL"] = "";
      }
      selBld.push(row);
    }
    return [selBld, baselineBuildFound];
  };

  let onSave = () => {
    try {
      const selectedRows = localStorage.getItem(props.id)
        ? JSON.parse(localStorage.getItem(props.id))
        : [];
      props.metricsBuildSelection(selectedRows)

    } catch (e) {
      console.log(e)
    }
    finally {
      props.handleCloseMetrics()
    }
  };

  // let selectAll = () => {
  //   tableInst.selectRow();
  // }

  let selectAllChildren = () => {
    if (tableInst == null) {
      console.log("null");
      return;
    }
    tableInst.selectRow(
      tableInst.getRows("active").filter((row) => {
        // Selecting child rows
        var children = row.getTreeChildren();
        console.log('HERE')

        if (children) {
          tableInst.selectRow(
            children.filter((cRow) => {
              return true;
            })
          );
        }
      })
    );
  };

  let storeRowToLocalCache = (row) => {
    let tempSelRow = props.config?.buildSpec
      ? _.cloneDeep(props.config?.buildSpec)
      : [];
    let localSelRowCache = localStorage.getItem(props.id)
      ? JSON.parse(localStorage.getItem(props.id))
      : [];
    if (!_.isEmpty(localSelRowCache)) {
      // Array.prototype.push.apply(tempSelRow, localSelRowCache);
      tempSelRow = localSelRowCache;
    }
    // tempSelRow = removeDuplicates(tempSelRow);
    let r = row;
    if (!objectExistInList(r, tempSelRow).includes(true)) {
      tempSelRow.push(r);
    }
    tempSelRow = removeDuplicates(tempSelRow);
    // console.log('tempSelRow', tempSelRow)
    // console.log('row', r);
    localStorage.setItem(props.id, JSON.stringify(tempSelRow));
  };
  // const selectAllParents = () => {
  //   console.log('B')
  // }
  let selectAllParents = () => {
    if (tableInst == null) {
      console.log("null");
      return;
    }
    tableInst.selectRow(
      tableInst.getRows("active").filter((row) => {
        // Selecting Parent rows
        let temp1 = row.getData();
        if (temp1["checkpoint"] == "") {
          return true;
        }
        return false;
      })
    );

    const input = {
      filter: tableInst.getHeaderFilters(),
      projects: metricProjectName,
      paginate: false,
    };
    axios
      .post(metricsURL + "getBuilds/", input)
      .then((response) => {
        if (response.status == 200)
          for (let i = 0; i < response.data.blds.length; i++) {
            storeRowToLocalCache(response.data.blds[i]);
          }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  let deselectAll = () => {
    if (tableInst == null) {
      console.log("null");
      return;
    }
    tableInst.deselectRow();
    localStorage.setItem(props.id, JSON.stringify([]));
    // handleConfigSettings({ buildSpec: [] });
    // preview = [];
  };

  let unFold = () => {
    if (tableInst == null) {
      console.log("null");
      return;
    }
    tableInst.getRows("active").filter((row) => {
      row.treeExpand();
    });
  };
  let fold = () => {
    if (tableInst == null) {
      console.log("null");
      return;
    }
    tableInst.getRows("active").filter((row) => {
      row.treeCollapse();
    });
  };


  let reportSpecDataChanged = (newValue) => {
    const fullName = newValue["specName"];
    axios
      // .post(metricsURL+'newReadSpecDoc/',
      //   { "specType": 2, "fullName": fullName }
      // )
      .post(metricsURL + "readSpecDoc/", {
        specType: "report_spec",
        specName: fullName,
      })
      .then((response) => {
        let r = _.get(response.data, "data", []);
        getSupportedReports(r, newValue);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  let hierSpecDataChanged = (newValue) => {
    const fullName = newValue["specName"];
    axios
      // .post(metricsURL+'newReadSpecDoc/',
      //   { "specType": 4, "fullName": fullName }
      // )
      .post(metricsURL + "readSpecDoc/", {
        specType: "hier_spec",
        specName: fullName,
      })
      .then((response) => {
        let r = _.get(response.data, "data", []);
        if (r) {
          // console.log(r["specDoc"][0]["data"]);
          handleConfigSettings({
            selectedHierSpecData: r["specDoc"][0]["data"],
            hierSpec: newValue,
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
    setHierSpecSelectedByUser(true);
  };

  let getSupportedReports = (repSpecDoc, newValue) => {
    let reports = repSpecDoc["specDoc"][0]["data"]["reportNames"];
    let baseMetrics = repSpecDoc["specDoc"][0]["data"]["metrics"];
    let hierRepMetrics = [];
    let uniqHierRepMetrics = null;
    // let headereports = new Set(reports.map(x => x.split('_')[0]));
    // setSupportedReportsDoc(repSpecDoc["specDoc"][0]["data"]);
    reports = Object.entries(reports).map((e) => ({ [e[0]]: e[1] }));
    for (let rep of reports) {
      for (let k in rep) {
        // console.log(rep[k].reportInfo.reportClass);
        if (rep[k].reportInfo.reportClass == "HierDashboardReport") {
          // console.log(Object.keys(rep[k].metrics).filter((col) => !col.startsWith('__')));
          hierRepMetrics = hierRepMetrics.concat(
            Object.keys(rep[k].metrics).filter((col) => !col.startsWith("__"))
          );
        }
      }
    }
    // console.log(hierRepMetrics);
    uniqHierRepMetrics = [...new Set(hierRepMetrics)];
    handleConfigSettings({
      supportedReportList: reports,
      hierRepMetrics: uniqHierRepMetrics,
      reportSpec: newValue,
      baseMetrics: baseMetrics,
    });
    isReportValid(reports);
  };

  let reportSelectionChanged = (report) => {
    //empty previous data
    useGlobalStore.getState().setWidgetData(props.id, {});
    // getMetricsOrderOfReport
    let _report = _.cloneDeep(report);
    let selectedRepSpecWithColorRule = _.cloneDeep(
      report[Object.keys(report)[0]].metrics);
    // let selectedRepSpecWithColorRule = _.cloneDeep(props.config.selectedRepSpec);
    let baseMetrics = props.config.baseMetrics;
    // console.log(props.config, report);
    let reportNames = Object.keys(report);
    let reportClasses = reportNames.flatMap(
      (r) => report[r].reportInfo.menuName
    );
    for (let sm in selectedRepSpecWithColorRule) {
      for (let bm in baseMetrics) {
        if (!("colorRule" in selectedRepSpecWithColorRule[sm]) && sm === bm) {
          selectedRepSpecWithColorRule[sm]["colorRule"] =
            baseMetrics[bm].colorRule;
          // We can fetch anything from baseMetrics to selected one
        }
        if (!("indexList" in selectedRepSpecWithColorRule[sm]) && sm === bm) {
          selectedRepSpecWithColorRule[sm]["indexList"] =
            baseMetrics[bm].indexList;
          // We can fetch anything from baseMetrics to selected one
        }
      }
    }
    _report[Object.keys(report)[0]].metrics = selectedRepSpecWithColorRule;
    // console.log(Object.keys(selectedRepSpecWithColorRule));
    axios
      .post(metricsURL + "getMetricsOrderOfReport/", {
        report: Object.keys(report)[0],
        reportSpecName: props.config.reportSpec["specName"],
      })
      .then((response) => {
        // console.log(response.data);
        if (_.get(response.data, "status", false)) {
          let defaultOrderMetrics = _.get(
            response.data,
            "defaultOrderMetrics",
            []
          );
          handleConfigSettings({
            report: _report,
            title: !titleDirty
              ? "Metrics - reportSpec: " +
              props.config.reportSpec["specName"] +
              " # Report: " +
              reportClasses[0]
              : props.config.title,
            baselineBuilds: [],
            baselineBuild: "",
            orgMode: "BCxM",
            displayMode: "VALUE",
            selectedRepSpec: selectedRepSpecWithColorRule,
            defaultOrderMetrics: defaultOrderMetrics,
          });
        } else {
          handleConfigSettings({
            report: _report,
            title: !titleDirty
              ? "Metrics - reportSpec: " +
              props.config.reportSpec["specName"] +
              " # Report: " +
              reportClasses[0]
              : props.config.title,
            baselineBuilds: [],
            baselineBuild: "",
            orgMode: "BCxM",
            displayMode: "VALUE",
            selectedRepSpec: selectedRepSpecWithColorRule,
            defaultOrderMetrics: [],
          });
          console.log(_.get(response.data, "message", ""));
        }
      })
      .catch((error) => {
        console.log("AddBuildsPopup -> reportSelectionChanged ---", error);
      });
  };

  let metricsSelectionChanged = (metric) => {
    let metricObject = null;
    let metricName = null;
    for (let rep of props.config.supportedReportList) {
      for (let k in rep) {
        // console.log(rep[k].reportInfo.reportClass);
        if (rep[k].reportInfo.reportClass == "HierDashboardReport") {
          if (rep[k].metrics[metric] != undefined) {
            // console.log(_.get(rep[k].metrics, metric, {}));
            metricObject = _.get(rep[k].metrics, metric, {});
          }
          // hierRepMetrics = hierRepMetrics.concat(Object.keys(rep[k].metrics).filter((col) => !col.startsWith('__')))
        }
      }
    }
    if (metricObject) {
      if (_.get(metricObject, "indexList", null)) {
        let tempIndexList = _.get(metricObject, "indexList");
        if (tempIndexList && tempIndexList.length > 7) {
          metricName = tempIndexList[5] + "__" + tempIndexList[7];
        } else if (tempIndexList && tempIndexList.length > 4) {
          metricName = tempIndexList[4].toLowerCase();
        } else {
          metricName = metric.includes("|")
            ? metric.replace("|", "__")
            : metric.toLowerCase();
        }
      }
    }
    // console.log(metricName);
    handleConfigSettings({
      hierTimeMetric: metricName,
      selectedHierTimeMetricsName: metric,
    });
  };

  let isReportValid = (reports) => {
    // console.log(props.config);
    if (!_.isEmpty(props.config?.report)) {
      let suppReports = [];
      let selReport = Object.keys(props.config.report);
      for (let r of reports) {
        suppReports.push(Object.keys(r)[0]);
      }
      if (suppReports.includes(selReport[0])) {
        setReportFlag(true);
      } else {
        setReportFlag(false);
      }
    }
  };

  let validateBuildSpec = (selectedRows, repClass) => {
    let block = null;
    let blockList = [];
    if (repClass == "HierDashboardReport") {
      for (let row of selectedRows) {
        // let row = key._row.data;
        if (row["BLOCK"]) {
          if (!blockList.includes(row["BLOCK"])) {
            blockList.push(row["BLOCK"]);
          } else {
            setBuildSpecSelectionNote("Please select single build per block");
            return false;
          }
        }
      }
    }
    // else if (repClass != "BuildsDashboardReport") {
    //   for (let row of selectedRows) {
    //     // let row = key._row.data;
    //     if (row["BLOCK"]) {
    //       if (block == null) {
    //         block = row["BLOCK"];
    //       }
    //       else {
    //         if (block != row["BLOCK"]) {
    //           setBuildSpecSelectionNote("Please select the builds which are belongs to same block");
    //           return false
    //         }
    //       }
    //     }
    //   }
    // }
    return true;
    // setDisableSubmitButton(true)
  };

  const getReportClass = () => {
    if (props.config?.report && Object.keys(props.config?.report).length > 0) {
      let reportNames = Object.keys(props.config.report);
      let reportClasses = reportNames.flatMap(
        (r) => props.config.report[r].reportInfo.reportClass
      );
      return reportClasses[0];
    }
    return "";
  };

  let queryEditor = (
    <div
      style={{
        visibility: !hidden ? "visible" : "hidden",
        height: !hidden ? "inherit" : 0,
      }}
    >
      <Typography variant="subtitle1" className={styles.label}>
        Query Editor
      </Typography>

      <AceEditor
        placeholder="Please modify df object depending on the query."
        mode="python"
        theme="xcode"
        name="code_editor"
        width="100%"
        // minHeight= "100px"
        // onLoad={this.onLoad}
        onChange={(value, event) => {
          onQueryChange(value);
        }}
        fontSize={16}
        maxLines={Infinity}
        showPrintMargin={true}
        showGutter={true}
        highlightActiveLine={true}
        value={props.config?.query ? props.config.query : defaultQueryBody}
        setOptions={{
          enableBasicAutocompletion: true,
          enableLiveAutocompletion: true,
          enableSnippets: false,
          showLineNumbers: true,
          tabSize: 2,
        }}
      />
    </div>
  );


  let getReportFormatData = () => {
    let _reporFormData = {
      orgMode: orgMode() ? orgMode() : "BCxM", // TableMode
      displayMode: displayMode() ? displayMode() : "VALUE",
      useMetricRefMode: useMetricRefMode() ? useMetricRefMode() : false,
      // showEmpty: this.showEmpty(),
      hierBlockMode: hierBlockMode() == undefined ? true : hierBlockMode(),
      hierBuildMode: hierBuildMode() == undefined ? true : hierBuildMode(),
      // plotMode: this.plotMode(),
    };
    return _reporFormData;
  };

  function sortRptSpec(a, b) {
    let user = _.get(useConfigStore.getState(), "authLoginUser", "");
    function localCompare(a, b) {
      if (a.specName < b.specName) {
        return -1;
      }
      if (a.specName > b.specName) {
        return 1;
      }
      return 0;
    }
    if (a.specName.split("/")[1] == user) {
      if (b.specName.split("/")[1] == user) {
        return localCompare(a, b);
      }
      return -1;
    }
    if (b.specName.split("/")[1] == user) {
      return 1;
    }
    if (a.specName < b.specName) {
      return -1;
    }
    if (a.specName > b.specName) {
      return 1;
    }
    return 0;
  }



  function rptSort(a, b) {
    if (
      a[Object.keys(a)[0]].reportInfo.menuGroup <
      b[Object.keys(b)[0]].reportInfo.menuGroup
    ) {
      return -1;
    }
    if (
      a[Object.keys(a)[0]].reportInfo.menuGroup >
      b[Object.keys(b)[0]].reportInfo.menuGroup
    ) {
      return 1;
    }
    return 0;
  }

  const getReportList = () => {
    let rpts = _.cloneDeep(props.config.supportedReportList);
    rpts?.sort(rptSort);
    return rpts;
  };

  return (
    <>
      <>
        <div style={{ display: "flex" }}>
        </div>
        <div
          id="analytics"
          style={{
            width: "inherit",
            visibility: !hidden ? "hidden" : "visible",
            height: !hidden ? 0 : "inherit",
          }}
        >
          <div
            ref={(r) => {
              tableRef = r;
            }}
          ></div>
        </div>
        {queryEditor}
      </>

      {modalEditFormat ? (
        <FormatPopup
          itemType={getReportClass()} //
          show={modalEditFormat}
          reportFormatData={getReportFormatData()}
          // globalFormatData={this.props.dataConfig.reportStates.globalFormatData}
          handleCancel={setModalEditFormat}
          handleAccept={handleAcceptEditFormat}
        />
      ) : null}
      <Stack spacing={1} direction="row" alignItems="flex-start">
        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={onSave}
          // onClick={(onSave)}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          Submit
        </Button>
        {/* Below format button and functionality has been disable intentionally since it was not ready.
            Suggestion- Move color, table mode and display mode logic to backend.*/}
        {/* {getReportClass() &&
          [
            "TableCompareReport",
            "TableDetailReport",
            "ImageCompareReport",
          ].includes(getReportClass()) ? (
          <Button
            variant="contained"
            size="small"
            disabled={false}
            onClick={() => {
              setModalEditFormat(true);
            }}
            classes={
              false
                ? { root: styles.save_button_disabled }
                : { root: styles.save_button }
            }
          >
            Format
          </Button>
        ) : null}

        {(
          <div className={styles.inline}>
            <div>
              <Popup
                trigger={
                  <Button
                    variant="contained"
                    size="small"
                    disabled={false}
                    classes={
                      false
                        ? { root: styles.save_button_disabled }
                        : { root: styles.save_button }
                    }
                  >
                    Preview
                  </Button>
                }
                modal
                contentStyle={{
                  paddingTop: "25px",
                  overflow: "scroll",
                  position: "relative",
                  width: "100%",
                  height: "100%",
                }}
              >
                {(close) => {
                  return (
                    <PreviewBuildSelection
                      config={props.config}
                      id={props.id}
                      handleConfigSettings={handleConfigSettings}
                      preview={
                        localStorage.getItem(props.id)
                          ? localStorage.getItem(props.id)
                          : props.config?.buildSpec
                      }
                      close={close}
                    />
                  );
                }}
              </Popup>
            </div>

            <Button
              variant="contained"
              size="small"
              disabled={false}
              onClick={selectAllParents}
              classes={
                false
                  ? { root: styles.save_button_disabled }
                  : { root: styles.save_button }
              }
            >
              Select All
            </Button>

            <Button
              variant="contained"
              size="small"
              disabled={false}
              onClick={selectAllChildren}
              classes={
                false
                  ? { root: styles.save_button_disabled }
                  : { root: styles.save_button }
              }
            >
              Select All children
            </Button>

            <Button
              variant="contained"
              size="small"
              disabled={false}
              onClick={deselectAll}
              classes={
                false
                  ? { root: styles.save_button_disabled }
                  : { root: styles.save_button }
              }
            >
              Deselect All
            </Button>
            <Button
              variant="contained"
              size="small"
              disabled={false}
              onClick={fold}
              classes={
                false
                  ? { root: styles.save_button_disabled }
                  : { root: styles.save_button }
              }
            >
              Fold
            </Button>
            <Button
              variant="contained"
              size="small"
              disabled={false}
              onClick={unFold}
              classes={
                false
                  ? { root: styles.save_button_disabled }
                  : { root: styles.save_button }
              }
            >
              Unfold
            </Button>
          </div>
        )} */}

        <Button
          variant="contained"
          size="small"
          onClick={selectAllParents}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          Select All
        </Button>

        <Button
          variant="contained"
          size="small"
          onClick={deselectAll}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          Deselect All
        </Button>

        <Button
          variant="contained"
          size="small"
          onClick={props.handleCloseMetrics}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </Stack>
    </>
  );
}, shouldComponentUpdate);

export default AddBuildsPopup;
