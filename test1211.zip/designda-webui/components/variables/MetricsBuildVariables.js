import React from 'react';
import {Dialog,AppBar , IconButton, Typography, Toolbar, Slide } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import MetricBuildConfig from './MetricBuildConfig';


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const MetricsBuildVariables = ({  open,handleCloseMetrics, variableName, metricsBuildSelection }) => {
  let resetShowConfig = () => {
    useGlobalStore.getState().setWidgetUiState(props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };


  return (
    <Dialog
      fullScreen
      open={open}
      handleCloseMetrics={handleCloseMetrics}
      TransitionComponent={Transition}
    >

      <AppBar sx={{ position: "relative", backgroundColor: "#5a2a82" }}>
        <Toolbar sx={{ backgroundColor: "#5a2a82" }}>
          <IconButton
            edge="start"
            color="inherit"
            onClick={handleCloseMetrics}
            aria-label="close"
          >
            <CloseIcon color="inherit" />
          </IconButton>
          <Typography
            sx={{ ml: 2, flex: 1, fontWeight: "bold" }}
            variant="h6"
            component="div"
          >
            Metrics Checkpoint Selection
          </Typography>
        </Toolbar>
      </AppBar>

      <div>
        <MetricBuildConfig
          // getReportClass={getReportClass}
          handleCloseMetrics={handleCloseMetrics}
          resetShowConfig={resetShowConfig}
          id={variableName}
          config={''}
          reportKey={''}
          rptType={''}
          metricsBuildSelection={metricsBuildSelection}
        />
      </div>

    </Dialog>
  );
};


export default MetricsBuildVariables;
