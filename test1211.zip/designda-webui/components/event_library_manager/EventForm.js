import React, { useState, useEffect } from 'react';
import { TextField, FormControlLabel, Switch, Button, Stack, MenuItem } from '@mui/material';
import Dialog from "@mui/material/Dialog";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import axios from 'axios'
import useConfigStore from "../../store/useConfigStore";
import { toast } from "react-toastify";
import { nanoid } from "nanoid";


const EventForm = (props) => {

  const {
    configData,
    authLoginUser,
  } = useConfigStore();

  const [project, setProject] = useState(props.eventForm?.project || '');
  const [eventName, setEventName] = useState(props.eventForm?.event_name || '');
  const [status, setStatus] = useState(props.eventForm?.active || false);
  const [eventType, setEventType] = useState(props.eventForm?.event_type || '');
  const [depEvent, setDepEvent] = useState(props.eventForm?.dependent_event || '');
  const [eventExpression, setEventExpression] = useState(props.eventForm?.event_expression || '');
  const [streamExpression, setStreamExpression] = useState(props.eventForm?.stream_expression || '');
  const [action, setAction] = useState(props.eventForm?.action || '');

  const [eventTypeList, setEventTypeList] = useState(['base', 'derived']);
  const [isEventExpressionValid, setIsEventExpressionValid] = useState(true);
  const [projectList, setProjectList] = useState([]);



  useEffect(() => {
    fetchItems();
  }, []);


  const fetchItems = async () => {
    try {
      const response = await axios.post(
        configData.rest_server_url + "/api/fetch_buckets",
        {
          user: authLoginUser,
        }
      );
      setProjectList(response.data.data);


    } catch (error) {
      console.error("Error fetching items:", error);
    }
  }

  const handleDataChange = (e) => {
    e.preventDefault();

    const inputValue = e.target.value;
    setEventExpression(inputValue);
    validateData(inputValue);
  };

  const validateData = (inputValue) => {
    try {
      JSON.parse(inputValue);
      setIsEventExpressionValid(true);
    } catch (error) {
      setIsEventExpressionValid(false);
    }
  };


  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const payload =
    {
      "config": {
        project: project,
        event_name: eventName,
        event_type: eventType,
        event_expression: eventExpression ? JSON.parse(eventExpression) : {},
        stream_expression: streamExpression,
        dependent_event: depEvent,
        action: action,
        active: status,
        _key: props.eventForm._key ? props.eventForm._key : nanoid()
      }
    };

    if (props?.mode === 'add') {
      try {
        const responseProfilePref = await axios.put(
          configData.rest_server_url +
          "/api/log_analysis/add_stream_event", payload
        );
        if (responseProfilePref) {
          toast.success(`Event Created`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          const newRow = _.cloneDeep(payload.config);
          newRow.event_expression = JSON.stringify(newRow.event_expression)
          props.updateTable([newRow], 'add');

        }
        else {
          toast.error(responseProfilePref?.data?.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });

        }
      } catch (e) {
        toast.error(e?.response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    }

    else {
      try {
        const responseProfilePref = await axios.post(
          configData.rest_server_url +
          "/api/log_analysis/update_stream_event", payload
        );
        if (responseProfilePref) {
          // const newData = await getTableData();
          toast.success(`Event Created`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          const newRow = _.cloneDeep(payload.config);
          newRow.event_expression = JSON.stringify(newRow.event_expression)
          props.updateTable([newRow], 'edit');


        }
      } catch (e) {
        console.log(e)
        toast.error(e?.response?.data?.detail, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }


    };
  }


  const handleClose = () => {
    props.handleFullScreen(false);
    // setWidgetData(constants.templateWidget, {});
  };

  return (
    <Dialog
      fullScreen
      open={true}
    // onClose={handleClose}
    // TransitionComponent={Transition}
    >
      <AppBar sx={{ position: "relative", backgroundColor: "#5a2a82" }}>
        <Toolbar sx={{ backgroundColor: "#5a2a82" }}>
          <IconButton
            edge="start"
            color="inherit"
            onClick={handleClose}
            aria-label="close"
          >
            <CloseIcon color="inherit" />
          </IconButton>
          <Typography sx={{ flexGrow: 1 }}> </Typography>

          {props.mode ? (
            <Button
              type="submit"
              sx={{
                backgroundColor: "white",
                "&:hover": {
                  backgroundColor: "lightgrey",
                },
              }}
              variant={"outlined"}
              disabled={!eventName}
              onClick={handleFormSubmit}
            >
              Save
            </Button>
          ) : null}
        </Toolbar>
      </AppBar>
      <Box sx={{ height: "calc(100vh - 64px)", width: "100%" }}>
        <Stack direction="row">
          <Box
            id="widgetDisplay"
            sx={{
              "& > :not(style)": { m: 1 },
              width: "100%",
            }}
          >

            <form >
              <Box sx={{ m: 2, mt: 5, mb: 3 }}>
                <TextField
                  select
                  label="Project"
                  value={project}
                  onChange={(e) => setProject(e.target.value)}
                  variant="outlined"
                  fullWidth

                >
                  {projectList.map(item => <MenuItem key={item} value={item}>{item}</MenuItem>)
                  }
                </TextField>
              </Box>

              <Box sx={{ m: 2 }}>
                <TextField
                  label="Event Name"
                  value={eventName}
                  onChange={(e) => setEventName(e.target.value)}
                  variant="outlined"
                  fullWidth
                  required
                />
              </Box>

              <Box sx={{ m: 0 }}>
                <FormControlLabel
                  control={<Switch checked={status} onChange={(e) => setStatus(e.target.checked)} />}
                  label="Active"
                  labelPlacement="start"
                />
              </Box>

              <Box sx={{ m: 2 }}>
                <TextField
                  select
                  label="Event Type"
                  value={eventType}
                  onChange={(e) => setEventType(e.target.value)}
                  variant="outlined"
                  fullWidth
                  helperText="Select the event type"
                >
                  {
                    eventTypeList.map(item => <MenuItem key={item} value={item}>{item}</MenuItem>)
                  }
                </TextField>
              </Box>

              <Box sx={{ m: 2 }}>
                <TextField
                  label="Dependent Event"
                  value={depEvent}
                  onChange={(e) => setDepEvent(e.target.value)}
                  variant="outlined"
                  fullWidth
                  helperText="Select the dependent event"
                  disabled={eventType === 'base'}
                >
                </TextField>
              </Box>

              <Box sx={{ m: 2 }}>
                <TextField
                  label="Event Expression"
                  value={(eventExpression)}
                  onChange={handleDataChange}
                  variant="outlined"
                  fullWidth
                  multiline
                  rows={4}
                  error={!isEventExpressionValid}
                  helperText={!isEventExpressionValid ? 'Invalid list or JSON' : 'Enter a valid list or JSON'}
                />
              </Box>


              <Box sx={{ m: 2 }}>
                <TextField
                  label="Target Stream Expression"
                  value={streamExpression}
                  onChange={(e) => setStreamExpression(e.target.value)}
                  variant="outlined"
                  fullWidth
                />
              </Box>

              <Box sx={{ m: 2 }}>
                <TextField
                  label="Action"
                  value={action}
                  onChange={(e) => setAction(e.target.value)}
                  variant="outlined"
                  fullWidth
                />
              </Box>
            </form>
          </Box>
        </Stack>
      </Box>
    </Dialog>
  );
};

export default EventForm;