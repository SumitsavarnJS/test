import React from "react";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import styles from "./eventLibManager.module.css";

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: "50%",
    height: "20%",
    bgcolor: "white",
    boxShadow: 24,
    p: 4,
    borderRadius: "6px",
    border: "1px solid black",
    boxShadow: " 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
};

export default function DeleteWidgetModal(props) {
    const { open, onClose, handleDelete } = props;
    return (
        <>
            <Modal
                open={open}
                onClose={onClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <Typography>
                       Are You Sure, You want to Delete this event?
                    </Typography>
                    <Button
                        id="delete"
                        className={styles.delete}
                        onClick={handleDelete}
                        variant="contained">
                        Delete
                    </Button>
                </Box>
            </Modal>
        </>
    );
};
