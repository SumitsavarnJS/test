import React, { useEffect, useRef, useState } from "react";
import * as styles from "./eventLibManager.module.css";
import axios from 'axios'
import { ReactTabulator } from "react-tabulator";
import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";
import { shallow } from "zustand/shallow";
import clipboardCopy from "clipboard-copy";
import _ from "lodash";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import EventForm from "./EventForm";
import { nanoid } from "nanoid";
import { toast } from "react-toastify";
import * as utils from "../../common/utils/utils";
import { useRouter } from "next/router";
import DeleteEventModal from "./DeleteEventModal";
import 'react-toastify/dist/ReactToastify.css';


const EventLibManager = (props) => {
  const tableRef = useRef(null);
  const { theme, authLoginUser, configData } = useConfigStore();
  const [data, setData] = useState([]);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [openRptAdd, setOpenRptAdd] = useState(false);
  const [formMode, setFormMode] = useState("edit");
  const [IsDeleteModalClicked, setDeleteModalClicked] = useState(false);
  const [tableData, setTableData] = useState([])

  const defaultEventForm = {
    _key: '',
    project: '',
    eventName: '',
    active: false,
    eventType: '',
    depEvent: '',
    eventExpression: '',
    streamExpression: '',
    action: '',
  
  };
  const [eventForm, setEventForm] = useState({});
  const [openAddEvent, setOpenAddEvent] = useState(false);
  const { allReports, allDashbrdRpts } = useGlobalStore(
    (state) => ({
      allReports: state.allReports,
      allDashbrdRpts: state.allDashbrdRpts,
    }),
    shallow
  );


  const handleSelectedRow = (e) => {
    setSelectedRows((selectedRows) => [e._row.data]);
  };
  const handleDeselectRow = (e) => {
    setSelectedRows((selectedRows) => {
      let newSelectedRows = [...selectedRows];
      newSelectedRows.splice(
        newSelectedRows.findIndex((x) => x._key == e._row.data._key),
        1
      );
      return newSelectedRows;
    });
  };
  const columns = [
    { field: "project", title: "Project", headerSort: false },
    { field: "event_name", title: "Event Name", headerSort: false },
    { field: "active", title: "Active", headerSort: false },
    // { field: "dataSource", title: "Data Source" },
    { field: "event_type", title: "Event Type", headerSort: false },
    { field: "dependent_event", title: "Dependent Event", headerSort: false },
    { field: "event_expression", title: "Event Expression", headerSort: false, headerFilter: false },
    { field: "stream_expression", title: "Target Stream Expression", headerSort: false },
    { field: "action", title: "Action", headerSort: false },

  ];
  const applyTheme = (theme) => {
    if (theme == "dark") {
      return "table-sm table-dark table-striped table-bordered";
    } else {
      return "table-sm table-striped table-bordered";
    }
  };
  const handleFullScreen = (isFullScreen) => {
    setIsFullScreen(isFullScreen);
  };
  const handleDelete = () => {
    setDeleteModalClicked(true);
  };

  const createDupEvent = async (formatPayload) => {
    const payload =
    {
      "config": {
        project: formatPayload.project,
        event_name: formatPayload.event_name,
        event_expression: formatPayload.event_expression ? formatPayload.clone_event_expression : {},
        stream_expression:formatPayload.stream_expression,
        dependent_event: formatPayload.dependent_event,
        event_type: formatPayload.eventType,
        action: formatPayload.action,
        active: formatPayload.active,
        _key: formatPayload._key
      }
    };

    try {
      const responseEventAdd = await axios.put(
        configData.rest_server_url +
        "/api/log_analysis/add_stream_event", payload
      );
      if (responseEventAdd) {
        toast.success(`Duplicate Event Created`, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });

      }
      else {
        toast.error(responseProfilePref?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });

      }
    } catch (e) {
      toast.error(e?.response?.data?.message, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  }

  const handleDuplicate = async () => {
    const newRow = _.cloneDeep(selectedRows[0]);

    const event_name = newRow.event_name + '_DUP';
    newRow.user = authLoginUser;
    newRow.event_name = event_name;
    newRow._key = nanoid();
    newRow.id = tableRef.current.getDataCount() + 1;

    await createDupEvent(newRow)
    if (createDupEvent) {
      updateTable([newRow], 'add');
    }
  };
  const getEventConfig = () => {
    const config = _.cloneDeep(selectedRows[0]);
    return config;
  };

  const handleEdit = () => {
    setEventForm(getEventConfig());
    setIsFullScreen(true);
    setFormMode("edit");
  };
  const handleAddNew = () => {
    let newForm = _.cloneDeep(defaultEventForm);
    newForm._key = nanoid();
    setEventForm(newForm);
    handleFullScreen(true);
    setOpenAddEvent(true);
    setFormMode("add");
  };

  const handleCloseDeleteModalClick = () => {
    handleDelete();
    deleteRow();
    setDeleteModalClicked(false);
  };

  const updateTable = (data, type) => {
    // tableRef.current.replaceData(data);

    if (data) {
      if(type === 'add'){
      tableRef.current.updateOrAddData(data);
      }
      else{
        
        tableRef.current.updateData(data);

      }
    }


  };
  const deleteRow = async () => {
    try {
      const eventId = selectedRows[0]._key;
      const response = await axios.delete(configData.rest_server_url + "/api/log_analysis/delete_stream_event",
        { data: { name: eventId } }

      );

      if (response.status) {
        const rowId = selectedRows[0]._key;
        let copyOfTableData = [...tableData];
        copyOfTableData = copyOfTableData.filter(obj => obj._key !== rowId);
        setTableData(copyOfTableData)
        tableRef.current.replaceData(copyOfTableData);
        setSelectedRows([]);
        toast.success(`Event Deleted`, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });

      }
      else {
        toast.error(response.data.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    } catch (e) {
      toast.error(e?.response?.data?.message, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }

  };

  // format List Object function
  const formattedResponseData = (response) => {
    
    if (response) {
      const formattedData = response.map(item => ({
        ...item,
        clone_event_expression: item?.event_expression,
        event_expression: JSON.stringify(item?.event_expression),
       

      }));
      setTableData(formattedData)
      return (formattedData)
    }
    else {
      return -1
    }

  }

  return (
    <div id="eventLibParent" className={styles.eventParent}>
      <div style={{ height: "80%" }}>
        <div id="analytics" style={{ height: "100%" }}>
          <ReactTabulator
            ref={tableRef}
            onRef={(r) => (tableRef.current = r.current)}
            className={applyTheme(theme)}
            columns={columns}
            layout="fitColumns"
            // data={data}
            options={{
              columnDefaults: {
                headerFilter: true,
                headerFilterLiveFilter: false,
                headerFilterPlaceholder: "...",
                tooltip: true,
              },
              index: "_key",
              pagination: true, //enable pagination
              paginationMode: "remote", //enable remote pagination
              // sortMode: "remote",
              filterMode: "remote",
              ajaxConfig: "POST",
              // paginationSize: 10,
              paginationInitialPage: 1,
              // movableColumns: true, // by Enabling this, it breaks filtering mechanism
              // paginationButtonCount: 10,
              // popupContainer:true,
              ajaxURL: configData.rest_server_url + "/api/log_analysis/get_stream_events", //set url for ajax request
              ajaxContentType: "json",
              ajaxParams: {
                limit:10

              },
              ajaxResponse: (url, params, responseData) => {
                const tabulatorLoreFormat = {
                  data: responseData.data ? formattedResponseData(responseData.data.events) : [],
                  last_page: responseData.data.count
                    ? responseData.data.count
                    : 0,
                };
                return tabulatorLoreFormat;
              },
              height: "100%",
              selectable: 1,
            }}
            events={{
              rowSelected: (event, row) => {
                handleSelectedRow(event);
              },
              rowDeselected: handleDeselectRow,
            }}
          />
        </div>
      </div>
      <div id="buttonArea" className={styles.buttonArea}>
        <Button variant="contained" onClick={handleAddNew}>
          Add
        </Button>
        <Tooltip
          title={
            selectedRows.length != 1
              // ||
              //   (selectedRows.length &&
              //     _.get(selectedRows[0], "user", "") !=
              //     useConfigStore.getState().authLoginUser &&
              //     !useConfigStore.getState().isAdminFlag)
              ? "You can't edit  created by other user. But you can duplicate and then edit your "
              : "Edit Event"
          }
        >
          <div>
            <Button
              disabled={
                selectedRows.length != 1
                // ||
                // (selectedRows.length &&
                //   _.get(selectedRows[0], "user", "") !=
                //   useConfigStore.getState().authLoginUser &&
                //   !useConfigStore.getState().isAdminFlag)
              }
              variant="contained"
              onClick={handleEdit}
            >
              Edit
            </Button>
          </div>
        </Tooltip>
        <Tooltip
          title={
            selectedRows.length &&
              _.get(selectedRows[0], "user", "") !=
              useConfigStore.getState().authLoginUser &&
              !useConfigStore.getState().isAdminFlag
              ? "You can't delete  created by others"
              : "Delete the "
          }
        >
          <div>
            <Button
              disabled={
                selectedRows.length != 1
                // ||
                // (selectedRows.length &&
                //   _.get(selectedRows[0], "user", "") !=
                //   useConfigStore.getState().authLoginUser &&
                //   !useConfigStore.getState().isAdminFlag)
              }
              variant="contained"
              color="error"
              onClick={handleDelete}
            >
              Delete
            </Button>
            {<DeleteEventModal open={IsDeleteModalClicked} onClose={handleCloseDeleteModalClick} handleDelete={handleCloseDeleteModalClick} />}
          </div>
        </Tooltip>
        <Tooltip title={"Duplicate the Event"}>
          <div>
            <Button
              variant="contained"
              disabled={selectedRows.length != 1}
              onClick={handleDuplicate}
            >
              Duplicate
            </Button>
          </div>
        </Tooltip>
      </div>
      <div>
        {isFullScreen ? (
          <EventForm
            key={eventForm._key}
            isFullScreen={isFullScreen}
            eventForm={eventForm}
            mode={formMode}
            handleFullScreen={handleFullScreen}
            updateTable={updateTable}
            dataCount={tableRef.current.getDataCount()}
          />
        ) : null}
      </div>
    </div>
  );
};
export default EventLibManager;