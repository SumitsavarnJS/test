import React, { useState } from "react";
import Button from "@mui/material/Button";
import AddIcon from "@mui/icons-material/Add";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import DataSourceSelection from "../../../components/DataSourceComponent";

const VariableDeclaration = (props) => {
  const [open, setOpen] = useState(false);
  const [variableName, setVariableName] = useState("");
  const [variableType, setVariableType] = useState("");
  const [variablesParent, setVariablesParent] = useState(
    props.locVar ?  props.locVar :{}
  );
  const [dataSource, setDataSource] = useState("");
  const [scenario, setScenario] = useState("");
  const [variableValue, setVariableValue] = useState("");
  const [dataSourceModalOpen, setDataSourceModalOpen] = useState(false);

  const [editVariableName, setEditVariableName] = useState("");
  const [editVariableType, setEditVariableType] = useState("");
  const [editVariableValue, setEditVariableValue] = useState("");
  const [editDataSource, setEditDataSource] = useState("");
  const [editScenario, setEditScenario] = useState("");

  const handleOpenDataSourceModal = (index) => {
    setDataSourceModalOpen(true);
  };

  const handleCloseDataSourceModal = () => {
    setDataSourceModalOpen(false);
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleAddVariable = () => {
    let newVariable;

    if (variableType === "user_defined") {
      newVariable = {
        [variableName]: variablesParent[variableName] || "", // Use the entered value or an empty string
      };
    } else if (variableType === "data_source") {
      newVariable = {
        [variableName]: {
          dataSource,
          scenario,
        },
      };
    }
    // Update variablesParent with the new variable
    const updatedVarParent = { ...variablesParent, ...newVariable };
    setVariablesParent(updatedVarParent);
    // console.log({updatedVarParent})
    // updating store
    // useGlobalStore
    //   .getState()
    //   .setRootLevelData("variablesParent", updatedVarParent);

    props.updateLocVariable(updatedVarParent);

    // Clear input fields
    setVariableName("");
    setVariableType("");
    setDataSource("");
    setScenario("");
    // Close the dialog
    handleClose();
  };

  const handleDataSourceSelection = (data) => {
    setDataSource(data.tempConfig);
    setScenario(data.scenariosSelect);
  };

  const handleEditVariable = (name, value) => {
    setVariableName(name);

    // Handle "Data Source" type variables differently
    if (typeof value === "object") {
      setVariableType("data_source");
      setDataSource(value.dataSource);
      setScenario(value.scenario);
      setVariableValue(""); // Clear user-defined variable value
    } else {
      setVariableType("user_defined");
      setVariableValue(value);
      setDataSource(""); // Clear data source variable values
      setScenario("");
    }

    setOpen(true);
  };

  const handleUpdateVariable = () => {
    let updatedVariable;

    if (variableType === "user_defined") {
      updatedVariable = {
        [variableName]: variableValue,
      };
    } else if (variableType === "data_source") {
      updatedVariable = {
        [variableName]: {
          dataSource,
          scenario,
        },
      };
    }

    setVariablesParent((prevVariables) => ({
      ...prevVariables,
      ...updatedVariable,
    }));

    // Clear the edit state
    setVariableName("");
    setVariableType("");
    setVariableValue("");
    setDataSource("");
    setScenario("");
    handleClose();
  };

  const handleDeleteVariable = (name) => {
    // Remove the variable from variablesParent
    const { [name]: deletedVariable, ...restVariables } = variablesParent;
    setVariablesParent(restVariables);
    props.updateLocVariable(restVariables);
  };

  return (
    <div style={{ overflowY: "auto", maxHeight: "80vh" }}>
      <Button
        onClick={handleClickOpen}
        startIcon={<AddIcon />}
        sx={{ textTransform: "capitalize" }}
        variant="outlined"
      >
        Add Variable
      </Button>

      <Dialog fullWidth maxWidth={"lg"} open={open} onClose={handleClose}>
        <DialogTitle>Add Variable</DialogTitle>
        <DialogContent>
          <br/>
          <TextField
            label="Variable Name"
            variant="outlined"
            fullWidth
            value={variableName}
            onChange={(e) => setVariableName(e.target.value)}
          />
          <TextField
            select
            label="Variable Type"
            variant="outlined"
            fullWidth
            value={variableType}
            onChange={(e) => setVariableType(e.target.value)}
            style={{ marginTop: "16px" }}
            disabled={!variableName}
          >
            {/* Provide options for variable types */}
            <MenuItem value="user_defined">User Defined</MenuItem>
            <MenuItem value="data_source">Data Source</MenuItem>
          </TextField>

          {variableType === "user_defined" && (
            <TextField
              label="Default Value"
              variant="outlined"
              fullWidth
              value={variablesParent[variableName] || ""}
              onChange={(e) =>
                setVariablesParent((prevVariables) => ({
                  ...prevVariables,
                  [variableName]: e.target.value,
                }))
              }
              style={{ marginTop: "16px" }}
            />
          )}

          {variableType === "data_source" && (
            <DataSourceSelection
              onClose={handleCloseDataSourceModal}
              onDataSourceSelection={handleDataSourceSelection}
            />
          )}

          <Button onClick={handleAddVariable} style={{ marginTop: "16px", textTransform: "capitalize" }} variant="contained" >
            Add Variable
          </Button>
        </DialogContent>
      </Dialog>

      <div style={{ marginTop: "16px" }}>
        <strong>Added Variables:</strong>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Value</TableCell>
                <TableCell>Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {variablesParent &&
                Object.entries(variablesParent).map(([name, value]) => (
                  <TableRow key={name}>
                    <TableCell>{name}</TableCell>
                    <TableCell>
                      {typeof value === "object"
                        ? "Data Source"
                        : "User Defined"}
                    </TableCell>
                    <TableCell>
                      {typeof value === "object"
                        ? `Data Source: ${value.dataSource}, Scenario: ${value.scenario}`
                        : value}
                    </TableCell>
                    <TableCell sx={{display: "flex", gap: "10px"}}>
                      <Button
                        onClick={() => handleEditVariable(name, value)}
                        sx={{ textTransform: "capitalize" }}
                        variant="outlined"
                      >
                        Edit
                      </Button>
                      <Button
                        onClick={() => handleDeleteVariable(name)}
                        sx={{ textTransform: "capitalize" }}
                        variant="outlined"
                      >
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>

      {/* Edit Variable Section */}
      {editVariableName && (
        <div style={{ marginTop: "16px" }}>
          {editVariableType === "user_defined" && (
            <TextField
              label="Edit Variable Value"
              variant="outlined"
              fullWidth
              value={editVariableValue}
              onChange={(e) => setEditVariableValue(e.target.value)}
            />
          )}

          {editVariableType === "data_source" && (
            <DataSourceSelection
              onDataSourceSelection={handleDataSourceSelection}
            />
          )}

          <Button onClick={handleUpdateVariable} style={{ marginTop: "16px" }}>
            Update
          </Button>
        </div>
      )}
    </div>
  );
};

export default VariableDeclaration;
