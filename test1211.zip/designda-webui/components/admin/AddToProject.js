import { React, useState, useEffect } from "react";
import { Typography, Button, Autocomplete, TextField } from "@mui/material";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";

import { DataGrid } from "@mui/x-data-grid";
import axios from "axios";
import useConfigStore from "../../store/useConfigStore";
import { toast } from "react-toastify";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "90%",
  height: "90%",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,

  padding: "0% 3%",
};

const AddToProject = (props) => {
  const {
    open,
    close,
    allProjects,
    handleConfirm,
    currentProject,
    setFetchUser,
  } = props;

  const [project, setProject] = useState(currentProject);
  const { configData, authLoginUser } = useConfigStore();

  const [rows, setRows] = useState([]);

  const handleDropDown = (newValue) => {
    setProject(newValue);
  };

  const fetchUserFromList = async () => {
    let formedObj = {
      user: useConfigStore.getState().authLoginUser,
    };
    const url =
      configData.rest_server_url + "/api/user_manager/fetch_all_users";

    try {
      const response = await axios.post(url, formedObj);

      if (response.data.status) {
        const entry = response.data.data;

        setRows(response.data.data);

        setFetchUser(response.data.data);

        toast.info(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      } else {
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    } catch (error) {
      console.log(error);
      toast.error(error?.data?.message, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  };

  useEffect(() => {
    fetchUserFromList();
  }, []);

  const handleButtonClick = async (userName, project) => {
    let formedObj = {
      user: useConfigStore.getState().authLoginUser,
      project_name: project,
      action: "add",
      username: userName,
      admin: false,
      pm: false,
    };
    const url =
      configData.rest_server_url + "/api/user_manager/user_management";

    try {
      const response = await axios.post(url, formedObj);

      if (response.data.data) {
        const entry = response.data.data;
        toast.info(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        setIsDelete(entry);
      } else {
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    } catch (error) {
      console.log(error);
      toast.error(error?.data?.error, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  };

  return (
    <>
      <Modal
        open={open}
        onClose={close}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div
            style={{
              fontSize: "24px",
              margin: "2%",
              borderBottom: "1px solid black",
              color: "#5B2A84",
            }}
          >
            <strong>Add User To Project</strong>
          </div>

          <div
            style={{ fontSize: "28px", marginBottom: "20px", color: "#5B2A84" }}
          >
            Select Project
          </div>

          {/*  Instead of this textfield nedd to add drop down*/}

          <Box>
            <Autocomplete
              disablePortal
              id="combo-box-demo"
              options={allProjects.sort().map((data) => data)}
              value={project}
              renderInput={(params) => (
                <TextField {...params} label="Select or Search Project" />
              )}
              onChange={(event, newValue) => handleDropDown(newValue)}
            />
          </Box>

          <div
            style={{ fontSize: "28px", margin: "20px 0px", color: "#5B2A84" }}
          >
            {" "}
            User Source{" "}
          </div>

          <DataGrid
            rows={rows
              .sort()
              .map((user, index) => ({ id: index, value: user }))}
            columns={[
              { field: "id", headerName: "ID", width: 70 },
              { field: "value", headerName: "Username", width: 150 },
              {
                field: "action",
                headerName: "Action",
                width: 150,
                renderCell: (params) => (
                  <Button
                    onClick={() => handleConfirm(params.row.value, project)}
                  >
                    Add User
                  </Button>
                ),
              },
            ]}
            sx={{
              height: "50%",
            }}
          />

          <div
            id="button_wrapper"
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-end",
              marginTop: "1%",
                   
            }}
          >
            <Button onClick={close}>Cancel</Button>
          </div>
        </Box>
      </Modal>
    </>
  );
};

export default AddToProject;
