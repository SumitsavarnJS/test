import { React, useEffect, useState } from "react";
import { Typography, Button, TextField, Autocomplete } from "@mui/material";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import crypto from "crypto";
import useConfigStore from "../../store/useConfigStore";
import axios from "axios";
import { toast } from "react-toastify";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";





const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "60%",
  height: "60%",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};









const EditModal = (props ) => {
  console.log(props.user, props.edit);
  console.log("FETCHING",props.fetchUser);
  // console.log(props.user)
  // console.log("CHECKING_PROPS",username);
  const { configData, authLoginUser } = useConfigStore();
  const [edituser, setEditUser] = useState(
useConfigStore.getState().authLoginUser);
  console.log("EDIT_USER", edituser);
  const [editPassword, setEditPassword] = useState("");
const [allUsers, setAllUsers] = useState([]);
  const hashPassword = (password) => {
    const hash = crypto.createHash("sha256");
    hash.update(password);
    return hash.digest("hex");
  };

  const editUser = async () => {
    const url = configData.rest_server_url + "/api/user_manager/edit_user";

    let formedObj = {
      user: edituser,
      current_user: 
useConfigStore.getState().authLoginUser,
      hash_passwd: hashPassword(editPassword),
    };
    console.log("Inside API call", formedObj);

    try {
      const response = await axios.post(url, formedObj);
    

      if (response.data.status) {
        toast.info(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      } else {
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    } catch (error) {
      console.log(error);
      toast.error(error?.data?.message, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  };





  const handleDropDown = (value) => {

    console.log("HANDLE_DROP_DOWN");
    setEditUser(value);
    console.log("EDIT_USER",edituser);
   
  };



  const fetchUserFromList = async () => {
    let formedObj = {
      user: 
useConfigStore.getState().authLoginUser,
    };
    const url =
      configData.rest_server_url + "/api/user_manager/fetch_all_users";

    try {
      const response = await axios.post(url, formedObj);

      if (response.data.status) {
        const entry = response.data.data;
    
   
        setAllUsers(response.data.data);
     
        toast.info(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });

       
      }
      else{
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    } catch (error) {
      console.log(error);
      toast.error(error?.data?.message, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  };
 
  useEffect(() => {

fetchUserFromList();
  }, []);


  return (
    <>
      <Modal
        open={props.open}
        onClose={props.close}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div
            style={{
              fontSize: "24px",
              margin: "2%",
              borderBottom: "1px solid black",
              color: "#5B2A84",
            }}
          >
            <strong>Edit User</strong>
          </div>

          <div style={{color:"#5B2A84"}}> 
         <strong> User Name </strong>
          </div>
    

          <Box sx={{marginTop:"10px"}}>
          {/* <FormControl sx={{width:700}}>
              <InputLabel id="demo-simple-select-label">
                Edit or Search User
              </InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={edituser}
                label="Search or Enter User"
                onChange={handleDropDown}
              >
                {/* {props.fetchUser.map((data) => (
                  <MenuItem value={data}>{data}</MenuItem>
                ))} */}
                     {/* {allUsers.sort().map((data) => (
                  <MenuItem value={data}>{data}</MenuItem>
                ))}
              </Select>
          {/*  // </FormControl> */} 
                 <Autocomplete
          disablePortal
          id="combo-box-demo"
          options={allUsers.sort().map((data) => data)}
          value={edituser}
          renderInput={(params) => <TextField {...params} label="Enter or Search User" />}
          onChange={(event, newValue) => handleDropDown(newValue)}
          />
          </Box> 


     
          <div
            id="bottom_wrapper"
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <div>
              <div style={{ margin: "5% 0 1% 0", color: "#5B2A84" }}>
               <strong> Set Password </strong>
              </div>
              <TextField
                id="outlined-basic"
                label="Enter Password"
                variant="outlined"
                type="password"
                value={editPassword}
                onChange={(e) => setEditPassword(e.target.value)}
                sx={{ width: 700 }}
              />
            </div>
          </div>
          <div
            id="button_wrapper"
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-end",
              marginTop: "2.5%",
            }}
          >
            <Button onClick={props.close}>Cancel</Button>
            <Button
              disabled={edituser === "" || editPassword === ""}
              onClick={editUser}
            >
              Confirm
            </Button>
          </div>
        </Box>
      </Modal>
    </>
  );
};

export default EditModal;
