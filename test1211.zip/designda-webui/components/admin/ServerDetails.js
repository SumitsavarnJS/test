import { React, useEffect, useState } from "react";
import axios from "axios";
import useConfigStore from "../../store/useConfigStore";
import styles from "./admin.module.css";
import CircularProgress from '@mui/material/CircularProgress';



const ServerDetails = () => {
  const { configData } = useConfigStore();

  const [serverData, setServerData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchServerDetails = async () => {

      const url = configData.rest_server_url + "/api/system_config";
     
      try {
        setIsLoading(true);
        const response = await axios.get(url);
   
        if (response) {

          const entries = Object.entries(response.data);
          setServerData(entries);
        }
        setIsLoading(false);
      } catch (e) {
        console.error(e);
        setIsLoading(false);
      }
    };
    fetchServerDetails();
  }, []);

  return (
    <div>
      <h5>Server Details</h5>
      <table>
        {serverData.length > 0 ? (
          serverData.map(([keyName, value]) => {
            return (
              <tr key={keyName}>
                <th className={styles.serverKey}>{keyName.split`_`.join` `}</th>
                <td>{value}</td>
              </tr>
            );
          })
        ) : (
          <></>
        )}
      </table>
      <div id="loader" style={{display:"flex", flexDirection:"row", justifyContent:"center", margin:"17px"}}>
      {isLoading ? <CircularProgress sx={{color:"#5B2A84"}} /> : <></>}
      </div>
    </div>
  );
}

export default ServerDetails;
