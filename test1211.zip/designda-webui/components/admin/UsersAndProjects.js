import { React, useState, useEffect } from "react";
import styles from "./users.module.css";
import Box from "@mui/material/Box";
import { Typography, IconButton, Tooltip } from "@mui/material";
import Button from "@mui/material/Button";
import axios from "axios";
import useConfigStore from "../../store/useConfigStore";
import { DataGrid } from "@mui/x-data-grid";
import { nanoid } from "nanoid";
import MoreIcon from "@mui/icons-material/More";
import Switch from "@mui/material/Switch";
import EditIcon from "@mui/icons-material/Edit";
import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import AddModal from "./AddModal";
import DeleteModal from "./DeleteModal";
import AddToProject from "./AddToProject";
import CircularProgress from "@mui/material/CircularProgress";
import { toast } from "react-toastify";
import EditModal from "./EditModal";

const UsersAndProjects = () => {
  const label = { inputProps: { "aria-label": "Switch demo" } };

  const { configData, authLoginUser } = useConfigStore();
  const [allProjects, setAllProjects] = useState([]);
  const [projectSelected, setProjectSelected] = useState(null);
  const [selectedProject, setSelectedProject] = useState([]);
  const [isAddIcon, setIsAddIcon] = useState(false);
  const [isEditIcon, setIsEditIcon] = useState(false);
  const [isDeleteIcon, setIsDeleteIcon] = useState(false);
  const [rows, setRows] = useState([]);
  const [isActionButtonClicked, setIsActionButtonClicked] = useState(null);
  const [loading, setLoading] = useState(false);
  const [userAdded, setUserAdded] = useState(false);
  const [deleteUser, setDeleteUser] = useState("");
  const [deleteProjectSelected, setDeleteProjectSelected] = useState("");
  const [fetchUser, setFetchUser] = useState(null);
  const [currentProject, setCurrentProject] = useState("");

  const fetchProjectDetails = async (data) => {
    let requiredObj = {
      user: 
useConfigStore.getState().authLoginUser,
      project: data,
    };

    const url =
      configData.rest_server_url + "/api/user_manager/fetch_project_details";
    try {
      setLoading(true);
      const response = await axios.post(url, requiredObj);

      if (response.data.data) {
        const entry = response.data.data;
        toast.info(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        console.log({ entry });
        setRows(entry);
        setSelectedProject(entry);
        setLoading(false);
      } else {
        setLoading(false);
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
      console.log(error);
      toast.error(error?.data?.message, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  };

  const handleProjectClick = (data, index) => {
    console.log("OUTER_BUTTON_INVOKED");
    setCurrentProject(data);
    fetchProjectDetails(data);
    setProjectSelected(data);
  };

  const handleCloseAddIconClick = () => {
    setIsAddIcon(false);
  };

  const handleAddUsers = () => {
    setIsAddIcon(true);
  };
  const handleEditIconClick = (username, projectSelected) => {
    setIsEditIcon(true);
    setDeleteUser(username);
  };

  const handleCloseEditIconClick = () => {
    setIsEditIcon(false);
  };

  const handleDeleteIconClick = (username, projectSelected) => {
    setIsDeleteIcon(true);

    setDeleteUser(username);
    setDeleteProjectSelected(projectSelected);
  };

  const handleCloseDeleteIconClick = () => {
    setIsDeleteIcon(false);
  };

  //   const [isDelete, setIsDelete] = useState(users);

  //   const [isAdd, setIsAdd] = useState(users);

  const handleDelete = async () => {
    let formedObj = {
      user: 
useConfigStore.getState().authLoginUser,
      project_name: deleteProjectSelected,
      action: "delete",
      username: deleteUser,
    };
    const url =
      configData.rest_server_url + "/api/user_manager/user_management";

    setIsDeleteIcon(false);

    try {
      setLoading(true);
      const response = await axios.post(url, formedObj);

      if (response.data.data) {
        const entry = response.data.data;
        toast.info(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        setIsDelete(entry);
        setLoading(false);
      } else {
        setLoading(false);
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    } catch (error) {
      setLoading(false);
      console.log(error);
      toast.error(response?.data?.error, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  };

  const CustomSwitch = ({ checked, onChange, username }) => {
    const handleChange = async (isChecked) => {
      let formedObj = isChecked
        ? {
            user: 
useConfigStore.getState().authLoginUser,
            project_name: currentProject,
            action: "add_pm",
            username: username,
            admin: "false",
            pm: isChecked,
          }
        : {
            user: 
useConfigStore.getState().authLoginUser,
            project_name: currentProject,
            action: "delete_pm",
            username: username,
            admin: "false",
            pm: isChecked,
          };
      try {
        setLoading(true);
        const url =
          configData.rest_server_url + "/api/user_manager/user_management";

        const response = await axios.post(url, formedObj);
        if (response.status) {
          console.log(response?.data);
          onChange(isChecked);
          toast.info(response?.data?.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          //   fetchProjectDetails(currentProject);

          setLoading(false);
        } else {
          setLoading(false);
          toast.error(response?.data?.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        }
      } catch (e) {
        setLoading(false);
        console.log(e);
        toast.error(e, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    };
    return (
      <Switch
        checked={checked}
        onChange={(event) => handleChange(event.target.checked)}
        inputProps={{ "aria-label": "controlled" }}
      />
    );
  };

  const handleChange = async (id, isChecked) => {
    const updatedRows = rows.map((row) => {
      if (row.username === id) {
        return { ...row, is_pm: isChecked };
      }
      return row;
    });

    setRows(updatedRows);
    return updatedRows;
  };

  const actionIconButton = (username) => {
    setIsActionButtonClicked(username);
  };

  const getStatus = (username) => {
    return isActionButtonClicked === username;
  };

  const handleOpen = (data) => (e) => {
    console.log("InnerButtonInvoked");
    e.stopPropagation();
    setUserAdded(true);

    setCurrentProject(data);
  };
  const handleClose = () => {
    setUserAdded(false);
  };

  const handleAddToProject = async (username, data) => {
    let formedObj = {
      user: 
useConfigStore.getState().authLoginUser,
      project_name: data,
      action: "add",
      username: username,
      admin: "false",
      pm: "false",
    };

    const url =
      configData.rest_server_url + "/api/user_manager/user_management";

    try {
      setLoading(true);
      const response = await axios.post(url, formedObj);

      if (response.data.status) {
        toast.info(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        setLoading(false);
      } else {
        setLoading(false);
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    } catch (error) {
      setLoading(false);
      console.log(error);
    }
  };

  const columns = [
    { field: "username", headerName: "User Name", width: 150 },
    {
      field: "is_admin",
      headerName: "Admin Access",
      width: 150,
    },
    {
      field: "is_pm",
      headerName: "Is Pm",
      width: 150,
      renderCell: (params) => (
        <CustomSwitch
          checked={params.row.is_pm}
          onChange={(isChecked) => {
            handleChange(params.row.username, isChecked);
          }}
          username={params.row.username}
        />
      ),
    },
    {
      field: "projects",
      headerName: "Projects Assigned",
      width: 150,
      editable: true,
    },

    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => (
        <IconButton
          color="primary"
          onClick={() => actionIconButton(params.row.username)}
        >
          {getStatus(params.row.username) ? (
            <div style={{ display: "flex", flexDirection: "row" }}>
              <IconButton
                onClick={() =>
                  handleEditIconClick(params.row.username, projectSelected)
                }
                // onClick={() => openModal( 'Edit')}
                sx={{ color: "#5B2A84" }}
              >
                <Tooltip title="Edit" placement="top-start">
                  <EditIcon />
                </Tooltip>
              </IconButton>
              <IconButton
                onClick={() =>
                  handleDeleteIconClick(params.row.username, projectSelected)
                }
                sx={{ color: "#5B2A84" }}
              >
                <Tooltip title="Delete" placement="top-start">
                  <DeleteIcon />
                </Tooltip>
              </IconButton>
            </div>
          ) : (
            <MoreIcon />
          )}
        </IconButton>
      ),
    },
  ];

  const handleRefresh = () => {
    console.log("REFRESH");
  };

  // USEEFFECTS USED IN THE CODE
  useEffect(() => {
    setIsEditIcon(true);
    setUserAdded(true);
    const fetchProjectList = async () => {
      let formedObj = {
        user: 
useConfigStore.getState().authLoginUser,
      };

      const url =
        configData.rest_server_url + "/api/user_manager/fetch_all_projects";

      try {
        setLoading(true);
        const response = await axios.post(url, formedObj);

        console.log(response);
        if (response.data.status) {
          const entry = response.data.data;
          toast.info(response?.data?.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          setAllProjects(entry);
          setLoading(false);
        } else {
          setLoading(false);
          toast.error(response?.data?.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        }
      } catch (error) {
        setLoading(false);
        console.log(error?.data?.message);
        toast.error(error?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    };

    fetchProjectList();

    setIsEditIcon(false);
    setUserAdded(false);
  }, []);

  return (
    <div>
      <div
        style={{
          fontSize: "28px",
          textAlign: "center",
          marginBottom: "11px",
          color: "#5B2A84",
        }}
      >
        Users and Projects
      </div>

      <div id="parent_container" className={styles.parent_container}>
        <Box id="t" className={styles.list}>
          <Typography
            sx={{
              borderBottom: "1px solid black",
              padding: "10px",
              margin: "7px",
              color: "#5B2A84",
            }}
          >
            <strong> List of Projects </strong>
          </Typography>

          <div
            id="progressor"
            style={{
              //   display: "flex",
              //   flexDirection: "row",
              //   justifyContent: "center",
              border: "1px solid pink",
              width: "fit-content",
              m: 4,
            }}
          ></div>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
              overflow: "auto",
            }}
          >
            {allProjects.map((data, index) => (
              <div key={index}>
                <Button
                  id="projects"
                  className={styles.projects}
                  onClick={() => handleProjectClick(data, index)}
                  variant="outlined"
                >
                  <div style={{ color: "#5B2A84" }}>{data}</div>

                  <Tooltip title="Add" placement="top-start">
                    <IconButton
                      onClick={handleOpen(data)}
                      sx={{ color: "#5B2A84" }}
                    >
                      <AddIcon />
                    </IconButton>
                  </Tooltip>
                </Button>
              </div>
            ))}
          </div>
        </Box>

        <Box id="users_management" className={styles.users_management}>
          <div
            id="users_management_top_bar"
            className={styles.users_management_top_bar}
          >
            <div>
              <Typography
                sx={{
                  padding: "10px",
                  margin: "7px",
                }}
              >
                <strong>Users Management</strong>
              </Typography>
            </div>
            <div>
              <Typography
                sx={{
                  padding: "10px",
                  margin: "7px",
                }}
              >
                Selected Project : {projectSelected}
              </Typography>
            </div>
            <div
              id="button_add_users"
              style={{ padding: "10px", margin: "7px" }}
            >
              {/* <Button onClick={handleRefresh}>Refresh</Button> */}
              <Button onClick={handleAddUsers}>Add Users</Button>

              <Button onClick={() => setIsEditIcon(true)}>Edit Users</Button>
            </div>
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
            }}
          >
            {loading ? <CircularProgress sx={{ color: "#5B2A84" }} /> : <></>}
          </div>
          <div
            id="users_management_content"
            className={styles.users_management_content}
          >
            {!loading ? (
              <DataGrid
                rows={rows}
                columns={columns}
                initialState={{
                  pagination: {
                    paginationModel: {
                      pageSize: 5,
                    },
                  },
                }}
                pageSizeOptions={[5]}
                disableRowSelectionOnClick
                getRowId={(row) => nanoid()}
              />
            ) : (
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                }}
              >
                <Typography sx={{ fontSize: "20px" }}>
                  {" "}
                  No Data Available{" "}
                </Typography>
              </div>
            )}
          </div>
        </Box>
      </div>

      <>
        {isAddIcon ? (
          <AddModal
            open={isAddIcon}
            close={handleCloseAddIconClick}
            // handleAdd={handleAdd}
            user={deleteUser}
            // user={params.row.username}
          />
        ) : null}

        {isEditIcon ? (
          <EditModal
            open={isEditIcon}
            close={handleCloseEditIconClick}
            user={deleteUser}
            fetchUser={fetchUser}
          />
        ) : null}

        {isDeleteIcon ? (
          <DeleteModal
            open={handleDeleteIconClick}
            close={handleCloseDeleteIconClick}
            handleDelete={handleDelete}
          />
        ) : null}
      </>

      {userAdded ? (
        <AddToProject
          allProjects={allProjects}
          open={handleOpen}
          close={handleClose}
          handleConfirm={handleAddToProject}
          currentProject={currentProject}
          rows={rows}
          setFetchUser={setFetchUser}
        />
      ) : null}
    </div>
  );
};

export default UsersAndProjects;
