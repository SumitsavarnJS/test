import * as React from "react";
import { useState } from "react";
import {
  AppBar,
  Dialog,
  IconButton,
  Slide,
  Toolbar,
  Typography,
} from "@mui/material";
// newly added imports
import ServerDetails from "./ServerDetails";
import UsersAndProjects from "./UsersAndProjects";
import Database from "./Database";
import License from "./License";
import CloseIcon from "@mui/icons-material/Close";
import getConfig from "next/config";
import styles from "./admin.module.css";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const Admin = () => {
  const { publicRuntimeConfig } = getConfig();
  const imageUrl = publicRuntimeConfig.basePath;
  const [isAdminPanelOpen, setAdminPanelOpen] = useState(false);
  const [activeNav, setActiveNav] = useState("");

  const menuOptions = {
    "server-details": "Server Details",
    "users-and-projects": "Users and projects",
    database: "Database",
    license: "License",
  };

  const onOpenAdminPanel = () => {
    setAdminPanelOpen(true);
  };

  const onCloseAdminPanel = () => {
    setAdminPanelOpen(false);
  };

  const renderRequiredComponent = () => {
    const currentActiveNav = activeNav;
    switch (currentActiveNav) {
      case "server-details":
        return <ServerDetails />;
        // break;
      case "users-and-projects":
        return <UsersAndProjects />;
        // break;
      case "database":
        return <Database />;
        // break;
      case "license":
        return <License />;
    }

  };

  return (
    <>
      <div style={{ color: "black" }}>
        <Typography
          onClick={onOpenAdminPanel}
          sx={{
            width: "200px",
            color: "black",
            textTransform: "capitalize",
            fontSize: "1rem",
          }}
        >
          Admin
        </Typography>
      </div>
      <Dialog
        fullScreen
        open={isAdminPanelOpen}
        onClose={onCloseAdminPanel}
        TransitionComponent={Transition}
      >
        <AppBar
          sx={{
            position: "relative",
            backgroundColor: "#fff",
            color: "#5A2A82",
            boxShadow: "none",
            borderBottom: "2px solid #dcdcdc",
          }}
        >
          <Toolbar>
            <Typography
              sx={{ fontSize: "1rem", flex: 1, textTransform: "uppercase" }}
              variant="h6"
              component="div"
            >
              <strong>Admin</strong> Team Manager
            </Typography>
            <IconButton
              edge="start"
              color="inherit"
              onClick={onCloseAdminPanel}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>
          </Toolbar>
        </AppBar>

        {/* dialog body */}
        <div className={styles.adminContainer}>
          {/* left nav */}
          <nav className={styles.sideNav}>
            <ul>
              {Object.entries(menuOptions).map(([keyName, value]) => {
                const iconName = activeNav === keyName ? `${keyName}-active` : keyName
                return (
                <li
                  key={keyName}
                  className={
                    activeNav === keyName
                      ? styles.activeListItem
                      : styles.listItem
                  }
                  onClick={() => setActiveNav(keyName)}
                >
                  <img
                    src={`${imageUrl}/admin_portal_icons/${ iconName }.svg`}
                    alt="workflow-icon"
                    className={styles.navIcon}
                  />
                  {value}
                </li>
              )})}
            </ul>
          </nav>
          {/* right-side-content */}
          <aside className={styles.asideContent}>
            {renderRequiredComponent()}
          </aside>
        </div>
      </Dialog>
    </>
  );
}

export default Admin;
