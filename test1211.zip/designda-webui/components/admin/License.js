import {React} from "react";
const License = () => {
    return (
        <div>
            <div>License</div>
        </div>
    )
}
export default License;