import { React, useState } from "react";
import axios from "axios";
import { Typography, Button, TextField } from "@mui/material";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import Switch from "@mui/material/Switch";
import crypto from "crypto";
import useConfigStore from "../../store/useConfigStore";
import { toast } from "react-toastify";
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "60%",
  height: "60%",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 7,
};

const AddModal = (props) => {
  console.log(props.user, props.edit);
  const { configData, authLoginUser } = useConfigStore();

  const { open, close } = props;

  const [systemuser, setSystemUser] = useState(props.user || "");
  const [systemUserPassword, setSystemUserPassword] = useState("");

  // For password Hashing
  const hashPassword = (password) => {
    const hash = crypto.createHash("sha256");
    hash.update(password);
    return hash.digest("hex");
  };

  // const passwordHasing=(e)=>{

  //   console.log(e.target.value)

  // }

  const addUser = async () => {
    const url = configData.rest_server_url + "/api/user_manager/add_user";

    let formedObj = {
      user: systemuser,
      current_user: 
useConfigStore.getState().authLoginUser,
      hash_passwd: hashPassword(systemUserPassword),
    };
    console.log("Inside API call", formedObj);

    try {
      const response = await axios.post(url, formedObj);

      if (response.data.status) {
        toast.info(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      } else {
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
      }
    } catch (error) {
      console.log(error);
      toast.error(error?.data?.message, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  };

  return (
    <>
      <Modal
        open={open}
        onClose={close}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div
            style={{
              fontSize: "24px",
              m: 4,
              borderBottom: "1px solid black",
              color: "#5B2A84",
            }}
          >
            <strong>Add New User</strong>
          </div>

          <div
            style={{ fontSize: "20px", color: "#5B2A84", marginTop: "10px" }}
          >
            <strong>User Name</strong>
          </div>
          <TextField
            value={systemuser}
            onChange={(e) => setSystemUser(e.target.value)}
            id="outlined-basic"
            label="Enter User"
            variant="outlined"
            sx={{ width: 700, margin: "1% 0" }}
            disabled={props.edit}
          />

          <div style={{ display: "flex", flexDirection: "row" }}>
            <div>
              <div
                style={{
                  margin: "5% 0 1% 0",
                  fontSize: "20px",
                  color: "#5B2A84",
                }}
              >
                <strong>Set Password</strong>
              </div>
              <TextField
                value={systemUserPassword}
                onChange={(e) => setSystemUserPassword(e.target.value)}
                id="outlined-basic"
                label="Type Password"
                variant="outlined"
                type="password"
                sx={{ width: 700 }}
              />
            </div>
          </div>
          <div
            id="button_wrapper"
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-end",
              marginTop: "2.5%",
            }}
          >
            <Button onClick={close}>Cancel</Button>
            <Button
              onClick={addUser}
              disabled={systemuser === "" || systemUserPassword === ""}
            >
              Confirm
            </Button>
          </div>
        </Box>
      </Modal>
      <></>
    </>
  );
};

export default AddModal;
