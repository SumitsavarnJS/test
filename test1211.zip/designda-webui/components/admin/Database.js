import {React} from "react";
const Database = () => {
    return (
        <div>
            <div>Database</div>
        </div>
    )
}
export default Database;