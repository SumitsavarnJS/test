import * as React from 'react';
import { useState, useEffect, useRef } from "react";
import axios from "axios";
import useConfigStore from "../../../store/useConfigStore";
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

  
function menuComponent(props) {
  const {param,toggleApi} = props;
  const [obj,setObj]=useState(null);
  const [clickStates, setClickStates] = useState({generalClick: false,userClick:false,databaseClick: false,licenseClick: false ,serverHealthClick: false})
  
  useEffect(() => {
    fetchData();
  }, [clickStates.generalClick]);

  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    fontSize: 12
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor:"#e1bee7",
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));

  const fetchData = async () => {
    const url =
      useConfigStore.getState().configData.rest_server_url + "/api/system_config";

    try {
      const response = await axios.get(url);
      if (response) {
        // console.log(response.data);
        setObj(response.data)
      }
    } catch (e) {
      console.log(e);
    }
  };

  function createData(key, value) {
    return { key, value};
  }
  const rows=obj?Object.entries(obj).map(([k,v])=>createData(k,v)):[]

  useEffect(()=>{
    if(param == ""){
        setClickStates({...clickStates,
            generalClick:false,
            userClick:false,
            databaseClick:false,
            licenseClick:false,
            serverHealthClick:false})    
    }
    if(param =="general"){

        setClickStates({...clickStates,
            generalClick:true,
            userClick:false,
            databaseClick:false,
            licenseClick:false,
            serverHealthClick:false})    
    }
    if(param =="users"){
        setClickStates({...clickStates,
            generalClick:false,
            userClick:true,
            databaseClick:false,
            licenseClick:false,
            serverHealthClick:false})   
    }
    if(param =="database"){
        setClickStates({...clickStates,
            generalClick:false,
            userClick:false,
            databaseClick:true,
            licenseClick:false,
            serverHealthClick:false})    
    }
    if(param =="license"){
        setClickStates({...clickStates,
            generalClick:false,
            userClick:false,
            databaseClick:false,
            licenseClick:true,
            serverHealthClick:false})    
    }
    if(param =="serverHealth"){
        setClickStates({...clickStates,
            generalClick:false,
            userClick:false,
            databaseClick:false,
            licenseClick:false,
            serverHealthClick:true})   
    }

  },[param, toggleApi])

  return (
    <>
    {clickStates.generalClick ? (
    <TableContainer component={Paper}>
      <Table sx={{ width: "200px" }} aria-label="customized table">
        <TableBody>
          {rows.map((row) => (
            <StyledTableRow key={row.name}>
              <StyledTableCell style={{borderRight:"1px solid black",padding:"0.5vw"}} component="th" scope="row"> {row.key}</StyledTableCell>
              <StyledTableCell style={{padding:"0.5vw"}}align="left">{row.value}</StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>)
    : null}

    {/* {userClick ?(
        <p>This is user/project</p>
    ):null}

    {databaseClick ?(
        <p>This is Database</p>
    ):null}

    {licenseClick ?(
        <p>This is License</p>
    ):null}

    {serverHealthClick ?(
        <p>This is ServerHealth</p>
    ):null} */}

    </>
    );
}

export default menuComponent;