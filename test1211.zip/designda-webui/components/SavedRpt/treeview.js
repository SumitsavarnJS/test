import React, { useState ,useEffect} from "react";
import { TreeView, TreeItem } from "@mui/lab";
import FolderOpenIcon from "@mui/icons-material/FolderOpen";
import FolderIcon from "@mui/icons-material/Folder";
import TextField from "@mui/material/TextField";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import refreshWidgetContent from "../../pages/rptdashboard/wigetWrapper/widgetRefreshData";
import FileOpenOutlinedIcon from "@mui/icons-material/FileOpenOutlined";
import { toast } from "react-toastify";
import axios from "axios";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import { useTheme } from "@mui/material/styles";
import * as constants from "../../constants/constants";

const ListToTreeView = ({ rptObject, onSubmit }) => {
  if (!rptObject || rptObject.length === 0) {
    // Handle the case when rptObject is empty or undefined
    return <div>Reports Not available</div>;
  }
  const { configData, authLoginUser,setCommonString } = useConfigStore();
  const [searchValue, setSearchValue] = useState("");
  const [expanded, setExpanded] = useState([]);
  const { clickedJsons, addClickedJson } = useConfigStore();
  const [dataLink, setDataLink] = useState("");
  const [rptObjectValue, setRptObjectValue] = useState(null);
  const [contextMenu, setContextMenu] = useState(null);
  const [open, setOpen] = useState(false);
  const theme = useTheme();
  const [files, setFiles] = useState([]);
  const [list,setList]=useState([])
  const [isValid,setIsValid]=useState(true);
  const [searchQuery,setSearchQuery]=useState([])
  const [comString,setComString]=useState("")

  // const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    maxWidth: "85%",
    bgcolor: "background.paper",
    border: "1px solid #000",
    boxShadow: 24,
    borderRadius: "5px",
  };

  useEffect(()=>{
    if(rptObject && rptObject.length>=1){
        const subString = rptObject.reduce((common, path) => {
          const match = path.match(/(.+\/gui_reports\/)/);
          return match ? match[1] : common;
        }, '');
      
        
        const Replaced_list = (rptObject && rptObject.map((item) => {
        return item.replace(subString, "");
        }) )// Remove the common string from each item
        
        setList(Replaced_list)      
        setComString(subString)
        setCommonString(subString)
      // }
    }
    
    else{
      setList([]);
      return <div>Reports Not available</div>;
    }
    
  },[rptObject])
  
  

  useEffect(()=>{
    if(searchValue){
      const escapeRegExp = (string) => {
        return string.replace(/[{}()|[\]\\]/g, '\\$&');
      };    
      const filterArrayByRegExp = (list, searchValue) => {
          const regex = new RegExp('^[+*?].*');
          if(list && searchValue){
            if(regex.test(searchValue)){
              setIsValid(false)
              return [];
            }
            else
            {
              const escapedSearchValue=escapeRegExp(searchValue)
              let regExp = new RegExp(escapedSearchValue);          
              let filteredList = list.filter((element) => regExp.test(element));
              return filteredList; 
            } 
          }  
      };
      const validateSearchQuery = (searchValue) => {
        const pattern = new RegExp(`[\\w\\-\\/\\.\\s:\\^\\$\\|\\*\\+\\(\\)\\{\\}\\[\\]\\?]`);
        const part = searchValue.split("");
        const valid = part.every((item) => pattern.test(item));
        
        if (valid) {
          setIsValid(true)
          setSearchQuery(filterArrayByRegExp(list, searchValue))
        } 
        else { 
          setIsValid(false)
          setSearchQuery([]);
        }
      };

      validateSearchQuery(searchValue)
    }
    else{
      setIsValid(true)
    }
  },[list,searchValue])
    
    
  const filterList = searchValue ? searchQuery: list;

  function generatePaths(input) {
    const paths = input.trim().split("/");
    const resultArray = [];

    let currentPath = "";
    for (const path of paths) {
      currentPath += "/" + path;
      resultArray.push(currentPath.slice(1));
    }
    return resultArray;
  }

  const expandArray = [];
  for (const input of filterList) {
    expandArray.push(generatePaths(input));
  }
  const mergedList = Array.from(new Set([].concat(...expandArray)));

  const handleSearchChange = (event) => {
    setSearchValue(event.target.value);
    if (event.target.value !== "") {
      // Get all nodeIds from the treeData
      const allNodeIds = mergedList;

      setExpanded(allNodeIds);
    } else {
      setExpanded([]); // Contract all nodes when searchValue is empty
    }
  };

  const handleToggle = (event, nodeIds) => {
    setExpanded(nodeIds);
  };

  const getJsonLinkStyle = (jsonLink) => {
    return isJsonClicked(jsonLink)
      ? { color: "#5a2a82" }
      : { color: "#0081FE" };
  };

  const isJsonClicked = (jsonLink) => {
    return clickedJsons.includes(jsonLink);
  };

  const filterArrayExp = (list, searchValue) => {
    let regExp = new RegExp(searchValue);          
    let filteredList = list.filter((element) => regExp.test(element));
    return filteredList; 
  } 

  const handleContextMenu = (event) => {
    event.preventDefault();
    event.stopPropagation();
    const linkVal = event.currentTarget.getAttribute("data-nodeId");
    if (linkVal.endsWith(".json")) {
      setDataLink(comString+linkVal);
      setFiles(linkVal.split(" "));
    } else {
      setDataLink(comString+linkVal + "/");
      setFiles(filterArrayExp(list, "^"+linkVal+"/"));
    }

    setContextMenu(
      contextMenu === null
        ? {
            mouseX: event.clientX,
            mouseY: event.clientY,
          }
        : null
    );
  };

  const actionDelete = () => {
    setOpen(false);

    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/delete_gui_report",
        {
          file_name: dataLink,
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((reportResponse) => {
        if (reportResponse) {
          onSubmit();
          toast.info("Report/s Deleted Successfully", {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        } else {
          // login failed
          toast.error(reportResponse.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error) => {
        toast.error("Api Request Timed Out", {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };
  const handleClose = () => {
    setContextMenu(null);
    setOpen(false);
  };

  const handleDelete = () => {
    setContextMenu(null);
    setOpen(true);
  };

  const handlerouteClick = (reportInfo) => {
    axios
      .post(`${configData.rest_server_url}/api/update_reports_info`, {
        data: reportInfo,
        user: useConfigStore.getState().authLoginUser,
      })
      .then((response) => {})

      .catch((error) => {
        // Handle error here, e.g. show error message

        console.error(error);

        toast.error(response.data.message, {
          position: toast.POSITION.BOTTOM_LEFT,

          style: { backgroundColor: "red", color: "white" },
        });
      });
  };

  const handleNodeSelect = (event, nodeId) => {
    if (list && list.includes(nodeId)) {
      let selectedPath = nodeId;
      addClickedJson(selectedPath);
      toast.info("Report Added To Queue", {
        position: toast.POSITION.BOTTOM_LEFT,
      });

      let userauth = authLoginUser;
      const selectedLink = comString + selectedPath;
      axios
        .post(configData.rest_server_url + "/api/get_gui_reports_id", {
          user: userauth,
          reportName: selectedLink,
        })
        .then((response) => {
          if (response.data) {
            let rpt = Object.keys(response.data.gui_reports)[0];
            let rptData = response.data.gui_reports[rpt];
            handlerouteClick(rptData);
            setRptObjectValue(rptData);
            const tempregex = /(template|templates)/i;
            if (tempregex.test(rpt) && rptData.widgetsOrder) {
              const widgetsOrder = rptData.widgetsOrder;

              let rptDataClone = _.cloneDeep(rptData);
              delete rptDataClone.widgets;
              rptDataClone["widgets"] = {};

              //add widgets according to the new order given
              for (let index = 0; index < widgetsOrder.length; index++) {
                rptDataClone["widgets"][widgetsOrder[index]] =
                  rptData["widgets"][widgetsOrder[index]];
              }

              // set the new ordered data report
              rptData = rptDataClone;
            }
            useGlobalStore.getState().updateGlobalObject(rptData.fileName, rptData);
            if (rptData.hasOwnProperty("widgets")) {
              for (const Wkey in rptData.widgets) {
                let WkeyObj = {
                  data: {},
                  uiState: {
                    isLoading: false,
                    showConfig: false,
                    isToastOpen: false,
                    toastSeverity: "info",
                    toastMessage: "",
                    cirlularLoading: false,
                  },
                };
                useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
              }
            }

            const widgetArray = Object.keys(rptData.widgets);
            if (!tempregex.test(rpt)) {
              for (let i = 0; i < widgetArray.length; i++) {
                const widgetId = widgetArray[i];
                const config = rptData.widgets[widgetId].config;
                const name = rptData.widgets[widgetId].name;
                const rptType = rptData.widgets[widgetId]?.rptType
                  ? rptData.widgets[widgetId]?.rptType
                  : constants.allReports;
                const reportKey = rptData.widgets[widgetId]?.reportKey
                  ? rptData.widgets[widgetId]?.reportKey
                  : nodeId;
                const rptDataVariablesCheck = rptData.hasOwnProperty('variables')  && rptData?.variables  ? rptData.variables : {}
                const widgetVariables = Object.keys(rptDataVariablesCheck).length >0 ? rptDataVariablesCheck :{}
                refreshWidgetContent({
                  widgetId: widgetId,
                  config: config,
                  widgetName: name,
                  reportKey: reportKey,
                  rptType: rptType,
                  variables:widgetVariables ? widgetVariables :{}
                });
             //condition to open the clicked report as current report in tabbed view
            if( useGlobalStore
              .getState().analyticsReportView.view==='tab'){
                useGlobalStore
                .getState()
                .setRootLevelData("analyticsReportView", {
                  view: "tab",
                  currentTab:rptData.fileName ,
                });
              }
              }
            }
          } else {
            toast.error(response.data.message, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: { backgroundColor: "red", color: "white" },
            });
          }
        })
        .catch((error) => {
          console.log(error)
          toast.error("Api Request Timed Out", {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        });
    }
  };

  const createTreeStructure = (items) => {
    const tree = {};
    if (items) {
      items.forEach((item) => {
        const parts = item.split("/");

        let currentNode = tree;

        parts.forEach((part) => {
          if (!currentNode[part]) {
            currentNode[part] = {};
          }
          currentNode = currentNode[part];
        });
      });
      return tree;
    }
  };

  const renderTreeItems = (nodes, parentNodeId = "") => {
    if (nodes) {
      return Object.keys(nodes).map((key, index) => {
        const label = key.replace(".json","");
        const subItems = nodes[key];
        const nodeId = parentNodeId ? `${parentNodeId}/${key}` : key;

        if (Object.keys(subItems).length > 0) {
          return (
            <TreeView
              defaultCollapseIcon={<FolderOpenIcon />}
              defaultExpandIcon={<FolderIcon />}
              expanded={expanded}
              onNodeToggle={handleToggle}
              onNodeSelect={handleNodeSelect}
              onContextMenu={handleContextMenu}
              data-nodeId={nodeId}
            >
              <TreeItem
                key={nodeId}
                nodeId={nodeId}
                label={label}
                style={{ color: "#0081FE" }}
              >
                {renderTreeItems(subItems, nodeId)}
              </TreeItem>
            </TreeView>
          );
        }
        return (
          <>
            <TreeView
              id="treeview"
              defaultCollapseIcon={<FolderOpenIcon />}
              defaultExpandIcon={<FolderIcon />}
              expanded={expanded}
              onNodeToggle={handleToggle}
              onNodeSelect={handleNodeSelect}
            >
              <TreeItem
                key={nodeId}
                nodeId={nodeId}
                label={label}
                data-nodeId={nodeId}
                onContextMenu={handleContextMenu}
                style={getJsonLinkStyle(nodeId)}
                icon={<FileOpenOutlinedIcon />}
              />
            </TreeView>
          </>
        );
      });
    }
  };

  const treeData = createTreeStructure(filterList);

  return (
    <>
      <div>
        <div>
          <TextField
             error={isValid?false:true}
             label="Search"
             value={searchValue}
             onChange={handleSearchChange}
             helperText= {isValid ?"" :"enter valid regular expression"}
          />
        </div>

        {renderTreeItems(treeData)}

        <Menu
          open={contextMenu !== null}
          onClose={handleClose}
          anchorReference="anchorPosition"
          anchorPosition={
            contextMenu !== null
              ? { top: contextMenu.mouseY, left: contextMenu.mouseX }
              : undefined
          }
        >
          <MenuItem onClick={handleDelete}>Delete</MenuItem>
        </Menu>
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <>
              <Typography sx={{ margin: "1vw 1vw 0.5vw 1vw" }}>
                {files.length == 1 ? (
                  <p style={{ fontSize: "1em", margin: "0" }}>
                    <strong>Do you want to delete this report?</strong>
                  </p>
                ) : (
                  <p style={{ fontSize: "1em" }}>
                    <strong>Do you want to delete these reports?</strong>
                  </p>
                )}
              </Typography>

              <Box
                sx={{
                  maxHeight: "20vw",
                  overflowY: "auto",
                  paddingRight: "1vw",
                  margin: "0.8vw 0 0 0.8vw",
                }}
              >
                <Typography
                  sx={{ color: "black", lineHeight: "1.1", fontSize: "1em" }}
                >
                  {files &&
                    files.map((item) => {
                      return <ul>{item.replace(".json","")}</ul>;
                    })}
                </Typography>
              </Box>
            </>

            <Box sx={{ float: "right", margin: "0.5vw" }}>
              <Button onClick={actionDelete} autoFocus>
                Delete
              </Button>
              <Button autoFocus onClick={handleClose}>
                Cancel
              </Button>
            </Box>
          </Box>
        </Modal>
      </div>
    </>
  );
};

ListToTreeView.defaultProps = {
  rptObject: {},
};

export default ListToTreeView;
