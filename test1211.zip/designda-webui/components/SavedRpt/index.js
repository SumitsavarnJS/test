import React, { useState, useEffect, useContext } from "react";
import { toast } from "react-toastify";
import { styled, alpha } from "@mui/material/styles";
import Typography from "@mui/material/Typography";
import axios from "axios";
import useConfigStore from "../../store/useConfigStore";
import ListToTreeView from "../../components/SavedRpt/treeview";
import getConfig from "next/config";
import api from "../../common/api/api";

const { publicRuntimeConfig } = getConfig();
const imageUrl = publicRuntimeConfig.basePath;

const useStyles = styled((theme) => ({
  root: {
    width: "100%",
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper,
  },
  tableHeader: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: theme.spacing(2),
  },
  oddRow: {
    backgroundColor: theme.palette.action.hover,
  },
}));

const MyComponent = () => {
  const { configData, authLoginUser } = useConfigStore();
  const classes = useStyles();
  const [rptObject, setRptObject] = useState(null);

  useEffect(() => {
    loadRptData();
  }, []);

  const loadRptData = async () => {
    let userauth = authLoginUser;
    await axios
      .post(configData.rest_server_url + "/api/get_gui_reports_tags", {
        user: userauth,
      })
      .then((reportResponse) => {
        if (reportResponse.data) {
          const response = reportResponse.data.gui_reports;
          // console.log(response)
          setRptObject(response);
        } else {
          // login failed
          toast.error(reportResponse.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error) => {
        // console.log(error);
        toast.error("Api Request Timed Out", {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };

  return (
    <div className={classes.root}>
      <div className={classes.tableHeader}>
        <div style={{ marginBottom: "1%" }}>
          <img
            style={{ width: "25%" }}
            src={`${imageUrl}/SavedReport.png`}
            alt="Design Dash logo"
          />
          <br />
        </div>
      </div>
      {rptObject && Object.keys(rptObject).length > 0 && rptObject ? (
        <div>
          <ListToTreeView rptObject={rptObject} onSubmit={loadRptData} />
        </div>
      ) : (
        <p> Reports Not Available</p>
      )}
    </div>
  );
};

export default MyComponent;
