import { useState, useEffect } from 'react';

import Typography from '@mui/material/Typography';

 

export default function TypingApiResponse({ apiResponse }) {

  const [displayText, setDisplayText] = useState('');

 

  useEffect(() => {

    let typingTimeout;

 

    const typeLine = (line) => {
        

      let charIndex = 0;

 

      typingTimeout = setInterval(() => {

        if (charIndex < line.length) {

          setDisplayText(line.substring(0, charIndex + 1));

          charIndex++;

        } else {

          clearInterval(typingTimeout);

        }

      }, 100); // Adjust the typing speed as needed

    };

 

    typeLine(apiResponse);

 

    return () => {

      clearInterval(typingTimeout);

    };

  }, [apiResponse]);

 

  return (

    <Typography variant="body1">

      {displayText}

    </Typography>

  );

}