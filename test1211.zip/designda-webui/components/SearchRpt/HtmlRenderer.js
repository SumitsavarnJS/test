import React from 'react';
import PropTypes from 'prop-types';
import sanitizeHtml from 'sanitize-html';

const HtmlRenderer = ({ html }) => {
// Sanitize the HTML content
const sanitizedHtml = sanitizeHtml(html);

return <div dangerouslySetInnerHTML={{ __html: sanitizedHtml }} />;
};

HtmlRenderer.propTypes = {
html: PropTypes.string.isRequired,
};

export default HtmlRenderer;