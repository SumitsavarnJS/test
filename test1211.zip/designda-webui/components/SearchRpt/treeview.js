import React, { useState } from "react";
import { TreeView, TreeItem } from "@mui/lab";
import FolderOpenIcon from "@mui/icons-material/FolderOpen";
import FolderIcon from "@mui/icons-material/Folder";
import TextField from "@mui/material/TextField";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import refreshWidgetContent from "../../pages/rptdashboard/wigetWrapper/widgetRefreshData";
import FileOpenOutlinedIcon from "@mui/icons-material/FileOpenOutlined";
import { toast } from "react-toastify";
import axios from "axios";

const ListToTreeView = ({ rptObject }) => {
  const { configData, authLoginUser } = useConfigStore();
  const [searchValue, setSearchValue] = useState("");
  const [expanded, setExpanded] = useState([]);
  const { clickedJsons, addClickedJson } = useConfigStore();
  const [rptObjectValue,setRptObjectValue]=useState(null)

  const commonString = rptObject[0].substring(0,rptObject[0].lastIndexOf("/") + 1); 
  const list = rptObject.map((item) => {return item.replace(commonString, "")}); // Remove the common string from each item


  const filterArrayByRegExp = (list, searchValue) => {
    let regExp = new RegExp(`${searchValue}`);
    let filteredList = list.filter((element) => regExp.test(element));
    return filteredList;
  };

  const filterList =
    searchValue === "" ? list : filterArrayByRegExp(list, searchValue);
  
  function generatePaths(input) {
    const paths = input.trim().split("/");
    const resultArray = [];

    let currentPath = "";
    for (const path of paths) {
      currentPath += "/" + path;
      resultArray.push(currentPath.slice(1));
    }
    return resultArray;
  }


  const expandArray = [];
  for (const input of filterList) {
    expandArray.push(generatePaths(input));
  }
  const mergedList = Array.from(new Set([].concat(...expandArray)));

  const handleSearchChange = (event) => {
    setSearchValue(event.target.value);
    if (event.target.value !== "") {
      // Get all nodeIds from the treeData
      const allNodeIds = mergedList;
      // console.log(allNodeIds);
      setExpanded(allNodeIds);
    } else {
      setExpanded([]); // Contract all nodes when searchValue is empty
    }
  };

  const handleToggle = (event, nodeIds) => {
    setExpanded(nodeIds);
  };


  const getJsonLinkStyle = (jsonLink) => {
    // console.log(jsonLink)
    return isJsonClicked(jsonLink)? { color: "#5a2a82" }: { color: "#0081FE" };
  };

  const isJsonClicked = (jsonLink) => {
    return clickedJsons.includes(jsonLink);
  };

  const handleNodeSelect=(event,nodeId)=>{
    if(list.includes(nodeId)){
      let selectedPath = nodeId
      //  console.log(selectedPath)
      addClickedJson(commonString+selectedPath)

      toast.info("Report Added To Queue", {
        position: toast.POSITION.BOTTOM_LEFT,        
      });

      let userauth = authLoginUser;
      const selectedLink=commonString+selectedPath
      axios
        .post(configData.rest_server_url + "/api/get_gui_reports_id", {user: userauth,reportName:selectedLink})
        .then((response) => {
          if (response.data){
            const rpt = Object.keys(response.data.gui_reports)[0];
            const rptData=response.data.gui_reports[rpt]
            setRptObjectValue(rptData);         
            // console.log(response.data.gui_reports)
          

            useGlobalStore.getState().updateGlobalObject(selectedLink, rptData);
            if (rptData.hasOwnProperty("widgets")) {
              for (const Wkey in rptData.widgets) {
                let WkeyObj = {
                  data: {},
                  uiState: {
                    isLoading: false,
                    showConfig: false,
                    isToastOpen: false,
                    toastSeverity: "info",
                    toastMessage: "",
                    cirlularLoading: false,
                  },
                };
                useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
              }
            }

            const widgetArray = Object.keys(rptData.widgets);

            for (let i = 0; i < widgetArray.length; i++) {
              const widgetId = widgetArray[i];
              const config = rptData.widgets[widgetId].config;
              const name = rptData.widgets[widgetId].name;
              const rptType = rptData.widgets[widgetId]?.rptType
                ? rptData.widgets[widgetId]?.rptType
                : "";
              const reportKey = rptData.widgets[widgetId]?.reportKey
                ? rptData.widgets[widgetId]?.reportKey
                : "";

              refreshWidgetContent({
                widgetId: widgetId,
                config: config,
                widgetName: name,
                reportKey: reportKey,
                rptType: rptType,
              });
            }  
          }
          else {
            toast.error(response.data.message, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: { backgroundColor: "red", color: "white" },
            });
          }       
        });                
      }    
  }

  const createTreeStructure = (items) => {
    const tree = {};

    items.forEach((item) => {
      const parts = item.split("/");
      // console.log(parts)
      let currentNode = tree;

      parts.forEach((part) => {
        if (!currentNode[part]) {
          currentNode[part] = {};
        }
        currentNode = currentNode[part];
      });
    });

    return tree;
  };

  const renderTreeItems = (nodes, parentNodeId = "") => {
    return Object.keys(nodes).map((key, index) => {
      const label = key;
      const subItems = nodes[key];
      const nodeId = parentNodeId ? `${parentNodeId}/${key}` : key;

      if (Object.keys(subItems).length > 0) {
        return (
          <TreeItem key={nodeId} nodeId={nodeId} label={label} style={{ color: "#0081FE" }}>
            {renderTreeItems(subItems, nodeId)}
          </TreeItem>
        );
      }

      return <TreeItem key={nodeId} nodeId={nodeId} label={label} style={getJsonLinkStyle(commonString+nodeId)} icon={<FileOpenOutlinedIcon />}/>;
    });
  };


  const treeData = createTreeStructure(filterList);

  return (
    <>
      <div>
        <TextField
          label="Search"
          value={searchValue}
          onChange={handleSearchChange}
        />
      </div>
      <TreeView
        defaultCollapseIcon={<FolderOpenIcon />}
        defaultExpandIcon={<FolderIcon />}
        expanded={expanded}
        onNodeToggle={handleToggle}
        onNodeSelect={handleNodeSelect}
      >
        {renderTreeItems(treeData)}
      </TreeView>
    </>
  );
};

ListToTreeView.defaultProps={
  rptObject:{},
  

}


export default ListToTreeView;
