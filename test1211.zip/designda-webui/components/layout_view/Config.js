import React from "react";
import { connect } from "react-redux";
import TextField from "@mui/material/TextField";
import AceEditor from "react-ace";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
// import Popup from "reactjs-popup";
import { Box } from "@mui/material";
import { ClickAwayListener } from "@mui/base";

// utility imprts
import _ from "lodash";
import axios from "axios";

// data source table
import DataSource from "../../pages/rptdashboard/data_source/DataSource";

import "ace-builds/src-noconflict/mode-python";
import "ace-builds/src-noconflict/theme-xcode";
import "brace/ext/language_tools";

import styles from "./Config.module.css";

import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";

const defaultQueryBody = `# Please write your own code to get layout items 
# Valid layout items - component, timing path, net, congestion_patch
# Then call the following functions to plot them
# self.add_component(name, x, y, width, height)
# self.add_timing_path WIP
# self.add_net WIP
# self.add_congestion_patch WIP

`;

class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      dataLocation: _.get(this.props.config, "dataLocation", ""),
      showPorts: _.get(this.props.config, "showPorts", false),
      showMacros: _.get(this.props.config, "showMacros", true),
      showBlockages: _.get(this.props.config, "showBlockages", false),
      showComponents: _.get(this.props.config, "showComponents", true),
      doSampling: _.get(this.props.config, "doSampling", true),
      activeZoom: _.get(this.props.config, "activeZoom", false),
      bucket: _.get(this.props.config, "bucket", ""),
      relativePlacement: _.get(this.props.config, "showRP", false),
      volatgeArea: _.get(this.props.config, "showVArea", false),
    };

    this.query = _.get(this.props.config, "query", defaultQueryBody);
  }

  // dataLocationChanged = (newDataLocation, bucket) => {

  //   this.setState({
  //     dataLocation: newDataLocation,
  //     bucket: bucket,
  //   });
  // };
  dataLocationChanged = (newDataLocation, bucket) => {
    const data = {
      bucket: bucket,
      key: newDataLocation,
    };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_root_directory",
        data
      )
      .then((response) => {
        const rootDataLoc = _.get(response.data, "rootPath", "");

        this.setState({
          dataLocation: rootDataLoc,
          bucket: bucket,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  onQueryChange = (newQuery) => {
    this.query = newQuery;
  };

  onSave = () => {
    const config = {};
    config["dataLocation"] = this.state.dataLocation;
    config["query"] = this.query;
    config["showPorts"] = this.state.showPorts;
    config["showMacros"] = this.state.showMacros;
    config["showBlockages"] = this.state.showBlockages;
    config["showComponents"] = this.state.showComponents;
    config["doSampling"] = this.state.doSampling;
    config["activeZoom"] = this.state.activeZoom;
    config["showVArea"] = this.state.volatgeArea;
    config["showRP"] = this.state.relativePlacement;
    config["bucket"] = this.state.bucket;
    config["heatmap"] = this.props.config.heatmap
      ? this.props.config.heatmap
      : {};

    // add title only if user has provided it
    if (this.state.title.length > 0) {
      config["title"] = this.state.title;
    }
    this.props.updateConfig(config, true);
  };

  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Select Data Source */}
        <div className={styles.inline}>
          <Button
            size="small"
            classes={{ root: styles.add_button }}
            onClick={() => this.setState({ showDataSource: true })}
          >
            Data Source
          </Button>
          {this.state.showDataSource ? (
            <ClickAwayListener
              onClickAway={() => {
                this.setState({ showDataSource: false });
              }}
            >
              <Box
                sx={{
                  zIndex: "5",
                  position: "absolute",
                  top: "0px",
                  left: "0px",
                  width: "100%",
                  height: "fit-content",
                  backgroundColor: "white",
                  padding: "5px",
                  boxShadow: "grey 5px 5px 5px",
                }}
              >
                <DataSource
                  dataLocationChanged={this.dataLocationChanged}
                  dataLocation={this.state.dataLocation}
                  bucket={this.state.bucket}
                  isScenario={true}
                  close={() => {
                    this.setState({ showDataSource: false });
                  }}
                />
              </Box>
            </ClickAwayListener>
          ) : null}
          <Typography
            variant="body2"
            style={{ marginTop: "15px", marginLeft: "15px" }}
          >
            {this.state.dataLocation.split("#")[1]}
          </Typography>
        </div>

        {/* Show/Hide Ports */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.showPorts}
              onChange={() => {
                this.setState({ showPorts: !this.state.showPorts });
              }}
              name="ports"
              color="primary"
            />
          }
          label="Ports"
        />

        {/* Show/Hide Macros */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.showMacros}
              onChange={() => {
                this.setState({ showMacros: !this.state.showMacros });
              }}
              name="macros"
              color="primary"
            />
          }
          label="Macros"
        />

        {/* Show/Hide Blockages */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.showBlockages}
              onChange={() => {
                this.setState({ showBlockages: !this.state.showBlockages });
              }}
              name="blockages"
              color="primary"
            />
          }
          label="Blockages"
        />

        {/* Show/Hide Components */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.showComponents}
              onChange={() => {
                this.setState({ showComponents: !this.state.showComponents });
              }}
              name="components"
              color="primary"
            />
          }
          label="Components"
        />

        {/* enable/disable doSampling */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.doSampling}
              onChange={() => {
                this.setState({ doSampling: !this.state.doSampling });
              }}
              name="doSampling"
              color="primary"
            />
          }
          label="Low Resolution"
        />

        {/* Relative placement */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.relativePlacement}
              onChange={() => {
                this.setState({
                  relativePlacement: !this.state.relativePlacement,
                });
              }}
              name="relativePlacement"
              color="primary"
            />
          }
          label="RP"
        />

        {/* Voltage area */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.volatgeArea}
              onChange={() => {
                this.setState({ volatgeArea: !this.state.volatgeArea });
              }}
              name="volatgeArea"
              color="primary"
            />
          }
          label="Voltage area"
        />

        {/* enable/disable ActiveZoom */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.activeZoom}
              onChange={() => {
                this.setState({ activeZoom: !this.state.activeZoom });
                // localStorage.setItem(`activeZoom${this.props.id}`, JSON.stringify(!this.state.activeZoom));
              }}
              name="activeZoom"
              color="primary"
            />
          }
          label="Active Zoom"
        />

        {/* Code editor */}
        <Typography variant="subtitle1" className={styles.label}>
          Query Editor
        </Typography>

        <AceEditor
          placeholder="Please modify df object depending on the query."
          mode="python"
          theme="xcode"
          name="code_editor"
          width="100%"
          // onLoad={this.onLoad}
          onChange={(value, event) => {
            this.onQueryChange(value);
          }}
          fontSize={16}
          maxLines={Infinity}
          showPrintMargin={true}
          showGutter={true}
          highlightActiveLine={true}
          value={this.query}
          setOptions={{
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: true,
            enableSnippets: false,
            showLineNumbers: true,
            tabSize: 2,
          }}
        />

        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={() => {
            this.onSave();
            localStorage.setItem(
              `activeZoom${this.props.id}`,
              JSON.stringify(this.state.activeZoom)
            );
          }}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={this.props.updateConfig.bind(this, {}, false)}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}

export default Config;
