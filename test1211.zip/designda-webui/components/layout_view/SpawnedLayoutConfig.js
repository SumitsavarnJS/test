import React from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import {produce} from "immer";

// utility imprts
import _ from "lodash";

import styles from "./Config.module.css";

class SpawnedLayoutConfig extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      showPorts: _.get(this.props.config, "showPorts", false),
      showMacros: _.get(this.props.config, "showMacros", true),
      showBlockages: _.get(this.props.config, "showBlockages", true),
      showComponents: _.get(this.props.config, "showComponents", true),
      bucket: _.get(this.props.config, "bucket", ""),
    };
  }

  onSave = () => {
    const config = produce(this.props.config, (configDraft) => {
      configDraft["showPorts"] = this.state.showPorts;
      configDraft["showMacros"] = this.state.showMacros;
      configDraft["showBlockages"] = this.state.showBlockages;
      configDraft["showComponents"] = this.state.showComponents;
      configDraft["bucket"] = this.state.bucket;

      // add title only if user has provided it
      if (this.state.title.length > 0) {
        configDraft["title"] = this.state.title;
      }
    });
    this.props.updateConfig(config, true);
  };

  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Show/Hide Ports */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.showPorts}
              onChange={() => {
                this.setState({ showPorts: !this.state.showPorts });
              }}
              name="ports"
              color="primary"
            />
          }
          label="Ports"
        />

        {/* Show/Hide Macros */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.showMacros}
              onChange={() => {
                this.setState({ showMacros: !this.state.showMacros });
              }}
              name="macros"
              color="primary"
            />
          }
          label="Macros"
        />

        {/* Show/Hide Blockages */}
        <FormControlLabel
          style={{ marginTop: "10px" }}
          control={
            <Checkbox
              checked={this.state.showBlockages}
              onChange={() => {
                this.setState({ showBlockages: !this.state.showBlockages });
              }}
              name="blockages"
              color="primary"
            />
          }
          label="Blockages"
        />
        <br/>

        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={this.onSave}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={this.props.updateConfig.bind(this, {}, false)}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}

export default SpawnedLayoutConfig;
