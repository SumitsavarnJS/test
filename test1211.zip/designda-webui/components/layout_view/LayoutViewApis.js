import React from "react";
import axios from "axios";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import * as utils from "../../common/utils/utils";
import _ from "lodash";
import { produce } from "immer";
import api from "../../common/api/api";
const uiState = {
  isLoading: false,
  showConfig: false,
  isToastOpen: false,
  toastSeverity: "info",
  toastMessage: "",
  cirlularLoading: true,
};
const getLayoutInput = (config) => {
  const input = {
    bucket: _.get(config, "bucket", ""),
    key: _.get(config, "dataLocation", ""),
    raw_query: _.get(config, "query", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
  };
  const components = ["floorplan"];
  if (_.get(config, "showPorts", true)) {
    components.push("ports");
  }
  if (_.get(config, "showMacros", true)) {
    components.push("macros");
  }
  if (_.get(config, "showBlockages", true)) {
    components.push("blockages");
  }
  if (_.get(config, "showComponents", true)) {
    components.push("components");
  }
  if (_.get(config, "showVArea", false)) {
    components.push("voltageArea");
  }
  if (_.get(config, "showRP", false)) {
    components.push("relativePlacement");
  }
  input["components"] = components;
  return input;
};
const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/api/get_task_layout",
    input
  );
  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }
};
const refreshLayoutView = (widgetId, config) => {
  fetchWidgetData(widgetId, getLayoutInput(config));
};
export default refreshLayoutView;
/**
 * API to draw timingpath
 * @param {*} widgetId
 * @param {*} config
 * @param {*} timingpath
 */
export const getTimingPathCoordinates = async (
  widgetId,
  config,
  timingpath
) => {
  const input = {
    data: _.get(config, "data", ""),
    bucket: _.get(config, "bucket", ""),
    key: utils.getRootDirectory(_.get(config, "dataLocation", "")),
    user: `${useConfigStore.getState().authLoginUser}`,
    timing_paths: timingpath,
    scenario: config.scenario,
  };
  const uiState = {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: true,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const data = useGlobalStore.getState()[widgetId].data;
  useGlobalStore.getState().setWidgetDataProp(widgetId, "isLoading2", true);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/api/get_cell_coordinates",
    input
  );
  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    const newData = produce(data, (draftData) => {
      let timingPaths = _.get(draftData, "timingPaths", []);
      timingPaths = [...timingPaths, ...fetchData.data];
      draftData["timingPaths"] = timingPaths;
      draftData["isLoading2"] = false;
    });
    useGlobalStore.getState().setWidgetData(widgetId, newData);
  }
};
export const drawCell = async (
  widgetId,
  config,
  cell,
  ttype,
  key,
  bucket,
  scenario
) => {
  const input = {
    data: _.get(config, "data", ""),
    bucket: bucket,
    key: key,
    user: `${useConfigStore.getState().authLoginUser}`,
    cell: cell,
    ttype: ttype,
    scenario: scenario,
  };
  const uiState = {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: true,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const data = useGlobalStore.getState()[widgetId].data;
  useGlobalStore.getState().setWidgetDataProp(widgetId, "isLoading2", true);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url + "/api/draw_cell",
    input
  );
  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    const newData = produce(data, (draftData) => {
      let cells = _.get(draftData, "cells", []);
      const newCells = produce(cells, (cells) => {
        cells.push(fetchData.data[0]);
      });
      draftData["cells"] = newCells;
      draftData["isLoading2"] = false;
    });
    useGlobalStore.getState().setWidgetData(widgetId, newData);
  }
};

export const drawPort = async (
  widgetId, port, ttype, key, bucket, scenario,config
) => {
  const input = {
    data: _.get(config, "data", ""),
    bucket: bucket,
    key: key,
    user: `${useConfigStore.getState().authLoginUser}`,
    port: port,
    ttype: ttype,
    scenario: scenario,
  };

  const uiState = {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: true,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);

  const data = useGlobalStore.getState()[widgetId].data;
  useGlobalStore.getState().setWidgetDataProp(widgetId, "isLoading2", true);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url + "/api/get_port_coordinates",
    input
  );
  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    const newData = produce(data, (draftData) => {
      let port = _.get(draftData, "port", []);
      const newport = produce(port, (port) => {
        port.push(fetchData.data[0]);
      });
      draftData["port"] = newport;
      draftData["isLoading2"] = false;
    });
    useGlobalStore.getState().setWidgetData(widgetId, newData);
  }
};

export const drawAllTimingPaths = async (widgetId, config) => {
  const endpoint =
    useConfigStore.getState().configData.rest_server_url +
    "/api/fetch_all_timingpaths";
  const uiState = {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: true,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const input = {
    bucket: _.get(_.get(config, "taskInfo", [])[0], "bucket", ""),
    key: _.get(_.get(config, "taskInfo", [])[0], "key", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
    payload: _.get(config, "taskInfo", []),
    flowPath: _.get(config, "flowPath", ""),
    flowBucket: _.get(config, "flowBucket", ""),
  };
  const response = await api(endpoint, input);
  if (response && response.status) {
    useGlobalStore
      .getState()
      .setWidgetDataProp(
        widgetId,
        "timingPaths",
        _.get(response.data, "timingpaths", [])
      );
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
      uiStateDraft.toastSeverity = "error";
      uiStateDraft.toastMessage = response.message;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
};
export const getNetCoordinates = async (widgetId, config) => {
  const endpoint =
    useConfigStore.getState().configData.rest_server_url +
    "/api/get_net_coordinates";
  const input = {
    data: _.get(config, "data", ""),
    bucket: _.get(config, "bucket", ""),
    key: _.get(config, "dataLocation", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
    net: [_.get(config, "net_value", "")],
    ttype: _.get(config, "ttype", ""),
    scenario: _.get(config, "scenario", ""),
  };
  const uiState = {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: true,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const response = await api(endpoint, input);
  if (response && response.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
    useGlobalStore
      .getState()
      .setWidgetDataProp(widgetId, "shapes", [response.data]);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
      uiStateDraft.toastSeverity = "error";
      uiStateDraft.toastMessage = response.message;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
};
export const getInstanceHeatmap = async (
  widgetId,
  config,
  filteredCoords = {}
) => {
  let instanceVal = (_.get(config, "instance_value", []))  
  // Check if the value is a string
  if (typeof instanceVal === 'string') {
    // Convert the string to an array
    instanceVal = [instanceVal];
  }

  const endpoint =
    useConfigStore.getState().configData.rest_server_url +
    "/api/get_instance_heatmap";
  const input = {
    data: _.get(config, "data", ""),
    bucket: _.get(config, "bucket", ""),
    key: _.get(config, "dataLocation", ""),
    instance: instanceVal,
    ttype: _.get(config, "ttype", ""),
    scenario: _.get(config, "scenario", ""),
    board: _.get(useGlobalStore.getState()[widgetId].data, "floorplan", []),
    filterCoords: filteredCoords,
  }

  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const response = await api(endpoint, input);
  if (response && response) {
    useGlobalStore
      .getState()
      .setWidgetDataProp(
        widgetId,
        "instComponents",
        _.get(response.data, "cells", [])
      );
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.cirlularLoading = false;
      uiStateDraft.toastSeverity = "error";
      uiStateDraft.toastMessage = response.message;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }
};
export const drawDRCNet = (widgetId, config) => {
  const endpoint =
    useConfigStore.getState().configData.rest_server_url +
    "/api/get_dummy_net_coordinates";
  const input = {
    data: _.get(config, "data", ""),
    bucket: config.bucket,
    key: config.dataLocation,
    user: useConfigStore.getState().authLoginUser,
    net: [config.net_value],
    ttype: config.ttype,
    scenario: config.scenario,
  };
  const data = useGlobalStore.getState()[widgetId].data;

  useGlobalStore.getState().setWidgetDataProp(widgetId, "isLoading2", true);
  axios
    .post(endpoint, input)
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const plotData = _.get(response, "data", {});
      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        const newUiState = produce(uiState, (uiStateDraft) => {
          uiStateDraft.cirlularLoading = false;
          uiStateDraft.toastSeverity = "error";
          uiStateDraft.toastMessage = response.message;
        });
        useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
        useGlobalStore
          .getState()
          .setWidgetDataProp(widgetId, "isLoading2", false);
      } else {
        const newData = produce(data, (draftData) => {
          draftData["DRC_net"] = [plotData]; // required to pass an array of arrays of arrays like timing path
          draftData["isLoading2"] = false;
        });
        useGlobalStore.getState().setWidgetData(widgetId, newData);
      }
    })
    .catch((error) => {
      console.log(error);
    });
};
