import React, { Component } from "react";
import { Line } from "react-konva";
// import Tooltip from "@mui/material/Tooltip";

class Shapes extends Component {
  state = {
    showFlylineText: false,
    showShapeText: false,
    opacity: 0.7,
  };

  getDensityColor = (density) => {
    if (density >= 1) {
      return "#ff0000";
    } else if (density >= 0.9) {
      return "#de9600";
    } else if (density >= 0.8) {
      return "#ffcb39";
    } else if (density >= 0.7) {
      return "#21c34a";
    } else if (density >= 0.6) {
      return "#008a21";
    } else if (density >= 0.5) {
      return "#016b6d";
    } else if (density >= 0.4) {
      return "#006db5";
    } else if (density >= 0.3) {
      return "#003fa4";
    } else if (density >= 0.2) {
      return "#302d67";
    } else if (density >= 0) {
      return "#141450";
    }
  };

  /**
   * To get the position relative to the
   * new origin (lower left corner)
   * of the plane after rotation and offsetX
   * @param {stageNode} node
   */
  getRelativePointerPosition = (node) => {
    var transform = node.getAbsoluteTransform().copy();

    // to detect relative position we need to invert transform
    transform.invert();

    // get pointer (say mouse or touch) position
    var pos = node.getStage().getPointerPosition();

    if (pos != null)
      // now we can find relative point
      this.setState({ x: transform.point(pos).x, y: transform.point(pos).y });
  };

  // make arrow visible once length is greater than 7 pixel
  arrowVisible = (arrow) => {
    if (
      Math.sqrt(
        Math.pow(arrow[0] - arrow[2], 2) + Math.pow(arrow[1] - arrow[3], 2)
      ) *
        this.props.stageScale >
      7
    )
      return true;
    return false;
  };

  handleOnMouseOver = (text) => {
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 0.7 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseDown = (text) => {
    this.props.getRelativePointerPosition();
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleClick = (e, text) => {
    if (!this.props.zoomIn && !this.props.zoomOut) {
      if (e.evt.detail === 1 && e.evt.button === 0) {
        // console.log('Left click');
        this.handleMouseDown(text);
      }
    }
  };

  render() {
    const { stageScale, colorPicker, properties } = this.props;
    const colorList = [
      "#2f4f4f",
      "#8b4513",
      "#008000",
      "#00008b",
      "#ff0000",
      "#cccc2b",
      "#00ff00",
      "#00ffff",
      "#ff00ff",
      "#eee8aa",
      "#6495ed",
      "#ff69b4",
    ];
    const netColorList = [
      "#8febeb",
      "#fa7a1e",
      "#03fc03",
      "#0303fc",
      "#ffbdbd",
      "#fcfc74",
      "#c5fcc5",
      "#d2fcfc",
      "#fac5fa",
      "#ffff03",
      "#dbe8ff",
      "#fcd4e8",
    ];
    let color = "";
    let netColor = "";
    if (this.props.theme === "dark") {
      color = netColorList[colorPicker % netColorList.length];
      netColor = colorList[colorPicker % colorList.length];
    } else {
      color = colorList[colorPicker % colorList.length];
      netColor = netColorList[colorPicker % netColorList.length];
    }

    return (
      <React.Fragment>
        {
            properties.shapes.map((coordinates) => (
              <Line
                key={properties.shapes.indexOf(coordinates)}
                points={[
                  coordinates[1],
                  coordinates[0],
                  coordinates[3],
                  coordinates[2],
                ]}
                fill={color}
                stroke={color}
                strokeWidth={2 / stageScale}
              />
            ))
          }
        
      </React.Fragment>
    );
  }
}

export default Shapes;
