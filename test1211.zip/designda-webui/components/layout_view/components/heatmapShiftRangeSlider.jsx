import React, { Component } from "react";
import Slider from "@mui/material/Slider";
import Tooltip from "@mui/material/Tooltip";

class HeatmapRangeShiftSlider extends Component {
  ValueLabelComponent = (props) => {
    const { children, open, value } = props;

    return (
      <Tooltip open={open} enterTouchDelay={0} placement="right" title={value}>
        {children}
      </Tooltip>
    );
  };

  render() {
    return (
      <Tooltip
        style={{ top: "-30px" }}
        placement="top-start"
        title="Change min/max"
      >
        <div
          style={{
            bottom: "30px",
            marginLeft: "5px",
            left: "0px",
            position: "absolute",
            width: "27px",
            height: "120px",
            display: this.props.displayLeftSlider,
            borderRadius: "5px",
            backgroundImage:
              "linear-gradient(to top, #D3D3D3, #4575b4, #74add1, #abd9e9, #e0f3f8, #ffffbf, #fee090, #fdae61, #f46d43, #d73027, #a50026)",
          }}
        >
          <Slider
            orientation="vertical"
            min={this.props.heatmapMin}
            max={this.props.heatmapMax}
            ValueLabelComponent={this.ValueLabelComponent}
            value={
              this.props.newRangeValue !== undefined &&
              this.props.newRangeValue.length > 1
                ? this.props.newRangeValue
                : [0, 100]
            }
            onChange={this.props.onHeatmapRangeShift}
          />
        </div>
      </Tooltip>
    );
  }
}

export default HeatmapRangeShiftSlider;
