import React, { Component } from "react";
import Slider from "@mui/material/Slider";
import Tooltip from "@mui/material/Tooltip";

class HeatmapCrosstalkValueSlider extends Component {
  render() {
    const marksPatch = [
      {
        value: 0,
        label: "TNS",
      },
      {
        value: 1,
        label: "WNS",
      },
      {
        value: 2,
        label: "NVP",
      },
      {
        value: 3,
        label: "Net Count",
      },
    ];

    const marksHeatmap = [
      {
        value: 0,
        label: "TNS",
      },
      {
        value: 1,
        label: "WNS",
      },
      {
        value: 2,
        label: "NVP",
      },
    ];

    return (
      <Tooltip placement="top-start" title="Type">
        <div
          style={{
            bottom: "30px",
            marginLeft: "5px",
            left: "0px",
            position: "absolute",
            width: "27px",
            height: "80px",
            borderRadius: "5px",
            display: this.props.displayLeftSlider,
          }}
        >
          <Slider
            orientation="vertical"
            marks={
              this.props.subType == "crosstalkPatch" ? marksPatch : marksHeatmap
            }
            step={null}
            track={false}
            min={0}
            max={this.props.subType == "crosstalkPatch" ? 3 : 2}
            valueLabelDisplay={"off"}
            value={this.props.crosstalkValue ? this.props.crosstalkValue : 0}
            onChange={this.props.onCrosstalkValueChange}
          />
        </div>
      </Tooltip>
    );
  }
}

export default HeatmapCrosstalkValueSlider;
