import React, { Component } from "react";
import { Arrow, Rect, Line } from "react-konva";
// import Tooltip from "@mui/material/Tooltip";

class TimingPath extends Component {
  state = {
    showFlylineText: false,
    showShapeText: false,
    opacity: 0.9,
  };

  getDensityColor = (density) => {
    if (density >= 1) {
      return "#ff0000";
    } else if (density >= 0.9) {
      return "#de9600";
    } else if (density >= 0.8) {
      return "#ffcb39";
    } else if (density >= 0.7) {
      return "#21c34a";
    } else if (density >= 0.6) {
      return "#008a21";
    } else if (density >= 0.5) {
      return "#016b6d";
    } else if (density >= 0.4) {
      return "#006db5";
    } else if (density >= 0.3) {
      return "#003fa4";
    } else if (density >= 0.2) {
      return "#302d67";
    } else if (density >= 0) {
      return "#141450";
    }
  };

  /**
   * To get the position relative to the
   * new origin (lower left corner)
   * of the plane after rotation and offsetX
   * @param {stageNode} node
   */
  getRelativePointerPosition = (node) => {
    var transform = node.getAbsoluteTransform().copy();

    // to detect relative position we need to invert transform
    transform.invert();

    // get pointer (say mouse or touch) position
    var pos = node.getStage().getPointerPosition();

    if (pos != null)
      // now we can find relative point
      this.setState({ x: transform.point(pos).x, y: transform.point(pos).y });
  };

  // make arrow visible once length is greater than 7 pixel
  arrowVisible = (arrow) => {
    if (
      Math.sqrt(
        Math.pow(arrow[0] - arrow[2], 2) + Math.pow(arrow[1] - arrow[3], 2)
      ) *
        this.props.stageScale >
      7
    )
      return true;
    return false;
  };

  handleOnMouseOver = (text) => {
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 0.9 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseDown = (text) => {
    this.props.getRelativePointerPosition();
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleClick = (e, text) => {
    if (!this.props.zoomIn && !this.props.zoomOut) {
      if (e.evt.detail === 1 && e.evt.button === 0) {
        // console.log('Left click');
        this.handleMouseDown(text);
      }
    }
  };

  render() {
    const { stageScale, colorPicker, properties } = this.props;
    const colorList = [
      "#00524e",
      "#bf02bf",
      "#118c11",
      "#9e4b02",
      "#ff0000",
      "#cccc2b",
      "#00ff00",
      "#00ffff",
      "#ff00ff",
      "#eee8aa",
      "#6495ed",
      "#ff69b4",
    ];
    const netColorList = [
      "#02d4cc",
      "#fc92fc",
      "#03fc03",
      "#f0a462",
      "#ffbdbd",
      "#fcfc74",
      "#c5fcc5",
      "#d2fcfc",
      "#fac5fa",
      "#ffff03",
      "#dbe8ff",
      "#fcd4e8",
    ];
    let color = "";
    let netColor = "";
    if (this.props.theme === "dark") {
      color = netColorList[colorPicker % netColorList.length];
      netColor = colorList[colorPicker % colorList.length];
    } else {
      color = colorList[colorPicker % colorList.length];
      netColor = netColorList[colorPicker % netColorList.length];
    }

    return (
      <React.Fragment>
        {stageScale >= 12 && properties.shapes
          ? properties.shapes.map((coordinates) => (
              <Line
                key={properties.shapes.indexOf(coordinates)}
                points={[
                  coordinates[1],
                  coordinates[0],
                  coordinates[3],
                  coordinates[2],
                ]}
                fill={color}
                stroke={netColor}
                strokeWidth={2 / stageScale}
              />
            ))
          : null}
        {stageScale >= 12 && properties.components
          ? properties.components.map((compProps) => (
              <Rect
                key={properties.components.indexOf(compProps)}
                batchDraw
                perfectDrawEnabled={false}
                x={compProps.lly}
                y={compProps.llx}
                width={compProps.ury - compProps.lly}
                height={compProps.urx - compProps.llx}
                fill={
                  properties.densityPresent
                    ? this.getDensityColor(compProps.density)
                    : "#9B59B6"
                }
                onMouseDown={(e) => {
                  const text = properties.densityPresent
                    ? "Ref: " +
                      compProps.refName +
                      "\n" +
                      "Density: " +
                      compProps.density
                    : "Ref: " + compProps.refName;
                  this.handleClick(e, text);
                }}
                // onMouseOver={()=>this.handleOnMouseOver(compProps.refName + "\n" + compProps.density)}
                onMouseOut={this.handleOnMouseOut}
                opacity={this.state.opacity}
                // stroke={"black"}
                // strokeScaleEnabled={false}
              />
            ))
          : null}
        {stageScale <= 20 && properties.sequence
          ? properties.sequence.map((arrow) => (
              <Arrow
                key={properties.sequence.indexOf(arrow)}
                pointerLength={
                  this.arrowVisible(arrow) ? 4 / stageScale : 1 / stageScale
                }
                pointerWidth={
                  this.arrowVisible(arrow) ? 4 / stageScale : 1 / stageScale
                }
                points={arrow}
                onMouseDown={(e) => this.handleClick(e, properties.timingPath)}
                // onMouseOver={()=>this.handleOnMouseOver(properties.timingPath)}
                onMouseOut={this.handleOnMouseOut}
                opacity={this.state.opacity}
                //opacity={0.5/properties.sequence.length * this.state.points.indexOf(arrow) + 0.5 }
                //dash={[(this.state.points.indexOf(arrow)+5)/ stageScale, (properties.sequence.length/(this.state.points.indexOf(arrow)+1))/ stageScale]}
                dash={properties.dotted ? [1, 1] : [0, 0]}
                stroke={color}
                strokeWidth={
                  properties.dotted ? 1.5 / stageScale : 3 / stageScale
                }
              />
            ))
          : null}
      </React.Fragment>
    );
  }
}

export default TimingPath;
