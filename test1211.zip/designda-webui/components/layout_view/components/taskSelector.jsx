import React, { Component } from "react";
import {
  Typography,
  FormControl,
  FormControlLabel,
  FormLabel,
  RadioGroup,
  Radio,
} from "@mui/material";
import Tooltip from "@mui/material/Tooltip";

class TaskSelector extends Component {
  colorPallet = {
    colorList: [
      "#00524e",
      "#bf02bf",
      "#118c11",
      "#9e4b02",
      "#ff0000",
      "#cccc2b",
      "#00ff00",
      "#00ffff",
      "#ff00ff",
      "#eee8aa",
      "#6495ed",
      "#ff69b4",
    ],
    darkThemeColorList: [
      "#02d4cc",
      "#fc92fc",
      "#03fc03",
      "#f0a462",
      "#ffbdbd",
      "#fcfc74",
      "#c5fcc5",
      "#d2fcfc",
      "#fac5fa",
      "#ffff03",
      "#dbe8ff",
      "#fcd4e8",
    ],
  };

  componentDidMount() {}

  getCustomStyle = (taskIndex) => {
    //if all (taskSelected == 0) is selected then select color from this procedure
    if (this.props.taskSelected.toString() === "0" && taskIndex >= 0) {
      if (this.props.theme === "dark") {
        return {
          color:
            this.colorPallet.darkThemeColorList[
              taskIndex % this.colorPallet.darkThemeColorList.length
            ],
          fontSize: "12px",
        };
      }
      return {
        color:
          this.colorPallet.colorList[
            taskIndex % this.colorPallet.colorList.length
          ],
        fontSize: "12px",
      };
    }
    // if all is not selected then select color from this procedure
    else {
      if (this.props.theme === "dark") {
        return { fontSize: "12px", color: "white" };
      } else {
        {
          return { fontSize: "12px", color: "black" };
        }
      }
    }
  };

  render() {
    return (
      <Tooltip placement="top-start" title="Tasks">
        <div
          style={{
            background: "transparent",
            top: 0,
            left: "15px",
            display: "block",
            paddingTop: "60px",
            position: "absolute",
          }}
        >
          <FormControl size="small" component="fieldset">
            <FormLabel
              component="legend"
              style={{ fontSize: "15px", marginLeft: "20px" }}
            >
              Tasks
            </FormLabel>
            <RadioGroup
              column
              name="scenario"
              value={this.props.taskSelected}
              onChange={this.props.onTaskChange}
            >
              <FormControlLabel
                key={0}
                value={0}
                style={{ height: "15px" }}
                control={
                  <Radio
                    size="small"
                    style={{ height: "5px" }}
                    checked={this.props.taskSelected == 0}
                  />
                }
                label={
                  <Typography style={this.getCustomStyle(-1)}>All</Typography>
                }
              />
              {/** List of tasks */}
              {this.props.taskInfo !== undefined &&
              this.props.taskInfo.length > 0
                ? this.props.taskInfo.map((task) => (
                    <FormControlLabel
                      key={this.props.taskInfo.indexOf(task) + 1}
                      value={this.props.taskInfo.indexOf(task) + 1}
                      style={{ height: "15px" }}
                      control={
                        <Radio
                          size="small"
                          checked={
                            this.props.taskSelected ==
                            this.props.taskInfo.indexOf(task) + 1
                          }
                          style={{ height: "5px" }}
                        />
                      }
                      label={
                        <Typography
                          style={this.getCustomStyle(
                            this.props.taskInfo.indexOf(task)
                          )}
                        >
                          {
                            this.props.taskInfo[
                              this.props.taskInfo.indexOf(task)
                            ].task
                          }
                        </Typography>
                      }
                    />
                  ))
                : null}
            </RadioGroup>
          </FormControl>
        </div>
      </Tooltip>
    );
  }
}

export default TaskSelector;
