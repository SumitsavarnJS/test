import React, { Component } from "react";
import { Text, Label, Tag } from "react-konva";
// import { Html } from "react-konva-utils";
// utility imprts
import _ from "lodash";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class LayoutTooltip extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  // componentDidMount() {
  //   if (this.text && this.text.getTextWidth()) {
  //     this.setState({ rectWidth: this.text.getTextWidth() });
  //   }
  // }
  // componentDidUpdate(prevProps, prevState) {
  //   if (!_.isEqual(this.props, prevProps)) {
  //     this.setState({ rectWidth: this.text.getTextWidth() });
  //   }
  // }

  render() {
    const { tooltipValue, stageScale, rotation } = this.props;
    let space = 18;
    if (tooltipValue.toString) {
      space = (tooltipValue.toString().match(/\n/g) || []).length * 18 + 18;
    }
    // console.log(this.state.rectWidth)
    return (
      <React.Fragment>
        {/* <Html
          transform={true}
          divProps={{
            style: {
              // rotation: rotation,
              transform: `rotate(${360-rotation})`,
              position: "static",
              top: 10,
              right: 10,
              color: "yellow"
            },
          }}
        >
          {tooltipValue}
        </Html> */}
        <Label
          x={this.props.x + (space - 3) / stageScale}
          y={this.props.y + 3 / stageScale}
          rotation={360 - rotation}
          scaleX={1 / stageScale}
          scaleY={1 / stageScale}
          cornerRadius={10}
          onMouseDown={this.props.handleTooltipClick}
        >
          {/* {this.state.rectWidth ? (
          <Rect
            cornerRadius={10 / stageScale}
            x={this.props.x}
            y={this.props.y}
            width={(space + 2) / stageScale}
            height={(this.state.rectWidth + 10) / stageScale}
            fill={"white"}
            shadowColor={"black"}
            shadowBlur={10/stageScale}
            // opacity={0.5}
          />
        ) : null} */}
          <Tag
            fill={"white"}
            cornerRadius={5}
            shadowColor={"black"}
            shadowBlur={10}
          />
          <Text
            ref={(node) => {
              this.text = node;
            }}
            batchDraw={true}
            wrap="char"
            // width={500}
            perfectDrawEnabled={false}
            text={this.props.tooltipValue}
            fontSize={12}
            fontFamily="Arial Black"
            // fontStyle="bold"
            fill="black"
            padding={5}
            // scaleX={1 / stageScale}
            // scaleY={1 / stageScale}
            opacity={1}
            // rotation={360 - rotation}
          />
        </Label>
      </React.Fragment>
    );
  }
}

export default (LayoutTooltip);
