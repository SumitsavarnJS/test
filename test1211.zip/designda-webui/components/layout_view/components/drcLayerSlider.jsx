import React, { Component } from "react";
import Slider from "@mui/material/Slider";
import Tooltip from "@mui/material/Tooltip";

class DrcLayerSlider extends Component {
  getMarks = () => {
    let marks = [{ label: "All", value: 0 }];
    for (let i = 0; i < this.props.drcLayersList.length; i++) {
      marks.push({ label: this.props.drcLayersList[i], value: i+1 });
    }
    return marks;
  };

  render() {
      const height = this.props.drcLayersList.length * 12
    return (
      <Tooltip placement="top-start" title="Layer">
        <div
          style={{
            top: "50px",
            marginLeft: "5px",
            left: "0px",
            position: "absolute",
            width: "27px",
            height: `${height}px`,
            borderRadius: "5px",
            display:  this.props.displayLeftSlider,
          }}
        >
          <Slider
            orientation="vertical"
            marks={this.getMarks()}
            step={null}
            track={false}
            min={0}
            max={this.props.drcLayersList.length}
            valueLabelDisplay={"off"}
            value={this.props.drcLayer ? this.props.drcLayer : 0}
            onChange={this.props.handleDrcLayers}
          />
        </div>
      </Tooltip>
    );
  }
}

export default DrcLayerSlider;
