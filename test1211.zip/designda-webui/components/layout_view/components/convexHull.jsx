import React, { Component } from "react";
import { Line } from "react-konva";
// import Tooltip from "@mui/material/Tooltip";

class ConvexHull extends Component {
  state = {
    showFlylineText: false,
    showShapeText: false,
    opacity: 0.9,
  };

  /**
   * To get the position relative to the
   * new origin (lower left corner)
   * of the plane after rotation and offsetX
   * @param {stageNode} node
   */
  getRelativePointerPosition = (node) => {
    var transform = node.getAbsoluteTransform().copy();

    // to detect relative position we need to invert transform
    transform.invert();

    // get pointer (say mouse or touch) position
    var pos = node.getStage().getPointerPosition();

    if (pos != null)
      // now we can find relative point
      this.setState({ x: transform.point(pos).x, y: transform.point(pos).y });
  };

  // make arrow visible once length is greater than 7 pixel
  arrowVisible = (arrow) => {
    if (
      Math.sqrt(
        Math.pow(arrow[0] - arrow[2], 2) + Math.pow(arrow[1] - arrow[3], 2)
      ) *
        this.props.stageScale >
      7
    )
      return true;
    return false;
  };

  handleOnMouseOver = (text) => {
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 0.7 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseDown = (text) => {
    this.props.getRelativePointerPosition();
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleClick = (e, text) => {
    if (!this.props.zoomIn && !this.props.zoomOut) {
      if (e.evt.detail === 1 && e.evt.button === 0) {
        // console.log('Left click');
        this.handleMouseDown(text);
      }
    }
  };

  render() {
    const { stageScale, colorPicker, properties } = this.props;
    const colorList = [
      "rgba(47, 79, 79, 0.5)",
    ];
    const netColorList = [
      "rgba(143, 235, 235, 0.5)",
    ];
    let color = "";
    let netColor = "";
    if (this.props.theme === "dark") {
      color = netColorList[(colorPicker*0) % netColorList.length];
      netColor = colorList[(colorPicker*0) % colorList.length];
    } else {
      color = colorList[(colorPicker*0) % colorList.length];
      netColor = netColorList[(colorPicker*0) % netColorList.length];
    }

    return (
      <React.Fragment>
        {
            // properties.map((coordinates) => (
              <Line
                // key={properties.points.indexOf(coordinates)}
                points={
                    properties
                }
                closed = {true}
                fill={color}
                stroke={color}
                strokeWidth={2 / stageScale}
              />
            // ))
          }
        
      </React.Fragment>
    );
  }
}

export default ConvexHull;
