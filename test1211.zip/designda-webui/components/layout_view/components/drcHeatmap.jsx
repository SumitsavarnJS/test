import React, { Component } from "react";
import { Rect, Star } from "react-konva";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class DRCHeatmap extends Component {
  state = { shouldShowText: false, x: 0, y: 0, scale: 1, opacity: 1 };

  // componentDidUpdate() {
  //   this.refs.rect.clearCache();
  // }

  handleOnMouseOver = (text) => {
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 1 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseMove = () => {
    this.props.getRelativePointerPosition();
  };

  render() {
    const { properties, layer, netType, stageScale, drcErrorType } = this.props;
    let color = "";
    let visible = false;
    let colorList = [
      "#f0e68c",
      "#006400",
      "#ffa500",
      "#0000ff",
      "#8b008b",
      "#e0ffff",
      "#90ee90",
      "#d3d3d3",
      "#92b0b0",
      "#f5f5dc",
      "#000000",
      "#a52a2a",
      "#00ffff",
      "#00008b",
      "#008b8b",
      "#a9a9a9",     
      "#bdb76b",     
      "#556b2f",
      "#ff8c00",
      "#9932cc",
      "#e9967a",
      "#9400d3",
      "#ffd700",
      "#008000",
      "#4b0082",
      "#ffb6c1",
      "#ffffe0",
      "#00ff00",
      "#ff00ff",
      "#800000",
      "#000080",
      "#808000",
      "#ffc0cb",
      "#800080",
      "#c0c0c0",
      "#ffffff",
      "#ffff00"
    ];
    if (properties.error_type === "Short") {
      color = "#FF0000";
    } else {
      color =
        colorList[
          this.props.drcErrorTypeList.indexOf(properties.error_type) %
            colorList.length
        ];
    }
    if (
      (layer === this.props.drcLayersList.indexOf(properties.layer) + 1 ||
        layer === 0) &&
      (netType === this.props.drcNetTypeList.indexOf(properties.netType) + 1 ||
        netType === 0)
    ) {
      visible = true;
      const top5errors = this.props.drcErrorTypeList.slice(0, 5).reverse();
      if (drcErrorType === 0) {
      } else if (!top5errors.includes("Short") && drcErrorType === 1) {
        visible = "Short" === properties.error_type;
      } else {
        visible = top5errors[drcErrorType - 1] === properties.error_type;
      }
    }

    const width = properties.urx - properties.llx;
    const height = properties.ury - properties.lly;

    return (
      <React.Fragment>
        {stageScale >= 20 ? (
          <Rect
            ref="rect"
            batchDraw={true}
            perfectDrawEnabled={false}
            x={properties.lly}
            y={properties.llx}
            width={height}
            height={width}
            fill={color}
            visible={visible}
            onMouseMove={this.handleMouseMove}
            onMouseOver={(e) => {
              const tooltip =
                "Error Type: " +
                properties.error_type +
                "\n" +
                "Metal layer: " +
                properties.layer +
                "\n" +
                "Net List: " +
                properties.netList +
                "\n" +
                "Coordinates: " +
                Math.round(properties.llx) +
                " " +
                Math.round(properties.lly) +
                " " +
                Math.round(properties.llx + width) +
                " " +
                Math.round(properties.lly + height);
              this.handleOnMouseOver(tooltip);
            }}
            onMouseOut={this.handleOnMouseOut}
            opacity={this.state.opacity}
            scaleX={this.state.scale}
            scaleY={this.state.scale}
            onContextMenu={(e) => {
              e.evt.preventDefault();
              // this.props.ContextMenu(properties, e);
            }}
          />
        ) : null}
        {stageScale < 20 ? (
          <Star
            x={(properties.ury + properties.lly) / 2}
            y={(properties.urx + properties.llx) / 2}
            outerRadius={8 / stageScale}
            innerRadius={2 / stageScale}
            visible={visible}
            fill={color}
            numPoints={4}
          />
        ) : null}
      </React.Fragment>
    );
  }
}

export default DRCHeatmap;
