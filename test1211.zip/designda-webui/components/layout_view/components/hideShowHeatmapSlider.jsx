import React, { Component } from "react";
import Slider from "@mui/material/Slider";
import Tooltip from "@mui/material/Tooltip";

class HeatmapHideShowSlider extends Component {
  ValueLabelComponent = (props) => {
    const { children, open, value } = props;

    return (
      <Tooltip open={open} enterTouchDelay={0} placement="right" title={value}>
        {children}
      </Tooltip>
    );
  };

  render() {
    return (
      <Tooltip
        style={{ top: "-30px" }}
        title="Show range"
        placement="bottom-start"
      >
        <div
          style={{
            top: "45px",
            marginLeft: "5px",
            left: "0px",
            position: "absolute",
            display: this.props.displayLeftSlider,
            width: "27px",
            height: "120px",
            borderRadius: "5px",
          }}
        >
          <Slider
            orientation="vertical"
            min={this.props.heatmapMin}
            max={this.props.heatmapMax}
            ValueLabelComponent={this.ValueLabelComponent}
            value={
              this.props.newHideShowValue !== undefined &&
              this.props.newHideShowValue.length > 1
                ? this.props.newHideShowValue
                : [0, 100]
            }
            onChange={this.props.handleHideShowHeatmapSlider}
          />
        </div>
      </Tooltip>
    );
  }
}

export default HeatmapHideShowSlider;
