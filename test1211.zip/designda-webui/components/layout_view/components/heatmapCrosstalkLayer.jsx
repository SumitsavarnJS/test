import React, { Component } from "react";
import { Rect } from "react-konva";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class CrosstalkHeatmapLayer extends Component {
  state = { shouldShowText: false, x: 0, y: 0, scale: 1, opacity: 1 };

  componentDidUpdate() {
    this.refs.rect.clearCache();
  }

  handleOnMouseOver = (text) => {
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 1 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseDown = (text) => {
    this.setState({ opacity: 0.8 });
    this.props.getRelativePointerPosition()
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleClick = (e, text) => {
    if(!this.props.zoomIn && !this.props.zoomOut){
      if (e.evt.detail === 1 && e.evt.button === 0) {
        // console.log('Left click');
        this.handleMouseDown(text);
      } 
    }
  };


  colorSet = (colorNo) => {
    if (colorNo >= this.props.colorCodes[0] - (this.props.colorCodes[1] - this.props.colorCodes[0]) && colorNo < this.props.colorCodes[0])
      return "#21618C";
    else if (colorNo >= this.props.colorCodes[0] && colorNo < this.props.colorCodes[1])
      return "#4575b4";
    else if (colorNo >= this.props.colorCodes[1] && colorNo < this.props.colorCodes[2])
      return "#74add1";
    else if (colorNo >= this.props.colorCodes[2] && colorNo < this.props.colorCodes[3])
      return "#abd9e9";
    else if (colorNo >= this.props.colorCodes[3] && colorNo < this.props.colorCodes[4])
      return "#e0f3f8";
    else if (colorNo >= this.props.colorCodes[4] && colorNo < this.props.colorCodes[5])
      return "#ffffbf";
    else if (colorNo >= this.props.colorCodes[5] && colorNo < this.props.colorCodes[6])
      return "#fee090";
    else if (colorNo >= this.props.colorCodes[6] && colorNo < this.props.colorCodes[7])
      return "#fdae61";
    else if (colorNo >= this.props.colorCodes[7] && colorNo < this.props.colorCodes[8])
      return "#f46d43";
    else if (colorNo >= this.props.colorCodes[8] && colorNo < this.props.colorCodes[9])
      return "#d73027";
    else if (colorNo >= this.props.colorCodes[9])
      return "#a50026";
  }

  reverseColorSet = (colorNo) => {
    if (colorNo <= this.props.colorCodes[0] - (this.props.colorCodes[1] - this.props.colorCodes[0]) && colorNo > this.props.colorCodes[0])
      return "#21618C";
    else if (colorNo <= this.props.colorCodes[0] && colorNo > this.props.colorCodes[1])
      return "#4575b4";
    else if (colorNo <= this.props.colorCodes[1] && colorNo > this.props.colorCodes[2])
      return "#74add1";
    else if (colorNo <= this.props.colorCodes[2] && colorNo > this.props.colorCodes[3])
      return "#abd9e9";
    else if (colorNo <= this.props.colorCodes[3] && colorNo > this.props.colorCodes[4])
      return "#e0f3f8";
    else if (colorNo <= this.props.colorCodes[4] && colorNo > this.props.colorCodes[5])
      return "#ffffbf";
    else if (colorNo <= this.props.colorCodes[5] && colorNo > this.props.colorCodes[6])
      return "#fee090";
    else if (colorNo <= this.props.colorCodes[6] && colorNo > this.props.colorCodes[7])
      return "#fdae61";
    else if (colorNo <= this.props.colorCodes[7] && colorNo > this.props.colorCodes[8])
      return "#f46d43";
    else if (colorNo <= this.props.colorCodes[8] && colorNo > this.props.colorCodes[9])
      return "#d73027";
    else if (colorNo <= this.props.colorCodes[9])
      return "#a50026";
  }

  render() {
    const { properties, crosstalkValue, newCrosstalkLayer } = this.props;
    let color = "";
    let text = "";
    let visible = false;


    if (newCrosstalkLayer === properties.dominant_crosstalk_layer || newCrosstalkLayer === 0) {
      visible = true;
    }

    if (this.props.colorCodes) {
      if (crosstalkValue == 0) {
        color = this.reverseColorSet(properties.TNS);
        text = properties.TNS;
        visible = properties.TNS == "NaN" ? false : visible;
      } else if (crosstalkValue == 1) {
        color = this.reverseColorSet(properties.WNS)
        text = properties.WNS;
        visible = properties.WNS == "NaN" ? false : visible;
      } else if (crosstalkValue == 2) {
        color = this.colorSet(properties.NVP)
        text = properties.NVP;
        visible = properties.NVP == "NaN" ? false : visible;
      } else if (crosstalkValue == 3) {
        color = this.colorSet(properties.net_count)
        text = properties.net_count;
        visible = properties.net_count == "NaN" ? false : visible;
      }
    }

    const width = properties.urx - properties.llx;
    const height = properties.ury - properties.lly;
    return (
      <React.Fragment>
        <Rect
          ref="rect"
          batchDraw={true}
          perfectDrawEnabled={false}
          x={properties.lly}
          y={properties.llx}
          width={height}
          height={width}
          fill={color}
          visible={visible}
          onMouseDown={e => {this.handleClick(e, text)}}
          // onMouseOver={e => { this.handleOnMouseOver(text) }}
          onMouseOut={this.handleOnMouseOut}
          opacity={this.state.opacity}
          scaleX={this.state.scale}
          scaleY={this.state.scale}
          onContextMenu={(e) => {
            e.evt.preventDefault();
            this.props.ContextMenu(properties, e)
          }}
        />
      </React.Fragment>
    );
  }
}

export default CrosstalkHeatmapLayer;
