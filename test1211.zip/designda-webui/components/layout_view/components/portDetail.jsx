import React, { Component } from "react";
import { Rect , Star} from "react-konva";


/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class PortDetail extends Component {
  
  render() {
    const { properties, stageScale} = this.props;
    return (
      <React.Fragment>
        <Rect
          x={properties.y1}
          y={properties.x1}
          width={properties.height}
          height={properties.width}
          fill="#800080"
          opacity={1}
        />
        {stageScale < 20 ? (
          <Star
            x={properties.y1 }
            y={properties.x1}
            outerRadius={8 / stageScale}
            innerRadius={2 / stageScale}
            fill={"#800080"}
            numPoints={4}
          />
        ) : null}
      </React.Fragment>
    );
  }
}

export default PortDetail;

