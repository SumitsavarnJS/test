import React, { Component } from "react";
import { Rect } from "react-konva";
import _ from "lodash";

/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class ZoomFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { filterX1, filterY1, filterX2, filterY2 } = this.props;
    const width = filterX2 - filterX1;
    const height = filterY2 - filterY1;
    return (
      <React.Fragment>
        <Rect
          x={filterX1}
          y={filterY1}
          opacity={0.5}
          fill={"blue"}
          width={width}
          height={height}
        />
      </React.Fragment>
    );
  }
}

export default ZoomFilter;
