import React, { Component } from "react";
import Slider from '@mui/material/Slider';
import Tooltip from '@mui/material/Tooltip';

class HeatmapCrosstalkDominantLayerSlider extends Component{
    state = {
        marks: [
            {
                value:0,
                label: "All"
            }
        ]
    };

    componentDidMount(){
        this.marks()
    }

    /**
     * this sets the marks for slider
     */
    marks =()=>{
        let marks = [];
        let allMark = {
            value: 0,
            label: "All"
        };
        marks.push(allMark);
        for(let i= 0;i<this.props.crosstalkLayers.length; i++)
        {   
           let mark = {}
           mark["value"] = this.props.crosstalkLayers.indexOf(this.props.crosstalkLayers[i]) +1
           mark["label"] = this.props.crosstalkLayers[i]
           marks.push(mark);
        }
        this.setState({marks: marks})
    }

    render(){

        const height = (this.props.crosstalkLayers.length + 1)  * 20
    
        return(
            <Tooltip  placement="top-start" title="Layers">
                <div
                style={
                    {
                        top:"45px",
                        marginLeft: "5px",
                        left:"0px",
                        position:"absolute",
                        width: "27px",
                        height: `calc(${height}px)`,
                        display: this.props.displayLeftSlider,
                        borderRadius: "5px",
                    }
                }
                >
                    <Slider
                        orientation="vertical"
                        marks={this.state.marks != null? this.state.marks:0}
                        valueLabelDisplay={"off"}
                        track={false}
                        step={null}
                        min={0}
                        max={this.props.crosstalkLayers.length}
                        defaultValue={0}
                        value={this.props.newCrosstalkLayer !== undefined ? this.props.newCrosstalkLayer : 0}
                        onChange={this.props.onCrosstalkDominantLayerChange}
                    />
                </div>
            </Tooltip>
        );
    }
}

export default HeatmapCrosstalkDominantLayerSlider;
