import React, { Component } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Canvas from "./canvas";
import { produce } from "immer";
import TaskSelector from "./taskSelector";
import NavBar2 from "./ZoomNavBar";
// utility imprts
import _ from "lodash";
import { drawAllTimingPaths } from "../LayoutViewApis";

import useGlobalStore from "../../../store/useGlobalStore";

class FlowContainer extends Component {
  state = {
    zoomIn: false,
    zoomOut: false,
    canvasKey: 1,
    contextMenu: { Xpos: 0, Ypos: 0 },
    heatmapSideNavwidth: "0px",
    taskSelected: 0,
  };

  constructor(props) {
    super(props);
    // this.state = {
    //   taskSelected: 0, //all timing paths
    // };
    this.canvas = React.createRef();
    this.handleNavBarSelect = this.handleNavBarSelect.bind(this);
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      const config = this.props.config;
      this.setState({
        dataLocation: config.dataLocation,
        bucket: config.bucket,
      });
    }
    // Draw all timing paths by default
    if (
      !this.props.timingPath ||
      (this.props.timingPath && this.props.timingPath.length === 0)
    ) {
      drawAllTimingPaths(this.props.id, this.props.config);
    }
  }

  /**
   * To handle right click on canvas
   * sets name of the component
   * to perform futher context menu actions
   * @param {rightClikEvent} e
   */
  handleContextMenu = (name, e) => {
    if (e !== undefined && e != null)
      this.setState({
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * To handle hot key press
   * @param {key Pressed} key
   */
  handleKeyPress = (key) => {
    if (key === "z") {
      this.setState({ zoomIn: true, zoomOut: false });
    } else if (key === "Z") {
      this.setState({ zoomOut: true, zoomIn: false });
    } else if (key === "f") {
      //delete previous zoom settings
      const config = produce(this.props.config, (configDraft) => {
        delete configDraft.zoom;
      });
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
      this.setState({ zoomIn: false, zoomOut: false, canvasKey: Date.now() });
    }
  };

  handleTaskChange = (event, indexValue) => {
    this.setState({ taskSelected: indexValue });
  };

  handleTimingPath = () => {
    if (this.state.taskSelected != 0 && this.props.timingPath && this.props.timingPath.length > 0) {
      return [this.props.timingPath[this.state.taskSelected - 1]];
    } else {
      return this.props.timingPath;
    }
  };

  handleHeatmapContextMenu = () => {};

  /**
   * To handle the selection of tool
   * from navigation bar and sub menu
   * of heatmap
   * @param {name of the tool} name
   */
  handleNavBarSelect = (name, event) => {
    if (name === "zoomIn" && event.target.checked) {
      this.setState({
        zoomIn: true,
        zoomOut: false,
      });
    } else if (name === "zoomOut" && event.target.checked) {
      this.setState({
        zoomIn: false,
        zoomOut: true,
      });
    } else if (
      (name === "zoomOut" || name === "zoomIn") &&
      !event.target.checked
    ) {
      this.setState({
        [name]: false,
      });
    }
  };

  render() {
    return (
      <React.Fragment>
        <div
          id="canvas"
          tabIndex="0"
          // onKeyPress={(e) => {  // Handled in canvas for all container
          //   console.log(e.key);
          //   this.handleKeyPress(e.key);
          // }}
          style={{
            width: "100%",
            height: "90%",
            overflow: "hidden",
            position: "relative",
          }}
        >
          <Canvas
            ref={this.canvas}
            key={this.state.canvasKey}
            id={this.props.id}
            isLoading={this.props.isLoading}
            isLoading2={this.props.isLoading2}
            board={this.props.board}
            ports={this.props.ports}
            macros={this.props.macros}
            blocks={this.props.blocks}
            heatmapPacthes={this.props.heatmapPacthes}
            showHeatmap={this.props.showHeatmap}
            handleContextMenu={this.handleContextMenu}
            handleHeatmapContextMenu={this.handleHeatmapContextMenu}
            colorCodes={this.props.colorCodes}
            showHeatmapPatch={this.props.showHeatmapPatch}
            timingPath={this.handleTimingPath()}
            handlePatchContextMenu={this.handlePatchContextMenu}
            zoomIn={this.state.zoomIn}
            zoomOut={this.state.zoomOut}
            handleKeyPress={this.handleKeyPress}
          />
          {/**Navigation bar */}
          <NavBar2
            onMenuSelect={this.handleNavBarSelect}
            zoomIn={this.state.zoomIn}
            zoomOut={this.state.zoomOut}
            selected={this.props.selected}
          />
          <TaskSelector
            onTaskChange={this.handleTaskChange}
            taskSelected={this.state.taskSelected}
            selected={this.props.selected}
            theme={this.props.theme}
            taskInfo={_.get(this.props.config, "taskInfo", [])}
          />
          {/**Loading progress on data fetch */}
          {this.props.isLoading || this.props.isLoading2 ? (
            <div
              style={{
                margin: "auto",
                position: "absolute",
                top: "50%",
                left: "50%",
              }}
            >
              <CircularProgress />
            </div>
          ) : null}
        </div>
      </React.Fragment>
    );
  }
}

export default FlowContainer;
