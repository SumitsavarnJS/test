import React, { Component } from "react";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Tooltip from "@mui/material/Tooltip";
import { Checkbox } from "@mui/material";
// import DynamicEnable from "/images/LayoutImages/dynamicEnable.png";
// // import DynamicDisable from "/images/LayoutImages/dynamicDisable.png";
// import InternalEnable from "/images/LayoutImages/internalEnable.png";
// // import InternalDisable from "/images/LayoutImages/internalDisable.png";
// import LeakEnable from "/images/LayoutImages/leakEnable.png";
// // import LeakDisable from "/images/Layout/Images/leakDisable.png";
// // import CongestionEnable from "/images/LayoutImages/congestionEnable.png";
// // import CongestionDisable from "/images/LayoutImages/congestionDisable.png";
// import HeatmapPatchEnable from "/images/LayoutImages/HeatmapPatchEnable.png";
// // import HeatmapPatchDisable from "/images/LayoutImages/HeatmapPatchDisable.png";
// import pinDensityEnable from "/images/LayoutImages/pinDensityEnable.png";
// // import pinDensityDisable from "/images/LayoutImages/pinDensityDisable.png";
// import cellDensityEnable from "/images/LayoutImages/cellDensityEnable.png";
// // import cellDensityDisable from "/images/LayoutImages/cellDensityDisable.png";
// import netDensity from "/images/LayoutImages/netDensity.png";
// // import netEnable from "/images/LayoutImages/netEnable.png";
// // import netDisable from "/images/LayoutImages/netDisable.png";
import TimelineIcon from "@mui/icons-material/Timeline";
import ClearIcon from "@mui/icons-material/Clear";
import ViewComfyIcon from "@mui/icons-material/ViewComfy";
import BorderClearIcon from "@mui/icons-material/BorderClear";

class HeatmapNavBar extends Component {
  render() {
    return (
      <div
        id="heatmapConfig"
        style={{
          height: "auto",
          // width: this.props.heatmapSideNavwidth,
          position: "absolute",
          zIndex: 1,
          top: 0,
          right: 0,
          backgroundColor: "transparent",
          display:
             this.props.showHeatmapSideNav
              ? "flex"
              : "none",
          transition: "0.3s",
          marginRight: "40px",
          paddingTop: "68px",
        }}
      >
        <FormGroup column>
          <FormGroup row>
            <Tooltip title="Cell internal" placement="top">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    disabled={this.props.cell_internal_active}
                    checked={this.props.cell_internal}
                    onChange={this.props.onMenuSelect("cell_internal")}
                    icon={
                      <img
                        src={"images/LayoutImages/internalEnable.png"}
                        alt="Internal Disabled"
                        style={{ height: "24px" }}
                      />
                    }
                    checkedIcon={
                      <img
                        src={"images/LayoutImages/internalEnable.png"}
                        alt="Internal Enabled"
                        style={{ height: "24px" }}
                      />
                    }
                    value="cell_internal"
                  />
                }
                label=""
              />
            </Tooltip>
            <Tooltip title="Leakage" placement="top">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    disabled={this.props.cell_leakage_active}
                    checked={this.props.leak}
                    onChange={this.props.onMenuSelect("leak")}
                    icon={
                      <img
                        src={"images/LayoutImages/leakEnable.png"}
                        alt="Leak Disabled"
                        style={{ height: "24px" }}
                      />
                    }
                    checkedIcon={
                      <img
                        src={"images/LayoutImages/leakEnable.png"}
                        alt="Leak Enabled"
                        style={{ height: "24px" }}
                      />
                    }
                    value="leak"
                  />
                }
                label=""
              />
            </Tooltip>
            <Tooltip title="Total Dynamic" placement="top">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    checked={this.props.totalDynamic}
                    onChange={this.props.onMenuSelect("totalDynamic")}
                    icon={
                      <img
                        src={"images/LayoutImages/dynamicEnable.png"}
                        alt="Dynamic disabled"
                        style={{ height: "24px" }}
                      />
                    }
                    checkedIcon={
                      <img
                        src={"images/LayoutImages/dynamicEnable.png"}
                        alt="Dynamic Enabled"
                        style={{ height: "24px" }}
                      />
                    }
                    value="totalDynamic"
                  />
                }
                label=""
              />
            </Tooltip>
          </FormGroup>

          {/**Congestion */}
          <FormGroup row>
            <Tooltip title="Congestion" placement="bottom">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    checked={this.props.congestion}
                    onChange={this.props.onMenuSelect("congestion")}
                    icon={<BorderClearIcon size="small" />}
                    checkedIcon={
                      <BorderClearIcon color={"primary"} size="small" />
                    }
                    value="congestion"
                  />
                }
                label=""
              />
            </Tooltip>

            <Tooltip title="Congestion Patch" placement="bottom">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    checked={this.props.congestionPatch}
                    onChange={this.props.onMenuSelect("congestionPatch")}
                    icon={
                      <img
                        src={"images/LayoutImages/HeatmapPatchEnable.png"}
                        alt="congestion patch disabled"
                        style={{ height: "24px" }}
                      />
                    }
                    checkedIcon={
                      <img
                        src={"images/LayoutImages/HeatmapPatchEnable.png"}
                        alt="congestion patch Enabled"
                        style={{ height: "24px" }}
                      />
                    }
                    value="congestionPatch"
                  />
                }
                label=""
              />
            </Tooltip>

            <Tooltip title="Pin Density" placement="bottom">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    checked={this.props.pinDensity}
                    onChange={this.props.onMenuSelect("pinDensity")}
                    icon={
                      <img
                        src={"images/LayoutImages/pinDensityEnable.png"}
                        alt="density disabled"
                        style={{ height: "24px" }}
                      />
                    }
                    checkedIcon={
                      <img
                        src={"images/LayoutImages/pinDensityEnable.png"}
                        alt="density Enabled"
                        style={{ height: "24px" }}
                      />
                    }
                    value="pinDensity"
                  />
                }
                label=""
              />
            </Tooltip>

            <Tooltip title="Net Density" placement="bottom">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    checked={this.props.pinDensity}
                    onChange={this.props.onMenuSelect("netDensity")}
                    icon={
                      <img
                        src={"images/LayoutImages/netDensity.png"}
                        alt="density disabled"
                        style={{ height: "24px" }}
                      />
                    }
                    checkedIcon={
                      <img
                        src={"images/LayoutImages/netDensity.png"}
                        alt="density Enabled"
                        style={{ height: "24px" }}
                      />
                    }
                    value="pinDensity"
                  />
                }
                label=""
              />
            </Tooltip>
          </FormGroup>

          {/**Timing */}
          <FormGroup row>
            {/**is data is post route then it will be shown */}
            <Tooltip title="Timing" placement="bottom">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    checked={this.props.crosstalkHeatmap}
                    onChange={this.props.onMenuSelect("crosstalkHeatmap")}
                    icon={<TimelineIcon size="small" />}
                    checkedIcon={<TimelineIcon size="small" />}
                    value="crosstalkHeatmap"
                  />
                }
                label=""
              />
            </Tooltip>
            {this.props.is_post_route ? (
              <Tooltip title="Crosstalk" placement="bottom">
                <FormControlLabel
                  control={
                    <Checkbox
                      fontSize="small"
                      checked={this.props.crosstalkPatch}
                      onChange={this.props.onMenuSelect("crosstalkPatch")}
                      icon={<ViewComfyIcon size="small" />}
                      checkedIcon={
                        <ViewComfyIcon color={"primary"} size="small" />
                      }
                      value="crosstalk"
                    />
                  }
                  label=""
                />
              </Tooltip>
            ) : null}
            <Tooltip title="Cell Density" placement="bottom">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    checked={this.props.cellDensity}
                    onChange={this.props.onMenuSelect("cellDensity")}
                    icon={
                      <img
                        src={"images/LayoutImages/cellDensityEnable.png"}
                        alt="density disabled"
                        style={{ height: "24px" }}
                      />
                    }
                    checkedIcon={
                      <img
                        src={"images/LayoutImages/cellDensityEnable.png"}
                        alt="density Enabled"
                        style={{ height: "24px" }}
                      />
                    }
                    value="cellDensity"
                  />
                }
                label=""
              />
            </Tooltip>
          </FormGroup>
          {this.props.is_post_route ? (
            <FormGroup row>
              <Tooltip title="DRC" placement="bottom">
                <FormControlLabel
                  control={
                    <Checkbox
                      fontSize="small"
                      onChange={this.props.onMenuSelect("DRC")}
                      value="DRC"
                      checkedIcon={<ClearIcon fontSize="small" />}
                      icon={<ClearIcon fontSize="small" />}
                      label=""
                    />
                  }
                />
              </Tooltip>
            </FormGroup>
          ) : null}
        </FormGroup>
      </div>
    );
  }
}

export default HeatmapNavBar;
