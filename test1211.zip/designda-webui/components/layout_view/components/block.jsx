import React, { Component } from "react";
import { Shape } from "react-konva";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class Block extends Component {

  render() {
    const { properties} = this.props;
    return (
      <React.Fragment>
        <Shape
          perfectDrawEnabled={false}
          batchDraw={true}
          sceneFunc={(context, shape) => {
            context.beginPath();
            for (let i = 0; i < properties.coordinates.length; i++) {
              context.lineTo(
                properties.coordinates[i][1],
                properties.coordinates[i][0]
              );
            }
            context.closePath();
            context.fillStrokeShape(shape);
          }}
          fill="#1F618D"
	        opacity={0.6}
          onContextMenu={(e) => {
            e.evt.preventDefault();
          }}
        />
      </React.Fragment>
    );
  }
}

export default Block;

