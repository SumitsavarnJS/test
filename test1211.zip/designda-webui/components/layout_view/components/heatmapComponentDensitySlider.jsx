import React, { Component } from "react";
import Slider from "@mui/material/Slider";
import Tooltip from "@mui/material/Tooltip";

class HeatmapComponentDensitySlider extends Component {
  render() {
    const marksPatch = [
      {
        value: 0,
        label: "all",
      },
      {
        value: 1,
        label: "boundary",
      },
      {
        value: 2,
        label: "buf_inv",
      },
      {
        value: 3,
        label: "combo",
      },
      {
        value: 4,
        label: "complex_combo",
      },
      {
        value: 5,
        label: "icg",
      },
      {
        value: 6,
        label: "latch",
      },
      {
        value: 7,
        label: "level_shifter",
      },
      {
        value: 8,
        label: "power_switch",
      },
      {
        value: 9,
        label: "sequential",
      },
    ];

    return (
      <Tooltip placement="top-start" title="Type">
        <div
          style={{
            bottom: "30px",
            marginLeft: "5px",
            left: "0px",
            position: "absolute",
            width: "27px",
            height: "175px",
            borderRadius: "5px",
            display: this.props.displayLeftSlider,
          }}
        >
          <Slider
            orientation="vertical"
            marks={marksPatch}
            step={null}
            track={false}
            min={0}
            max={9}
            valueLabelDisplay={"off"}
            value={
              this.props.componentTypeValue ? this.props.componentTypeValue : 0
            }
            onChange={(event, value) => {
              this.props.onComponentDensityValueChange(event, value);
            }}
          />
        </div>
      </Tooltip>
    );
  }
}

export default HeatmapComponentDensitySlider;
