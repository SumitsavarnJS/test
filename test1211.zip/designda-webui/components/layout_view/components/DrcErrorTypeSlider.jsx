import React, { Component } from "react";
import Slider from "@mui/material/Slider";
import Tooltip from "@mui/material/Tooltip";

class DrcErrorTypeSlider extends Component {
  getMarks = () => {
    let marks = [{ label: "All", value: 0 }];
    const top5errors = this.props.drcErrorTypeList.slice(0, 5).reverse();
    if (!top5errors.includes("Short")) {
      if (top5errors.length < 5) {
        for (let i = 0; i < top5errors.length; i++) {
          marks.push({ label: top5errors[i].slice(0, 6), value: i + 1 });
        }
      } else {
        marks.push({ label: "Short", value: 1 });
        for (let i = 1; i < top5errors.length; i++) {
          marks.push({ label: top5errors[i].slice(0, 6), value: i + 1 });
        }
      }
    } else {
      for (let i = 0; i < top5errors.length; i++) {
        marks.push({ label: top5errors[i].slice(0, 6), value: i + 1 });
      }
    }
    return marks;
  };

  getTooltipMarks = () => {
    let marks = [{ label: "All", value: 0 }];
    const top5errors = this.props.drcErrorTypeList.slice(0, 5).reverse();
    if (!top5errors.includes("Short")) {
      if (top5errors.length < 5) {
        for (let i = 0; i < top5errors.length; i++) {
          marks.push({ label: top5errors[i], value: i + 1 });
        }
      } else {
        marks.push({ label: "Short", value: 1 });
        for (let i = 1; i < top5errors.length; i++) {
          marks.push({ label: top5errors[i], value: i + 1 });
        }
      }
    } else {
      for (let i = 0; i < top5errors.length; i++) {
        marks.push({ label: top5errors[i], value: i + 1 });
      }
    }
    return marks;
  };

  render() {
    const marks = this.getMarks();
    const height = marks.length * 12;
    return (
      <div
        style={{
          bottom: "30px",
          marginLeft: "5px",
          right: "50px",
          position: "absolute",
          width: "27px",
          height: `${height}px`,
          borderRadius: "5px",
          display:  this.props.displayLeftSlider,
        }}
      >
        <Tooltip
          open={this.props.selected}
          placement="top-start"
          title={this.getTooltipMarks()[this.props.drcErrorType].label}
        >
          <Slider
            orientation="vertical"
            marks={marks}
            step={null}
            track={false}
            min={0}
            max={marks.length - 1}
            valueLabelDisplay={"off"}
            value={this.props.drcErrorType}
            onChange={this.props.handleDrcErrorType}
          />
        </Tooltip>
      </div>
    );
  }
}

export default DrcErrorTypeSlider;
