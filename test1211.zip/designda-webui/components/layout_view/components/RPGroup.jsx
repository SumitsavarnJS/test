import React, { Component } from "react";
import { Rect } from "react-konva";

/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class RPGroup extends Component {
  render() {
    const { properties, stageScale } = this.props;
    return (
      <React.Fragment>
        <Rect
          x={properties.lly}
          y={properties.llx}
          width={properties.height}
          height={properties.width}
          opacity={1}
          fill=""
          stroke={"#d1b449"}
          strokeWidth={2 / stageScale}
        />
      </React.Fragment>
    );
  }
}

export default RPGroup;
