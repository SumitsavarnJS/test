import React, { Component } from "react";
import { connect } from "react-redux";
import { Stage, Layer } from "react-konva";
import Board from "./board";
import Macro from "./macros";
import Block from "./block";
import Ports from "./ports";
import TimingPath from "./timingPath";
import Shapes from "./shapesNet";
import Cell from "./cell";
import HeatMapLayer from "./heatMapLayer";
import CongestionPatch from "./congestion_patch";
import CrosstalkHeatmapLayer from "./heatmapCrosstalkLayer";
import HeatmapCellDensityLayer from "./heatmapCellDensityLayer";
import HeatmapPinDensityLayer from "./heatmapPinDensityLayer";
import HeatmapNetDensityLayer from "./heatmapNetDensityLayer";
import DRCHeatmap from "./drcHeatmap";
import LayoutTooltip from "./tooltip";
import ZoomFilter from "./ZoomFilter";
import PortDetail from "./portDetail";
import HeatmapInstanceLayer from "./heatmapInstanceLayer";
import DrcNet from "./dummyDrcNet";
import VoltageArea from "./voltageArea";
import RPBlockage from "./rp_blockage";
import RPGroup from "./RPGroup";

// import { setConfig, setTooltip } from "../LayoutViewApis";

// utility imprts
import _ from "lodash";

//import axios from "axios";

class Canvas extends Component {
  state = {
    stageScale: 1,
    initialStageScale: 1,
    stageX: 0,
    stageY: 0,
    originalFloorplanWidth: 0,
    originalFloorplanHeight: 0,
    stageWidth: window.innerWidth,
    stageHeight: window.innerHeight,
    offsetX: 0, //+ve to move down the origin
    offsetY: 0, //-ve to move right the origin
    // to get right orintation ,
    //all values in child components needs to switch x values with y and vice-versa
    rotation: 270,
    heatmaps: [],
    bucket: "",
    dataLocation: "",
    showTooltip: false,
    tooltipValue: "",
    tooltipX: 0,
    tooltipY: 0,
    filterX1: 0,
    filterX2: 0,
    filterY1: 0,
    filterY2: 0,
    localIsLoading: false,
  };

  resizeObserver = null;

  constructor(props) {
    super(props);
    this.stageNode = React.createRef();
    this.canvas = React.createRef();
    this.getRelativePointerPosition =
      this.getRelativePointerPosition.bind(this);
    this.handleShowTooltip = this.handleShowTooltip.bind(this);
    this.handleTooltipValue = this.handleTooltipValue.bind(this);
  }

  componentDidMount() {
    // const element = this.canvas.current;
    // element.addEventListener("resize", this.fitStageIntoParentContainer);
    // function checkResize(mutations) {
    //   const el = mutations[0].target;
    //   const w = el.clientWidth;
    //   const h = el.clientHeight;

    //   const isChange = mutations
    //     .map((m) => `${m.oldValue}`)
    //     .some(
    //       (prev) => prev.indexOf(`width: ${w}px`) === -1 || prev.indexOf(`height: ${h}px`) === -1
    //     );

    //   if (!isChange) {
    //     return;
    //   }
    //   const event = new CustomEvent("resize", {
    //     detail: { width: w, height: h },
    //   });
    //   el.dispatchEvent(event);
    // }
    // const observer = new MutationObserver(checkResize);
    // observer.observe(element, {
    //   attributes: true,
    //   attributeOldValue: true,
    //   attributeFilter: ["style"],
    // });
    this.resizeObserver = new ResizeObserver((entries) => {
      this.fitStageIntoParentContainer();
    });

    this.resizeObserver.observe(this.canvas.current);

    if (this.props.config !== undefined) {
      const config = this.props.config;
      this.setState({
        dataLocation: config.dataLocation,
        bucket: config.bucket,
      });
      // this.fitStageIntoParentContainer()
    }
  }

  // componentDidUpdate() {
  //   this.fitStageIntoParentContainer()
  // }

  componentWillUnmount() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
  }

  static getDerivedStateFromProps(props, state) {
    if (props.hasOwnProperty("draggableStage")) {
      return { draggableStage: props.draggableStage };
    } else {
      return { draggableStage: true };
    }
  }

  /**
   * to set origin such that the floorplan is displayed
   * at the center of the window irrespective
   * of the quadrants it is drawn
   */
  setOriginPosition = () => {
    let sortCoordinates = [...this.props.board.coordinates];
    var container = this.canvas.current;
    sortCoordinates.sort(function (a, b) {
      return a[0] - b[0];
    });
    let floorplanMidX =
      (sortCoordinates[sortCoordinates.length - 1][0] + sortCoordinates[0][0]) /
      2;
    let floorPlanMaxX =
      sortCoordinates[sortCoordinates.length - 1][0] - sortCoordinates[0][0];
    sortCoordinates.sort(function (a, b) {
      return a[1] - b[1];
    });
    let floorplanMidY =
      (sortCoordinates[sortCoordinates.length - 1][1] + sortCoordinates[0][1]) /
      2;
    let floorPlanMaxY =
      sortCoordinates[sortCoordinates.length - 1][1] - sortCoordinates[0][1];

    let minSideRatio =
      container.offsetWidth / floorPlanMaxX <
      container.offsetHeight / floorPlanMaxY
        ? container.offsetWidth / floorPlanMaxX
        : container.offsetHeight / floorPlanMaxY;

    let newScale = minSideRatio * 0.95;

    let shiftX = floorplanMidX * newScale - container.offsetWidth / 2;
    let shiftY = floorplanMidY * newScale + container.offsetHeight / 2;

    this.setState({
      originalFloorplanWidth: floorplanMidX * 2,
      originalFloorplanHeight: floorplanMidY * 2,
      stageY: shiftY,
      stageX: -shiftX,
      stageScale: newScale,
      minScale: newScale * 0.9,
    });
  };

  /**
   * To resize the stage canvas with the window
   * on resizing
   */
  fitStageIntoParentContainer = () => {
    var container = this.canvas.current;

    const changeMargin = 15;
    if (
      this.state.stageWidth - container.offsetWidth >= changeMargin ||
      this.state.stageHeight - container.offsetHeight >= changeMargin ||
      this.state.stageWidth - container.offsetWidth <= -changeMargin ||
      this.state.stageHeight - container.offsetHeight <= -changeMargin
    ) {
      this.setState({
        stageWidth: container.offsetWidth - 8,
        stageHeight: container.offsetHeight,
      });
      this.setOriginPosition();
    }
  };

  /**
   * To get the position relative to the
   * new origin (lower left corner)
   * of the plane after rotation and offsetX
   * @param {stageNode} node
   */
  getRelativePointerPosition() {
    const node = this.stageNode;

    var transform = node.getAbsoluteTransform().copy();
    // to detect relative position we need to invert transform
    transform.invert();

    // get pointer (say mouse or touch) position
    var pos = node.getStage().getPointerPosition();

    console.log(pos);
    if (pos != null) {
      // now we can find relative point
      const relativePos = transform.point(pos);
      this.setState({
        tooltipX: relativePos.x,
        tooltipY: relativePos.y,
      });
    }
  }

  getFilterRelativePointerPosition = () => {
    const node = this.stageNode;

    var transform = node.getAbsoluteTransform().copy();
    // to detect relative position we need to invert transform
    transform.invert();

    // get pointer (say mouse or touch) position
    var pos = node.getStage().getPointerPosition();
    // console.log(pos.x,pos.y)
    return transform.point(pos);
  };

  /**
   * to return filter in llx,lly,urx, ury format
   */
  getFilterdCoords = () => {
    const { filterX1, filterX2, filterY1, filterY2 } = this.state;
    let filteredCoords = { llx: 0, lly: 0, urx: 0, ury: 0 };
    // to set filter data in lower left and upper right format

    // if first coordinates are lower left and second corrdinates are upper right
    if (filterY1 < filterY2 && filterX1 < filterX2) {
      filteredCoords["llx"] = filterY1;
      filteredCoords["lly"] = filterX1;
      filteredCoords["urx"] = filterY2;
      filteredCoords["ury"] = filterX2;
    }
    // if first coordinates are upper left and second coordinates are lower right
    else if (filterY1 < filterY2 && filterX1 > filterX2) {
      filteredCoords["llx"] = filterY1;
      filteredCoords["lly"] = filterX2;
      filteredCoords["urx"] = filterY2;
      filteredCoords["ury"] = filterX1;
    }
    // if first coordinates are upper right and second coordinates are lower left
    else if (filterY1 > filterY2 && filterX1 > filterX2) {
      filteredCoords["llx"] = filterY2;
      filteredCoords["lly"] = filterX2;
      filteredCoords["urx"] = filterY1;
      filteredCoords["ury"] = filterX1;
    }
    // if first coordinates are lower right and second coordinates are upper left
    else if (filterY1 > filterY2 && filterX1 < filterX2) {
      filteredCoords["llx"] = filterY2;
      filteredCoords["lly"] = filterX1;
      filteredCoords["urx"] = filterY1;
      filteredCoords["ury"] = filterX2;
    }

    return filteredCoords;
  };

  /**
   * To pass filtered coordinates
   * to parent class
   */
  handleMouseUp = (e) => {
    if (this.props.enableZoomFilter) {
      this.props.handleZoomFilter(false);
      this.props.getFilteredData(this.getFilterdCoords());
      this.setState({
        filterX1: 0,
        filterX2: 0,
        filterY1: 0,
        filterY2: 0,
      });
    }
  };

  /**
   * To set initial coordinates for filter
   */

  handleMouseDown = (e) => {
    if (this.props.enableZoomFilter) {
      const pos = this.getFilterRelativePointerPosition();
      this.setState({
        filterX1: _.get(pos, "x", 0),
        filterY1: _.get(pos, "y", 0),
        filterX2: _.get(pos, "x", 0),
        filterY2: _.get(pos, "y", 0),
      });
    }
  };

  /**
   * To set diagonal coordinates of filter
   */
  handleMouseMove = (e) => {
    if (this.props.enableZoomFilter) {
      if (this.state.filterX1 || this.state.filterY1) {
        const pos = this.getFilterRelativePointerPosition();
        this.setState({
          filterX2: _.get(pos, "x", 0),
          filterY2: _.get(pos, "y", 0),
        });
      }
    }
  };

  activeZoom = (object) => {
    // Active Zoom
    let urx = this.state.originalFloorplanWidth;
    let ury = this.state.originalFloorplanHeight;
    let llx = 0;
    let lly = 0;
    if (
      object.y + object.height > 0 && // checking layout has not positioned beyond top bounderies
      object.y < this.state.stageHeight && // checking layout has not positioned beyond bottom bounderies
      object.x + object.width > 0 && // checking layout has not positioned beyond left bounderies
      object.x < this.state.stageWidth // checking layout has not positioned beyond right bounderies
    ) {
      // finding the relative ury and lly
      if (object.y < 0) {
        if (object.height + object.y > 0) {
          ury =
            this.state.originalFloorplanHeight -
            Math.abs(object.y) / this.state.stageScale; // case 1
        }
        if (this.state.stageHeight + Math.abs(object.y) < object.height) {
          lly =
            (object.height - this.state.stageHeight - object.y) /
            this.state.stageScale; // case 1
        }

        if (Math.abs(object.y) < object.height) {
          ury = (object.height + object.y) / this.state.stageScale; //case 3
          lly = 0; //case 3
        }
      }

      if (object.y > 0) {
        if (object.y < this.state.stageHeight) {
          ury = this.state.originalFloorplanHeight; //case 2
        }
      }

      if (object.y + object.height > this.state.stageHeight) {
        lly =
          (object.height - (this.state.stageHeight - object.y)) /
          this.state.stageScale; // case 2
      }

      // finding the relative urx and llx
      if (object.x + object.width > this.state.stageWidth) {
        urx = (this.state.stageWidth - object.x) / this.state.stageScale; //case 4
      }

      if (object.x > 0) {
        if (object.x < this.state.stageWidth) {
          llx = 0; //case 4
        }
      }

      if (
        object.x < 0 &&
        object.x + object.width > 0 &&
        object.x + object.width > this.state.stageWidth
      ) {
        urx = this.state.originalFloorplanWidth; //case 5
      }

      if (object.x < 0) {
        llx = 0 - object.x / this.state.stageScale; //case 5
      }

      if (object.x < 0 && object.x + object.width > this.state.stageWidth) {
        urx =
          (this.state.stageWidth + Math.abs(object.x)) / this.state.stageScale; //case 6
      }
    }
    console.log("urx:", urx, " ury:", ury, " llx:", llx, " lly:", lly);
    let filteredCoords = {};
    filteredCoords["llx"] = llx;
    filteredCoords["lly"] = lly;
    filteredCoords["urx"] = urx;
    filteredCoords["ury"] = ury;
    this.props.getFilteredData(filteredCoords);
  };

  /**
   * To handle the zoom by wheel and single click
   * @param {wheelEvent} e
   */
  handleZoom = (e) => {
    e.evt.preventDefault();
    // e.evt.stopImmediatePropagation();
    let localAZ =
      localStorage.getItem(`activeZoom${this.props.id}`) === "true"
        ? true
        : false;
    // console.log(typeof(localAZ));
    // console.log("ActiveZoom: ",localAZ, "Redux active zoom: ", this.props.config.activeZoom );
    if (
      !(
        this.props.isLoading ||
        this.props.isLoading2 ||
        this.state.localIsLoading
      ) ||
      !this.props.config.activeZoom
    ) {
      this.setState({ localIsLoading: true });
      let activeZoomFlag = false;
      const scaleBy = 2;
      let stage = e.target.getStage();
      if (typeof stage === "undefined") {
        stage = e.currentTarget.getStage(); //e.target will be null due to InstanceLayout mapping issue
      }
      const oldScale = stage.scaleX();
      const mousePointTo = {
        x: stage.getPointerPosition().x / oldScale - stage.x() / oldScale,
        y: stage.getPointerPosition().y / oldScale - stage.y() / oldScale,
      };
      // console.log("Original Width:", this.state.originalFloorplanWidth, "Height:", this.state.originalFloorplanHeight);
      // console.log("Stage width:", this.state.stageWidth, "Height:", this.state.stageHeight);
      // console.log("Mouse position: ", mousePointTo);

      let newScale = null;

      if (e.evt.constructor.name === "WheelEvent") {
        newScale = e.evt.deltaY < 0 ? oldScale * scaleBy : oldScale / scaleBy;
        activeZoomFlag = true;
      } else if (e.evt.constructor.name === "MouseEvent") {
        if (this.props.zoomIn) {
          newScale = oldScale * 2;
          activeZoomFlag = true;
        } else if (this.props.zoomOut) {
          newScale = oldScale / 2;
          activeZoomFlag = true;
        }
      }

      if (
        newScale != null &&
        newScale >= this.state.minScale &&
        newScale < 160
      ) {
        this.setState({
          stageScale: newScale,
          stageX:
            -(mousePointTo.x - stage.getPointerPosition().x / newScale) *
            newScale,
          stageY:
            -(mousePointTo.y - stage.getPointerPosition().y / newScale) *
            newScale,
        });
      }
      // console.log("StageScale:", this.state.stageScale);
      // console.log(stage.getClientRect());
      this.setState({ localIsLoading: false });
      if (
        activeZoomFlag &&
        this.props.config &&
        (this.props.config.activeZoom || localAZ)
      ) {
        this.activeZoom(stage.getClientRect());
      }
    }
    // let zoom = {};
    // zoom["stageX"] =
    //   -(mousePointTo.x - stage.getPointerPosition().x / newScale) * newScale;
    // zoom["stageY"] =
    //   -(mousePointTo.y - stage.getPointerPosition().y / newScale) * newScale;
    // zoom["stageScale"] = newScale;

    // const config = produce(this.props.config, (configDraft) => {
    //   configDraft["zoom"] = zoom;
    // });

    // this.props.setConfig({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    //   config: config,
    // });
  };

  /**
   * To save zoom config on drag end event
   * @param {drag event} e
   */
  handleDragZoomConfig = (e) => {
    let zoom = {};
    zoom["stageX"] = e.target.x();
    zoom["stageY"] = e.target.y();
    zoom["stageScale"] = this.state.stageScale;

    // const config = produce(this.props.config, (configDraft) => {
    //   configDraft["zoom"] = zoom;
    // });

    // this.props.setConfig({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    //   config: config,
    // });
    this.setState({
      stageX: e.target.x(),
      stageY: e.target.y(),
    });
  };

  handleTooltipValue = (value) => {
    this.setState({ tooltipValue: value });
    // this.props.setTooltip({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    //   tooltipValue: value,
    //   showTooltip: true,
    // })
  };

  handleShowTooltip = (flag) => {
    this.setState({ showTooltip: flag });
  };

  // handleKeyBoard = (e) => {
  //   if (e.key === 'Enter' || e.key === 'Escape') {
  //     this.handleShowTooltip(false);
  //     e.stopPropagation()
  //   }
  // };

  /**
   * To add hotkeys for zoom
   * @param {key press event} e
   */
  handleKeyPress = (e) => {
    let localAZ =
      localStorage.getItem(`activeZoom${this.props.id}`) === "true"
        ? true
        : false;
    if (e.key === "Enter" || e.key === "Escape") {
      this.handleShowTooltip(false);
      e.stopPropagation();
    } else if (e.key === "z") {
      this.props.handleKeyPress("z");
    } else if (e.key === "Z") {
      this.props.handleKeyPress("Z");
    } else if (e.key === "f") {
      this.props.handleKeyPress("f");
      this.setOriginPosition();
      if (this.props.config.activeZoom || localAZ) {
        let filteredCoords = {};
        filteredCoords["llx"] = 0;
        filteredCoords["lly"] = 0;
        filteredCoords["urx"] = this.state.originalFloorplanWidth;
        filteredCoords["ury"] = this.state.originalFloorplanHeight;
        this.props.getFilteredData(filteredCoords);
      }
    }
  };

  render() {
    // let background = "white";
    // if (this.props.theme === "dark") {
    //   background = "rgba(51,51,51,1)";
    // }
    return (
      <React.Fragment>
        <div
          ref={this.canvas}
          id="canvasChild"
          onKeyDown={(e) => {
            e.preventDefault();
            this.handleKeyPress(e);
          }}
          tabIndex="0"
          style={{
            width: "inherit",
            height: "inherit",
            position: "absolute",
            // background: background,
          }}
        >
          <Stage
            ref={(node) => {
              this.stageNode = node;
            }}
            onDragEnd={(e) => {
              this.handleDragZoomConfig(e);
            }}
            rotation={this.state.rotation}
            onWheel={this.handleZoom}
            draggable={this.state.draggableStage}
            onClick={this.handleZoom}
            offsetY={this.state.offsetY}
            offsetX={this.state.offsetX}
            scaleX={this.state.stageScale}
            scaleY={this.state.stageScale}
            width={this.state.stageWidth}
            height={this.state.stageHeight}
            x={this.state.stageX}
            y={this.state.stageY}
            onMouseDown={this.handleMouseDown}
            onMouseUp={this.handleMouseUp}
            onMouseMove={this.handleMouseMove}
            onContextMenu={(e) => {
              if (e.target.constructor.name === "Stage")
                this.props.handleContextMenu(null);
              this.props.handleHeatmapContextMenu(null);
            }}
          >
            {/**Floor plan */}
            <Layer listening={false} ref={(node) => (this.board = node)}>
              {this.props.board !== undefined ? (
                <Board
                  key={this.props.board.id}
                  board={this.props.board}
                  theme={this.props.theme}
                />
              ) : null}
              {/* </Layer> */}

              {/**Floor plan components */}
              {/* <Layer> */}

              {this.props.voltageArea !== undefined &&
              this.props.voltageArea.length > 0
                ? this.props.voltageArea.map((va) => (
                    <VoltageArea
                      key={this.props.voltageArea.indexOf(va)}
                      voltageArea={va}
                      stageScale={this.state.stageScale}
                    />
                  ))
                : null}
              {this.props.RPGroup !== undefined && this.props.RPGroup.length > 0
                ? this.props.RPGroup.map((rpg) => (
                    <RPGroup
                      key={this.props.RPGroup.indexOf(rpg)}
                      properties={rpg}
                      stageScale={this.state.stageScale}
                    />
                  ))
                : null}

              {this.props.RPBlockage !== undefined &&
              this.props.RPBlockage.length > 0
                ? this.props.RPBlockage.map((rp) => (
                    <RPBlockage
                      key={this.props.RPBlockage.indexOf(rp)}
                      properties={rp}
                    />
                  ))
                : null}

              {this.props.ports !== undefined && this.props.ports.length > 0
                ? this.props.ports.map((port) =>
                    port.height * this.state.stageScale > 1 &&
                    port.width * this.state.stageScale > 1 ? (
                      <Ports
                        key={this.props.ports.indexOf(port)}
                        properties={port}
                      />
                    ) : null
                  )
                : null}
              {this.props.blocks !== undefined && this.props.blocks.length > 0
                ? this.props.blocks.map((block) => (
                    <Block
                      key={this.props.blocks.indexOf(block)}
                      properties={block}
                    />
                  ))
                : null}
              {this.props.macros !== undefined && this.props.macros.length > 0
                ? this.props.macros.map((macro) => (
                    <Macro
                      key={this.props.macros.indexOf(macro)}
                      properties={macro}
                      stageScale={this.state.stageScale}
                    />
                  ))
                : null}
            </Layer>

            {/** Heatmap layers*/}
            <Layer>
              {this.props.port !== undefined && this.props.port.length > 0
                ? this.props.port.map((_port) => (
                    <PortDetail
                      key={this.props.port.indexOf(_port)}
                      properties={_port}
                      stageScale={this.state.stageScale}
                    />
                  ))
                : null}

              {this.props.cells !== undefined && this.props.cells.length > 0
                ? this.props.cells.map((cell) => (
                    <Cell
                      key={this.props.cells.indexOf(cell)}
                      properties={cell}
                      stageScale={this.state.stageScale}
                      handleShowTooltip={this.handleShowTooltip}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      handleTooltipValue={this.handleTooltipValue}
                    />
                  ))
                : null}
              {this.props.showHeatmap &&
              this.props.heatmaps &&
              this.props.heatmaps != null &&
              this.props.heatmaps.length > 0
                ? this.props.heatmaps.map((heatMap) =>
                    heatMap[4] >= this.props.newHideShowValue[0] &&
                    heatMap[4] <= this.props.newHideShowValue[1] ? (
                      <HeatMapLayer
                        key={this.props.heatmaps.indexOf(heatMap)}
                        properties={heatMap}
                        handleShowTooltip={this.handleShowTooltip}
                        handleTooltipValue={this.handleTooltipValue}
                        getRelativePointerPosition={
                          this.getRelativePointerPosition
                        }
                        ContextMenu={this.props.handleHeatmapContextMenu}
                        colorCodes={this.props.colorCodes}
                        zoomIn={this.props.zoomIn}
                        zoomOut={this.props.zoomOut}
                      />
                    ) : null
                  )
                : null}

              {this.props.showHeatmapPatch &&
              this.props.heatmapPacthes !== undefined &&
              this.props.heatmapPacthes.length > 0
                ? this.props.heatmapPacthes.map((patch) => (
                    <CongestionPatch
                      key={this.props.heatmapPacthes.indexOf(patch)}
                      properties={patch}
                      handleShowTooltip={this.handleShowTooltip}
                      handleTooltipValue={this.handleTooltipValue}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      colorCodes={this.props.colorCodes}
                      ContextMenu={this.props.handlePatchContextMenu}
                      getPointerPosition={this.props.getRelativePointerPosition}
                      setPointerPosition={this.state.pointerPosition}
                      stageScale={this.state.stageScale}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}
              {this.props.showHeatmap &&
              this.props.crosstalkPatches &&
              this.props.crosstalkPatches.length > 0
                ? this.props.crosstalkPatches.map((patch) => (
                    <CrosstalkHeatmapLayer
                      key={this.props.crosstalkPatches.indexOf(patch)}
                      colorCodes={this.props.colorCodes}
                      handleShowTooltip={this.handleShowTooltip}
                      handleTooltipValue={this.handleTooltipValue}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      newCrosstalkLayer={this.props.newCrosstalkLayer}
                      crosstalkValue={this.props.crosstalkValue}
                      ContextMenu={this.props.crosstalkContextMenu}
                      properties={patch}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}
              {this.props.showHeatmap &&
              this.props.drcHeatmap &&
              this.props.drcHeatmap.length > 0
                ? this.props.drcHeatmap.map((bbox) => (
                    <DRCHeatmap
                      key={this.props.drcHeatmap.indexOf(bbox)}
                      handleShowTooltip={this.handleShowTooltip}
                      handleTooltipValue={this.handleTooltipValue}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      drcNetTypeList={this.props.drcNetTypeList}
                      drcLayersList={this.props.drcLayersList}
                      drcErrorTypeList={this.props.drcErrorTypeList}
                      stageScale={this.state.stageScale}
                      layer={this.props.drcLayer}
                      netType={this.props.drcNetType}
                      drcErrorType={this.props.drcErrorType}
                      ContextMenu={this.props.crosstalkContextMenu}
                      properties={bbox}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}

              {this.props.showHeatmap &&
              this.props.cellDensityHeatmap &&
              this.props.cellDensityHeatmap != null &&
              this.props.cellDensityHeatmap.length > 0
                ? this.props.cellDensityHeatmap.map((bbox_id) => (
                    <HeatmapCellDensityLayer
                      key={this.props.cellDensityHeatmap.indexOf(bbox_id)}
                      handleShowTooltip={this.handleShowTooltip}
                      handleTooltipValue={this.handleTooltipValue}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      componentTypeValue={this.props.componentTypeValue}
                      ContextMenu={this.props.crosstalkContextMenu}
                      properties={bbox_id}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}

              {this.props.showHeatmap &&
              this.props.pinDensityHeatmap &&
              this.props.pinDensityHeatmap != null &&
              this.props.pinDensityHeatmap.length > 0
                ? this.props.pinDensityHeatmap.map((bbox_id) => (
                    <HeatmapPinDensityLayer
                      key={this.props.pinDensityHeatmap.indexOf(bbox_id)}
                      handleShowTooltip={this.handleShowTooltip}
                      handleTooltipValue={this.handleTooltipValue}
                      colorCodes={this.props.colorCodes}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      ContextMenu={this.props.crosstalkContextMenu}
                      properties={bbox_id}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}

              {this.props.showHeatmap &&
              this.props.netDensityHeatmap &&
              this.props.netDensityHeatmap != null &&
              this.props.netDensityHeatmap.length > 0
                ? this.props.netDensityHeatmap.map((bbox_id) => (
                    <HeatmapNetDensityLayer
                      key={this.props.netDensityHeatmap.indexOf(bbox_id)}
                      handleShowTooltip={this.handleShowTooltip}
                      handleTooltipValue={this.handleTooltipValue}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      layersList={this.props.netDensityLayers}
                      netDensityLayer={this.props.netDensityLayer}
                      // ContextMenu={this.props.crosstalkContextMenu}
                      properties={bbox_id}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}

              {this.props.shapes !== undefined && this.props.shapes.length > 0
                ? this.props.shapes.map((path) => (
                    <Shapes
                      key={this.props.shapes.indexOf(path)}
                      colorPicker={this.props.shapes.indexOf(path)}
                      // handleShowTooltip={this.handleShowTooltip}
                      // handleTooltipValue={this.handleTooltipValue}
                      // getRelativePointerPosition={
                      //   this.getRelativePointerPosition
                      // }
                      theme={this.props.theme}
                      properties={path}
                      stageScale={this.state.stageScale}
                      stageNode={this.stageNode}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}

              {this.props.DRC_net !== undefined && this.props.DRC_net.length > 0
                ? this.props.DRC_net.map((path) => (
                    <DrcNet
                      key={this.props.DRC_net.indexOf(path)}
                      colorPicker={this.props.DRC_net.indexOf(path)}
                      handleShowTooltip={this.handleShowTooltip}
                      handleTooltipValue={this.handleTooltipValue}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      theme={this.props.theme}
                      properties={path}
                      stageScale={this.state.stageScale}
                      stageNode={this.stageNode}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}

              {this.props.instComponents !== undefined &&
              this.props.instComponents.length > 0
                ? this.props.instComponents.map((component) =>
                    component.map((path) => (
                      <HeatmapInstanceLayer
                        key={Math.random()} // (Encountered two children with the same key issue), handling in the "handlZoom" function, e.target becomes e.currentTarget
                        colorPicker={this.props.instComponents.indexOf(
                          component
                        )}
                        handleShowTooltip={this.handleShowTooltip}
                        handleTooltipValue={this.handleTooltipValue}
                        getRelativePointerPosition={
                          this.getRelativePointerPosition
                        }
                        theme={this.props.theme}
                        instanceToolTip={this.props.instanceToolTip}
                        properties={path}
                        stageScale={this.state.stageScale}
                        stageNode={this.stageNode}
                        zoomIn={this.props.zoomIn}
                        zoomOut={this.props.zoomOut}
                      />
                    ))
                  )
                : null}

              {this.props.timingPath !== undefined &&
              this.props.timingPath.length > 0
                ? this.props.timingPath.map((path) => (
                    <TimingPath
                      key={this.props.timingPath.indexOf(path)}
                      colorPicker={this.props.timingPath.indexOf(path)}
                      handleShowTooltip={this.handleShowTooltip}
                      handleTooltipValue={this.handleTooltipValue}
                      getRelativePointerPosition={
                        this.getRelativePointerPosition
                      }
                      theme={this.props.theme}
                      properties={path}
                      stageScale={this.state.stageScale}
                      stageNode={this.stageNode}
                      zoomIn={this.props.zoomIn}
                      zoomOut={this.props.zoomOut}
                    />
                  ))
                : null}
              {this.props.enableZoomFilter ? (
                <ZoomFilter
                  filterX1={this.state.filterX1}
                  filterX2={this.state.filterX2}
                  filterY1={this.state.filterY1}
                  filterY2={this.state.filterY2}
                />
              ) : null}
              {this.state.showTooltip ? (
                <LayoutTooltip
                  tooltipValue={this.state.tooltipValue}
                  x={this.state.tooltipX}
                  y={this.state.tooltipY}
                  rotation={this.state.rotation}
                  stageScale={this.state.stageScale}
                  handleTooltipClick={this.props.handleTooltipClick}
                />
              ) : null}
            </Layer>
          </Stage>
        </div>
      </React.Fragment>
    );
  }
}

export default Canvas;
