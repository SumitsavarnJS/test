import React, { Component } from "react";
import { Line } from "react-konva";

/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y coordinate and vice versa
 * every widht is height and vice versa
 */
class Board extends Component {
  render() {
    const { board } = this.props;
    let color = "#D0D3D4"
    if(this.props.theme === "dark")
    {
      color = "#283747"
    }
    return (
      // <Shape
      //   sceneFunc={(context, shape) => {
      //     context.beginPath();
      //     for (let i = 0; i < board.coordinates.length; i++) {
      //       context.lineTo(board.coordinates[i][1], board.coordinates[i][0]);
      //     }
      //     context.closePath();
      //     context.fillStrokeShape(shape);
      //   }}
      //   fill="#D0D3D4"
      // />
      <Line
        points={board.coordinates.flatMap((item) => [item[1], item[0]])}
        fill={color}
        closed={true}
      />
    );
  }
}

export default Board;
