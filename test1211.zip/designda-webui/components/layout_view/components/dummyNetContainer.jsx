import React, { Component } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Canvas from "./canvas";
import NavBar2 from "./ZoomNavBar";
import {drawDRCNet } from '../LayoutViewApis'
// utility imprts
import _ from "lodash";

class DummyNetContainer extends Component {
  state = {
    zoomIn: false,
    zoomOut: false,
    canvasKey: 1,
    contextMenu: { Xpos: 0, Ypos: 0 },
    heatmapSideNavwidth: "0px",
    taskSelected: 0,
  };

  constructor(props) {
    super(props);
    this.canvas = React.createRef();
    this.handleNavBarSelect = this.handleNavBarSelect.bind(this);
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      const config = this.props.config;
      this.setState({
        dataLocation: config.dataLocation,
        bucket: config.bucket,
      });
  

      
    }
    // this.props.getTimingpathSummary(this.props.config.timingpath);
    //draws net 
    this.getNet();
   
  }

  /**
   * To handle right click on canvas
   * sets name of the component
   * to perform futher context menu actions
   * @param {rightClikEvent} e
   */
  handleContextMenu = (name, e) => {
    if (e !== undefined && e != null)
      this.setState({
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * To handle hot key press
   * @param {key Pressed} key
   */
  handleKeyPress = (key) => {
    if (key === "z") {
      this.setState({ zoomIn: true, zoomOut: false });
    } else if (key === "Z") {
      this.setState({ zoomOut: true, zoomIn: false });
    } else if (key === "f") {
      this.setState({ zoomIn: false, zoomOut: false, canvasKey: Date.now() });
    }
  };

  getNet = () => {
    console.log("CONFIG",this.props.config)
    drawDRCNet(
      this.props.id,
      this.props.config
    );
  };


  /**
   * To handle the selection of tool
   * from navigation bar and sub menu
   * of heatmap
   * @param {name of the tool} name
   */
  handleNavBarSelect = (name, event) => {
    if (name === "zoomIn" && event.target.checked) {
      this.setState({
        zoomIn: true,
        zoomOut: false,
      });
    } else if (name === "zoomOut" && event.target.checked) {
      this.setState({
        zoomIn: false,
        zoomOut: true,
      });
    } else if (
      (name === "zoomOut" || name === "zoomIn") &&
      !event.target.checked
    ) {
      this.setState({
        [name]: false,
      });
    }
  };

  render() {
    const { summaryData } = this.props;
    // let background = "white";
    // let color = "black";
    // // if (this.props.theme === "dark") {
    //   // background = "rgba(51,51,51,1)";
    //   color = "white";
    // // }
    return (
      <React.Fragment>
        <div
          id="canvas"
          tabIndex="0"
          // onKeyPress={(e) => {   // Handled in canvas for all container
          //   this.handleKeyPress(e.key);
          // }}
          style={{
            width: "100%",
            height: "90%",
            overflowX: "auto",
            overflowY: "hidden",
            // background: background,
            // color: color,
            fontSize: 12
          }}
        >
          <div style={{ width: "100%", height: "90%"}}> 
            <Canvas
              ref={this.canvas}
              key={this.state.canvasKey}
              id={this.props.id}
              isLoading={this.props.isLoading}
              isLoading2={this.props.isLoading2}
              board={this.props.board}
              ports={this.props.ports}
              macros={this.props.macros}
              blocks={this.props.blocks}
              handleContextMenu={this.handleContextMenu}
              DRC_net={this.props.DRC_net}
              zoomIn={this.state.zoomIn}
              zoomOut={this.state.zoomOut}
              handleKeyPress={this.handleKeyPress}
            />
            {/**Navigation bar */}
            <NavBar2
              onMenuSelect={this.handleNavBarSelect}
              // heatmapActive={this.props.showHeatmap}
              // heamapNavBarOpen={this.state.heamapNavBarOpen}
              zoomIn={this.state.zoomIn}
              zoomOut={this.state.zoomOut}
              selected={this.props.selected}
            />
          </div>

          {/**Loading progress on data fetch */}
          {this.props.isLoading || this.props.isLoading2 ? (
            <div
              style={{
                margin: "auto",
                position: "absolute",
                top: "50%",
                left: "50%",
              }}
            >
              <CircularProgress />
            </div>
          ) : null}
        </div>
      </React.Fragment>
    );
  }
}


export default DummyNetContainer;
