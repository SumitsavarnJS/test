import React, { Component } from "react";
import { Line } from "react-konva";

/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y coordinate and vice versa
 * every widht is height and vice versa
 */
class VoltageArea extends Component {
  render() {
    const { voltageArea, stageScale } = this.props;
    let color = "#eeeac4";
    return (
      <Line
        points={voltageArea}
        strokeWidth={1}
        dashEnabled
        dash={[1]}
        stroke={color}
        opacity={1}
        closed={true}
      />
    );
  }
}

export default VoltageArea;
