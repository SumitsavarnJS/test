import React, { Component } from "react";
import { Rect, Star } from "react-konva";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class Cell extends Component {
  componentDidUpdate() {
    this.rectangle.clearCache();
  }

  showTooltip = () => {
    this.props.handleTooltipValue(
      `Density: ${this.props.properties.density}\nCell reference: ${this.props.properties.refName}\nTNS: ${this.props.properties.TNS}\nWNS: ${this.props.properties.WNS}`
    );
    this.props.handleShowTooltip(true);
    this.props.getRelativePointerPosition();
  };

  hideTooltip = () => {
    this.props.handleShowTooltip(false);
  };
  render() {
    const { properties, stageScale } = this.props;
    return (
      <React.Fragment>
        <Rect
          ref={(rectangle) => (this.rectangle = rectangle)}
          perfectDrawEnabled={false}
          batchDraw={true}
          x={properties.lly}
          y={properties.llx}
          width={properties.ury - properties.lly}
          height={properties.urx - properties.llx}
          stroke="black"
          strokeWidth={1 / stageScale}
          fill="#9B59B6"
          opacity={1}
          onMouseEnter={(e) => {
            this.showTooltip();
          }}
          onMouseLeave={(e) => {
            this.hideTooltip();
          }}
          onClick={this.showTooltip}
          onContextMenu={(e) => {
            e.evt.preventDefault();
            // this.props.onDriver(this.props.name, e);
          }}
        />
        {stageScale < 20 ? (
          <Star
            x={(properties.ury + properties.lly) / 2}
            y={(properties.urx + properties.llx) / 2}
            outerRadius={8 / stageScale}
            innerRadius={2 / stageScale}
            fill={"green"}
            numPoints={4}
          />
        ) : null}
      </React.Fragment>
    );
  }
}

export default Cell;
