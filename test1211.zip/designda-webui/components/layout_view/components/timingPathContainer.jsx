import React, { Component } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Canvas from "./canvas";
import NavBar2 from "./ZoomNavBar";
// utility imprts
import _ from "lodash";

import useGlobalStore from "../../../store/useGlobalStore";
import { getTimingPathCoordinates } from "../LayoutViewApis";

class TimingPathContainer extends Component {
  state = {
    zoomIn: false,
    zoomOut: false,
    canvasKey: 1,
    contextMenu: { Xpos: 0, Ypos: 0 },
    heatmapSideNavwidth: "0px",
    taskSelected: 0,
  };

  constructor(props) {
    super(props);
    this.canvas = React.createRef();
    this.handleNavBarSelect = this.handleNavBarSelect.bind(this);
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      const config = this.props.config;
      this.setState({
        dataLocation: config.dataLocation,
        bucket: config.bucket,
      });
    }
    const isTimingPathAvailable = useGlobalStore.getState()[this.props.id].data.hasOwnProperty("timingPaths");
    if(!isTimingPathAvailable){
      this.props.getTimingpathSummary(this.props.config.timingpath);
      //draw timing path
      this.getTimingPath();
    }
  }

  /**
   * To handle right click on canvas
   * sets name of the component
   * to perform futher context menu actions
   * @param {rightClikEvent} e
   */
  handleContextMenu = (name, e) => {
    if (e !== undefined && e != null)
      this.setState({
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * To handle hot key press
   * @param {key Pressed} key
   */
  handleKeyPress = (key) => {
    if (key === "z") {
      this.setState({ zoomIn: true, zoomOut: false });
    } else if (key === "Z") {
      this.setState({ zoomOut: true, zoomIn: false });
    } else if (key === "f") {
      //delete previous zoom settings
      //   const config = produce(this.props.config, (configDraft) => {
      //     delete configDraft.zoom;
      //   });
      //   this.props.setConfig({
      //     reportName: this.props.currentReportName,
      //     widgetId: this.props.id,
      //     config: config,
      //   });
      this.setState({ zoomIn: false, zoomOut: false, canvasKey: Date.now() });
    }
  };

  getTimingPath = () => {
    getTimingPathCoordinates(this.props.id, this.props.config, [
      this.props.config.timingpath,
    ]);
    // this.props.drawTimingPath(
    //   this.props.id,
    //   [this.props.config.timingpath],
    //   this.props.config.scenario,
    //   this.props.config.dataLocation,
    //   this.props.config.bucket
    // );
  };

  /**
   * To handle the selection of tool
   * from navigation bar and sub menu
   * of heatmap
   * @param {name of the tool} name
   */
  handleNavBarSelect = (name, event) => {
    if (name === "zoomIn" && event.target.checked) {
      this.setState({
        zoomIn: true,
        zoomOut: false,
      });
    } else if (name === "zoomOut" && event.target.checked) {
      this.setState({
        zoomIn: false,
        zoomOut: true,
      });
    } else if (
      (name === "zoomOut" || name === "zoomIn") &&
      !event.target.checked
    ) {
      this.setState({
        [name]: false,
      });
    }
  };

  render() {
    const { summaryData } = this.props;
    // let background = "white";
    // let color = "black";
    // // if (this.props.theme === "dark") {
    //   // background = "rgba(51,51,51,1)";
    //   color = "white";
    // // }

    let time = "Setup Time";

    const pathCategory = _.get(summaryData, "path_category", "");
    if (pathCategory.endsWith("Out")) {
      time = "Output external delay";
    }
    return (
      <React.Fragment>
        <div
          id="canvas"
          tabIndex="0"
          // onKeyPress={(e) => {   // Handled in canvas for all container
          //   this.handleKeyPress(e.key);
          // }}
          style={{
            width: "100%",
            // overflowX: "auto",
            // overflowY: "hidden",
         
            // background: background,
            // color: color,
            fontSize: 12,
          }}
        >
          <div
            style={{
              width: "45%",
              height: "100%",
              float: "left",
              fontSize: 14,
          
       
            }}
          >
            <div style ={{ overflowWrap: "break-word"}}>
            Start Point: {_.get(summaryData, "start_point", "")}
            <br></br>
            </div>
            <div style ={{ overflowWrap: "break-word"}}>
            End Point: {_.get(summaryData, "end_point", "")}
            <br></br>
            </div>
            Slack: {_.get(summaryData, "slack", "")}
            <br></br>
            Cause: {_.get(summaryData, "cause", "")}
            <br></br>
            Cause Category: {_.get(summaryData, "cause_category", "")}
            <br></br>
            Total cell delay: {_.get(summaryData, "total_cell_delay", "")}
            <br></br>
            Total net delay: {_.get(summaryData, "total_net_delay", "")}
            <br></br>
            Total crosstalk delay:{" "}
            {_.get(summaryData, "total_crosstalk_delay", "")}
            <br></br>
            Clock skew: {_.get(summaryData, "clock_skew", "")}
            <br></br>
            Clock uncertainity: {_.get(summaryData, "clock_uncertainty", "")}
            <br></br>
            {time}: {_.get(summaryData, "setup_time", "")}
          </div>
          <div style={{ width: "45%", height: "100%", float: "right" }}>
            <Canvas
              ref={this.canvas}
              key={this.state.canvasKey}
              id={this.props.id}
              isLoading={this.props.isLoading}
              isLoading2={this.props.isLoading2}
              board={this.props.board}
              ports={this.props.ports}
              macros={this.props.macros}
              blocks={this.props.blocks}
              heatmapPacthes={this.props.heatmapPacthes}
              showHeatmap={this.props.showHeatmap}
              handleContextMenu={this.handleContextMenu}
              colorCodes={this.props.colorCodes}
              showHeatmapPatch={this.props.showHeatmapPatch}
              timingPath={this.props.timingPath}
              handlePatchContextMenu={this.handlePatchContextMenu}
              zoomIn={this.state.zoomIn}
              zoomOut={this.state.zoomOut}
              handleKeyPress={this.handleKeyPress}
            />
            {/**Navigation bar */}
            <NavBar2
              onMenuSelect={this.handleNavBarSelect}
              // heatmapActive={this.props.showHeatmap}
              // heamapNavBarOpen={this.state.heamapNavBarOpen}
              zoomIn={this.state.zoomIn}
              zoomOut={this.state.zoomOut}
              selected={this.props.selected}
            />
          </div>

          {/**Loading progress on data fetch */}
          {this.props.isLoading || this.props.isLoading2 ? (
            <div
              style={{
                margin: "auto",
                position: "absolute",
                top: "50%",
                left: "50%",
              }}
            >
              <CircularProgress />
            </div>
          ) : null}
        </div>
      </React.Fragment>
    );
  }
}

export default TimingPathContainer;
