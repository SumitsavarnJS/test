import React, { Component } from "react";
import Slider from "@mui/material/Slider";
import Tooltip from "@mui/material/Tooltip";

class DrcNetSlider extends Component {
  getMarks = () => {
    let marks = [{ label: "All", value: 0 }];
    for (let i = 0; i < this.props.drcNetTypeList.length; i++) {
      if (!this.props.drcNetTypeList[i]) {
        marks.push({ label: "None", value: i + 1 });
      } else {
        marks.push({ label: this.props.drcNetTypeList[i], value: i + 1 });
      }
    }
    return marks;
  };

  render() {
    const height = this.props.drcNetTypeList.length * 12;

    return (
      <Tooltip placement="top-start" title="Type">
        <div
          style={{
            bottom: "30px",
            marginLeft: "5px",
            left: "0px",
            position: "absolute",
            width: "27px",
            height: `${height}px`,
            borderRadius: "5px",
            display: this.props.displayLeftSlider
              ,
          }}
        >
          <Slider
            orientation="vertical"
            marks={this.getMarks()}
            step={null}
            track={false}
            min={0}
            max={this.props.drcNetTypeList.length}
            valueLabelDisplay={"off"}
            value={this.props.drcNetType ? this.props.drcNetType : 0}
            onChange={this.props.handleDrcNetType}
          />
        </div>
      </Tooltip>
    );
  }
}

export default DrcNetSlider;
