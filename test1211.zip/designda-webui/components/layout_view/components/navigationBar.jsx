import React, { Component } from "react";
import { Checkbox } from "@mui/material";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import MemoryIcon from "@mui/icons-material/Memory";
import ZoomInIcon from "@mui/icons-material/ZoomIn";
import CropFreeIcon from "@mui/icons-material/CropFree";
import ZoomOutIcon from "@mui/icons-material/ZoomOut";
import Tooltip from "@mui/material/Tooltip";
// import HeatmapActive from "/images/LayoutImages/heatmapEnable.png";
// import HeatmapInactive from "/images/LayoutImages/heatmapDisable.png";

class NavBar extends Component {
  handleChange = (name) => (event) => {
    this.props.onMenuSelect(name, event);
  };

  render() {
    return (
      <div
        id="mySidenav"
        style={{
          width: "auto",
          position: "absolute",
          zIndex: 1,
          top: "50%",
          right: "0px",
          display: "block",
          backgroundColor: "transparent",
          transform: "translateY(-50%)",
        }}
      >
        <FormGroup column>
          <Tooltip
            title="Heatmap"
            placement={this.props.heamapNavBarOpen ? "top" : "left"}
          >
            <FormControlLabel
              control={
                <div
                  onClick={(e) => {
                    this.props.onHeatmapButtonClick();
                  }}
                >
                  {this.props.heatmapActive ? (
                    <img
                      src={"images/LayoutImages/heatmapEnable.png"}
                      alt="Heatmap"
                      style={{ height: "24px", marginLeft: "8px" }}
                    />
                  ) : (
                    <img
                      src={"images/LayoutImages/heatmapEnable.png"}
                      srcSet={"images/LayoutImages/heatmapEnable.png"}
                      alt="Heatmap"
                      style={{ height: "24px", marginLeft: "8px" }}
                    />
                  )}
                </div>
              }
              label=""
            />
          </Tooltip>
          <Tooltip title="Layout" placement="left">
            <FormControlLabel
              control={
                <Checkbox
                  fontSize="small"
                  checked={this.props.chip}
                  onChange={this.props.onMenuSelect("chip")}
                  icon={<MemoryIcon />}
                  checkedIcon={<MemoryIcon color="primary" />}
                  value="chip"
                />
              }
              label=""
            />
          </Tooltip>

          <Tooltip title="Zoom In" placement="left">
            <FormControlLabel
              control={
                <Checkbox
                  fontSize="small"
                  checked={this.props.zoomIn}
                  onChange={this.props.onMenuSelect("zoomIn")}
                  icon={<ZoomInIcon />}
                  checkedIcon={<ZoomInIcon color="primary" />}
                  value="zoomIn"
                />
              }
              label=""
            />
          </Tooltip>

          <Tooltip title="Zoom out" placement="left">
            <FormControlLabel
              control={
                <Checkbox
                  fontSize="small"
                  checked={this.props.zoomOut}
                  onChange={this.props.onMenuSelect("zoomOut")}
                  icon={<ZoomOutIcon />}
                  checkedIcon={<ZoomOutIcon color="primary" />}
                  value="zoomOut"
                />
              }
              label=""
            />
          </Tooltip>
          {/* {this.props.showZoomFilter ? (
            <Tooltip title="Filter" placement="left">
              <FormControlLabel
                control={
                  <Checkbox
                    fontSize="small"
                    checked={this.props.enableZoomFilter}
                    onChange={this.props.onMenuSelect("filter")}
                    icon={<CropFreeIcon />}
                    checkedIcon={<CropFreeIcon color="primary" />}
                    value="zoomOut"
                  />
                }
                label=""
              />
            </Tooltip>
          ) : null} */}
        </FormGroup>
      </div>
    );
  }
}
export default NavBar;
