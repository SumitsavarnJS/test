import React, { Component } from "react";
import { Rect } from "react-konva";


/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class RPBlockage extends Component {
  
  render() {
    const { properties} = this.props;
    return (
      <React.Fragment>
        <Rect
          x={properties.lly}
          y={properties.llx}
          width={properties.height}
          height={properties.width}
          fill="#6bed8b"
          opacity={1}
        />
      </React.Fragment>
    );
  }
}

export default RPBlockage;

