import React, { Component } from "react";
import Slider from "@mui/material/Slider";
import Tooltip from "@mui/material/Tooltip";

class HeatmapNetDensityLayerSlider extends Component {
  getMarks = () => {
    let marks = [];
    for (let i = 0; i < this.props.netDensityLayers.length; i++) {
      marks.push({ label: this.props.netDensityLayers[i], value: i });
    }
    return marks;
  };

  render() {
    const height = this.props.netDensityLayers.length * 20;
    return (
      <Tooltip placement="top-start" title="Layer">
        <div
          style={{
            top: "50px",
            marginLeft: "5px",
            left: "0px",
            position: "absolute",
            width: "27px",
            height: `${height}px`,
            borderRadius: "5px",
            display: this.props.displayLeftSlider,
          }}
        >
          <Slider
            orientation="vertical"
            marks={this.getMarks()}
            step={null}
            track={false}
            min={0}
            max={this.props.netDensityLayers.length}
            valueLabelDisplay={"off"}
            value={this.props.netDensityLayer}
            onChange={this.props.handleNetDensityLayers}
          />
        </div>
      </Tooltip>
    );
  }
}

export default HeatmapNetDensityLayerSlider;
