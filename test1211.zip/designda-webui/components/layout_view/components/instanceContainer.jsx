import React, { Component } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";
import Canvas from "./canvas";
import NavBar2 from "./ZoomNavBar";

import { getInstanceHeatmap } from "../LayoutViewApis";
// utility imprts
import _ from "lodash";

class InstanceContainer extends Component {
  state = {
    zoomIn: false,
    zoomOut: false,
    canvasKey: 1,
    contextMenu: { Xpos: 0, Ypos: 0 },
    heatmapSideNavwidth: "0px",
    taskSelected: 0,
  };

  constructor(props) {
    super(props);
    this.canvas = React.createRef();
    this.handleNavBarSelect = this.handleNavBarSelect.bind(this);
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      const config = this.props.config;
      this.setState({
        dataLocation: config.dataLocation,
        bucket: config.bucket,
      });
    }
    // this.props.getTimingpathSummary(this.props.config.timingpath);
    //draws net
    this.getInstanceHeatmap();
  }

  /**
   * To handle right click on canvas
   * sets name of the component
   * to perform futher context menu actions
   * @param {rightClikEvent} e
   */
  handleContextMenu = (name, e) => {
    if (e !== undefined && e != null)
      this.setState({
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * To handle hot key press
   * @param {key Pressed} key
   */
  handleKeyPress = (key) => {
    if (key === "z") {
      this.setState({ zoomIn: true, zoomOut: false });
    } else if (key === "Z") {
      this.setState({ zoomOut: true, zoomIn: false });
    } else if (key === "f") {
      this.setState({ zoomIn: false, zoomOut: false, canvasKey: Date.now() });
    }
  };

  getInstanceHeatmap = (filteredCoords) => {
    console.log(this.props.id,
      this.props.config,
      filteredCoords);
    getInstanceHeatmap(
      this.props.id,
      this.props.config,
      filteredCoords
    );
  };

  /**
   * To handle the selection of tool
   * from navigation bar and sub menu
   * of heatmap
   * @param {name of the tool} name
   */
  handleNavBarSelect = (name, event) => {
    if (name === "zoomIn" && event.target.checked) {
      this.setState({
        zoomIn: true,
        zoomOut: false,
      });
    } else if (name === "zoomOut" && event.target.checked) {
      this.setState({
        zoomIn: false,
        zoomOut: true,
      });
    } else if (
      (name === "zoomOut" || name === "zoomIn") &&
      !event.target.checked
    ) {
      this.setState({
        [name]: false,
      });
    }
  };

  instanceToolTip = (properties) => {
    var obj = [],
      temp = {},
      ret = "";
    const inst = this.props.instComponents;
    const instNames = _.get(this.props.config, "instance_value", "");
    if (typeof instNames === "string") {
      return properties.density;
    }
    // console.log(inst);
    // console.log(properties);
    // console.log(instNames,"  ", typeof(instNames));
    for (let i = 0; i < inst.length; i++) {
      temp = inst[i].find(
        (o) => o.llx === properties.llx && o.lly === properties.lly
      );
      if (typeof temp === "undefined") {
        temp = { density: 0 };
      }
      obj.push(temp);
    }
    if (obj.length) {
      for (let i = 0; i < obj.length; i++) {
        ret = ret.concat(instNames[i] + ": " + obj[i].density);
        ret = ret + "\n";
      }
    }
    ret = ret.slice(0, -1);
    return ret;
  };

  render() {
    const instance_value = _.get(this.props.config, "instance_value", "");
    return (
      <React.Fragment>
        <div
          id="canvas"
          tabIndex="0"
          style={{
            width: "100%",
            height: "90%",
            overflowX: "auto",
            overflowY: "hidden",
            fontSize: 12,
          }}
        >
          {instance_value.length === 2 ? (
            <div
              style={{ paddingLeft: "5px", paddingTop: "20px", float: "left" }}
            >
              <Box
                sx={{
                  // width: 30,
                  height: 30,
                  color: this.props.theme == "light" ? "black" : "white",
                  backgroundColor:
                    this.props.theme == "light" ? "#b37500" : "#7579a4",
                }}
              >
                {" "}
                {instance_value[0]}
              </Box>
              <br></br>
              <Box
                sx={{
                  // width: 30,
                  height: 30,
                  backgroundColor:
                    this.props.theme == "light" ? "#99c125" : "#cf497f",
                }}
              >
                {" "}
                {instance_value[1]}
              </Box>
            </div>
          ) : null}
          <Canvas
            ref={this.canvas}
            key={this.state.canvasKey}
            id={this.props.id}
            isLoading={this.props.isLoading}
            isLoading2={this.props.isLoading2}
            board={this.props.board}
            instComponents={this.props.instComponents}
            instanceToolTip={this.instanceToolTip}
            macros={this.props.macros}
            blocks={this.props.blocks}
            getFilteredData={this.getInstanceHeatmap}
            zoomIn={this.state.zoomIn}
            zoomOut={this.state.zoomOut}
            handleKeyPress={this.handleKeyPress}
          />
          {/**Navigation bar */}
          <NavBar2
            onMenuSelect={this.handleNavBarSelect}
            zoomIn={this.state.zoomIn}
            zoomOut={this.state.zoomOut}
            selected={this.props.selected}
          />

          {/**Loading progress on data fetch */}
          {this.props.isLoading || this.props.isLoading2 ? (
            <div
              style={{
                margin: "auto",
                position: "absolute",
                top: "50%",
                left: "50%",
              }}
            >
              <CircularProgress />
            </div>
          ) : null}
        </div>
      </React.Fragment>
    );
  }
}

export default InstanceContainer;
