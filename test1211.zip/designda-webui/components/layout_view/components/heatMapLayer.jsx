import React, { Component } from "react";
import { Rect } from "react-konva";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class HeatMapLayer extends Component {
  state = { opacity:0.7};

  componentDidUpdate()
  {
    this.refs.rect.clearCache();
  }

  handleOnMouseOver = () => {
    this.setState({opacity: 0.8 });
    this.props.handleShowTooltip(true);
    this.props.handleTooltipValue(this.props.properties[4]);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 0.7 });
    // this.props.handleShowTooltip(false);
    // this.props.handleTooltipValue(this.props.properties[4]);
  };

  handleMouseDown=()=>{
    this.setState({opacity: 0.8 });
    this.props.handleShowTooltip(true);
    this.props.handleTooltipValue(this.props.properties[4]);
    this.props.getRelativePointerPosition()
  };

  handleClick = (e) => {
    if(!this.props.zoomIn && !this.props.zoomOut){
      if (e.evt.detail === 1 && e.evt.button === 0) {
        // console.log('Left click');
        this.handleMouseDown();
      } 
    }
  };

  render() {
    const { colorCodes, properties } = this.props;
    let color = "";
    if (properties[4] < colorCodes[0])
      color = "#D3D3D3";
    else if (properties[4] >= colorCodes[0] && properties[4] < colorCodes[1])
      color = "#4575b4";
    else if (properties[4] >= colorCodes[1] && properties[4] < colorCodes[2])
      color = "#74add1";
    else if (properties[4] >= colorCodes[2] && properties[4] < colorCodes[3])
      color = "#abd9e9";
    else if (properties[4] >= colorCodes[3] && properties[4] < colorCodes[4])
      color = "#e0f3f8";
    else if (properties[4] >= colorCodes[4] && properties[4] < colorCodes[5])
      color = "#ffffbf";
    else if (properties[4] >= colorCodes[5] && properties[4] < colorCodes[6])
      color = "#fee090";
    else if (properties[4] >= colorCodes[6] && properties[4] < colorCodes[7])
      color = "#fdae61";
    else if (properties[4] >= colorCodes[7] && properties[4] < colorCodes[8])
      color = "#f46d43";
    else if (properties[4] >= colorCodes[8] && properties[4] < colorCodes[9])
      color = "#d73027";
    else if (properties[4] >= colorCodes[9]) 
      color = "#a50026";

    const width = properties[2] - properties[0];
    const height = properties[3] - properties[1];
    return (
      <React.Fragment>
        <Rect
          ref="rect"
          batchDraw={true}
          perfectDrawEnabled={false}
          x={properties[1]}
          y={properties[0]}
          width={height}
          height={width}
          fill={color}
          onMouseDown={(e) => {this.handleClick(e)}}
          // onMouseOver={this.handleOnMouseOver}
          onMouseOut={this.handleOnMouseOut}
          opacity={this.state.opacity}
          scaleX={this.state.scale}
          scaleY={this.state.scale}
          onContextMenu={(e) => {
            e.evt.preventDefault();
            this.props.ContextMenu(properties, e)
          }}
        />
      </React.Fragment>
    );
  }
}

export default HeatMapLayer;
