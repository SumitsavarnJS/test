import React, { Component } from "react";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import CircularProgress from "@mui/material/CircularProgress";
import NavBar from "./navigationBar";
import HeatmapNavBar from "./heatmapNavBar";
import HeatmapScenario from "./heatmapScenarioSelection";
import HeatmapRangeShiftSlider from "./heatmapShiftRangeSlider";
import HeatmapHideShowSlider from "./hideShowHeatmapSlider";
import HeatmapCrosstalkValueSlider from "./heatmapCrosstalkValueSlider";
import HeatmapCrosstalkDominantLayerSlider from "./heatmapCrosstalkDominantLayerSlider";
import HeatmapComponentDensitySlider from "./heatmapComponentDensitySlider";
import DrcErrorTypeSlider from "./DrcErrorTypeSlider";
import DrcLayerSlider from "./drcLayerSlider";
import DrcNetSlider from "./drcNetSlider";
import HeatmapNetDensityLayerSlider from "./heatmapNetDensityLayerSlider";
import Canvas from "./canvas";
import { produce } from "immer";

import useGlobalStore from "../../../store/useGlobalStore";
import {getTimingPathCoordinates} from "../LayoutViewApis";

// utility imprts
import _ from "lodash";

class CanvasContainer extends Component {
  state = {
    zoomIn: false,
    zoomOut: false,
    canvasKey: 1,
    contextMenu: { Xpos: 0, Ypos: 0 },
    showHeatmapSideNav: false,
    newCrosstalkLayer: 0,
    crosstalkValue: 0,
    componentTypeValue: 0,
    netDensityLayer: 0,
    heatmapActive: false,
    heamapNavBarOpen: false,
    drcNetType: 0,
    drcLayer: 0,
    drcErrorType: 0,
    draggableStage: true,
    enableZoomFilter: false,
  };

  constructor(props) {
    super(props);
    this.componentType = "all";
    this.canvas = React.createRef();
    this.handleNavBarSelect = this.handleNavBarSelect.bind(this);
    this.handleScenarioSelect = this.handleScenarioSelect.bind(this);
    this.handleHeatmapButton = this.handleHeatmapButton.bind(this);
    this.handleZoomFilter = this.handleZoomFilter.bind(this);
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      const config = this.props.config;
      this.setState({
        dataLocation: config.dataLocation,
        bucket: config.bucket,
      });

      if (config && config.dataLocation) {
        this.props.getCrosstalkScenario();
        this.props.getPowerScenarios(config.bucket, config.dataLocation);
      }

      if (config.hasOwnProperty("timingpath")) {
        this.getTimingPath();
      }
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (!prevProps.showZoomFilter && prevState.enableZoomFilter) {
      this.setState({ draggableStage: true, enableZoomFilter: false });
    }

    // this.handleNetDensityLayers("", 0);
  }

  //to open heatmap config navigation bar
  openHeatmapConfig = () => {
    this.setState({ heamapNavBarOpen: true, showHeatmapSideNav: true });
  };

  /**
   * To reset the heatmap type
   * selection menu
   */
  resetHeatmapMenu = () => {
    this.setState({
      heatmapActive: false,
      cell_internal: false,
      leak: false,
      totalDynamic: false,
      crosstalkHeatmap: false,
      crosstalkPatch: false,
      pinDensity: false,
      cellDensity: false,
      congestion: false,
      congestionPatch: false,
      heatmapType: null,
    });
    // this.props.removeAllTimingPaths();
    this.props.handleHeatmap(false);
    this.props.handleHeatmapPatch(false);

    //to remove heatmap from report's JSON
    if (this.props.config !== undefined) {
      if (this.props.config.hasOwnProperty("heatmap")) {
        const config = produce(this.props.config, (configDraft) => {
          delete configDraft.heatmap;
        });

        useGlobalStore
          .getState()
          .updateConfig(
            this.props.rptType,
            this.props.reportKey,
            this.props.id,
            config
          );
      }
    }
  };
  /**
   * To handle Slider of Types of crosstalk
   * @param {event} event
   * @param {Type} crosstalkValue
   */
  handleCrosstalkType = (event, crosstalkValue) => {
    this.setState({ crosstalkValue: crosstalkValue });

    if (crosstalkValue == 0) {
      //TNS
      this.props.heatmapColorCode(0, this.props.crosstalkMin.TNS);
    } else if (crosstalkValue == 1) {
      //WNS
      this.props.heatmapColorCode(0, this.props.crosstalkMin.WNS);
    } else if (crosstalkValue == 2) {
      //NVP
      this.props.heatmapColorCode(0, this.props.crosstalkMax.NVP);
    } else if (crosstalkValue == 3) {
      //net count
      this.props.heatmapColorCode(
        this.props.crosstalkMin.net_count,
        this.props.crosstalkMax.net_count
      );
    }
  };

  /**
   * to get preconfigured timing path
   */
  getTimingPath = () => {
    getTimingPathCoordinates(this.props.id,this.props.config,[this.props.config.timingpath])
    // this.props.drawTimingPath(
    //   this.props.id,
    //   [this.props.config.timingpath],
    //   this.props.config.scenario,
    //   this.props.config.dataLocation,
    //   this.props.config.bucket
    // );
  };

  /**
   * To handle Slider of Types of Density
   * @param {event} event
   * @param {Type} component_density
   */
  handleComponentDensity = (event, value) => {
    this.setState({ componentTypeValue: value });
    switch (value) {
      case 0:
        this.componentType = "all";
        break;
      case 1:
        this.componentType = "boundary";
        break;
      case 2:
        this.componentType = "buf_inv";
        break;
      case 3:
        this.componentType = "combo";
        break;
      case 4:
        this.componentType = "complex_combo";
        break;
      case 5:
        this.componentType = "icg";
        break;
      case 6:
        this.componentType = "latch";
        break;
      case 7:
        this.componentType = "level_shifter";
        break;
      case 8:
        this.componentType = "power_switch";
        break;
      case 9:
        this.componentType = "sequential";
        break;
    }
    const config = this.props.config;
    let localAZ =
      localStorage.getItem(`activeZoom${this.props.id}`) === "true"
        ? true
        : false;
    let data = {};
    data["bucket"] = this.state.bucket;
    data["key"] = this.state.dataLocation;
    data["type"] = "timing";
    data["sub_type"] = "cellDensityHeatmap";
    data["component_type"] = this.componentType;
    data["board"] = _.get(this.props.board, "coordinates", []);
    data["doSampling"] = config.doSampling;
    data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
    this.props.getHeatmap(data);
    this.closeHeatmapConfig();
  };

  getTimingPathsFromContextMenu = () => {
    if (
      (this.props.crosstalkPatches && this.props.crosstalkPatches.length > 0) ||
      (this.props.drcHeatmap && this.props.drcHeatmap.length > 0) ||
      (this.props.cellDensityHeatmap &&
        this.props.cellDensityHeatmap.length > 0) ||
      (this.props.pinDensityHeatmap && this.props.pinDensityHeatmap.length > 0)
    ) {
      this.getTimingPathForCrosstalk();
    } else {
      this.getHeatmapTileTimePath();
    }
  };

  /**
   *  To handler layer selector slider
   * @param {event} event
   * @param {Layer} newCrosstalkLayer
   */
  handleCrosstalkDominantLayerChange = (event, newCrosstalkLayer) => {
    this.setState({ newCrosstalkLayer: newCrosstalkLayer });
  };
  /**
   * To handle heatmap button
   * from navigation bar
   */
  handleHeatmapButton = () => {
    if (this.state.heamapNavBarOpen) this.closeHeatmapConfig();
    else this.openHeatmapConfig();
  };

  /**
   * To select the scenario
   * and prepare the data for
   * the API
   * @param {scenario} event
   */
  handleScenarioSelect = (event) => {
    let data = {};

    if (this.state.heatmapType == "power") {
      data["type"] = "power";
      data["sub_type"] = this.state.heatmapSubTypeSelected;
    } else if (
      this.state.heatmapType == "crosstalkHeatmap" ||
      this.state.heatmapType == "crosstalkPatch"
    ) {
      this.props.handleHeatmap(true);
      this.setState({
        //by default TNS
        crosstalkValue: 0,

        //by defalut All
        newCrosstalkLayer: 0,
      });
      data["type"] = "timing";
      data["sub_type"] = "timingHeatmap";
    }
    data["scenario"] = event.target.value;
    data["bucket"] = this.state.bucket;
    if (this.state.heatmapType == "crosstalkPatch") {
      data["sub_type"] = "crosstalk_patch";
    }
    data["key"] = this.state.dataLocation;
    this.setState({
      displayHeatmapScenario: "none",
      heatmapScenarioSelected: event.target.value,
      displayLeftSlider: "block",
    });
    data["board"] = _.get(this.props.board, "coordinates", []);
    this.props.getHeatmap(data);
  };

  //close heatmap config navigation bar
  closeHeatmapConfig = () => {
    this.setState({ heamapNavBarOpen: false, showHeatmapSideNav: false });
  };

  handleDrcNetType = (e, value) => {
    this.setState({ drcNetType: value });
  };

  handleDrcErrorType = (e, value) => {
    this.setState({ drcErrorType: value });
  };

  handleDrcLayers = (e, value) => {
    this.setState({ drcLayer: value });
  };

  handleNetDensityLayers = (e, value) => {
    this.setState({ netDensityLayer: value });
    const config = this.props.config;
    let localAZ =
      localStorage.getItem(`activeZoom${this.props.id}`) === "true"
        ? true
        : false;
    if (config.heatmap && config.heatmap.sub_type === "netDensityHeatmap") {
      let data = {};
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "congestion";
      data["layer"] = this.props.netDensityLayers[value];
      data["sub_type"] = "netDensityHeatmap";
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["doSampling"] = config.doSampling;
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      this.props.getHeatmap(data);
    }
  };
  /**
   * To handle the selection of tool
   * from navigation bar and sub menu
   * of heatmap
   * @param {name of the tool} name
   */
  handleNavBarSelect = (name) => (event) => {
    if (name === "chip") {
      // layout option in the widget[right bar 2nd option]
      this.resetHeatmapMenu();
      this.setState({ chip: true });
      this.closeHeatmapConfig();
      this.props.removeAllTimingPaths(this.props.id);
    }
    if (name === "cell_internal") {
      this.setState({
        leak: false,
        heatmapActive: true,
        cell_internal: true,
        totalDynamic: false,
        chip: false,
        congestion: false,
        crosstalkPatch: false,
        crosstalkHeatmap: false,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: false,
        netDensity: false,
        heatmapSubTypeIndex: 0,
        heatmapSubTypeSelected: "cell_internal_power",
        heatmapScenarioSelected: "none",
        displayLeftSlider: "none",
        displayHeatmapScenario: "block",
        heatmapType: "power",
      });
      this.closeHeatmapConfig();
    } else if (name === "leak") {
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: true,
        congestion: false,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: false,
        netDensity: false,
        totalDynamic: false,
        chip: false,
        crosstalkPatch: false,
        crosstalkHeatmap: false,
        heatmapSubTypeIndex: 2,
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "cell_leakage_power",
        displayHeatmapScenario: "block",
        displayLeftSlider: "none",
        heatmapType: "power",
      });
      this.closeHeatmapConfig();
    } else if (name === "totalDynamic") {
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        chip: false,
        congestion: false,
        crosstalkPatch: false,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: false,
        netDensity: false,
        crosstalkHeatmap: false,
        totalDynamic: true,
        heatmapSubTypeIndex: 1,
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "total_dynamic_power",
        displayLeftSlider: "none",
        displayHeatmapScenario: "block",
        heatmapType: "power",
      });
      this.closeHeatmapConfig();
    } else if (name === "congestion") {
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        chip: false,
        congestion: true,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: false,
        netDensity: false,
        crosstalkPatch: false,
        crosstalkHeatmap: false,
        totalDynamic: false,
        heatmapSubTypeIndex: "NA",
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "congestion",
        displayLeftSlider: "block",
        displayHeatmapScenario: "none",
        heatmapType: "congestion",
      });
      let data = {};
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "congestion";
      data["sub_type"] = "Congestionheatmap";
      data["board"] = _.get(this.props.board, "coordinates", []);
      this.props.getHeatmap(data);
      this.closeHeatmapConfig();
    } else if (name === "congestionPatch") {
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        chip: false,
        congestion: false,
        congestionPatch: true,
        pinDensity: false,
        cellDensity: false,
        netDensity: false,
        crosstalkPatch: false,
        crosstalkHeatmap: false,
        totalDynamic: false,
        heatmapSubTypeIndex: "NA",
        heatmapScenarioSelected: "none",
        displayHeatmapScenario: "none",
        displayLeftSlider: "block",
        heatmapType: "congestion",
      });
      this.props.handleHeatmap(false);
      let data = {};
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      this.props.getCongestionPatch(data);
      this.closeHeatmapConfig();
    } else if (name === "crosstalkPatch") {
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        congestion: false,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: false,
        netDensity: false,
        totalDynamic: false,
        chip: false,
        crosstalkHeatmap: false,
        crosstalkPatch: true,
        heatmapSubTypeIndex: "NA",
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "NA",
        displayHeatmapScenario: "block",
        displayLeftSlider: "none",
        heatmapType: "crosstalkPatch",
      });
      this.props.handleHeatmap(false);
      this.closeHeatmapConfig();
    } else if (name === "crosstalkHeatmap") {
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        congestion: false,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: false,
        netDensity: false,
        totalDynamic: false,
        chip: false,
        crosstalkHeatmap: true,
        crosstalkPatch: false,
        heatmapSubTypeIndex: "NA",
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "NA",
        displayHeatmapScenario: "block",
        displayLeftSlider: "none",
        heatmapType: "crosstalkHeatmap",
      });
      this.props.handleHeatmap(false);
      this.closeHeatmapConfig();
    } else if (name === "DRC") {
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        congestion: false,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: false,
        netDensity: false,
        totalDynamic: false,
        chip: false,
        crosstalkHeatmap: false,
        crosstalkPatch: false,
        heatmapSubTypeIndex: "NA",
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "NA",
        displayHeatmapScenario: "none",
        displayLeftSlider: "block",
        heatmapType: "DRC",
      });
      let data = {};
      const config = this.props.config;
      let localAZ =
        localStorage.getItem(`activeZoom${this.props.id}`) === "true"
          ? true
          : false;
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "DRC";
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["doSampling"] = config.doSampling;
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      // console.log("config: ",data);
      this.props.getHeatmap(data);
      this.props.handleHeatmap(false);
      this.closeHeatmapConfig();
    } else if (name === "pinDensity") {
      // pin density
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        chip: false,
        congestion: false,
        congestionPatch: false,
        pinDensity: true,
        cellDensity: false,
        netDensity: false,
        crosstalkPatch: false,
        crosstalkHeatmap: false,
        totalDynamic: false,
        heatmapSubTypeIndex: "NA",
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "pinDensityHeatmap",
        displayLeftSlider: "block",
        displayHeatmapScenario: "none",
        heatmapType: "congestion",
      });
      let data = {};
      const config = this.props.config;
      let localAZ =
        localStorage.getItem(`activeZoom${this.props.id}`) === "true"
          ? true
          : false;
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "congestion";
      data["sub_type"] = "pinDensityHeatmap";
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["doSampling"] = config.doSampling;
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      this.props.getHeatmap(data);
      this.closeHeatmapConfig();
    } else if (name === "cellDensity") {
      // cell density
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        chip: false,
        congestion: false,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: true,
        netDensity: false,
        crosstalkPatch: false,
        crosstalkHeatmap: false,
        totalDynamic: false,
        heatmapSubTypeIndex: "NA",
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "cellDensityHeatmap",
        displayLeftSlider: "block",
        displayHeatmapScenario: "none",
        heatmapType: "timing",
      });
      let data = {};
      const config = this.props.config;
      let localAZ =
        localStorage.getItem(`activeZoom${this.props.id}`) === "true"
          ? true
          : false;
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "timing";
      data["sub_type"] = "cellDensityHeatmap";
      data["component_type"] = this.componentType;
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["doSampling"] = config.doSampling;
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      this.props.getHeatmap(data);
      this.closeHeatmapConfig();
    } else if (name === "netDensity") {
      // net density
      this.setState({
        cell_internal: false,
        heatmapActive: true,
        leak: false,
        chip: false,
        congestion: false,
        congestionPatch: false,
        pinDensity: false,
        cellDensity: false,
        netDensity: true,
        crosstalkPatch: false,
        crosstalkHeatmap: false,
        totalDynamic: false,
        heatmapSubTypeIndex: "NA",
        heatmapScenarioSelected: "none",
        heatmapSubTypeSelected: "netDensityHeatmap",
        displayLeftSlider: "block",
        displayHeatmapScenario: "none",
        heatmapType: "congestion",
      });
      let data = {};
      const config = this.props.config;
      let localAZ =
        localStorage.getItem(`activeZoom${this.props.id}`) === "true"
          ? true
          : false;
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "congestion";
      data["sub_type"] = "netDensityHeatmap";
      data["layer"] = this.props.netDensityLayers[this.state.netDensityLayer]
        ? this.props.netDensityLayers[this.state.netDensityLayer]
        : "sum";
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["doSampling"] = config.doSampling;
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      this.props.getHeatmap(data);
      this.closeHeatmapConfig();
    } else if (name === "zoomIn" && event.target.checked) {
      this.setState({
        zoomIn: true,
        zoomOut: false,
      });
    } else if (name === "zoomOut" && event.target.checked) {
      this.setState({
        zoomIn: false,
        zoomOut: true,
      });
    } else if (
      (name === "zoomOut" || name === "zoomIn") &&
      !event.target.checked
    ) {
      this.setState({
        [name]: false,
      });
    } else if (name === "filter" && event.target.checked) {
      this.setState({ draggableStage: false, enableZoomFilter: true });
    } else if (name === "filter" && !event.target.checked) {
      this.setState({ draggableStage: true, enableZoomFilter: false });
    }
  };

  /**
   * to handle context menu of heatmap
   * @param {coordinates} properties
   * @param {event} e
   */
  handleHeatmapContextMenu = (properties, e) => {
    if (e !== undefined && e != null)
      this.setState({
        heatmapTile: true,
        tileProperties: properties,
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * get timing paths and add table
   */
  getTimingPathForCrosstalk = () => {
    this.setState({ heatmapTile: null });
    const config = this.props.config;
    let properties = {};
    properties["bucket"] = this.state.bucket;
    properties["key"] = this.state.dataLocation;
    properties["columns"] = [
      "timing_path",
      "start_point",
      "end_point",
      "slack",
      "path_group",
      "path_category",
    ];
    properties["llx"] = this.state.tileProperties.llx;
    properties["lly"] = this.state.tileProperties.lly;
    properties["urx"] = this.state.tileProperties.urx;
    properties["ury"] = this.state.tileProperties.ury;
    properties["sub_type"] = config.heatmap.sub_type;
    if (this.state.tileProperties.bboxType) {
      properties["bboxType"] = this.state.tileProperties.bboxType;
    }
    if (this.props.subType === "crosstalkPatch") {
      properties["timingpathList"] = this.state.tileProperties.timingpathList;
      properties["scenario"] = this.props.config.heatmap.scenario;
    }

    this.props.getTimingPaths(properties);
  };

  /**
   * to get tables of timing path from heatmap
   */
  getHeatmapTileTimePath = () => {
    this.setState({ heatmapTile: null });
    let properties = {};
    properties["llx"] = this.state.tileProperties[0];
    properties["lly"] = this.state.tileProperties[1];
    properties["urx"] = this.state.tileProperties[2];
    properties["ury"] = this.state.tileProperties[3];
    if (this.state.tileProperties[5]) {
      properties["bboxType"] = this.state.tileProperties[5];
    }
    properties["bucket"] = this.state.bucket;
    properties["key"] = this.state.dataLocation;
    properties["columns"] = [
      "timing_path",
      "start_point",
      "end_point",
      "slack",
      "path_group",
      "path_category",
    ];
    this.props.getTimingPaths(properties);
  };

  /**
   * To set crosstalk context menu properties
   * @param {properties} properties
   */
  crosstalkContextMenu = (properties, e) => {
    if (e !== undefined && e != null)
      this.setState({
        heatmapTile: true,
        tileProperties: properties,
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * to get tables of timing path from patch
   */
  getPatchTimePath = () => {
    this.setState({ patchContextMenu: null });
    let properties = {};
    properties["patch"] = this.state.patchProperties;
    properties["bucket"] = this.state.bucket;
    properties["sub_type"] = "patch";
    properties["key"] = this.state.dataLocation;
    properties["columns"] = [
      "timing_path",
      "start_point",
      "end_point",
      "slack",
      "path_group",
      "path_category",
    ];
    this.props.getTimingPaths(properties);
  };

  /**
   * To handle right click on canvas
   * sets name of the component
   * to perform futher context menu actions
   * @param {rightClikEvent} e
   */
  handleContextMenu = (name, e) => {
    if (e !== undefined && e != null)
      this.setState({
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * To activate zoom filter
   */
  handleZoomFilter = (value) => {
    this.setState({ enableZoomFilter: value, draggableStage: !value });
  };

  getFilteredData = (filteredCoords) => {
    const config = this.props.config;
    let localAZ =
      localStorage.getItem(`activeZoom${this.props.id}`) === "true"
        ? true
        : false;
    if (config.heatmap.type === "DRC") {
      let data = {};
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "DRC";
      data["filterCoords"] = filteredCoords;
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      this.props.getHeatmap(data);
      this.props.handleHeatmap(false);
      this.setState({ drcErrorType: 0, drcNetType: 0, drcLayer: 0 });
    }
    if (config.heatmap.sub_type === "pinDensityHeatmap") {
      let data = {};
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "congestion";
      data["filterCoords"] = filteredCoords;
      data["sub_type"] = "pinDensityHeatmap";
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["doSampling"] = config.doSampling;
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      this.props.getHeatmap(data);
    }
    if (config.heatmap.sub_type === "netDensityHeatmap") {
      let data = {};
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "congestion";
      data["filterCoords"] = filteredCoords;
      data["layer"] = this.props.netDensityLayers[this.state.netDensityLayer];
      data["sub_type"] = "netDensityHeatmap";
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["doSampling"] = config.doSampling;
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      this.props.getHeatmap(data);
    }
    if (config.heatmap.sub_type === "cellDensityHeatmap") {
      let data = {};
      data["bucket"] = this.state.bucket;
      data["key"] = this.state.dataLocation;
      data["type"] = "timing";
      data["sub_type"] = "cellDensityHeatmap";
      data["filterCoords"] = filteredCoords;
      data["component_type"] = this.componentType;
      data["board"] = _.get(this.props.board, "coordinates", []);
      data["doSampling"] = config.doSampling;
      data["activeZoom"] = config.activeZoom ? config.activeZoom : localAZ;
      this.props.getHeatmap(data);
    }
  };
  /**
   * to handle context menu of patch
   * @param {coordinates} properties
   * @param {event} e
   */
  handlePatchContextMenu = (properties, e) => {
    if (e !== undefined && e != null)
      this.setState({
        patchContextMenu: true,
        patchProperties: properties,
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * To handle hot key press
   * @param {key Pressed} key
   */
  handleKeyPress = (key) => {
    if (key === "z") {
      this.setState({ zoomIn: true, zoomOut: false });
    } else if (key === "Z") {
      this.setState({ zoomOut: true, zoomIn: false });
    } else if (key === "f") {
      //delete previous zoom settings
      const config = produce(this.props.config, (configDraft) => {
        delete configDraft.zoom;
      });
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
      this.setState({ zoomIn: false, zoomOut: false, canvasKey: Date.now() });
    }
  };

  getMapTypeText = () => {
    let bottomText = "";
    if (this.props.config && this.props.config.heatmap) {
      if (this.props.config.heatmap.sub_type === "cell_internal_power") {
        bottomText = "Cell Internal Power";
      } else if (this.props.config.heatmap.sub_type === "cell_leakage_power") {
        bottomText = "Cell Leakage Power";
      } else if (this.props.config.heatmap.sub_type === "total_dynamic_power") {
        bottomText = "Total Dynamic Power";
      } else if (this.props.config.heatmap.sub_type === "Congestionheatmap") {
        bottomText = "Congestion";
      } else if (this.props.config.heatmap.subtype === "congestionPatch") {
        bottomText = "Congestion Patch";
      } else if (this.props.config.heatmap.sub_type === "total_dynamic_power") {
        bottomText = "Total Dynamic Power";
      } else if (this.props.config.heatmap.sub_type === "pinDensityHeatmap") {
        bottomText = "Pin Density";
      } else if (this.props.config.heatmap.sub_type === "timingHeatmap") {
        bottomText = "Timing";
      } else if (this.props.config.heatmap.sub_type === "crosstalk_patch") {
        bottomText = "Crosstalk Patch";
      } else if (this.props.config.heatmap.sub_type === "cellDensityHeatmap") {
        bottomText = "Cell Density";
      } else if (this.props.config.heatmap.type === "DRC") {
        bottomText = "DRC";
      } else if (this.props.config.heatmap.sub_type === "netDensityHeatmap") {
        bottomText = "Net Density";
      }
    }

    return (
      <div
        style={{
          textAlign: "center",
          position: "absolute",
          bottom: 0,
          width: "100%",
        }}
      >
        {bottomText}
      </div>
    );
  };

  render() {
    let background = "white";
    if (this.props.theme === "dark") {
      background = "rgba(51,51,51,1)";
    }

    return (
      <React.Fragment>
        <div
          id="canvas"
          // tabIndex="0"
          // onKeyPress={(e) => {  // Handled in canvas for all container
          //   e.preventDefault();
          //   this.handleKeyPress(e.key);
          // }}
          style={{ width: "100%", height: "100%" }}
        >
          <Canvas
            ref={this.canvas}
            key={this.state.canvasKey}
            id={this.props.id}
            config={this.props.config}
            isLoading={this.props.isLoading}
            isLoading2={this.props.isLoading2}
            board={this.props.board}
            ports={this.props.ports}
            macros={this.props.macros}
            blocks={this.props.blocks}
            heatmaps={this.props.heatmaps}
            heatmapPacthes={this.props.heatmapPacthes}
            showHeatmap={this.props.showHeatmap}
            colorCodes={this.props.colorCodes}
            showHeatmapPatch={this.props.showHeatmapPatch}
            timingPath={this.props.timingPath}
            voltageArea={this.props.voltageArea}
            RPBlockage={this.props.RPBlockage}
            RPGroup={this.props.RPGroup}
            newHideShowValue={this.props.newHideShowValue}
            handleHeatmapContextMenu={this.handleHeatmapContextMenu}
            handleContextMenu={this.handleContextMenu}
            crosstalkValue={this.state.crosstalkValue}
            componentTypeValue={this.state.componentTypeValue}
            newCrosstalkLayer={this.state.newCrosstalkLayer}
            subType={this.props.subType}
            crosstalkPatches={this.props.crosstalkPatches}
            cellDensityHeatmap={this.props.cellDensityHeatmap}
            pinDensityHeatmap={this.props.pinDensityHeatmap}
            netDensityHeatmap={this.props.netDensityHeatmap}
            netDensityLayer={this.state.netDensityLayer}
            netDensityLayers={this.props.netDensityLayers}
            crosstalkContextMenu={this.crosstalkContextMenu}
            handlePatchContextMenu={this.handlePatchContextMenu}
            crosstalkLayers={this.props.crosstalkLayers}
            drcHeatmap={this.props.drcHeatmap}
            drcLayersList={this.props.drcLayersList}
            drcErrorType={this.state.drcErrorType}
            drcNetTypeList={this.props.drcNetTypeList}
            drcErrorTypeList={this.props.drcErrorTypeList}
            drcLayer={this.state.drcLayer}
            drcNetType={this.state.drcNetType}
            zoomIn={this.state.zoomIn}
            zoomOut={this.state.zoomOut}
            handleKeyPress={this.handleKeyPress}
            handleZoomFilter={this.handleZoomFilter}
            enableZoomFilter={this.state.enableZoomFilter}
            getFilteredData={this.getFilteredData}
            draggableStage={this.state.draggableStage}
            handleTooltipClick={this.props.handleTooltipClick}
          />

          {/**Navigation bar */}
          <NavBar
            onMenuSelect={this.handleNavBarSelect}
            onHeatmapButtonClick={this.handleHeatmapButton}
            heatmapActive={this.props.showHeatmap}
            heamapNavBarOpen={this.state.heamapNavBarOpen}
            chip={this.state.chip}
            zoomIn={this.state.zoomIn}
            zoomOut={this.state.zoomOut}
            selected={this.props.selected}
            enableZoomFilter={this.state.enableZoomFilter}
            showZoomFilter={this.props.showZoomFilter}
          />
          {/**Heatmap Navigation Bar */}
          <HeatmapNavBar
            ref={this.mySidenav}
            onMenuSelect={this.handleNavBarSelect}
            leak={this.state.leak}
            showHeatmapSideNav={this.state.showHeatmapSideNav}
            dynamic={this.state.dynamic}
            totalDynamic={this.state.totalDynamic}
            cell_internal={this.state.cell_internal}
            congestion={this.state.congestion}
            congestionPatch={this.state.congestionPatch}
            cellDensity={this.state.cellDensity}
            pinDensity={this.state.pinDensity}
            crosstalkHeatmap={this.state.crosstalkHeatmap}
            crosstalkPatch={this.state.crosstalkPatch}
            is_post_route={this.props.is_post_route}
            selected={this.props.selected}
          />
          {/**Heatmap scenarios */}
          {this.state.heatmapActive ? (
            <HeatmapScenario
              ref={(node) => (this.heatmapScenario = node)}
              scenario={this.props.scenario}
              heatmapScenarioSelected={this.state.heatmapScenarioSelected}
              heatmapSubTypeIndex={this.state.heatmapSubTypeIndex}
              scenarioTable={this.props.scenarioTable}
              displayHeatmapScenario={this.state.displayHeatmapScenario}
              handleScenarioSelect={this.handleScenarioSelect}
              heatmapType={this.state.heatmapType}
              crosstalkScenarios={this.props.crosstalkScenarios}
              selected={this.props.selected}
              theme={this.props.theme}
            />
          ) : null}

          {/**Heatmap Range Shifting Slider */}
          {this.props.showHeatmap &&
          this.props.heatmaps &&
          this.props.heatmaps != null &&
          this.props.heatmaps.length > 0 ? (
            <HeatmapRangeShiftSlider
              heatmapMin={this.props.heatmapMin}
              heatmapMax={this.props.heatmapMax}
              displayLeftSlider={this.state.displayLeftSlider}
              newRangeValue={this.props.newRangeValue}
              onHeatmapRangeShift={this.props.handleHeatmapRangeShift}
              selected={this.props.selected}
            />
          ) : null}

          {/**Heatmap hide and show Slider */}
          {this.props.showHeatmap &&
          this.props.heatmaps &&
          this.props.heatmaps != null &&
          this.props.heatmaps.length > 0 ? (
            <HeatmapHideShowSlider
              heatmapMin={this.props.heatmapMin}
              displayLeftSlider={this.state.displayLeftSlider}
              heatmapMax={this.props.heatmapMax}
              newHideShowValue={this.props.newHideShowValue}
              handleHideShowHeatmapSlider={
                this.props.handleHideShowHeatmapSlider
              }
              selected={this.props.selected}
            />
          ) : null}

          {/**Crosstalk layer selector Slider */}
          {this.props.showHeatmap &&
          this.props.crosstalkPatches &&
          this.props.crosstalkPatches.length > 0 &&
          this.props.crosstalkLayers &&
          this.props.crosstalkLayers.length > 0 &&
          this.props.subType === "crosstalkPatch" ? (
            <HeatmapCrosstalkDominantLayerSlider
              crosstalkLayers={this.props.crosstalkLayers}
              newCrosstalkLayer={this.state.newCrosstalkLayer}
              displayLeftSlider={this.state.displayLeftSlider}
              onCrosstalkDominantLayerChange={
                this.handleCrosstalkDominantLayerChange
              }
              selected={this.props.selected}
            />
          ) : null}

          {/**Crosstalk value selector */}
          {this.props.showHeatmap &&
          this.props.crosstalkPatches &&
          this.props.crosstalkPatches.length > 0 ? (
            <HeatmapCrosstalkValueSlider
              onCrosstalkValueChange={this.handleCrosstalkType}
              displayLeftSlider={this.state.displayLeftSlider}
              crosstalkValue={this.state.crosstalkValue}
              selected={this.props.selected}
              subType={this.props.subType}
            />
          ) : null}

          {/**Component/cell density selector */}
          {this.props.showHeatmap &&
          this.props.cellDensityHeatmap &&
          this.props.cellDensityHeatmap != null &&
          this.props.cellDensityHeatmap.length > 0 ? (
            <HeatmapComponentDensitySlider
              onComponentDensityValueChange={this.handleComponentDensity}
              displayLeftSlider={this.state.displayLeftSlider}
              componentTypeValue={this.state.componentTypeValue}
              selected={this.props.selected}
              subType={this.props.subType}
            />
          ) : null}

          {this.props.showHeatmap &&
          this.props.drcHeatmap &&
          this.props.drcHeatmap.length > 0 ? (
            <DrcLayerSlider
              drcLayersList={this.props.drcLayersList}
              displayLeftSlider={this.state.displayLeftSlider}
              selected={this.props.selected}
              handleDrcLayers={this.handleDrcLayers}
              drcLayer={this.state.drcLayer}
            />
          ) : null}
          {this.props.showHeatmap &&
          this.props.drcHeatmap &&
          this.props.drcHeatmap.length > 0 ? (
            <DrcNetSlider
              drcNetTypeList={this.props.drcNetTypeList}
              displayLeftSlider={this.state.displayLeftSlider}
              selected={this.props.selected}
              handleDrcNetType={this.handleDrcNetType}
              drcNetType={this.state.drcNetType}
            />
          ) : null}
          {this.props.showHeatmap &&
          this.props.drcHeatmap &&
          this.props.drcHeatmap.length > 0 ? (
            <DrcErrorTypeSlider
              drcErrorTypeList={this.props.drcErrorTypeList}
              displayLeftSlider={this.state.displayLeftSlider}
              selected={this.props.selected}
              handleDrcErrorType={this.handleDrcErrorType}
              drcErrorType={this.state.drcErrorType}
            />
          ) : null}

          {/**net density layer slider */}
          {this.props.showHeatmap &&
          this.props.netDensityHeatmap &&
          this.props.netDensityHeatmap.length > 0 ? (
            <HeatmapNetDensityLayerSlider
              netDensityLayers={this.props.netDensityLayers}
              displayLeftSlider={this.state.displayLeftSlider}
              selected={this.props.selected}
              handleNetDensityLayers={this.handleNetDensityLayers}
              netDensityLayer={this.state.netDensityLayer}
            />
          ) : null}

          {/**Loading progress on data fetch */}
          {this.props.isLoading || this.props.isLoading2 ? (
            <div
              style={{
                margin: "auto",
                position: "absolute",
                top: "50%",
                left: "50%",
              }}
            >
              <CircularProgress />
            </div>
          ) : null}
        </div>
        {/* {this.getMapTypeText()} */}
        {/* Context menu for heatmap */}
        <Menu
          anchorReference="anchorPosition"
          anchorPosition={{
            top: this.state.contextMenu.Ypos,
            left: this.state.contextMenu.Xpos,
          }}
          keepMounted
          open={
            this.state.heatmapTile != null &&
            this.state.heatmapTile !== undefined
          }
          onClose={() => {
            this.setState({ heatmapTile: null });
          }}
        >
          <MenuItem dense onClick={this.getTimingPathsFromContextMenu}>
            Get Timing Paths
          </MenuItem>
        </Menu>

        {/* Context menu for patch */}
        <Menu
          anchorReference="anchorPosition"
          anchorPosition={{
            top: this.state.contextMenu.Ypos,
            left: this.state.contextMenu.Xpos,
          }}
          keepMounted
          open={
            this.state.patchContextMenu != null &&
            this.state.patchContextMenu !== undefined
          }
          onClose={() => {
            this.setState({ patchContextMenu: null });
          }}
        >
          <MenuItem dense onClick={this.getPatchTimePath}>
            Get Timing Paths
          </MenuItem>
        </Menu>
      </React.Fragment>
    );
  }
}

export default CanvasContainer;
