import React, { Component } from "react";
import { Rect } from "react-konva";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class HeatmapNetDensityLayer extends Component {
  state = { shouldShowText: false, x: 0, y: 0, scale: 1, opacity: 0.6 };

  componentDidUpdate() {
    this.refs.rect.clearCache();
  };

  handleOnMouseOver = (text) => {
    this.setState({ opacity: 0.7 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 0.6 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseDown = (text) => {
    this.setState({ opacity: 0.7 });
    this.props.getRelativePointerPosition()
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleClick = (e, text) => {
    console.log(text);
    if(!this.props.zoomIn && !this.props.zoomOut){
      if (e.evt.detail === 1 && e.evt.button === 0) {
        // console.log('Left click');
        this.handleMouseDown(text);
      } 
    }
  };

  getDensityColor = (density) => {
    if (density >= 1) {
      return "#5b0000"
    } else if (density >= 0.9) {
      return "#a40000"
    } else if (density >= 0.8) {
      return "#c80000"
    } else if (density >= 0.7) {
      return "#ed0000"
    } else if (density >= 0.6) {
      return "#ff1212"
    } else if (density >= 0.5) {
      return "#ff3737"
    } else if (density >= 0.4) {
      return "#ff5b5b"
    } else if (density >= 0.3) {
      return "#ff8080"
    } else if (density >= 0.2) {
      return "#ffa4a4"
    } else if (density > 0) {
      return "#ffc8c8"
    }
  }


  render() {
    const { properties, netDensityLayer, layersList } = this.props;
    let visible = true;
    const tooltip_text = "NetDensity: " + properties.net_density + "\n" +
                         "llx: " + properties.llx.toFixed(2) + "\n" +
                         "lly: " + properties.lly.toFixed(2) + "\n" +
                         "urx: " + properties.urx.toFixed(2) + "\n" +
                         "ury: " + properties.ury.toFixed(2) + "\n"

     const width = properties.urx - properties.llx;
    const height = properties.ury - properties.lly;
    return (
      <React.Fragment>
        <Rect
          ref="rect"
          batchDraw={true}
          perfectDrawEnabled={false}
          x={properties.lly}
          y={properties.llx}
          width={height}
          height={width}
          fill={this.getDensityColor(properties.net_density)}
          visible={visible}
          onMouseDown={e => {this.handleClick(e, tooltip_text)}}
          // onMouseOver={e => { this.handleOnMouseOver(properties.component_density) }}
          onMouseOut={this.handleOnMouseOut}
          opacity={this.state.opacity}
          scaleX={this.state.scale}
          scaleY={this.state.scale}
          onContextMenu={(e) => {
            e.evt.preventDefault();
            // this.props.ContextMenu(properties , e)
          }}
        />
      </React.Fragment>
    );
  }
}

export default HeatmapNetDensityLayer;
