import React, { Component } from "react";
import { Rect, Text } from "react-konva";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class Components extends Component {
  state = {
    textWidth: 1, // to measure width of the name
  };

  componentDidMount() {
    this.setState({
      textWidth: this.textNode.getTextWidth(),
    });
  }

  componentDidUpdate()
  {
    this.rectangle.clearCache();
    this.textNode.clearCache();
  }

  render() {
    const { name, properties, stageScale, rotation } = this.props;
    return (
      <React.Fragment>
        <Rect
          ref={(rectangle) => (this.rectangle = rectangle)}
          perfectDrawEnabled={false}
          batchDraw={true}
          x={properties.y1}
          y={properties.x1}
          width={properties.height}
          height={properties.width}
          stroke="black"
          strokeWidth={1 / stageScale}
          fill="#9B59B6"
          opacity={0.7}
          onContextMenu={(e) => {
            e.evt.preventDefault();
            this.props.onDriver(this.props.name, e);
          }}
        />
        <Text
          ref={(node) => {
            this.textNode = node;
          }}
          text={name}
          x={properties.y1 + properties.height / 2 + 15 / (2 * stageScale)}
          y={
            properties.x1 +
            properties.width / 2 -
            this.state.textWidth / (2 * stageScale)
          }
          fontSize={15}
          fontFamily="Times New Roman"
          fill="white"
          scaleX={1 / stageScale}
          scaleY={1 / stageScale}
          visible
          opacity={0.8}
          rotation={360 - rotation}
        />
      </React.Fragment>
    );
  }
}

export default Components;

