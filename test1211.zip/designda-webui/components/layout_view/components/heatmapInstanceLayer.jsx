import React, { Component } from "react";
import { Rect, Star } from "react-konva";
// import Tooltip from "@mui/material/Tooltip";

class HeatmapInstanceLayer extends Component {
  state = { shouldShowText: false, x: 0, y: 0, scale: 1, opacity: 0.8 };

  componentDidUpdate() {
    this.refs.rect.clearCache();
  };

  handleOnMouseOver = (text) => {
    this.setState({ opacity: 0.7 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 0.8 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseDown = (text) => {
    this.setState({ opacity: 0.7 });
    this.props.getRelativePointerPosition()
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleClick = (e, text) => {
    let ret="";
    console.log(text.component_name);
    if(!this.props.zoomIn && !this.props.zoomOut){
      if (e.evt.detail === 1 && e.evt.button === 0) {
        console.log('Left click');
        if(text.component_name){
          this.handleMouseDown("Name: "+text.component_name+'\n'+"Ref: "+text.cell_ref_name);
        }else{
          ret = this.props.instanceToolTip(text);
          this.handleMouseDown(ret);
        }
      } 
    }
  };

  getDensityColor = (prop, color) => {
    if(prop.component_name)
      return this.props.theme=="light"?color[0]:color[2]
    if (prop.density >= 1) {
      return color[0]
    } else if (prop.density >= 0.6) {
      return color[1]
    } else if (prop.density >= 0.3) {
      return color[2]
    } else if (prop.density > 0) {
      return color[3]
    }
  }

  render() {
    const { properties, stageScale, theme } = this.props;
    let color = null;
    let visible = true;
    let colorListLight = [
      ["#4d3200", "#b37500", "#ffb01a", "#ffd380"], // for Light theme
      // ["#f0f0f5", "#b2b5cc", "#7579a4", "#474b6c"], // for Dark theme
      ["#556b14", "#99c125", "#c3e269", "#e5f3bf"], // for Light theme
      // ["#faebf1", "#e59ab8", "#cf497f", "#8e254f"], // for Dark theme
    ];
    let colorListDark = [
      ["#f0f0f5", "#b2b5cc", "#7579a4", "#474b6c"], // for Dark theme
      ["#faebf1", "#e59ab8", "#cf497f", "#8e254f"], // for Dark theme
    ];
    if (theme=="light"){
      color =
        colorListLight[
          this.props.colorPicker // Should take care if multiple Instances are selected
        ];
    }else{
      color =
        colorListDark[
          this.props.colorPicker // Should take care if multiple Instances are selected
        ];
    }
    

    const width = properties.urx - properties.llx;
    const height = properties.ury - properties.lly;
    return (
      <React.Fragment>
        <Rect
          ref="rect"
          batchDraw={true}
          perfectDrawEnabled={false}
          x={properties.lly}
          y={properties.llx}
          width={height}
          height={width}
          fill={this.getDensityColor(properties, color)}
          visible={visible}
          onMouseDown={e => {this.handleClick(e, properties)}}
          // onMouseOver={e => { this.handleOnMouseOver(properties.density) }}
          onMouseOut={this.handleOnMouseOut}
          opacity={this.state.opacity}
          scaleX={this.state.scale}
          scaleY={this.state.scale}
          // onContextMenu={(e) => {
          //   e.evt.preventDefault();
          //   this.props.ContextMenu(properties , e)
          // }}
        />
        {stageScale < 20 && properties.component_name ? (
          <Star
            x={(properties.ury + properties.lly) / 2}
            y={(properties.urx + properties.llx) / 2}
            outerRadius={8 / stageScale}
            innerRadius={2 / stageScale}
            visible={visible}
            fill={color[1]}
            numPoints={4}
          />
        ) : null}
      </React.Fragment>
    );
  }
}
export default HeatmapInstanceLayer;
