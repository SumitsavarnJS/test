import React, { Component } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Canvas from "./canvas";
import NavBar2 from "./ZoomNavBar";
import _ from "lodash";
import { drawPort} from "../LayoutViewApis";

class PortContainer extends Component {
  state = {
    zoomIn: false,
    zoomOut: false,
    canvasKey: 1,
    contextMenu: { Xpos: 0, Ypos: 0 },
    heatmapSideNavwidth: "0px",
    taskSelected: 0,
  };

  constructor(props) {
    super(props);
    this.canvas = React.createRef();
    this.handleNavBarSelect = this.handleNavBarSelect.bind(this);
  }

  componentDidMount() {
    if (this.props.config !== undefined) {
      const config = this.props.config;
      this.setState({
        dataLocation: config.dataLocation,
        bucket: config.bucket,
      });
    }
    this.getPort();
  }

  /**
   * To handle right click on canvas
   * sets name of the component
   * to perform futher context menu actions
   * @param {rightClikEvent} e
   */
  handleContextMenu = (name, e) => {
    if (e !== undefined && e != null)
      this.setState({
        contextMenu: { Xpos: e.evt.pageX, Ypos: e.evt.pageY },
      });
  };

  /**
   * To handle hot key press
   * @param {key Pressed} key
   */
  handleKeyPress = (key) => {
    if (key === "z") {
      this.setState({ zoomIn: true, zoomOut: false });
    } else if (key === "Z") {
      this.setState({ zoomOut: true, zoomIn: false });
    } else if (key === "f") {
      //delete previous zoom settings
      //   const config = produce(this.props.config, (configDraft) => {
      //     delete configDraft.zoom;
      //   });
      //   this.props.setConfig({
      //     reportName: this.props.currentReportName,
      //     widgetId: this.props.id,
      //     config: config,
      //   });
      this.setState({ zoomIn: false, zoomOut: false, canvasKey: Date.now() });
    }
  };

  getPort = () => {
    drawPort(
      this.props.id,
      [this.props.config.port],
      this.props.config.ttype,
      this.props.config.dataLocation,
      this.props.config.bucket,
      this.props.config.scenario,
      this.props.config
    );
  };

  /**
   * To handle the selection of tool
   * from navigation bar and sub menu
   * of heatmap
   * @param {name of the tool} name
   */
  handleNavBarSelect = (name, event) => {
    if (name === "zoomIn" && event.target.checked) {
      this.setState({
        zoomIn: true,
        zoomOut: false,
      });
    } else if (name === "zoomOut" && event.target.checked) {
      this.setState({
        zoomIn: false,
        zoomOut: true,
      });
    } else if (
      (name === "zoomOut" || name === "zoomIn") &&
      !event.target.checked
    ) {
      this.setState({
        [name]: false,
      });
    }
  };

  render() {

    return (
      <React.Fragment>
        <div
          id="canvas"
          tabIndex="0"
          style={{
            width: "100%",
            height: "90%",
            overflowX: "auto",
            overflowY: "hidden",
            fontSize: 12,
          }}
        >
          <div style={{ width: "100%", height: "90%" }}>
            <Canvas
              ref={this.canvas}
              key={this.state.canvasKey}
              id={this.props.id}
              isLoading={this.props.isLoading}
              isLoading2={this.props.isLoading2}
              board={this.props.board}
              port={this.props.port}
              macros={this.props.macros}
              blocks={this.props.blocks}
              handleContextMenu={this.handleContextMenu}
              zoomIn={this.state.zoomIn}
              zoomOut={this.state.zoomOut}
              handleKeyPress={this.handleKeyPress}
            />
            {/**Navigation bar */}
            <NavBar2
              onMenuSelect={this.handleNavBarSelect}
              zoomIn={this.state.zoomIn}
              zoomOut={this.state.zoomOut}
              selected={this.props.selected}
            />
          </div>

          {/**Loading progress on data fetch */}
          {this.props.isLoading || this.props.isLoading2 ? (
            <div
              style={{
                margin: "auto",
                position: "absolute",
                top: "50%",
                left: "50%",
              }}
            >
              <CircularProgress />
            </div>
          ) : null}
        </div>
      </React.Fragment>
    );
  }
}


export default PortContainer;
