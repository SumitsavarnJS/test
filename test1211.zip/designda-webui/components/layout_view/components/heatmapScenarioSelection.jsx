import React, { Component } from "react";
import {
  Typography,
  FormControl,
  FormControlLabel,
  FormLabel,
  RadioGroup,
  Radio,
} from "@mui/material";

class HeatmapScenario extends Component {
  handleRadioButtonChange = (event) => {
    this.setState({ value: event.target.value });
    this.props.handleScenarioSelect(event);
  };

  getDisableStatus = (index) => {
    return this.props.heatmapType == "power"
      ? !this.props.scenarioTable[index][this.props.heatmapSubTypeIndex]
      : this.props.crosstalkScenarios
      ? !this.props.crosstalkScenarios.includes(this.props.scenario[index][0])
      : true;
  };

  getFontStyle = (disabledStatus) => {
    if (disabledStatus) {
      if (this.props.theme === "dark")
        return { fontSize: "12px", color: "white" };
      else {
        return { fontSize: "12px", color: "black" };
      }
    } else {
      if (this.props.theme === "dark")
        return { fontSize: "12px", color: "white", fontWeight: "bold" };
      else {
        return { fontSize: "12px", color: "black", fontWeight: "bold" };
      }
    }
  };

  render() {
    return (
      <div
        style={{
          background: "transparent",
          top: 0,
          left: 15,
          display: this.props.displayHeatmapScenario,
          paddingTop: "60px",
          position: "absolute",
        }}
      >
        <FormControl size="small" component="fieldset">
          <FormLabel component="legend" style={{ fontSize: "15px" }}>
            Scenario
          </FormLabel>
          <RadioGroup
            column
            name="scenario"
            value={
              this.props.heatmapScenarioSelected
                ? this.props.heatmapScenarioSelected
                : ""
            }
            onChange={this.handleRadioButtonChange}
          >
            {/** List of scenarios */}
            {this.props.scenario !== undefined && this.props.scenario.length > 0
              ? this.props.scenario.map((scenario) => (
                  <FormControlLabel
                    key={this.props.scenario.indexOf(scenario)}
                    value={
                      this.props.scenario[
                        this.props.scenario.indexOf(scenario)
                      ][0]
                        ? this.props.scenario[
                            this.props.scenario.indexOf(scenario)
                          ][0]
                        : ""
                    }
                    disabled={this.getDisableStatus(
                      this.props.scenario.indexOf(scenario)
                    )}
                    control={<Radio size="small" />}
                    label={
                      <Typography
                        style={this.getFontStyle(
                          this.getDisableStatus(
                            this.props.scenario.indexOf(scenario)
                          )
                        )}
                      >
                        {
                          this.props.scenario[
                            this.props.scenario.indexOf(scenario)
                          ][0]
                        }
                      </Typography>
                    }
                  />
                ))
              : null}
          </RadioGroup>
        </FormControl>
      </div>
    );
  }
}

export default HeatmapScenario;
