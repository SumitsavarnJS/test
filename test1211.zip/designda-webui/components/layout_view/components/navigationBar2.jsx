import React, { Component } from "react";
import { Checkbox } from "@mui/material";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import ZoomInIcon from "@mui/icons-material/ZoomIn";
import ZoomOutIcon from "@mui/icons-material/ZoomOut";
import Tooltip from "@mui/material/Tooltip";

class NavBar2 extends Component {
  handleChange = (name) => (event) => {
    this.props.onMenuSelect(name, event);
  };

  render() {
    return (
      <div
        id="mySidenav"
        style={{
          height: "90%",
          width: "auto",
          position: "absolute",
          zIndex: 1,
          top: 0,
          right: 0,
          display: "block",
          backgroundColor: "transparent",
          overflowX: "hidden",
          paddingTop: "68px",
        }}
      >
        <FormGroup column>
          <Tooltip title="Zoom In" placement="left">
            <FormControlLabel
              control={
                <Checkbox
                  fontSize="small"
                  checked={this.props.zoomIn}
                  onChange={this.handleChange("zoomIn")}
                  icon={<ZoomInIcon />}
                  checkedIcon={<ZoomInIcon color="primary" />}
                  value="zoomIn"
                />
              }
              label=""
            />
          </Tooltip>

          <Tooltip title="Zoom out" placement="left">
            <FormControlLabel
              control={
                <Checkbox
                  fontSize="small"
                  checked={this.props.zoomOut}
                  onChange={this.handleChange("zoomOut")}
                  icon={<ZoomOutIcon />}
                  checkedIcon={<ZoomOutIcon color="primary" />}
                  value="zoomOut"
                />
              }
              label=""
            />
          </Tooltip>
        </FormGroup>
      </div>
    );
  }
}
export default NavBar2;
