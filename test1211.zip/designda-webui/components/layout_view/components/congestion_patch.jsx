import React, { Component } from "react";
import { Shape } from "react-konva";

/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y coordinate and vice versa
 * every widht is height and vice versa
 */
class CongestionPatch extends Component {
  state = { opacity:0.6};

  handleOnMouseOver = () => {
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(this.props.properties.congestion);
    this.props.handleShowTooltip(true);
  };
  handleOnMouseOut = () => {
    this.setState({ opacity: 0.6 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseDown=()=>{
    this.setState({ opacity: 0.8 });
    this.props.handleTooltipValue(this.props.properties.congestion);
    this.props.handleShowTooltip(true);
    this.props.getRelativePointerPosition()
  };

  handleClick = (e) => {
    if(!this.props.zoomIn && !this.props.zoomOut){
      if (e.evt.detail === 1 && e.evt.button === 0) {
        // console.log('Left click');
        this.handleMouseDown();
      } 
    }
  };

  render() {
    const { properties ,colorCodes, stageScale} = this.props;
    let color = "";
    if (properties.congestion < colorCodes[0])
      color = "#4575b4";
    else if (properties.congestion >= colorCodes[0] && properties.congestion < colorCodes[1])
      color = "#4575b4";
    else if (properties.congestion >= colorCodes[1] && properties.congestion < colorCodes[2])
      color = "#74add1";
    else if (properties.congestion >= colorCodes[2] && properties.congestion < colorCodes[3])
      color = "#abd9e9";
    else if (properties.congestion >= colorCodes[3] && properties.congestion < colorCodes[4])
      color = "#e0f3f8";
    else if (properties.congestion >= colorCodes[4] && properties.congestion < colorCodes[5])
      color = "#ffffbf";
    else if (properties.congestion >= colorCodes[5] && properties.congestion < colorCodes[6])
      color = "#fee090";
    else if (properties.congestion >= colorCodes[6] && properties.congestion < colorCodes[7])
      color = "#fdae61";
    else if (properties.congestion >= colorCodes[7] && properties.congestion < colorCodes[8])
      color = "#f46d43";
    else if (properties.congestion >= colorCodes[8] && properties.congestion < colorCodes[9])
      color = "#d73027";
    else if (properties.congestion >= colorCodes[9]) 
      color = "#a50026";

    return (
      <React.Fragment>
        <Shape
          onContextMenu={(e) => {
            e.evt.preventDefault();
            this.props.ContextMenu(properties.patch_vertices, e)
          }}
          sceneFunc={(context, shape) => {
            context.beginPath();
            for (let i = 0; i < properties.patch_vertices.length; i++) {
              context.lineTo(properties.patch_vertices[i][1], properties.patch_vertices[i][0]);
            }
            context.closePath();
            context.fillStrokeShape(shape);
          }}
          fill={color}
          stroke={"black"}
          strokeWidth={1/stageScale}          
          onMouseDown={(e) => {this.handleClick(e)}}
          // onMouseOver={this.handleOnMouseOver}
          onMouseOut={this.handleOnMouseOut}
          opacity={this.state.opacity}
        />
      </React.Fragment>
    );
  }
}

export default CongestionPatch;
