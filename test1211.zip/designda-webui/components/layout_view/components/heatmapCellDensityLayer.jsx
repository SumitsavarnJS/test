import React, { Component } from "react";
import { Rect } from "react-konva";
/**
 * Becuase of the plane roation in the stage
 * x line represents y line and vice-versa
 * So, every x coordinate is y and vice versa
 * every widht is height and vice versa
 */
class HeatmapCellDensityLayer extends Component {
  state = { shouldShowText: false, x: 0, y: 0, scale: 1, opacity: 1 };

  componentDidUpdate() {
    this.refs.rect.clearCache();
  };

  handleOnMouseOver = (text) => {
    this.setState({ opacity: 0.7 });
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleOnMouseOut = () => {
    this.setState({ opacity: 1 });
    // this.props.handleShowTooltip(false);
  };

  handleMouseDown = (text) => {
    this.setState({ opacity: 0.7 });
    this.props.getRelativePointerPosition()
    this.props.handleTooltipValue(text);
    this.props.handleShowTooltip(true);
  };

  handleClick = (e, text) => {
    if(!this.props.zoomIn && !this.props.zoomOut){
      if (e.evt.detail === 1 && e.evt.button === 0) {
        // console.log('Left click');
        this.handleMouseDown(text);
      } 
    }
  };

  getDensityColor = (density) => {
    if (density >= 1) {
      return "#ff0000"
    } else if (density >= 0.9) {
      return "#de9600"
    } else if (density >= 0.8) {
      return "#ffcb39"
    } else if (density >= 0.7) {
      return "#21c34a"
    } else if (density >= 0.6) {
      return "#008a21"
    } else if (density >= 0.5) {
      return "#016b6d"
    } else if (density >= 0.4) {
      return "#006db5"
    } else if (density >= 0.3) {
      return "#003fa4"
    } else if (density >= 0.2) {
      return "#302d67"
    } else if (density > 0) {
      return "#141450"
    }
  }


  render() {
    const { properties, componentTypeValue } = this.props;
    let color = "";
    let text = "";
    let visible = true;

    const width = properties.urx - properties.llx;
    const height = properties.ury - properties.lly;
    return (
      <React.Fragment>
        <Rect
          ref="rect"
          batchDraw={true}
          perfectDrawEnabled={false}
          x={properties.lly}
          y={properties.llx}
          width={height}
          height={width}
          fill={this.getDensityColor(properties.component_density)}
          visible={visible}
          onMouseDown={e => {this.handleClick(e, properties.component_density)}}
          // onMouseOver={e => { this.handleOnMouseOver(properties.component_density) }}
          onMouseOut={this.handleOnMouseOut}
          opacity={this.state.opacity}
          scaleX={this.state.scale}
          scaleY={this.state.scale}
          onContextMenu={(e) => {
            e.evt.preventDefault();
            this.props.ContextMenu(properties , e)
          }}
        />
      </React.Fragment>
    );
  }
}

export default HeatmapCellDensityLayer;
