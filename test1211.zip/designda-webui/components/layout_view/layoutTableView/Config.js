import React from "react";
import {produce} from "immer";
// import FormControlLabel from '@mui/material/FormControlLabel';
// import Checkbox from '@mui/material/Checkbox';
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
//import AceEditor from "react-ace";
//import Typography from '@mui/material/Typography';
import Button from "@mui/material/Button";
//import Popup from "reactjs-popup";

// utility imprts
import _ from "lodash";
import axios from "axios";

// import "ace-builds/src-noconflict/mode-python";
// import "ace-builds/src-noconflict/theme-xcode";
import useConfigStore from "../../../store/useConfigStore";
// import "brace/ext/language_tools";

import styles from "./Config.module.css";

class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      bucket: _.get(this.props.config, "bucket", ""),
      title: _.get(this.props.config, "title", ""),
      dataLocation: _.get(this.props.config, "dataLocation", ""),
      columns: _.get(this.props.config, "columns", []),
      llx: _.get(this.props.config, "llx", ""),
      lly: _.get(this.props.config, "lly", ""),
      urx: _.get(this.props.config, "urx", ""),
      ury: _.get(this.props.config, "ury", ""),
      scenario: _.get(this.props.config, "scenario", ""),
      dataDirs: [],
      dataList: [],
      columnList: [],
    };
  }

  componentDidMount() {
    // refresh column list if data is present
    this.getColumns();
  }

  getColumns = () => {
    const data = {
      bucket: this.state.bucket,
      key: this.state.dataLocation+"/"+this.state.scenario,
      ldb_file: "das_timing_path_data.ldb",
    };
    axios
      .post(_.get(useConfigStore.getState().configData, "rest_server_url", "") + "/api/fetch_parquet_columns", data)
      .then((response) => {
        this.setState({
          columnList: _.get(response.data, "data", {}),
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  onSave = () => {
    //timing path is mandatory
    if (!this.state.columns.includes("timing_path")) {
      this.state.columns.push("timing_path");
    }
    if (!this.state.columns.includes("start_point")) {
      this.state.columns.push("start_point");
    }
    if (!this.state.columns.includes("end_point")) {
      this.state.columns.push("end_point");
    }

    // update config
    const config = produce(this.props.config, (configDraft) => {
      configDraft["columns"] = this.state.columns;
      // add title only if user has provided it
      if (this.state.title.length > 0) {
        configDraft["title"] = this.state.title;
      }
      configDraft["tableId"] = Date.now();
    });

    this.props.updateConfig(config, true);
  };

  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Select Columns */}
        <Autocomplete
          id="columns-input"
          multiple
          filterSelectedOptions
          style={{ marginTop: "10px" }}
          defaultValue={this.state.columns}
          onChange={(event, newValue) => {
            this.setState({ columns: newValue });
          }}
          classes={{
            option: styles.option,
          }}
          size="small"
          options={this.state.columnList}
          renderInput={(params) => <TextField {...params} label="Columns" variant="outlined" />}
        />

        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={this.onSave}
          classes={false ? { root: styles.save_button_disabled } : { root: styles.save_button }}
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={this.props.updateConfig.bind(this, {}, false)}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}


export default Config;
