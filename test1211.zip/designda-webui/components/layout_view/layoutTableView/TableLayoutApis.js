// import { createSlice } from "@reduxjs/toolkit";
// import axios from "axios";
// import _ from "lodash";

// import {
//   showToast,
//   setLoading,
// } from "../../../analytics_widget/AnalyticsWidgetSlice";

// const slice = createSlice({
//   name: "LayoutTableViewReducer",
//   reducers: {
//     setConfig: (state, action) => {
//       state.allReports[action.payload.reportName].widgets[
//         action.payload.widgetId
//       ].config = action.payload.config;
//     },
//     setData: (state, action) => {
//       Object.assign(
//         state["Layout Table View"][action.payload.widgetId],
//         action.payload.data
//       );
//     },
//   },
// });

// export const { setConfig, setData } = slice.actions;

// /**
//  * Async actions
//  */

// // Refresh Table View Data
// export const refreshLayoutTableView = (reportName, widgetId) => (
//   dispatch,
//   getState
// ) => {
//   const state = getState();
//   const endpoint =
//     state.config.analyticsBackendUrl + "/api/fetch_timing_path_from_heatmap";
//   const config = state.allReports[reportName].widgets[widgetId].config;
//   const input = {
//     bucket: _.get(config, "bucket", ""),
//     key: _.get(config, "dataLocation", ""),
//     scenario: _.get(config, "scenario", ""),
//     cache_key: _.get(config, "cache_key", ""),
//     user: state.config.user.userid,
//   };
//   if (config.isPatch) {
//     input["patch"] = _.get(config, "patch");
//     input["sub_type"] = _.get(config, "sub_type", "patch");
//   } else if (config.sub_type && config.sub_type === "crosstalk_patch") {
//     input["sub_type"] = config.sub_type;
//     input["timingpathList"] = config.timingpathList;
//   } else {
//     input["bboxType"] = _.get(config, "bboxType","")
//     input["llx"] = _.get(config, "llx", 0);
//     input["lly"] = _.get(config, "lly", 0);
//     input["urx"] = _.get(config, "urx", 0);
//     input["ury"] = _.get(config, "ury", 0);
//   }

//   // add default columns
//   let columns = _.get(config, "columns", []);

//   if (!columns.includes("timing_path")) {
//     columns.push("timing_path");
//   }
//   if (!columns.includes("slack")) {
//     columns.push("slack");
//   }
//   if (!columns.includes("start_point")) {
//     columns.includes("start_point");
//   }
//   if (!columns.includes("end_point")) {
//     columns.push("end_point");
//   }

//   input["columns"] = columns;

//   // show loading animation
//   dispatch(
//     setLoading({
//       reportName: reportName,
//       widgetId: widgetId,
//       isLoading: true,
//     })
//   );

//   axios
//     .post(endpoint, input)
//     .then((response) => {
//       response = response.data;
//       const requestStatus = _.get(response, "status", false);
//       const plotData = _.get(response, "data", {});
//       const message = _.get(
//         response,
//         "message",
//         "No valid response from server"
//       );
//       if (!requestStatus) {
//         // stop loading animation
//         dispatch(
//           setLoading({
//             reportName: reportName,
//             widgetId: widgetId,
//             isLoading: false,
//           })
//         );
//         // show toast
//         dispatch(
//           showToast({
//             reportName: reportName,
//             widgetId: widgetId,
//             severity: "error",
//             message: message,
//           })
//         );
//       } else {
//         if (input.sub_type && input.sub_type === "crosstalk_patch") {
//           // set data
//           dispatch(
//             setData({
//               widgetId: widgetId,
//               data: plotData,
//             })
//           );
//         } else {
//           // set data
//           dispatch(
//             setData({
//               widgetId: widgetId,
//               data: plotData[0].schema,
//             })
//           );
//         }

//         // stop loading animation
//         dispatch(
//           setLoading({
//             reportName: reportName,
//             widgetId: widgetId,
//             isLoading: false,
//           })
//         );
//       }
//     })
//     .catch((error) => {
//       console.log(error);
//       // stop loading animation
//       dispatch(
//         setLoading({
//           reportName: reportName,
//           widgetId: widgetId,
//           isLoading: false,
//         })
//       );
//       // show toast
//       dispatch(
//         showToast({
//           reportName: reportName,
//           widgetId: widgetId,
//           severity: "error",
//           message: "Internal server error",
//         })
//       );
//     });
// };

// export default slice.reducer;


import React from "react";

import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import api from "../../../common/api/api";

const getLayoutTableInput = (config) => {
  const input = {
    bucket: _.get(config, "bucket", ""),
    key: _.get(config, "dataLocation", ""),
    scenario: _.get(config, "scenario", ""),
    cache_key: _.get(config, "cache_key", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
  };
  if (config.isPatch) {
    input["patch"] = _.get(config, "patch");
    input["sub_type"] = _.get(config, "sub_type", "patch");
  } else if (config.sub_type && config.sub_type === "crosstalk_patch") {
    input["sub_type"] = config.sub_type;
    input["timingpathList"] = config.timingpathList;
  } else {
    input["bboxType"] = _.get(config, "bboxType","")
    input["llx"] = _.get(config, "llx", 0);
    input["lly"] = _.get(config, "lly", 0);
    input["urx"] = _.get(config, "urx", 0);
    input["ury"] = _.get(config, "ury", 0);
  }

  // add default columns
  let columns = _.get(config, "columns", []);

  if (!columns.includes("timing_path")) {
    columns.push("timing_path");
  }
  if (!columns.includes("slack")) {
    columns.push("slack");
  }
  if (!columns.includes("start_point")) {
    columns.includes("start_point");
  }
  if (!columns.includes("end_point")) {
    columns.push("end_point");
  }

  input["columns"] = columns;
  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/api/fetch_timing_path_from_heatmap",
    input
  );

  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }

  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
    if (input.sub_type && input.sub_type === "crosstalk_patch") {
     
      useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
    } else {
      useGlobalStore.getState().setWidgetData(widgetId, fetchData.data[0].schema);
    }

  }
};

const refreshLayoutTableView = (widgetId, config) => {
  fetchWidgetData(widgetId, getLayoutTableInput(config));
};

export default refreshLayoutTableView;