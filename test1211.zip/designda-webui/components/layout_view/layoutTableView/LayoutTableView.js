// react imports
import React from "react";
import { ReactTabulator } from "react-tabulator";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import Typography from "@mui/material/Typography";

import Config from "./Config";
// import echarts from 'echarts/lib/echarts';

//utility
import _ from "lodash";
import axios from "axios";

// import actions

// css imports
import styles from "./TableView.module.css";
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import { getTimingPathCoordinates } from "../LayoutViewApis";
import * as addWidget from "../../../pages/rptdashboard/addWidget/addWidget";
import { produce } from "immer";

// Global Variables
var colors = [
  "c47541",
  "107896",
  "829356",
  "bca136",
  "c2571a",
  "e28743",
  "76b5c5",
  "873e23",
  "34eb4f",
  "34ebdf",
];
var i = 0;
let tableInst = null;

class LayoutTableView extends React.Component {
  // consturctor
  constructor(props) {
    super(props);
    this.state = {
      contextMenuOpen: false,
      // isLoading: false,
      mousePos: {
        x: 0,
        y: 0,
      },
      selectedRow: null,
      isDownloadingCSV: false,
    };
    this.ref = React.createRef();
  }

  componentDidMount() {
    tableInst = new Tabulator(this.ref.current, {
      layout: "fitColumns",
      responsiveLayout: true,
      columns: useGlobalStore?.getState()[this.props.id]?.data?.columns
        ? this.enable_filter()
        : [],
      // data={data.rows ? data.rows : []}
      placeholder: "No table data, please refresh!",
      autoResize: false,

      rowContextMenu: this.getRowContextMenu,
      persistenceID: this.props.widgetProps.config.tableId,
      ajaxURL:
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/remote_pagination2", //set url for ajax request
      ajaxContentType: "json",
      ajaxParams: {
        cacheKey: this.props.widgetProps.config.cache_key
          ? this.props.widgetProps.config.cache_key
          : data.cache_key,
        key: this.props.widgetProps.config.dataLocation,
        columns: this.props.widgetProps.config.columns,
        bucket: this.props.widgetProps.config.bucket,
        scenario: this.props.widgetProps.config.scenario,
      },
      ajaxResponse: (url, params, responseData) => {
        const tabulatorLoreFormat = {
          data: responseData.data ? responseData.data : [],
          last_page: responseData.last_page ? responseData.last_page : 0,
        };
        return tabulatorLoreFormat;
      },
      pagination: true, //enable pagination
      paginationMode: "remote", //enable remote pagination
      sortMode: "remote",
      filterMode: "remote",
      ajaxConfig: "POST",
      paginationSize: "10",
      paginationInitialPage: 1,
      paginationSizeSelector: [20],
      height: "85%",
      columnDefaults: {
        headerFilter: true,
        headerFilterLiveFilter: false,
        headerFilterPlaceholder: "...",
        tooltip: true,
      },
      ajaxResponse: (url, params, responseData) => {
        const tabulatorLoreFormat = {
          data: responseData.data ? responseData.data : [],
          last_page: responseData.last_page ? responseData.last_page : 0,
        };
        return tabulatorLoreFormat;
      },
      columnDefaults: {
        headerFilter: true,
        headerFilterLiveFilter: false,
        headerFilterPlaceholder: "...",
        tooltip: true,
      },
      cellContext: (event, cell) => {
        localStorage.setItem("cell", JSON.stringify(cell._cell.value));
      },
      ajaxError: (error) => {
        console.log(error);
      },
    });
  }

  setLoading = (loadingProps) => {
    const uiState = produce(
      useGlobalStore.getState()[this.props.id].uiState,
      (uiStateDraft) => {
        uiStateDraft.cirlularLoading = _.get(
          loadingProps,
          "cirlularLoading",
          false
        );
      }
    );
    useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  addClockPathDetailsWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    var randomColor = colors[i++];
    if (i == 10) i = 0;
    // Math.floor(Math.random()*16777215).toString(16);
    console.log(randomColor);
    const row = rowObj._row;
    const config = this.props.widgetProps.config;
    const timing_path = row.data.__object
      ? row.data.__object.split("/").slice(1).join("/")
      : row.data.timing_path;
    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }
    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found / meta data not found',
      });
      return;
    }
    // get_clock_path_meta_data
    const request = {
      timing_path: timing_path,
      bucket: config.bucket,
      key: config.dataLocation,
      hold: hold,
      scenario: this.props.widgetProps.config.scenario,
      col: [
        "start_point_name",
        "start_point_object_type",
        "end_point_name",
        "end_point_object_type",
        "timing_path",
        "start_point_clock",
        "end_point_clock",
      ],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_clock_path_meta_data",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const stpt = _.get(response, "start_point_name", "");
        const stpt_type = _.get(response, "start_point_object_type", "");
        const ept = _.get(response, "end_point_name", "");
        const ept_type = _.get(response, "end_point_object_type", "");
        const stpt_clk = _.get(response, "start_point_clock", "");
        const ept_clk = _.get(response, "end_point_clock", "");
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        }
        if (stpt_type[0] == "in" && ept_type[0] == "out") {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "info",
            message: "Both Launch clock and Capture clock paths Does not exist",
          });
          this.setLoading({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            cirlularLoading: false,
          });
        } else {
          this.addLaunchClockDetailsWidget(
            e,
            rowObj,
            timing_path,
            stpt[0],
            stpt_type[0],
            ept[0],
            ept_type[0],
            stpt_clk[0],
            ept_clk[0],
            randomColor
          );
          this.addCaptureClockDetailsWidget(
            e,
            rowObj,
            timing_path,
            stpt[0],
            stpt_type[0],
            ept[0],
            ept_type[0],
            stpt_clk[0],
            ept_clk[0],
            randomColor
          );
        }
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch meta data for clock Details",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  showToast = (toast) => {
    const uiState = produce(
      useGlobalStore.getState()[this.props.id].uiState,
      (uiStateDraft) => {
        uiStateDraft.isToastOpen = true;
        uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
        uiStateDraft.toastMessage = _.get(toast, "message", "");
      }
    );
    useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  addLaunchClockDetailsWidget = (
    e,
    rowObj,
    timing_path,
    stpt,
    stpt_type,
    ept,
    ept_type,
    stpt_clk,
    ept_clk,
    tColor
  ) => {
    console.log(
      rowObj,
      timing_path,
      stpt,
      stpt_type,
      ept,
      ept_type,
      stpt_clk,
      ept_clk,
      tColor
    );
    // this.setState({ isLoading: true });
    // close context menu
    this.handleMenuClose();
    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    let _stpt = stpt_type != "in" ? stpt : "";
    let _ept = ept_type != "out" ? ept : "";

    if (_stpt == "") {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Launch clock path Does not exist",
      });
      // this.setState({ isLoading: false });
      return;
    }

    const request = {
      timing_path: timing_path,
      start_point: _stpt,
      end_point: _ept,
      start_point_clock: stpt_clk,
      end_point_clock: ept_clk,
      bucket: config.bucket,
      key: config.dataLocation,
      ttype: row.data.__ttype ? row.data.__ttype : "max",
      scenario: this.props.widgetProps.config.scenario,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_launch_clock_details",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const colors = _.get(data, "colors", {});
        const dataLocation = _.get(data, "dataLocation", "");
        const bucket = _.get(data, "bucket", "");
        const cache_key = _.get(response, "cache_key", "");
        const scenario = _.get(data, "scenario", "");
        const column_list = _.get(data, "column_list", []);
        const version = _.get(response, "version", "1");
        const v1_default_columns = [
          "object_level",
          "object_name",
          "object_type",
          "cell_delay_capture",
          "net_delay_capture",
          "transition_capture",
        ];
        const v2_default_columns = [
          "s_no",
          "obj_name",
          "obj_ref_name",
          "delay",
          "obj_type",
        ];
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below

          console.log(data);
          addWidget.addWidgetCommonFunction(
            this.props.rptType,
            this.props.reportKey,
            {
              name: "Timing Path Details",
              width: 20,
              height: 12,
              y: yCoord + 1,
              config: {
                title: `Launch Clock Details for ${_stpt}`,
                title_color: "#" + tColor,
                dataLocation: dataLocation,
                bucket: bucket,
                cache_key: cache_key,
                colors: colors,
                scenario: scenario,
                column_list: column_list,
                columns:
                  version === "2" ? v2_default_columns : v1_default_columns,
              },
            },
            data,
            addWidget.showWidgetDataUiState,
            this.props.index
          );
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Launch clock Details",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addCaptureClockDetailsWidget = (
    e,
    rowObj,
    timing_path,
    stpt,
    stpt_type,
    ept,
    ept_type,
    stpt_clk,
    ept_clk,
    tColor
  ) => {
    console.log(
      rowObj,
      timing_path,
      stpt,
      stpt_type,
      ept,
      ept_type,
      stpt_clk,
      ept_clk,
      tColor
    );
    // this.setState({ isLoading: true });
    // close context menu
    this.handleMenuClose();
    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    let _stpt = stpt_type != "in" ? stpt : "";
    let _ept = ept_type != "out" ? ept : "";

    if (_ept == "") {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Capture clock path Does not exist",
      });
      // this.setState({ isLoading: false });
      return;
    }

    const request = {
      timing_path: timing_path,
      start_point: _stpt,
      end_point: _ept,
      start_point_clock: stpt_clk,
      end_point_clock: ept_clk,
      bucket: config.bucket,
      key: config.dataLocation,
      ttype: row.data.__ttype ? row.data.__ttype : "max",
      scenario: this.props.widgetProps.config.scenario,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_capture_clock_details",
        request
      )
      .then((response) => {
        response = response.data;
        console.log("get_capture_clock_details", response);
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        console.log("get_capture_clock_details", data);
        const colors = _.get(data, "colors", {});
        const dataLocation = _.get(data, "dataLocation", "");
        const bucket = _.get(data, "bucket", "");
        const cache_key = _.get(response, "cache_key", "");
        const scenario = _.get(data, "scenario", "");
        const column_list = _.get(data, "column_list", []);
        const version = _.get(response, "version", "1");
        const v1_default_columns = [
          "object_level",
          "object_name",
          "object_type",
          "cell_delay_capture",
          "net_delay_capture",
          "transition_capture",
        ];
        const v2_default_columns = [
          "s_no",
          "obj_name",
          "obj_ref_name",
          "delay",
          "obj_type",
        ];
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          addWidget.addWidgetCommonFunction(
            this.props.rptType,
            this.props.reportKey,
            {
              name: "Timing Path Details",
              width: 20,
              height: 12,
              y: yCoord + 1,
              config: {
                title: `Capture clock Details for ${_ept}`,
                title_color: "#" + tColor,
                dataLocation: dataLocation,
                bucket: bucket,
                cache_key: cache_key,
                colors: colors,
                scenario: scenario,
                column_list: column_list,
                columns:
                  version === "2" ? v2_default_columns : v1_default_columns,
              },
            },
            data,
            addWidget.showWidgetDataUiState,
            this.props.index
          );
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Capture Clock Details",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };
  // -------------------------------------------------

  // Function to add Timing Path Details Widget (copied from TableView.js)
  addDataPathDetailsWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    this.handleMenuClose();
    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (row == null) return;
    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }

    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found / meta data not found',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      timing_path: row.data.__object
        ? row.data.__object.split("/").slice(1).join("/")
        : row.data.timing_path,
      bucket: config.bucket,
      key: config.dataLocation,
      hold: hold,
      scenario: this.props.widgetProps.config.scenario,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_data_path_details",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const colors = _.get(response, "colors", {});
        const data = _.get(response, "data", {});
        const cache_key = _.get(response, "cache_key", "");
        const dataLocation = _.get(response, "dataLocation", "");
        const bucket = _.get(response, "bucket", "");
        const column_list = _.get(response, "column_list", []);
        const version = _.get(response, "version", "1");
        const v1_default_columns = [
          "object_level",
          "object_name",
          "object_type",
          "cell_delay_capture",
          "net_delay_capture",
          "transition_capture",
        ];
        const v2_default_columns = [
          "s_no",
          "obj_name",
          "obj_ref_name",
          "delay",
          "obj_type",
        ];
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          console.log({
            name: "Timing Path Details",
            width: 20,
            height: 12,
            y: yCoord + 1,
            config: {
              title: `Data Path Details for ${
                row.data.__object
                  ? row.data.__object.split("/").slice(1).join("/")
                  : row.data.timing_path
              }`,
              dataLocation: dataLocation,
              bucket: bucket,
              cache_key: cache_key,
              colors: colors,
              column_list: column_list,
              columns:
                version === "2" ? v2_default_columns : v1_default_columns,
            },
          });
          // add table view widget below
          addWidget.addWidgetCommonFunction(
            this.props.rptType,
            this.props.reportKey,
            {
              name: "Timing Path Details",
              width: 20,
              height: 12,
              y: yCoord + 1,
              config: {
                title: `Data Path Details for ${
                  row.data.__object
                    ? row.data.__object.split("/").slice(1).join("/")
                    : row.data.timing_path
                }`,
                dataLocation: dataLocation,
                bucket: bucket,
                cache_key: cache_key,
                colors: colors,
                column_list: column_list,
                columns:
                  version === "2" ? v2_default_columns : v1_default_columns,
              },
            },
            data,
            addWidget.showWidgetDataUiState,
            this.props.index
          );
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Data Path Details",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // Function to add Timing Path Summary Widget (copied from TableView.js)
  addTimingPathSummaryWidget = (e, rowObj) => {
    // close context menu
    this.handleMenuClose();

    const row = rowObj._row;
    const config = this.props.widgetProps.config;

    if (!("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found',
      });
      return;
    }

    const request = {
      timing_path: row.data.timing_path,
      bucket: config.bucket,
      key: config.dataLocation,
      scenario: config.scenario,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_timing_path_summary",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          addWidget.addWidgetCommonFunction(
            this.props.rptType,
            this.props.reportKey,
            {
              name: "Timing Path Summary",
              width: 20,
              height: 12,
              y: yCoord + 1,
              config: {
                title: `Timing Path Summary for ${row.data.timing_path}`,
              },
            },
            data,
            addWidget.showWidgetDataUiState,
            this.props.index
          );
        }
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Timing Summary Data",
        });
      });
  };

  //Show timing path on parent layout view
  showTimingPath = (e, rowObj) => {
    const config = this.props.widgetProps.config;
    const row = rowObj._row;
    let timingPaths = [];
    timingPaths.push(row.data.timing_path);
    // config.showTimingPath(this.state.selectedRow.data.timing_path, config.scenario )
    getTimingPathCoordinates(config.parentLayoutId, config, timingPaths);

    this.handleMenuClose();
  };

  // to copy to clipboard
  copyToClipboard = () => {
    const copyStr = localStorage.getItem("cell")
      ? JSON.parse(localStorage.getItem("cell"))
      : {};
    // if it is a secured connection (https) then it will write it to sytem clipboard directly
    if (window.isSecureContext && navigator.clipboard !== undefined) {
      navigator.clipboard.writeText(copyStr);
    }

    //otherwise it will copy to web ui clipboard
    else {
      var textarea = document.createElement("textarea");
      textarea.textContent = copyStr;
      document.body.appendChild(textarea);

      var selection = document.getSelection();
      var range = document.createRange();

      range.selectNode(textarea);
      selection.removeAllRanges();
      selection.addRange(range);

      document.execCommand("copy");
      selection.removeAllRanges();

      document.body.removeChild(textarea);
    }
  };

  showInIcc2 = (e, rowObj) => {
    const config = this.props.widgetProps.config;
    const row = rowObj._row;
    // string that needs to be copied
    let copyStr = `report_timing -from ${row.data.start_point} -to ${row.data.end_point} -scenarios ${config.scenario}`;
    localStorage.setItem("cell", JSON.stringify(copyStr));
    this.copyToClipboard();
  };

  copyCellValue = () => {
    this.copyToClipboard();
  };

  // Function to return context menu for rows
  getRowContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show Clock Path Details",
        action: (e, row) => {
          this.addClockPathDetailsWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show Data Path Details",
        action: (e, row) => {
          this.addDataPathDetailsWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show Timing Path Summary",
        action: (e, row) => {
          this.addTimingPathSummaryWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.showTimingPath(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in icc2/fc",
        action: (e, row) => {
          this.showInIcc2(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyCellValue(e, row);
        },
      },

      // <Menu
      //   anchorReference="anchorPosition"
      //   anchorPosition={{
      //     top: this.state.mousePos.y,
      //     left: this.state.mousePos.x,
      //   }}
      //   keepMounted
      //   open={this.state.contextMenuOpen}
      //   onClose={this.handleMenuClose}
      // >
      //   <MenuItem dense onClick={this.addClockPathDetailsWidget}>
      //     Show Clock Path Details
      //   </MenuItem>
      //   <MenuItem dense onClick={this.addDataPathDetailsWidget}>
      //     Show Data Path Details
      //   </MenuItem>
      //   <MenuItem dense onClick={this.addTimingPathSummaryWidget}>
      //     Show Timing Path Summary
      //   </MenuItem>
      //   <MenuItem dense onClick={this.showTimingPath}>
      //     Show in Layout
      //   </MenuItem>
      //   <MenuItem dense onClick={this.showInIcc2}>
      //     Show in icc2/fc
      //   </MenuItem>
      //   <MenuItem dense onClick={this.copyCellValue}>
      //     Copy text
      //   </MenuItem>
      // </Menu>
    ];
  };

  handleMenuClose = () => {
    this.setState({
      contextMenuOpen: false,
    });
  };

  handleCellContextEvent = (event, cell) => {
    event.preventDefault();
    const mousePos = {
      x: event.pageX,
      y: event.pageY,
    };

    this.setState({
      mousePos: mousePos,
      contextMenuOpen: true,
      selectedRow: cell._cell.row,
      selectedCell: cell,
    });
  };

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  enable_filter = () => {
    let col = _.cloneDeep(
      _.get(useGlobalStore?.getState()[this.props.id], "data", {}).columns
    );
    for (let x = 0; x < col.length; x++) {
      if (
        col[x].field === "__object" ||
        col[x].field === "__obtype" ||
        col[x].field === "__ttype"
      ) {
        col[x].visible = false;
      }
      if (col[x].columns) {
        let len = col[x].columns.length;
        for (let y = 0; y < len; y++) {
          if (
            col[x].columns[y].field === "__object" ||
            col[x].columns[y].field === "__obtype" ||
            col[x].columns[y].field === "__ttype"
          ) {
            col[x].columns[y].visible = false;
          }
        }
      }
    }
    return col;
  };

  applyTheme = (theme) => {
    if (theme == "dark") {
      return "table-sm table-dark table-striped table-bordered";
    } else {
      return "table-sm table-striped table-bordered";
    }
  };


  downloadFile = (data, fileName) => {
    const url = window.URL.createObjectURL(new Blob([data])) 
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', fileName)
    document.body.appendChild(link)
    link.click()
    link.remove()
  }

  onDownloadTableData = () => {
    // set state to downloading
    this.setState({isDownloadingCSV: true});
    const filters = tableInst.getHeaderFilters();
    const config = this.props.widgetProps.config;
    const request = {
      cacheKey: config.cache_key ? config.cache_key : data.cache_key,
      filter: filters,
      mode: 2,
      file_format: "csv",
      scenario: config.scenario,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/download_cached_table",
        request
      )
      .then((response) => {
       const dataFromResponse = response.data;
       if(dataFromResponse) {
        const fileName = `${config.title ? config.title : 'dd_file'}_${this.props.widgetProps.name ? this.props.widgetProps.name.split(' ').join('_') : '_'}.csv`;
        this.downloadFile(dataFromResponse, fileName ? fileName : 'file.csv');
       }
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to download table data",
        });
      })
      .finally(() => {
        this.setState({isDownloadingCSV: false});
      })
  }

  // render method
  render() {
    const config = this.props.widgetProps.config;

    const data = _.get(useGlobalStore.getState()[this.props.id], "data", {});
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    if (uiState.showConfig) {
      return (
        <Config
          updateConfig={this.updateConfig}
          config={config}
          id={this.props.id}
        />
      );
    } else {
      return this.props.widgetProps.config.cache_key === "" ? ( //||
        // this.props.data.rows === undefined ||
        // Object.keys(this.props.data.rows).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <div id="analytics" className={styles.tableParent}>
          <button
            className={styles.downloadButton}
            onClick={this.onDownloadTableData}
            disabled={this.state.isDownloadingCSV}
          >
            {this.state.isDownloadingCSV ? "Downloading ..." : "Download CSV"}
          </button>
          <div
            key={_.get(useConfigStore.getState().theme)}
            className={this.applyTheme(_.get(useConfigStore.getState().theme))}
            ref={(ref) => (this.ref.current = ref)}
          />
          {/* <ReactTabulator
            key={_.get(useConfigStore.getState().theme)}
            className={this.applyTheme(_.get(useConfigStore.getState().theme))}
            layout="fitColumns"
            onRef={(ref) => (this.ref = ref)}
            columns={data.columns ? this.enable_filter() : []}
            // data={this.props.data.row ? this.props.data.row : []}
            placeholder="Please refresh the widget"
            autoResize={false}
            options={{
              rowContextMenu: this.getRowContextMenu,
              persistenceID: this.props.widgetProps.config.tableId,
              ajaxURL:
                _.get(
                  useConfigStore.getState().configData,
                  "rest_server_url",
                  ""
                ) + "/api/remote_pagination2", //set url for ajax request
              ajaxContentType: "json",
              ajaxParams: {
                cacheKey: this.props.widgetProps.config.cache_key
                  ? this.props.widgetProps.config.cache_key
                  : data.cache_key,
                key: this.props.widgetProps.config.dataLocation,
                columns: this.props.widgetProps.config.columns,
                bucket: this.props.widgetProps.config.bucket,
                scenario: this.props.widgetProps.config.scenario,
              },
              ajaxResponse: (url, params, responseData) => {
                const tabulatorLoreFormat = {
                  data: responseData.data ? responseData.data : [],
                  last_page: responseData.last_page
                    ? responseData.last_page
                    : 0,
                };
                return tabulatorLoreFormat;
              },
              pagination: true, //enable pagination
              paginationMode: "remote", //enable remote pagination
              sortMode: "remote",
              filterMode: "remote",
              ajaxConfig: "POST",
              paginationSize: "10",
              paginationInitialPage: 1,
              paginationSizeSelector: [20],
              height: "85%",
              columnDefaults: {
                headerFilter: true,
                headerFilterLiveFilter: false,
                headerFilterPlaceholder: "...",
                tooltip: true,
              },
            }}
            events={{
              cellContext: (event, cell) => {
                localStorage.setItem("cell", JSON.stringify(cell._cell.value));
              },
              ajaxError: (error) => {
                console.log(error);
              },
            }}
          /> */}
        </div>
      );
    }
  }
}

export default LayoutTableView;
