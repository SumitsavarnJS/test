// react imports
import React from "react";
import Typography from "@mui/material/Typography";
import { produce } from "immer";

// local imports
import Config from "./Config";
import SpawnedLayoutConfig from "./SpawnedLayoutConfig";
import CanvasContainer from "./components/canvasContainer";
import FlowContainer from "./components/flowContainer";
import TimingPathContainer from "./components/timingPathContainer";
import NetContainer from "./components/netContainer";
import CongestionPatchContainer from "./components/congestionPatchContainer";
import CellContainer from "./components/cellContainer";
import PortContainer from "./components/portContainer";
import InstanceContainer from "./components/instanceContainer";
import DummyNetContainer from "./components/dummyNetContainer";

import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";

import * as constants from "../../constants/constants";

import * as addWidgets from "../../pages/rptdashboard/addWidget/addWidget";

// utility imprts
import _ from "lodash";

// import actions

// css imports
import styles from "./LayoutView.module.css";

import axios from "axios";

class LayoutView extends React.Component {
  // consturctor
  constructor(props) {
    super(props);
    localStorage.setItem(`activeZoom${this.props.id}`, JSON.stringify(false));
    this.getHeatmap = this.getHeatmap.bind(this);
    this.handleHeatmap = this.handleHeatmap.bind(this);
    this.heatmapColorCode = this.heatmapColorCode.bind(this);
    this.getTimingpathSummary = this.getTimingpathSummary.bind(this);
    // this.removeAllTimingPaths = this.removeAllTimingPaths.bind(this);
  }

  state = {
    heatmaps: [],
    showHeatmap: false,
    isLoading: false,
  };

  componentDidMount() {
    const config = this.props.widgetProps.config;
    if (this.props.widgetProps.config !== undefined) {
      const config = this.props.widgetProps.config;
      if (config.hasOwnProperty("heatmap")) {
        if (
          config.heatmap.hasOwnProperty("subtype") &&
          config.heatmap.subtype === "congestionPatch"
        ) {
          this.getCongestionPatch(config.heatmap);
        } else this.getHeatmap(config.heatmap);
      }
    }
  }

  showToast = (toast) => {
    // const uiState = produce(
    //   useGlobalStore.getState()[this.props.id].uiState,
    //   (uiStateDraft) => {
    //     uiStateDraft.isToastOpen = true;
    //     uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
    //     uiStateDraft.toastMessage = _.get(toast, "message", "");
    //   }
    // );
    // useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  // setLoading = (loadingProps) => {
  //   const uiState = produce(
  //     useGlobalStore.getState()[this.props.id].uiState,
  //     (uiStateDraft) => {
  //       uiStateDraft.cirlularLoading = _.get(
  //         loadingProps,
  //         "cirlularLoading",
  //         false
  //       );
  //     }
  //   );
  //   useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  // };

  // //to resize the child canvas on parents resize
  // componentDidUpdate() {
  //   if (this.refs.canvas !== undefined) this.refs.canvas.fitStageIntoParentContainer();
  // }

  /**
   * to get scenarios where power is true
   * @param {bucket} bucket
   * @param {task dataLocation} dataLocation
   */
  getPowerScenarios = (bucket, dataLocation) => {
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_heatmap_metadata",
        {
          bucket: bucket,
          key: dataLocation,
        }
      )
      .then((response) => {
        if (Object.keys(response.data.data).length !== 0) {
          response = response.data.data;
          response = Object.entries(response);

          //setting types
          let scenarioTypes = [];
          for (let i = 0; i < response.length; i++) {
            let heatmapSubType = [];
            for (let type = 0; type < 3; type++) {
              let sub = ["power", "dynamic_power", "leakage_power"];
              let subNotFound = true;
              for (let j = 0; j < response[i][1].length; j++) {
                if (response[i][1][j] === sub[type]) {
                  subNotFound = false;
                  heatmapSubType.push(true);
                }
              }
              if (subNotFound) {
                heatmapSubType.push(false);
              }
            }
            scenarioTypes.push(heatmapSubType);
          }

          this.setState({ scenarioTable: scenarioTypes, scenario: response });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // Function to update config
  updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore.getState().setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  /**
   * to get cross talk scenarios
   */
  getCrosstalkScenario = () => {
    const config = this.props.widgetProps.config;

    let input = {};

    input["key"] = config.dataLocation;
    input["bucket"] = config.bucket;

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_crosstalk_scenario",
        input
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const scenarioData = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          this.setState({
            crosstalkScenarios: scenarioData.scenario,
            is_post_route: scenarioData.post_route,
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  /**
   * To fetch the heatmap data
   * @param {scenario,
   * heatmap type,
   * location} properties
   */
  getHeatmap = (properties) => {
    this.setState({ isLoading: true });
    // deep copy of properties param
    let _properties = _.cloneDeep(properties);
    // heatmap variable to be used for config below
    let heatmap = _.cloneDeep(properties);
    heatmap.filterCoords = {};

    // adding key, bucket, filterCoords in '_properties' -> if does not exist in 'properties'
    if (!properties.hasOwnProperty("key")) {
      _properties.key = this.props.widgetProps.config.dataLocation;
    }
    if (!properties.hasOwnProperty("bucket")) {
      _properties.bucket = this.props.widgetProps.config.bucket;
    }
    if (!properties.hasOwnProperty("filterCoords")) {
      _properties.filterCoords = {};
    }

    const config = produce(this.props.widgetProps.config, (configDraft) => {
      configDraft["heatmap"] = heatmap;
    });

    useGlobalStore
      .getState()
      .updateConfig(
        this.props.rptType,
        this.props.reportKey,
        this.props.id,
        config
      );
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_heatmap_data",
        // sending '_properties' here instead of 'properties'
        _properties
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          response = response.data;

          if (properties.type === "DRC") {
            this.setState({
              crosstalkPatches: [],
              heatmapPacthes: [],
              heatmaps: [],
              cellDensityHeatmap: [],
              pinDensityHeatmap: [],
              netDensityHeatmap: [],
              subType: "DRC",
              showHeatmap: true,
              crosstalkLayers: [],
              netDensityLayers: [],
              drcHeatmap: response.cells,
              drcLayersList: response.layerList,
              drcNetTypeList: response.netTypes,
              drcErrorTypeList: response.errorTypeList,
              showZoomFilter: true,
            });
            if (response.sampled) {
              this.showToast({
                reportName: this.props.currentReportName,
                widgetId: this.props.id,
                severity: "info",
                message: "Sampled Data",
              });
            }
          } else if (
            properties.type === "congestion" &&
            properties.sub_type === "netDensityHeatmap"
          ) {
            this.heatmapColorCode(response.min, response.max, response.step);
            this.setState({
              heatmaps: [],
              heatmapPacthes: [],
              crosstalkPatches: [],
              netDensityLayers: response.netDensityLayers,
              cellDensityHeatmap: [],
              pinDensityHeatmap: [], // modification needed based on backend data
              netDensityHeatmap: response.cells,
              showHeatmap: true,
              drcHeatmap: [],
              showZoomFilter: false,
            });
          } else if (
            properties.type === "congestion" &&
            properties.sub_type === "pinDensityHeatmap"
          ) {
            this.heatmapColorCode(response.min, response.max, response.step);
            this.setState({
              heatmaps: [],
              heatmapPacthes: [],
              crosstalkPatches: [],
              cellDensityHeatmap: [],
              pinDensityHeatmap: response.cells, // modification needed based on backend data
              netDensityHeatmap: [],
              showHeatmap: true,
              drcHeatmap: [],
              showZoomFilter: false,
            });
          } else if (
            properties.type === "timing" &&
            properties.sub_type === "cellDensityHeatmap"
          ) {
            this.setState({
              heatmaps: [],
              heatmapPacthes: [],
              crosstalkPatches: [],
              cellDensityHeatmap: response.cells, // modification needed based on backend data
              pinDensityHeatmap: [],
              netDensityHeatmap: [],
              showHeatmap: true,
              drcHeatmap: [],
              showZoomFilter: false,
            });
          } else if (
            properties.type != "timing" &&
            response.cells !== undefined &&
            response.cells.length > 0
          ) {
            this.heatmapColorCode(response.min, response.max);
            let rangeSliderValues = [];
            rangeSliderValues.push(response.min);
            rangeSliderValues.push(response.max);
            this.setState({
              heatmaps: response.cells,
              heatmapPacthes: [],
              crosstalkPatches: [],
              cellDensityHeatmap: [],
              pinDensityHeatmap: [],
              netDensityHeatmap: [],
              showHeatmap: true,
              drcHeatmap: [],
              heatmapMin: response.min,
              heatmapMax: response.max,
              newRangeValue: rangeSliderValues,
              newHideShowValue: rangeSliderValues,
              showZoomFilter: false,
            });
          } else if (properties.type === "timing") {
            this.setState({
              crosstalkPatches: response.cell_data,
              cellDensityHeatmap: [],
              pinDensityHeatmap: [],
              netDensityHeatmap: [],
              heatmapPacthes: [],
              heatmaps: [],
              drcHeatmap: [],
              subType: "timingHeatmap",
              showHeatmap: true,
              crosstalkMin: response.min,
              crosstalkMax: response.max,
              crosstalkLayers: [],
              netDensityLayers: [],
              showZoomFilter: false,
            });
            if (
              properties.sub_type &&
              properties.sub_type === "crosstalk_patch"
            ) {
              this.setState({
                subType: "crosstalkPatch",
                crosstalkLayers: response.crosstalk_layers,
                showZoomFilter: false,
              });
            }
            this.heatmapColorCode(response.max.TNS, response.min.TNS);
          }
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        console.log(error);
        this.setState({ isLoading: false });
      });
  };

  /**
   * To fetch the congestion patch data
   * @param { location} properties
   */
  getCongestionPatch = (properties) => {
    this.setState({ isLoading: true });
    const config = produce(this.props.widgetProps.config, (configDraft) => {
      configDraft["heatmap"] = Object.assign({}, properties);
      configDraft.heatmap["type"] = "congestion";
      configDraft.heatmap["subtype"] = "congestionPatch";
    });

    useGlobalStore
      .getState()
      .updateConfig(
        this.props.rptType,
        this.props.reportKey,
        this.props.id,
        config
      );

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_heatmap_patch",
        properties
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          response = response.data;
          let max = 0;
          let min = 0;
          for (let i = 0; i < response.length; i++) {
            if (response[i].congestion > max) {
              max = response[i].congestion;
            }
            if (response[i].congestion < min) {
              min = response[i].congestion;
            }
          }
          this.heatmapColorCode(min, max);
          let rangeSliderValues = [];
          rangeSliderValues.push(min);
          rangeSliderValues.push(max);
          this.setState({
            heatmapPacthes: response,
            heatmaps: [],
            drcHeatmap: [],
            showHeatmap: true,
            crosstalkPatches: [],
            cellDensityHeatmap: [],
            pinDensityHeatmap: [],
            netDensityHeatmap: [],
            showHeatmapPatch: true,
            heatmapMin: min,
            heatmapMax: max,
            newRangeValue: rangeSliderValues,
            newHideShowValue: rangeSliderValues,
          });
        }

        this.setState({ isLoading: false });
      })
      .catch((error) => {
        console.log(error);
        this.setState({ isLoading: false });
      });
  };

  /**
   * To fetch the congestion patch data
   * @param { location} properties
   */
  getPatch = (properties) => {
    this.setState({ isLoading: true });
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_patch",
        properties
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          response = response.data;
          let max = 0;
          let min = 0;
          for (let i = 0; i < response.length; i++) {
            if (response[i].congestion > max) {
              max = response[i].congestion;
            }
            if (response[i].congestion < min) {
              min = response[i].congestion;
            }
          }
          this.heatmapColorCode(min, max);
          this.setState({
            heatmapPacthes: response,
            heatmaps: [],
            drcHeatmap: [],
            showHeatmap: true,
            crosstalkPatches: [],
            showHeatmapPatch: true,
            heatmapMin: min,
            heatmapMax: max,
          });
        }

        this.setState({ isLoading: false });
      })
      .catch((error) => {
        console.log(error);
        this.setState({ isLoading: false });
      });
  };

  handleHeatmap = (value) => {
    this.setState({ showHeatmap: value });
  };

  handleHeatmapPatch = (value) => {
    this.setState({ showHeatmapPatch: value });
  };

  /**
   * To set color codes in heatmap
   * @param {min and max values } min
   */
  heatmapColorCode = (min, max, step = 0) => {
    let colorCode = [];
    if (step != 0) {
      for (let i = 0; i <= 9; i++) {
        colorCode.push(max - step * i);
      }
      colorCode.push(min);
      colorCode.reverse();
    } else {
      let diff = max - min;
      let segment = diff / 11; //to 11 color codes in heatmap layer
      for (let i = 1; i <= 11; i++) {
        colorCode.push(min + segment * i);
      }
    }
    this.setState({ colorCodes: colorCode });
  };

  /**
   * to handle range shift slider
   */
  handleHeatmapRangeShift = (e, newValue) => {
    this.setState({
      newRangeValue: newValue,
    });
    this.heatmapColorCode(newValue[0], newValue[1]);
  };

  /**
   * To handle hide and show values
   * @param {event} e
   * @param {new hide show value} newValue
   */
  handleHideShowHeatmapSlider = (e, newValue) => {
    this.setState({
      newHideShowValue: newValue,
    });
  };

  /**
   * To get timing path details and show it in a table
   * @param {input} properties
   */
  getTimingPaths = (properties) => {
    this.setState({ isLoading: true });
    const config = this.props.widgetProps.config;

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_timing_path_from_heatmap",
        properties
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const plotData = _.get(response, "data", {});
        const cache_key = _.get(response, "cache_key", "");
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget

          if (
            config.heatmap.sub_type &&
            config.heatmap.sub_type == "crosstalk_patch"
          ) {
            let tableConfig = {
              bucket: config.bucket,
              cache_key: cache_key,
              parentLayoutId: this.props.id,
              dataLocation: config.dataLocation,
              isPatch: false,
              timingpathList: properties.timingpathList,
              sub_type: "crosstalk_patch",
              llx: properties.llx,
              lly: properties.lly,
              urx: properties.urx,
              ury: properties.ury,
              tableId: Date.now(),
              // showTimingPath: this.showTimingPath,
              scenario: config.heatmap.scenario,
              title: `Timing paths for ${
                config.title !== undefined ? config.title : "Layout View"
              } {${config.heatmap.scenario}} crosstalk patch   { ${Math.round(
                properties.llx
              )}, ${Math.round(properties.lly)}, ${Math.round(
                properties.urx
              )}, ${Math.round(properties.ury)} }`,
              columns: properties.columns,
            };
            // add table view widget below
            addWidgets.addWidgetCommonFunction(
              this.props.rptType,
              this.props.reportKey,
              {
                name: "Layout Table View",
                width: 15,
                height: 9,
                y: this.props.widgetProps.y + 1,
                x: 0,
                config: tableConfig,
              },
              plotData,
              addWidgets.showWidgetDataUiState,
              this.props.index + 1
            );
          } else {
            /**
             * to add a table of timing path below the current widget
             */
            for (let i = 0; i < plotData.length; i++) {
              let tableConfig = {};
              //if timing path is asked for a rectangle shape
              if (
                config.heatmap.sub_type &&
                config.heatmap.sub_type !== "crosstalk_patch"
              ) {
                tableConfig = {
                  bucket: config.bucket,
                  cache_key: cache_key,
                  parentLayoutId: this.props.id,
                  dataLocation: config.dataLocation,
                  data: config.data,
                  isPatch: false,
                  llx: properties.llx,
                  lly: properties.lly,
                  urx: properties.urx,
                  ury: properties.ury,
                  tableId: Date.now() + i,
                  bboxType: _.get(properties, "bboxType", ""),
                  // showTimingPath: this.showTimingPath,
                  scenario: plotData[i].scenario,
                  title: `Timing paths for ${
                    config.title !== undefined ? config.title : "Layout View"
                  }   {${plotData[i].scenario}}   { ${Math.round(
                    properties.llx
                  )}, ${Math.round(properties.lly)}, ${Math.round(
                    properties.urx
                  )}, ${Math.round(properties.ury)} }`,
                  columns: properties.columns,
                };
              }
              //if timing path is asked for a patch
              else {
                tableConfig = {
                  bucket: config.bucket,
                  cache_key: cache_key,
                  parentLayoutId: this.props.id,
                  dataLocation: plotData[i].key,
                  data: config.data,
                  isPatch: true,
                  sub_type: properties.sub_type,
                  patch: properties.patch,
                  showTimingPath: this.showTimingPath,
                  scenario: plotData[i].scenario,
                  title: `Timing paths for ${
                    config.title !== undefined ? config.title : "Layout View"
                  }   {${plotData[i].scenario}}`,
                  columns: properties.columns,
                };
              }

              // add table view widget below
              addWidgets.addWidgetCommonFunction(
                this.props.rptType,
                this.props.reportKey,
                {
                  name: "Layout Table View",
                  width: 15,
                  height: 9,
                  y: this.props.widgetProps.y + 1,
                  x: 0,
                  config: tableConfig,
                },
                plotData[i].schema,
                addWidgets.showWidgetDataUiState,
                this.props.index
              );
            }
          }
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        console.log(error);
        this.setState({ isLoading: false });
      });
  };

  getCongestionPatchContainer = () => {
    return (
      <CongestionPatchContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        ports={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "ports",
          undefined
        )}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        components={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "components",
          undefined
        )}
        timingPath={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "timingPaths",
          undefined
        )}
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        heatmapPacthes={
          this.state.heatmapPacthes ? this.state.heatmapPacthes : null
        }
        showHeatmap={this.state.showHeatmap}
        handleHeatmap={this.handleHeatmap}
        getPatch={this.getPatch}
        heatmapMin={this.state.heatmapMin}
        heatmapMax={this.state.heatmapMax}
        newRangeValue={this.state.newRangeValue}
        isLoading={this.state.isLoading}
        colorCodes={this.state.colorCodes}
        showHeatmapPatch={this.state.showHeatmapPatch}
        handleHeatmapPatch={this.handleHeatmapPatch}
        getTimingPaths={this.getTimingPaths}
        heatmapColorCode={this.heatmapColorCode}
        selected={this.props.selected}
        subType={this.state.subType ? this.state.subType : null}
      />
    );
  };

  getTaskCanvasContainer = () => {
    return (
      <CanvasContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        ports={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "ports",
          undefined
        )}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        components={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "components",
          undefined
        )}
        voltageArea={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "voltageArea"
        )}
        RPBlockage={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "RPBlockage"
        )}
        RPGroup={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "RPGroup"
        )}
        timingPath={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "timingPaths",
          undefined
        )}
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        heatmaps={this.state.heatmaps ? this.state.heatmaps : null}
        heatmapPacthes={
          this.state.heatmapPacthes ? this.state.heatmapPacthes : null
        }
        drcHeatmap={this.state.drcHeatmap ? this.state.drcHeatmap : []}
        drcNetTypeList={
          this.state.drcNetTypeList ? this.state.drcNetTypeList : []
        }
        drcLayersList={this.state.drcLayersList ? this.state.drcLayersList : []}
        drcErrorTypeList={
          this.state.drcErrorTypeList ? this.state.drcErrorTypeList : []
        }
        getPowerScenarios={this.getPowerScenarios}
        getCrosstalkScenario={this.getCrosstalkScenario}
        showHeatmap={this.state.showHeatmap}
        handleHeatmap={this.handleHeatmap}
        heatmapMin={this.state.heatmapMin}
        heatmapMax={this.state.heatmapMax}
        newRangeValue={this.state.newRangeValue}
        getHeatmap={this.getHeatmap}
        cellDensityHeatmap={this.state.cellDensityHeatmap}
        pinDensityHeatmap={this.state.pinDensityHeatmap}
        netDensityHeatmap={this.state.netDensityHeatmap}
        netDensityLayers={
          this.state.netDensityLayers ? this.state.netDensityLayers : []
        }
        isLoading={this.state.isLoading}
        getCongestionPatch={this.getCongestionPatch}
        colorCodes={this.state.colorCodes}
        showHeatmapPatch={this.state.showHeatmapPatch}
        handleHeatmapPatch={this.handleHeatmapPatch}
        newHideShowValue={this.state.newHideShowValue}
        handleHideShowHeatmapSlider={this.handleHideShowHeatmapSlider}
        handleHeatmapRangeShift={this.handleHeatmapRangeShift}
        getTimingPaths={this.getTimingPaths}
        heatmapColorCode={this.heatmapColorCode}
        selected={this.props.selected}
        subType={this.state.subType ? this.state.subType : null}
        crosstalkScenarios={this.state.crosstalkScenarios}
        is_post_route={
          this.state.is_post_route ? this.state.is_post_route : null
        }
        crosstalkPatches={
          this.state.crosstalkPatches ? this.state.crosstalkPatches : null
        }
        crosstalkMin={this.state.crosstalkMin ? this.state.crosstalkMin : null}
        crosstalkMax={this.state.crosstalkMax ? this.state.crosstalkMax : null}
        crosstalkLayers={
          this.state.crosstalkLayers ? this.state.crosstalkLayers : null
        }
        scenarioTable={this.state.scenarioTable}
        scenario={this.state.scenario}
        showZoomFilter={this.state.showZoomFilter}
        handleTooltipClick={this.props.handleTooltipClick}
      />
    );
  };

  getTimingpathSummary = (timingPath) => {
    const config = this.props.widgetProps.config;
    var hold = false;
    try {
      if (config.data && config.data.toString().includes("min_")) {
        hold = true;
      }
    } catch (err) {
      console.log("Widget id", this.props.id);
      console.log("Config", config);
    }

    // temporary fix TODO: why key does not have scenario
    let keyForRequest = config.dataLocation;
    const scenarioForRequest = config.scenario
      ? config.scenario
      : config.dataLocation.split("/").slice(-1).toString();
    // if key does not have scenario -> add scenario at the end
    if (!keyForRequest.endsWith(scenarioForRequest)) {
      keyForRequest = `${keyForRequest}/${scenarioForRequest}`;
    }

    const request = {
      bucket: config.bucket,
      key: keyForRequest,
      timing_path: timingPath, //_.get(row._row.data,"timing_path","")
      hold: hold,
      scenario: scenarioForRequest,
    };
    this.setState({ isLoading: true });
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_timing_path_summary",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          this.setState({
            summaryData: _.get(data, "tableData", {}),
            isLoading: false,
          });
        }
        this.setState({ isLoading: false });
      })
      .catch((error) => {
        console.log("Failed to fetch Timingpath Sumaary Data");
        this.setState({ isLoading: false });
        console.log(error);
      });
  };

  getFlowCanvasContainer = () => {
    return (
      <FlowContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        ports={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "ports",
          undefined
        )}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        components={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "components",
          undefined
        )}
        timingPath={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "timingPaths",
          undefined
        )}
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        heatmapPacthes={
          this.state.heatmapPacthes ? this.state.heatmapPacthes : null
        }
        showHeatmap={true}
        isLoading={this.state.isLoading}
        getCongestionPatch={this.getCongestionPatch}
        colorCodes={this.state.colorCodes}
        showHeatmapPatch={this.state.showHeatmapPatch}
        handleHeatmapPatch={this.handleHeatmapPatch}
        getTimingPaths={this.getTimingPaths}
        selected={this.props.selected}
      />
    );
  };

  getTimingPathContainer = () => {
    return (
      <TimingPathContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        ports={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "ports",
          undefined
        )}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        components={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "components",
          undefined
        )}
        timingPath={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "timingPaths",
          undefined
        )}
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        summaryData={_.get(this.state, "summaryData", {})}
        heatmapPacthes={
          this.state.heatmapPacthes ? this.state.heatmapPacthes : null
        }
        showHeatmap={true}
        getTimingpathSummary={this.getTimingpathSummary}
        isLoading={this.state.isLoading}
        getCongestionPatch={this.getCongestionPatch}
        colorCodes={this.state.colorCodes}
        showHeatmapPatch={this.state.showHeatmapPatch}
        handleHeatmapPatch={this.handleHeatmapPatch}
        getTimingPaths={this.getTimingPaths}
        selected={this.props.selected}
      />
    );
  };

  getDummyNetContainer = () => {
    return (
      <DummyNetContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        // ports={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "ports", undefined)}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        // components={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "components", undefined)}
        DRC_net={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "DRC_net",
          undefined
        )} // we set "DRC and shape" data in LayoutViewSlice.js
        // timingPath={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "timingPaths", undefined)}
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        // summaryData={_.get(this.state, "summaryData", {})}

        // showHeatmap={true}
        // getTimingpathSummary={this.getTimingpathSummary}
        isLoading={this.state.isLoading}
        // getCongestionPatch={this.getCongestionPatch}
        colorCodes={this.state.colorCodes}
        // showHeatmapPatch={this.state.showHeatmapPatch}
        // handleHeatmapPatch={this.handleHeatmapPatch}
        // getTimingPaths={this.getTimingPaths}
        selected={this.props.selected}
      />
    );
  };

  getNetContainer = () => {
    return (
      <NetContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        // ports={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "ports", undefined)}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        // components={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "components", undefined)}
        shapes={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "shapes",
          undefined
        )} // we set "shapes" in LayoutViewSlice.js
        // timingPath={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "timingPaths", undefined)}
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        // summaryData={_.get(this.state, "summaryData", {})}

        // showHeatmap={true}
        // getTimingpathSummary={this.getTimingpathSummary}
        isLoading={this.state.isLoading}
        // getCongestionPatch={this.getCongestionPatch}
        colorCodes={this.state.colorCodes}
        // showHeatmapPatch={this.state.showHeatmapPatch}
        // handleHeatmapPatch={this.handleHeatmapPatch}
        // getTimingPaths={this.getTimingPaths}
        selected={this.props.selected}
      />
    );
  };

  getCellContainer = () => {
    return (
      <CellContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        // ports={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "ports", undefined)}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        // components={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "components", undefined)}
        cells={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "cells",
          undefined
        )} // we set "shapes" in LayoutViewSlice.js
        // timingPath={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "timingPaths", undefined)}
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        // summaryData={_.get(this.state, "summaryData", {})}

        // showHeatmap={true}
        // getTimingpathSummary={this.getTimingpathSummary}
        isLoading={this.state.isLoading}
        // getCongestionPatch={this.getCongestionPatch}
        colorCodes={this.state.colorCodes}
        // showHeatmapPatch={this.state.showHeatmapPatch}
        // handleHeatmapPatch={this.handleHeatmapPatch}
        // getTimingPaths={this.getTimingPaths}
        selected={this.props.selected}
      />
    );
  };

  getPortContainer = () => {
    return (
      <PortContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        //  ports={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "ports", undefined)}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        // components={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "components", undefined)}
        port={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "port",
          undefined
        )} // we set "port" in LayoutViewSlice.js
        // timingPath={_.get(_.get(useGlobalStore.getState()[this.props.id], "data", {}), "timingPaths", undefined)}
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        // summaryData={_.get(this.state, "summaryData", {})}

        // showHeatmap={true}
        // getTimingpathSummary={this.getTimingpathSummary}
        isLoading={this.state.isLoading}
        // getCongestionPatch={this.getCongestionPatch}
        colorCodes={this.state.colorCodes}
        // showHeatmapPatch={this.state.showHeatmapPatch}
        // handleHeatmapPatch={this.handleHeatmapPatch}
        // getTimingPaths={this.getTimingPaths}
        selected={this.props.selected}
      />
    );
  };

  getInstanceContainer = () => {
    return (
      <InstanceContainer
        ref="canvas"
        id={this.props.id}
        config={this.props.widgetProps.config}
        rptType={this.props.rptType}
        reportKey={this.props.reportKey}
        board={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "floorplan",
          undefined
        )}
        macros={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "macros",
          undefined
        )}
        blocks={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "blockages",
          undefined
        )}
        instComponents={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "instComponents",
          undefined
        )} // we set "instComponents" in LayoutViewSlice.js
        isLoading2={_.get(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}),
          "isLoading2",
          false
        )}
        isLoading={this.state.isLoading}
        colorCodes={this.state.colorCodes}
        selected={this.props.selected}
      />
    );
  };

  getContainer = () => {
    if (this.props.widgetProps.config.flowLayout) {
      return this.getFlowCanvasContainer();
    } else if (this.props.widgetProps.config.timingPathContainer) {
      return this.getTimingPathContainer();
    } else if (this.props.widgetProps.config.congestionPatchContainer) {
      return this.getCongestionPatchContainer();
    } else if (this.props.widgetProps.config.netContainer) {
      return this.getNetContainer();
    } else if (this.props.widgetProps.config.cellContainer) {
      return this.getCellContainer();
    } else if (this.props.widgetProps.config.portContainer) {
      return this.getPortContainer();
    } else if (this.props.widgetProps.config.instanceContainer) {
      return this.getInstanceContainer();
    } else if (this.props.widgetProps.config.dummyNetContainer) {
      return this.getDummyNetContainer();
    } else {
      return this.getTaskCanvasContainer();
    }
  };

  getConfig = () => {
    if (
      this.props.widgetProps.config &&
      (this.props.widgetProps.config.flowLayout ||
        this.props.widgetProps.config.timingPathContainer ||
        this.props.widgetProps.config.congestionPatchContainer ||
        this.props.widgetProps.config.instanceContainer)
    ) {
      return (
        <SpawnedLayoutConfig
          updateConfig={this.updateConfig}
          config={this.props.widgetProps.config}
        />
      );
    } else {
      return (
        <Config
          updateConfig={this.updateConfig}
          id={this.props.id}
          config={this.props.widgetProps.config}
        />
      );
    }
  };

  render() {
    const uiState = _.get(useGlobalStore.getState()[this.props.id], "uiState", {
      showConfig: false,
    });

    let background = "white";
    if (useConfigStore.getState().theme === "dark") {
      background = "#100c2a";
    }

    if (uiState.showConfig) {
      return this.getConfig();
    } else {
      return Object.keys(
        _.get(useGlobalStore.getState()[this.props.id], "data", {})
      ).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : useGlobalStore.getState()[this.props.id] && useGlobalStore.getState()[this.props.id].data.floorplan && Object.keys(
          _.get(useGlobalStore.getState()[this.props.id], "data", {}).floorplan
        ).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No proper data. Please reconfigure and refresh again!
        </Typography>
      ) : (
        <div
          id="LayoutView"
          style={{ background: background, height: "100%", width: "100%" }}
        >
          {this.getContainer()}
        </div>
      );
    }
  }
}

export default LayoutView;
