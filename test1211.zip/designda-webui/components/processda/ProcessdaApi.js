/* eslint-disable no-prototype-builtins*/
/*eslint-disable no-unused-vars*/

// import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import _ from "lodash";
// import { produce } from "immer";
import { toast } from "react-toastify";
import axios from "axios";
// import api from "../../../common/api/api";

// const { configData } = useConfigStore();
export const toastConfig = {
  position: toast.POSITION.BOTTOM_LEFT,
  style: {
    fontSize: "14px",
    padding: "8px 12px",
  },
};

const styleForWidth = {
  fontSize: "14px",
  padding: "8px 12px",
  width: '40rem'
}

const getTechLibListURL = "/api/fetch_techlib_list";
const getDesignTemplatesURL = "/api/fetch_design_templates";
const getVariablesURL = "/api/fetch_techlib_vars";
const getExperimentTableURL= "/api/fetch_old_exp_table"
const getVariableTableURL = "/api/fetch_var_table";
const runWorkflowURL = "/api/workflow/suite/run";
const removeExperimentURL = "/api/delete_experiments";
const addExperimentURL = "/api/add_experiments";

// some API's might have the exact same code, but it is kept separate so that response can be altered if required
export const getTechLibApi = async (inputPayload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}${getTechLibListURL}`;
  const apiResponse = await axios
    .post(url, inputPayload)
    .then((response) => {
      //   console.log({ response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response?.data?.data;
        if(apiData.length === 0) {
          const toastMsg = response?.data?.message;
          toast.error(toastMsg, toastConfig);
        }
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching the data";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

export const getDesignTemplatesApi = async (inputPayload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}${getDesignTemplatesURL}`;

  const apiResponse = await axios
    .post(url, inputPayload)
    .then((response) => {
      //   console.log({ response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response.data.data;
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching the data";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

export const getVariablesApi = async (inputPayload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}${getVariablesURL}`;

  const apiResponse = await axios
    .post(url, inputPayload)
    .then((response) => {
      //   console.log({ response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const {variables, workflow_args} = response.data.data;
        return {variables, workflow_args};
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching the data";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

export const getVariableTableApi = async (inputPayload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}${getVariableTableURL}`;

  const apiResponse = await axios
    .post(url, inputPayload)
    .then((response) => {
        // console.log({ response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const { data, selection, value_col, user_defined, type } = response.data.data;
        return { data, selection, value_col, user_defined, type };
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching the data";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

export const getExperimentTableApi = async (inputPayload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}${getExperimentTableURL}`;

  const apiResponse = await axios
    .post(url, inputPayload)
    .then((response) => {
      // console.log("old exp", { response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response?.data?.data;
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching the data";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

export const runWorkflowApi = async (inputPayload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}${runWorkflowURL}`;
  //   const payload = { techlib: techLib };

  const apiResponse = await axios
    .post(url, inputPayload)
    .then((response) => {
      // console.log({ response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response.data;
        if (apiData.suite_name && apiData.suite_dir) {
          const successMsg = `Workflow ran successfully with suite_name: ${apiData.suite_name} and suite_dir: ${apiData.suite_dir}`;
          toast.success(successMsg, {...toastConfig, style: styleForWidth});
        }
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching the data";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

export const removeExperimentApi = async (inputPayload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}${removeExperimentURL}`;

  const apiResponse = await axios
    .post(url, inputPayload)
    .then((response) => {
      // console.log("remove exp", { response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response?.data;
        if (apiData.status && apiData.message) {
          toast.success(apiData.message, {...toastConfig, style: styleForWidth});
        }else {
          toast.error(apiData.message, {...toastConfig, style: styleForWidth});
        }
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in removing experiment";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

export const addExperimentApi = async (inputPayload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}${addExperimentURL}`;

  const apiResponse = await axios
    .post(url, inputPayload)
    .then((response) => {
      // console.log("add exp", { response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response?.data;
        if (apiData.status && apiData.message) {
          toast.success(apiData.message, toastConfig);
        }
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in adding experiment";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};
