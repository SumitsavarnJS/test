import { Autocomplete, TextField } from "@mui/material";
// import { nanoid } from "nanoid";

export default function SelectComponent(props) {
  const {
    optionList,
    searchTerm,
    selectedValue,
    onSearchList,
    onSelectOption,
    labelText,
    isDisabled,
    type,
  } = props;

  const onSearch = (e, val) => {
    // call parent method
    onSearchList(e, val, type);
  };

  const onSelectValue = (e, val) => {
    // call parent method
    onSelectOption(e, val);
  };

  return (
    <Autocomplete
      disableClearable
      disabled={isDisabled}
      options={optionList}
      inputValue={searchTerm}
      onInputChange={onSearch}
      onChange={onSelectValue}
      value={selectedValue}
      sx={{ width: "30%" }}
      renderInput={(params) => (
        <TextField {...params} label={labelText} variant="outlined" />
      )}
      filterOptions={(options, { inputValue }) => {
        return options.filter((option) => {
          try {
            return new RegExp(inputValue, "i").test(option);
          } catch (e) {
            console.error("Not a valid regular expression");
          }
        });
      }}
    />
  );
}
