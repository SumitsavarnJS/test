import { Box, Button } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useState } from "react";
import { toast } from "react-toastify";
import { toastConfig } from "./ProcessdaApi";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import RefreshIcon from "@mui/icons-material/Refresh";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import BorderColorOutlinedIcon from "@mui/icons-material/BorderColorOutlined";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";

import styles from "./Processda.module.css";
export default function ConfigTable(props) {
  // const multipleRowsForDuplicationErrorMsg =
  //   "Note: Multiple configurations cannot be duplicated. Please select a single configuration to duplicate";
  const {
    rows,
    groups,
    columns,
    configurations,
    sendRowToParentToDuplicate,
    sendSelectedExperimentsToParent,
    sendRowToParentToRemove,
    sendColumnNameToParent,
    sendEditedValueToParent,
    isPopOverOpen,
    hitRefreshButton,
    isRemovingExperiment,
    isDoubleClickApiCalled,
  } = props;

  const noApiColumns = ["id", "configuration_name", "status", "user"];
  // const keyAction = ["escapeKeyDown", "cellFocusOut", "tabKeyDown"];
  // if (keyAction.includes(params.reason) || isPopOverOpen)
  //   event.defaultMuiPrevented = true;
  const [selectedExperiments, setSelectedExperiments] = useState([]);
  const [selectedCellId, setSelectedCellId] = useState("");
  const [showCellError, setShowCellError] = useState(false);

  const statusColor = {
    copied: "#f4fcd9",
    new: "#65e6fc",
    success: "#57f79c",
    failed: "#fc6c62",
    running: "#5797f7",
    killed: "#dedede",
  };

  const statusFormatter = (cell) => {
    return (
      <span>
        <span
          className={styles.cellStatus}
          style={{
            backgroundColor: statusColor[cell],
            boxShadow: `rgba(99, 99, 99, 0.2) 2px 2px 10px 0px`,
            letterSpacing: "0.5px",
          }}
        >
          {cell}
        </span>
      </span>
    );
  };
  const userFormatter = (cell) => {
    return (
      <span>
        <span>
          <AccountCircleOutlinedIcon sx={{ height: 18 }} />
          {cell}
        </span>
      </span>
    );
  };
  // generate columns
  const calculatedColumns =
    columns &&
    columns
      .map((colName) => {
        const colObj = {};
        const isColumnStatusOrUser = colName === "status" || colName === "user";
        colObj.field = colName;
        colObj.headerName = colName;
        colObj.sortable = false;
        colObj.minWidth = colName === "configuration_name" ? "200" : "150";
        colObj.editable = !isColumnStatusOrUser;
        colObj.headerClassName = "exp-table-header";
        if (colName === "status") {
          colObj.renderCell = (params) => statusFormatter(params.value);
        }
        if (colName === "user") {
          colObj.renderCell = (params) => userFormatter(params.value);
        }
        return colObj;
      })
      .filter((colObj) => colObj.field !== "id");

  const iconCol = {
    field: "icon",
    headerName: "",
    sortable: false,
    editable: false,
    width: "50",
    renderCell: (params) =>
      params.row.status === "copied" ? (
        <BorderColorOutlinedIcon sx={{ height: 20 }} />
      ) : (
        <LockOutlinedIcon sx={{ height: 20 }} />
      ),
  };
  calculatedColumns.unshift(iconCol);
  const [columnsForTable, setColumnsForTable] = useState(calculatedColumns);

  // add center align in group
  const groupModel =
    groups &&
    groups.map((groupObj) => {
      return { ...groupObj, headerClassName: "exp-table-group-header" };
    });

  const onDuplicateRow = () => {
    if (selectedExperiments && selectedExperiments.length > 0) {
      sendRowToParentToDuplicate(selectedExperiments);
    } else {
      toast.info(
        `Please pick experiments from table to duplicate`,
        toastConfig
      );
    }
  };
  const onRemoveRow = () => {
    if (selectedExperiments && selectedExperiments.length > 0) {
      sendRowToParentToRemove(selectedExperiments);
    } else {
      toast.info(`Please pick experiments from table to remove`, toastConfig);
    }
  };

  const onRefreshTable = () => {
    hitRefreshButton();
  };

  const onRowSelection = (ids) => {
    const selectedIDs = new Set(ids);
    const selectedRowData = rows.filter((row) => selectedIDs.has(row.id));
    setSelectedExperiments(selectedRowData);
    sendSelectedExperimentsToParent(selectedRowData);
  };

  const onResize = (obj) => {
    const forField = obj.colDef.field;
    const widthVal = obj.width;
    const copyOfColumns = [...columnsForTable];
    const updatedColumns = copyOfColumns.map((colObj) => {
      if (colObj.field === forField) {
        colObj.width = widthVal;
        return colObj;
      }
      return colObj;
    });
    setColumnsForTable(updatedColumns);
  };

  const onCellDoubleClick = (params) => {
    // console.log("check", { params });
    const { field, id, formattedValue: currentCellValue } = params;
    // do not send to parent for certain columns -> columns for which API call is not required
    if (!noApiColumns.includes(field)) {
      sendColumnNameToParent(field, id, currentCellValue);
      setSelectedCellId(id); // used for styling
    }
  };

  const cellClassName = (params) => {
    // if error is present, make row red in color
    if (params.id === selectedCellId && showCellError) {
      return "selected-cell-error";
    } else if (params.id === selectedCellId) {
      return "selected-cell";
    } else if (params.row.status !== "copied") {
      return "read-only-cell";
    }
    return "";
    // return params.id === selectedCellId ? "selected-cell" : "";
  };

  const onEditCellStop = (params, event) => {
    // console.log("reason", params.reason);
    // Enter / Tab / Escape will result in saving edited value | focus out will NOT

    const newValue = event?.target?.value;
    const { field, id, formattedValue: oldValue } = params;
    // handle same configuration name error here
    // check if user updated the configuration_name column,
    if (field === "configuration_name") {
      // if yes -> check if same configuration name exists
      // since configuration_name is unique, do not allow same names
      const allConfigNames = configurations.map(
        (configObj) => configObj.configuration_name
      );
      if (allConfigNames.includes(newValue)) {
        // showError
        setShowCellError(true);
        setTimeout(() => {
          setShowCellError(false);
        }, 1500);
        toast.error(
          `Configuration Name: "${newValue}" already exists`,
          toastConfig
        );
        sendEditedValueToParent(field, id, oldValue);

        console.error("same config name exists");
      } else {
        // update
        setShowCellError(false);
        sendEditedValueToParent(field, id, newValue ? newValue : oldValue);
      }
    } else {
      // for other columns, send value for updation directly to parent only if popover is NOT open
      // if popover is open, focus out will trigger a re-render
      if (!isPopOverOpen) {
        setShowCellError(false);
        sendEditedValueToParent(field, id, newValue ? newValue : oldValue);
      }
    }
  };

  return (
    <div id="analytics">
      <Button
        variant="outlined"
        className={styles.experimentTableButtons}
        startIcon={<ContentCopyIcon />}
        onClick={onDuplicateRow}
      >
        Duplicate Selected Experiment(s)
      </Button>
      <Button
        variant="outlined"
        className={styles.experimentTableButtons}
        startIcon={<DeleteOutlineIcon />}
        onClick={onRemoveRow}
        disabled={isRemovingExperiment}
      >
        {isRemovingExperiment
          ? "Removing experiment(s) ..."
          : "Remove Experiment(s) and Workarea(s)"}
      </Button>
      <Button
        variant="outlined"
        className={styles.experimentTableButtons}
        startIcon={<RefreshIcon />}
        onClick={onRefreshTable}
      >
        Refresh Experiments Table
      </Button>

      <Box
        sx={{
          // minHeight: 400,
          position: "relative",
          marginTop: "2rem",
          width: "100%",
          "& .read-only-cell": {
            // backgroundColor: "rgba(0, 0, 0, 0.6)",
          },
          "& .selected-cell": {
            backgroundColor: "rgba(0, 0, 0, 0.1)",
          },
          "& .selected-cell-error": {
            transition: "0.3s ease-in-out",
            backgroundColor: "rgba(255, 0, 0, 0.6)",
          },
          "& .exp-table-header": {
            background: "linear-gradient(to left top, #f0dcf4, #fdf5ff)",
            borderRight: "2px solid #dcdcdc",
          },
          "& .exp-table-group-header": {
            background: "linear-gradient(to left top, #f0dcf4, #fdf5ff)",
          },
        }}
      >
        <DataGrid
          rows={rows}
          columns={columnsForTable}
          sx={{
            minHeight: rows && rows.length <= 7 ? 410 : 800,
            // for pagination, fixing overwritten CSS
            "& p": {
              marginBottom: 0,
            },
          }}
          disableColumnMenu
          initialState={{
            pagination: { paginationModel: { pageSize: 10 } },
          }}
          // editMode="row"
          columnGroupingModel={groupModel}
          pageSizeOptions={[5, 10, 20, 50]}
          checkboxSelection
          disableRowSelectionOnClick
          onRowSelectionModelChange={(ids) => onRowSelection(ids)}
          onColumnWidthChange={onResize}
          onCellDoubleClick={(params, event) =>
            params.row.status === "copied"
              ? onCellDoubleClick(params, event)
              : null
          }
          getCellClassName={cellClassName}
          onCellEditStop={(params, event) =>
            params.row.status === "copied"
              ? onEditCellStop(params, event)
              : null
          }
          isCellEditable={(params) => params.row.status === "copied"}
        />

        {/* overlay for loading */}
        {isDoubleClickApiCalled || isRemovingExperiment ? (
          <div className={styles.loaderOverlay}>
            {isDoubleClickApiCalled ? "Fetching data ..." : "Loading ..."}
          </div>
        ) : (
          <></>
        )}
      </Box>
    </div>
  );
}
