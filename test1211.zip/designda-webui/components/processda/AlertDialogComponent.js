import * as React from "react";
import { useState, useEffect } from "react";
import {
  Box,
  Button,
  Divider,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Slide,
  TextField,
} from "@mui/material";
import TaskAltIcon from "@mui/icons-material/TaskAlt";
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function AlertDialogComponent(props) {
  const {
    open,
    closeAlertDialog,
    type,
    confirmAlertDialog,
    title,
    primaryContent,
    secondaryContent,
    primaryButtonName,
    secondaryButtonName,
    workflowArgs,
    selectedConfigurations,
    isRunWorkflowCalled
  } = props;

  const [formState, setFormState] = useState({});

  useEffect(() => {
    // console.log("workflowArgs", workflowArgs);
    const workflowArr =
      workflowArgs && Object.keys(workflowArgs).length > 0
        ? Object.keys(workflowArgs)
        : [];
    // console.log('workflowArr', workflowArr);
    const formFields = [
      ...new Set([
        ...workflowArr,
        "block",
        "phase",
        // "flow",
        // "DUT",
        // "project",
        "suite_tag",
      ]),
    ];
    // console.log("formFields", formFields)
    const stateObj = {};
    formFields.forEach((field) => {
      stateObj[field] =
        workflowArgs && workflowArgs[field] ? workflowArgs[field] : "";
    });
    // console.log("stateObj", stateObj)
    setFormState(stateObj);
  }, [workflowArgs]);

  const onClose = () => {
    closeAlertDialog();
  };
  const onConfirm = () => {
    // if parent is using the value of form state, then fin
    //  pass in both cases i.e reset and run
    confirmAlertDialog(formState);
  };

  return (
    <React.Fragment>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={onClose}
        maxWidth="lg"
      >
        <DialogTitle sx={{ padding: "1em 2em" }}>{title}</DialogTitle>
        <DialogContent sx={{ padding: "2.5em" }}>
          <DialogContentText sx={{ marginBottom: "1em" }}>
            {primaryContent}
            <br />
            {secondaryContent}
          </DialogContentText>
          {type === "run" ? (
            <div style={{ display: "flex" }}>
              <Box
                component="form"
                sx={{
                  "& .MuiTextField-root": {
                    display: "flex",
                    flexDirection: "column",
                    width: "50ch",
                  },
                  padding: "1em",
                }}
                autoComplete="off"
              >
                {formState &&
                  Object.keys(formState).length > 0 &&
                  Object.keys(formState).map((formItem) => (
                    <TextField
                      key={formItem}
                      required
                      margin="dense"
                      name={formItem}
                      label={formItem}
                      type="text"
                      size="small"
                      variant="standard"
                      value={formState[formItem]}
                      onChange={(e) =>
                        setFormState({
                          ...formState,
                          [formItem]: e.target.value,
                        })
                      }
                      sx={{ marginBottom: "1.5rem" }}
                      autoComplete="off"
                    />
                  ))}
              </Box>
              <Divider orientation="vertical" flexItem />
              <Box
                sx={{
                  padding: "1em",
                  height: "20rem",
                  width: "20rem",
                  overflowY: "auto",
                }}
              >
                <h6>Selected Configurations : </h6>
                {selectedConfigurations && selectedConfigurations.length > 0 ? (
                  selectedConfigurations.map((config) => (
                    <div
                      key={config.configuration_name}
                      style={{
                        marginBottom: "10px",
                        width: "100%",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                      title={config.configuration_name}
                    >
                      <TaskAltIcon sx={{ color: "#1ea61e", mr: "5px" }} />
                      {config.configuration_name}
                    </div>
                  ))
                ) : (
                  <></>
                )}
              </Box>
            </div>
          ) : (
            <></>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={onClose}
            variant="outlined"
            sx={{ textTransform: "capitalize" }}
          >
            {secondaryButtonName}
          </Button>
          {/* {console.log("formstate", formState)} */}
          <Button
            onClick={onConfirm}
            variant="contained"
            disabled={
              (formState &&
              Object.values(formState).length > 0 &&
              Object.values(formState).some((el) => el.length === 0)) || (isRunWorkflowCalled)
            }
            sx={{
              textTransform: "capitalize",
              color: "#fff",
              "&:hover": {
                backgroundColor: "#8741fa",
              },
            }}
          >
            {isRunWorkflowCalled ? "Running ..." : primaryButtonName}
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
}
