/*eslint-disable no-unused-vars*/

// process-data-analytics | process exploration
import * as React from "react";
import { useState, useEffect, useRef } from "react";
import {
  Backdrop,
  Button,
  Skeleton,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  CircularProgress,
  Slide,
} from "@mui/material";
import { ReactTabulator } from "react-tabulator";
import AddIcon from "@mui/icons-material/Add";
import { nanoid } from "nanoid";
// import getConfig from "next/config";
import AlertDialogComponent from "./AlertDialogComponent";
import ConfigTable from "./ConfigTable";
// import apis
import {
  getTechLibApi,
  getDesignTemplatesApi,
  // getVariablesApi,
  getVariableTableApi,
  getExperimentTableApi,
  runWorkflowApi,
  removeExperimentApi,
  addExperimentApi,
} from "./ProcessdaApi";
import axios from "axios";

import styles from "./Processda.module.css";
import { toast } from "react-toastify";
import { toastConfig } from "./ProcessdaApi";
import clipboardCopy from "clipboard-copy";
import useConfigStore from "../../store/useConfigStore";
import SelectComponent from "./SelectComponent";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function ConfigurationComponent() {
  // const authLoginUser = useConfigStore.getState().authLoginUser;
  const processDaName = "process_data_analytics_selections";
  const { authLoginUser, setRootLevelData } = useConfigStore();

  const dialogFields = {
    resetTitle: "Reset confirmation",
    resetPrimaryContent:
      "This action will reset the selected tech-library, design-template and configuration panel. All associated techchanges will be lost.",
    resetSecondaryContent: "Are you sure you want to reset the form?",
    resetPrimaryButtonName: "Reset Configuration Panel",
    resetSecondaryButtonName: "Cancel",
    runTitle: "Run Workflow",
    runPrimaryContent: "All fields are required to run a workflow",
    runSecondaryContent: "",
    runPrimaryButtonName: "Run Workflow",
    runSecondaryButtonName: "Cancel",
  };

  // console.log("check this", useConfigStore.getState()[`${processDaName}`]);

  // default tableOptions
  const tableOptions = {
    selectable: true, // 1 for single selection, true for all selections
    // remove browser default right click
    rowContext: function (e, row) {
      e.preventDefault();
    },
    // rowContextMenu: getRowContextMenu,
    // persistenceID: widgetId,
    pagination: "local",
    paginationSize: 10,
    columnDefaults: {
      headerFilter: true,
      headerFilterLiveFilter: false,
      headerFilterPlaceholder: "Type to search ...",
      tooltip: true,
    },
    persistence: {
      filter: true,
      headerFilter: true,
      page: true,
      columns: ["width"],
    },
  };

  // stores all api responses data for a tab-content
  const [tabContentObj, setTabContentObj] = useState({});

  // loader for each tab
  const [isLoading, setIsLoading] = useState({
    techlibOptions: false,
    designTemplateOptions: false,
    tabulatorContent: false,
    cellContent: false,
    experimentTable: false,
    removeExperiment: false,
    initialBackdrop: false,
    isRunWorkflowCalled: false,
  });

  // boolean states, set default to "run"
  const [alertDialog, setAlertDialog] = useState({
    open: false,
    type: "run",
  });

  // selection based states
  const [techLibOptions, setTechLibOptions] = useState([]);
  const [techLib, setTechLib] = useState("");
  const [techLibSearchTerm, setTechLibSearchTerm] = useState("");
  const [designTemplateOptions, setDesignTemplateOptions] = useState([]);
  const [designTemplate, setDesignTemplate] = useState("");
  const [designTemplateSearchTerm, setDesignTemplateSearchTerm] = useState("");
  const [workflowArgs, setWorkflowArgs] = useState({});
  // experiment table data coming from API
  const [configList, setConfigList] = useState([]); // list of selected experiments
  const [experimentTable, setExperimentTable] = useState([]);
  const [experimentTableGroups, setExperimentTableGroups] = useState([]);
  const [experimentTableColumns, setExperimentTableColumns] = useState([]);
  const [userDefinedColumns, setUserDefinedColumns] = useState([]);
  const [configurationNameList, setConfigurationNameList] = useState([]); // [{id: , name: }, ...]
  const [showVariablesTable, setShowVariablesTable] = useState(false);

  const noRowsSelectedError =
    "Please select rows in order to add it to configuration";
  const noteForTechLib =
    "Note: Changing the tech-library will reset the Design-Template and Experiments-Table";
  const noteForRunWorkflow =
    "Note: Only editable experiments are eligible for Run Workflow";

  const noExperimentMsg = "No Experiments found to display";
  // Ref are used because states DO NOT seem to work inside Tabulator context-menu logics
  // store selected rows
  const tabulatorSelectedRowsRef = useRef([]);

  const applyTheme = () => "table-sm table-striped table-bordered";

  const fetchTechLib = async (techLibValue, valuesPresentInStore) => {
    if (authLoginUser) {
      try {
        setIsLoading({
          ...isLoading,
          techlibOptions: true,
          initialBackdrop: true,
        });
        const payload = { user: authLoginUser };
        const options = await getTechLibApi(payload);
        setTechLibOptions(options);
        // if store has a techlib value that is also present in the techlib options
        // then set techlib to that value
        if (techLibValue && options.includes(techLibValue)) {
          setTechLib(techLibValue);
        }
      } catch (err) {
        toast.error(
          `Something went wrong in fetching tech-lib list`,
          toastConfig
        );
      } finally {
        if (valuesPresentInStore) {
          setIsLoading({
            ...isLoading,
            techlibOptions: false,
          });
        } else {
          setIsLoading({
            ...isLoading,
            techlibOptions: false,
            initialBackdrop: false,
          });
        }
      }
    }
  };
  // on component Mount
  useEffect(() => {
    const storedData = useConfigStore.getState()[`${processDaName}`];
    const { techLibValue, designTemplateValue } = storedData || {};
    const areBothValuesPresentInStore =
      techLibValue &&
      techLibValue.length > 0 &&
      designTemplateValue &&
      designTemplateValue.length > 0;
    fetchTechLib(techLibValue, areBothValuesPresentInStore);
    return () => {
      console.info("cleaning up");
      const source = axios.CancelToken.source();
      source.cancel("cancel operation due to component mounting");
    };
  }, []);

  const onRunBtnClick = () => {
    setAlertDialog({ type: "run", open: true });
  };

  const getDesignTemplates = async (designTemplateValue) => {
    try {
      setIsLoading({ ...isLoading, designTemplateOptions: true });
      const payload = { techlib: techLib, user: authLoginUser };
      const designOptions = await getDesignTemplatesApi(payload);
      // designOptions is an array of strings
      setDesignTemplateOptions(designOptions);

      // if store has a design-template value that is also present in the design-template options
      // then set design-template to that value
      if (designTemplateValue && designOptions.includes(designTemplateValue)) {
        setDesignTemplate(designTemplateValue);
      }
    } catch (err) {
      toast.error(
        `Something went wrong in fetching design-templates list`,
        toastConfig
      );
    } finally {
      setIsLoading({
        ...isLoading,
        designTemplateOptions: false,
        initialBackdrop: false,
      });
    }
  };

  // on tech-lib change, calling api for tech-data
  useEffect(() => {
    // check if techLib is selected then => call API
    if (techLib && techLib.length > 0) {
      const storedData = useConfigStore.getState()[`${processDaName}`];
      const { designTemplateValue } = storedData || {};
      // fetch design templates
      getDesignTemplates(designTemplateValue);
    }
  }, [techLib]);

  // all tab content related methods

  const rowToString = (rowObj) => Object.values(rowObj).join("");

  // const selectRowOnRender = (row) => {
  //   const rowData = row.getData();
  //   if(selectedRowsList[activeTab].includes(rowData)) {
  //     row.select();
  //   }
  //   return row
  // }

  const onRowSelect = (e) => {
    const rowData = e._row.data;
    const allSelections = tabulatorSelectedRowsRef.current; // get the array
    const updatedSelections =
      tabContentObj["selection_type"] === "many"
        ? [...allSelections, rowData]
        : [rowData];
    tabulatorSelectedRowsRef.current = updatedSelections;
  };

  const onRowDeselect = (e, row) => {
    const rowData = e._row.data;
    const allSelections = tabulatorSelectedRowsRef.current; // get the object
    const deselectedString = rowToString(rowData);
    const updatedSelections =
      allSelections && allSelections.length > 0
        ? allSelections.filter(
            (rowObj) => rowToString(rowObj) !== deselectedString
          )
        : [];
    tabulatorSelectedRowsRef.current = updatedSelections;
  };

  const regexBasedFilter = (headerValue, rowValue, rowData, filterParams) => {
    //headerValue - the value of the header filter element (input)
    //rowValue - the value of the column in this row
    //rowData - the data for the row being filtered
    //filterParams - params object passed to the headerFilterFuncParams property
    try {
      return RegExp(headerValue, "i").test(rowValue);
    } catch (error) {
      console.error("Filter cannot be applied");
    }
  };

  const updateEditedValue = (
    experimentTableColumn,
    experimentId,
    updatedCellValue
  ) => {
    const originalExperimentRow = experimentTable.filter(
      (expRow) => expRow.id === experimentId
    )[0];

    const shallowCopyOfExpRow = { ...originalExperimentRow };

    const copyOfExperiments = [...experimentTable]; // array of objects

    const updatedExperiments = copyOfExperiments.map((obj) => {
      if (obj.id === experimentId) {
        shallowCopyOfExpRow[experimentTableColumn] = updatedCellValue;
        return shallowCopyOfExpRow; //post update, return the row
      } else {
        return obj;
      }
    });
    setExperimentTable(updatedExperiments);
    // clear selected rows ref
    tabulatorSelectedRowsRef.current = [];

    // data for store, to be stored in root level data
    const storeData = {
      techLibValue: techLib,
      designTemplateValue: designTemplate,
      copiedExperiments: updatedExperiments.filter(
        (exp) => exp.status === "copied"
      ),
    };
    setRootLevelData(processDaName, storeData);
  };

  const onCopyCellValue = async (val) => {
    try {
      await clipboardCopy(val);
    } catch (err) {
      toast.error(`Something went wrong in copying cell data`, toastConfig);
    }
  };

  const getCellContextMenu = (e, cell) => {
    const menuArray = [
      {
        label: "Copy Text",
        action: (e, cell) => {
          const cellData = cell.getValue();
          onCopyCellValue(cellData);
        },
      },
    ];
    return menuArray;
  };

  const getTableData = async (tabName, experimentId, currentCellValue) => {
    try {
      // check if columnName (tabName) is user-defined
      if (userDefinedColumns.includes(tabName)) {
        updateEditedValue(tabName, experimentId, currentCellValue);
      }
      else {
        // else its not user defined, call API for tabulator data
        setIsLoading({ ...isLoading, tabulatorContent: true });
        const payload = {
          techlib: techLib,
          user: authLoginUser,
          variable: tabName,
          design_template: designTemplate,
        };
        // respData is an object
        const respData = await getVariableTableApi(payload);
        if (respData) {
          const { data, selection, value_col, user_defined, type } = respData;
          // check for user_defined
          if (!user_defined) {
            // user defined is false -> data will be an array -> render table in dialog
            if (data) {
              const firstRowObj = data.length > 0 ? data[0] : {};
              const columns = Object.keys(firstRowObj);
              const tableColumns = [];
              // construct columns
              columns.forEach((colName) => {
                const colObj = {
                  title: colName,
                  field: colName,
                  headerSort: true,
                  headerFilterFunc: regexBasedFilter,
                  resizable: true,
                  contextMenu: getCellContextMenu,
                };
                tableColumns.push(colObj);
              });
              // construct options
              const options = {
                ...tableOptions,
                selectable: selection === "many" ? true : 1, // how many rows can be selected in a table
                // persistenceID: activeTab,
                // rowContextMenu: getRowContextMenu,
                // selected: selectedRowsList[activeTab]
              };
              // update content of tab
              setTabContentObj({
                data: data,
                columns: tableColumns,
                table_options: options,
                column_name: value_col,
                selection_type: selection,
                user_defined: user_defined,
                tab_name: tabName,
                experiment_id: experimentId,
                current_value: currentCellValue,
              });
              // show dialog
              setShowVariablesTable(true);
            } else {
              console.error("No data received from API");
            }
          }
        }
      }
    } catch (err) {
      toast.error(`Something went wrong in fetching metadata`, toastConfig);
    } finally {
      setIsLoading({ ...isLoading, tabulatorContent: false });
    }
  };

  const closeAlertDialog = () => {
    setAlertDialog({ ...alertDialog, open: false });
  };

  const confirmResetAlertDialog = () => {
    setTechLib("");
    setTechLibSearchTerm("");
    setDesignTemplate("");
    setDesignTemplateSearchTerm("");
    setTabContentObj({});
    tabulatorSelectedRowsRef.current = [];
    setAlertDialog({ ...alertDialog, open: false });
  };

  const onSearchList = (e, val, type) => {
    type === "tech-lib"
      ? setTechLibSearchTerm(val)
      : setDesignTemplateSearchTerm(val);
  };

  const getIdNameRelation = (experimentRows) => {
    const arr =
      experimentRows &&
      experimentRows.length > 0 &&
      experimentRows.map((expObj) => {
        const obj = {};
        obj.id = expObj.id;
        obj.configuration_name = expObj.configuration_name;
        return obj;
      });
    return arr;
  };

  const resetExpTable = () => {
    setExperimentTable([]);
    setExperimentTableGroups([]);
    setExperimentTableColumns([]);
    setUserDefinedColumns([]);
    setWorkflowArgs({});
    setConfigList([]);
  };

  const getExpTable = async () => {
    try {
      // reset the experiment table first
      resetExpTable();
      setIsLoading({ ...isLoading, experimentTable: true });

      const storedData = useConfigStore.getState()[`${processDaName}`];
      const { copiedExperiments } = storedData || {};

      const payload = {
        techlib: techLib,
        user: authLoginUser,
        design_template: designTemplate,
      };
      const {
        data: experimentRows,
        workflow_args,
        groups,
        columns,
        user_defined_columns,
      } = await getExperimentTableApi(payload);

      // exclude experiments that are duplicated in both api response and copiedExperiments
      const filteredCopiedExperiments =
        copiedExperiments && copiedExperiments.length > 0
          ? copiedExperiments.filter(
              (expCopy) =>
                !experimentRows.some(
                  (expObj) =>
                    expObj.configuration_name === expCopy.configuration_name
                )
            )
          : [];

      // update experiment table as per response
      const allExps =
        copiedExperiments && copiedExperiments.length > 0
          ? [...experimentRows, ...filteredCopiedExperiments]
          : experimentRows;
      setExperimentTable(allExps);
      setExperimentTableGroups(groups);
      setExperimentTableColumns(columns);
      setWorkflowArgs(workflow_args);
      setUserDefinedColumns(user_defined_columns);
      // get all configuration names
      const configNameList = getIdNameRelation(experimentRows);
      setConfigurationNameList(configNameList);

      // data for store, to be stored in root level data
      const storeData = {
        techLibValue: techLib,
        designTemplateValue: designTemplate,
        copiedExperiments: filteredCopiedExperiments,
      };
      setRootLevelData(processDaName, storeData);
    } catch (err) {
      toast.error(
        `Something went wrong in fetching experiments table`,
        toastConfig
      );
    } finally {
      setIsLoading({ ...isLoading, experimentTable: false });
    }
  };
  // on tech-lib change, calling api for tech-data
  useEffect(() => {
    // check if designTemplate is selected then => call API
    if (designTemplate && designTemplate.length > 0) {
      // tabs in UI are referred to as variables
      // getTabs();
      // get the experiment table as well
      getExpTable();
    }
  }, [designTemplate]);

  // on RUN WORKFLOW confirm
  const confirmRunAlertDialog = async (formState) => {
    try {
      setIsLoading({ ...isLoading, isRunWorkflowCalled: true });
      // construct the config
      const config = {};
      configList.forEach((configObj) => {
        const { configuration_name: _, ...rest } = configObj;
        config[configObj.configuration_name] = { ...rest };
      });
      // construct the payload
      const payload = {
        workflows: ["experiment_generator"],
        args: {
          config: config,
          user: authLoginUser, //authLoginUser
          techlib: techLib, // techLib state
          design_template: designTemplate, // selected design template
          project: techLib && techLib.length > 0 ? techLib.split("/")[0] : "",
          ...formState,
          // ...workflowArgs, // replace value from formState
        },
        tag: formState.suite_tag,
      };
      // console.log({ formState, payload, workflowArgs });
      const runApiResponse = await runWorkflowApi(payload);
      if (
        runApiResponse &&
        runApiResponse.suite_name &&
        runApiResponse.suite_dir
      ) {
        const addApiPayload = {
          config: config,
          user: authLoginUser, //authLoginUser
          techlib: techLib, // techLib state
          design_template: designTemplate, // selected design template
        };
        const addApiResponse = await addExperimentApi(addApiPayload);
        if (addApiResponse && addApiResponse.status) {
          // get the experiment table
          getExpTable();
        }
      }
    } catch (err) {
      toast.error(`Something went wrong in running the workflow`, toastConfig);
    } finally {
      setIsLoading({ ...isLoading, isRunWorkflowCalled: false });
      setAlertDialog({ ...alertDialog, open: false });
    }
  };

  const onChangeTechLib = (evt, value) => {
    setTechLib(value);
    setDesignTemplate("");
    setDesignTemplateSearchTerm("");
    setTabContentObj({});
    tabulatorSelectedRowsRef.current = [];
    setExperimentTable([]);
    setExperimentTableColumns([]);
    setExperimentTableGroups([]);
    setUserDefinedColumns([]);
    setConfigurationNameList([]);
    // data for store, to be stored in root level data
    // since changing the tech-lib should also change corresponding design template and local copied experiments
    const storeData = {
      techLibValue: value,
      designTemplateValue: "",
      copiedExperiments: [],
    };
    setRootLevelData(processDaName, storeData);
  };

  const onChangeDesignTemplate = (evt, value) => {
    setDesignTemplate(value);
    // data for store, to be stored in root level data
    // since changing the design-template should also change corresponding local copied experiments
    const storeData = {
      techLibValue: techLib,
      designTemplateValue: value,
      copiedExperiments: [],
    };
    setRootLevelData(processDaName, storeData);
  };

  const duplicateRowFromChild = (rowsArr) => {
    // console.log("row-to-copy", rowsArr);
    const existingExpLength = experimentTable.length;
    // loop through selected rows
    const newRows = rowsArr.map((selectedRow, index) => {
      const uniqueNumber = existingExpLength + index + 1;
      const { id, configuration_name } = selectedRow;
      return {
        ...selectedRow,
        id: `${id}_${uniqueNumber}`,
        configuration_name: `${configuration_name}_${uniqueNumber}`,
        status: "copied",
        user: authLoginUser,
      };
    });
    // update experiment table which is an array of objects
    const allExps = [...experimentTable, ...newRows];
    setExperimentTable(allExps);
    const configNameList = getIdNameRelation(newRows);
    setConfigurationNameList([...configurationNameList, ...configNameList]);

    // data for store, to be stored in root level data
    const storeData = {
      techLibValue: techLib,
      designTemplateValue: designTemplate,
      copiedExperiments: allExps.filter((exp) => exp.status === "copied"),
    };
    setRootLevelData(processDaName, storeData);
  };

  const removeLocalExperimentsIfAny = (copiedRowsArr) => {
    if (copiedRowsArr.length > 0) {
      const copiedArrIds = copiedRowsArr.map((row) => row.id); // ids of local copied rows , an array
      // data for store, to be stored in root level data
      const dataFromStore = useConfigStore.getState()[`${processDaName}`];
      // update the store for copiedExperiments
      const storeData = {
        techLibValue: techLib,
        designTemplateValue: designTemplate,
        copiedExperiments: dataFromStore?.copiedExperiments.filter(
          (exp) => !copiedArrIds.includes(exp.id)
        ),
      };
      setRootLevelData(processDaName, storeData);
    }
  };

  const getPayloadForRemovingExperiments = (experimentsArr) => {
    const trailNamesObj = {};
    experimentsArr.forEach((row) => {
      const { configuration_name, user } = row;
      trailNamesObj[configuration_name] = user;
    });
    const payload = {
      user: authLoginUser, //authLoginUser
      techlib: techLib, // techLib state
      design_template: designTemplate, // selected design template
      trial_names: trailNamesObj,
    };
    return payload;
  };

  const removeRowFromChild = async (rowsArr) => {
    try {
      setIsLoading({ ...isLoading, removeExperiment: true });

      const copiedRowsArr = rowsArr.filter((row) => row.status === "copied");
      const otherRowsArr = rowsArr.filter((row) => row.status !== "copied");
      // there are 3 possible scenarios
      // case 1: user has selected both copied and non-copied experiments
      // case 2: user has selected only copied experiments
      // case 1: user has selected only non-copied experiments
      if (copiedRowsArr.length > 0 && otherRowsArr.length > 0) {
        // hit API
        // check response of API
        // if api-status -> true, proceed with copied experiments deletion
        const payload = getPayloadForRemovingExperiments(otherRowsArr);
        const removeExpResp = await removeExperimentApi(payload);

        if (removeExpResp && removeExpResp.status) {
          // remove the local experiments if selected from state and global store
          removeLocalExperimentsIfAny(copiedRowsArr);
          // get the experiment table
          getExpTable();
        }
      } else if (copiedRowsArr.length > 0 && otherRowsArr.length === 0) {
        // directly remove experiments
        // no need of checking for user as copied experiments belong to loggedin user and available only for that user
        removeLocalExperimentsIfAny(copiedRowsArr);
        // get the experiment table
        getExpTable();
      } else if (copiedRowsArr.length === 0 && otherRowsArr.length > 0) {
        const payload = getPayloadForRemovingExperiments(otherRowsArr);
        // console.log("payload", payload);
        const removeExpResp = await removeExperimentApi(payload);

        // console.log("removeExpResp", removeExpResp);
        if (removeExpResp && removeExpResp.status) {
          // get the experiment table
          getExpTable();
        }
      }
    } catch (err) {
      toast.error(
        `Something went wrong in removing experiment(s)`,
        toastConfig
      );
    } finally {
      setIsLoading({ ...isLoading, removeExperiment: false });
    }
  };

  const selectedRowsFromChild = (rowsArr) => {
    // config list will be the set of selected experiments
    setConfigList(rowsArr);
  };

  const onCancelTabulatorPopUp = () => {
    setShowVariablesTable(false);
    tabulatorSelectedRowsRef.current = [];
  };

  const onAddTabulatorSelectedRowsToConfig = () => {
    // get selected rows
    const tabulatorSelectedRows = tabulatorSelectedRowsRef.current; // an array of objects
    if (tabulatorSelectedRows.length > 0) {
      // add it to the column of the experiment table
      // get id of experiment row,
      // tab_name is column name of experiment table,
      // column_name is tabulators column name for which value is to be extracted
      const {
        experiment_id,
        tab_name,
        column_name: columnValueRequired,
      } = tabContentObj;
      const originalExperimentRow = experimentTable.filter(
        (expRow) => expRow.id === experiment_id
      )[0];

      const shallowCopyOfExpRow = { ...originalExperimentRow };

      const copyOfExperiments = [...experimentTable]; // array of objects

      const valueOfSelectedRows = tabulatorSelectedRows.map(
        (selectedObj) => selectedObj[columnValueRequired]
      ); // array
      const updatedExperiments = copyOfExperiments.map((obj) => {
        if (obj.id === experiment_id) {
          shallowCopyOfExpRow[tab_name] = valueOfSelectedRows;
          return shallowCopyOfExpRow; //post update, return the row
        } else {
          return obj;
        }
      });
      setExperimentTable(updatedExperiments);
      setShowVariablesTable(false);
      // clear selected rows ref
      tabulatorSelectedRowsRef.current = [];

      // data for store, to be stored in root level data
      const storeData = {
        techLibValue: techLib,
        designTemplateValue: designTemplate,
        copiedExperiments: updatedExperiments.filter(
          (exp) => exp.status === "copied"
        ),
      };
      setRootLevelData(processDaName, storeData);
    }
  };

  return (
    // configurationContainer contains tabContainer, tabBodyContainer and buttonContainer
    <div className={styles.configurationContainer}>
      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={isLoading.initialBackdrop}
        // isLoading.initialBackdrop
      >
        <CircularProgress color="inherit" sx={{ mr: 2 }} /> Fetching data ...
      </Backdrop>
      <div className={styles.selectionContainer}>
        {/* Tech Lib Selection */}
        <SelectComponent
          optionList={techLibOptions ? techLibOptions : []}
          searchTerm={techLibSearchTerm}
          selectedValue={techLib}
          onSearchList={onSearchList}
          onSelectOption={onChangeTechLib}
          labelText={"Select or Search a Tech Library"}
          isDisabled={techLibOptions && techLibOptions.length === 0}
          type={"tech-lib"}
        />

        {/* Design Template Selection */}
        <SelectComponent
          optionList={designTemplateOptions ? designTemplateOptions : []}
          searchTerm={designTemplateSearchTerm}
          selectedValue={designTemplate}
          onSearchList={onSearchList}
          onSelectOption={onChangeDesignTemplate}
          labelText={"Select or Search a Design Template"}
          isDisabled={
            designTemplateOptions && designTemplateOptions.length === 0
          }
          type={"design-template"}
        />
      </div>

      {/* helper texts for Select's */}
      <div className={styles.helperText}>
        {experimentTable && experimentTable.length > 0 ? noteForTechLib : ""}
        {isLoading.techlibOptions ? (
          <div className={styles.selectLoader}>
            <CircularProgress size={15} sx={{ mr: "10px" }} /> Fetching Techlib
            Options ...
          </div>
        ) : (
          <></>
        )}
        {isLoading.designTemplateOptions ? (
          <div className={styles.selectLoader}>
            <CircularProgress size={15} sx={{ mr: "10px" }} /> Fetching Design
            Templates ...
          </div>
        ) : (
          <></>
        )}
      </div>

      <hr className={styles.customDivider} />

      {/* render config table */}
      <div className={styles.tableContainer}>
        {experimentTable && experimentTable.length > 0 ? (
          <>
            <h6>Experiments:</h6>
            <ConfigTable
              rows={experimentTable}
              groups={experimentTableGroups}
              columns={experimentTableColumns}
              configurations={configurationNameList}
              sendRowToParentToDuplicate={duplicateRowFromChild}
              sendRowToParentToRemove={removeRowFromChild}
              sendSelectedExperimentsToParent={selectedRowsFromChild}
              sendColumnNameToParent={getTableData}
              sendEditedValueToParent={updateEditedValue}
              isPopOverOpen={showVariablesTable}
              hitRefreshButton={getExpTable}
              isRemovingExperiment={isLoading.removeExperiment}
              isDoubleClickApiCalled={isLoading.tabulatorContent}
            />
            {/* button container */}
            <div className={styles.tableButtonContainer}>
              <div>
                <Button
                  variant="contained"
                  startIcon={<AddIcon />}
                  onClick={onRunBtnClick}
                  disabled={
                    (configList && configList.length === 0) ||
                    (configList &&
                      configList.filter((row) => row.status !== "copied")
                        .length >= 1)
                  }
                >
                  Run Workflow For Selected Experiment(s)
                </Button>
              </div>
              <div className={styles.helperText}>{noteForRunWorkflow}</div>
            </div>
          </>
        ) : experimentTable && isLoading.experimentTable ? (
          <Skeleton
            variant="rectangular"
            animation="wave"
            className={styles.skeletonLoader}
          />
        ) : (
          <h6>{noExperimentMsg}</h6>
        )}
      </div>

      {/* dialog component to show alert */}

      <AlertDialogComponent
        open={alertDialog.open}
        closeAlertDialog={closeAlertDialog}
        type={alertDialog.type}
        confirmAlertDialog={
          alertDialog.type === "reset"
            ? confirmResetAlertDialog
            : confirmRunAlertDialog
        }
        title={dialogFields[`${alertDialog.type}Title`]}
        primaryContent={dialogFields[`${alertDialog.type}PrimaryContent`]}
        secondaryContent={dialogFields[`${alertDialog.type}SecondaryContent`]}
        primaryButtonName={dialogFields[`${alertDialog.type}PrimaryButtonName`]}
        secondaryButtonName={
          dialogFields[`${alertDialog.type}SecondaryButtonName`]
        }
        workflowArgs={workflowArgs}
        selectedConfigurations={configList}
        isRunWorkflowCalled={isLoading.isRunWorkflowCalled}
      />

      {/* dialog to show TABLE */}
      <Dialog
        open={showVariablesTable}
        onClose={() => setShowVariablesTable(false)}
        TransitionComponent={Transition}
        // maxWidth="xl"
        fullScreen
      >
        <DialogTitle sx={{ padding: "16px 24px 10px 24px" }}>
          For <strong>{tabContentObj["tab_name"]}</strong>, you are allowed{" "}
          <strong>{tabContentObj["selection_type"]}</strong> selection(s) of{" "}
          <strong>{tabContentObj["column_name"]}</strong>
          <div className={styles.helperText}>{noRowsSelectedError}</div>
        </DialogTitle>
        <DialogContent>
          <div id="analytics">
            <ReactTabulator
              key={nanoid()}
              className={applyTheme()}
              // style={{ marginTop: "10px", height: "98%", border: 0 }}
              layout="fitDataStretch"
              responsiveLayout="collapse"
              autoResize={false}
              resizableColumnFit={true}
              columns={tabContentObj["columns"]}
              data={tabContentObj["data"]}
              options={tabContentObj["table_options"]}
              // rowFormatter = {selectRowOnRender}
              events={{
                rowSelected: (event, row) => {
                  onRowSelect(event);
                },
                rowDeselected: (event, row) => {
                  // if many selections are possible, allow method
                  // this will enhance performance
                  // as for 'single' selection deselect and select happen together, so state setting is expensive
                  tabContentObj["selection_type"] === "many"
                    ? onRowDeselect(event)
                    : null;
                },
              }}
            />
          </div>
        </DialogContent>
        <DialogActions>
          <Button
            variant="outlined"
            sx={{ textTransform: "capitalize" }}
            onClick={onCancelTabulatorPopUp}
          >
            Cancel
          </Button>
          <Button
            sx={{ textTransform: "capitalize" }}
            onClick={onAddTabulatorSelectedRowsToConfig}
            variant="contained"
          >
            Add selection to configuration
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
