import { useMsal } from '@azure/msal-react';
 
const SignOutButton = () => {
  const { instance } = useMsal();
    instance.logoutPopup().catch(e => {
      console.error(e);
    });
};
 
export default SignOutButton;