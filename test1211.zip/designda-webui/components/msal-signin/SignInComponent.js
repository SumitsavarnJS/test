// components/SignInButton.js
import { useMsal } from '@azure/msal-react';
import loginStyles from '../../pages/Login/login.module.css'
 
const SignInButton = () => {
  const { instance } = useMsal();
 
  const handleLogin = () => {
    instance.loginPopup().catch(e => {
      console.error(e);
    });
  };
 
  return <button className={loginStyles.azureLoginBtn} onClick={handleLogin}>Sign in with Azure SSO</button>;
};
 
export default SignInButton;