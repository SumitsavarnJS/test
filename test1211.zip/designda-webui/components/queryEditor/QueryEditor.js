import React from "react";
import AceEditor from "react-ace";
import Box from "@mui/material/Box";

import _ from "lodash";

import "ace-builds/src-noconflict/mode-python";
import "ace-builds/src-noconflict/ext-language_tools";
import "ace-builds/src-noconflict/theme-xcode";
// import { maxHeight } from "@mui/system";
// import { overflowY } from "@xstyled/styled-components";

const Editor = (props) => {

  const aceEditorStyle ={
    maxHeight:'500px',
    overflowY:'auto'
  }
  return (
    <Box style={{
      maxHeight:'500px',
      overflowY:'auto'
    }}>
      <Box id="example"></Box>
      <AceEditor
        placeholder={_.get(
          props,
          "placeholder",
          "Please modify df object depending on the query."
        )}
        mode={_.get(props, "mode", "python")}
        theme={_.get(props, "theme", "xcode")}
        name={_.get(props, "name", "code_editor")}
        width={_.get(props, "width", "100%")}
        onChange={(value, event) => {
          props.onChange(value, event);
        }}
        fontSize={_.get(props, "fontSize", 16)}
        maxLines={_.get(props, "maxLines", Infinity)}
        showPrintMargin={_.get(props, "showPrintMargin", true)}
        showGutter={_.get(props, "showGutter", true)}
        highlightActiveLine={_.get(props, "highlightActiveLine", true)}
        value={_.get(props, "value", "")}
        setOptions={_.get(props, "setOptions", {
          enableBasicAutocompletion: true,
          enableLiveAutocompletion: true,
          enableSnippets: false,
          showLineNumbers: true,
          tabSize: 2,
        })}
        minLines={_.get(props, "minLines", 1)}
        readOnly={_.get(props, "readOnly", false)}
      />
    </Box>
  );
};

export default Editor;
