import React, { Component } from "react";
import _ from "lodash";
import Rule from "./Rule";
import axios from "axios";
import { ReactTabulator } from "react-tabulator";
import Button from "react-bootstrap/Button";
import useConfigStore from "../../store/useConfigStore";
import styles from "./Policy.module.css";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";

class Policy extends Component {
  state = {
    showRule: false,
    policyTableColumns: [
      {
        title: "Rule Id",
        field: "rule_id",
        visible: false,
      },
      {
        title: "Rule",
        field: "rule",
      },
      {
        title: "Query",
        field: "query",
        visible: false,
      },
      {
        title: "Datatype",
        field: "dataType",
        visible: false,
      },
      {
        title: "Months",
        field: "months",
        visible: false,
      },
      {
        title: "Days",
        field: "days",
        visible: false,
      },
      {
        title: "Action",
        field: "action",
      },
      {
        title: "Notice Period(in days)",
        field: "notification_period",
      },
      {
        title: "Active",
        field: "active",
      },
    ],
    policyTableData: [],
    ruleData: {},
    disableEdit: true,
    disableDelete: true,
    editMode: null,
    openDeleteConfirmDialog: false,
    openEditDialog: false,
  };

  constructor(props) {
    super(props);
    this.talbleRef = React.createRef();
    this.handleRuleForm = this.handleRuleForm.bind(this);
    this.handleButtonDisable = this.handleButtonDisable.bind(this);
    this.handleEditMode = this.handleEditMode.bind(this);
  }

  componentDidMount() {
    this.fetchTableData();
  }

  rowSelected = (_row) => {
    const row = _.get(_row, "_row");
    _row.getElement().style.backgroundColor = "#7098c2";
    this.setState({ ruleData: _.get(row, "data", {}), disableEdit: false });
    const data = _.get(row, "data", {});
    if (_.get(data, "active", false)) {
      this.setState({ disableDelete: true });
    } else this.setState({ disableDelete: false });
  };

  handleDeleteButton = () => {
    this.openDeleteConfirmDialog();
  };

  openDeleteConfirmDialog = () => {
    this.setState({ openDeleteConfirmDialog: true });
  };

  closeDeleteConfirmDialog = () => {
    this.setState({ openDeleteConfirmDialog: false });
  };

  deleteRule = () => {
    this.closeDeleteConfirmDialog();
    const requestData = { id: _.get(this.state.ruleData, "rule_id", 0) };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") + "/api/delete_retention_rule",
        requestData
      )
      .then((response) => {
        if (_.get(response, "status", false)) {
          this.talbleRef.current
            .deleteRow(this.state.ruleData.id)
            .then(this.handleButtonDisable(true))
            .catch();
        } else {
        }
      })
      .catch((error) => {});
  };

  handleButtonDisable = (val) => {
    this.setState({ disableEdit: val });
  };

  handleRuleForm = (val) => {
    this.setState({ showRule: val });
  };

  editRule = () => {
    this.closeEditDialog();
    this.handleButtonDisable(true);
    this.handleRuleForm(true);
    this.setState({ editMode: "edit" });
  };

  addNewRule = () => {
    this.setState({ ruleData: {} });
    this.handleRuleForm(true);
    this.setState({ editMode: "create" });
  };

  handleEditMode = (mode) => {
    this.setState({ editMode: mode });
  };

  handleRuleBack = () => {
    this.handleRuleForm(false);
    this.setState({ disableDelete: true });
    this.handleButtonDisable(true);
    this.fetchTableData();
  };

  rowFormatter = (row) => {
    //row - row component
    var data = row.getData();
    if (data.active) {
      row.getElement().style.backgroundColor = "#74b87d";
    }
  };

  fetchTableData = () => {
    axios
      .get(_.get(useConfigStore.getState().configData, "rest_server_url", "") + "/api/get_data_retention_policy")
      .then((response) => {
        if (_.get(response, "status", false)) {
          const responseData = _.get(response, "data", {});
          const data = _.get(responseData, "data", {});
          this.setState({ policyTableData: _.get(data, "rows", []) });
        }
      })
      .catch((error) => {});
  };

  rowDeselected = (_row) => {
    const data = _row.getData();
    if (data.active) {
      _row.getElement().style.backgroundColor = "#74b87d";
    } else if (_row.getPosition(true) % 2 == 0) {
      _row.getElement().style.backgroundColor = "#ffffff";
    } else {
      _row.getElement().style.backgroundColor = "#f0f0f0";
    }
    this.setState({ disableDelete: true });
    this.handleButtonDisable(true);
  };

  openEditDialog = () => {
    this.setState({ openEditDialog: true });
  };

  closeEditDialog = () => {
    this.setState({ openEditDialog: false });
  };

  applyTheme = (theme) => {
    if (theme == "dark") {
      return "table-sm table-dark table-striped table-bordered";
    } else {
      return "table-sm table-striped table-bordered";
    }
  };

  render() {
    if (this.state.showRule) {
      return (
        <Rule
          theme={this.props.theme}
          data={this.state.ruleData}
          handleRuleBack={this.handleRuleBack}
          editMode={this.state.editMode}
          handleEditMode={this.handleEditMode}
        />
      );
    } else {
      return (
        <div id="policyContents" className={styles.policyContents}>
          <div id="analytics" className={styles.policyTableDiv}>
            <h3> Data Retention Policy</h3>
            <ReactTabulator
              key={this.props.theme}
              className={this.applyTheme(this.props.theme)}
              onRef={(ref)=>(this.talbleRef=ref)}
              autoResize={false}
              columns={this.state.policyTableColumns}
              data={this.state.policyTableData}
              options={{
                selectable: 1,
                height: "80%",
                rowFormatter: this.rowFormatter,
              }}
              events={{
                rowDeselected: this.rowDeselected,
                rowSelected: this.rowSelected,
              }}
            />
          </div>
          <div id="policyBtnArea" className={styles.policyBtnArea}>
            <Button
              size="sm"
              className={`${styles.addBtn} rptButton`}
              onClick={(e) => this.addNewRule()}
            >
              Add New Rule
            </Button>

            <Button
              size="sm"
              className={styles.editBtn}
              onClick={(e) => this.openEditDialog()}
              disabled={this.state.disableEdit}
            >
              Edit
            </Button>
            <Button
              className={`${styles.delBtn} rptButton`}
              variant="danger"
              size="sm"
              onClick={(e) => this.handleDeleteButton()}
              disabled={this.state.disableDelete}
            >
              Delete
            </Button>
          </div>
          <Dialog
            fullWidth
            open={this.state.openEditDialog}
            onClose={(e) => {
              this.closeEditDialog();
            }}
          >
            <DialogTitle>{"Edit warning!"}</DialogTitle>
            <DialogContent
            //  style={{width:"60%"}}
            >
              {`Editing the rule will not update the policy for the data that have been selected!\n
              It will be applied to the new data that will be selected from this rule.`}
            </DialogContent>
            <DialogActions>
              <Button
                size="sm"
                className="rptButton"
                onClick={(e) => {
                  this.editRule();
                }}
              >
                Okay
              </Button>
            </DialogActions>
          </Dialog>
          <Dialog
            fullWidth
            open={this.state.openDeleteConfirmDialog}
            onClose={(e) => {
              this.closeDeleteConfirmDialog();
            }}
          >
            <DialogTitle>{"Delete Rule"}</DialogTitle>
            <DialogContent>
              {`Are you sure you want to delete ${_.get(
                this.state.ruleData,
                "rule",
                ""
              )}?`}
            </DialogContent>
            <div style={{ float: "left", margin: "20px" }}>
              <Button
                size="sm"
                className={`rptButton`}
                onClick={(e) => {
                  this.deleteRule();
                }}
              >
                Delete
              </Button>
              <Button
                size="sm"
                className={`rptButton`}
                style={{margin: "0px 10px" }}
                variant="danger"
                onClick={(e) => {
                  this.closeDeleteConfirmDialog();
                }}
              >
                Cancel
              </Button>
            </div>
          </Dialog>
        </div>
      );
    }
  }
}


export default Policy;
