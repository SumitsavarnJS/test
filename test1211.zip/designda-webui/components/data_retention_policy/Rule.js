import React, { Component } from "react";
import {
  FormControl,
  FormControlLabel,
  InputLabel,
  MenuItem,
  Select,
  Switch,
  TextField,
  Tooltip,
} from "@mui/material";
import Button from "react-bootstrap/Button";
import { Autocomplete } from "@mui/material";
import _ from "lodash";
import axios from "axios";

import styles from "./Policy.module.css";
import { ReactTabulator } from "react-tabulator";
import useConfigStore from "../../store/useConfigStore";
import { toast } from "react-toastify";

class Rule extends Component {
  constructor(props) {
    super(props);
  }
  state = {
    ruleValue: "",
    queryValue: [],
    monthsValue: 6,
    daysValue: 0,
    dataTypeValue: "taskData",
    activeValue: _.get(this.props.data, "active", false),
    actionValue: "DEL",
    notification_periodValue: 15,
    dataList: [],
    disableSave: true,
    validQueryFlag: true,
    dataColumns: [
      { title: "Bucket Name", field: "bucket_name" },
      { title: "Phase", field: "phase" },
      { title: "Run Tag", field: "run_tag" },
      { title: "Block", field: "block" },
      { title: "Username", field: "username" },
      { title: "Checkpoint", field: "checkpoint" },
    ],
  };

  componentDidMount() {
    const { data } = this.props;
    this.setState(
      {
        id: _.get(data, "rule_id"),
        ruleValue: _.get(data, "rule", ""),
        queryValue: _.get(data, "query", "").split("__SEP__")[0]
          ? this.getBucketToProjectValue(
              _.get(data, "query", "").split("__SEP__")
            )
          : [],
        monthsValue: _.get(data, "months", 6),
        daysValue: _.get(data, "days", 0),
        dataTypeValue: _.get(data, "dataType", "taskData"),
        activeValue: _.get(data, "active", false),
        actionValue: _.get(data, "action", "DEL"),
        notification_periodValue: _.get(data, "notification_period", 15),
      },
      this.getDataList
    );
  }

  getDataColumns = () => {
    if (this.state.dataTypeValue === "taskData") {
      return [
        { title: "Bucket Name", field: "bucket_name", visible: false },
        { title: "Phase", field: "phase" },
        { title: "Run Tag", field: "run_tag" },
        { title: "Block", field: "block" },
        { title: "Username", field: "username" },
        { title: "Checkpoint", field: "checkpoint" },
      ];
    } else if (this.state.dataTypeValue === "flowData") {
      return [
        {
          title: "Bucket Name",
          field: "bucket_name",
          visible: false,
        },
        {
          title: "Username",
          field: "username",
        },
        {
          title: "Report Name",
          field: "report_name",
        },
        {
          title: "Scenario",
          field: "scenario",
          visible: false,
        },
      ];
    } else if (this.state.dataTypeValue === "metricsData") {
      return [
        { title: "Bucket Name", field: "bucket_name", visible: false },
        { title: "Phase", field: "phase" },
        { title: "Run Tag", field: "run_tag" },
        { title: "Block", field: "block" },
        { title: "Username", field: "username" },
        { title: "Checkpoint", field: "checkpoint" },
      ];
    } else if (this.state.dataTypeValue === "techlibData") {
      return [
        { title: "Project", field: "bucket_name", visible: false },
        { title: "Username", field: "username" },
        { title: "Library", field: "library" },
        { title: "Foundry", field: "foundry" },
        { title: "Time stamp", field: "time_stamp" },
        { title: "Node", field: "node" },
        { title: "Tag", field: "tag" },
      ];
    } else if (this.state.dataTypeValue === "custom") {
      return [
        { title: "Project", field: "bucket_name", visible: false },
        { title: "Username", field: "username" },
        { title: "Key", field: "key" },
        { title: "Report type", field: "report_type" },
        { title: "Cluster", field: "cluster", visible: false },
        { title: "Time stamp", field: "time_stamp" },
        { title: "Created date", field: "created_date" },
      ];
    }
  };

  handlePolicyTimeChange = (event) => {
    if (event.target.value >= 0) {
      this.setState({
        monthsValue: event.target.value,
        daysValue: 0,
        disableSave: true,
      });
    }
  };

  handleCustomTimeChange = (event) => {
    if (event.target.value > 0 || event.target.value === "0") {
      this.setState({ daysValue: event.target.value, disableSave: true });
    }
  };

  handleRuleName = (event) => {
    this.setState({ ruleValue: event.target.value });
  };

  createRule = () => {
    const rule = {
      rule: this.state.ruleValue,
      query: this.getProjectToBucketValue(this.state.queryValue),
      months: this.state.monthsValue,
      days: this.state.daysValue,
      data_type: this.state.dataTypeValue,
      active: this.state.activeValue,
      action: this.state.actionValue,
      notification_period: this.state.notification_periodValue,
    };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/create_retention_rule",
        rule
      )
      .then((response) => {
        response = response.data;
        const success = _.get(response, "status", false);

        if (!success) {
          const message = _.get(response, "message", "Unknown error");
          toast.error(message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          console.error(message);
        } else {
          toast.success("Rule saved successfully", {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        }
      })
      .catch((error) => {});
  };

  editRule = () => {
    const rule = {
      rule: this.state.ruleValue,
      query: this.getProjectToBucketValue(this.state.queryValue),
      months: this.state.monthsValue,
      days: this.state.daysValue,
      data_type: this.state.dataTypeValue,
      active: this.state.activeValue,
      action: this.state.actionValue,
      notification_period: this.state.notification_periodValue,
      id: _.get(this.props.data, "rule_id", 0),
    };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/update_retention_rule",
        rule
      )
      .then((response) => {
        response = response.data;
        const success = _.get(response, "status", false);

        if (!success) {
          const message = _.get(response, "message", "Unknown error");
          toast.error(message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          console.error(message);
        } else {
          toast.success("Rule saved successfully", {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        }
      })
      .catch((error) => {});
  };
  handleSave = () => {
    if (this.props.editMode == "create") {
      this.createRule();
      this.props.handleEditMode("edit");
    } else if (this.props.editMode == "edit") {
      this.editRule();
    }
  };

  handleQueryKeyDown = (event) => {
    switch (event.key) {
      case " ":
        if (!dataLocation.concat(operators).includes(event.target.value)) {
          break;
        } else {
          if (event.target.value.length > 0) {
            event.preventDefault();
            event.stopPropagation();
            this.setState({
              queryValue: [...this.state.queryValue, event.target.value],
              disableSave: true,
            });
          }
          break;
        }
      case '"': {
        if (
          event.target.value.length > 1 &&
          event.target.value.trimStart().slice(0, 1) === '"'
        ) {
          event.preventDefault();
          event.stopPropagation();
          this.setState({
            queryValue: [
              ...this.state.queryValue,
              event.target.value.trimStart() + '"',
            ],
            disableSave: true,
          });
        }
      }
      default:
    }
  };

  handleQueryValueChange = (event, newValue, reason, details) => {
    let value = [...this.state.queryValue];
    if (reason === "clear") {
      value = [];
    } else if (
      reason === "removeOption" &&
      event.type === "keydown" &&
      event.key === "Backspace"
    ) {
      value.pop();
    } else if (reason !== "blur") {
      value.push(details.option);
    }
    this.setState({ queryValue: value, disableSave: true });
  };

  handleInputChange = (event, newValue, reason) => {
    // console.log(event, newValue, reason);
  };

  getQueryOptions = () => {
    const { queryValue } = this.state;
    if (
      queryValue.length &&
      dataLocation.includes(queryValue[queryValue.length - 1])
    ) {
      return operators;
    }
    return operators.concat(dataLocation);
  };

  getProjectToBucketValue = (value) => {
    let oldValue = [...value];
    let newValue = [];
    for (let index in oldValue) {
      if (oldValue[index] == "project") {
        newValue.push("bucket_name");
      } else {
        newValue.push(oldValue[index]);
      }
    }
    return newValue;
  };

  getBucketToProjectValue = (value) => {
    let oldValue = [...value];
    let newValue = [];
    for (let index in oldValue) {
      if (oldValue[index] == "bucket_name") {
        newValue.push("project");
      } else {
        newValue.push(oldValue[index]);
      }
    }
    return newValue;
  };

  getDataList = () => {
    const requestData = {
      query: this.getProjectToBucketValue(this.state.queryValue),
      months: this.state.monthsValue,
      days: this.state.daysValue,
      data_type: this.state.dataTypeValue,
    };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_data_in_rule",
        requestData
      )
      .then((response) => {
        if (_.get(response, "status", false)) {
          const responseData = _.get(response, "data", {});
          if (_.get(responseData, "status", false)) {
            this.setState({ disableSave: false, validQueryFlag: true });
          } else {
            this.setState({ disableSave: true, validQueryFlag: false });
          }
          const data = _.get(responseData, "data", {});
          this.setState({
            dataList: _.get(data, "rows", []),
          });
        }
      })
      .catch((error) => {});
  };

  handleActive = (event) => {
    this.setState({ activeValue: event.target.checked });
  };

  handleAction = (event) => {
    this.setState({ actionValue: event.target.value });
  };

  handleNotificationPeriod = (event) => {
    if (event.target.value > 0) {
      this.setState({ notification_periodValue: event.target.value });
    }
  };

  handleDataTypeChange = (event) => {
    this.setState({
      dataTypeValue: event.target.value,
      dataList: [],
      disableSave: true,
    });
  };

  isSaveDisabled = () => {
    return this.state.disableSave || !this.state.ruleValue;
  };

  applyTheme = (theme) => {
    if (theme == "dark") {
      return "table-sm table-dark table-striped table-bordered";
    } else {
      return "table-sm table-striped table-bordered";
    }
  };

  render() {
    const {
      monthsValue,
      daysValue,
      queryInputValue,
      queryValue,
      ruleValue,
      activeValue,
      actionValue,
      dataTypeValue,
      notification_periodValue,
      validQueryFlag,
    } = this.state;
    const bColor = this.props.theme == "dark" ? "#100c2a" : "white";
    const _color = this.props.theme == "dark" ? "white" : "black";
    return (
      <div
        id="ruleContainer"
        className={styles.ruleContent}
        style={{ background: bColor }}
      >
        <div id="Form-area" className={styles.formArea}>
          <div id="ruleLeftSideForm" className={styles.ruleLeftSideForm}>
            <TextField
              inputProps={{
                style: { color: _color },
              }}
              InputLabelProps={{
                style: { color: ruleValue ? _color : "#f44336" },
              }}
              size={"small"}
              style={{ width: "20%" }}
              helperText={ruleValue ? "" : "Entry is required"}
              required
              error={ruleValue ? false : true}
              label={"Rule name"}
              value={ruleValue}
              onChange={this.handleRuleName}
            />

            <FormControlLabel
              style={{
                margin: "0px 10px",
                color: _color,
                background: this.props.theme == "dark" ? "grey" : "white",
              }}
              label="Active"
              size="small"
              labelPlacement={"top"}
              control={
                <Switch
                  color="primary"
                  value={activeValue}
                  defaultChecked={activeValue}
                  onChange={this.handleActive}
                />
              }
            />

            <FormControl style={{ marginRight: "10px", color: _color }}>
              <InputLabel style={{ background: bColor, color: _color }}>
                Action
              </InputLabel>
              <Select
                style={{
                  color: _color,
                  background: this.props.theme == "dark" ? "grey" : "white",
                }}
                label={"Action"}
                value={actionValue}
                onChange={this.handleAction}
              >
                <MenuItem
                  style={{ background: bColor, color: _color }}
                  value={"DEL"}
                >
                  Delete
                </MenuItem>
              </Select>
            </FormControl>

            <TextField
              inputProps={{
                style: {
                  color: _color,
                  background: this.props.theme == "dark" ? "grey" : "white",
                },
              }}
              InputLabelProps={{ style: { color: _color } }}
              size={"small"}
              fullWidth={false}
              type={"number"}
              label={"Notice Period (in days)"}
              value={notification_periodValue}
              onChange={this.handleNotificationPeriod}
            />

            <FormControl
              size="small"
              style={{ margin: "0px 10px", color: _color }}
            >
              <InputLabel style={{ background: bColor, color: _color }}>
                Data Type
              </InputLabel>
              <Select
                style={{
                  color: _color,
                  background: this.props.theme == "dark" ? "grey" : "white",
                }}
                value={dataTypeValue}
                onChange={this.handleDataTypeChange}
              >
                <MenuItem value={"taskData"}>Task Data</MenuItem>
                <MenuItem value={"flowData"}>Flow Data</MenuItem>
                <MenuItem value={"metricsData"}>Metrics Data</MenuItem>
                <MenuItem value={"custom"}>Custom</MenuItem>
                <MenuItem value={"techlibData"}>Techib Data</MenuItem>
              </Select>
            </FormControl>

            <div
              id="olderThan"
              className={styles.olderThan}
              style={{ color: _color }}
            >
              <span style={{ marginTop: "20px" }}>Older than</span>
              <FormControl size="small" style={{ margin: "0px 10px" }}>
                <InputLabel style={{ background: bColor, color: _color }}>
                  Months
                </InputLabel>
                <Select
                  style={{
                    color: _color,
                    background: this.props.theme == "dark" ? "grey" : "white",
                  }}
                  size="small"
                  label={"Months"}
                  value={monthsValue}
                  onChange={this.handlePolicyTimeChange}
                >
                  <MenuItem
                    style={{ background: bColor, color: _color }}
                    value={1}
                  >
                    1 month
                  </MenuItem>
                  <MenuItem
                    style={{ background: bColor, color: _color }}
                    value={3}
                  >
                    3 months
                  </MenuItem>
                  <MenuItem
                    style={{ background: bColor, color: _color }}
                    value={6}
                  >
                    6 months
                  </MenuItem>
                  <MenuItem
                    style={{ background: bColor, color: _color }}
                    value={0}
                  >
                    Custom
                  </MenuItem>
                </Select>
              </FormControl>

              {monthsValue == 0 ? (
                <TextField
                  inputProps={{
                    style: { color: _color },
                  }}
                  size={"small"}
                  fullWidth={false}
                  style={{ width: "40%" }}
                  type={"number"}
                  label={"Days"}
                  value={daysValue}
                  onChange={this.handleCustomTimeChange}
                />
              ) : null}
            </div>
          </div>

          <div id="ruleRightSide" className={styles.ruleRightSide}>
            <Tooltip
              title='Write your query here after "WHERE" clause'
              placement="top-start"
            >
              <Autocomplete
                forcePopupIcon={false}
                multiple
                fullWidth={true}
                id="tags-outlined"
                options={this.getQueryOptions()}
                //   getOptionLabel={(option) => option.title || option}
                value={queryValue}
                // autoSelect
                autoComplete
                autoHighlight
                // autoCorrect
                inputValue={queryInputValue}
                onChange={(event, newValue, reason, details) =>
                  this.handleQueryValueChange(event, newValue, reason, details)
                }
                onInputChange={(event, newValue, reason) => {
                  this.handleInputChange(event, newValue, reason);
                }}
                renderTags={(titles, getTagProps) => {
                  return titles.map((title, index) => (
                    <div key={index} style={{ marginRight: "5px" }}>
                      {title}
                    </div>
                  ));
                }}
                size={"small"}
                filterSelectedOptions={false}
                renderInput={(params) => {
                  params.inputProps.onKeyDown = this.handleQueryKeyDown;
                  return (
                    <TextField
                      {...params}
                      error={!validQueryFlag}
                      style={{
                        maxHeight: "100%",
                        overflowY: "auto",
                        background: "white",
                      }}
                      helperText={validQueryFlag ? "" : "Invalid Query"}
                      variant="outlined"
                      size="small"
                      // label="SELECT DATA WHERE"
                      placeholder={
                        queryValue.length ? "" : "SELECT DATA WHERE ..."
                      }
                      margin="normal"
                    />
                  );
                }}
              />
            </Tooltip>
          </div>
        </div>
        <div id="analytics" className={styles.tabulator}>
          <ReactTabulator
            key={this.props.theme}
            className={this.applyTheme(this.props.theme)}
            data={this.state.dataList}
            columns={this.getDataColumns()}
            options={{
              pagination: "local",
              groupBy: "bucket_name",
              paginationSize: 10,
            }}
          />
        </div>
        <div id={"ruleBtnArea"} className={styles.ruleBtnArea}>
          <Button
            className={"rptButton"}
            size="sm"
            disabled={this.isSaveDisabled()}
            onClick={(e) => this.handleSave()}
          >
            Save
          </Button>
          <Button
            className={"rptButton"}
            size="sm"
            onClick={(e) => this.props.handleRuleBack()}
          >
            Back
          </Button>
          <Button
            className={"rptButton"}
            size="sm"
            onClick={(e) => this.getDataList()}
          >
            Get Data
          </Button>
        </div>
      </div>
    );
  }
}

export default Rule;

const times = [
  { title: "1 month", value: 1 },
  { title: "3 months", value: 3 },
  { title: "6 months", value: 6 },
  { title: "custom", value: 0 },
];

const dataLocation = [
  "project",
  "phase",
  "run_tag",
  "block",
  "checkpoint",
  "username",
  "report_name",
  "library",
  "foundry",
  "tag",
  "node",
].sort();
const operators = ["=", "(", ")", "LIKE", "AND", "OR", "NOT"].sort();
