import React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import WidgetLibManager from "./wgtLibManager";
import Modal from "@mui/material/Modal";
import styles from "./wgtLibManager.module.css";
import WarningOutlinedIcon from "@mui/icons-material/WarningOutlined";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  bgcolor: "#fff",
  padding: "2em",
  borderRadius: "6px",
  border: "1px solid black",
  boxShadow:
    " 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
};

export default function DeleteWidgetModal(props) {
  const { open, onClose, handleDelete } = props;
  return (
    <Modal
      open={open}
      onClose={onClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={style}>
        <Typography variant="h6">
          <WarningOutlinedIcon sx={{color: "#fa7025", marginRight: '1rem'}}/>
          Are you sure you want to <strong>delete</strong> this widget ?
        </Typography>
        <Box className={styles.deleteModalButton}>
          <Button
            id="delete"
            className={styles.delete}
            onClick={handleDelete}
            variant="contained"
          >
            Yes, delete
          </Button>
          <Button
            className={styles.deleteCancel}
            onClick={onClose}
            variant="outlined"
          >
            Cancel
          </Button>
        </Box>
      </Box>
    </Modal>
  );
}
