import * as utils from "../../common/utils/utils";
// import _ from "lodash";
import { toast } from "react-toastify";
import axios from "axios";

export const toastConfig = {
  position: toast.POSITION.BOTTOM_LEFT,
  style: {
    fontSize: "14px",
    padding: "8px 12px",
  },
};


// const getWidgetsURL = "http://us01odc-sc5-1-faa001:24565/mlbackend/api/list_documents";
// const getFilterValuesURL = "http://us01odc-sc5-1-faa001:24565/mlbackend/api/get_search_tags";
// const getWidgetsURL = "http://10.195.21.190:3000/api/list_documents";
// const getFilterValuesURL = "http://10.195.21.190:3000/api/get_search_tags";
// const getTagsURL = "http://10.195.21.190:3000/api/get_constant_tags";
const getWidgetsURL = utils.getMLUrl() + "/api/list_documents";
const getFilterValuesURL = utils.getMLUrl() + "/api/get_search_tags";
const getTagsURL = utils.getMLUrl() + "/api/get_constant_tags";
// get widgets in library
export const getWidgetsFromLibrary = async (inputPayload) => {
  // console.log("calling get widgets library API");
  const apiResponse = await axios
    .post(getWidgetsURL, inputPayload)
    .then((response) => {
      // console.log("in api-", { response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response?.data?.data?.data;
        const totalData = response?.data?.data?.total;
        // console.log("data", apiData, apiData && apiData.length === 0)
        if (apiData && apiData.length === 0) {
          const toastMsg = "No widgets found !";
          toast.info(toastMsg, toastConfig);
        }
        return {apiData, totalData};
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching widgets from library";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

// get search tags
export const getSearchTags = async (inputPayload) => {
  // console.log("calling get search Tags API");
  const apiResponse = await axios
    .post(getFilterValuesURL, inputPayload)
    .then((response) => {
      // console.log("in search tags api", { response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response?.data?.data;
        // console.log("data", apiData)
        if (apiData && apiData.length === 0) {
          const toastMsg = response?.data?.message;
          toast.error(toastMsg, toastConfig);
        }
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching widgets from library";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

// get constant tags
export const getConstantTags = async () => {
  // console.log("calling get search Tags API");
  const apiResponse = await axios
    .get(getTagsURL)
    .then((response) => {
      // console.log("in constant tags api", { response });
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response?.data?.data;
        
        if (apiData && Object.keys(apiData).length === 0) {
          const toastMsg = response?.data?.message;
          toast.error(toastMsg, toastConfig);
        }
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching widgets from library";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};
