import React from "react";
import CropLandscapeIcon from "@mui/icons-material/CropLandscape";
import CachedIcon from "@mui/icons-material/Cached";
import SettingsIcon from "@mui/icons-material/Settings";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/system";

//styles
import * as widgetTitleStyles from "./widgetTitle.module.css";

import IconButton from "@mui/material/IconButton";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import * as constants from "../../constants/constants";
import { widgets } from "../../pages/rptdashboard/addWidget/addWidget";
import { saveWidgetInLib } from "../../common/utils/utils";

import { shallow } from "zustand/shallow";
import useGlobalStore from "../../store/useGlobalStore";

const RotateIconButton = styled(IconButton)({
  padding: "0px 3px",
  transition: "transform 0.7s ease-in-out",
  "&:hover": { transform: "rotate(360deg)" },
});

const ScaleIconButton = styled(IconButton)({
  padding: "0px 3px",
  transition: "transform 0.7s ease-in-out",
  "&:hover": { transform: "scale(1.5)" },
});

class WidgetTitle extends React.Component {
  state = {
    openAddWidget: false,
  };

  handleAddWidget = () => {
    this.setState({ openAddWidget: !this.state.openAddWidget });
  };
  handleMenuClick = (option) => {
    switch (option) {
      case "Delete":
        useGlobalStore
          .getState()
          .deleteWgt(
            constants.allReports,
            this.props.reportKey,
            this.props.widgetId
          );
        break;
      case "Refresh":
        this.props.refreshWidget();
        break;

      case "Settings":
        this.props.updateUiState({
          isLoading: false,
          showConfig:
            !useGlobalStore.getState()[this.props.widgetId].uiState.showConfig,
          isToastOpen: false,
          toastSeverity: "info",
          toastMessage: "",
          cirlularLoading: false,
        });
        break;

      case "Copy":
        useGlobalStore
          .getState()
          .setRootLevelData("copyWidget", this.props.widgetSettings);
        break;
      case "Add to library":
        saveWidgetInLib(
          this.props.widgetSettings.name,
          this.props.widgetSettings.config,
          this.props.widgetSettings.metaData
        );
        break;
      default:
        console.log(
          `Menu event ${option} not is implemented or break statement is missing`
        );
    }
  };
  render() {
    return (
      <div
        {...this.props.handleProps}
        id="widgetTitle"
        className={widgetTitleStyles.titleBar}
      >
        <Tooltip title={this.props.widgetSettings.name}>
          <img
            loading="lazy"
            width="50"
            height="20"
            src={
              widgets[this.props.widgetSettings.name]
                ? widgets[this.props.widgetSettings.name].imageUrl
                : ""
            }
            srcSet={
              widgets[this.props.widgetSettings.name]
                ? widgets[this.props.widgetSettings.name].imageUrl
                : ""
            }
            alt=""
            borderRadius={"10px"}
          />
        </Tooltip>
        <Typography className={widgetTitleStyles.title}>
          {this.props.title}
        </Typography>
        <div
          id="widgetMenuIconArea"
          className={widgetTitleStyles.widgetMenuIcon}
        >
          <Tooltip title="Refresh">
            <RotateIconButton
              aria-label="refresh"
              id="long-button2"
              aria-haspopup="true"
              sx={{ padding: "0px 3px", fontSize: "2px" }}
              // disabled={this.props.widgetName == "Document View"}
              disabled={["Document View", "Metrics Group Bar Chart"].includes(
                this.props.widgetName
              )}
              onClick={() => this.handleMenuClick("Refresh")}
            >
              <CachedIcon
                fontSize={"small"}
                className={widgetTitleStyles.widgetIcon}
              />
            </RotateIconButton>
          </Tooltip>
          <Tooltip title="Settings">
            <RotateIconButton
              aria-label="more"
              id="long-button4"
              aria-haspopup="true"
              // sx={{ padding: "0px 3px" }}
              onClick={() => this.handleMenuClick("Settings")}
            >
              <SettingsIcon
                fontSize={"small"}
                className={widgetTitleStyles.widgetIcon}
              />
            </RotateIconButton>
          </Tooltip>
        </div>
      </div>
    );
  }
}

WidgetTitle.defaultProps = {
  text: "",
  widgetId: "",
  reportKey: "",
  widgetName: "",
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  },
  widgetSettings: {
    name: "Table View",
    metaData: { description: "", tags: "" },
  },
};

export default WidgetTitle;
