import React, { useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import AppBar from "@mui/material/AppBar";
import Typography from "@mui/material/Typography";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Slide from "@mui/material/Slide";
import Box from "@mui/material/Box";
import _ from "lodash";
import { Button, Stack } from "@mui/material";
import * as styles from "./WidgetForm.module.css";
import useGlobalStore from "../../store/useGlobalStore";
import { shallow } from "zustand/shallow";

import * as constants from "../../constants/constants";

// import WidgetWrapper from "./LibraryWidgetWrapper";

import api from "../../common/api/api";
import * as utils from "../../common/utils/utils";

import { nanoid } from "nanoid";
import { toast } from "react-toastify";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function WidgetForm(props) {
  // console.log("inside widget form", props)
  //backend data for editing
  // const [widgetForm, setWidgetForm] = useState(props.widgetForm);
  const {widgetForm, mode} = props
  const {
    setWidgetData,
    templateReport,
    updateSettingsProp,
    updateWidgetSettings,
  } = useGlobalStore(
    (state) => ({
      setWidgetData: state.setWidgetData,
      templateReport: state.templateReport,
      updateSettingsProp: state.updateSettingsProp,
      updateWidgetSettings: state.updateWidgetSettings,
    }),
    shallow
  );

  useEffect(() => {
    updateWidgetSettings(
      constants.templateReport,
      constants.template,
      constants.templateWidget,
      {
        name: _.get(widgetForm, "widget_name", "Table View"),
        config: getFormConfig(),
        x: 0,
        y: 0,
        w: 12,
        h: 10,
        id: constants.templateWidget,
        metaData: getWidgetMetaData(),
      }
    );
  }, []);

  const handleClose = () => {
    props.handleFullScreen(false);
    setWidgetData(constants.templateWidget, {});
  };

  const getFormConfig = () => {
    return _.get(
      utils.getWidgetSettings(_.get(widgetForm, "widget_name", "Table View"), {
        ...widgetForm,
      }),
      "config",
      {}
    );
  };

  const getWidgetMetaData = () => {
    const widgetMetaData = _.get(
      utils.getWidgetSettings(_.get(widgetForm, "widget_name", "Table View"), {
        ...widgetForm,
      }),
      "metaData",
      {}
    );
    return widgetMetaData;
  };

  const handleSettingsProp = (wProp, settingsProp) => {
    updateSettingsProp(
      constants.templateReport,
      constants.template,
      constants.templateWidget,
      wProp,
      settingsProp
    );
  };

  const getTableData = async () => {
    let data = [];
    const enpointUrl = utils.getMLUrl() + "/api/list_documents";
    const input = { category: "widgets_library", page: 1 };
    const response = await api(enpointUrl, input);
    if (response.status) {
      data = response.data;
    } else {
      console.log(response.message);
    }
    return data;
  };

  // save widget is only called for mode- add not view. Help search uses only preview mode
  const saveWidget = async () => {
    const config = _.cloneDeep(
      _.get(templateReport.template.widgets.templateWidget, "config", {})
    );
    config.doc_id = _.get(widgetForm, "doc_id", nanoid());
    const saveWidgetResponse = await utils.saveWidgetInLib(
      _.get(widgetForm, "widget_name", ""),
      config,
      _.get(templateReport.template.widgets.templateWidget, "metaData", {})
    );

    // commenting API call, as it is now handled in widget library
    // const newData = await getTableData();
    // props.updateTable(newData);

    // although saveWidgetInLib returns "data", calling "list_documents" API again to ensure correct result
    if(saveWidgetResponse.status) {
      props.updateTable();
      handleClose();
    }
    else {
      // show a toast
      const errMsg = saveWidgetResponse?.message || "Something went wrong!"
      toast.error(errMsg, {
        position: toast.POSITION.BOTTOM_LEFT,
      });
    }
  };

  return (
    <div>
      <Dialog
        fullScreen
        open={props.isFullScreen}
        onClose={handleClose}
        TransitionComponent={Transition}
      >
        <AppBar sx={{ position: "relative", backgroundColor: "#5a2a82" }}>
          <Toolbar sx={{ backgroundColor: "#5a2a82" }}>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <CloseIcon color="inherit" />
            </IconButton>
            <Typography sx={{ flexGrow: 1, fontSize: '1.2rem', textTransform: "capitalize" }}>{props.mode}</Typography>
            {/* <Tooltip title="Refresh">
              <Button
                aria-label="refresh"
                id="refreshButton"
                sx={{
                  backgroundColor: "white",
                  "&:hover": {
                    backgroundColor: "lightgrey",
                  },
                  mr: "10px",
                }}
                onClick={() => {
                  refreshWidgetContent({
                    widgetId: constants.templateWidget,
                    config: getFormConfig(),
                    widgetName: _.get(widgetForm, "widget_name", "Table View"),
                    reportKey: constants.template,
                    rptType: constants.templateReport,
                  });
                }}
                variant={"outlined"}
              >
                Refresh
              </Button>
              </Tooltip>*/}
            {props.mode && props.mode != "view" ? (
              <Button
                sx={{
                  backgroundColor: "#fff",
                  textTransform: "capitalize",
                  "&:hover": {
                    backgroundColor: "#dcdcdc",
                  },
                }}
                variant={"outlined"}
                onClick={saveWidget}
              >
                Save Widget
              </Button>
            ) : null}
          </Toolbar>
        </AppBar>
        <Box sx={{ height: "calc(100vh - 64px)", width: "100%" }}>
          <Stack direction="row">
            <Box
              id="widgetDisplay"
              className={styles.widgetDisplay}
              sx={{
                "& > :not(style)": { m: 1 },
                width: "100%",
              }}
            >
              {/* <WidgetWrapper
                widgetProps={templateReport.template.widgets.templateWidget}
                updateSettingsProp={handleSettingsProp}
                id={constants.templateWidget}
                rptType={constants.templateReport}
                reportKey={constants.template}
                mode={mode}
              /> */}
            </Box>
          </Stack>
        </Box>
      </Dialog>
    </div>
  );
}

WidgetForm.defaultProps = {
  childComponent: null,
  title: "",
  isFullScreen: false,
};
