/* eslint-disable no-unused-vars */
import * as React from "react";
import { useEffect, useState } from "react";

import {
  Autocomplete,
  Checkbox,
  CircularProgress,
  TextField,
  Button,
  Pagination,
  Tooltip,
  IconButton,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Select,
  Skeleton,
} from "@mui/material";

import * as styles from "./wgtLibManager.module.css";
import api from "../../common/api/api";
import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";
import { shallow } from "zustand/shallow";
import clipboardCopy from "clipboard-copy";
import _ from "lodash";
import WidgetForm from "./WidgetForm";
import { nanoid } from "nanoid";
import {
  AddTemplateWgtToRpt,
  addWidgetCommonFunction,
  nonDataSpecificWidgets,
} from "../../pages/rptdashboard/addWidget/addWidget";
import { toast } from "react-toastify";
import * as utils from "../../common/utils/utils";
// import { useRouter } from "next/router";
import SelectWidget from "./widgetSelect";
import * as constants from "../../constants/constants";
import DeleteWidgetModal from "./DeleteWidgetModal";
import "react-toastify/dist/ReactToastify.css";

import getConfig from "next/config";
import { getWidgetsFromLibrary, getSearchTags } from "./wgtLibraryApi";

import MoreVertIcon from "@mui/icons-material/MoreVert";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import BorderColorOutlinedIcon from "@mui/icons-material/BorderColorOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import ContentCopyOutlinedIcon from "@mui/icons-material/ContentCopyOutlined";
import AddCircleOutlineOutlinedIcon from "@mui/icons-material/AddCircleOutlineOutlined";
import ContentPasteOutlinedIcon from "@mui/icons-material/ContentPasteOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import RefreshIcon from "@mui/icons-material/Refresh";
import FilterAltOutlinedIcon from "@mui/icons-material/FilterAltOutlined";
import TaskAltIcon from "@mui/icons-material/TaskAlt";
import { Close } from "@mui/icons-material";

const WidgetLibManager = (props) => {
  const widgetLibraryFilterInStore = "widget_library_filter_selections";
  const isFilterOpen = "widget_library_filter_section_open";

  const { authLoginUser, widLibDataSource, isAdminFlag, setRootLevelData } =
    useConfigStore();

  const storedFilterData =
    useConfigStore.getState()[widgetLibraryFilterInStore];
  const isFilterSectionOpen = useConfigStore.getState()[isFilterOpen];
  const filterList = constants.filterList;
  const baseFilterStateObj = storedFilterData
    ? storedFilterData
    : constants.baseFilterStateObj;
  const { publicRuntimeConfig } = getConfig();
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [selectedWidget, setSelectedWidget] = useState({});
  const [openRptAdd, setOpenRptAdd] = useState(false);
  const [formMode, setFormMode] = useState("edit"); // 3 modes | add - view - edit
  const [IsDeleteModalClicked, setDeleteModalClicked] = useState(false);
  // const router = useRouter();
  const defaultWidgetForm = {
    category: "widgets_library",
    cluster: utils.getRootDirectory(widLibDataSource.taskData.dataLocation)
      ? utils
          .getRootDirectory(widLibDataSource.taskData.dataLocation)
          .split("#")[0]
      : "",
    columns: [],
    content: "",
    created_at: "",
    data: "",
    description: "",
    doc_id: "",
    location: utils.getRootDirectory(widLibDataSource.taskData.dataLocation)
      ? utils
          .getRootDirectory(widLibDataSource.taskData.dataLocation)
          .split("#")[1]
      : "",
    bucket: _.get(widLibDataSource, "bucket", ""),
    score: 0,
    tags: "",
    title: "",
    updated_at: "",
    dataLocation: "",
    user: "",
  };
  const [widgetForm, setWidgetForm] = useState(defaultWidgetForm);
  const [openAddWid, setOpenAddWid] = useState(false);
  const [widgetLibData, setWidgetLibData] = useState([]);
  const [totalData, setTotalData] = useState(0);
  const { allReports, allDashbrdRpts } = useGlobalStore(
    (state) => ({
      allReports: state.allReports,
      allDashbrdRpts: state.allDashbrdRpts,
    }),
    shallow
  );

  const [anchorEl, setAnchorEl] = useState(null);
  // pagination states
  const paginationRowsCount = [10, 20, 30, 50];
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const [countPages, setCountPages] = useState(
    Math.ceil(totalData / rowsPerPage)
  );
  const [isLibraryLoading, setIsLibraryLoading] = useState(false);
  const [isFetchingSearchTags, setIsFetchingSearchTags] = useState(false);
  const [isAddingWidget, setIsAddingWidget] = useState(false);

  const [textBasedFilterCategories, setTextBasedFilterCategories] = useState(
    []
  );
  const [filterCategoryValues, setFilterCategoryValues] = useState({});
  const [selectedWidgetObj, setSelectedWidgetObj] = useState({});

  const [filterOptions, setFilterOptions] = useState(baseFilterStateObj);

  const onPageNumberChange = (e, value) => {
    setPage(value);
  };

  const onRowsPerPageChange = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10)); // converts to base 10
    setPage(1);
  };

  const onMenuClose = () => {
    setAnchorEl(null);
  };

  const imageUrl = publicRuntimeConfig.basePath;

  const getWidgets = async (payload = {}) => {
    try {
      setWidgetLibData([]);
      setIsLibraryLoading(true);
      const payloadForWidLib =
        Object.keys(payload).length > 0
          ? payload
          : {
              category: "widgets_library",
              filter: filterOptions,
              page: page,
              size: rowsPerPage,
              exact_match: false,
            };

      const { apiData, totalData } = await getWidgetsFromLibrary(
        payloadForWidLib
      );

      if (apiData) {
        // console.log("responseFromApi-", apiData);
        setWidgetLibData(apiData);
        setTotalData(totalData);
        setCountPages(Math.ceil(totalData / rowsPerPage));
      }
    } catch (err) {
      console.error("Something went wrong in fetching widgets from library");
    } finally {
      setIsLibraryLoading(false);
    }
  };

  const searchTags = async (payload, openFilter) => {
    try {
      setIsFetchingSearchTags(true);
      // setFilterCategoryValues({});
      let apiData = await getSearchTags(payload);
      if (apiData) {
        // console.log("responseFromApi-searchTags", apiData);
        const filterOptionsCopy = baseFilterStateObj;
        // add "select all" label to each category i.e updating api response
        for (let key in apiData) {
          const values = apiData[key];
          apiData[key] = values.length > 0 ? ["Select all", ...values] : [];
        }
        setFilterOptions(filterOptionsCopy);
        setRootLevelData(widgetLibraryFilterInStore, filterOptionsCopy);
        setFilterCategoryValues(apiData);
      }
    } catch (err) {
      console.error("Something went wrong in searching tags");
    } finally {
      setIsFetchingSearchTags(false);
    }
  };

  const handleSelectedRow = (widgetObj) => {
    // console.log("selected widget is", widgetObj);
    setSelectedWidget(widgetObj);
  };

  const onMoreIconClick = (event, widgetObj) => {
    // console.log("on menu click", widgetObj);
    handleSelectedRow(widgetObj);
    setAnchorEl(event.currentTarget);
  };

  const handleFullScreen = (isFullScreen) => {
    setIsFullScreen(isFullScreen);
  };

  const handleDelete = () => {
    setDeleteModalClicked(true);
    onMenuClose();
  };

  const handleDuplicate = async () => {
    onMenuClose();
    const newRow = _.cloneDeep(selectedWidget);
    const doc_id = nanoid();
    newRow.user = authLoginUser;
    const settings = utils.getWidgetSettings(
      _.get(widgetForm, "widget_name", "Table View"),
      newRow
    );

    settings.config.doc_id = doc_id;

    newRow.doc_id = doc_id;
    newRow.id = 11;

    const duplicateApiResponse = await utils.saveWidgetInLib(
      newRow.widget_name,
      _.get(settings, "config", {}),
      _.get(settings, "metaData", {})
    );

    // although saveWidgetInLib returns "data", calling "list_documents" API again to ensure correct result
    if (duplicateApiResponse.status) {
      getWidgets();
    }
  };

  const getWidgetConfig = (selectedWidgetObj = {}) => {
    // console.log("selectedWidgetObj", selectedWidgetObj);
    // console.log("state", selectedWidget);
    const config =
      selectedWidget && Object.keys(selectedWidget).length > 0
        ? selectedWidget
        : selectedWidgetObj;

    // console.log("get config", config);
    // if location is task location
    if (config.location && config.location.startsWith("task")) {
      // get cluster from default data source from prefrence
      config.cluster = utils
        .getRootDirectory(widLibDataSource.taskData.dataLocation)
        .split("#")[0];

      //get location if location is root directory
      if (utils.isRootDirectory("c0#" + config.location)) {
        config.location = utils
          .getRootDirectory(widLibDataSource.taskData.dataLocation)
          .split("#")[1];
      } else {
        //get location from default data source
        let location = _.get(widLibDataSource.taskData, "dataLocation", "#");
        if (location.split("#").length) {
          config.location = location.split("#")[1];
        }
      }
      config.bucket = _.get(widLibDataSource.taskData, "bucket", "");
    }
    // if location is flow location
    else if (config.location && config.location.startsWith("flow")) {
      config.cluster = utils
        .getRootDirectory(widLibDataSource.flowData.dataLocation)
        .split("#")[0];
      if (utils.isRootDirectory("c0#" + config.location)) {
        config.location = utils
          .getRootDirectory(widLibDataSource.flowData.dataLocation)
          .split("#")[1];
      } else {
        config.location = _.get(
          widLibDataSource.flowData,
          "dataLocation",
          "#"
        ).split("#")[1];
      }
      config.bucket = _.get(widLibDataSource.flowData, "bucket", "");
    }
    //if location is custom location
    else if (config.location && config.location.startsWith("custom")) {
      config.cluster = utils
        .getRootDirectory(widLibDataSource.customData.dataLocation)
        .split("#")[0];
      if (utils.isRootDirectory("c0#" + config.location)) {
        config.location = utils
          .getRootDirectory(widLibDataSource.customData.dataLocation)
          .split("#")[1];
      } else {
        config.location = utils
          .getRootDirectory(
            _.get(widLibDataSource.customData, "dataLocation", "#")
          )
          .split("#")[1];
      }
      config.bucket = _.get(widLibDataSource.customData, "bucket", "");
    }

    return config;
  };

  const onPreviewWidgets = () => {
    // console.log("selection onPreviewWidgets", selection);
    // if _reactName exists => it means its an event, hence coming from "Preview" -> so take state | else take params
    // const selectedWidgetObj = selection._reactName ? selectedWidget : selection;
    // console.log("selected row onPreviewWidgets", selectedWidgetObj);
    onMenuClose();
    // Object.values(selectedWidgetObj).forEach((selectedWidget) => {
    if (selectedWidget.category == "widgets_library") {
      setWidgetForm(getWidgetConfig(selectedWidget));
      setIsFullScreen(true);
      setFormMode("view");
    }
    // });
  };

  const handleEdit = () => {
    onMenuClose();
    if (selectedWidget.category == "widgets_library") {
      setWidgetForm(getWidgetConfig(selectedWidget));
      setIsFullScreen(true);
      setFormMode("edit");
    }
  };

  const addNewWidget = () => {
    //we need to add a modal to ask category(widget/report) that user wants to add
    let newForm = _.cloneDeep(defaultWidgetForm);
    newForm.doc_id = nanoid();
    setWidgetForm(newForm);
    setOpenAddWid(true);
    setFormMode("add");
  };

  const handleSelectWidget = (widName) => {
    const newForm = _.cloneDeep(widgetForm);
    newForm.widget_name = widName;
    setWidgetForm(newForm);
    handleFullScreen(true);
  };

  const handleCloseAddWid = () => {
    setOpenAddWid(false);
  };

  const handleAddToRpt = (value = true) => {
    onMenuClose();
    setOpenRptAdd(value);
  };

  // to copy to clipboard
  const copyToClipboard = async () => {
    onMenuClose();
    const copyStr = selectedWidget.doc_id;
    try {
      await clipboardCopy(copyStr);
      console.log("Text copied to clipboard:", copyStr);
    } catch (err) {
      console.error("Unable to copy text to clipboard:", err);
    }
  };
  const createWidgetSettings = () => {
    let widgetSettings = [];
    Object.values(selectedWidgetObj).forEach((selectedWidget) => {
      widgetSettings.push(
        utils.getWidgetSettings(selectedWidget.widget_name, selectedWidget)
      );
    });
    // for (let i = 0; i < selectedWidget.length; i++) {
    // }
    return widgetSettings;
  };

  const routeToRpt = () => {
    // router.push({
    //   pathname: "/rptdashboard",
    // });
    setOpenRptAdd(false);
  };

  const deleteWidget = async () => {
    const doc_id = selectedWidget.doc_id;
    const response = await api(utils.getMLUrl() + "/api/delete_doc", {
      doc_id: doc_id,
    });
    // console.log("response delete", response)
    if (response.status) {
      // setSelectedWidget([]);
      getWidgets();
    }
  };

  const handleCloseDeleteModalClick = () => {
    // handleDelete();
    setDeleteModalClicked(false);
    deleteWidget();
  };

  const handleAddToDashboard = () => {
    try {
      setIsAddingWidget(true);
      // run a loop to add all widgets
      Object.values(selectedWidgetObj).forEach((selectedWidget) => {
        //get widget settings
        const widgetSettings = _.cloneDeep(
          utils.getWidgetSettings(selectedWidget.widget_name, selectedWidget)
        );

        //update config with dashboard data source
        if (widgetSettings && widgetSettings.config) {
          let defaultDataLocation = "";
          let defaultBucket = "";
          if (utils.isRootDirectory(widgetSettings.config.dataLocation)) {
            defaultDataLocation = utils.getRootDirectory(
              _.get(
                allDashbrdRpts[constants.dashboardReport],
                "dataLocation",
                ""
              )
            );
          } else {
            defaultDataLocation = _.get(
              allDashbrdRpts[constants.dashboardReport],
              "dataLocation",
              ""
            );
          }
          defaultBucket = _.get(
            allDashbrdRpts[constants.dashboardReport],
            "bucket",
            ""
          );

          if (!nonDataSpecificWidgets.includes(widgetSettings.widgetName)) {
            widgetSettings.config.dataLocation = defaultDataLocation;
            widgetSettings.config.bucket = defaultBucket;
          }
        }

        // add to dashboard
        addWidgetCommonFunction(
          constants.allDashbrdRpts,
          constants.dashboardReport,
          widgetSettings
        );
      });
    } catch (err) {
      toast.error(`Something went wrong in adding to dashboard`, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    } finally {
      setIsAddingWidget(false);
      toast.success(`Selected widget(s) added to dashboard`, {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    }
  };

  // declare constants
  const menuOptions = [
    // {
    //   name: "Preview",
    //   icon: <VisibilityOutlinedIcon fontSize="small" />,
    //   action: onPreviewWidgets,
    // },
    {
      name: "Preview",
      icon: <VisibilityOutlinedIcon fontSize="small" />,
      action: onPreviewWidgets,
      isDisabled: false,
      showDivider: true,
    },
    {
      name: "Edit",
      icon: <BorderColorOutlinedIcon fontSize="small" />,
      action: handleEdit,
      isDisabled:
        selectedWidget && Object.keys(selectedWidget).length > 0
          ? !(selectedWidget.user === authLoginUser || isAdminFlag)
          : false,
      showDivider: false,
    },
    {
      name: "Delete",
      icon: <DeleteOutlineOutlinedIcon fontSize="small" />,
      action: handleDelete,
      isDisabled:
        selectedWidget && Object.keys(selectedWidget).length > 0
          ? !(selectedWidget.user === authLoginUser || isAdminFlag)
          : false,
      showDivider: false,
    },
    {
      name: "Duplicate",
      icon: <ContentCopyOutlinedIcon fontSize="small" />,
      action: handleDuplicate,
      isDisabled: false,
      showDivider: true,
    },
    // {
    //   name: props.parent == "analytics" ? "Add to Reports" : "Add to Dashboard",
    //   icon: <AddCircleOutlineOutlinedIcon fontSize="small" />,
    //   action:
    //     props.parent == "analytics" ? handleAddToRpt : handleAddToDashboard,
    //   isDisabled: false,
    //   showDivider: false,
    // },
    {
      name: "Copy Widget ID",
      icon: <ContentPasteOutlinedIcon fontSize="small" />,
      action: copyToClipboard,
      isDisabled: false,
      showDivider: false,
    },
  ];

  const onFilterIconClick = (openFilter = false) => {
    if (openFilter) {
      setRootLevelData(isFilterOpen, true);
    }
    // get search tags
    const filterCategories = filterList.map((item) => item.column);
    // console.log("filterCategories", filterCategories); //total selected categories
    // remove the text box based categories
    const onlyDropdownFilterCategories = filterList
      .map((obj) =>
        filterCategories.includes(obj.column) && obj.type === "select"
          ? obj.column
          : null
      )
      .filter(Boolean);
    // console.log("onlyDropdownFilterCategories", onlyDropdownFilterCategories);

    const textFilterCategories = filterCategories.filter(
      (item) => !onlyDropdownFilterCategories.includes(item)
    );
    setTextBasedFilterCategories(textFilterCategories);

    const payload = {
      fields: onlyDropdownFilterCategories,
    };
    searchTags(payload, openFilter);
  };

  // on component mount call api
  useEffect(() => {
    onFilterIconClick();
    getWidgets();
  }, [page, rowsPerPage]);

  const onChangeAutoComplete = (e, option, reason, category) => {
    // console.log("onChangeAutoComplete", e, option, reason, category);
    const filterOptionsLocal = { ...filterOptions };
    const possibleCategoryValues = filterCategoryValues[category];
    const selectAllUnchecked = option.length === possibleCategoryValues.length;
    const selectAllChecked =
      option.length + 1 === possibleCategoryValues.length;

    // select-all checbox is unchecked
    if (option.includes("Select all") && selectAllUnchecked) {
      filterOptionsLocal[category] = [];
    }
    // select-all checbox is checked
    else if (option.includes("Select all") || selectAllChecked) {
      // get all possible values of that category
      filterOptionsLocal[category] = possibleCategoryValues;
    } else {
      filterOptionsLocal[category] = option;
    }
    // console.log("filterOptionsLocal after", filterOptionsLocal);
    setFilterOptions(filterOptionsLocal);
    setRootLevelData(widgetLibraryFilterInStore, filterOptionsLocal);
  };

  const onChangeFilterTextBox = (e, category) => {
    // console.log("typed val: ", e.target.value, " in ", category);
    const value = e.target.value;
    const filterOptionsLocal = { ...filterOptions };
    filterOptionsLocal[category] = value.length === 0 ? [] : [value]; // this check is required as value is set to empty string
    setFilterOptions(filterOptionsLocal);
    setRootLevelData(widgetLibraryFilterInStore, filterOptionsLocal);
  };

  const onClearFilter = () => {
    const filterOptionsCopy = { ...filterOptions };
    for (let key in filterOptionsCopy) {
      filterOptionsCopy[key] = [];
    }
    const payload = {
      category: "widgets_library",
      filter: filterOptionsCopy,
      page: page,
      size: rowsPerPage,
      exact_match: false,
    };
    // console.log("onm clear filterOptionsCopy", filterOptionsCopy);
    setFilterOptions(filterOptionsCopy);
    setRootLevelData(widgetLibraryFilterInStore, filterOptionsCopy);

    getWidgets(payload);
  };

  const onApplyFilters = () => {
    // console.log("filterOptions", filterOptions);
    // remove "select all" if any
    const filterOptionsLocal = { ...filterOptions };
    for (const key in filterOptionsLocal) {
      filterOptionsLocal[key] = filterOptionsLocal[key].filter(
        (item) => item !== "Select all"
      );
    }
    // console.log("filterOptionsLocal", filterOptionsLocal);
    setFilterOptions(filterOptionsLocal);
    setRootLevelData(widgetLibraryFilterInStore, filterOptionsLocal);
    const payload = {
      category: "widgets_library",
      filter: filterOptionsLocal,
      page: page,
      size: rowsPerPage,
      exact_match: false,
      // !textBasedFilterCategories.length > 0, // if text boxes are added for filteration, send exact_match to be False
    };
    // console.log("payload for filter", payload);
    getWidgets(payload);
  };

  // const onDoubleClickWidget = (clickedWidget) => {
  //   console.log("double clickle d widget", clickedWidget);
  //   onPreviewWidgets(clickedWidget);
  // };

  const onWidgetComponentClick = (clickedWidget) => {
    // console.log("clciked widget", clickedWidget);
    const widgetId = clickedWidget.doc_id;
    const clickedIdList = Object.keys(selectedWidgetObj);

    if (clickedIdList.includes(widgetId)) {
      // remove from list
      const copySelectedWidgets = { ...selectedWidgetObj };
      delete copySelectedWidgets[widgetId];
      setSelectedWidgetObj(copySelectedWidgets);
    } else {
      // add to list
      setSelectedWidgetObj({ ...selectedWidgetObj, [widgetId]: clickedWidget });
    }
  };

  const onCloseFilterBox = () => {
    setRootLevelData(isFilterOpen, false);
    setFilterCategoryValues({});
    setTextBasedFilterCategories([]);
  };

  return (
    <>
      <div
        id="wigtLibParent"
        className={styles.wigtParent}
        style={{
          gridTemplateRows: isFilterSectionOpen
            ? "0.01fr 0.05fr 0.07fr 1fr 0.05fr"
            : "0.01fr 0.07fr 1fr 0.05fr",
        }}
      >
        {/* modal used for confirmation of deleting widget */}
        <DeleteWidgetModal
          open={IsDeleteModalClicked}
          onClose={handleCloseDeleteModalClick}
          handleDelete={handleCloseDeleteModalClick}
        />

        {/* widget button container starts here */}
        <div className={styles.widgetButtonContainer}>
          <Button
            className={styles.addWidgetBtn}
            variant="contained"
            onClick={addNewWidget}
          >
            Add a New Widget to Widget Library
          </Button>
          <Tooltip title="Add filter categories" placement="top">
            <IconButton
              onClick={() => onFilterIconClick(true)}
              disabled={isFetchingSearchTags || isLibraryLoading}
              sx={{ p: 0 }}
            >
              <FilterAltOutlinedIcon
                sx={{
                  color: "#5a2a82",
                  opacity: isFetchingSearchTags || isLibraryLoading ? 0.5 : 1,
                }}
              />
            </IconButton>
          </Tooltip>
        </div>

        {/* widget filters */}
        {!isFilterSectionOpen ? (
          <></>
        ) : (
          <div className={styles.widgetFilterContainer}>
            {isFetchingSearchTags ? (
              <Skeleton
                variant="rectangular"
                animation="wave"
                className={styles.skeletonFilterBoxLoader}
              />
            ) : (
              <>
                <div className={styles.filterTitle}>
                  <h6>Categories to filter</h6>
                  <IconButton onClick={onCloseFilterBox}>
                    <Close sx={{ width: "1.3rem", height: "1.3rem" }} />
                  </IconButton>
                </div>
                <div className={styles.widgetFilterContainerChild}>
                  {/* iterate thorugh filter obj and get filters */}
                  {Object.keys(filterCategoryValues).map((item) => {
                    // console.log("autocomplete chjeck", item, filterOptions, filterOptions[item]);
                    return (
                      <Autocomplete
                        key={item}
                        value={filterOptions[item]?.filter(
                          (val) => val !== "Select all"
                        )}
                        multiple
                        size="small"
                        autoHighlight
                        // limitTags={1}
                        options={filterCategoryValues[item]}
                        disableCloseOnSelect
                        onChange={(e, value, reason) =>
                          onChangeAutoComplete(e, value, reason, item)
                        }
                        renderOption={(props, option) => (
                          <li
                            {...props}
                            style={{
                              fontSize: "0.9rem",
                              padding: "5px 10px",
                            }}
                          >
                            <Checkbox
                              style={{ padding: 0, marginRight: 5 }}
                              checked={
                                filterOptions[item]
                                  ? filterOptions[item].includes(option)
                                  : false
                              }
                            />
                            {option}
                          </li>
                        )}
                        style={{
                          minWidth: 220,
                          maxWidth: 320,
                          transition: "0.3s ease-in-out",
                        }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={`Select ${
                              filterList.filter((obj) => obj.column === item)[0]
                                ?.title || item
                            }`}
                            sx={{ "& label": { fontSize: "0.88rem" } }}
                          />
                        )}
                        disabled={isLibraryLoading}
                      />
                    );
                  })}

                  {/* render text-boxes */}
                  {textBasedFilterCategories &&
                    textBasedFilterCategories.length > 0 &&
                    textBasedFilterCategories.map((category) => {
                      return (
                        <TextField
                          key={category}
                          label={
                            filterList.filter(
                              (obj) => obj.column === category
                            )[0]?.title || category
                          }
                          placeholder={`Type a ${
                            filterList.filter(
                              (obj) => obj.column === category
                            )[0]?.title || category
                          }...`}
                          sx={{
                            "& label": { fontSize: "0.88rem" },
                            minWidth: 220,
                            maxWidth: 320,
                            transition: "0.3s ease-in-out",
                          }}
                          value={filterOptions[category]}
                          onChange={(e) => onChangeFilterTextBox(e, category)}
                          size="small"
                          disabled={isLibraryLoading}
                        />
                      );
                    })}
                </div>
                <div className={styles.filterButtonContainer}>
                  <Button
                    variant="contained"
                    onClick={onApplyFilters}
                    disabled={isLibraryLoading}
                  >
                    Apply filters
                  </Button>
                  <Button
                    variant="outlined"
                    onClick={onClearFilter}
                    disabled={isLibraryLoading}
                  >
                    Clear all filters
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        <div className={styles.actionButtonContainer}>
          <div className={styles.selectedWidgetCount}>
            Selected Widgets: {Object.keys(selectedWidgetObj).length}/
            {totalData}
          </div>
          <div className={styles.widgetButtonAction}>
            <Button
              // className={styles.addWidgetBtn}
              variant="outlined"
              onClick={() => setSelectedWidgetObj({})}
              startIcon={<Close fontSize="small" />}
              disabled={Object.keys(selectedWidgetObj).length === 0}
            >
              Clear Widgets Selection
            </Button>
            {/* <Button
            variant="outlined"
            onClick={onPreviewWidgets}
            startIcon={<VisibilityOutlinedIcon fontSize="small" />}
          >
            Preview Selected Widgets
          </Button> */}
            <Button
              // className={styles.addWidgetBtn}
              variant="contained"
              onClick={
                props.parent == "analytics"
                  ? handleAddToRpt
                  : handleAddToDashboard
              }
              startIcon={
                isAddingWidget ? (
                  <CircularProgress sx={{ color: "#333" }} size={15} />
                ) : (
                  <AddCircleOutlineOutlinedIcon fontSize="small" />
                )
              }
              disabled={
                isAddingWidget || Object.keys(selectedWidgetObj).length === 0
              }
            >
              {props.parent == "analytics"
                ? "Add to Reports"
                : "Add to Dashboard"}
            </Button>
          </div>
        </div>
        {/* widget cards */}
        <div className={styles.widgetComponentContainer}>
          {isLibraryLoading ? (
            [...Array(20)].map((item, index) => (
              <Skeleton
                key={index}
                variant="rectangular"
                animation="wave"
                className={styles.skeletonTabLoader}
              />
            ))
          ) : widgetLibData && widgetLibData.length > 0 ? (
            widgetLibData.map((widget) => {
              const { title, widget_name, user, doc_id } = widget;
              const widgetTitle = title.length > 0 ? title : widget_name;
              const widgetImg = `${imageUrl}/widget_library_icons/${widget_name}.svg`;
              const placeholderImg = `${imageUrl}/widget_library_icons/placeholder.svg`;
              const keyForComponent = `${doc_id}`;
              const isMenuOpen = Boolean(anchorEl);
              const isWidgetSelected =
                selectedWidgetObj &&
                Object.keys(selectedWidgetObj).includes(doc_id);
              return (
                <div
                  key={keyForComponent}
                  className={
                    isWidgetSelected
                      ? styles.selectedWidgetComponent
                      : styles.widgetComponent
                  }
                >
                  <header
                    className={styles.widgetComponentHeader}
                    style={{
                      background: isWidgetSelected
                        ? "transparent"
                        : "linear-gradient(to left top, #e9b8f3, #fdf5ff)",
                    }}
                  >
                    <div title={widgetTitle}>{widgetTitle}</div>
                    {isWidgetSelected ? (
                      <TaskAltIcon fontSize="small" />
                    ) : (
                      <>
                        <IconButton onClick={(e) => onMoreIconClick(e, widget)}>
                          <MoreVertIcon sx={{ width: "1rem" }} />
                        </IconButton>
                        <Menu
                          anchorEl={anchorEl}
                          open={isMenuOpen}
                          onClose={onMenuClose}
                          PaperProps={{
                            style: {
                              maxHeight: "17rem",
                              minWidth: "22ch",
                              boxShadow: "none",
                              border: "1px solid #dcdcdc",
                            },
                          }}
                        >
                          {menuOptions && menuOptions.length > 0 ? (
                            menuOptions.map((option, index) => {
                              const keyForMenuItem = `${keyForComponent}_${index}`;
                              const {
                                name,
                                icon,
                                action,
                                isDisabled,
                                showDivider,
                              } = option;
                              return (
                                <>
                                  <MenuItem
                                    key={keyForMenuItem}
                                    onClick={isDisabled ? null : action}
                                    disableInteractive
                                  >
                                    <ListItemIcon
                                      sx={{ opacity: isDisabled ? 0.4 : 1 }}
                                    >
                                      {icon}
                                    </ListItemIcon>
                                    <ListItemText
                                      sx={{ opacity: isDisabled ? 0.4 : 1 }}
                                    >
                                      {name}
                                    </ListItemText>
                                    {isDisabled ? (
                                      <Tooltip
                                        title={
                                          name === "Edit"
                                            ? "Duplicate this widget to edit"
                                            : "You can delete your widgets only"
                                        }
                                        arrow
                                      >
                                        <IconButton sx={{ p: 0 }}>
                                          <InfoOutlinedIcon />
                                        </IconButton>
                                      </Tooltip>
                                    ) : (
                                      <></>
                                    )}
                                  </MenuItem>
                                  {showDivider ? <Divider /> : <></>}
                                </>
                              );
                            })
                          ) : (
                            <></>
                          )}
                        </Menu>
                      </>
                    )}
                  </header>
                  <div
                    className={styles.widgetComponentBody}
                    onClick={() => onWidgetComponentClick(widget)}
                  >
                    {/* <div className={styles.widgetComponentBody} onDoubleClick = {() => onDoubleClickWidget(widget)}> */}
                    <img
                      src={widgetImg}
                      alt="widget-snap"
                      onError={(e) => (e.currentTarget.src = placeholderImg)}
                      className={styles.widgetComponentImage}
                    />
                    <footer className={styles.widgetComponentFooter}>
                      <strong>{widget_name}</strong> created by{" "}
                      <strong>{user}</strong>
                    </footer>
                    {/* <div className={styles.widgetComponentOverlay}>
                      {description.length > 0 ? (
                        <>
                          <strong>Description:</strong>
                          <p>{description}</p>
                        </>
                      ) : (
                        "No description provided"
                      )}
                    </div> */}
                  </div>
                </div>
              );
            })
          ) : (
            <h6>No widgets found to display</h6>
          )}
        </div>

        <div className={styles.paginationContainer}>
          <div>
            <Tooltip title="Refresh Widget Library">
              <IconButton variant="contained" onClick={() => getWidgets()}>
                <RefreshIcon />
              </IconButton>
            </Tooltip>
          </div>
          <div className={styles.pageContainer}>
            Widgets per page
            <Select
              value={rowsPerPage}
              label="Widgets per page"
              onChange={onRowsPerPageChange}
              className={styles.widgetPerPageSelect}
              disabled={widgetLibData.length === 0}
            >
              {paginationRowsCount.map((val) => (
                <MenuItem key={val} value={val}>
                  {val}
                </MenuItem>
              ))}
            </Select>
            <Pagination
              count={countPages} // total number of pages = ceil(421/10) = 43
              color="primary"
              page={page}
              onChange={onPageNumberChange}
              className={styles.wigetPagination}
              disabled={widgetLibData.length === 0}
            />
          </div>
        </div>
      </div>
      <div>
        {isFullScreen ? (
          <WidgetForm
            key={widgetForm.doc_id}
            isFullScreen={isFullScreen}
            widgetForm={widgetForm}
            mode={formMode}
            handleFullScreen={handleFullScreen}
            updateTable={getWidgets}
          />
        ) : null}
      </div>
      <div>
        {openRptAdd ? (
          <AddTemplateWgtToRpt
            open={openRptAdd}
            widgetSettings={createWidgetSettings()}
            handleClose={handleAddToRpt}
            routeToRpt={routeToRpt}
          />
        ) : null}
      </div>
      <SelectWidget
        handleSelectWidget={handleSelectWidget}
        handleClose={handleCloseAddWid}
        open={openAddWid}
      />
    </>
  );
};
export default WidgetLibManager;
