import React, { useState, useEffect, useMemo } from "react";
import { styled } from "@mui/material/styles";
import {
  Collapse,
  IconButton,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  FormLabel,
  Skeleton,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import EditIcon from "@mui/icons-material/Edit";
import { getConstantTags } from "./wgtLibraryApi";
import DocumentView from "../../pages/rptdashboard/widgets/document/DocumentView";

// import { shallow } from "zustand/shallow";
// import useGlobalStore from "../../../store/useGlobalStore";
// import * as constants from "./../../../constants/constants";

import _ from "lodash";
import * as widgetFooterStyles from "./widgetFooter.module.css";
import { TextField, Typography } from "@mui/material";

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
  marginLeft: "auto",
  position: "absolute",
  bottom: "0px",
  right: "5px",
  padding: "0px",
  transition: theme.transitions.create("transform", {
    duration: theme.transitions.duration.shortest,
  }),
}));

function WidgetFooter(props) {
  const { mode, widgetProps } = props;
  const [expandDescription, setExpandDescription] = useState(true);
  const [radioSelections, setRadioSelections] = useState(
    _.get(props.widgetProps.metaData, "radioSelections", {})
  );
  const [tags, setTags] = useState(
    _.get(props.widgetProps.metaData, "tags", "")
  );
  const [description, setDescription] = useState(
    _.get(props.widgetProps.metaData, "description", "")
  );
  const [categories, setCategories] = useState({});
  const [isCategoriesLoading, setIsCategoriesLoading] = useState(false);
  //  all methods start here:
  const handleExpandClick = () => {
    setExpandDescription(!expandDescription);
  };

  const updateDescriptiobAndTagsInStore = (
    descriptionValue,
    tagsValue,
    radioSelectionsValue
  ) => {
    props.updateSettingsProp("metaData", {
      description: descriptionValue,
      tags: tagsValue,
      radioSelections: radioSelectionsValue,
    });
  };
  // useEffect(() => {
  //   updateDescriptiobAndTagsInStore();
  // }, [description, tags]);

  const debounceCall = useMemo(
    () => _.debounce(updateDescriptiobAndTagsInStore, 400),
    []
  );

  // cleanup debounce call on unmount
  useEffect(() => {
    return () => {
      debounceCall.cancel();
    };
  }, [debounceCall]);

  const onEditDescription = (descText) => {
    setDescription(descText);
    debounceCall(descText, tags, radioSelections); // tags and radioSelections from state
  };

  const onTagsChange = (tagsText) => {
    setTags(tagsText);
    debounceCall(description, tagsText, radioSelections); // description and radioSelections from state
  };

  const onRadioButtonChange = (evt, category) => {
    const radioSelectionsCopy = { ...radioSelections };
    radioSelectionsCopy[category] = evt.target.value;
    setRadioSelections(radioSelectionsCopy);
    debounceCall(description, tags, radioSelectionsCopy); // description and tags from state
  };

  // on component mount get all avaiable meta-data (categories that will be used during filteration)
  useEffect(() => {
    if (mode && mode !== "view") {
      const getCategoriesFromApi = async () => {
        try {
          setIsCategoriesLoading(true);
          const categoriesObj = await getConstantTags();
          setCategories(categoriesObj);
        } catch (err) {
          console.error(
            "Something went wrong in getting constant tags from API!"
          );
        } finally {
          setIsCategoriesLoading(false);
        }
      };
      getCategoriesFromApi();
    }
  }, []);

  return (
    <div id="widgetFooter" className={widgetFooterStyles.widgetFooter}>
      {/* adding new meta data field */}
      <div style={{ margin: "10px", fontSize: "1.1rem", fontWeight: "500" }}>
        {mode === "view" ? "Metadata of widget:" : "Add meta data to widget: "}
      </div>
      <div className={widgetFooterStyles.widgetMetaDataContainer}>
        {/* when mode is preview-> just show the radioSelects as a text */}
        {mode === "view" ? (
          Object.entries(widgetProps?.metaData?.radioSelections).map(
            ([categoryName, value]) => (
              <span>{`${categoryName}: ${value}`}</span>
            )
          )
        ) : isCategoriesLoading ? 
          [...Array(5)].map((item, index) => (
            <Skeleton variant="rectangular" animation="wave" className={widgetFooterStyles.metaDataSkeleton} />
          ))
         
         : categories && Object.entries(categories).length > 0 ? (
          Object.entries(categories).map(([category, valueList]) => (
            <FormControl>
              <FormLabel sx={{ textTransform: "capitalize" }}>
                {category.split("_").join(" ")}:
              </FormLabel>
              <RadioGroup row>
                {valueList.map((value) => (
                  <FormControlLabel
                    sx={{ textTransform: "capitalize" }}
                    value={value}
                    control={
                      <Radio
                        onChange={(e) => onRadioButtonChange(e, category)}
                        checked={radioSelections[category] === value}
                      />
                    }
                    label={value.split("_").join(" ")}
                  />
                ))}
              </RadioGroup>
            </FormControl>
          ))
        ) : (
          <>No meta data found</>
        )}
      </div>
      <Collapse in={expandDescription} timeout="auto" unmountOnExit>
        <div style={{ margin: "10px", fontSize: "1.1rem", fontWeight: "500" }}>
          {mode === "view"
            ? "Description of widget:"
            : "Add description to widget: "}
        </div>
        {/* <div>
          <IconButton
            onClick={handleEditDescription}
            aria-label="edit note"
            className={widgetFooterStyles.editIcon}
          >
            <EditIcon />
          </IconButton>
        </div> */}
        <div style={{ margin: "0 5px" }}>
          <div style={{ flexGrow: "1", padding: "5px" }}>
            <DocumentView
              text={description}
              editMode={mode !== "view"} // i.e edit only when ADD WIDGET or EDIT WIDGET mode
              handleEdit={onEditDescription}
            />
          </div>
        </div>
      </Collapse>

      <div style={{ margin: "10px", fontSize: "1.1rem", fontWeight: "500" }}>
        {mode === "view" ? "Tags of widget:" : "Add tags to widget: "}
      </div>

      <div id={"widgetTags"} className={widgetFooterStyles.widgetTags}>
        {mode === "view" ? (
          _.get(props.widgetProps.metaData, "tags", "")
        ) : (
          <div>
            <TextField
              value={tags}
              fullWidth
              onChange={(e) => {
                onTagsChange(e.target.value);
              }}
              size="small"
            ></TextField>
          </div>
        )}
      </div>
      <br />
      <br />
      <ExpandMore
        expand={expandDescription}
        onClick={handleExpandClick}
        aria-expanded={expandDescription}
        aria-label="show more"
      >
        <ExpandMoreIcon />
      </ExpandMore>
    </div>
  );
}

WidgetFooter.defaultProps = {
  widgetProps: { name: "", config: { tags: "#TNS #WNS" } },
};

export default WidgetFooter;
