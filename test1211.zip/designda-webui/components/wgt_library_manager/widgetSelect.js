import React from "react";
import { widgets } from "../../pages/rptdashboard/addWidget/addWidget";
import { Box, Modal, Autocomplete, TextField } from "@mui/material";

function WidgetSelect(props) {
  const widgetOptions = Object.keys(widgets).sort();

  return (
    <Autocomplete
      id="widgets-select"
      sx={{
        width: "100%",
      }}
      ListboxProps={{
        style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", rowGap: '1em' },
      }}
      options={widgetOptions}
      autoHighlight
      getOptionLabel={(option) => option}
      renderOption={(props, option) => (
        <Box
          component="li"
          sx={{ "& > img": { mr: 2, flexShrink: 0 } }}
          {...props}
        >
          <img
            loading="lazy"
            width="50"
            height="35"
            src={widgets[option].imageUrl}
            srcSet={widgets[option].imageUrl}
            alt=""
          />

          {option}
        </Box>
      )}
      onChange={props.handleWidgetSelect}
      renderInput={(params) => (
        <TextField {...params} label="Choose a widget" />
      )}
    />
  );
}

const SelectWidget = (props) => {
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "60%",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    borderRadius: "15px",
    p: 4,
  };

  const handleAddWidgetClick = (event, widgetName, reason) => {
    props.handleSelectWidget(widgetName);
    props.handleClose();
  };

  return (
    <Box>
      <Modal open={props.open} onClose={props.handleClose}>
        <Box sx={style}>
          <WidgetSelect handleWidgetSelect={handleAddWidgetClick} />
        </Box>
      </Modal>
    </Box>
  );
};

export default SelectWidget;
