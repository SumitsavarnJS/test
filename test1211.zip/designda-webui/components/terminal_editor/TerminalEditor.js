import React, { useState } from "react";
import { IconButton, Snackbar } from "@mui/material";
import FileCopyIcon from "@mui/icons-material/FileCopy";
import { CopyToClipboard } from "react-copy-to-clipboard";

const CommandPromptOutput = ({ response }) => {
  const [copySuccess, setCopySuccess] = useState(false);
  const isError = response && response.stderr;
  const isSuccess = response && response.stdout;
  const handleCopySuccess = () => {
    setCopySuccess(true);
  };

  return (
    response && (
      <div
        style={{
          position: "relative",
          color: "black",
          background: "black",
          fontFamily: "monospace",
          padding: "10px",
          borderRadius: "5px",
        }}
      >
        <Snackbar
          open={copySuccess}
          autoHideDuration={2000}
          onClose={() => setCopySuccess(false)}
          message="Text copied to clipboard"
        />
        <CopyToClipboard
          text={response && response.stdout + "\n" + response.stderr}
          onCopy={handleCopySuccess}
        >
          <IconButton
            style={{
              position: "absolute",
              top: 0,
              right: 24,
              color: "white",
              zIndex: 1,
            }}
          >
            <FileCopyIcon />
          </IconButton>
        </CopyToClipboard>
        <div style={{ maxHeight: "300px", overflowY: "auto" }}>
          <pre style={{ color: "white" }}> Query Output!</pre>
          {isSuccess && <pre style={{ color: "green" }}>{response.stdout}</pre>}
          {isError && <pre style={{ color: "red" }}>{response.stderr}</pre>}
        </div>
      </div>
    )
  );
};
export default CommandPromptOutput;
