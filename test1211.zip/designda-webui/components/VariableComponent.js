import React, { useState } from "react"
import dynamic from 'next/dynamic'
import Button from "@mui/material/Button"
import AddIcon from "@mui/icons-material/Add"
import Dialog from "@mui/material/Dialog"
import DialogTitle from "@mui/material/DialogTitle"
import DialogContent from "@mui/material/DialogContent"
import TextField from "@mui/material/TextField"
import MenuItem from "@mui/material/MenuItem"
import DataSourceSelection from "./DataSourceComponent"
import Table from "@mui/material/Table"
import TableBody from "@mui/material/TableBody"
import TableCell from "@mui/material/TableCell"
import TableContainer from "@mui/material/TableContainer"
import TableHead from "@mui/material/TableHead"
import TableRow from "@mui/material/TableRow"
import useGlobalStore from "../store/useGlobalStore"
import MetricsBuildVariables from "./variables/MetricsBuildVariables"
import VisibilityIcon from "@mui/icons-material/Visibility"
import DialogActions from "@mui/material/DialogActions"
import IconButton from "@mui/material/IconButton"
// Dynamically import react-syntax-highlighter
const SyntaxHighlighter = dynamic(() => import('react-syntax-highlighter'), { ssr: false });
const a11yDark = dynamic(() => import('react-syntax-highlighter/dist/esm/styles/prism/a11y-dark'), { ssr: false });
const VariableDeclaration = ({
  saveReportInfo,
}) => {
  const varParentFromStore =
    useGlobalStore.getState().allDashbrdRpts.dashboardReport.variables
  const [open, setOpen] = useState(false)
  const [variableName, setVariableName] = useState("")
  const [variableType, setVariableType] = useState("")
  const [variablesParent, setVariablesParent] = useState(
    varParentFromStore ? varParentFromStore : {}
  )
  const [metricsDialogOpen, setMetricsDialogOpen] = useState(false)
  const [dataSource, setDataSource] = useState("")
  const [metricsCheckPoint, setMetricCheckPoint] = useState("")
  const [jsonViewerOpen, setJsonViewerOpen] = useState(false)
  const [jsonToView, setJsonToView] = useState(null)


  const [scenario, setScenario] = useState("")
  const [variableValue, setVariableValue] = useState("")
  const [dataSourceModalOpen, setDataSourceModalOpen] = useState(false)

  const [editVariableName, setEditVariableName] = useState("")
  const [editVariableType, setEditVariableType] = useState("")
  const [editVariableValue, setEditVariableValue] = useState("")


  const handleCloseDataSourceModal = () => {
    setDataSourceModalOpen(false)
  }
  const handleMetricsDialogClose = () => {
    setMetricsDialogOpen(false)
  }

  const handleClickOpen = () => {
    setOpen(true)
  }

  const handleVariableTypeChange = (e) => {
    const value = e.target.value
    setVariableType(value)

    // Open the MetricsBuildVariables dialog if the type is 'metrics_data_source'
    if (value === "metrics_data_source") {
      setMetricsDialogOpen(true)
    }
  }
  const resetForm = () => {
    setVariableName("")
    setVariableType("")
    setVariableValue("")
    setDataSource("")
    setScenario("")
    setMetricCheckPoint("")
  }
  const handleClose = () => {
    resetForm()
    setOpen(false)
  }

  const determineVariableType = (obj) => {
    return typeof obj !== 'object'
      ? 'user_defined'
      : obj.hasOwnProperty('dataSource')
        ? 'data_source'
        : obj.hasOwnProperty('metricsCheckPoint')
          ? 'metrics_data_source'
          : 'unknown'
  }
  const determineVariableValue = (value) => {
    return typeof value !== 'object'
      ? value
      : value.hasOwnProperty('metricsCheckPoint')
        ? `Metrics Source: ${JSON.stringify(value)}`
        : value.hasOwnProperty('dataSource')
          ? `Data Source: ${value.dataSource}, Scenario: ${value.scenario}`
          : 'unknown'
  }
  //function to add variables in dashboard json
  const handleAddVariable = () => {
    let newVariable
    if (variableType === "user_defined") {
      newVariable = {
        [variableName]: variableValue || "", // Use the entered value or an empty string
      }
    } else if (variableType === "data_source") {
      newVariable = {
        [variableName]: {
          dataSource,
          scenario,
        },
      }
    }
    else if (variableType === "metrics_data_source") {
      newVariable = {
        [variableName]: {
          metricsCheckPoint
        },
      }
    }
    // Update variablesParent with the new variable
    const updatedVarParent = { ...variablesParent, ...newVariable }
    setVariablesParent(updatedVarParent)

    //Update the Global state with latest variables
    useGlobalStore
      .getState()
      .setRootLevelData("variablesParent", updatedVarParent)
    const reportInfo = _.cloneDeep(
      useGlobalStore.getState().allDashbrdRpts.dashboardReport
    )

    reportInfo["variables"] = updatedVarParent
    useGlobalStore
      .getState()
      .updateDashboardObject({ dashboardReport: reportInfo })
    saveReportInfo()


    // Close the dialog
    resetForm()
    handleClose()
  }

  const handleDataSourceSelection = ({ tempConfig, scenariosSelect }) => {
    setDataSource(tempConfig)
    setScenario(scenariosSelect)
  }

  const metricsBuildSelection = (checkpoints) => {
    setMetricCheckPoint(checkpoints)
  }

  const handleEditVariable = (name, value) => {
    setVariableName(name)

    const variableTypeCheck = determineVariableType(value)

    // Handle "Data Source" type variables differently
    if (variableTypeCheck === "data_source") {

      setVariableType("data_source")
      setDataSource(value.dataSource)
      setScenario(value.scenario)
      setVariableValue("") // Clear user-defined variable value
      setMetricCheckPoint("")
    }
    else if (variableTypeCheck === "metrics_data_source") {

      setMetricsDialogOpen(true)
      setVariableType("metrics_data_source")
      setDataSource("")
      setScenario("")
      setMetricCheckPoint(value.metricsCheckPoint)
      setVariableValue("") // Clear user-defined variable value
    }

    else {
      setVariableType("user_defined")
      setVariableValue(value)
      setDataSource("") // Clear data source variable values
      setScenario("")
      setMetricCheckPoint("")
    }

    setOpen(true)
  }

  const handleUpdateVariable = () => {
    let updatedVariable

    if (variableType === "user_defined") {
      updatedVariable = {
        [variableName]: variableValue,
      }
    } else if (variableType === "data_source") {
      updatedVariable = {
        [variableName]: {
          dataSource,
          scenario,
        },
      }
    }

    setVariablesParent((prevVariables) => ({
      ...prevVariables,
      ...updatedVariable,
    }))

    // Clear the edit state
    setVariableName("")
    setVariableType("")
    setVariableValue("")
    setDataSource("")
    setScenario("")
    handleClose()
  }
  const handleJsonViewerOpen = (json) => {
    setJsonToView(json)
    setJsonViewerOpen(true)
  }
  const handleJsonViewerClose = () => {
    setJsonViewerOpen(false)
    setJsonToView(null)
  }
  const handleDeleteVariable = (name) => {
    // Remove the variable from variablesParent
    const { [name]: deletedVariable, ...restVariables } = variablesParent
    setVariablesParent(restVariables)

    const reportInfo = _.cloneDeep(
      useGlobalStore.getState().allDashbrdRpts.dashboardReport
    )

    //Update the Local variable when Global variable is changes
    // for (const widgetName in reportInfo.widgets) {
    //   if (
    //     constants.interactiveWidgetList.includes(
    //       reportInfo.widgets[widgetName].name
    //     )
    //   ) {
    //     reportInfo.widgets[widgetName].config["wVariables"] = _.merge(
    //       reportInfo.widgets[widgetName].config["wVariables"],
    //       restVariables
    //     )
    //   }
    // }
    reportInfo["variables"] = restVariables
    useGlobalStore
      .getState()
      .updateDashboardObject({ dashboardReport: reportInfo })
    saveReportInfo()
  }

  return (
    <div>
      <div>
        <Button
          onClick={handleClickOpen}
          startIcon={<AddIcon />}
          sx={{ textTransform: "capitalize" }}
          variant="outlined"
        >
          Add Variable
        </Button>

        <div>
          <Dialog fullWidth maxWidth={"lg"} open={open} onClose={handleClose}>
            <DialogTitle>Add Variable</DialogTitle>
            <DialogContent>
              <br />
              <TextField
                label="Variable Name"
                variant="outlined"
                fullWidth
                value={variableName}
                onChange={(e) => setVariableName(e.target.value)}
              />
              <TextField
                select
                label="Variable Type"
                variant="outlined"
                fullWidth
                value={variableType}
                // onChange={(e) => setVariableType(e.target.value)}
                onChange={handleVariableTypeChange}
                style={{ marginTop: "16px" }}
                disabled={!variableName}
              >
                {/* Provide options for variable types */}
                <MenuItem value="user_defined">User Defined</MenuItem>
                <MenuItem value="data_source">Data Source</MenuItem>
                <MenuItem value="metrics_data_source">Metrics Data Source</MenuItem>
              </TextField>
              {variableType === "user_defined" && (
                <TextField
                  label="Default Value"
                  variant="outlined"
                  fullWidth
                  value={variableValue}
                  onChange={(e) => setVariableValue(e.target.value)}
                  style={{ marginTop: "16px" }}
                />
              )}

              {variableType === "data_source" && (
                <DataSourceSelection
                  onClose={handleCloseDataSourceModal}
                  onDataSourceSelection={handleDataSourceSelection}
                />
              )}
              {variableType === "metrics_data_source" && metricsDialogOpen && (
                <MetricsBuildVariables
                  metricsBuildSelection={(checkpoints) => {
                    setMetricCheckPoint(checkpoints)
                    handleMetricsDialogClose()
                  }}
                  open={metricsDialogOpen}
                  handleCloseMetrics={handleMetricsDialogClose}
                  variableName={variableName}
                />
              )}
              <div style={{ display: 'flex', justifyContent: "flex-start", marginTop: "16px", alignItems: "center" }}>
                <Button
                  onClick={handleAddVariable}
                  variant="contained"
                >
                  Add Variable
                </Button>

                <Button onClick={handleClose} sx={{ textTransform: "capitalize", ml: 1 }} variant="outlined">
                  Cancel
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Variables Added Table */}
      <div style={{ marginTop: "16px" }}>
        <strong>Added Variables:</strong>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Value</TableCell>
                <TableCell>Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {variablesParent &&
                Object.entries(variablesParent).map(([name, value]) => (
                  <TableRow key={name}>
                    <TableCell>{name}</TableCell>
                    <TableCell>
                      {determineVariableType(value)}
                    </TableCell>
                    <TableCell>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: 'flex-start' }}> {["data_source", "metrics_data_source"].includes(determineVariableType(value)) ? (<><IconButton onClick={() => handleJsonViewerOpen(value)}> <VisibilityIcon /></IconButton></>) : (determineVariableValue(value))} </div>
                    </TableCell>
                    <TableCell sx={{ display: "flex", gap: "10px" }}>
                      {/* Variable Value Visulisation for JSON values used React's JSON display package  */}
                      <Dialog open={jsonViewerOpen} onClose={handleJsonViewerClose} maxWidth="md" fullWidth><DialogTitle>Variable's Value</DialogTitle><DialogContent>
                        <SyntaxHighlighter language="json" style={a11yDark}>
                          {JSON.stringify(jsonToView, null, 2)}
                        </SyntaxHighlighter>
                      </DialogContent><DialogActions><Button onClick={handleJsonViewerClose}>Close</Button></DialogActions></Dialog>
                      <Button
                        onClick={() => handleEditVariable(name, value)}
                        sx={{ textTransform: "capitalize" }}
                        variant="outlined"
                      >
                        Edit
                      </Button>
                      <Button
                        onClick={() => handleDeleteVariable(name)}
                        sx={{ textTransform: "capitalize" }}
                        variant="outlined"
                      >
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
      {editVariableName && (
        <div style={{ marginTop: "16px" }}>
          {editVariableType === "user_defined" && (
            <TextField
              label="Edit Variable Value"
              variant="outlined"
              fullWidth
              value={editVariableValue}
              onChange={(e) => setEditVariableValue(e.target.value)}
            />
          )}

          {editVariableType === "data_source" && (
            <DataSourceSelection
              onDataSourceSelection={handleDataSourceSelection}
            />
          )}

          <Button onClick={handleUpdateVariable} style={{ marginTop: "16px" }}>
            Update
          </Button>
        </div>
      )}
    </div>
  )
}

export default VariableDeclaration
