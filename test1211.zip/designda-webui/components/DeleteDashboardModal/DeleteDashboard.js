import React, { useState, useEffect } from "react";


import {
  Dialog,
  DialogTitle,
  DialogContent,
  Select,
  Button,
  MenuItem,
  FormControl,
  Box,
  InputLabel,
  ListItemIcon,
  Tooltip,
  IconButton
} from "@mui/material";
import Modal from "@mui/material/Modal";
import DeleteIcon from "@mui/icons-material/Delete";
import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";
import Backdrop from '@mui/material/Backdrop';
import Fade from '@mui/material/Fade';
import getConfig from "next/config";
import axios from "axios";
import styles from "../../components/DeleteDashboardModal/DeleteDashboard.module.css";
import { toast } from 'react-toastify';

import 'react-toastify/dist/ReactToastify.css';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

export default function DeleteDashboard({ dashboardfileName, modalStateHandler, modalState }) {
  // const [open, setOpen] = useState(false);
  // const handleOpen = () => setOpen(true);
  const handleClose = () => modalStateHandler(false);
  const { publicRuntimeConfig } = getConfig();
  const imageUrl = publicRuntimeConfig.basePath;
  const [dashboardName, setDashboardName] = useState(
    useGlobalStore
      .getState()
      .allDashbrdRpts?.dashboardReport?.fileName.toString()
  );

  const handleDelete = async () => {

    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/delete_dashboard_report",
        {
          user: useConfigStore.getState().authLoginUser,
          file_name: dashboardfileName,
        }
      )
      .then((response) => {
        response = response.data;
        // saveConfig();
        if (response.status) {
          toast.info(response.message, { position: toast.POSITION.BOTTOM_LEFT });
           axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
        "/api/save_user_config",
        {
          data: {
            fileName: "Untitled-Dashboard",
            theme: "light",
            title: "Untitled-Dashboard",
            widgets: {},
          },
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          console.log(response.success);
          let rptData = {
            dashboardReport: {
              fileName: "",
              config: { expanded: false },
              widgets: {},
            },
          };
          useGlobalStore.getState().updateDashboardObject(rptData);
        } else {
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        console.log("Failed to reach Server");
      });
        } else {
          toast.error(response.message, { position: toast.POSITION.BOTTOM_LEFT });
        }
      })
      .catch((error) => {
        console.log("Failed to reach Server");
      });
    
    modalStateHandler(false);
  };


  return (

    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={modalState}
      onClose={handleClose}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}
    >
      <Fade in={modalState}>
        <Box sx={style}>
          <p> Do you want to delete the dashboard ? </p>
          <p>{dashboardfileName}
          </p>
          <Button id="btn1" onClick={handleDelete} autoFocus
            className={styles.button}
          > Yes, Delete It</Button>
          <Button id="btn2" onClick={handleClose} autoFocus
            className={styles.button}
          > Cancel </Button>
        </Box>
      </Fade>
    </Modal>
  );
}


