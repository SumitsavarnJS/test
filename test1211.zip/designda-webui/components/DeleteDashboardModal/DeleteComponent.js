
import React, { useState, useEffect } from "react";


import {
  Dialog,
  DialogTitle,
  DialogContent,
  Select,
  Button,
  MenuItem,
  FormControl,
  Box,
  InputLabel,
  ListItemIcon,
  Tooltip,
  IconButton
} from "@mui/material";
import Modal from "@mui/material/Modal";
import DeleteIcon from "@mui/icons-material/Delete";
import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";
import Backdrop from '@mui/material/Backdrop';
import Fade from '@mui/material/Fade';
import getConfig from "next/config";
import axios from "axios";
import styles from "../../components/DeleteDashboardModal/DeleteDashboard.module.css";
import { toast } from 'react-toastify';

import 'react-toastify/dist/ReactToastify.css';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 600,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

export default function DeleteComponent({  modalStateHandler, modalState, allReports,  report, closeReport, file_name}) {
  // const [open, setOpen] = useState(false);
  // const handleOpen = () => setOpen(true);

  console.log("checking props", {modalStateHandler, modalState, allReports,  report})
  const handleClose = () => modalStateHandler(false);
  const { publicRuntimeConfig } = getConfig();
  const imageUrl = publicRuntimeConfig.basePath;
  const commonString = useConfigStore.getState().commonString;
  
  const deleteReportInfo = () => {
    const reportInfo = allReports[report];
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/delete_gui_report",
        {
          file_name: commonString + allReports[report].fileName + ".json",
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          console.log("inside success resp -", response)
          // Show success toast message
          // Show Failure toast message
          closeReport(report);
          toast.info(`Analytics Report Deleted!`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        } else {
          // Show Failure toast message
          toast.error("Failed to delete analytics report", {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error) => {
        // show network error message
        // Show Failure toast message
        console.log("error");
      });
    // this.props.close();
    // this.props.handleSettingsMenuClose();
    modalStateHandler(false);
  };

















  


  return (

    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={modalState}
      onClose={handleClose}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}
    >
      <Fade in={modalState}>
        <Box sx={style}>
          <p> Do you want to delete the below Report ? </p>
         
          <p id="name1" className={styles.crisp}>{file_name}</p> 
      
        
          <Button id="btn1" onClick={deleteReportInfo} autoFocus
            className={styles.button}
          > Yes, Delete It</Button>
          <Button id="btn2" onClick={handleClose} autoFocus
            className={styles.button}
          > Cancel </Button>
        </Box>
      </Fade>
    </Modal>
  );
}


