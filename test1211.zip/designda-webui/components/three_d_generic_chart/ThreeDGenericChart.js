import React from "react";
import 'echarts-gl';
import ReactECharts from "echarts-for-react";
import useConfigStore from "../../store/useConfigStore";
const theme = useConfigStore.getState().theme;

const ThreeDGenericChart = (props) => {
    return (
        <ReactECharts
            option={props.optionData}
            style={{
                height: "100%",
                width: "100%",
                backgroundColor: theme == "dark" ? "rgb(50,50,50)" : "",
            }}
            theme={theme}
            notMerge={true}
        />
    );
};

export default ThreeDGenericChart;

ThreeDGenericChart.defaultProps = {
    optionData: {},
};