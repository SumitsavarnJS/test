import React, { useState, useRef, useEffect } from "react";
import "/node_modules/react-grid-layout/css/styles.css";
import "/node_modules/react-resizable/css/styles.css";
import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";
import GridLayout, { WidthProvider } from "react-grid-layout";
import * as styles from "../../pages/Dashboards/Dashboard.module.css";
import TabbedWidgetError from "../../components/widgetError/tabbedWidgetError";
import _ from "lodash";
import styled from "@xstyled/styled-components";
import { grid } from "../../constants/constants";

const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  padding: ${grid}px;
  border: ${grid}px;
  width: auto;
  padding-bottom: 0;
  user-select: none;
  width: auto;
`;

const DropZone = styled.div`
  /* stop the list collapsing when empty */
  height: auto;
  width: auto;
  /*
    not relying on the items for a margin-bottom
    as it will collapse when the list is empty
  */
  padding-bottom: ${grid}px;
`;

const ScrollContainer = styled.div`
  overflow-x: hidden;
  overflow-y: auto;
  height: auto;
`;

const Container = styled.div``;


const ReactGridLayout = WidthProvider(GridLayout);

function ReportGrid() {
    const { allReports, analyticsReportView } =
        useGlobalStore();
        const reportInfo = _.cloneDeep(allReports[analyticsReportView.currentTab]);

    const updateLayout = useGlobalStore((state) => state.updateReportWidgetLayout);


    const { configData, authLoginUser, theme } = useConfigStore();
    const isLocked = useGlobalStore((state) => state.reports[reportInfo.fileName]);


    const onLayoutChange = (newLayout) => {
        updateLayout(analyticsReportView.currentTab, newLayout);
        // console.log(newLayout)
    };


    const deleteWidget = (widgetId, report) => {
        const reports = _.cloneDeep(allReports);
        let widOrder = Object.keys(reports);
        widOrder.splice(widOrder.indexOf(widgetId), 1);
        delete reports[report].widgets[widgetId];
        reports[report]["widgetsOrder"] = widOrder;
        setRootLevelData("allReports", reports);
    };

    const getWidget = (widget, index) => {
        return (
            <div
                data-grid={{
                    i: widget.key,
                    x: _.get(widget, "x", 0),
                    y: _.get(widget, "y", 0),
                    w: _.get(widget, "w", _.get(widget, "width", 15)),
                    h: _.get(widget, "h", _.get(widget, "height", 10)),
                    minW: 2,
                    minH: 3,
                }}
                key={widget.key}
            >
                <TabbedWidgetError 
                widgetProps={widget} 
                id={widget.key} 
                deleteWidget={deleteWidget}
                index={index}
                report={
                    allReports[
                    useGlobalStore.getState().analyticsReportView
                      .currentTab
                    ]
                  }      
                  reportKey={ allReports[
                    useGlobalStore.getState().analyticsReportView
                      .currentTab
                    ].fileName}
                  endPointUrl=''
                  />
            </div>
        );
    };


    return (



        <>

            <Wrapper
                style={{
                    backgroundColor: useConfigStore.getState().theme == "dark"
                        ? "rgb(25,25,25)"
                        : "white",
                }}
            >
                <ScrollContainer >
                    <Container>
                        <DropZone>

                            <ReactGridLayout
                                className={styles.grid}
                                style={{
                                    backgroundColor: theme == "light" ? "white" : "rgb(30,30,30)",
                                }}
                                rowHeight={30}
                                cols={24}
                                draggableHandle={".draggable"}
                                draggableCancel={".non-draggable"}
                                onLayoutChange={onLayoutChange}
                                resizeHandle={
                                    <div className={isLocked ? styles.main : styles.lockMain}   >
                                        <div
                                            className={styles.quarter + " " + styles.quarter4}
                                            style={{
                                                backgroundColor: theme == "light" ? "grey" : "white",
                                            }}
                                        ></div>
                                        <div
                                            className={styles.cutout}
                                            style={{
                                                backgroundColor:
                                                    theme == "light" ? "white" : "rgb(18,18,18)",
                                            }}
                                        ></div>
                                    </div>
                                }
                            >
                                {  allReports[analyticsReportView.currentTab].hasOwnProperty("widgets") && _.map(allReports[analyticsReportView.currentTab]?.widgets, (widget) => getWidget(widget))}
                            </ReactGridLayout>
                        </DropZone>
                    </Container>

                </ScrollContainer>
            </Wrapper>

        </>
    )
}

ReportGrid.defaultProps = {
    widgets: {
        name: "",
        config: { w: 10, h: 8, title: "" },
        handleProps: {},
    },
};

export default ReportGrid
