import React, { useState, useEffect, useRef } from "react";
import styles from "./datacard.module.css";
import { styled } from "@mui/material/styles";
import PushPinIcon from '@mui/icons-material/PushPin';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import ToggleButton from '@mui/material/ToggleButton';
import Stack from '@mui/material/Stack';
import ListAltIcon from '@mui/icons-material/ListAlt';
import DescriptionIcon from '@mui/icons-material/Description';
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";

import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  TextField,
  CircularProgress,
  Divider,
  Tab,
  Tabs,
  TabScrollButton,
  Tooltip,
  Typography,
  IconButton,
  Skeleton,
  Button
} from "@mui/material";
import getConfig from "next/config";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import axios from "axios";
import StarIcon from "@mui/icons-material/Star";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import KeyboardDoubleArrowRightIcon from "@mui/icons-material/KeyboardDoubleArrowRight";
import KeyboardDoubleArrowLeftIcon from "@mui/icons-material/KeyboardDoubleArrowLeft";
import refreshWidgetContent from "../../pages/rptdashboard/wigetWrapper/widgetRefreshData";
import { toast } from "react-toastify";
import { useRouter } from "next/router";
import { nanoid } from "nanoid";
import { shallow } from "zustand/shallow";
import _, { capitalize } from "lodash";
import { margin } from "@mui/system";
import { marginTop } from "@xstyled/styled-components";

const CustomTabScrollButton = styled(TabScrollButton)(({ theme }) => ({
  "&.MuiTabScrollButton-vertical": {
    background: "linear-gradient(to right, #e3c3e9, #fdf5ff)",
  },
  "&.MuiTabs-scrollButtons.Mui-disabled": {
    opacity: 0.3,
  },
  // transition: "width 0.5s ease-in-out",
}));

function PrimarySearchAppBar({ dataInput, resizePanel, keyProp }) {
  const { publicRuntimeConfig } = getConfig();
  const imageUrl = publicRuntimeConfig.basePath;
  const { configData, authLoginUser } = useConfigStore();
  const { setRootLevelData, analyticsRightPane, dataPannelExpandCheck } = useGlobalStore(
    (state) => ({
      setRootLevelData: state.setRootLevelData,
      analyticsRightPane: state.analyticsRightPane,
      dataPanelExpandCheck: state.dataPanelExpandCheck,
    }),
    shallow
  );
  const authUser = authLoginUser;
  const [pinnedQueryStatus, setPinnedQueryStatus] = useState('')
  const [isEditing, setIsEditing] = useState({});
  const [editedDescriptions, setEditedDescriptions] = useState({});

  const taskParameters = ['project', 'username', 'block', 'phase', 'run_tag', 'checkpoint', 'time_stamp'];
  const flowParameters = ['project', 'username', 'report_name', 'time_stamp'];
  const techLibParameters = ['project', 'username', 'foundry', 'library', 'node', 'tag', 'time_stamp'];


  //project username phase runtag block checkpoint timestamp
  const [isClicked, setIsClicked] = useState(false);
  const [post, setPost] = useState([]);
  const [pathIndex, setPathIndex] = useState([])
  const [allData, setAllData] = useState([]);
  const [tabData, setTabData] = useState({});
  const [dashboardState, setDashboardState] = useState(true);
  const [showAllRptData, setShowAllRptData] = useState(false);
  const [selectedButton, setSelectedButton] = useState('available');

  const [formattedValue, setFormattedValue] = useState("");
  const [showDataCard, setDataCard] = useState(false);
  const [expanded, setExpanded] = useState({});
  const [activeTab, setActiveTab] = useState({});
  const [sugList, setSuggestionsList] = useState(false);
  const router = useRouter();
  const [starred, setStarred] = useState([]);
  const searchBoxRef = useRef(null);
  const accordionButtonRef = useRef({})
  const suggestionListRef = useRef(null);
  const [recentCard, setRecent] = useState([]);
  const { clickedJsons, addClickedJson, dataSearchActive } = useConfigStore();
  const [showDataCardText, setshowDataCardText] = useState(false);
  const [loading, setLoading] = useState({});
  // newly added states
  const [isResultLoading, setIsResultLoading] = useState(false);
  const [isPanelExpanded, setIsPanelExpanded] = useState(useGlobalStore.getState().dataPanelExpandCheck);
  const [reportLoadingDict, setReportLoadingDict] = useState({});

  const getJsonLinkStyle = (jsonLink) => {
    return isJsonClicked(jsonLink)
      ? { color: "#5a2a82" }
      : { color: "#0081FE" };
  };
  const isJsonClicked = (jsonLink) => {
    return clickedJsons.includes(jsonLink);
  };

  const onPinChange = () => {
    let pinQueryParam = formattedValue
    if (isClicked) {
      // Remove from local storage
      localStorage.removeItem('savedQuery');
      setIsClicked(false);
      setPinnedQueryStatus('')
    } else {
      // Add to local storage
      const newQuery = pinQueryParam; // You can replace this with your actual query
      localStorage.setItem('savedQuery', newQuery);
      setPinnedQueryStatus(newQuery)
      setIsClicked(true);
      toast.info(`Pinned Query: ${pinQueryParam}`, {
        position: toast.POSITION.BOTTOM_LEFT,
      });

    }
  };
  const handleQuery = (card) => {
    let str = card.key;
    let indexVal = str.indexOf("/");
    let firstPart = str.slice(0, indexVal);
    let secondPart = str.slice(indexVal + 1);
    let reportFinalKey = `${card.node}#${card.doc_type}/${secondPart}`;
    let report_type_val = "";
    if (card.doc_type === "task_reports") {
      report_type_val = "task";
    } else if (card.doc_type === "techlib_reports") {
      report_type_val = "techlib";
    } else if (card.doc_type === "flow_reports") {
      report_type_val = "flow";
    } else {
      report_type_val = "custom";
    }
    let formedObj = {
      bucket: firstPart,
      key: reportFinalKey,
      report_type: report_type_val,
      user: authUser,
    };
    axios
      .post(`${configData.rest_server_url}/api/fetch_report_data`, formedObj)
      .then((response) => {
        if (
          response?.status
        ) {
          toast.info(response?.message, {
            position: toast.POSITION.BOTTOM_LEFT,
          });
        } else {
          toast.error(response?.data?.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error, response) => {
        console.log(error)
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };

  const onReportJSONClick = (card, jsonLink) => {
    // start loading
    let str = card.key;
    const uniqueValueForLoader = `${str}_${jsonLink}`;
    setReportLoadingDict({
      ...reportLoadingDict,
      [uniqueValueForLoader]: true,
    });
    let indexVal = str.indexOf("/");
    let firstPart = str.slice(0, indexVal);
    let secondPart = str.slice(indexVal + 1);
    let reportFinalKey = `${card.node}#${card.doc_type}/${secondPart}`;
    let report_type_val = "";
    if (card.doc_type === "task_reports") {
      report_type_val = "task";
    } else if (card.doc_type === "flow_reports") {
      report_type_val = "flow";
    } else if (card.doc_type === "techlib_reports") {
      report_type_val = "techlib";
    } else {
      report_type_val = "custom";
    }
    let formedObj = {
      bucket: firstPart,
      key: reportFinalKey,
      report_type: report_type_val,
      user: authUser,
      child_name: jsonLink,
    };
    axios
      .post(`${configData.rest_server_url}/api/fetch_report_data`, formedObj)
      .then((response) => {
        if (
          response.data &&
          typeof response.data.data[0] === "object" &&
          response.data.data[0] !== null
        ) {
          // Handle success here, e.g. update state or show success message
          handlerouteClick(response.data.data[0]);
          let rptName = response.data.data[0].fileName;
          let rptData = response.data.data[0];
          addClickedJson(rptName);
          toast.info("Report Added To Queue", {
            position: toast.POSITION.BOTTOM_LEFT,
          });
          //if widget order is given separately
          if (response.data.data[0].widgetsOrder) {
            const widgetsOrder = response.data.data[0].widgetsOrder;
            //clone rpt data to set new order
            let rptDataClone = _.cloneDeep(rptData);
            delete rptDataClone.widgets;
            rptDataClone["widgets"] = {};
            //add widgets according to the new order given
            for (let index = 0; index < widgetsOrder.length; index++) {
              rptDataClone["widgets"][widgetsOrder[index]] =
                rptData["widgets"][widgetsOrder[index]];
            }
            rptData = rptDataClone;
          }
          rptData["report_metaData"] = formedObj;
          useGlobalStore.getState().updateGlobalObject(rptName, rptData);
          if (rptData.hasOwnProperty("widgets")) {
            for (const Wkey in rptData.widgets) {
              let WkeyObj = {
                data: {},
                uiState: {
                  isLoading: false,
                  showConfig: false,
                  isToastOpen: false,
                  toastSeverity: "info",
                  toastMessage: "",
                  cirlularLoading: false,
                },
              };
              useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
            }
          }
          const widgetArray = Object.keys(rptData.widgets);
          for (let i = 0; i < widgetArray.length; i++) {
            const widgetId = widgetArray[i];
            const config = rptData.widgets[widgetId].config;
            const name = rptData.widgets[widgetId].name;
            const rptType = rptData.widgets[widgetId]?.rptType
              ? rptData.widgets[widgetId]?.rptType
              : "";
            const reportKey = rptData.widgets[widgetId]?.reportKey
              ? rptData.widgets[widgetId]?.reportKey
              : "";
            const rptDataVariablesCheck = rptData.hasOwnProperty('variables') && rptData?.variables ? rptData.variables : {}
            const widgetVariables = Object.keys(rptDataVariablesCheck).length > 0 ? rptDataVariablesCheck : {}
            refreshWidgetContent({
              widgetId: widgetId,
              config: config,
              widgetName: name,
              reportKey: reportKey,
              rptType: rptType,
              variables: widgetVariables ? widgetVariables : {}
            });

            //condition to open the clicked report as current report in tabbed view
            if (useGlobalStore.getState().analyticsReportView.view === "tab") {
              useGlobalStore
                .getState()
                .setRootLevelData("analyticsReportView", {
                  view: "tab",
                  currentTab: rptName,
                });
            }
          }
        } else {
          toast.error(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error) => {
        // Handle error here, e.g. show error message
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      })
      .finally(() => {
        setReportLoadingDict({
          ...reportLoadingDict,
          [uniqueValueForLoader]: false,
        });
      });
  };

  const handlePinClick = () => {
    setSelectedButton('available')
    handleFormatClick(pinnedQueryStatus);
    setIsClicked(true)
  }
  const dataSummaryToggle = () => {
    // Add logic to fetch data based on the selected button (all or available)
    if (selectedButton === 'all') {
      handleReportDataSearch(true);
      setSelectedButton('available')
    } else {
      handleReportDataSearch(false);
      setSelectedButton('all')

    }
  };

  const processData = (data) => { return data.sort((a, b) => new Date(b.creation_date) - new Date(a.creation_date)).sort((a, b) => (a.doc_type === 'task_reports' && b.doc_type !== 'task_reports' ? -1 : 1)); }

  const handleReportDataSearch = (reportFilter) => {
    if (reportFilter) {
      const onlyReports = post.filter((card) => card.has_report);
      setPost(onlyReports);
      setShowAllRptData(true);
    } else {
      setPost(allData);
      setShowAllRptData(false);
    }
  };
  const handleFormatClick = (dataInput) => {
    // state to load the result
    setIsResultLoading(true);
    setSuggestionsList(false);
    setDataCard(true);
    setDashboardState(false);
    setshowDataCardText(true);
    setSelectedButton('available')
    let formattedString = dataInput;
    setFormattedValue(formattedString);
    axios
      .post(`${configData.rest_server_url}/api/fetch_data_cards`, {
        text: dataInput,
        user: authUser,
      })
      .then((response) => {
        try {
          // Update the state with the sorted array
          const sortedArray = processData(response.data.data)
          setAllData(sortedArray);
          // handleReportDataSearch(true)
          const onlyReports = sortedArray.filter((card) => card.has_report);
          setPost(onlyReports);
          const latestTaskWithReportAvailableIndex = onlyReports.findIndex(item => item.doc_type === 'task_reports' && item.has_report === true);
          if (latestTaskWithReportAvailableIndex !== -1) {
            try {
              let data = onlyReports[latestTaskWithReportAvailableIndex]
              //expand the generative summary tab
              onAccordionExpand(
                null,
                data,
                data.key,
                "view_more",
                true
              )
              // accordionButtonRef[path]?.click()
            }
            catch (e) {
              console.log(e)
            }
          }





          // update the starred array depending on is_pinned data
          const pinnedData = sortedArray
            .filter((obj) => obj.is_pinned)
            .map((obj) => obj.key);
          setStarred(pinnedData);
        } catch (e) {
          console.log(e);
        }
      })
      .catch((error) => {
        console.error("Error sending data to API:", error);
      })
      .finally(() => {
        setIsResultLoading(false);
      });
  };

  // api to fetch reports for a project
  const fetchReports = async (dataInput, uniqueKey) => {
    const payload = {
      project: dataInput.key.split("/")[0],
      report_name: dataInput.key,
      report_type: dataInput.doc_type,
      user: authUser,
    };
    setLoading({ ...loading, [uniqueKey]: true });
    axios
      .post(`${configData.rest_server_url}/api/fetch_reports`, payload)
      .then((response) => {
        try {
          const reqdResult = {
            ...tabData,
            [uniqueKey]: response.data.data,
          };
          setTabData(reqdResult);
          const defaultTabName = 'gen_task_summary'
          let tabNames = response?.data?.data?.tab_names
          let activeTabName = tabNames[0];

          if (tabNames.includes(defaultTabName)) {
            activeTabName = defaultTabName
            //open the summary report of generative summary workflow
            onReportJSONClick(dataInput, 'Gen_Task_Summary-->Checkpoint_Summary/Summary')
          }

          // const activeTabName = 'debug_clock_hold';
          setActiveTab({ ...activeTab, [dataInput.key]: activeTabName });
        } catch (e) {
          console.log(e)
          setLoading({ ...loading, [uniqueKey]: false });
          toast.error(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "white", color: "gray" },
          });
        }
      })
      .catch((error) => {
        console.error("Error sending data to API:", error);
      })
      .finally(() => {
        setLoading({ ...loading, [uniqueKey]: false });
      });
  };


  const handleEditClick = (key) => {
    setIsEditing((prev) => ({ ...prev, [key]: true }));
  };



  const handleSaveClick = (key) => {
    // Add your save logic here, e.g., API call to save the description
    setIsEditing((prev) => ({ ...prev, [key]: false }));
    console.log(key)
  };

  const onDescriptionChange = (key, value) => {
    setEditedDescriptions((prev) => ({ ...prev, [key]: value }));
  };
  // method that executes when accordion expand is clicked
  const onAccordionExpand = (e, data, key, clickedString, isReportPresent) => {

    if (!e) {
      e = {
        stopPropagation: () => {
          // Custom logic to mimic stopPropagation if needed
          console.log("Propagation stopped programmatically.");
        }
      };

    } else {
      e.stopPropagation();
    }
    // expand/collapse the accordion item
    setExpanded({ ...expanded, [data.key]: !expanded[data.key] });
    isPanelExpanded ? "" : onPanelClick(!isPanelExpanded);
    // if user clicks on expand accordion and reports are available, call APi to get reports
    if (isReportPresent && clickedString === "view_more") {
      fetchReports(data, key);
    }
  };

  // const onAccordionExpand = (e, data, key, clickedString, isReportPresent) => {
  //   // If no event is provided, create a synthetic event
  //   if (!e) {
  //     e = {
  //       stopPropagation: () => {
  //         // Custom logic to mimic stopPropagation if needed
  //         console.log("Propagation stopped programmatically.");
  //       }
  //     };
  //     e.stopPropagation();

  //   } else {
  //     e.stopPropagation();
  //   }
  //   // e.stopPropagation();
  //   // Toggle the expanded state for the specific accordion item
  //   setExpanded((prevExpanded) => ({
  //     ...prevExpanded,
  //     [data.key]: !prevExpanded[data.key],
  //   }));

  //   const isPanelExpanded = expanded[data.key]; // Assuming you have a state or variable to track panel expansion

  //   if (!isPanelExpanded) {
  //     onPanelClick(!isPanelExpanded);
  //   }

  //   if (isReportPresent && clickedString === "view_more") {
  //     fetchReports(data, key);
  //   }
  // };

  const handleTabClick = (name, uniqueKey) => {
    setActiveTab({ ...activeTab, [uniqueKey]: name });
  };

  //function to add descriptions
  const saveDescription = (cardKey, value) => {
    let reportTypeCheck = cardKey.split("/").length;
    let report_type_val = "task";
    if (reportTypeCheck === 7) {
      report_type_val = "task";
    } else if (reportTypeCheck === 4) {
      report_type_val = "flow";
    } else {
      report_type_val = "custom";
    }
    let indexVal = cardKey.indexOf("/");
    let firstPart = cardKey.slice(0, indexVal);
    let secondPart = cardKey.slice(indexVal + 1);

    let descriptionVal = value
    if (descriptionVal) {
      axios
        .post(`${configData.rest_server_url}/api/add_description`, {
          key: secondPart,
          bucket_name: firstPart,
          report_type: report_type_val,
          description: descriptionVal,
        })
        .then((response) => {
          if (response.data.status) {
            toast.info(response?.data?.message, {
              position: toast.POSITION.BOTTOM_LEFT,
            });
          }
          else {
            toast.error(response?.data?.message, {
              position: toast.POSITION.BOTTOM_LEFT,
            });

          }
        })
        .catch((error) => {
          // Handle error here, e.g. show error message
          toast.error(error, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        });
    } else {
      toast.error("Description cannot be empty", {
        position: toast.POSITION.BOTTOM_LEFT,
        style: { backgroundColor: "red", color: "white" },
      });
    }
  };

  const handleStarClick = (event, card, key, action, type) => {
    // prevent opening of accordion on star click
    event.stopPropagation();
    axios
      .post(`${configData.rest_server_url}/api/update_user_activity`, {
        user: authUser,
        key: key,
        doc_type: type,
        action: action,
      })
      .then((response) => {
        // set star / unstar on api response
        try {
          if (response.data.status) {
            if (action === "pin" && card.has_report) {
              handleQuery(card);
            }
            if (action == "unpin") {
              const rightPane = _.cloneDeep(analyticsRightPane);
              rightPane.savedRptCount = savedRptCount;
              rightPane.favouriteRptCount -= 1;
              setRootLevelData("analyticsRightPane", rightPane);
              fetchDataRecent();
            }
            const index = starred.indexOf(key);
            if (index === -1) {
              setStarred([...starred, key]);
            } else {
              const newStarred = [...starred];
              newStarred.splice(index, 1);
              setStarred(newStarred);
            }
          } else {
            toast.error(response.data.message, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: { backgroundColor: "red", color: "white" },
            });
          }
        } catch (err) {
          console.error("Something went wrong in update_user_activity API");
        }
      })
      .catch((error) => {
        console.error(error);
        toast.error(response.data.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };

  const handlerouteClick = (reportInfo) => {
    axios
      .post(`${configData.rest_server_url}/api/update_reports_info`, {
        data: reportInfo,
        user: useConfigStore.getState().authLoginUser,
      })
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        // Handle error here, e.g. show error message
        console.error(error);
        toast.error(response?.data?.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };

  const queryExecutionOnTypeChange = (index, location, docType) => {
    // Check if the clicked item is already selected, if yes, remove it
    const item = pathIndex[index];
    // Construct the string with predefined parameters for each item
    let constructedString = '';
    for (let i = 0; i <= index; i++) {
      const parameter = docType[i]; // Predefined parameter name
      const value = location.split('/')[i]; // Value of the clicked item
      constructedString += `${parameter}='${value}' AND `;
    }
    // Remove the trailing " AND " from the end of the string
    constructedString = constructedString.slice(0, -5);
    // setPinnedQueryStatus(constructedString)
    setIsClicked(false);

    handleFormatClick(constructedString)
    // Update selectedItems state with the clicked item
    setPathIndex([...pathIndex.slice(0, index), location.split('/')[index]]);
  }
  const onPathParamsClick = (index, location, dataType) => {
    if (dataType === "task_reports") {
      queryExecutionOnTypeChange(index, location, taskParameters)
    }
    else if (dataType === "flow_reports") {
      queryExecutionOnTypeChange(index, location, flowParameters)

    }
    else if (dataType === "techlib_reports") {
      queryExecutionOnTypeChange(index, location, techLibParameters)

    }
    else {
      toast.info("Current Support not there for Custom Reports", {
        position: toast.POSITION.BOTTOM_LEFT,
      });
    }


  };


  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        searchBoxRef.current &&
        !searchBoxRef.current.contains(event.target) &&
        suggestionListRef.current &&
        !suggestionListRef.current.contains(event.target) &&
        !event.target.matches(".suggestion-item")
      ) {
        setSuggestionsList(false);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [searchBoxRef, suggestionListRef]);

  useEffect(() => {
    // Check if localStorage is available and retrieve data
    const localStoredQuery = typeof window !== 'undefined' ? localStorage.getItem('savedQuery') : null;
    if (localStoredQuery) {
      // If data is found in localStorage, update the state
      setPinnedQueryStatus(localStoredQuery);
      if (dataSearchActive) {
        setIsClicked(false)
      }
      else {
        setIsClicked(true)
      }
    }

    if (dataInput) {
      let searchValueRoute = dataInput;
      handleFormatClick(searchValueRoute);
      // setDataCard(true);
      setDashboardState(false);
    }
  }, [dataSearchActive, dataInput, keyProp]);

  const fetchDataRecent = async (type) => {
    axios
      .post(`${configData.rest_server_url}/api/fetch_recent_docs`, {
        user: authUser,
      })
      .then((response) => setRecent(response.data.data))
      .catch((error) => {
        console.error("Error sending data to API:", error);
      });
  };

  // this method will collapse all expanded accordion
  const collapseAllExpandedAccordion = () => {
    let newExpandedState = { ...expanded };

    for (let key in newExpandedState) {
      newExpandedState[key] = false;
    }
    setExpanded(newExpandedState);
  };

  const onPanelClick = (panelExpansionBool) => {
    setIsPanelExpanded(panelExpansionBool);
    // props from parent
    useGlobalStore.getState().setRootLevelData('dataPanelExpandCheck', panelExpansionBool)
    resizePanel(panelExpansionBool);
  };

  const onTabChange = (event, tabName, key) => {
    setActiveTab({ ...activeTab, [key]: tabName });
    // on tab change, expand the panel if closed
    if (!isPanelExpanded) {
      onPanelClick(!isPanelExpanded)
    }
  };

  const ReportSkeletonLoader = () => {
    return (
      <div className={styles.reportSkeletonContainer}>
        {/* for tabs */}
        <div className={styles.skeletonTabLoaderDiv}>
          {/* render 3 tabs */}
          {[...Array(3)].map((item, index) => (
            <Skeleton
              key={index}
              variant="rectangular"
              animation="wave"
              className={styles.skeletonTabLoader}
            />
          ))}
        </div>
        {/* for tab content */}
        <div>
          <Skeleton
            variant="rectangular"
            animation="wave"
            className={styles.skeletonContentLoader}
          />
        </div>
      </div>
    );
  };

  const NoReportsAvailable = () => {
    return (
      <div className={styles.noReportsAvailable}>No reports available</div>
    );
  };

  return (
    <>
      <div
        className={styles.summaryHeader}
        style={{ justifyContent: isPanelExpanded ? "space-between" : "unset" }}
      >
        <div>
          {isPanelExpanded ? (
            <>
              <div>
                <Typography sx={{ fontSize: '16px', color: '#5B2C84' }}>
                  <strong>Data Summary:</strong>
                </Typography>
                <Stack direction="row" spacing={2} alignItems="center">
                  <ToggleButton
                    value={selectedButton}
                    onClick={dataSummaryToggle}
                    sx={{
                      width: 340, // Set a fixed width for the toggle button
                      // bgcolor: '#5B2C84',
                      // color: 'white',
                      '&.Mui-selected': {
                        // bgcolor: '#5B2C84',
                        color: 'black',
                      },
                      textTransform: 'capitalize',
                    }}
                  >
                    {selectedButton === 'all' ? <ListAltIcon /> : <DescriptionIcon />}
                    {selectedButton === 'all' ? 'Show Available Reports' : 'Show All Reports'}
                  </ToggleButton>
                  <div style={{ flexGrow: 15 }}></div> {/* Add a flexible space to align the "Show Pinned" button to the right */}
                  <Button
                    onClick={handlePinClick}
                    sx={{
                      bgcolor: isClicked ? '#CE93D8' : '',
                      color: isClicked ? '#000000' : '',
                      '&:hover': { bgcolor: isClicked ? '#CE93D8' : '#CE93D8' },
                      textTransform: 'capitalize',
                      display: isPanelExpanded ? "block" : "none"
                    }}
                  >
                    <PushPinIcon /> Show Pinned
                  </Button>
                </Stack>
              </div>

            </>
          ) : (
            <Typography
              sx={{
                fontSize: "16px",
                color: "#5B2C84",
                cursor: "pointer",
              }}
            // onClick={() => {
            //   handleReportDataSearch(false);
            // }}
            >
              <strong>Data </strong>
            </Typography>
          )}
        </div>
        {/* for showing pin icon and expand collapse icon */}
        <div>
          <IconButton onClick={() => { onPinChange() }}>
            {isClicked ? (<Tooltip placement="right" title={'pinned query: ' + pinnedQueryStatus}><PushPinIcon sx={{ display: isPanelExpanded ? "block" : "none" }} color="primary" /> </Tooltip>) :
              (<Tooltip placement="right" title={"Pin the Query"} > <PushPinIcon sx={{ transform: 'rotate(90deg)', display: isPanelExpanded ? "block" : "none" }} />  </Tooltip>)}

          </IconButton>
          <IconButton
            sx={{
              padding: "2px",
              color: "#5B2A84;",
            }}
            onClick={() => onPanelClick(!isPanelExpanded)}
          >
            {isPanelExpanded ? (
              <KeyboardDoubleArrowLeftIcon />
            ) : (
              <KeyboardDoubleArrowRightIcon />
            )}
          </IconButton>
        </div>
      </div>

      {isResultLoading ? (
        [...Array(50)].map((item, index) => (
          <Skeleton
            key={index}
            variant="rectangular"
            width="100%"
            height={40}
            animation="wave"
            className={styles.skeletonLoader}
          />
        ))
      ) : post.length > 0 ? (
        
        
        post.map((data, postIndex) => {
          // find all necessary data here
          const {
            key: path,
            data_type,
            doc_type,
            has_report: isReportPresent,
            creation_date
          } = data;
          const tab_names =
            tabData && tabData[path]?.tab_names ? tabData[path].tab_names : [];
          const tab_content =
            tabData && tabData[path]?.tab_content
              ? tabData[path].tab_content
              : [];

          const number_of_tabs = tab_names.length;
          return (
            <div key={path+'_'+postIndex}>
              <Accordion
                expanded={expanded[path] === undefined ? false : expanded[path]}
                style={{
                  borderBottomRightRadius: 0,
                  borderBottomLeftRadius: 0,
                  borderTopRightRadius: 0,
                  borderTopLeftRadius: 0,
                  borderBottom: "2px solid #dcdcdc",
                  backgroundColor: expanded[path]
                    ? "rgba(247, 245, 245, 0.5)"
                    : "#fff",
                }}
              >
                <Tooltip
                  placement="right"
                  title={`Data ${data_type} | Path: ${path
                    .split("/")
                    .join(" > ")}`}
                >
                  <AccordionSummary
                    expandIcon={(
                      <IconButton
                        ref={(elem) => { accordionButtonRef[path] = elem; }}
                        sx={{ p: 0 }}
                        onClick={(e) => onAccordionExpand(e, data, path, expanded[path] ? "view_less" : "view_more", isReportPresent)}

                      >
                        <ExpandMoreIcon sx={{ color: "#5a2a82" }} />
                      </IconButton>
                    )
                    }
                    style={{ padding: "0 10px", position: "relative" }}
                  >

                    {/* icon for analytics OR metrics */}
                    <Typography sx={{ width: "8%", flexShrink: 0, display: isPanelExpanded ? "block" : "none" }}>
                      <img
                        src={`${imageUrl}/data_search_icons/${data_type}.svg`}
                        alt="metrics-or-analytics-icon"
                      />
                    </Typography>

                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <Breadcrumbs aria-label="breadcrumb">
                        {path.split("/").map((entity, index) => (
                          <Link
                            key={index}
                            color="inherit"
                            href="#"
                            onClick={() => {
                              // Update pathIndex state when a breadcrumb is clicked
                              // setPathIndex(path.split("/").slice(0, index + 1));
                              // Call onPathParamsClick to construct and send the string
                              onPathParamsClick(index, path, doc_type);
                            }}
                          >
                            {entity}
                          </Link>
                        ))}
                      </Breadcrumbs>

                      <div id="descriptions" style={{ marginTop: '20px' }}>
                        {data.description?.length > 0 && !isEditing[data.key] ? (
                          <div id="descriptions" className={styles.descriptions}>
                            <TextField
                              sx={{ width: "90%" }}
                              variant="outlined"
                              size="small"
                              disabled
                              value={data.description}
                            />
                            <IconButton sx={{ color: "black" }} onClick={() => handleEditClick(data.key)}>
                              <EditIcon />
                            </IconButton>
                          </div>
                        ) : (
                          <>
                            <TextField
                              sx={{ width: "90%" }}
                              placeholder="Add Description"
                              variant="outlined"
                              size="small"
                              value={editedDescriptions[data.key]}
                              onChange={(event) => onDescriptionChange(data.key, event.target.value)}
                            />
                            <IconButton sx={{ color: "black" }} onClick={() => saveDescription(data.key, editedDescriptions[data.key])}>
                              <SaveIcon />
                            </IconButton>
                          </>
                        )}
                      </div>

                    </div>


                    {/* adding fav icon */}
                    <Typography
                      sx={{
                        width: "8%",
                        flexShrink: 0,
                        display: isPanelExpanded ? "block" : "none",
                      }}
                    >
                      <IconButton
                        sx={{
                          padding: "0",
                          marginLeft: "1%",
                          position: "absolute",
                          right: "2.5rem",
                        }}
                        disableRipple
                      >
                        <StarIcon
                          onClick={(event) =>
                            handleStarClick(
                              event,
                              data,
                              path,
                              starred.includes(path) ? "unpin" : "pin",
                              doc_type
                            )
                          }
                          style={{
                            color: starred.includes(path)
                              ? "#ffcf40" // golden
                              : "#dcdcdc", // grey
                            fontSize: "1.5rem",
                            marginLeft: "20px",
                          }}
                        />
                      </IconButton>
                    </Typography>

                    {/* <div >
                      <ExpandMoreIcon sx={{ color: "green" }} />
                    </div> */}

                  </AccordionSummary>
                </Tooltip>

                {/* body of accordion */}
                <AccordionDetails style={{ padding: "8px 1px" }}>
                  {/* if report exists, api gets called from onAccordionExpand method and loading /notloading happens */}
                  {/* if report does not exist, show the user that report is not available */}
                  {isReportPresent ? (
                    loading[path] ? (
                      <ReportSkeletonLoader />
                    ) : (
                      <Box
                        sx={{
                          flexGrow: 1,
                          bgcolor: "#fff",
                          // this will remove display - if not requierd use method of "collapseAllExpandedAccordion"
                          // display: isPanelExpanded ? "flex" : "none",
                          display: "flex",
                          height: number_of_tabs >= 4 ? 400 : 250,
                        }}
                      >
                        <Tabs
                          orientation="vertical"
                          variant="scrollable"
                          value={activeTab[path]}
                          scrollButtons
                          allowScrollButtonsMobile
                          ScrollButtonComponent={CustomTabScrollButton}
                          sx={{
                            borderRight: 2,
                            borderColor: "#fff",
                            minWidth: "10rem", // a min width for pink vertical tabs
                          }}
                        >
                          {/* render tab names */}
                          {tab_names.map((tab_name, tab_index) => (
                            <Tab
                              key={`${tab_name}_${tab_index}`}
                              label={tab_name.length > 0 ? tab_name : "NA"}
                              value={tab_name}
                              onClick={(event) =>
                                onTabChange(event, tab_name, path)
                              }
                              title={tab_name}
                              style={{
                                background:
                                  activeTab[path] == tab_name
                                    ? "linear-gradient(to right, #fff, #fff)"
                                    : "linear-gradient(to right, #e3c3e9, #fdf5ff)",
                                margin: "2px 0",
                                border:
                                  activeTab[path] === tab_name
                                    ? "2px solid #e3c3e9"
                                    : 0,
                                textTransform: "none",
                                color: "#333",
                                fontWeight:
                                  activeTab[path] === tab_name ? "700" : "400",
                              }}
                            />
                          ))}
                        </Tabs>

                        {/* render tab content */}
                        {tab_content
                          .filter(
                            (tab_content_obj) =>
                              tab_content_obj.tab_name === activeTab[path]
                          )
                          .map((tab_content_obj, tab_content_obj_index) => {
                            const keyForUniqueness =
                              tab_content_obj.creation_date
                                ? tab_content_obj.creation_date
                                : "";
                            return (
                              <div
                                key={`${keyForUniqueness}_${tab_content_obj_index}`}
                                className={styles.tabContent}
                              >
                                {/* description of a tab */}
                                <div>
                                  <p style={{ wordWrap: "break-word" }}>
                                    <strong>Description : </strong>
                                    {tab_content_obj.report_description}
                                  </p>
                                </div>
                                <Divider />
                                <br />

                                {/* show reports */}
                                <div className={styles.reportSection}>
                                  {tab_content_obj.stepper.map(
                                    (step_obj, step_index) => (
                                      <div
                                        key={`${step_obj.name}_${step_index}`}
                                        className={styles.reportGroupContainer}
                                      >
                                        <div className={styles.reportHeader}>
                                          <img
                                            src={`${imageUrl}/data_search_icons/workflow.svg`}
                                            alt="workflow-icon"
                                            className={styles.workflowIcon}
                                          />

                                          <div
                                            className={styles.reportHeaderName}
                                          >
                                            {step_obj.name.toString()}
                                          </div>
                                        </div>
                                        <div>
                                          {step_obj.description.map(
                                            (item, item_index) => (
                                              <div
                                                key={`${item}_${item_index}`}
                                                className={
                                                  styles.reportLogoAndNameContainer
                                                }
                                              >
                                                {reportLoadingDict[
                                                  `${item.report.key}_${item.report.child_name}`
                                                ] ? (
                                                  <CircularProgress
                                                    size={10}
                                                    sx={{
                                                      marginTop: "7px",
                                                    }}
                                                  />
                                                ) : (
                                                  <img
                                                    src={`${imageUrl}/data_search_icons/document.svg`}
                                                    alt="report-icon"
                                                    className={
                                                      styles.reportLogo
                                                    }
                                                  />
                                                )}

                                                <div
                                                  className={styles.reportName}
                                                  onClick={() =>
                                                    onReportJSONClick(
                                                      item.report,
                                                      item.report.child_name
                                                    )
                                                  }
                                                >
                                                  {item.report.name.toString()}
                                                </div>
                                              </div>
                                            )
                                          )}
                                        </div>
                                      </div>
                                    )
                                  )}
                                </div>
                              </div>
                            );
                          })}
                      </Box>
                    )
                  ) : (
                    <NoReportsAvailable />
                  )}
                </AccordionDetails>
              </Accordion>
            </div>
          );
        })
      ) : (
        <div className={styles.flexCenter}>No results found</div>
      )}
    </>
  );
}
export default PrimarySearchAppBar;
