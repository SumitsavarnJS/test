import React, { useState, useEffect } from "react";
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import _ from "lodash";
import axios from "axios";
import DataSource from '../../../pages/rptdashboard/data_source/DataSource';
import useConfigStore from "../../../store/useConfigStore";
import { Box } from "@mui/material";
import { ClickAwayListener } from "@mui/base";
import dynamic from "next/dynamic";
import refreshScatterPlot from './ScatterPlotApi';
import styles from "./Config.module.css";

// get ace editor as a dynamic import
const AceEditor = dynamic(
    () =>
        import("../../queryEditor/QueryEditor").then(
            (mod) => mod.default
        ),
    { ssr: false }
);


const Config = (props) => {
    // comments for query editor
    const defaultQueryBody = `# Data has been loaded in df variable
# Please modify the df variable to contain data needed for the plot
# 1st column plots X axis
# 2nd column plots Y axis
`

    const [title, setTitle] = useState(_.get(props.config, 'title', ''));
    const [dataLocation, setDataLocation] = useState(_.get(props.config, 'dataLocation', ''));
    const [data, setData] = useState(_.get(props.config, 'data', ''));
    const [columns, setColumns] = useState(_.get(props.config, 'columns', []));
    const [bucket, setBucket] = useState(_.get(props.config, 'bucket', ''));
    const [query, setQuery] = useState(_.get(props.config, 'query', defaultQueryBody));
    const [showDataSource, setShowDataSource] = useState(false);
    const [dataList, setDataList] = useState([]);
    const [columnList, setColumnList] = useState([]);


    // dataChanged handler. This will fetch the list of columns for this data
    const dataChanged = (location, newData) => {
        const data = {
            bucket: bucket,
            key: location,
            ldb_file: newData
        }
        axios
            .post(
                _.get(useConfigStore.getState().configData, "rest_server_url", "") +
                "/api/fetch_parquet_columns",
                data
            )
            .then((response) => {
                let localColumns = [];
                const selectedColumns = columns;
                const columnList = _.get(response.data, "data", {});
                for (const rowIdx in selectedColumns) {
                    if (columnList.includes(selectedColumns[rowIdx])) {
                        localColumns.push(selectedColumns[rowIdx])
                    }
                }
                setData(newData);
                setColumnList(columnList);
                setColumns(localColumns);
            })
            .catch(error => {
                console.error(error);
            });
    }

    // handler when data source is changed
    const dataLocationChanged = (newDataLocation, bucket) => {
        const inputData = {
            bucket: bucket,
            key: newDataLocation
        }
        axios
            .post(
                _.get(useConfigStore.getState().configData, "rest_server_url", "") +
                "/api/get_ldb_files",
                inputData
            )
            .then((response) => {
                const dataList = _.get(response.data, "data", {});
                let localData = data; //data from state
                if (localData && !dataList.includes(localData)) {
                    localData = "";
                }
                // update states
                setDataLocation(newDataLocation);
                setDataList(dataList)
                setBucket(bucket)
                setData(localData)

                if (localData) {
                    dataChanged(dataLocation, localData);
                } else {
                    setColumns([]);
                    setColumnList([]);
                }
            })
            .catch(error => {
                console.error(error);
            });
    }

    // on mount, do a check if source is changed => refresh if true
    useEffect(() => {
        // refresh data list if data location is present
        if (dataLocation) {
            dataLocationChanged(dataLocation, bucket);
        }
    }, [])

    // on query editor change
    const onQueryChange = (newQuery) => {
        setQuery(newQuery);
    }

    // handler when user clicks OK button in Config
    const onOKButtonClick = () => {
        const config = {};
        config['dataLocation'] = dataLocation;
        config['data'] = data;
        config['columns'] = columns;
        config['query'] = query;
        config['bucket'] = bucket;
        // add title only if user has provided it
        if (title.length > 0) {
            config['title'] = title;
        }
        // call a method to update the config
        props.updateConfig(config, true);
        // add a method to call 'refresh' fucntionality i.e api call
        refreshScatterPlot(props.id, config)
    }

    return (
        <div className={styles.outer_div}>
            <div>
                <TextField fullWidth
                    label="Title" size="small" value={title}
                    InputLabelProps={{
                        shrink: true,
                    }}
                    onChange={(event) => setTitle(event.target.value)}
                    variant="outlined"
                />
            </div>

            {/* Select Data Source */}
            <div className={styles.inline}>
                <Button
                    size="small"
                    classes={{ root: styles.add_button }}
                    onClick={() => setShowDataSource(true)}
                >
                    Data Source
                </Button>
                {/* show data source table if user has clicked Data Source button */}
                {showDataSource ? (
                    <ClickAwayListener
                        onClickAway={() => {
                            setShowDataSource(false);
                        }}
                    >
                        <Box
                            sx={{
                                zIndex: "5",
                                position: "absolute",
                                top: "0px",
                                left: "0px",
                                width: "100%",
                                height: "fit-content",
                                backgroundColor: "white",
                                padding: "5px",
                                boxShadow: "grey 5px 5px 5px",
                            }}
                        >
                            <DataSource
                                dataLocationChanged={dataLocationChanged}
                                dataLocation={dataLocation}
                                bucket={bucket}
                                close={() => setShowDataSource(false)}
                            />
                        </Box>
                    </ClickAwayListener>
                ) : null}
                <Typography
                    variant="body2"
                    style={{ marginTop: "15px", marginLeft: "15px" }}
                >
                    {dataLocation.split("#")[1]}
                </Typography>
            </div>

            {/* Select Dataframe */}
            <Autocomplete
                id="data-input"
                className={styles.data_autocomplete_field}
                value={data}
                onChange={(event, newDataLocationValue) => dataChanged(dataLocation, newDataLocationValue)}
                classes={{
                    'option': styles.option
                }}
                size="small"
                options={dataList}
                getOptionLabel={(option) => option.includes('#') ? option.split("#")[1] : option}
                renderInput={(params) => <TextField {...params} label="Data" variant="outlined" />}
            />

            {/* Select Columns */}
            <Autocomplete
                id="columns-input"
                multiple
                filterSelectedOptions
                className={styles.data_autocomplete_field}
                value={columns}
                onChange={(event, newColumnValue) => setColumns(newColumnValue)}
                classes={{
                    'option': styles.option
                }}
                size="small"
                options={columnList}
                renderInput={(params) => <TextField {...params} label="Columns" variant="outlined" />}
            />

            {/* Code editor */}
            <Typography variant="subtitle1" className={styles.label}>
                Query Editor
            </Typography>
            <AceEditor
                placeholder="Please modify df object depending on the query."
                mode="python"
                theme="xcode"
                name="code_editor"
                width="100%"
                onChange={(value, event) => onQueryChange(value)}
                fontSize={16}
                maxLines={Infinity}
                showPrintMargin={true}
                showGutter={true}
                highlightActiveLine={true}
                value={query}
                setOptions={{
                    enableBasicAutocompletion: true,
                    enableLiveAutocompletion: true,
                    enableSnippets: false,
                    showLineNumbers: true,
                    tabSize: 2,
                }} />

            <Button
                variant="contained"
                size="small"
                disabled={false}
                onClick={onOKButtonClick}
                classes={
                    false
                        ? { root: styles.save_button_disabled }
                        : { root: styles.save_button }
                }
            >
                OK
            </Button>
            <Button
                variant="contained"
                size="small"
                onClick={() => props.updateConfig({}, false)}
                classes={{ root: styles.cancel_button }}
            >
                Cancel
            </Button>
        </div>
    );
}

export default Config;