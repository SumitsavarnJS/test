// react imports
import React, { useState, useEffect } from "react";
import Typography from "@mui/material/Typography";
import ReactEcharts from "echarts-for-react";
import Config from "./Config";
import useGlobalStore from "../../../store/useGlobalStore";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";
import { produce } from "immer";
import styles from "./ScatterPlot.module.css";

const ScatterPlot = (props) => {
  // component constants
  const widgetId = props.id;
  const [data, setData] = useState(_.get(useGlobalStore.getState()[props.id], "data", {}))
  const uiState = _.get(useGlobalStore.getState()[props.id], "uiState", {
    showConfig: false,
  });
  const [showErrorMsg, setShowErrorMsg] = useState(false);

  // check if error in data
  useEffect(() => {
    // if data exists
    if (Object.keys(data).length > 0) {
      const oneRow = data.series[0].data[0]; // rows is an array of arrays
      if (typeof oneRow[0] == "string" || typeof oneRow[1] === "string") {
        setShowErrorMsg(true);
      }
    }

  }, [data])
  // Function to update config
  const updateConfig = (config, save) => {
    // if user has refreshed, save the data in store
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(props.rptType, props.reportKey, widgetId, config);
    }

    useGlobalStore.getState().setWidgetUiState(widgetId, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  const getEchartsOption = (option) => {
    // tooltip formatter
    const formatTooltip = {
      formatter: function (params) {
        const Ycoord = params.data[1];
        const Xcoord = params.data[0];
        return "X: " + Xcoord + "<br/>" + "Y: " + Ycoord;
      },
    }
    // const rows = option["series"][0]["data"];
    
    const updatedOption = produce(option, (optionDraft) => {
      optionDraft["tooltip"]["formatter"] = formatTooltip.formatter;
    });
    return updatedOption;
  };

  // render components (React tabulator) conditionally depending on data
  return (
    <>
      {uiState.showConfig ? (
        <Config
          updateConfig={updateConfig}
          config={props.config}
          id={widgetId}
        />
      ) : data && Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <div className={styles.chartParent}>
          {/* get the 3d scatter chart component here */}
          {
            showErrorMsg ? "Input data is incorrect" :
              <ReactEcharts
                style={{
                  height: "100%",
                  width: "100%",
                }}
                option={getEchartsOption(data)}
              />
          }
        </div>
      )}
    </>
  );
};

export default ScatterPlot;

ScatterPlot.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
