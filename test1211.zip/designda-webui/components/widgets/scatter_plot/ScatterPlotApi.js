import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { produce } from "immer";
import { toast } from "react-toastify";
import api from "../../../common/api/api";
const getScatterPlotPayload = (config) => {
  const payload = {
    bucket: _.get(config, "bucket", ""),
    chart_type: "scatter_plot",
    key: _.get(config, "dataLocation", ""),
    ldb_file: _.get(config, "data", ""),
    raw_query: _.get(config, "query", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
  };

  // add columns if provided
  const columns = _.get(config, "columns", []);
  if (columns.length > 0) {
    payload["columns"] = config.columns;
  }
  return payload;
};

const fetchWidgetData = async (widgetId, payload) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  // api call to get scatter plot data
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url + "/api/run_query",
    payload
  );
  const {status, message} = fetchData;
  const toastConfig = {
    position: toast.POSITION.BOTTOM_LEFT,
    style: {
      fontSize: "14px",
      padding: "8px  12px",
    },
  }
  
  //  show error toast if fetchData->status is false
  if(!status) {
    toast.error(message, toastConfig);
  }

  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
  }
};

const refreshScatterPlot = (widgetId, config) => {
  fetchWidgetData(widgetId, getScatterPlotPayload(config));
};

export default refreshScatterPlot;
