import React, { useState } from "react";

//utilitis
import _ from "lodash";

import api from "../../../common/api/api";
import * as utils from "../../../common/utils/utils";
import * as constants from "../../../constants/constants";

//store
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";

import styles from "./LayoutViewV2.module.css";
import Canvas from "./components/drawings/Canvas";
import ControlPanel from "./components/panels/ControlPanel";
import { Box, Typography } from "@mui/material";

import Config from "./Config";
import refreshWidgetContent from "../../../pages/rptdashboard/wigetWrapper/widgetRefreshData";

const LayoutViewV2 = (props) => {
  const { updateConfig, setWidgetUiState } = useGlobalStore();

  const [config, setConfig] = useState({
    lock: true,
    showControlPanel: true,
    objects: {
      cell: {
        visible: true,
        expanded: false,
        contextMenu: [{ label: "gfgffd", action: "addWidget", widgetId: "" }],
      },
      macro: { visible: true, expanded: false, contextMenu: [] },
      blockage: { visible: true, expanded: false, contextMenu: [] },
      voltageArea: { visible: true, expanded: false, contextMenu: [] },
      rp: { visible: true, expanded: false, contextMenu: [] },
      net: { visible: true, expanded: false, contextMenu: [] },
      timingpath: { visible: true, expanded: false, contextMenu: [] },
    },
  });

  const handleControlPanel = (newConfig) => {
    setConfig(newConfig);
  };

  const refreshLayout = (config) => {
    console.log({
      widgetId: props.id,
      widgetName: constants.layoutView,
      config: config,
      reportKey: props.reportKey,
      rptType: props.rptType,
      variables:
        useGlobalStore.getState()[props.rptType][props.reportKey].variables,
    });
    refreshWidgetContent({
      widgetId: props.id,
      widgetName: constants.layoutView,
      config: config,
      reportKey: props.reportKey,
      rptType: props.rptType,
      variables:
        useGlobalStore.getState()[props.rptType][props.reportKey].variables,
    });
  };

  // Function to update config
  const updateWidgetConfig = (config, save) => {
    const nextUiState = {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    };

    if (save) {
      updateConfig(props.rptType, props.reportKey, props.id, config);
      refreshLayout(config);
      nextUiState.isLoading = true;
    }

    setWidgetUiState(props.id, nextUiState);
  };

  const getContainer = () => {
    return (
      <Box id="LayoutContainer" className={styles.Layout_container}>
        <div id="LayoutContent" className={styles.Layout_Content}>
          <div id="DrawingArea" className={styles.Drawing_Area}>
            <Canvas />
          </div>
        </div>
        <ControlPanel config={config} handleControlPanel={handleControlPanel} />
      </Box>
    );
  };

  const getConfig = () => {
    return (
      <Config
        updateWidgetConfig={updateWidgetConfig}
        id={props.id}
        config={props.widgetProps.config}
      />
    );
  };

  const getLayout = () => {
    const uiState = _.get(useGlobalStore.getState()[props.id], "uiState", {
      showConfig: false,
    });

    let background = "white";
    if (useConfigStore.getState().theme === "dark") {
      background = "#100c2a";
    }

    if (uiState.showConfig) {
      return getConfig();
    } else {
      return Object.keys(_.get(useGlobalStore.getState()[props.id], "data", {}))
        .length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : useGlobalStore.getState()[props.id] &&
        useGlobalStore.getState()[props.id].data.floorplan &&
        Object.keys(
          _.get(useGlobalStore.getState()[props.id], "data", {}).floorplan
        ).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No proper data. Please reconfigure and refresh again!
        </Typography>
      ) : (
        <div
          id="LayoutView"
          style={{ background: background, height: "100%", width: "100%" }}
        >
          {getContainer()}
        </div>
      );
    }
  };

  return (
    <div id="LayoutView_V2" className={styles.Layout_container}>
      {getContainer()}
    </div>
  );
};

export default LayoutViewV2;
