import React, { useState } from "react";

import styles from "./ControlPanel.module.css";
import {
  Box,
  Divider,
  FormControl,
  FormControlLabel,
  Stack,
  Switch,
  Tab,
  Tabs,
  Tooltip,
  Typography,
} from "@mui/material";

import { styled } from "@mui/material/styles";
import _ from "lodash";
import LayerView from "./control_panel_components/LayerView";
import MapView from "./control_panel_components/MapView";
import ObjectView from "./control_panel_components/ObjectView";
import InfoView from "./control_panel_components/InfoView";

const CustomTabs = styled(Tabs)(({ theme }) => ({
  "&.MuiTabs-root": {
    height: "30px",
    width: "100%",
    minHeight: "30px",
    backgroundColor: "#d9d9d9",
  },
  "& .Mui-selected": {
    backgroundColor: "#ffffff",
  },
}));

const CustomTab = styled(Tab)(({ theme }) => ({
  "&.MuiTab-root": {
    minHeight: "30px",
    height: "30px",
    border: "1px solid white",
    borderRadius: "5px",
  },
}));

const tabs = [
  {
    label: "Info",
    value: "info",
    tooltip: "Shows information about currently present Objects",
  },
  { label: "Object", value: "objects", tooltip: "Design components" },
  { label: "Layer", value: "layer", tooltip: "Metal Layers" },
  {
    label: "HeatMap",
    value: "map",
    tooltip: "Heatmaps of power, timing path, congestion, DRC",
  },
];

const ControlPanel = (props) => {
  const [panelSettings, setPanelSettings] = useState({
    currentTab: tabs[0].value,
  });
  const handleConfigChange = (event) => {
    props.handleControlPanel({
      ...props.config,
      [event.target.name]: event.target.checked,
    });
  };
  console.log(props.config);
  const handleCollapsePanel = () => {
    const newConfig = {
      ...props.config,
      showControlPanel: !_.get(props.config, "showControlPanel", false),
    };
    if (!newConfig.showControlPanel) {
      newConfig.lock = false;
    }
    props.handleControlPanel(newConfig);
  };

  const getSidePanelStyles = () => {
    if (_.get(props.config, "showControlPanel", false)) {
      return {
        position: _.get(props.config, "lock", false) ? "" : "absolute",
        transform: "translateX(0)",
      };
    } else {
      return {
        position: _.get(props.config, "lock", false) ? "" : "absolute",
        transform: "translateX(100%)",
      };
    }
  };

  const handleTabsChange = (event, newValue) => {
    setPanelSettings({ ...panelSettings, currentTab: newValue });
  };

  const getSettingsView = () => {
    let view = null;
    switch (panelSettings.currentTab) {
      case "objects":
        view = (
          <ObjectView
            handleControlPanel={props.handleControlPanel}
            config={props.config}
          />
        );
        break;
      case "layer":
        view = (
          <LayerView
            handleControlPanel={props.handleControlPanel}
            config={props.config}
          />
        );
        break;
      case "map":
        view = (
          <MapView
            handleControlPanel={props.handleControlPanel}
            config={props.config}
          />
        );
        break;
      case "info":
        view = (
          <InfoView
            handleControlPanel={props.handleControlPanel}
            config={props.config}
          />
        );
        break;
      default:
        console.log("No view assigned");
    }

    return view;
  };

  return (
    <div
      id="Side_panel_parent"
      className={styles.Side_panel_parent}
      style={getSidePanelStyles()}
    >
      <Stack direction={"column"} className={styles.panel}>
        <FormControl>
          <FormControlLabel
            label={<Typography variant="body2">Dock Control Panel</Typography>}
            control={
              <Switch
                size="small"
                checked={_.get(props.config, "lock", false)}
                onChange={handleConfigChange}
                name="lock"
                sx={{ marginLeft: "10px" }}
              />
            }
          />
        </FormControl>
        <Divider
          variant="fullwidth"
          sx={{ bgcolor: "primary.light", borderBottomWidth: "1px" }}
        />

        <Box className={styles.settings_box}>
          <Typography className={styles.settings_text} variant="body1">
            Control Panel
          </Typography>
          <CustomTabs
            value={panelSettings.currentTab}
            onChange={handleTabsChange}
          >
            {tabs.map((tab, index) => (
              <CustomTab
                sx={{ height: "20px" }}
                value={tab.value}
                label={
                  <Tooltip title={_.get(tab, "tooltip", "")} placement="top">
                    <Typography variant="body2">{tab.label}</Typography>
                  </Tooltip>
                }
              />
            ))}
          </CustomTabs>
          <Box id="View_pane" className={styles.View_Pane}>
            {getSettingsView()}
          </Box>
        </Box>
      </Stack>
      <div
        id={"Collapse_Button"}
        className={styles.Collapse_button}
        onClick={handleCollapsePanel}
      >
        {!_.get(props.config, "showControlPanel", false) ? "<" : ">"}
      </div>
    </div>
  );
};

export default ControlPanel;
