import React from "react";

import styles from "./InfoView.module.css";
import { Accordion, AccordionDetails, AccordionSummary } from "@mui/material";
import { Objects } from "./ObjectView";

const InfoGroups = [
  { label: "Objects", value: "object", tooltip: "" },
  { label: "HeatMap", value: "heatmap", tooltip: "" },
];

const InfoView = (props) => {
  const getObjects = () => {
    return Objects.map((object, index) => (
      <Accordion
        key={object.value}
        disableGutters
        slotProps={{ transition: { unmountOnExit: true } }}
      >
        <AccordionSummary>{object.label}</AccordionSummary>
        <AccordionDetails></AccordionDetails>
      </Accordion>
    ));
  };

  const getGroupDetail = (group) => {
    let groupDetail = null;
    switch (group) {
      case "object":
        groupDetail = getObjects();
        break;
      case "heatmap":
        break;
      default:
        console.log("No group defined");
    }

    return groupDetail;
  };
  return (
    <div id="Info_view" className={styles.Info_View}>
      {InfoGroups.map((group, index) => (
        <Accordion
          key={group.value}
          disableGutters
          slotProps={{ transition: { unmountOnExit: true } }}
        >
          <AccordionSummary>{group.label}</AccordionSummary>
          <AccordionDetails>{getGroupDetail(group.value)}</AccordionDetails>
        </Accordion>
      ))}
    </div>
  );
};

export default InfoView;
