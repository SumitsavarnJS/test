import {
  Box,
  Collapse,
  FormControlLabel,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Switch,
  Typography,
} from "@mui/material";

import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLess from "@mui/icons-material/ExpandLess";

import React from "react";

import styles from "./ObjectView.module.css";
import _ from "lodash";

import ContextMenu from "./ContextMenu";

export const Objects = [
  { label: "Cell", value: "cell", tooltip: "Cells" },
  { label: "Net", value: "net", tooltip: "Net" },
  { label: "Timing Path", value: "timingpath", tooltip: "Timing Path" },
  { label: "Macro", value: "macro", tooltip: "Macros" },
  { label: "Blockage", value: "blockage", tooltip: "Blockage" },
  { label: "Voltage Area", value: "voltageArea", tooltip: "Volatge Area" },
  { label: "RP", value: "rp", tooltip: "Relative Placement" },
];

const ObjectView = (props) => {
  const handleVisibility = (objectValue) => {
    const newConfig = {
      ...props.config,
    };
    newConfig.objects[objectValue].visible = !_.get(
      props.config,
      ["objects", objectValue, "visible"],
      true
    );
    props.handleControlPanel(newConfig);
  };

  const handleAllVisibility = (event) => {
    const newConfig = {
      ...props.config,
    };
    Object.entries(props.config.objects).forEach(([key, val]) => {
      newConfig.objects[key].visible = event.target.checked;
    });
    props.handleControlPanel(newConfig);
  };

  const handleObjectExpand = (objectValue) => {
    const newConfig = {
      ...props.config,
    };
    newConfig.objects[objectValue].expanded = !_.get(
      props.config,
      ["objects", objectValue, "expanded"],
      true
    );
    props.handleControlPanel(newConfig);
  };

  const getAllVisible = () => {
    let visibility = false;
    Object.entries(props.config.objects).forEach(([key, val]) => {
      if (val.visible) {
        visibility = true;
      }
    });
    return visibility;
  };

  return (
    <Box id="ObjectView" className={styles.ObjectView}>
      <Box className={styles.top_bar}>
        <Typography variant="body2">Objects</Typography>
        <FormControlLabel
          className={styles.top_right}
          label={<Typography variant="body2">Hide/View</Typography>}
          labelPlacement="start"
          control={
            <Switch
              size="small"
              edge={"end"}
              onChange={handleAllVisibility}
              checked={getAllVisible()}
            />
          }
        />
      </Box>

      <Box id="Selection_area" className={styles.Selection_Area}>
        <List>
          {Objects.map((object, index) => (
            <div id="Object_row" className={styles.Object_row}>
              <ListItem
                sx={{ height: "40px" }}
                key={object.value}
                secondaryAction={
                  <Switch
                    edge="end"
                    size="small"
                    onChange={() => handleVisibility(object.value)}
                    checked={_.get(
                      props.config,
                      ["objects", object.value, "visible"],
                      true
                    )}
                  />
                }
                disablePadding
              >
                <ListItemButton
                  sx={{ height: "100%" }}
                  onClick={() => handleObjectExpand(object.value)}
                >
                  <ListItemIcon>
                    {_.get(
                      props.config,
                      ["objects", object.value, "expanded"],
                      true
                    ) ? (
                      <ExpandLess />
                    ) : (
                      <ExpandMoreIcon />
                    )}
                  </ListItemIcon>
                  <ListItemText id={object.value} primary={object.label} />
                </ListItemButton>
              </ListItem>
              <Collapse
                in={_.get(
                  props.config,
                  ["objects", object.value, "expanded"],
                  true
                )}
              >
                {_.get(
                  props.config,
                  ["objects", object.value, "expanded"],
                  true
                ) ? (
                  <ContextMenu
                    object={object.value}
                    config={props.config}
                    handleControlPanel={props.handleControlPanel}
                  />
                ) : null}
              </Collapse>
            </div>
          ))}
        </List>
      </Box>
    </Box>
  );
};

export default ObjectView;
