import { Box } from "@mui/material";
import React from "react";

import styles from "./LayerView.module.css";

const LayerView = (props) => {
  return <Box id="LayerView" className={styles.LayerView}>Layer</Box>;
};

export default LayerView;
