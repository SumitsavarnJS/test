import React, { useEffect, useRef, useState } from "react";

import { TabulatorFull as Tabulator } from "tabulator-tables";

import styles from "./ContextMenu.module.css";
import {
  Button,
  ButtonGroup,
  FormControl,
  FormGroup,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import _ from "lodash";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

const defaultFormVal = {
  label: "",
  action: "addWidget",
  widgetId: "",
};

const ContextMenu = (props) => {
  const tableInst = useRef(null);
  let tableRef = null;

  const [formValue, setFormValue] = useState();

  const formatter = (cell, formatterParams, onRendered) => {
    return _.get(cell.getData(), "label", "");
  };

  useEffect(() => {
    tableInst.current = new Tabulator(tableRef, {
      // className: "table-sm table-striped table-bordered",
      layout: "fitDataStretch",
      columns: [
        {
          title: "Menu Label",
          field: "label",
          formatter: formatter,
          headerSort: false,
        },
      ],
      data: props.config.objects[props.object].contextMenu,
    });
    tableInst.current.on("rowClick");
  }, []);

  const handleValueChange = (event) => {
    setFormValue({ ...formValue, [event.target.name]: event.target.value });
  };

  return (
    <div id="Context_Menu" className={styles.Context_menu}>
      <div className={styles.Context_menu_text}>Context Menu</div>
      <div className={styles.context_menu_area}>
        <div id="analytics" style={{ width: "50%", height: "100%" }}>
          <div
            style={{ width: "100%", height: "100%" }}
            ref={(r) => {
              tableRef = r;
            }}
          ></div>
        </div>
        <div
          id="Context_menu_Form_Area"
          className={styles.Context_menu_Form_Area}
        >
          <FormGroup>
            <FormControl>
              <TextField
                variant="filled"
                label="Label"
                name="label"
                value={_.get(formValue, "label", "")}
                onChange={handleValueChange}
              />
            </FormControl>
            <FormControl variant="filled">
              <InputLabel>Action</InputLabel>
              <Select
                name="action"
                variant="filled"
                value={_.get(formValue, "action", "")}
                onChange={handleValueChange}
              >
                {[
                  {
                    title: "Add widget",
                    value: "addWidget",
                    key: "addWidget",
                  },
                ].map((item, index) => (
                  <MenuItem key={item.key} value={item.value}>
                    {item.title}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl>
              <TextField
                variant="filled"
                label="Widget Id"
                name="widgetId"
                value={_.get(formValue, "widgetId", "")}
                onChange={handleValueChange}
              />
            </FormControl>
          </FormGroup>
          <div
            id="Context_menu_Button_area"
            className={styles.Context_menu_Button_area}
          >
            <ButtonGroup size="small">
              <ThemedButton type={"info"} text="Apply" />
              <ThemedButton type={"info"} text="Add New" />
              <ThemedButton type={"alert"} text={"Delete"} />
              <ThemedButton type={"alert"} text={"Reset"} />
            </ButtonGroup>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ContextMenu;
