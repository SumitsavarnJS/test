import { Box } from "@mui/material";
import React from "react";

import styles from "./MapView.module.css";

const MapView = (props) => {
  return <Box id="MapView" className={styles.MapView}>Map</Box>;
};

export default MapView;
