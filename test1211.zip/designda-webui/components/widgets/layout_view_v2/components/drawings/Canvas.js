import React from "react";

import styles from "./Canvas.module.css"
const Canvas = (props) => {
  return <div id="Canvas" className={styles.Canvas}>
    
  </div>;
};

export default Canvas;
