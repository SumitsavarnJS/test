import React from "react";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { Box } from "@mui/material";
import { ClickAwayListener } from "@mui/base";

// utility imprts
import _ from "lodash";
import axios from "axios";

// data source table

import styles from "./Config.module.css";

import DataSource from "../../../pages/rptdashboard/data_source/DataSource";
import useConfigStore from "../../../store/useConfigStore";

class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      dataLocation: _.get(this.props.config, "dataLocation", ""),
      showPorts: _.get(this.props.config, "showPorts", false),
      showMacros: _.get(this.props.config, "showMacros", true),
      showBlockages: _.get(this.props.config, "showBlockages", false),
      showComponents: _.get(this.props.config, "showComponents", true),
      doSampling: _.get(this.props.config, "doSampling", true),
      activeZoom: _.get(this.props.config, "activeZoom", false),
      bucket: _.get(this.props.config, "bucket", ""),
      relativePlacement: _.get(this.props.config, "showRP", false),
      volatgeArea: _.get(this.props.config, "showVArea", false),
    };
  }

  dataLocationChanged = (newDataLocation, bucket) => {
    const data = {
      bucket: bucket,
      key: newDataLocation,
    };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_root_directory",
        data
      )
      .then((response) => {
        const rootDataLoc = _.get(response.data, "rootPath", "");

        this.setState({
          dataLocation: rootDataLoc,
          bucket: bucket,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  onSave = () => {
    const config = {};
    config["dataLocation"] = this.state.dataLocation;
    config["query"] = this.query;
    config["showPorts"] = this.state.showPorts;
    config["showMacros"] = this.state.showMacros;
    config["showBlockages"] = this.state.showBlockages;
    config["showComponents"] = this.state.showComponents;
    config["doSampling"] = this.state.doSampling;
    config["activeZoom"] = this.state.activeZoom;
    config["showVArea"] = this.state.volatgeArea;
    config["showRP"] = this.state.relativePlacement;
    config["bucket"] = this.state.bucket;
    config["heatmap"] = this.props.config.heatmap
      ? this.props.config.heatmap
      : {};

    // add title only if user has provided it
    if (this.state.title.length > 0) {
      config["title"] = this.state.title;
    }
    this.props.updateWidgetConfig(config, true);
  };

  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Select Data Source */}
        <div className={styles.inline}>
          <Button
            size="small"
            classes={{ root: styles.add_button }}
            onClick={() => this.setState({ showDataSource: true })}
          >
            Data Source
          </Button>
          {this.state.showDataSource ? (
            <ClickAwayListener
              onClickAway={() => {
                this.setState({ showDataSource: false });
              }}
            >
              <Box
                sx={{
                  zIndex: "5",
                  position: "absolute",
                  top: "0px",
                  left: "0px",
                  width: "100%",
                  height: "100%",
                  backgroundColor: "white",
                  padding: "5px",
                  boxShadow: "grey 5px 5px 5px",
                  overflow: "auto",
                }}
              >
                <DataSource
                  dataLocationChanged={this.dataLocationChanged}
                  dataLocation={this.state.dataLocation}
                  bucket={this.state.bucket}
                  isScenario={true}
                  close={() => {
                    this.setState({ showDataSource: false });
                  }}
                />
              </Box>
            </ClickAwayListener>
          ) : null}
          <Typography
            variant="body2"
            style={{ marginTop: "15px", marginLeft: "15px" }}
          >
            {this.state.dataLocation.split("#")[1]}
          </Typography>
        </div>

        <Button
          variant="contained"
          size="small"
          disabled={false}
          onClick={() => {
            this.onSave();
          }}
          classes={
            false
              ? { root: styles.save_button_disabled }
              : { root: styles.save_button }
          }
        >
          OK
        </Button>
        <Button
          variant="contained"
          size="small"
          onClick={this.props.updateWidgetConfig.bind(this, {}, false)}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>
      </div>
    );
  }
}

export default Config;
