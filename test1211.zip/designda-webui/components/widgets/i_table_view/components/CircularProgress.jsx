import React, { Component } from "react";
import CircularProgress from "@mui/material/CircularProgress";

export default class CircularIndeterminate extends Component {
// consturctor
  constructor(props) {
    super(props);
  }

  render(){
    if (this.props.isLoading){
        return (
            <div
              style={{
                margin: "auto",
                position: "absolute",
                top: "50%",
                left: "50%",
              }}
            >
              <CircularProgress/>
            </div> 
        );
    } 
    else{
        return(null)
    } 
  } 
}