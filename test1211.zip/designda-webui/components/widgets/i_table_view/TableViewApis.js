import React from "react";

import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { produce } from "immer";
import interactiveWidgetApi from "../../../common/api/interactiveWidgetApi";
import * as utils from "../../../common/utils/utils";

const getTableInput = (config,variables) => {
  const input = {
    chart_type: "table",
    raw_query: _.get(config, "query", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
    variables:variables ? variables:{}

  };
  // add columns if provided
  const columns = _.get(config, "columns", []);
  if (columns.length > 0) {
    input["columns"] = config.columns;
  }
  const scenario = utils.getScenarioFromDataLoc(
    _.get(config, "dataLocation", "")
  );

  const tempregex = /(__disable_cache = True)/i;
  if (tempregex.test(input.raw_query)) {
    input.cache_key = Date.now().toString()
  }
  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);

  const fetchData = await interactiveWidgetApi(
    useConfigStore.getState().configData.rest_server_url + "/cli/fetch_widget_data",
    input
  );

  if (fetchData) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } 

  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData);
  }
  else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData?.message || 'Something went wrong!';
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
    useGlobalStore.getState().setWidgetData(widgetId, {});

  }

};

const refreshInteractiveTableView = (widgetId, config, variables) => {
  fetchWidgetData(widgetId, getTableInput(config, variables));
};

export default refreshInteractiveTableView;
