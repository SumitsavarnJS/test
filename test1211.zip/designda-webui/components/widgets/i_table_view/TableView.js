// react imports
/* eslint-disable*/
import React from "react";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import { Menu, MenuItem, Typography, CircularProgress } from "@mui/material";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

// utility imprts
import _ from "lodash";
import axios from "axios";
import { produce } from "immer";
import Config from "./Config";
import ConfigChild from "./ConfigChild";

// css imports
import styles from "./TableView.module.css";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";
import * as utils from "../../../common/utils/utils";

import {
  addWidgetCommonFunction,
  showConfigUiState,
  showWidgetDataUiState,
  widgets,
} from "../../../pages/rptdashboard/addWidget/addWidget";
import { getContextMenuOptions } from "../generic_interactive_widget/iWidgetApi";
import { handleContextMenuAction } from "../generic_interactive_widget/contexMenu";

import refreshWidgetContent from "../../../pages/rptdashboard/wigetWrapper/widgetRefreshData";
import { showReportOnClick } from "../../../components/widgets/workflow_monitor_table/WorkflowMonitorTableApi";

var colors = [
  "c47541",
  "107896",
  "829356",
  "bca136",
  "c2571a",
  "e28743",
  "76b5c5",
  "873e23",
  "34eb4f",
  "34ebdf",
];
var i = 0;

class TableView extends React.Component {
  // consturctor
  constructor(props) {
    super(props);
    this.updateColResize = true;
    this.ref = React.createRef();
    // initialise new state for table loading on context menu option clicks
    this.state = {
      isTableViewLoading: false,
      isContextMenuOpen: false,
      contextMenuOptions: [],
      mousePosition: { x: 0, y: 0 },
      isPre_cts: false,
    };
  }
  // tabulator = null; //variable to hold your table

  // state = {
  //   // isLoading: false,
  //   isPre_cts: false,
  // };

  componentDidMount() {
    const iTableData = _.get(
      useGlobalStore?.getState()[this.props.id],
      "data",
      {}
    );
    const isGenContextMenuFuncAvailable =
      (iTableData.context_menu_func_src &&
        iTableData.context_menu_func_src.length > 0) ||
      false;
    //Commenting check pre cts api call
    // if (this.props.widgetProps.config.dataLocation) this.checkForPre_cts();
    this.tabulator = new Tabulator(this.ref.current, {
      layout: "fitColumns",
      // responsiveLayout: true,
      selectableRows: isGenContextMenuFuncAvailable, // rows will be selectable only for new-context-menu
      movableColumns: true,
      columns: useGlobalStore?.getState()[this.props.id]?.data?.data?.columns
        ? this.enable_filter()
        : [],
      // data={data.rows ? data.rows : []}
      placeholder: "No table data, please refresh!",
      autoResize: false,
      // row level context menu method to be available on for new-context-menu
      rowContextMenu: isGenContextMenuFuncAvailable
        ? this.getContextMenu
        : null,
      persistenceID: _.get(
        this.props.widgetProps.config,
        "tableId",
        this.props.id
      ),
      // // persistentLayout: false,
      persistence: {
        // sort: true, //persist column sorting
        // filter: true, //persist filter sorting
        // group: true, //persist row grouping
        // page: true, //persist page
        // columns: true, //persist columns
      },
      pagination: true, //enable pagination
      paginationMode: "remote", //enable remote pagination
      sortMode: "remote",
      filterMode: "remote",
      ajaxConfig: "POST",
      paginationSize: 10,
      paginationInitialPage: 1,
      // maxHeight: "90%",
      height: "100%",
      paginationSizeSelector: [20],
      // movableColumns: true, // by Enabling this, it breaks filtering mechanism
      paginationButtonCount: 5,
      // popupContainer:true,
      // if "Stage" column exists, sort it by Ascending order
      // no issue if column name does not exist
      initialSort: [{ column: "Stage", dir: "asc" }],
      ajaxURL:
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/cli/fetch_table_page",
      //set url for ajax request
      ajaxContentType: "json",
      ajaxParams: {
        raw_query: this.props.widgetProps.config.query,
        page: 10,
        size: 10,
        variables:
          useGlobalStore.getState()[this.props.rptType][this.props.reportKey]
            .variables,
        user: `${useConfigStore.getState().authLoginUser}`,
      },
      ajaxResponse: (url, params, responseData) => {
        const tabulatorLoreFormat = {
          data: responseData.data ? responseData.data : [],
          last_page: responseData.last_page ? responseData.last_page : 0,
        };
        return tabulatorLoreFormat;
      },
      columnDefaults: {
        headerFilter: true,
        headerFilterLiveFilter: false,
        headerFilterPlaceholder: "...",
        tooltip: true,
        headerTooltip: true,
        formatter: this.formatCells,
      },
      cellContext: (event, cell) => {
        localStorage.setItem("cell", JSON.stringify(cell._cell.value));
      },
      ajaxError: (error) => {
        console.log(error);
      },
    });
  }

  getContextMenu = async (event) => {
    const selectedRows = this.tabulator.getSelectedData();
    if (selectedRows.length > 0) {
      // console.log("get context menu", event, event.pageX);
      const mousePos = {
        x: event.pageX,
        y: event.pageY,
      };
      // console.log("mousePos", mousePos)
      this.setState({
        isContextMenuOpen: true,
        mousePosition: mousePos,
      });
      // setMousePosition(mousePos);
      const iTableData = _.get(
        useGlobalStore?.getState()[this.props.id],
        "data",
        {}
      );
      // logic of gen_context_menu
      const contextMenuArr = await this.getContextMenuFromApi(
        iTableData,
        selectedRows
      );
      // console.log("getContextMenu | contextMenuArr", contextMenuArr);
      this.setState({
        contextMenuOptions: contextMenuArr,
      });
    } else {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "No rows have been selected. Click on a row to select",
      });
    }
  };

  shouldComponentUpdate = (nextProps, nextState) => {
    let themeFromReports = "light";
    if (nextProps.rptType === "allReports") {
      const reportInfo = _.cloneDeep(
        useGlobalStore.getState().allReports[nextProps.reportKey]
      );
      themeFromReports = reportInfo.theme;
    }
    if (themeFromReports != nextProps.theme) {
      return true;
    } else if (
      _.get(nextProps.uiState, "isToastOpen", true) !=
        _.get(this.props.uiState, "isToastOpen", true) ||
      _.get(nextProps.uiState, "cirlularLoading", true) !=
        _.get(this.props.uiState, "cirlularLoading", true) ||
      _.get(nextProps.uiState, "isLoading", true) !=
        _.get(this.props.uiState, "isLoading", true)
    ) {
      return false;
    } else if (
      _.get(nextProps, "uiState", true) != _.get(this.props, "uiState", true)
    ) {
      // this.updateColResize = true;
      return true;
    }
    this.updateColResize = true;
    return false;
  };

  showToast = (toast) => {
    const uiState = produce(
      useGlobalStore.getState()[this.props.id].uiState,
      (uiStateDraft) => {
        uiStateDraft.isToastOpen = true;
        uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
        uiStateDraft.toastMessage = _.get(toast, "message", "");
      }
    );
    useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  setLoading = (loadingProps) => {
    // change state when any context menu option is clicked
    this.setState({ isTableViewLoading: loadingProps.cirlularLoading });
    // below code is for loading widget that is getting added via addWidgets
    const uiState = produce(
      useGlobalStore.getState()[this.props.id].uiState,
      (uiStateDraft) => {
        uiStateDraft.cirlularLoading = _.get(
          loadingProps,
          "cirlularLoading",
          false
        );
      }
    );
    useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
  };

  addWidgets = (props) => {
    for (let i = 0; i < props.widgets.length; i++) {
      const widgetsSettings = produce(props.widgets[i], (settingsDraft) => {
        delete settingsDraft.currentReportName;
        delete settingsDraft.data;
      });

      const data = _.get(props.widgets[i], "data", {});

      addWidgetCommonFunction(
        this.props.rptType,
        this.props.reportKey,
        widgetsSettings,
        data,
        showWidgetDataUiState,
        this.props.index
      );
    }
  };

  checkForPre_cts = () => {
    const config = this.props.widgetProps.config;
    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
    };
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/check_report_is_pre_cts",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const pre_cts = _.get(response, "pre_cts", false);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        this.setState({ isPre_cts: pre_cts });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch meta data",
        });
      });
  };

  addClockPathDetailsWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    var randomColor = colors[i++];
    if (i == 10) i = 0;
    // Math.floor(Math.random()*16777215).toString(16);
    // console.log(randomColor);
    const row = rowObj._cell.row;
    const rowHasScenario = row.data.scenario && row.data.scenario.length > 0;
    const rowHasTimingPath =  row.data.timing_path && row.data.timing_path.length > 0;
    const config = this.props.widgetProps.config;
    const timing_path = rowHasTimingPath ? row.data.timing_path : row.data?.__object?.split("/").slice(1).join("/");
    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }
    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found / meta data not found',
      });
      return;
    }
    // get_clock_path_meta_data
    const request = {
      timing_path: timing_path,
      bucket: config.bucket,
      key: config.dataLocation,
      hold: hold,
      scenario: rowHasScenario ? row.data.scenario : row.data.__object
        ? row.data.__object.split("/")[0]
        : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
      col: [
        "start_point_name",
        "start_point_object_type",
        "end_point_name",
        "end_point_object_type",
        "timing_path",
        "start_point_clock",
        "end_point_clock",
      ],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_clock_path_meta_data",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const stpt = _.get(response, "start_point_name", "");
        const stpt_type = _.get(response, "start_point_object_type", "");
        const ept = _.get(response, "end_point_name", "");
        const ept_type = _.get(response, "end_point_object_type", "");
        const stpt_clk = _.get(response, "start_point_clock", "");
        const ept_clk = _.get(response, "end_point_clock", "");
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        }
        if (stpt_type[0] == "in" && ept_type[0] == "out") {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "info",
            message: "Both Launch clock and Capture clock paths Does not exist",
          });
          this.setLoading({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            cirlularLoading: false,
          });
        } else {
          this.addLaunchClockDetailsWidget(
            e,
            rowObj,
            timing_path,
            stpt[0],
            stpt_type[0],
            ept[0],
            ept_type[0],
            stpt_clk[0],
            ept_clk[0],
            randomColor
          );
          this.addCaptureClockDetailsWidget(
            e,
            rowObj,
            timing_path,
            stpt[0],
            stpt_type[0],
            ept[0],
            ept_type[0],
            stpt_clk[0],
            ept_clk[0],
            randomColor
          );
        }
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch meta data for clock Details",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addLaunchClockDetailsWidget = (
    e,
    rowObj,
    timing_path,
    stpt,
    stpt_type,
    ept,
    ept_type,
    stpt_clk,
    ept_clk,
    tColor
  ) => {
    // this.setState({ isLoading: true });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;
    const rowHasScenario = row.data.scenario && row.data.scenario.length > 0;

    if (row == null) return;

    let _stpt = stpt_type != "in" ? stpt : "";
    let _ept = ept_type != "out" ? ept : "";

    if (_stpt == "") {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Launch clock path Does not exist",
      });
      // this.setState({ isLoading: false });
      return;
    }

    const request = {
      timing_path: timing_path,
      start_point: _stpt,
      end_point: _ept,
      start_point_clock: stpt_clk,
      end_point_clock: ept_clk,
      bucket: config.bucket,
      key: config.dataLocation,
      ttype: row.data.__ttype ? row.data.__ttype : "max",
      scenario: rowHasScenario ? row.data.scenario : row.data.__object
        ? row.data.__object.split("/")[0]
        : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_launch_clock_details",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const colors = _.get(data, "colors", {});
        const dataLocation = _.get(data, "dataLocation", "");
        const bucket = _.get(data, "bucket", "");
        const cache_key = _.get(response, "cache_key", "");
        const scenario = _.get(data, "scenario", "");
        const column_list = _.get(data, "column_list", []);
        const version = _.get(response, "version", "1");
        const v1_default_columns = [
          "object_level",
          "object_name",
          "object_type",
          "cell_delay_launch",
          "net_delay_launch",
          "transition_launch",
        ];
        const v2_default_columns = [
          "s_no",
          "obj_name",
          "obj_ref_name",
          "delay",
          "obj_type",
        ];

        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Timing Path Details",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Launch Clock Details for ${_stpt}`,
                  title_color: "#" + tColor,
                  dataLocation: dataLocation,
                  bucket: bucket,
                  cache_key: cache_key,
                  colors: colors,
                  scenario: scenario,
                  column_list: column_list,
                  // persistence: {
                  //   columns: true,
                  // },
                  columns:
                    version === "2" ? v2_default_columns : v1_default_columns,
                },
                data: data,
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Launch clock Details",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // Function to add Timing_Path(renamed to Data_path) Details Widget
  addDataPathDetailsWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;
    const rowHasScenario = row.data.scenario && row.data.scenario.length > 0;
    const rowHasTimingPath =  row.data.timing_path && row.data.timing_path.length > 0;

    if (row == null) return;
    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }

    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found / meta data not found',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      timing_path: rowHasTimingPath ? row.data.timing_path : row.data.__object.split("/").slice(1).join("/"),
      bucket: config.bucket,
      key: config.dataLocation,
      hold: hold,
      scenario: rowHasScenario ? row.data.scenario : row.data.__object
        ? row.data.__object.split("/")[0]
        : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_data_path_details",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const colors = _.get(response, "colors", {});
        const data = _.get(response, "data", {});
        const cache_key = _.get(response, "cache_key", "");
        const dataLocation = _.get(response, "dataLocation", "");
        const bucket = _.get(response, "bucket", "");
        const column_list = _.get(response, "column_list", []);
        const version = _.get(response, "version", "1");
        const v1_default_columns = [
          "point_id",
          "point_type",
          "point_name",
          "cell_ref_name",
          "fanout",
          "incr_delay",
          "path_delay",
        ];
        const v2_default_columns = [
          "s_no",
          "obj_name",
          "obj_ref_name",
          "delay",
          "obj_type",
        ];

        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Timing Path Details",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Data Path Details for ${
                    row.data.__object
                      ? row.data.__object.split("/").slice(1).join("/")
                      : row.data.timing_path
                  }`,
                  dataLocation: dataLocation,
                  bucket: bucket,
                  cache_key: cache_key,
                  colors: colors,
                  column_list: column_list,
                  columns:
                    version === "2" ? v2_default_columns : v1_default_columns,
                },
                data: data,
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Data Path Details",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addCaptureClockDetailsWidget = (
    e,
    rowObj,
    timing_path,
    stpt,
    stpt_type,
    ept,
    ept_type,
    stpt_clk,
    ept_clk,
    tColor
  ) => {
    // this.setState({ isLoading: true });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;
    const rowHasScenario = row.data.scenario && row.data.scenario.length > 0;

    if (row == null) return;

    let _stpt = stpt_type != "in" ? stpt : "";
    let _ept = ept_type != "out" ? ept : "";

    if (_ept == "") {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Capture clock path Does not exist",
      });
      // this.setState({ isLoading: false });
      return;
    }

    const request = {
      timing_path: timing_path,
      start_point: _stpt,
      end_point: _ept,
      start_point_clock: stpt_clk,
      end_point_clock: ept_clk,
      bucket: config.bucket,
      key: config.dataLocation,
      ttype: row.data.__ttype ? row.data.__ttype : "max",
      scenario: rowHasScenario ? row.data.scenario : row.data.__object
        ? row.data.__object.split("/")[0]
        : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_capture_clock_details",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const colors = _.get(data, "colors", {});
        const dataLocation = _.get(data, "dataLocation", "");
        const bucket = _.get(data, "bucket", "");
        const cache_key = _.get(response, "cache_key", "");
        const scenario = _.get(data, "scenario", "");
        const column_list = _.get(data, "column_list", []);
        const version = _.get(response, "version", "1");
        const v1_default_columns = [
          "object_level",
          "object_name",
          "object_type",
          "cell_delay_capture",
          "net_delay_capture",
          "transition_capture",
        ];
        const v2_default_columns = [
          "s_no",
          "obj_name",
          "obj_ref_name",
          "delay",
          "obj_type",
        ];

        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Timing Path Details",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Capture clock Details for ${_ept}`,
                  title_color: "#" + tColor,
                  dataLocation: dataLocation,
                  bucket: bucket,
                  cache_key: cache_key,
                  colors: colors,
                  scenario: scenario,
                  column_list: column_list,
                  columns:
                    version === "2" ? v2_default_columns : v1_default_columns,
                },
                data: data,
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Capture Clock Details",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // Function to add Timing Path Summary Widget
  addTimingPathSummaryWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const rowHasScenario = row.data.scenario && row.data.scenario.length > 0;
    const rowHasTimingPath =  row.data.timing_path && row.data.timing_path.length > 0;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }

    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found / meta data not found',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }
    // temporary fix TODO: why key does not have scenario
    let keyForRequest = config.dataLocation;
    const scenarioForRequest = rowHasScenario
      ? row.data.scenario
      : row.data.__object
      ? row.data.__object.split("/")[0]
      : _.get(config, "dataLocation", "").split("/").slice(-1).toString();
    // if key does not have scenario -> add scenario at the end
    if (!keyForRequest.endsWith(scenarioForRequest)) {
      keyForRequest = `${keyForRequest}/${scenarioForRequest}`;
    }

    const request = {
      timing_path: rowHasTimingPath ? row.data.timing_path : row.data.__object.split("/").slice(1).join("/"),
      bucket: config.bucket,
      key: keyForRequest,
      hold: hold,
      scenario: scenarioForRequest,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_timing_path_summary",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Timing Path Summary",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Timing Path Summary for ${
                    row.data.__object
                      ? row.data.__object.split("/").slice(1).join("/")
                      : row.data.timing_path
                  }`,
                },
                data: data,
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Timing Summary Data",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // Function to add Timing Path Treemap Widget
  addTimingPathTreemapWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }

    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found / meta data not found',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      timing_path: row.data.__object
        ? row.data.__object.split("/").slice(1).join("/")
        : row.data.timing_path,
      bucket: config.bucket,
      key: config.dataLocation,
      hold: hold,
      scenario: row.data.__object
        ? row.data.__object.split("/")[0]
        : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_timing_path_treemap",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const data2 = _.get(response, "data2", {});
        const data3 = _.get(response, "data3", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        data3["series"][0]["data"].push(data2["series"][0]["data"][0]);
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Treemap",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Treemap for ${
                    row.data.__object
                      ? row.data.__object.split("/").slice(1).join("/")
                      : row.data.timing_path
                  }`,
                },
                data: data3,
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Treemap Data",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // Function to add Multi Stage Timing Table
  showMultiStageTimingTable = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }

    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found / meta data not found',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }
    let keyForRequest = config.dataLocation;
    const scenarioForRequest = row.data.__object
      ? row.data.__object.split("/")[0]
      : _.get(config, "dataLocation", "").split("/").slice(-1).toString();
    // if key does not have scenario -> add scenario at the end
    if (!keyForRequest.endsWith(scenarioForRequest)) {
      keyForRequest = `${keyForRequest}/${scenarioForRequest}`;
    }
    const request = {
      timing_path: row.data.__object
        ? row.data.__object.split("/").slice(1).join("/")
        : row.data.timing_path,
      bucket: config.bucket,
      key: keyForRequest,
      hold: hold,
      scenario: scenarioForRequest,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_multistage_timing_table",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", {});
        const dataLocation = _.get(response, "dataLocation", "");
        const data = _.get(response, "file", {});
        const bucket = _.get(response, "bucket", {});
        // const query = _.get(response, "query", "df = df.sort_values(by='Stage', ascending=True)");
        const col = _.get(response, "columns", []);
        const columnsList = _.get(response, "columnsList", []);
        const rows = _.get(response, "rows", []);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          const yCoord = this.props.widgetProps.y;
          // add TableView widget below
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName,
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Multi Stage Timing Path for ${
                    row.data.__object
                      ? row.data.__object.split("/").slice(1).join("/")
                      : row.data.timing_path
                  }`,
                  dataLocation: dataLocation,
                  data: data,
                  bucket: bucket,
                  query: "df = df.compute()", //query,
                  columns: columnsList,
                  cache_key: cache_key,
                },
                data: { rows: rows, columns: col },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Multi Stage Timing Path Data",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // Function to add Multi Stage Timing Graph
  showMultiStageTimingGraph = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }

    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: '"timing_path" column not found / meta data not found',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }
    let keyForRequest = config.dataLocation;
    const scenarioForRequest = row.data.__object
      ? row.data.__object.split("/")[0]
      : _.get(config, "dataLocation", "").split("/").slice(-1).toString();
    // if key does not have scenario -> add scenario at the end
    if (!keyForRequest.endsWith(scenarioForRequest)) {
      keyForRequest = `${keyForRequest}/${scenarioForRequest}`;
    }
    const request = {
      timing_path: row.data.__object
        ? row.data.__object.split("/").slice(1).join("/")
        : row.data.timing_path,
      bucket: config.bucket,
      // key: config.dataLocation,
      key: keyForRequest,
      hold: hold,
      scenario: scenarioForRequest,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_multistage_timing_graph",
        request
      )
      .then((response) => {
        response = response?.data;
        const graphData = _.get(response, "graph", {});
        const requestStatus = _.get(response, "status", false);
        const minSlack = _.get(response, "minSlack", 0);
        const maxSlack = _.get(response, "maxSlack", 100);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          const yCoord = this.props.widgetProps.y;
          // add Graph Chart View widget below
          this.addWidgets({
            widgets: [
              {
                name: "Graph Chart",
                reportName: this.props.currentReportName,
                width: 20,
                height: 12,
                y: yCoord + 1,
                // sending required data in 'data' so that its reflected in STORE
                data: {
                  data: { ...graphData, minSlack, maxSlack },
                  payload: {
                    request,
                    isPre_cts: this.state.isPre_cts,
                    row,
                    allProps: this.props,
                    yCoord: yCoord + 1,
                  },
                },
                config: {
                  title: `Multi Stage Timing Graph for ${
                    row.data.__object
                      ? row.data.__object.split("/").slice(1).join("/")
                      : row.data.timing_path
                  }`,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Multi Stage Timing Graph Data",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // generic context menu
  getContextMenuFromApi = async (iTableData, selectedRows) => {
    let contextMenuArr = [];
    // console.log("ref", this.tabulator.getSelectedData());
    const payload = {
      user: useConfigStore.getState().authLoginUser,
      chart_type: "table",
      context_menu_func_src: iTableData.context_menu_func_src,
      context_menu_vars: iTableData.context_menu_vars,
      context_menu_args: { rows: selectedRows },
    };
    const contextMenuOptions = await getContextMenuOptions(payload);
    // console.log("\n contextMenuOptions", contextMenuOptions);
    if (
      contextMenuOptions?.context_menu &&
      contextMenuOptions.context_menu.length > 0
    ) {
      contextMenuArr = contextMenuOptions.context_menu;
    }
    // console.log("\n")
    return contextMenuArr;
  };

  // Function to return context menu for rows
  getRowContextMenu = (data) => {
    // follow older logic
    let contextMenu = [];
    if (data.__obtype === "path_category/path_group/cause") {
      contextMenu = this.getPathGroupContextMenu();
    } else if (data.__obtype === "timing_path") {
      contextMenu = this.getTimingPathContextMenu(data);
    }
    // remove condition for "flow_timing_path" from here
    else if (data.__obtype === "tp_trend") {
      contextMenu = this.getFlowTrendRowContextMenu();
      // } else if ((data.__obtype === "tp_trend")||(
      //   [
      //     "das_flow_trend_report_data.ldb",
      //     "das_flow_trend_report_min_data.ldb",
      //   ].includes(_.get(this.props.widgetProps.config, "data", ""))
      // )) {
      //   contextMenu =  this.getFlowTrendFullRowContextMenu();
    }
    // show flow context menu for the following conditions
    else if (data.__obtype === "flow_timing_path" && data.__ttype === "max") {
      contextMenu = this.getFlowTrendRowContextMenu();
    } else if (
      _.get(this.props.widgetProps.config, "data", "") ===
      "das_data_task_congestion_data.ldb"
    ) {
      contextMenu = this.congestPatchContextMenu();
    } else if (
      data.__obtype === "net" &&
      data.__object.split("/")[0] === "__dummy"
    ) {
      contextMenu = this.getDummyNetContextMenu();
    } else if (data.__obtype === "net") {
      contextMenu = this.getNetContextMenu();
    } else if (data.__obtype === "cell") {
      contextMenu = this.getDesignCellContextMenu();
    } else if (data.__obtype === "instance_trend") {
      contextMenu = this.getInstanceTrendContextMenu();
    } else if (
      data.__obtype === "instance" &&
      !this.props.widgetProps.config.dataLocation.includes("flow_reports")
    ) {
      contextMenu = this.getInstanceContextMenu();
    } else if (data.__obtype === "clock/cell") {
      contextMenu = this.getClockCellContextMenu();
    } else if (data.__obtype === "clock/net") {
      contextMenu = this.getClockNetContextMenu();
    } else if (
      data.__obtype === "clock/port" ||
      data.__obtype === "clock/in" ||
      data.__obtype === "clock/out"
    ) {
      contextMenu = this.getPortContextMenu();
    } else {
      contextMenu = this.defaultConextMenu();
    }
    let customMenu = null;
    if (data.hasOwnProperty("__contextMenu")) {
      customMenu = this.addCustomMenu(data.__contextMenu, data);
      contextMenu = contextMenu.concat(customMenu);
    }
    return contextMenu;
  };

  //function to add widget from custom context menu
  addCustomMenu = (__contextMenu, rowData) => {
    let contextMenu = [];
    for (let i = 0; i < __contextMenu.length; i++) {
      if (
        __contextMenu[i] &&
        __contextMenu[i][0] &&
        __contextMenu[i][0].hasOwnProperty("label") &&
        __contextMenu[i][0].hasOwnProperty("label") &&
        __contextMenu[i][0].hasOwnProperty("action") &&
        __contextMenu[i][0].action == "addWidget" &&
        __contextMenu[i][0].hasOwnProperty("args") &&
        __contextMenu[i][0].args.hasOwnProperty("wid")
      ) {
        contextMenu.push({
          label: `<i class='fas fa-user'></i> ${__contextMenu[i][0].label}`,
          action: (e, row) => {
            this.addCustomWidget(__contextMenu[i][0].args, rowData);
          },
        });
      }
    }
    return contextMenu;
  };

  //create query which will be prepended
  //this is creating a string which will declare variables in the query
  createPreQuery = (rowData) => {
    let preQuery = "";
    for (const [key, value] of Object.entries(rowData)) {
      if (
        key.startsWith("__") &&
        !["__contextMenu", "__obtype", "__object", "__ttype"].includes(key) &&
        !key.includes("__META__")
      ) {
        preQuery = preQuery + `${key} = ${value}\n`;
      }
    }
    return preQuery;
  };

  //add widget from custom menu
  addCustomWidget = async (args, rowData) => {
    //new argument copy for config of the widget

    let argsCopy = _.cloneDeep(args);
    const wid = args.wid;
    delete argsCopy.wid;

    //handling scenario
    let scenario = null;
    if (args.hasOwnProperty("scenario")) {
      scenario = args.scenario;

      //delete sceanrio key as it is not needed in config
      delete argsCopy.scenario;
    }

    //root level data location from aprent widget and not the report
    let dataLocation = utils.getRootDirectory(
      this.props.widgetProps.config.dataLocation
    );

    //change data location if given in argruments
    if (args.hasOwnProperty("dataLocation")) {
      dataLocation = args.dataLocation;
      delete argsCopy.dataLocation;
    }

    let bucket = this.props.widgetProps.config.bucket;
    if (args.hasOwnProperty("bucket")) {
      bucket = args.bucket;
      delete argsCopy.bucket;
    }

    // add handle query
    const preQuery = this.createPreQuery(rowData);

    // all other arguments left after wid, sceanrio, dataLocation , bucktes are handled
    // this copy of arguments will be merged with config from widget library
    let configCopy = argsCopy;

    //get widget Template from widget Library
    const wTemplate = await utils.getWidgetFromLib(wid);

    if (Object.keys(wTemplate).length == 0) {
      const uiState = {
        isLoading: false,
        showConfig: false,
        isToastOpen: true,
        toastSeverity: "error",
        toastMessage:
          "Invalid widget id. Please configure context menu with valid 'wid' from widget library",
        cirlularLoading: false,
      };
      useGlobalStore.getState().setWidgetUiState(this.props.id, uiState);
      return;
    }

    //recuntruct the widget settings and config from template
    const settings = utils.getWidgetSettings(wTemplate.widget_name, wTemplate);

    //if scenario is given then add to data location
    if (scenario) {
      dataLocation = dataLocation + "/" + scenario;
    }

    let newConfig = _.cloneDeep(settings.config);

    // merging new config with arguments
    newConfig = { ...newConfig, ...configCopy };

    // over write data location and bucket with values that was handled earlier
    newConfig.dataLocation = dataLocation;
    newConfig.bucket = bucket;

    //handle query if exists
    if (newConfig.hasOwnProperty("query")) {
      newConfig.query = preQuery + newConfig.query;
    }

    //prepare final widget settings
    settings.config = newConfig;
    settings.h = widgets[wTemplate.widget_name].height;
    settings.w = widgets[wTemplate.widget_name].width;
    settings.y = this.props.widgetProps.y + 1;
    settings.x = this.props.widgetProps.x;
    settings.name = wTemplate.widget_name;
    settings.metaData = {
      description: _.get(wTemplate, "description", ""),
      tags: _.get(wTemplate, "tags", ""),
    };

    // add the new widget
    const newIdList = addWidgetCommonFunction(
      this.props.rptType,
      this.props.reportKey,
      settings,
      {},
      showConfigUiState,
      this.props.index
    );

    // auto reload the new widget
    refreshWidgetContent({
      widgetId: newIdList[0],
      widgetName: wTemplate.widget_name,
      config: settings.config,
      reportKey: this.props.reportKey,
      rptType: this.props.rptType,
      variables:
        useGlobalStore.getState()[this.props.rptType][this.props.reportKey]
          .variables,
    });

    // inform the user that widget is added
    this.showToast({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      severity: "info",
      message: "Widget added below",
    });
  };

  defaultConextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getDesignCellContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show Timing Paths",
        action: (e, row) => {
          this.addCellTimingPaths(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addCellLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getInstanceContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show details",
        action: (e, row) => {
          this.addInstanceDetails(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addInstanceLayout(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getClockCellContextMenu = () => {
    return [
      // {
      //   label: "<i class='fas fa-user'></i> Show Timing Paths",
      //   action: (e, row) => {
      //     this.props.addCellTimingPaths(e, row);
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addCellLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getClockNetContextMenu = () => {
    return [
      // {
      //   label: "<i class='fas fa-user'></i> Show Timing Paths",
      //   action: (e, row) => {
      //     this.props.addNetTimingPaths(e, row);
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addNetLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getPortContextMenu = () => {
    return [
      // {
      //   label: "<i class='fas fa-user'></i> Show Timing Paths",
      //   action: (e, row) => {
      //     this.props.addNetTimingPaths(e, row);
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addPortLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getInstanceTrendContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show Compare Report",
        action: (e, row) => {
          this.addInstanceCompareReport(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getPathGroupContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show Timing Paths",
        action: (e, row) => {
          this.addPathGroupTimingPaths(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  congestPatchContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addCongestionPatchLayout(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  // refer Jira- 5980
  getDummyNetContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addDummyNetLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getNetContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addNetLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show Timing Paths",
        action: (e, row) => {
          this.addNetTimingPaths(e, row);
        },
      },
      // {
      //   label: "<i class='fas fa-user'></i> Net summary",
      //   action: (e, row) => {
      //     this.copyToClipboard(); // yet to be implemented
      //   },
      // },
      // {
      //   label: "<i class='fas fa-user'></i> Scalability Metrics",
      //   action: (e, row) => {
      //     this.copyToClipboard(); // yet to be implemented
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };

  getTimingPathContextMenu = (data) => {
    let ret = [
      {
        label: "<i class='fas fa-user'></i> Show Clock Path Details",
        action: (e, row) => {
          this.addClockPathDetailsWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show Data Path Details",
        action: (e, row) => {
          this.addDataPathDetailsWidget(e, row); //It was renamed from addTimingPathDetailsWidget
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show Timing Path Summary",
        action: (e, row) => {
          this.addTimingPathSummaryWidget(e, row);
        },
      },
      // {
      //   label: "<i class='fas fa-user'></i> Show Timing Path Treemap",
      //   action: (e, row) => {
      //     this.addTimingPathTreemapWidget(e, row);
      //   },
      // },
      {
        label: "<i class='fas fa-user'></i> Show in Layout",
        action: (e, row) => {
          this.addTimingLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in Layout with Heatmap",
        action: (e, row) => {
          this.addHeatmapLayoutWidget(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in icc2/fc",
        action: (e, row) => {
          this.showInIcc2(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];

    // if ttype is 'max', show the following option
    if (data && data.__ttype && data.__ttype === "max") {
      // insert at end of array since the isPre_cts condition below
      // removes item at 0 index
      ret.push(
        {
          label: "<i class='fas fa-user'></i> Show Multistage Timing Table",
          action: (e, row) => {
            this.showMultiStageTimingTable(e, row);
          },
        },
        // adding multi-stage-graph menu option
        {
          label: "<i class='fas fa-user'></i> Show Multistage Timing Graph",
          action: (e, row) => {
            this.showMultiStageTimingGraph(e, row);
          },
        }
      );
    }
    if (this.state.isPre_cts === true) return ret.slice(1);
    else return ret;
  };

  addHeatmapLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;
    const rowHasScenario = row.data.scenario && row.data.scenario.length > 0;

    if (row == null) return;

    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: 'Columns should have "timing_path" to fetch Layout View',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${_.get(config, "title", "Timingpath ")} ${
                    _.get(row.data, "timing_path", "")
                      ? _.get(row.data, "timing_path", "")
                      : row.data.__object
                  }}`,
                  bucket: _.get(config, "bucket", ""),
                  timingpath: _.get(row.data, "timing_path", "")
                    ? _.get(row.data, "timing_path", "")
                    : row.data.__object.split("/").slice(1).join("/"),
                  dataLocation: _.get(config, "dataLocation", ""),
                  scenario: rowHasScenario ? row.data.scenario : row.data.__object
                    ? row.data.__object.split("/")[0]
                    : _.get(config, "dataLocation", "")
                        .split("/")
                        .slice(-1)
                        .toString(),
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addCongestionPatchLayout = (e, rowObj) => {
    // close context menu
    // this.handleMenuClose();
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });

    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!("patch_id" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: 'Columns should have "patch_id" to fetch Layout View',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation + "/scenario",
      components: ["floorplan", "macros"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  title: `{${_.get(
                    config,
                    "title",
                    "Congestion patch "
                  )} ${_.get(row.data, "congestion_patch", "")}}`,
                  bucket: _.get(config, "bucket", ""),
                  dataLocation: _.get(config, "dataLocation", "") + "/scenario",
                  patchId: row.data.patch_id,
                  congestionPatchContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addDummyNetLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.__obtype == "net")) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Missing net value to fetch Layout View",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{
                  ${_.get(config, "title", "Net_name ")}  ,  
                  Net List:"${
                    row.data.__object
                      ? row.data.__object.split("/").slice(1).join("/")
                      : row.data.net_list
                  }",
                  Nets Type:"${row.data.nets_type ? row.data.nets_type : ""}"
                  }`,
                  bucket: _.get(config, "bucket", ""),
                  net_value: row.data.__object.split("/").slice(1).join("/"),
                  ttype: row.data.__ttype,
                  dataLocation: _.get(config, "dataLocation", ""),
                  scenario: row.data.__object.split("/")[0],
                  dummyNetContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addNetLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.__obtype == "net") && !(row.data.__obtype == "clock/net")) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Missing net value to fetch Layout View",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${_.get(config, "title", "Net_name ")} ${
                    row.data.__object
                  }}`,
                  bucket: _.get(config, "bucket", ""),
                  net_value: row.data.__object.split("/").slice(1).join("/"),
                  ttype: row.data.__ttype,
                  dataLocation: _.get(config, "dataLocation", ""),
                  scenario: row.data.__object.split("/")[0],
                  netContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addCellLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (
      !(row.data.__obtype == "cell") &&
      !(row.data.__obtype == "clock/cell")
    ) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Missing cell value to fetch Layout View",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${_.get(config, "title", "Cell Name")} ${
                    row.data.__object
                  }}`,
                  bucket: _.get(config, "bucket", ""),
                  cell_name: row.data.__object.split("/").slice(1).join("/"),
                  ttype: row.data.__ttype,
                  scenario: row.data.__object.split("/")[0],
                  dataLocation: _.get(config, "dataLocation", ""),
                  cellContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.error(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addPortLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (
      !(
        row.data.__obtype === "clock/port" ||
        row.data.__obtype === "port" ||
        row.data.__obtype === "clock/in" ||
        row.data.__obtype === "clock/out"
      ) ||
      row.data.__obtype === null
    ) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "PORT meta-data not found",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
          this.setLoading({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            cirlularLoading: false,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${row.data.__object}}`,
                  bucket: _.get(config, "bucket", ""),
                  port: row.data.__object.split("/").slice(1).join("/"),
                  ttype: row.data.__ttype,
                  scenario: row.data.__object.split("/")[0],
                  dataLocation: _.get(config, "dataLocation", ""),
                  portContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.error(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addInstanceCompareReport = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.__obtype == "instance_trend") || row.data.__obtype == null) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Meta-data not found in the table data",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    try {
      var request = {
        bucket: config.bucket,
        key: config.dataLocation,
        instance: row.data.__object.split("/").slice(1).join("/"),
        ttype: row.data.__ttype ? row.data.__ttype : "max",
        scenario: row.data.__object.split("/")[0],
      };
    } catch {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Please add meta data in query",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_instance_compare_report",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", {});
        const dataLocation = _.get(response, "dataLocation", "");
        //   .split("/")
        //   .slice(0, -1);
        // dataLocationArr.push(row.data.__object.split("/")[0]);
        // const dataLocation = dataLocationArr.join("/");
        const data = _.get(response, "file", {});
        const bucket = _.get(response, "bucket", {});
        // const query = _.get(response, "query", "");
        const col = _.get(response, "columns", []);
        const columnsList = _.get(response, "columnsList", []);
        const rows = _.get(response, "rows", []);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `${row.data.__object.split("/").slice(1).join("/")} ${
                    row.data.__ttype
                  } data`,
                  dataLocation: dataLocation,
                  data: data,
                  bucket: bucket,
                  query: "df = df.compute()", //query,
                  columns: columnsList,
                  cache_key: cache_key,
                },
                data: { rows: rows, columns: col },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        console.error(error);
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Report",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addInstanceDetails = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.__obtype == "instance") || row.data.__obtype == null) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Instance meta-data not found in the table data",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    try {
      var request = {
        bucket: config.bucket,
        key: config.dataLocation,
        instance: row.data.__object.split("/").slice(1).join("/"),
        ttype: row.data.__ttype ? row.data.__ttype : "max",
        scenario: row.data.__object.split("/")[0],
      };
    } catch {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Please add meta data in query",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_instance_details",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", "");
        const dataLocation = _.get(response, "dataLocation", "");
        const data = _.get(response, "file", {});
        const bucket = _.get(response, "bucket", {});
        const title = _.get(response, "title", "");
        const col = _.get(response, "columns", []);
        const columnsList = _.get(response, "columnsList", []);
        const rows = _.get(response, "rows", []);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `${title} details: ${row.data.__object
                    .split("/")
                    .slice(1)
                    .join("/")} `,
                  dataLocation: dataLocation,
                  data: data,
                  bucket: bucket,
                  query: "df = df.compute()", //query,
                  columns: columnsList,
                  cache_key: cache_key,
                },
                data: { rows: rows, columns: col },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        console.error(error);
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Report",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addInstanceLayout = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;
    const object = row.data.__object.split("/").slice(2).join("/");

    if (row == null) return;

    if (!(row.data.__obtype == "instance")) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Missing instance value to fetch Layout View",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    if (object == "") {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message:
          "Please select other than 'TOP' instance value to fetch Layout View",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${_.get(config, "title", "parent_inst")} ${
                    row.data.__object
                  }}`,
                  bucket: _.get(config, "bucket", ""),
                  instance_value: object,
                  ttype: row.data.__ttype,
                  dataLocation: _.get(config, "dataLocation", ""),
                  scenario: row.data.__object.split("/")[0],
                  instanceContainer: true,
                  activeZoom: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addPathGroupTimingPaths = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (
      !(row.data.__obtype == "path_category/path_group/cause") ||
      row.data.__obtype == null
    ) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Net meta-data not found in the table data",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }
    //row.data.__obtype = $scenario + "/" + $path_category+ '/' + $path_group + "/" + $cause
    try {
      let keyForRequest = config.dataLocation;
      const scenarioForRequest = row.data.__object
        ? row.data.__object.split("/")[0]
        : _.get(config, "dataLocation", "").split("/").slice(-1).toString();
      // if key does not have scenario -> add scenario at the end
      if (!keyForRequest.endsWith(scenarioForRequest)) {
        keyForRequest = `${keyForRequest}/${scenarioForRequest}`;
      }
      var request = {
        bucket: config.bucket,
        key: keyForRequest,
        path_group_object: row.data.__object,
        ttype: row.data.__ttype,
      };
    } catch {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Please add meta data in query",
      });
    }

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_path_group_timing_paths",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", "");
        const dataLocation = _.get(response, "dataLocation", "");
        const data = _.get(response, "file", "");
        const bucket = _.get(response, "bucket", "");
        // const query = _.get(response, "query", "");
        const col = _.get(response, "columns", []);
        const rows = _.get(response, "rows", [[]]);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Path_group Timing Paths for ${row.data.__object}`,
                  dataLocation: dataLocation,
                  data: data,
                  bucket: bucket,
                  query: "df = df.sort_values('slack', ascending = True)",
                  columns: [
                    "path_category",
                    "start_point",
                    "end_point",
                    "slack",
                    "cause",
                    "timing_path",
                  ],
                  cache_key: cache_key,
                },
                data: { rows: [[]], columns: col, cache_key: cache_key },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Net Timing Paths",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addNetTimingPaths = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.__obtype == "net") || row.data.__obtype == null) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Net meta-data not found in the table data",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    try {
      var request = {
        bucket: config.bucket,
        key: utils.getRootDirectory(config.dataLocation),
        net: row.data.__object.split("/").slice(1).join("/"),
        ttype: row.data.__ttype,
        scenario: row.data.__object.split("/")[0],
      };
    } catch {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Please add meta data in query",
      });
    }

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_net_timing_paths",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", "");
        const dataLocation = _.get(response, "dataLocation", "");
        const data = _.get(response, "file", "");
        const bucket = _.get(response, "bucket", "");
        // const query = _.get(response, "query", "");
        const col = _.get(response, "columns", []);
        const rows = _.get(response, "rows", [[]]);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Net Timing Paths for ${row.data.__object}`,
                  dataLocation: dataLocation,
                  data: data,
                  // row.data.__ttype === "min"
                  //   ? "das_timing_path_min_data.ldb"
                  //   : "das_timing_path_data.ldb",
                  bucket: bucket,
                  query: "df = df.sort_values('slack', ascending = True)",
                  columns: [
                    "path_category",
                    "start_point",
                    "end_point",
                    "slack",
                    "cause",
                    "timing_path",
                  ],
                  cache_key: cache_key,
                },
                data: { rows: [[]], columns: col, cache_key: cache_key },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Net Timing Paths",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addCellTimingPaths = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;

    if (!(row.data.__obtype == "cell") || row.data.__obtype == null) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: "Cell meta-data not found in the table data",
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    try {
      var request = {
        bucket: config.bucket,
        key: utils.getRootDirectory(config.dataLocation),
        cell: row.data.__object.split("/").slice(1).join("/"),
        ttype: row.data.__ttype,
        scenario: row.data.__object.split("/")[0],
      };
    } catch {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "info",
        message: "Please add meta data in query",
      });
    }

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_cell_timing_paths",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const cache_key = _.get(response, "cache_key", {});
        const dataLocation = _.get(response, "dataLocation", {});
        const data = _.get(response, "file", "");
        const query = _.get(response, "query", "");
        const bucket = _.get(response, "bucket", {});
        const col = _.get(response, "columns", []);
        const rows = _.get(response, "rows", []);
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Table View",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Cell Timing Paths for ${row.data.__object}`,
                  dataLocation: dataLocation,
                  data: data,
                  // row.data.__ttype === "min"
                  //   ? "das_timing_path_min_data.ldb"
                  //   : "das_timing_path_data.ldb",
                  bucket: bucket,
                  query: "df = df.sort_values('slack', ascending = True)", //query,
                  columns: [
                    // "path_group",
                    "path_category",
                    "start_point",
                    "end_point",
                    "slack",
                    "cause",
                    "timing_path",
                  ],
                  cache_key: cache_key,
                },
                data: { rows: rows, columns: col },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Cell Timing Paths",
        });
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addTimingLayoutWidget = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;
    const rowHasScenario = row.data.scenario && row.data.scenario.length > 0;

    if (row == null) return;

    if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message: 'Columns should have "timing_path" to fetch Layout View',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      key: config.dataLocation,
      components: ["floorplan", "macros"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_task_layout",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          if (message !== "No valid response from server") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message: message,
            });
          }
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;

          //add Layout view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${_.get(config, "title", "Timingpath ")} ${
                    _.get(row.data, "timing_path", "")
                      ? _.get(row.data, "timing_path", "")
                      : row.data.__object
                  }}`,
                  bucket: _.get(config, "bucket", ""),
                  timingpath: _.get(row.data, "timing_path", "")
                    ? _.get(row.data, "timing_path", "")
                    : row.data.__object.split("/").slice(1).join("/"),
                  dataLocation: _.get(config, "dataLocation", ""),
                  scenario: rowHasScenario ? row.data.scenario : row.data.__object
                    ? row.data.__object.split("/")[0]
                    : _.get(config, "dataLocation", "")
                        .split("/")
                        .slice(-1)
                        .toString(),
                  timingPathContainer: true,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // Function to return context menu for rows
  getFlowTrendRowContextMenu = () => {
    return [
      {
        label: "<i class='fas fa-user'></i>Show in Timing Correlation",
        action: (e, row) => {
          this.addTimingCorrelation(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show in Layout View",
        action: (e, row) => {
          this.addLayoutView(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Show Path Compare Summary",
        action: (e, row) => {
          this.addTasksCompareSummary(e, row);
        },
      },
      {
        label: "<i class='fas fa-user'></i> Copy text",
        action: (e, row) => {
          this.copyToClipboard();
        },
      },
    ];
  };
  // Function to add Path Compare Summary Widget
  addTasksCompareSummary = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // close context menu
    // this.handleMenuClose();
    let refs = null;
    let hold = false;
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;

    if (row == null) return;
    if (row.data.__object) {
      refs = row.data.__object.split(",");
    }
    if (row.data.__ttype) {
      if (row.data.__ttype === "true" || row.data.__ttype === "min")
        hold = true;
    }

    if (
      !(
        "start_point_reference" in row.data && "end_point_reference" in row.data
      ) &&
      !(row.data.__obtype == "tp_trend")
    ) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message:
          'Columns should have "start_point_reference" and "end_point_reference" to fetch Timing Correlation',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      start_point: refs ? refs[0] : row.data.start_point_reference,
      end_point: refs ? refs[1] : row.data.end_point_reference,
      key: config.dataLocation,
      is_hold: [
        "das_flow_trend_report_min_data.ldb",
        "das_flow_trend_report_sorted_min_data.ldb",
      ].includes(_.get(this.props.widgetProps.config, "data"))
        ? true
        : hold,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_path_compare_summary",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          const config = this.props.widgetProps.config;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Timing Path Compare",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Path Compare Summary for start point reference: ${request.start_point} and end point reference: ${request.end_point}`,
                  bucket: config.bucket,
                  dataLocation: config.dataLocation,
                },
                data: data,
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Path Compare Summary Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // Function to add Timing Path Summary Widget
  addTimingCorrelation = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    // this.showToast({
    //   reportName: this.props.currentReportName,
    //   widgetId: this.props.id,
    //   severity: "info",
    //   message: "Work in progress",
    // });

    // close context menu
    // this.handleMenuClose();
    let refs = null;
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;
    let _data = _.get(this.props.widgetProps.config, "data", "");

    if (row == null) return;
    if (row.data.__object) {
      refs = row.data.__object.split(",");
    }

    if (_data.includes("#")) {
      const tmp = _data.split("#");
      _data = tmp[1];
    }

    if (
      !(
        "start_point_reference" in row.data && "end_point_reference" in row.data
      ) &&
      !(row.data.__obtype == "tp_trend")
    ) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message:
          'Columns should have "start_point_reference" and "end_point_reference" to fetch Timing Correlation',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      start_point: refs ? refs[0] : row.data.start_point_reference,
      end_point: refs ? refs[1] : row.data.end_point_reference,
      key: config.dataLocation,
      data: _data,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_timing_correlation_from_table",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          if (message === "list index out of range") {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "info",
              message:
                "Timing Correlation is available for top 1000 timing paths with worst negative slack",
            });
          } else {
            this.showToast({
              reportName: this.props.currentReportName,
              widgetId: this.props.id,
              severity: "error",
              message: message,
            });
          }
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          const config = this.props.widgetProps.config;
          // add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Timing Correlation",
                reportName: this.props.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Timing Correlation {${_.get(
                    config,
                    "title",
                    "Flow Trend"
                  )}}`,
                  data: config.data,
                  bucket: config.bucket,
                  showSlider: false,
                  timingpath: data.timingPath,
                  dataLocation: config.dataLocation,
                  reverseIndex:
                    999 - data.timingPathList.indexOf(data.timingPath),
                },
                data: { timingPathList: data.timingPathList },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Timing Correlation Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  addLayoutView = (e, rowObj) => {
    this.setLoading({
      reportName: this.props.currentReportName,
      widgetId: this.props.id,
      cirlularLoading: true,
    });
    let refs = null;
    const row = rowObj._cell.row;
    const config = this.props.widgetProps.config;
    let _data = _.get(this.props.widgetProps.config, "data", "");

    if (row == null) return;
    if (row.data.__object) {
      refs = row.data.__object.split(",");
    }

    if (_data.includes("#")) {
      const tmp = _data.split("#");
      _data = tmp[1];
    }

    if (
      !(
        "start_point_reference" in row.data && "end_point_reference" in row.data
      ) &&
      !(row.data.__obtype === "tp_trend")
    ) {
      this.showToast({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        severity: "error",
        message:
          'Columns should have "start_point_reference" and "end_point_reference" to fetch Layout View',
      });
      this.setLoading({
        reportName: this.props.currentReportName,
        widgetId: this.props.id,
        cirlularLoading: false,
      });
      return;
    }

    const request = {
      bucket: config.bucket,
      start_point: refs ? refs[0] : row.data.start_point_reference,
      end_point: refs ? refs[1] : row.data.end_point_reference,
      key: config.dataLocation,
      data: _data,
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/fetch_flow_layout_from_table",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const data = _.get(response, "data", {});
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // get y coord and height of current widget
          const yCoord = this.props.widgetProps.y;
          const config = this.props.widgetProps.config;
          const taskInfo = _.get(data, "task_info", [
            { bucket: "", key: "", scenario: "" },
          ]);
          //add table view widget below
          this.addWidgets({
            widgets: [
              {
                name: "Layout View",
                reportName: this.props.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: _.get(data, "task_layout", {}),
                config: {
                  title: `{${_.get(
                    config,
                    "title",
                    "Flow Trend"
                  )} for start point reference: ${
                    row.data.start_point_reference
                  }    end point reference: ${row.data.end_point_reference}}`,
                  bucket: _.get(taskInfo[0], "bucket", ""),
                  dataLocation: _.get(taskInfo[0], "key", ""),
                  scenario: _.get(taskInfo[0], "scenario", ""),
                  flowLayout: true,
                  flowPath: this.props.widgetProps.config.dataLocation,
                  flowBucket: this.props.widgetProps.config.bucket,
                  taskInfo: taskInfo,
                },
              },
            ],
          });
        }
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch Layout View Data",
        });
        console.log(error);
        this.setLoading({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          cirlularLoading: false,
        });
      });
  };

  // handleMenuClose = () => {
  //   this.setState({
  //     contextMenuOpen: false,
  //   });
  //   this.releaseRedraw();
  // };

  showInIcc2 = (e, rowObj) => {
    const config = this.props.widgetProps.config;
    const row = rowObj._cell.row;
    if (row == null) return;
    var hold = false;
    if (
      row.data.__ttype == "min" ||
      config.data == "das_timing_path_min_data.ldb"
    ) {
      hold = true;
    }
    const request = {
      timing_path: row.data.__object
        ? row.data.__object.split("/").slice(1).join("/")
        : row.data.timing_path,
      bucket: config.bucket,
      key: config.dataLocation,
      hold: hold,
      // scenario: _.get(config, "scenario", "")
      //   ? _.get(config, "scenario")
      //   : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
      scenario: row.data.__object
        ? row.data.__object.split("/")[0]
        : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
      col: ["timing_path", "start_point", "end_point"],
    };

    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_clock_path_meta_data",
        request
      )
      .then((response) => {
        response = response.data;
        const requestStatus = _.get(response, "status", false);
        const stpt = _.get(response, "start_point", "");
        const ept = _.get(response, "end_point", "");
        const message = _.get(
          response,
          "message",
          "No valid response from server"
        );
        if (!requestStatus) {
          this.showToast({
            reportName: this.props.currentReportName,
            widgetId: this.props.id,
            severity: "error",
            message: message,
          });
        } else {
          // string that needs to be copied
          let copyStr = `report_timing -from ${stpt[0]} -to ${ept[0]} -scenarios ${request.scenario}`;
          localStorage.setItem("cell", JSON.stringify(copyStr));
          this.copyToClipboard();
        }
      })
      .catch((error) => {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "Failed to fetch showInIcc2 Details",
        });
      });
  };

  // to copy to clipboard
  copyToClipboard = () => {
    // this.handleMenuClose();
    console.log(localStorage);
    const copyStr = localStorage.getItem("cell")
      ? JSON.parse(localStorage.getItem("cell"))
      : {};
    // if it is a secured connection (https) then it will write it to sytem clipboard directly
    if (window.isSecureContext && navigator.clipboard !== undefined) {
      navigator.clipboard.writeText(copyStr);
    }

    //otherwise it will copy to web ui clipboard
    else {
      var textarea = document.createElement("textarea");
      textarea.textContent = copyStr;
      document.body.appendChild(textarea);

      var selection = document.getSelection();
      var range = document.createRange();

      range.selectNode(textarea);
      selection.removeAllRanges();
      selection.addRange(range);

      document.execCommand("copy");
      selection.removeAllRanges();

      document.body.removeChild(textarea);
    }
  };

  // handleCellContextEvent = (event, cell) => {
  // event.preventDefault();
  // const mousePos = {
  //   x: event.pageX,
  //   y: event.pageY,
  // };

  updateConfig = (config, save, typeOfClick = "generate") => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(
          this.props.rptType,
          this.props.reportKey,
          this.props.id,
          config
        );
    }

    useGlobalStore?.getState()?.setWidgetUiState(this.props.id, {
      isLoading: false,
      showConfig: typeOfClick === "execute",
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  formatCells = (cell, formatterParams, onRendered) => {
    let val = cell.getValue();
    if (val == "Passed" || val == "Success") {
      cell.getElement().style.color = "green";
    } else if (val == "Failed") {
      cell.getElement().style.color = "red";
    }

    const rowData = cell._cell.row.data;
    const fields = Object.keys(rowData);
    const metaData = fields.filter((val, index) => val.includes("__META__"));
    const feildCols = metaData.filter((val, index) =>
      val.startsWith(`__${cell._cell.column.field}`)
    );
    const textColorCols = feildCols.filter((val, index) =>
      val.endsWith("textColor")
    );

    const backGroundCols = feildCols.filter((val, index) =>
      val.endsWith("background")
    );

    if (textColorCols.length && typeof rowData[textColorCols[0]] == "string") {
      cell.getElement().style.color = _.get(rowData, textColorCols[0], "black");
    }

    if (
      backGroundCols.length &&
      typeof rowData[backGroundCols[0]] == "string"
    ) {
      cell.getElement().style.background = _.get(
        rowData,
        backGroundCols[0],
        "black"
      );
    }

    return val;
  };

  getCellContextMenu = (e, cell) => {
    // console.log("called getCellContextMenu")
    let contextMenu = [];
    const iTableData = _.get(
      useGlobalStore?.getState()[this.props.id],
      "data",
      {}
    );
    // if generic context menu func (new way of defining context menu) is NOT available
    // then follow older logic of context menu
    if (
      !iTableData.context_menu_func_src ||
      iTableData.context_menu_func_src.length === 0
    ) {
      const rowData = cell._cell.row.data;
      const fields = Object.keys(rowData);
      const metaContextMenu = fields.filter(
        (val, index) =>
          val.endsWith("__META__contextMenu") &&
          val.startsWith(`__${cell._cell.column.field}__META__`)
      );
      let cellContextMenu = [];
      if (metaContextMenu.length) {
        cellContextMenu = this.addCustomMenu(
          rowData[metaContextMenu[0]],
          rowData
        );
      }

      contextMenu = this.getRowContextMenu(cell._cell.row.data).concat(
        cellContextMenu
      );
      // console.log("inside actual logic", contextMenu);
      return contextMenu;
    }
  };

  formatReportNameAsLink = (cell, formatterParams, onRendered) => {
    let val = cell.getValue();
    return `<a class='reportLink'>${val}</a> `;
  };

  //function to get report json
  openReportOnClick = async (e, cell) => {
    try {
      let payloadforReports = cell.getRow().getData();
      //project/user/block/phase/run_tag/checkpoint/time_stamp
      const keysToCheck = [
        "__project",
        "__user",
        "__block",
        "__phase",
        "__run_tag",
        "__checkpoint",
        "__timestamp",
      ];
      let allKeysPresent = keysToCheck.every((key) =>
        payloadforReports.hasOwnProperty(key)
      );
      let modifiedKeys = "";
      if (allKeysPresent) {
        modifiedKeys = keysToCheck
          .map((key, index) => {
            if (index === 0) {
              return payloadforReports[key];
            } else {
              return `/${payloadforReports[key]}`;
            }
          })
          .join("");
        let payload = {
          bucket: payloadforReports.__project,
          key: modifiedKeys,
          report_type: "task",
          user: `${useConfigStore.getState().authLoginUser}`,
          child_name: payloadforReports.Reports
            ? payloadforReports.Reports
            : "",
        };
        //call for report heson fetch API
        const getReport = await showReportOnClick(payload);
      } else {
        this.showToast({
          reportName: this.props.currentReportName,
          widgetId: this.props.id,
          severity: "error",
          message: "All keys not present to fetch Report",
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

  enable_filter = () => {
    let col = _.cloneDeep(
      _.get(useGlobalStore?.getState()[this.props.id], "data", {}).data.columns
    );
    for (let x = 0; x < col.length; x++) {
      // set resizable option to be true

      if (col[x].title === "Reports") {
        col[x].formatter = this.formatReportNameAsLink;
        col[x].cellClick = this.openReportOnClick;
      }

      col[x].resizable = true;
      // proceed with logic
      if (col[x].field && col[x].field.startsWith("__")) {
        col[x].visible = false;
      } else {
        col[x]["cellContext"] = (event, cell) => {
          localStorage.setItem("cell", JSON.stringify(cell._cell.initialValue));
        };
        col[x].visible = true;
        col[x].contextMenu = this.getCellContextMenu;
        col[x].resizable = true;
      }
      if (col[x].columns) {
        let len = col[x].columns.length;
        for (let y = 0; y < len; y++) {
          if (
            col[x].columns[y].field === "__object" ||
            col[x].columns[y].field === "__obtype" ||
            col[x].columns[y].field === "__ttype"
          ) {
            col[x].columns[y].visible = false;
          } else {
            col[x].columns[y]["cellContext"] = (event, cell) => {
              localStorage.setItem("cell", JSON.stringify(cell._cell.value));
            };
            col[x].columns[y].visible = col[x].columns[y].field.startsWith("__")
              ? false
              : true;
            col[x].columns[y].contextMenu = this.getCellContextMenu;
            col[x].columns[y].resizable = true;
          }
        }
      }
    }
    return col;
  };

  // applyTheme = (theme) => {
  //   if (theme == "dark") {
  //     return "table-sm table-dark table-striped table-bordered";
  //   } else {
  //     return "table-sm table-striped table-bordered";
  //   }
  // };

  onDownloadPNG = () => {
    // pass the reference of the table to the utility function
    utils.downloadTableSnapshot(this.ref.current);
  };

  onMenuClose = () => {
    this.setState({
      isContextMenuOpen: false,
    });
  };

  onOptionClick = (optionObj, iTableData) => {
    const props = this.props;
    const { action, label, args } = optionObj;
    const { context_menu_vars } = iTableData;
    try {
      // call action handler, also pass context_menu_vars
      handleContextMenuAction(
        action,
        args,
        { props },
        context_menu_vars,
        label
      );
    } catch (err) {
      console.error("Something went wrong on context-menu click!");
    } finally {
      // close context menu
      this.onMenuClose();
    }
  };
  // render method
  render() {
    // console.log(this.props)
    const iTableData = _.get(
      useGlobalStore?.getState()[this.props.id],
      "data",
      {}
    );
    let defaultTheme = "light";
    if (this.props.rptType === "allReports") {
      const reportInfo = _.cloneDeep(
        useGlobalStore.getState().allReports[this.props.reportKey]
      );
      defaultTheme = reportInfo.theme;
    }

    // const defaultTheme=reportInfo.theme ? reportInfo.theme : "light"
    const { data, theme: iTableTheme = defaultTheme } = iTableData;
    const updatedITableTheme =
      iTableTheme && iTableTheme.length > 0 ? iTableTheme : defaultTheme;
    const uiState = _.get(
      useGlobalStore?.getState()[this.props.id],
      "uiState",
      {
        showConfig: false,
      }
    );

    if (uiState.showConfig) {
      return this.props.widgetProps.config.cache_key ? (
        <ConfigChild
          updateConfig={this.updateConfig}
          config={this.props.widgetProps.config}
        />
      ) : (
        <Config
          updateConfig={this.updateConfig}
          config={this.props.widgetProps.config}
          rptType={this.props.rptType}
          reportKey={this.props.reportKey}
          id={this.props.id}
        />
      );
    } else {
      return data && Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <div
          id="analytics"
          className={`${styles.tableParent} dd-tabulator-theme-${updatedITableTheme}`}
        >
          <button
            className={styles.saveTableImage}
            onClick={this.onDownloadPNG}
          >
            Save Image
          </button>
          <div
            // loading style -> no pointer events happen on table load
            style={{
              pointerEvents: this.state.isTableViewLoading ? "none" : "auto",
            }}
            //  className={this.applyTheme(theme)}
            ref={(ref) => (this.ref.current = ref)}
          />
          {/* if table is loading, show overlay text */}
          {this.state.isTableViewLoading ? (
            <div className={styles.loadingTableOverlay}>
              <div className={styles.loadingText}>Fetching Data ...</div>
            </div>
          ) : (
            <></>
          )}

          <Menu
            open={this.state.isContextMenuOpen}
            anchorReference="anchorPosition"
            anchorPosition={{
              top: this.state.mousePosition && this.state.mousePosition.y,
              left: this.state.mousePosition && this.state.mousePosition.x,
            }}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
            variant="menu"
            keepMounted
            style={{ display: "block" }}
            onClose={this.onMenuClose}
          >
            {this.state.contextMenuOptions &&
            this.state.contextMenuOptions.length > 0 ? (
              this.state.contextMenuOptions.map((optionObj, index) => {
                // console.log("optionObj", optionObj);
                const { label } = optionObj;
                return (
                  <MenuItem
                    key={`${label}_${index}`}
                    onClick={() => this.onOptionClick(optionObj, iTableData)}
                  >
                    {label}
                  </MenuItem>
                );
              })
            ) : (
              <Typography sx={{ padding: "8px" }}>
                <CircularProgress size={13} sx={{ marginRight: "10px" }} />
                Fetching options
              </Typography>
            )}
          </Menu>
        </div>
      );
    }
  }
}

TableView.defaultProps = {
  widgetProps: { config: {} },
};

export default TableView;
