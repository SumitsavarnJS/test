// react imports
import React, { useState, useEffect, useRef } from "react";
import { produce } from "immer";
import { Typography } from "@mui/material";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";

import styles from "./TableDetailImages.module.css";
import Image from "next/image";

const TableDetailImages = (props) => {
  const { configData } = useConfigStore();

  const metricsURL = configData.rest_server_url + "/metrics/";
  useEffect(() => {
    console.log(props);
  }, []);

  return (
    <div id="tableDetailImages">
      {props?.widgetProps?.config?.images
        ? props.widgetProps.config.images.map((image) => (
            <div
              id={_.get(image, "minio_key", "image")}
              className={styles.image}
            >
              <Typography variant={"h5"}>
                Build name: {_.get(image, "buildName", "ERROR")}
              </Typography>
              <Typography variant={"h6"}>
                File name: {_.get(image, "display_name", "No Name")}
              </Typography>
              <img
                src={
                  metricsURL +
                  "downloadFile?minio_bucket=" +
                  _.get(image, "minio_bucket", "") +
                  "&minio_key=" +
                  _.get(image, "minio_key", "") +
                  "&ftype=IMAGE"
                }
                alt={_.get(image, "minio_key", "")}
                height={"500px"}
              />
            </div>
          ))
        : null}
    </div>
  );
};

export default TableDetailImages;
