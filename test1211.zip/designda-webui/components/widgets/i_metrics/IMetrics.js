import React, { useEffect, useRef, useState } from "react";

import { useRouter } from "next/router";

//utilitis
import _ from "lodash";

import api from "../../../common/api/api";
import * as utils from "../../../common/utils/utils";
import * as constants from "../../../constants/constants";
import * as funcs from "../../../common/Funcs";
import { shallow } from "zustand/shallow";
import { produce } from "immer";

import {
  Box,
  Button,
  Drawer as MuiDrawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  styled,
  Modal,
  Tooltip,
} from "@mui/material";

// icons import
import ImageIcon from "@mui/icons-material/Image";
import AssessmentIcon from "@mui/icons-material/Assessment";
import DifferenceIcon from "@mui/icons-material/Difference";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import GridViewIcon from "@mui/icons-material/GridView";
import FindInPageIcon from "@mui/icons-material/FindInPage";
import TopicIcon from "@mui/icons-material/Topic";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";

//table for report selection
import tabulator, { TabulatorFull as Tabulator } from "tabulator-tables";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

import { ReactTabulator } from "react-tabulator";

//store
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";

import TableCompareReport from "./metrics/reports/TableCompareReport";
import BuildsDashboardReport from "./metrics/reports/BuildsDashboardReport";
import HierDashboardReport from "./metrics/reports/HierDashboardReport";
import HierTimeDashboardReport from "./metrics/reports/HierTimeDashboardReport";
import ProfileReport from "./metrics/reports/ProfileReport";
import TableDetailReport from "./metrics/reports/TableDetailReport";
import FileReport from "./metrics/reports/FileReport";
import ImageCompareReport from "./metrics/reports/ImageCompareReport";

import Config from "./Config";
import { addWidgetCommonFunction } from "../../../pages/rptdashboard/addWidget/addWidget";
import refreshWidgetContent from "../../../pages/rptdashboard/wigetWrapper/widgetRefreshData";

const Drawer = styled(MuiDrawer)({
  position: "relative", //imp
  width: "auto", //drawer width
  "& .MuiDrawer-paper": {
    width: "auto", //drawer width
    position: "absolute", //imp
    left: "0px",
    transition: "none !important",
  },
});

function IMetrics(props) {
  const { data, uiState, updateConfig, setWidgetUiState, setWidgetDataProp } =
    useGlobalStore(
      (state) => ({
        data: state[props.id] ? state[props.id].data : {},
        uiState: state[props.id]
          ? state[props.id].uiState
          : {
              isLoading: false,
              showConfig: false,
              isToastOpen: false,
              toastSeverity: "info",
              toastMessage: "",
              cirlularLoading: false,
            },
        updateConfig: state.updateConfig,
        setWidgetUiState: state.setWidgetUiState,
        setWidgetDataProp: state.setWidgetDataProp,
      }),
      shallow
    );

  const { configData, authLoginUser } = useConfigStore(
    (state) => ({
      configData: state.configData,
      authLoginUser: state.authLoginUser,
    }),
    shallow
  );

  const router = useRouter();

  const metricsURL = configData.rest_server_url + "/metrics/";

  const reportSpecRef = useRef({});
  const hierSpecRef = useRef([]);
  const [reportsTableData, setReportsTableData] = useState([]);
  const [buildSpec, setBuildSpec] = useState([]);
  const [reportMountKey, setReportMountKey] = useState(1);
  const [openReportsPane, setOpenReportsPane] = useState(false);
  const [openCheckpoints, setOpenCheckpoints] = useState(false);

  const handleReportsPane = (open) => {
    setOpenReportsPane(open);
  };

  //reports table inst
  const reportsTableInst = useRef(null);
  const reportsTableRef = useRef(null);
  const iMetricsRef = useRef(null);

  const handleConfigSettings = (obj) => {
    // console.log(config);
    const config = props.widgetProps.config;
    const newConfig = produce(config, (configDraft) => {
      Object.entries(obj).forEach(function ([key, value]) {
        configDraft.savedReportConfig[configDraft.currentReport][key] = value;
      });
    });
    updateConfig(props.rptType, props.reportKey, props.id, newConfig);
  };

  const getReportClass = () => {
    const config = props.widgetProps.config;
    if (
      config?.currentReport &&
      reportSpecRef &&
      reportSpecRef.current &&
      reportSpecRef.current.reportNames
    ) {
      return reportSpecRef.current.reportNames[config.currentReport].reportInfo
        .reportClass;
    }
    return "";
  };

  let setBaselineBuild = (buildName) => {
    handleConfigSettings({ baselineBuild: buildName });
  };

  let setBaselineBuilds = (buildNames) => {
    handleConfigSettings({ baselineBuilds: buildNames });
  };

  let setBaselineBuildCheckpoint = (buildName, chkpt, timeStamp) => {
    handleConfigSettings({
      baselineBuild: buildName,
      baselineCheckpoint: chkpt,
      baselineTimestop: timeStamp.toString(),
    });
    setReportMountKey(Date.now());
  };

  const updateWidgetConfig = (config, save, newConfigFlag = false) => {
    // if user has refreshed, save the data in store
    if (save) {
      //   updateConfig(props.rptType, props.reportKey, props.id, config);
      //load report spec
      if (config.reportSpecName) {
        getReportSpec(config, newConfigFlag);
      } else {
        updateReportConfig(config, false);
        setWidgetUiState(props.id, {
          isLoading: false,
          showConfig: false,
          isToastOpen: false,
          toastSeverity: "info",
          toastMessage: "",
          cirlularLoading: false,
        });
      }
    } else {
      setWidgetUiState(props.id, {
        isLoading: false,
        showConfig: false,
        isToastOpen: false,
        toastSeverity: "info",
        toastMessage: "",
        cirlularLoading: false,
      });
    }
  };

  const updateReportConfig = (config, remountReport = true) => {
    updateConfig(props.rptType, props.reportKey, props.id, config);
    //remount the report
    if (remountReport) {
      setReportMountKey(Date.now());
    }
  };

  const getReportIcon = (reportClass) => {
    let icon = <AssessmentIcon />;
    switch (reportClass) {
      case "TableCompareReport":
        icon = <DifferenceIcon />;
        break;
      case "ImageCompareReport":
        icon = <ImageIcon />;
        break;
      case "FileReport":
        icon = <AttachFileIcon />;
        break;
      case "BuildDashboardReport":
        icon = <GridViewIcon />;
        break;
      case "TableDetailReport":
        icon = <FindInPageIcon />;
        break;
      case "ProfileReport":
        icon = <TopicIcon />;
        break;
      case "HierDashboardReport":
        icon = <AccountTreeIcon />;
        break;
      case "HierTimeDashboardReport":
        icon = <CalendarMonthIcon />;
        break;
    }
    return icon;
  };

  const openAnalyticsReport = async (query) => {
    const input = { text: query, user: authLoginUser };
    const response = await api(
      configData.rest_server_url + "/api/fetch_data_cards",
      input
    );
    if (response && response.status && response.data.length) {
      router.push(
        {
          pathname: "/rptdashboard",
          query: { queryParams: query },
        },
        "/rptdashboard"
      );
    } else {
      setWidgetUiState(props.id, {
        isLoading: false,
        showConfig: false,
        isToastOpen: true,
        toastSeverity: "info",
        toastMessage: "No associated analytics data found",
        cirlularLoading: false,
      });
    }
  };

  const handleOpenCheckpoint = (flag) => {
    setOpenCheckpoints(flag);
  };

  const handleSaveCheckpoints = (hiddenCheckpointsList = []) => {
    const newConfig = _.cloneDeep(props.widgetProps.config);

    newConfig.checkpointsConfig = {
      hiddenCheckpoints: hiddenCheckpointsList,
    };

    setOpenCheckpoints(false);

    updateReportConfig(newConfig);
  };

  const handleAddWidget = async (widgetId, preQuery) => {
    const wTemplate = await utils.getWidgetFromLib(widgetId);

    if (wTemplate && Object.keys(wTemplate).length == 0) {
      setWidgetUiState(props.id, {
        isLoading: false,
        showConfig: false,
        isToastOpen: true,
        toastSeverity: "error",
        toastMessage:
          "Menu incorrectly configured. Please reconfigure the menu in the report spec",
        cirlularLoading: false,
      });
      return;
    }

    //recuntruct the widget settings and config from template
    const settings = utils.getWidgetSettings(wTemplate.widget_name, wTemplate);

    if (
      settings.hasOwnProperty("config") &&
      settings.config.hasOwnProperty("query")
    ) {
      settings.config.query = preQuery + settings.config.query;
    }

    settings.y = props.widgetProps.y + 1;
    settings.w = props.widgetProps.w;
    const newIdList = addWidgetCommonFunction(
      props.rptType,
      props.reportKey,
      settings,
      {},
      {
        isLoading: false,
        showConfig: false,
        isToastOpen: false,
        toastSeverity: "info",
        toastMessage: "",
        cirlularLoading: false,
      },
      props.index
    );
    refreshWidgetContent({
      widgetId: newIdList[0],
      widgetName: settings.name,
      config: settings.config,
      reportKey: props.reportKey,
      rptType: props.rptType,
      variables:
        useGlobalStore.getState()[props.rptType][props.reportKey].variables,
    });
  };

  const getReportJSX = () => {
    let ret = null;
    const config = props.widgetProps.config;
    const reportClass = getReportClass();
    switch (reportClass) {
      case "TableCompareReport":
        ret = (
          <TableCompareReport
            selectedReportClass={"TableCompareReport"}
            setBaselineBuild={setBaselineBuild}
            baselineBuild={
              config.savedReportConfig[config.currentReport].baselineBuild
            }
            reportSpec={reportSpecRef.current}
            buildSpec={data.buildSpec}
            checkpoints={data.checkpoints}
            id={props.id}
            config={config}
            widgetProps={props.widgetProps}
            reportKey={props.reportKey}
            rptType={props.rptType}
            index={props.index}
            openCheckpoints={openCheckpoints}
            updateReportConfig={updateReportConfig}
            handleReportsPane={handleReportsPane}
            openAnalyticsReport={openAnalyticsReport}
            handleAddWidget={handleAddWidget}
            handleOpenCheckpoint={handleOpenCheckpoint}
            handleSaveCheckpoints={handleSaveCheckpoints}
          />
        );
        break;
      case "BuildsDashboardReport":
        ret = (
          <BuildsDashboardReport
            selectedReportClass={"BuildsDashboardReport"}
            id={props.id}
            config={config}
            widgetProps={props.widgetProps}
            reportKey={props.reportKey}
            rptType={props.rptType}
            index={props.index}
            reportSpec={reportSpecRef.current}
            buildSpec={data.buildSpec}
            checkpoints={data.checkpoints}
            openCheckpoints={openCheckpoints}
            updateReportConfig={updateReportConfig}
            handleReportsPane={handleReportsPane}
            handleAddWidget={handleAddWidget}
            handleOpenCheckpoint={handleOpenCheckpoint}
            handleSaveCheckpoints={handleSaveCheckpoints}
          />
        );
        break;
      case "HierDashboardReport":
        ret = (
          <HierDashboardReport
            selectedReportClass={"HierDashboardReport"}
            id={props.id}
            config={config}
            widgetProps={props.widgetProps}
            reportKey={props.reportKey}
            rptType={props.rptType}
            index={props.index}
            reportSpec={reportSpecRef.current}
            hierSpec={hierSpecRef.current}
            buildSpec={data.buildSpec}
            checkpoints={data.checkpoints}
            openCheckpoints={openCheckpoints}
            updateReportConfig={updateReportConfig}
            handleReportsPane={handleReportsPane}
            handleAddWidget={handleAddWidget}
            handleOpenCheckpoint={handleOpenCheckpoint}
            handleSaveCheckpoints={handleSaveCheckpoints}
          />
        );
        break;
      case "HierTimeDashboardReport":
        ret = (
          <HierTimeDashboardReport
            selectedReportClass={"HierTimeDashboardReport"}
            id={props.id}
            config={config}
            widgetProps={props.widgetProps}
            reportKey={props.reportKey}
            rptType={props.rptType}
            index={props.index}
            buildSpec={data.buildSpec}
            checkpoints={data.checkpoints}
            reportSpec={reportSpecRef.current}
            hierSpec={hierSpecRef.current}
            openCheckpoints={openCheckpoints}
            updateReportConfig={updateReportConfig}
            handleReportsPane={handleReportsPane}
            handleAddWidget={handleAddWidget}
            handleOpenCheckpoint={handleOpenCheckpoint}
            handleSaveCheckpoints={handleSaveCheckpoints}
          />
        );
        break;

      case "ProfileReport":
        ret = (
          <ProfileReport
            selectedReportClass={"ProfileReport"}
            id={props.id}
            config={config}
            widgetProps={props.widgetProps}
            reportKey={props.reportKey}
            rptType={props.rptType}
            index={props.index}
            buildSpec={data.buildSpec}
            checkpoints={data.checkpoints}
            reportSpec={reportSpecRef.current}
            hierSpec={hierSpecRef.current}
            openCheckpoints={openCheckpoints}
            updateReportConfig={updateReportConfig}
            handleReportsPane={handleReportsPane}
            handleAddWidget={handleAddWidget}
            handleOpenCheckpoint={handleOpenCheckpoint}
            handleSaveCheckpoints={handleSaveCheckpoints}
          />
        );
        break;

      case "TableDetailReport":
        ret = (
          <TableDetailReport
            selectedReportClass={"TableDetailReport"}
            setBaselineBuildCheckpoint={setBaselineBuildCheckpoint}
            id={props.id}
            config={config}
            reportSpec={reportSpecRef.current}
            widgetProps={props.widgetProps}
            reportKey={props.reportKey}
            rptType={props.rptType}
            index={props.index}
            buildSpec={data.buildSpec}
            checkpoints={data.checkpoints}
            openCheckpoints={openCheckpoints}
            updateReportConfig={updateReportConfig}
            handleReportsPane={handleReportsPane}
            handleAddWidget={handleAddWidget}
            handleOpenCheckpoint={handleOpenCheckpoint}
            handleSaveCheckpoints={handleSaveCheckpoints}
          />
        );
        break;

      case "FileReport":
        ret = (
          <FileReport
            selectedReportClass={"FileReport"}
            // setBaselineBuildCheckpoint={setBaselineBuildCheckpoint}
            handleConfigSettings={handleConfigSettings}
            id={props.id}
            config={config}
            widgetProps={props.widgetProps}
            reportKey={props.reportKey}
            rptType={props.rptType}
            index={props.index}
            buildSpec={data.buildSpec}
            checkpoints={data.checkpoints}
            openCheckpoints={openCheckpoints}
            updateReportConfig={updateReportConfig}
            handleReportsPane={handleReportsPane}
            handleAddWidget={handleAddWidget}
            handleOpenCheckpoint={handleOpenCheckpoint}
            handleSaveCheckpoints={handleSaveCheckpoints}
          />
        );
        break;
      case "ImageCompareReport":
        ret = (
          <ImageCompareReport
            selectedReportClass={"ImageCompareReport"}
            setBaselineBuild={setBaselineBuilds}
            baselineBuild={
              config.savedReportConfig[config.currentReport].baselineBuild
            }
            id={props.id}
            config={config}
            widgetProps={props.widgetProps}
            reportKey={props.reportKey}
            rptType={props.rptType}
            index={props.index}
            buildSpec={data.buildSpec}
            checkpoints={data.checkpoints}
            openCheckpoints={openCheckpoints}
            updateReportConfig={updateReportConfig}
            handleReportsPane={handleReportsPane}
            handleAddWidget={handleAddWidget}
            handleOpenCheckpoint={handleOpenCheckpoint}
            handleSaveCheckpoints={handleSaveCheckpoints}
          />
        );
        break;
      default:
        ret = <div>Selected report is under development</div>;
        if (repClass == "") {
          ret = (
            <div>
              Please go to settings and select reportSpec, report and build/s{" "}
            </div>
          );
        }
    }

    return ret;
  };

  const getReportNames = (reportSpec) => {
    let reports = [];
    if (reportSpec && reportSpec.reportNames) {
      for (let [report, reportsValue] of Object.entries(
        reportSpec.reportNames
      )) {
        const menuGroup = _.get(reportsValue.reportInfo, "menuGroup", "");
        const menuName = _.get(reportsValue.reportInfo, "menuName", "");
        reports.push({
          menuGroup: menuGroup,
          menuName: menuName,
          reportName: report,
          reportInfo: reportsValue.reportInfo,
        });
      }
    }
    return reports;
  };

  const getReportSpec = async (config, newConfigFlag = true) => {
    // unset buildspec if new New config, or builds don't exist
    if (
      !data.hasOwnProperty("buildSpec") ||
      (data.hasOwnProperty("buildSpec") && data.buildSpec.length == 0) ||
      newConfigFlag
    ) {
      setWidgetDataProp(props.id, "buildSpec", []);
    }
    // show circular loading
    setWidgetUiState(props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: true,
    });

    // console.log(uiStateCircularLoading);
    const reportSpecDoc = await api(metricsURL + "readSpecDoc/", {
      specType: "report_spec",
      specName: config.reportSpecName,
    });
    if (
      reportSpecDoc &&
      reportSpecDoc.data &&
      Object.keys(reportSpecDoc.data).length
    ) {
      //get builds from query
      if (config.selectedRuns) {
        setWidgetDataProp(props.id, "buildSpec", config.selectedRuns);
      }
      if (
        !data.hasOwnProperty("buildSpec") ||
        (data.hasOwnProperty("buildSpec") && data.buildSpec.length == 0) ||
        newConfigFlag
      ) {
        const buildResponse = await api(metricsURL + "getRunsWithQuery", {
          rawQuery: _.get(config, "query", ""),
          auth: { user: authLoginUser },
          variables:
            useGlobalStore.getState()[props.rptType][props.reportKey].variables,
        });

        if (buildResponse && buildResponse.status) {
          setWidgetDataProp(
            props.id,
            "buildSpec",
            _.get(buildResponse, "runs", [])
          );
          setWidgetDataProp(
            props.id,
            "checkpoints",
            _.get(buildResponse, "completeCheckpointsList", [])
          );
          setReportMountKey(Date.now());
        }
      }
      // end on fetching build spec

      //fetch hier spec
      if (config.hierSpecName) {
        const hierSpecResponse = await api(metricsURL + "readSpecDoc/", {
          specType: "hier_spec",
          specName: config.hierSpecName,
        });
        if (hierSpecResponse && hierSpecResponse.data) {
          hierSpecRef.current = hierSpecResponse.data.specDoc[0].data;
        }
      }
      // end of fetching hier spec

      //reading report spec for spec doc api
      const reportSpec = reportSpecDoc.data.specDoc[0].data;
      reportSpecRef.current = reportSpec;
      const rows = getReportNames(reportSpec);
      setReportsTableData(rows);
      //open first report
      if (rows.length && !config.hasOwnProperty("currentReport")) {
        handleReportsTableClick(rows[0], config);
      } else {
        const newConfig = _.cloneDeep(config);
        if (
          reportSpecRef.current &&
          Object.keys(reportSpecRef.current.reportNames).includes(
            newConfig.currentReport
          )
        ) {
          const reportClass =
            reportSpecRef.current.reportNames[newConfig.currentReport]
              .reportInfo.reportClass;
          if (
            !newConfig.savedReportConfig[
              newConfig.currentReport
            ].hasOwnProperty("metricsConfig") &&
            [
              "TableCompareReport",
              "TableDetailReport",
              "BuildsDashboardReport",
              "HierDashboardReport",
            ].includes(reportClass)
          ) {
            newConfig.savedReportConfig[newConfig.currentReport].metricsConfig =
              getMetricsConfig(newConfig.currentReport);
          }
        }
        newConfig.savedReportConfig[newConfig.currentReport];
        updateReportConfig(newConfig);
      }
      if (config.currentReport) {
        // reportsTableInst.current.selectRow(config.currentReport);
      }
    } else {
      //raise error
      console.log("report spec not found, raise alert WIP");
    }

    // stop load visual
    const uiStateStopCicularLoading = _.cloneDeep(uiState);
    uiStateStopCicularLoading.cirlularLoading = false;
    uiStateStopCicularLoading.showConfig = false;
    setWidgetUiState(props.id, uiStateStopCicularLoading);
  };

  const getMetricsConfig = (reportName) => {
    const metrics = {};
    if (
      reportSpecRef.current &&
      reportSpecRef.current.reportNames[reportName]
    ) {
      for (let [metricName, metricValue] of Object.entries(
        reportSpecRef.current.reportNames[reportName].metrics
      )) {
        metrics[metricName] = { hidden: _.get(metricValue, "hidden", false) };
      }
    }
    return metrics;
  };

  const getReportConfig = (reportName, config) => {
    let reportConfig = {};
    //check report spec
    if (reportSpecRef.current && reportSpecRef.current.reportNames) {
      //check if the name exists in report spec
      if (
        Object.keys(reportSpecRef.current.reportNames).includes(reportName) &&
        reportSpecRef.current.reportNames[reportName].reportInfo
      ) {
        const reportClass =
          reportSpecRef.current.reportNames[reportName].reportInfo.reportClass;
        //check if the report config was saved
        // let config = props.widgetProps.config;
        // the above config is not updated, don't know why, if you know how to fix
        // then please remove the below code for getting updagted config

        ///////////////////////////////////////////////////////////////////////////
        // // get config
        // if (props.rptType == "allDashbrdRpts") {
        //   config =
        //     useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets[
        //       props.id
        //     ].config;
        // } else {
        //   config =
        //     useGlobalStore.getState().allReports[props.reportKey].widgets[
        //       props.id
        //     ].config;
        // }
        ///////////////////////////////////////////////////////////////////////////

        if (
          config &&
          config.savedReportConfig &&
          Object.keys(config.savedReportConfig).includes(reportName)
        ) {
          reportConfig = _.cloneDeep(config.savedReportConfig[reportName]);
          // backward compatibility, if report does not have metrics config then add it
          if (
            !reportConfig.hasOwnProperty("metricsConfig") &&
            [
              "TableCompareReport",
              "TableDetailReport",
              "BuildsDashboardReport",
              "HierDashboardReport",
            ].includes(reportClass)
          ) {
            reportConfig.metricsConfig = getMetricsConfig(reportName);
          }
        }
        //if report config was not saved then return default report config
        else {
          switch (reportClass) {
            case "TableCompareReport":
              reportConfig.baselineBuilds = [];
              reportConfig.metricsConfig = getMetricsConfig(reportName);
              reportConfig.orgMode = "BCxM";
              reportConfig.displayMode = "VALUE";
              reportConfig.hierBlockMode = true;
              reportConfig.hierBuildMode = true;
              reportConfig.showEmpty = true;
              reportConfig.tablePersistence = {};
              reportConfig.tablePersistence.BCxM = {};
              reportConfig.tablePersistence.BCxM.VALUE = {
                filters: [],
                sorters: [],
              };
              break;
            case "ImageCompareReport":
              reportConfig.baselineBuilds = [];
              reportConfig.orgMode = "BCxM";
              reportConfig.hierBlockMode = true;
              reportConfig.hierBuildMode = true;
              reportConfig.tablePersistence = {};
              reportConfig.tablePersistence.BCxM = {
                filters: [],
                sorters: [],
              };
              break;
            case "FileReport":
              reportConfig.tablePersistence = {
                filters: [],
                sorters: [],
              };
              break;
            case "TableDetailReport":
              reportConfig.baselineBuild = "";
              reportConfig.metricsConfig = getMetricsConfig(reportName);
              reportConfig.displayMode = "VALUE";
              reportConfig.showEmpty = false;
              reportConfig.showDiff = false;
              reportConfig.tablePersistence = {};
              reportConfig.tablePersistence.VALUE = {
                filters: [],
                sorters: [],
              };
              break;
            case "BuildsDashboardReport":
              reportConfig.rowOrg = "None";
              reportConfig.metricsConfig = getMetricsConfig(reportName);
              reportConfig.tablePersistence = {
                filters: [],
                sorters: [],
              };
              break;
            case "HierDashboardReport":
              reportConfig.showSummary = false;
              reportConfig.metricsConfig = getMetricsConfig(reportName);
              reportConfig.tablePersistence = {
                filters: [],
                sorters: [],
              };
              break;
            case "HierTimeDashboardReport":
              reportConfig.seletedMetric = null;
              reportConfig.tablePersistence = {
                filters: [],
                sorters: [],
              };
              break;
            case "ProfileReport":
              reportConfig = {};
              break;
            default:
              reportConfig = null;
          }
        }
      }
    }
    return reportConfig;
  };

  const handleReportsTableClick = (rowData, config) => {
    // let config = props.widgetProps.config;
    // the above config is not updated, don't know why, if you know how to fix
    // then please remove the below code for getting updagted config

    ///////////////////////////////////////////////////////////////////////////////
    // //get config
    // if (props.rptType == "allDashbrdRpts") {
    //   config =
    //     useGlobalStore.getState().allDashbrdRpts.dashboardReport.widgets[
    //       props.id
    //     ].config;
    // } else {
    //   config =
    //     useGlobalStore.getState().allReports[props.reportKey].widgets[props.id]
    //       .config;
    // }
    ///////////////////////////////////////////////////////////////////////////////

    let newConfig = _.cloneDeep(config);
    // const rowData = cell.getData();
    // cell.getRow().select();
    if (rowData.reportInfo) {
      //   reportsTableInst.current.deselectRow();
      //   cell.getRow().select();
      //if config don't have any savedReportConfig then add a new key
      if (!newConfig.hasOwnProperty("savedReportConfig")) {
        newConfig.savedReportConfig = {};
      }

      // get saved or default report config
      const reportConfig = getReportConfig(rowData.reportName, config);
      if (reportConfig != null) {
        newConfig.savedReportConfig[rowData.reportName] = reportConfig;
        newConfig.currentReport = rowData.reportName;
        newConfig.currentReportName = rowData.menuName;
        updateConfig(props.rptType, props.reportKey, props.id, newConfig);
        // remount the report if it is a new newport
        if (rowData.reportName != config.currentReport) {
          setReportMountKey(Date.now());
        }
        // close the left nav bar
        setOpenReportsPane(false);
      }
    }
  };

  // const options = {
  //   layout: "fitDataStretch",
  //   index: "reportName",
  //   headerVisible: false,
  //   selectableRows: 1,
  //   columnDefaults: {
  //     tooltip: true,
  //     headerTooltip: true,
  //   },
  //   columns: [
  //     {
  //       title: "Reports",
  //       field: "menuName",
  //       headerSort: false,
  //       cellClick: handleReportsTableClick,
  //       // formatter: (cell, formatterParams, onRendered) =>
  //       //   cellFormatter(cell, formatterParams, onRendered),
  //     },
  //     { title: "Menu Group", field: "menuGroup", visible: false },
  //     {
  //       title: "Report Name",
  //       field: "reportName",
  //       visible: false,
  //     },
  //     {
  //       title: "ReportInfo",
  //       field: "reportInfo",
  //       visible: false,
  //     },
  //   ],
  //   groupBy: ["menuGroup"],
  //   // data: reportsTableData,
  //   // rowHeight: 40,
  //   height: "100%",
  //   width: "100%",
  // };

  useEffect(() => {
    const config = props.widgetProps.config;
    if (config && config.reportSpecName) {
      getReportSpec(config);
    }
  }, []);

  useEffect(() => {
    // close the opened report pane if you switch to config
    if (uiState.showConfig && openReportsPane) {
      setOpenReportsPane(false);
    }
  });

  const showReport = () => {
    const config = props.widgetProps.config;
    return (
      config.currentReport &&
      config.savedReportConfig &&
      config.savedReportConfig[config.currentReport] &&
      reportSpecRef &&
      reportSpecRef.current &&
      reportSpecRef.current.reportNames &&
      Object.keys(reportSpecRef.current.reportNames).includes(
        config.currentReport
      )
    );
  };

  const getMetrics = () => {
    const config = props.widgetProps.config;
    if (uiState.showConfig) {
      return (
        <Config
          id={props.id}
          config={props.widgetProps.config}
          reportKey={props.reportKey}
          rptType={props.rptType}
          updateWidgetConfig={updateWidgetConfig}
        />
      );
    } else {
      //check report spec in the config
      if (config.reportSpecName && reportsTableData) {
        //if report spec is configured then show reports table
        return (
          <Box
            id="IMetrics"
            ref={(ref) => (iMetricsRef.current = ref)}
            sx={{
              height: "100%",
              display: "flex",
              position: "relative",
              transform: "translate(0px, 0px)", //this is needed to position modal of drawer inside this div
            }}
          >
            {/* <div
              id="analytics"
              style={{
                width: "20%",
                height: "100%",
                maxWidth: "300px",
                flexShrink: 0,
              }}
            >
              <ReactTabulator
                onRef={(r) => (reportsTableInst.current = r.current)}
                options={options}
                // className={"table-sm table-striped table-bordered"}
                data={reportsTableData}
              /> 
            </div> */}
            <Box id="Drawer" sx={{ position: "absolute" }}>
              <Modal
                container={iMetricsRef.current}
                open={openReportsPane}
                onClose={() => {
                  //   if (!config.currentReport) {
                  handleReportsPane(false);
                  //   }
                }}
              >
                <Box
                  sx={{
                    position: "absolute",
                    top: "0px",
                    left: "0px",
                    transform: "translate(0px, 0px)",
                    width: "auto",
                    height: "100%",
                    bgcolor: "background.paper",
                    overflow: "auto",
                    // border: "2px solid #000",
                    boxShadow: 24,
                    borderRadius: "5px",
                    // p: 2,
                  }}
                >
                  <List id="ReportsPane" dense>
                    {reportsTableData.map((row, index) => (
                      <ListItem key={index} disablePadding dense>
                        <ListItemButton
                          onClick={() => {
                            handleReportsTableClick(row, config);
                          }}
                          selected={row.reportName == config.currentReport}
                          disablePadding
                          dense
                        >
                          <ListItemIcon>
                            <Tooltip
                              title={row.reportInfo.reportClass}
                              placement="top-end"
                            >
                              {getReportIcon(row.reportInfo.reportClass)}
                            </Tooltip>
                          </ListItemIcon>
                          <ListItemText>{row.menuName}</ListItemText>
                        </ListItemButton>
                      </ListItem>
                    ))}
                  </List>
                </Box>
              </Modal>
            </Box>
            {/* <div id="analytics" style={{ width: "25%", height: "100%" }}>
              <div
                ref={(r) => {
                  reportsTableRef.current = r;
                }}
              />
            </div> */}
            <Box
              sx={{
                flexGrow: 1,
                flexShrink: 1,
                flexBasis: 0,
                width: "100%",
              }}
            >
              {showReport() && data.buildSpec && data.buildSpec.length > 0 ? (
                <div
                  key={reportMountKey}
                  style={{ width: "100%", height: "100%" }}
                >
                  {getReportJSX()}
                </div>
              ) : (
                <Box
                  sx={{
                    display: "flex",
                    flexGrow: 1,
                    flexShrink: 1,
                    flexBasis: 0,
                    width: "100%",
                  }}
                >
                  <Button
                    sx={{ margin: "auto", width: "auto", height: "auto" }}
                    // variant={"h5"}
                    onClick={() => {
                      handleReportsPane(true);
                    }}
                  >
                    Click here to select a report
                  </Button>
                </Box>
              )}
            </Box>
          </Box>
        );
      }
      //display message to user to configure widget
      else {
        return (
          <Box>
            <Typography variant="h5" align="center">
              Configure the Specs in settings to load metrics
            </Typography>
          </Box>
        );
      }
    }
  };

  return getMetrics();
}

export default IMetrics;
