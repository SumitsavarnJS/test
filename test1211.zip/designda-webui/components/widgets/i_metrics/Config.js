import React, { useEffect, useState, createRef, useRef } from "react";

//utilitis
import _ from "lodash";
import axios from "axios";

import { produce } from "immer";
import { shallow } from "zustand/shallow";

import api from "../../../common/api/api";
import getApi from "../../../common/api/getApi";
import * as utils from "../../../common/utils/utils";
import * as constants from "../../../constants/constants";

import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

import {
  Box,
  Typography,
  Button,
  TextField,
  Autocomplete,
} from "@mui/material";

import { styled, lighten, darken } from "@mui/system";

//table for builds preview
import { TabulatorFull as Tabulator } from "tabulator-tables";

//table filters
import {
  customInput,
  customFilter,
  timeFilter,
  dateFromSeconds,
} from "../../../common/filter";

//store
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";

import dynamic from "next/dynamic";

import styles from "./Config.module.css";

// import VariableComponent from "../../CliVariables/TableViewCli/VariableLocal";

// INFO: dynamically importing query editor to prevent SSR issues
const AceEditor = dynamic(
  () =>
    import("../../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);

const GroupHeader = styled("div")(({ theme }) => ({
  position: "sticky",
  top: "-8px",
  padding: "4px 10px",
  color: "black",
  fontWeight: "700",
  backgroundColor:
    theme.palette.mode === "light"
      ? lighten("rgb(244, 208, 63)", 0.85)
      : darken(theme.palette.primary.main, 0.8),
}));

const GroupItems = styled("ul")({
  padding: 0,
});

const Config = (props) => {
  const { data, uiState, updateConfig, setWidgetUiState, setWidgetData } =
    useGlobalStore(
      (state) => ({
        data: state[props.id] ? state[props.id].data : {},
        setWidgetData: state.setWidgetData,
        uiState: state[props.id]
          ? state[props.id].uiState
          : {
              isLoading: false,
              showConfig: false,
              isToastOpen: false,
              toastSeverity: "info",
              toastMessage: "",
              cirlularLoading: false,
            },
        updateConfig: state.updateConfig,
        setWidgetUiState: state.setWidgetUiState,
      }),
      shallow
    );

  const { configData, authLoginUser } = useConfigStore(
    (state) => ({
      configData: state.configData,
      authLoginUser: state.authLoginUser,
    }),
    shallow
  );
  const metricsURL = configData.rest_server_url + "/metrics/";
  const defaultQueryBody = `# Invoke the cli object to query data
# builds are stored in variable 'runs'
# pattern format = user/block/phase/runtag/checkpoint
# you can get get multiple projects by merging two cli runs. 
# Example runs1 = cli.get_metrics_data( pattern = '.*', project = 'project1', count = 10000 )
#         runs2 = cli.get_metrics_data( pattern = '.*', project = 'project2', count = 10000 )
#         runs = runs1 + runs2
# you can edit the pattern to fetch runs 
# runs = cli.get_metrics_data( pattern = 
# '(?:user1|user2)/(?:block1|block2)/(?:phase1|phase2)/(?:runtag1:runtag2)/(?:checkpoint1|checkpoint2)',
# project = 'project1',
# count = 10000 )
`;
  const [title, setTitle] = useState(_.get(props.config, "title", ""));
  const [query, setQuery] = useState(
    _.get(props.config, "query", defaultQueryBody)
  );
  const [reportSpecList, setReportSpecList] = useState([]);
  const [hierSpecList, setHierSpecList] = useState([]);
  const [reportSpecName, setReportSpecName] = useState(
    _.get(props.config, "reportSpecName", "")
  );
  const [hierSpecName, setHierSpecName] = useState(
    _.get(props.config, "hierSpecName", "")
  );
  const [buildSpecList, setBuildSpecList] = useState([]);
  const [wVariables, setWVariables] = useState(
    useGlobalStore.getState()[props.rptType][props.reportKey].variables
  );
  const [selectedRows, setSelectedRows] = useState(
    _.get(props.config, "selectedRuns", [])
  );

  //table refs
  const tableRef = useRef(null);
  const tableInst = useRef(null);

  //Query Change
  const onQueryChange = (newQuery) => {
    setSelectedRows([]);
    setQuery(newQuery);
  };

  const handleConfigSettings = (obj) => {
    const config = props.config;
    const newConfig = produce(config, (configDraft) => {
      Object.entries(obj).forEach(function ([key, value]) {
        configDraft[key] = value;
      });
    });
    updateConfig(props.rptType, props.reportKey, props.id, newConfig);
  };

  const updateLocVariable = (locVariables) => {
    setWVariables(locVariables);
  };

  //report Spec change
  let reportSpecDataChanged = (newValue) => {
    setReportSpecName(newValue);
  };

  //hier spec change
  let hierSpecDataChanged = (newValue) => {
    setHierSpecName(newValue);
  };

  function sortRptSpec(a, b) {
    let user = authLoginUser;
    function localCompare(a, b) {
      if (a < b) {
        return -1;
      }
      if (a > b) {
        return 1;
      }
      return 0;
    }
    if (a.split("/")[1] == user) {
      if (b.split("/")[1] == user) {
        return localCompare(a, b);
      }
      return -1;
    }
    if (b.split("/")[1] == user) {
      return 1;
    }
    if (a < b) {
      return -1;
    }
    if (a > b) {
      return 1;
    }
    return 0;
  }

  const getRptSpecList = () => {
    let rptSpecList = _.cloneDeep(reportSpecList);
    rptSpecList?.sort(sortRptSpec);
    return rptSpecList;
  };

  const getSpecInfo = async () => {
    const responseData = await getApi(metricsURL + "getSpecInfo/");
    if (responseData) {
      const specInfoObj = _.get(responseData, "specInfoObj", []);
      let reportSpecList = [];
      let hierSpecList = [];
      for (const [user, specList] of Object.entries(specInfoObj.Users)) {
        for (let i = 0; i < specList.length; i++) {
          if (specList[i].specType == "report_spec") {
            reportSpecList.push(specList[i].specName);
          } else if (specList[i].specType == "hier_spec") {
            hierSpecList.push(specList[i].specName);
          }
        }
      }

      //setting specs with "Users/<user>/<projectName/specname>"
      setReportSpecList(reportSpecList);
      setHierSpecList(hierSpecList);
    } else {
      //raise error
      console.log("error in fething metrics specs");
    }

    /////////////////////////////////////////////////////////////////
    /// Reading build spec from query on mount
    /////////////////////////////////////////////////////////////////
    // getRunsWithQuery();
  };

  const dateFormatter = (cell, formatterParams, onRendered) => {
    const seconds = cell.getValue();
    return dateFromSeconds(seconds);
  };

  const buildsTableColumns = [
    {
      title: "Project",
      field: "PROJECT",
      headerSort: false,
      sorter: false,
      //   headerFilter: customInput,
      //   headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "Phase",
      field: "PHASE",
      headerSort: false,
      sorter: false,
      //   headerFilter: customInput,
      //   headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "Run Tag",
      field: "RUNTAG",
      headerSort: false,
      sorter: false,
      //   headerFilter: customInput,
      //   headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "Block",
      field: "BLOCK",
      headerSort: false,
      sorter: false,
      //   headerFilter: customInput,
      //   headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "User",
      field: "USER",
      headerSort: false,
      sorter: false,
      //   headerFilter: customInput,
      //   headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "User Label",
      field: "LABEL",
      headerSort: false,
      sorter: false,
      //   headerFilter: customInput,
      //   headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "Checkpoint",
      field: "checkpoint",
      headerSort: false,
      //   headerFilter: customInput,
    },

    // {
    //   title: "Time Start",
    //   field: "timeStart",
    // headerSort: false,
    // sorter: "string",
    // sorterParams: {
    //     format: "yyyy-MM-dd HH:mm:ss",
    //     alignEmptyValues: "top",
    //   },
    //   formatter: dateFormatter,
    // },
    {
      title: "Time Stop",
      field: "timeStop",
      headerSort: false,
      sorter: "string",
      formatter: dateFormatter,
    },
  ];

  const handleRowClick = (e, _row) => {
    const rowData = _row.getData();
    setSelectedRows((prev) => {
      const newSelectedRows = [...prev];
      const existingIndex = newSelectedRows.findIndex((data) =>
        _.isEqual(data, rowData)
      );
      if (existingIndex !== -1) {
        newSelectedRows.splice(existingIndex, 1);
        _row.deselect();
      } else {
        newSelectedRows.push(rowData);
        _row.select();
      }
      return newSelectedRows;
    });
  };

  const rowFormatter = (_row) => {
    const rowData = _row.getData();
    if (selectedRows.some((data) => _.isEqual(data, rowData))) {
      _row.select();
    }
  };

  const initiateTable = (initialQuery = "") => {
    tableInst.current = new Tabulator(tableRef.current, {
      layout: "fitDataStretch",
      pagination: true, //enable.
      paginationMode: "remote",
      paginationSize: 10,
      paginationSizeSelector: [10, 25, 50, 100, 200],
      paginationCounter: "rows",
      columns: buildsTableColumns,
      // rowHeight: 40,
      height: "430px",
      width: "100%",
      groupBy: ["BLOCK"],
      ajaxConfig: "POST",
      ajaxURL: metricsURL + "getRunsWithQuery",
      ajaxContentType: "json",
      ajaxParams: {
        rawQuery: initialQuery ? initialQuery : query,
        auth: { user: authLoginUser },
        variables: wVariables,
      },
      ajaxResponse: (url, params, responseData) => {
        if (!responseData.status) {
          // tableInst.current.alertManager.alert(responseData.message, "error");
          throw responseData.message;
        }
        const tabulatorLoreFormat = {
          data: responseData.runs ? responseData.runs : [],
          last_page: responseData.lastPage ? responseData.lastPage : 0,
          last_row: responseData.completeCount
            ? responseData.completeCount
            : 10,
        };
        return tabulatorLoreFormat;
      },
      columnDefaults: {
        headerFilterPlaceholder: "...",
        headerFilterLiveFilter: false,
        resizable: true,
      },
      rowFormatter: rowFormatter,
      selectableRows: true,
    });
    tableInst.current.on("dataLoadError", (error) => {
      tableInst.current.alertManager.alert(error, "error");
    });
    tableInst.current.on("rowClick", handleRowClick);
  };

  const getDefaultQuery = async () => {
    let userDefaultQuery = "";
    let runsQuery = "\nruns = runs0";

    //set query if changes are made
    if (defaultQueryBody == query) {
      const response = await api(
        configData.rest_server_url + "/api/get_profile_config",
        {
          user: authLoginUser,
        }
      );
      if (
        response &&
        response.profile_config &&
        response.profile_config.project
      ) {
        let projectQuery = "";
        for (let i = 0; i < response.profile_config.project.length; i++) {
          projectQuery = `\nruns${i} = cli.get_metrics_data( pattern = "${authLoginUser}", project = "${response.profile_config.project[i]}")`;
          userDefaultQuery = userDefaultQuery + projectQuery;
          if (i == 0) {
            continue;
          }
          runsQuery = runsQuery + ` + runs${i}`;
        }

        // add user and project related project
        let userProjectQuery = defaultQueryBody + userDefaultQuery + runsQuery;
        setQuery(userProjectQuery);
        initiateTable(userProjectQuery);
      }
    }
  };

  useEffect(() => {
    getDefaultQuery();
    getSpecInfo();
  }, []);

  const getRunsWithQuery = async () => {
    initiateTable();
  };

  const getSelectedRuns = () => {
    return selectedRows;
  };

  //handle save
  const onSave = () => {
    let config = {};
    let newConfigFlag = true;

    // if only title changes then overwrite the config
    if (
      _.isEqual(reportSpecName, props.config.reportSpecName) &&
      _.isEqual(hierSpecName, props.config.hierSpecName) // &&
      // _.isEqual(query, props.config.query)
    ) {
      config = _.cloneDeep(props.config);
      newConfigFlag = false;
    }

    // otherwise if any spec changes then create a new config
    config.title = title;
    config.reportSpecName = reportSpecName;
    config.hierSpecName = hierSpecName;
    config.query = query;
    if (selectedRows.length) {
      config.selectedRuns = getSelectedRuns();
    }
    props.updateWidgetConfig(config, true, newConfigFlag);
  };

  return (
    <Box>
      <TextField
        fullWidth
        label="Title"
        size="small"
        value={title}
        InputLabelProps={{
          shrink: true,
        }}
        onChange={(event) => setTitle(event.target.value)}
        variant="outlined"
      />

      {
        //Report Spec Selection
      }
      <Autocomplete
        id="data-input"
        disabled={reportSpecList ? false : true}
        style={{ marginTop: "10px", width: "98%" }}
        value={reportSpecName}
        onChange={(event, newValue) => {
          // handleConfigSettings("reportSpec", newValue);
          if (newValue != null) {
            reportSpecDataChanged(newValue);
          } else {
            handleConfigSettings({ supportedReportList: [] });
          }
        }}
        classes={{
          option: styles.option,
        }}
        size="small"
        // sx={{ width: 500 }}
        options={getRptSpecList()}
        groupBy={(option) => option.split("/")[1]}
        getOptionLabel={(option) => {
          return option && option.split("/")[2];
        }}
        renderInput={(params, option) => (
          <TextField
            {...params}
            label="Report Spec"
            variant="outlined"
            required
          />
        )}
        renderGroup={(params) => (
          <li key={params.key}>
            <GroupHeader>{params.group}</GroupHeader>
            <GroupItems>{params.children}</GroupItems>
          </li>
        )}
      />

      {
        //Hier Spec selection
      }
      <Autocomplete
        id="data-input"
        disabled={hierSpecList ? false : true}
        style={{ marginTop: "10px", width: "98%" }}
        value={hierSpecName}
        onChange={(event, newValue) => {
          if (newValue != null) {
            hierSpecDataChanged(newValue);
          } else {
            handleConfigSettings({
              selectedHierSpecData: [],
              hierSpec: newValue,
            });
            setHierSpecSelectedByUser(false);
          }
        }}
        classes={{
          option: styles.option,
        }}
        size="small"
        // sx={{ width: 500 }}
        options={hierSpecList}
        groupBy={(option) => option && option.split("/")[1]}
        getOptionLabel={(option) => {
          if (option && option) {
            return option.split("/")[2];
          } else {
            return "";
          }
        }}
        renderInput={(params, option) => (
          <TextField {...params} label="Hier Spec" variant="outlined" />
        )}
        renderGroup={(params) => (
          <li key={params.key}>
            <GroupHeader>{params.group}</GroupHeader>
            <GroupItems>{params.children}</GroupItems>
          </li>
        )}
      />

      {/* <VariableComponent
        locVar={wVariables}
        updateLocVariable={updateLocVariable}
      /> */}
      {
        //Build selection query
      }
      <Typography variant="subtitle1" className={styles.label}>
        Query Editor
      </Typography>
      <AceEditor
        placeholder="Please modify df object depending on the query."
        mode="python"
        theme="xcode"
        name="code_editor"
        width="100%"
        onChange={(value, event) => onQueryChange(value)}
        fontSize={16}
        maxLines={Infinity}
        showPrintMargin={true}
        showGutter={true}
        highlightActiveLine={true}
        value={query}
        setOptions={{
          enableBasicAutocompletion: true,
          enableLiveAutocompletion: true,
          enableSnippets: false,
          showLineNumbers: true,
          tabSize: 2,
        }}
      />

      <Button
        variant={"outlined"}
        onClick={getRunsWithQuery}
        sx={{ margin: "10px 0px" }}
      >
        Get Builds
      </Button>

      {
        //builds table
      }
      <div id="analytics" style={{ width: "inherit" }}>
        <div
          ref={(r) => {
            tableRef.current = r;
          }}
        ></div>
      </div>

      <Button
        variant="contained"
        size="small"
        disabled={false}
        onClick={onSave}
        classes={{ root: styles.save_button }}
      >
        Save
      </Button>
      <Button
        variant="contained"
        size="small"
        onClick={() => props.updateWidgetConfig({}, false)}
        classes={{ root: styles.cancel_button }}
      >
        Cancel
      </Button>
    </Box>
  );
};

export default Config;
