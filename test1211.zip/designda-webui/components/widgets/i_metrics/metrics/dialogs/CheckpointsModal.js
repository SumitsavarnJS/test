import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  ButtonGroup,
  Checkbox,
  Divider,
  FormControlLabel,
  FormGroup,
  Typography,
} from "@mui/material";

const Checkpoints = (props) => {
  const [hiddenCheckpoints, setHiddenCheckpoints] = useState(
    props.hiddenCheckpoints
  );

  const [checkpoints, setCheckpoints] = useState(
    _.get(props, "checkpoints", [])
  );

  const handleCheckpointsCheck = (checkpoint, index, event) => {
    const newHiddenCheckpoints = _.cloneDeep(hiddenCheckpoints);
    if (!event.target.checked && !newHiddenCheckpoints.includes(checkpoint)) {
      newHiddenCheckpoints.push(checkpoint);
    } else {
      newHiddenCheckpoints.splice(hiddenCheckpoints.indexOf(checkpoint), 1);
    }
    setHiddenCheckpoints(newHiddenCheckpoints);
  };

  const saveCheckpoints = () => {
    props.handleSaveCheckpoints(hiddenCheckpoints);
  };

  const handleAllCheckpointVisbility = (visibilityFlag) => {
    if (visibilityFlag) {
      setHiddenCheckpoints([]);
    } else {
      setHiddenCheckpoints(checkpoints);
    }
  };
  return (
    <Box
      sx={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "80%",
        height: "100%",
        bgcolor: "background.paper",
        border: "2px solid #000",
        boxShadow: 24,
        borderRadius: "15px",
        p: 2,
      }}
    >
      <Box id="Checkpoints_Box" sx={{ height: "100%" }}>
        <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
          Checkpoints
        </Typography>
        <Divider />
        <Box sx={{ height: "calc(100% - 93px)" }}>
          <FormGroup sx={{ height: "calc(100% - 50px)", width: "100%" }}>
            {/* <Typography variant="h6">Hidden Checkpoints</Typography> */}
            {checkpoints.map((checkpoint, index) => (
              <FormControlLabel
                control={
                  <Checkbox
                    checked={!hiddenCheckpoints.includes(checkpoint)}
                    onChange={(event) =>
                      handleCheckpointsCheck(checkpoint, index, event)
                    }
                  />
                }
                label={checkpoint}
              />
            ))}
          </FormGroup>
        </Box>
        <Divider />
        <ButtonGroup
          size={"small"}
          variant="contained"
          sx={{ float: "left", marginTop: "10px" }}
        >
          <Button
            onClick={() => {
              handleAllCheckpointVisbility(true);
            }}
          >
            Show All
          </Button>
          <Button
            onClick={() => {
              handleAllCheckpointVisbility(false);
            }}
          >
            Hide All
          </Button>
        </ButtonGroup>
        <ButtonGroup
          size={"small"}
          variant="contained"
          sx={{ float: "right", marginTop: "10px" }}
        >
          <Button onClick={saveCheckpoints}>Save</Button>
          <Button
            onClick={() => {
              props.handleCancel();
            }}
          >
            Cancel
          </Button>
        </ButtonGroup>
      </Box>
    </Box>
  );
};
export default Checkpoints;
