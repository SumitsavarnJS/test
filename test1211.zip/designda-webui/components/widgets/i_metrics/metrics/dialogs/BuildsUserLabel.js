import {
  Box,
  Button,
  ButtonGroup,
  Checkbox,
  Divider,
  FormControlLabel,
  FormGroup,
  TextField,
  Typography,
} from "@mui/material";
import React from "react";
import useConfigStore from "../../../../../store/useConfigStore";

const BuildUserLabel = (props) => {
  const { authLoginUser, isAdminFlag } = useConfigStore();

  const disableBuildLabel = () => {
    const buildName = props.selectedBuild;
    if (
      buildName &&
      buildName.split("/").length >= 5 &&
      (buildName.split("/")[1] == authLoginUser || isAdminFlag)
    ) {
      return false;
    }
    return true;
  };

  return (
    <Box
      sx={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "80%",
        // height: "100%",
        bgcolor: "background.paper",
        border: "2px solid #000",
        boxShadow: 24,
        borderRadius: "15px",
        p: 2,
      }}
    >
      <Box id="BuildsLabel">
        <Typography>Build Attributes</Typography>
        <Divider />
        <FormGroup>
          <TextField
            disabled={disableBuildLabel()}
            helperText={
              disableBuildLabel()
                ? "Only the owner of the build or the project manager can edit"
                : ""
            }
            size="small"
            value={props.buildLabel}
            onChange={props.handleBuildsLabel}
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={props.selectedBuildHiddenFlag}
                onChange={props.handleBuildsVisibleCheck}
              />
            }
            label={"Hide"}
          />
        </FormGroup>
        <Divider />
        <ButtonGroup size={"small"} sx={{ float: "right" }} variant="contained">
          <Button onClick={props.saveBuildLabel}>Save</Button>
          <Button onClick={props.cancelBuildLabel}>Cancel</Button>
        </ButtonGroup>
      </Box>
    </Box>
  );
};

export default BuildUserLabel;
