import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  ButtonGroup,
  Checkbox,
  Divider,
  FormControlLabel,
  FormGroup,
  Typography,
} from "@mui/material";

import { tags } from "../../../../../constants/constants";

const Builds = (props) => {
  const [hiddenBuilds, setHiddenBuilds] = useState(props.hiddenBuilds);

  const handleBuildsCheck = (build, index, event) => {
    const newHiddenBuilds = _.cloneDeep(hiddenBuilds);
    if (event.target.checked && !newHiddenBuilds.includes(build)) {
      newHiddenBuilds.push(build);
    } else {
      newHiddenBuilds.splice(hiddenBuilds.indexOf(build), 1);
    }
    setHiddenBuilds(newHiddenBuilds);
  };

  const saveBuilds = () => {
    props.handleSaveBuilds(hiddenBuilds);
  };

  const getDefaultCheck = (field) => {
    if (field == "label") {
      return _.get(props.buildsNomenclature[field], "show", false);
    } else {
      return _.get(props.buildsNomenclature[field], "show", true);
    }
  };

  return (
    <Box
      sx={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "80%",
        height: "100%",
        bgcolor: "background.paper",
        border: "2px solid #000",
        boxShadow: 24,
        borderRadius: "15px",
        p: 2,
      }}
    >
      <Box id="Builds_Box" sx={{ height: "100%" }}>
        <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
          Builds
        </Typography>
        <Divider />
        <Box sx={{ height: "calc(100% - 93px)" }}>
          <FormGroup sx={{ height: "calc(100% - 50px)", width: "100%" }}>
            <Typography variant="h6">Hidden builds</Typography>
            {props.hiddenBuilds.map((build, index) => (
              <FormControlLabel
                control={
                  <Checkbox
                    checked={hiddenBuilds.includes(build)}
                    onChange={(event) => handleBuildsCheck(build, index, event)}
                  />
                }
                label={build}
              />
            ))}
          </FormGroup>
          <FormGroup row={true} sx={{ overflow: "auto", height: "50px" }}>
            {tags.map((tag, index) => (
              <FormControlLabel
                control={
                  <Checkbox
                    checked={getDefaultCheck(tag.field)}
                    onChange={(event) =>
                      props.handleBuildsNameCheck(
                        _.get(tag, "field", ""),
                        event
                      )
                    }
                  />
                }
                label={_.get(tag, "label", "")}
              />
            ))}
          </FormGroup>
        </Box>
        <Divider />
        <ButtonGroup
          size={"small"}
          variant="contained"
          sx={{ float: "right", marginTop: "10px" }}
        >
          <Button onClick={saveBuilds}>Save</Button>
          <Button
            onClick={() => {
              props.handleCancle();
            }}
          >
            Cancel
          </Button>
        </ButtonGroup>
      </Box>
    </Box>
  );
};
export default Builds;
