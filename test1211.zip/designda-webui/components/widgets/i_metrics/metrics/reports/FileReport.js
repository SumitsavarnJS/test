import React from "react";
import { useState, useEffect, useRef, memo } from "react";
import { shallow } from "zustand/shallow";
import { produce } from "immer";
// import { ReactTabulator } from "react-tabulator";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import Builds from "../dialogs/BuildsModal";

import axios from "axios";
import _ from "lodash";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

//color
import { calcCell, _colors } from "../../../../../common/color";
import useConfigStore from "../../../../../store/useConfigStore";
import useGlobalStore from "../../../../../store/useGlobalStore";

import * as utils from "../../../../../common/utils/utils";

import { tags } from "../../../../../constants/constants";
import { getBuildsNomenclature } from "../../../../../common/utils/utils";

import * as funcs from "common/Funcs";

import styles from "./FileReport.module.css";

import {
  Button,
  ButtonGroup,
  Checkbox,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  InputLabel,
  MenuItem,
  Modal,
  Select,
  Stack,
  Typography,
} from "@mui/material";
import { Box } from "@mui/system";

import {
  customInput,
  customFilter,
  customFilterDisplayValue,
  globFilterDisplayValue,
} from "../../../../../common/filter";
import {
  customFilterDisplayValueTooltip,
  globFilterDisplayValueTooltip,
} from "../../../../../common/tooltip";

import ReactDOMServer from "react-dom/server";

import {
  addWidgetCommonFunction,
  showConfigUiState,
  showWidgetDataUiState,
  widgets,
} from "../../../../../pages/rptdashboard/addWidget/addWidget";
import Checkpoints from "../dialogs/CheckpointsModal";

function FileReport(props) {
  const { data, setWidgetDataProp } = useGlobalStore(
    (state) => ({
      data: state[props.id] ? state[props.id].data : {},
      setWidgetDataProp: state.setWidgetDataProp,
    }),
    shallow
  );

  let tableRef = React.createRef();
  const fileReportRef = useRef(null);

  const [openBuilds, setOpenBuilds] = useState(false);
  const [buildsNomenclature, setBuildsNomenclature] = useState(
    _.get(props.config.buildsConfig, "buildsNomenclature", {})
  );

  let tableInst = null;
  let prevRowHighlighted = null;
  let customContexts = [];
  let selectedRows = [];
  let c = [];
  let r = [];
  const metricsURL =
    useConfigStore.getState().configData.rest_server_url + "/metrics/";

  const [showFormat, setShowFormat] = useState(false);
  const [reportConfig, setReportConfig] = useState(
    props.config.savedReportConfig[props.config.currentReport]
  );

  const isNumber = (value) => {
    return !isNaN(value) && !isNaN(parseFloat(value));
  };

  const [hiddenBuilds, setHiddenBuilds] = useState(
    _.get(props.config.buildsConfig, "hiddenBuilds", [])
  );

  const handleSaveBuilds = (hiddenBuildsList = []) => {
    const newConfig = _.cloneDeep(props.config);

    newConfig.buildsConfig = {
      buildsNomenclature: buildsNomenclature,
      hiddenBuilds: hiddenBuildsList,
    };

    props.updateReportConfig(newConfig);
  };
  const handleBuildsNameCheck = (tag, event) => {
    const newBuildsNomenclature = _.cloneDeep(buildsNomenclature);
    newBuildsNomenclature[tag] = { show: event.target.checked };
    setBuildsNomenclature(newBuildsNomenclature);
  };

  const handleOpenBuilds = (flag) => {
    setOpenBuilds(flag);
  };

  const handleBuildsCancel = () => {
    setBuildsNomenclature(
      _.get(props.config.buildsConfig, "buildsNomenclature", {})
    );
    handleOpenBuilds(false);
  };

  const handleCheckpointCancel = () => {
    props.handleOpenCheckpoint(false);
  };

  let selectedData = _.get(
    props.config.savedReportConfig[props.config.currentReport],
    "selectedData",
    null
  );

  const globFilter = (headerValue, rowValue, rowData) => {
    let match = false;

    if (rowValue == undefined) {
      return match;
    }

    let pattern = headerValue;
    let cellText = rowValue;

    if (rowData._children != null) {
      match = true;
    } else {
      let options = { nocase: true };
      match = funcs.globMatch(pattern, cellText.toString(), options);
    }

    return match;
  };

  const fetchImage = async (bucket, key) => {
    let img = await axios
      .post(
        metricsURL + "downloadFile",
        {
          minio_bucket: bucket,
          minio_key: key,
          ftype: "IMAGE",
        },
        { responseType: "arraybuffer" }
      )
      .then((responseData) => {
        if (responseData.status == 200) {
          return responseData.data;
        } else {
          return null;
        }
      });
    return img;
  };

  const fetchHTML = async (bucket, key) => {
    let img = await axios
      .post(
        metricsURL + "downloadFile",
        {
          minio_bucket: bucket,
          minio_key: key,
        },
        { headers: { "Content-Type": "text/html" } }
      )
      .then((responseData) => {
        if (responseData.status == 200) {
          return responseData.data;
        } else {
          return null;
        }
      });
    return img;
  };

  const fetchText = async (bucket, key) => {
    let text = await axios
      .post(
        metricsURL + "downloadFile",
        {
          minio_bucket: bucket,
          minio_key: key,
          ftype: "TEXT",
        }
        // { responseType: "arraybuffer" }
      )
      .then((responseData) => {
        if (responseData.status == 200) {
          return responseData.data;
        } else {
          return null;
        }
      });
    return text;
  };

  const setRightPane = async (rowData) => {
    const ftype = _.get(rowData, "ftype", "");

    let data = {};

    if (ftype) {
      if (ftype == "TEXT") {
        let windowWidth = document.documentElement.clientWidth;
        let windowHeight = document.documentElement.clientHeight;
        let windowFeatures =
          "menubar=1,toolbar=1,location=1,status=1,resizable=1,scrollbars=1";
        windowFeatures += ",width=" + windowWidth;
        windowFeatures += ",height=" + windowHeight;
        const minio_bucket = _.get(rowData, "minio_bucket", "");
        const minio_key = _.get(rowData, "minio_key", "");
        const text = await fetchText(minio_bucket, minio_key);
        const html = <pre style={{ height: "100%" }}>{text}</pre>;
        // data = window.open("", minio_bucket + minio_key, windowFeatures);

        data = html;
      } else if (ftype == "IMAGE") {
        const image = await fetchImage(
          _.get(rowData, "minio_bucket", ""),
          _.get(rowData, "minio_key", "")
        );
        const src =
          "data:image/png;base64," +
          Buffer.from(image, "binary").toString("base64");
        data = <img src={src} alt={_.get(rowData, "minio_key", "")} />;
      } else if (ftype == "HTML") {
        data = <data>HTML WILL OPEN IN NEW TAB WITH RIGHT CLICK</data>;
      }
    }
    useGlobalStore
      .getState()
      .setWidgetDataProp(props.id, props.config.currentReport, data);
  };

  const rowClick = async (e, row) => {
    let data = row.getData();

    // Ignore clicks on folders
    if (data.hasOwnProperty("_children")) {
      return;
    }

    let fname = data.fname;
    let ftype = data.ftype;
    let fid = data.fid;

    // De-select any selected rows and select current row

    let tmpRows = tableInst.getSelectedRows();

    for (let tmpRow of tmpRows) {
      tmpRow.deselect();
    }
    row.select();

    // tableInst.updateData(tableInst.getData())

    // change the font weight of previous selection to normal
    const prevSelectedData = selectedData;
    if (prevSelectedData && prevSelectedData.hasOwnProperty("file")) {
      let rows = tableInst.getRows();
      for (let i = 0; i < rows.length; i++) {
        const prevCheckpoint = _.get(prevSelectedData, "checkpoint", {})[
          "display_name"
        ];
        const prevBuild = _.get(prevSelectedData, "build", {})["display_name"];
        const prevFile = _.get(prevSelectedData, "file", {})["display_name"];
        //prev build check
        if (rows[i].getData()["display_name"] == prevBuild) {
          const checkpointRows = rows[i].getTreeChildren();
          if (checkpointRows) {
            for (let cpt = 0; cpt < checkpointRows.length; cpt++) {
              //check file checkpoint
              if (
                checkpointRows[cpt].getData()["display_name"] == prevCheckpoint
              ) {
                const fileRows = checkpointRows[cpt].getTreeChildren();
                //check file
                if (fileRows) {
                  for (let f = 0; f < fileRows.length; f++) {
                    if (fileRows[f].getData()["display_name"] == prevFile) {
                      fileRows[f].getElement().style.fontWeight = "normal";
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    //set font weight of selected as bold
    row.getElement().style.fontWeight = "bold";

    //update selectedData
    const config = _.cloneDeep(
      props.config.savedReportConfig[props.config.currentReport]
    );
    const file = _.cloneDeep(row.getData());
    const checkpoint = _.cloneDeep(row.getTreeParent().getData());
    const build = _.cloneDeep(row.getTreeParent().getTreeParent().getData());
    config.selectedData = {
      file: file,
      checkpoint: checkpoint,
      build: build,
    };

    selectedData = {
      file: file,
      checkpoint: checkpoint,
      build: build,
    };

    props.handleConfigSettings(config);

    let fileData = { fname: fname, ftype: ftype, fid: fid };

    let fileInfo;
    fileInfo = setRightPane(data);
    // }

    let rowIdSelected = data.id;

    let theUpdate = {};
    theUpdate.fileInfo = fileInfo;
    theUpdate.rowIdSelected = rowIdSelected;
    // this.props.setReportState(this.getId(), theUpdate);
  };

  const COOKIE_NAME = "/metrics/ReportTweaks";

  const getId = () => {
    let id = props.id;
    return id;
  };

  const orgModeFunc = () => {
    // This function is only present to keep the column-width code consistent across reports
    return "default";
  };

  // Cookie support

  const setCookie = (cookie) => {
    funcs.writeCookie(COOKIE_NAME, cookie);
  };

  const getCookie = () => {
    let cookie = funcs.readCookie(COOKIE_NAME);
    let id = getId();
    let orgMode = orgModeFunc();

    if (_.isEmpty(cookie)) {
      cookie = {};
    }
    if (!cookie.hasOwnProperty(id)) {
      cookie[id] = {};
    }
    if (!cookie[id].hasOwnProperty(orgMode)) {
      cookie[id][orgMode] = {};
    }
    if (!cookie[id][orgMode].hasOwnProperty("columnWidths")) {
      cookie[id][orgMode]["columnWidths"] = {};
    }
    if (!cookie[id][orgMode].hasOwnProperty("headerSorters")) {
      cookie[id][orgMode]["headerSorters"] = [];
    }
    if (!cookie[id][orgMode].hasOwnProperty("headerFilters")) {
      cookie[id][orgMode]["headerFilters"] = [];
    }
    if (!cookie[id][orgMode].hasOwnProperty("rowExpandedInfo")) {
      cookie[id][orgMode]["rowExpandedInfo"] = {};
    }

    return cookie;
  };

  const dataTreeStartExpanded = (row, level) => {
    // if (_.isEmpty(props.dataConfig.reportStates)) {
    //   return false;
    // }

    let data = row.getData();
    if (!data.hasOwnProperty("_children")) {
      return false;
    }

    let cookie = getCookie();
    let id = getId();
    let orgMode = orgModeFunc();
    let rowExpandedInfo = cookie[id][orgMode]["rowExpandedInfo"];

    let expansionName = data.display_name;
    let expanded = rowExpandedInfo.hasOwnProperty(expansionName)
      ? rowExpandedInfo[expansionName]
      : false;
    return expanded;
  };

  const dataTreeRowExpanded = (row, level) => {
    let data = row.getData();
    let expansionName = data.display_name;

    let cookie = getCookie();
    let id = getId();
    let orgMode = orgModeFunc();
    let rowExpandedInfo = cookie[id][orgMode]["rowExpandedInfo"];

    rowExpandedInfo[expansionName] = true;

    cookie[id][orgMode]["rowExpandedInfo"] = rowExpandedInfo;
    setCookie(cookie);
  };

  const dataTreeRowCollapsed = (row, level) => {
    let data = row.getData();
    let expansionName = data.display_name;

    let cookie = getCookie();
    let id = getId();
    let orgMode = orgModeFunc();
    let rowExpandedInfo = cookie[id][orgMode]["rowExpandedInfo"];

    rowExpandedInfo[expansionName] = false;

    cookie[id][orgMode]["rowExpandedInfo"] = rowExpandedInfo;
    setCookie(cookie);
  };

  const cellFormatter = (cell, formatterParams, onRendered) => {
    let data = cell.getRow().getData();
    let isSelected = false;

    let rowType = data.rowType;
    let ftype = data.ftype;
    let displayName = _.cloneDeep(data.display_name);

    const row = cell.getRow();
    const prevSelectedData = selectedData;
    if (prevSelectedData) {
      const prevCheckpoint = _.get(prevSelectedData, "checkpoint", {})[
        "display_name"
      ];
      const prevBuild = _.get(prevSelectedData, "build", {})["display_name"];
      const prevFile = _.get(prevSelectedData, "file", {})["display_name"];
      if (displayName == prevFile) {
        const cptRow = row.getTreeParent();
        if (cptRow && cptRow.getData()["display_name"] == prevCheckpoint) {
          const buildRow = cptRow.getTreeParent();
          if (buildRow && buildRow.getData()["display_name"] == prevBuild) {
            isSelected = true;
          }
        }
      }
    }

    if (rowType == "build") {
      displayName = getBuildsNomenclature(
        displayName,
        buildsNomenclature,
        _.get(cell.getData(), "LABEL", "")
      );
    }

    let returnValue = displayName;

    let fg = funcs.palette("Default").fg;
    let bg = funcs.palette("Default").bg;

    if (rowType == "build") {
      bg = funcs.palette("DarkGray").bg;
    } else if (rowType == "checkpoint") {
      bg = funcs.palette("LightGray").bg;
    } else {
      if (ftype == "TEXT") {
        fg = funcs.palette("textFile").fg;
        bg = funcs.palette("textFile").bg;
      } else if (ftype == "IMAGE") {
        fg = funcs.palette("imageFile").fg;
        bg = funcs.palette("imageFile").bg;
      } else if (ftype == "HTML") {
        fg = funcs.palette("htmlFile").fg;
        bg = funcs.palette("htmlFile").bg;
        bg = funcs.palette("LightGray").bg;
      }
    }

    cell.getElement().style.color = fg;
    cell.getElement().style.backgroundColor = bg;

    if (isSelected) {
      cell.getElement().style.fontWeight = "bold";
    }

    return returnValue;
  };

  const getColumns = () => {
    let col = null;
    let rootGroupObj = {};
    rootGroupObj.title = null;
    rootGroupObj.columns = [];

    col = {
      title: "Files",
      field: "display_name",
      visible: true,
      headerSort: false,
      headerFilter: customInput,
      headerFilterFunc: globFilter,
      // headerTooltip: globFilterDisplayValueTooltip,
      formatter: (cell, formatterParams, onRendered) =>
        cellFormatter(cell, formatterParams, onRendered),
    };

    return [col];
  };

  // to copy to clipboard
  const copyToClipboard = (copyStr) => {
    // this.handleMenuClose();
    // if it is a secured connection (https) then it will write it to sytem clipboard directly
    if (window.isSecureContext && navigator.clipboard !== undefined) {
      navigator.clipboard.writeText(copyStr);
    }

    //otherwise it will copy to web ui clipboard
    else {
      var textarea = document.createElement("textarea");
      textarea.textContent = copyStr;
      document.body.appendChild(textarea);

      var selection = document.getSelection();
      var range = document.createRange();

      range.selectNode(textarea);
      selection.removeAllRanges();
      selection.addRange(range);

      document.execCommand("copy");
      selection.removeAllRanges();

      document.body.removeChild(textarea);
    }
  };

  const openInNewTab = async (rowData) => {
    const ftype = _.get(rowData, "ftype", "");
    let data = {};
    const minio_bucket = _.get(rowData, "minio_bucket", "");
    const minio_key = _.get(rowData, "minio_key", "");
    const title = minio_key.split("/").slice(-1)[0];

    if (ftype != "HTML") {
      window.open(
        metricsURL +
          "downloadFile?minio_bucket=" +
          minio_bucket +
          "&minio_key=" +
          minio_key +
          "&ftype=" +
          ftype,
        "_blank",
        "noopener,noreferrer"
      );
    } else if (ftype == "HTML") {
      let url =
        metricsURL +
        "mountStaticFile?minio_bucket=" +
        minio_bucket +
        "&minio_key=" +
        minio_key +
        "&ftype=" +
        ftype;

      let theWindow = window.open(url, "_blank", "noopener,noreferrer");

      // theWindow.document.write(html);
      // theWindow.document.close();
    }
    // if (ftype == "TEXT") {
    // const text = await fetchText(minio_bucket, minio_key);
    //   const html = (
    //     <div>
    //       <pre>{text}</pre>
    //     </div>
    //   );
    //   const newTab = window.open();
    //   if (newTab) {
    //     newTab.document.open();
    //     newTab.document.write(html);
    //     newTab.document.close();
    //   }
    // } else if (ftype == "IMAGE") {
    //   data = <img src={metricsURL +
    //     "downloadFile?minio_bucket=" +
    //     _.get(rowData, "minio_bucket", "") +
    //     "&minio_key=" +
    //     _.get(rowData, "minio_key", "")} alt={_.get(rowData, "minio_key", "")} />;
    //   window.open(metricsURL +
    //     "downloadFile?minio_bucket=" +
    //     _.get(rowData, "minio_bucket", "") +
    //     "&minio_key=" +
    //     _.get(rowData, "minio_key", ""), "_blank", "noopener,noreferrer");
    // } else if (ftype == "HTML") {
    //   const html = await fetchHTML(minio_bucket, minio_key);
    //   const newTab = window.open();
    //   if (newTab) {
    //     newTab.document.open();
    //     newTab.document.write(html);
    //     newTab.document.close();
    //   }
    // }
  };

  const getRowContextMenu = (e, row) => {
    let rowContextMenu = [];
    const rowData = row.getData();

    rowContextMenu.push({
      label: "Copy File name",
      action: () =>
        copyToClipboard(_.get(rowData, "display_name", "EMPTY STRING")),
    });
    rowContextMenu.push({
      label: "Open In New tab",
      action: () => openInNewTab(rowData),
    });

    return rowContextMenu;
  };

  // let rowMouseEnter = (e, row) => {
  //     if (tableInst == null) {
  //         return;
  //     }
  //     // Deselect all rows styles
  //     if (prevRowHighlighted != null) {
  //         for (let id in prevRowHighlighted) {
  //             prevRowHighlighted[id].getElement().style.borderColor = "#cccccc";
  //             // prevRowHighlighted[id].getElement().style.color = "#333333";
  //         }
  //     }
  //     // const selctedRow = tableInst.getSelectedRows();
  //     // if(selctedRow){
  //     //     for (let i in selctedRow) {
  //     //         selctedRow[i].getElement().style.backgroundColor = "pink";
  //     //     }
  //     // }

  //     if (true) {
  //         let hoverCheckpoint = row.getData().checkpoint;
  //         let rows = tableInst.getRows().filter((r) => {
  //             return r.getData().checkpoint == hoverCheckpoint;
  //         });
  //         prevRowHighlighted = rows;
  //         for (let id in rows) {
  //             rows[id].getElement().style.borderColor = "blue";
  //             // rows[id].getElement().style.color = "white";
  //         }
  //     }
  // };

  let afterTableBuilt = () => {
    console.log(
      "After table built",
      props.config.savedReportConfig[props.config.currentReport]
    );
  };

  const getRightPane = () => {
    if (props.id) {
      const fileRightPaneData = data[props.config.currentReport];
      if (
        typeof fileRightPaneData === "object" &&
        Object.keys(fileRightPaneData).length == 0
      ) {
        return null;
      }
      return fileRightPaneData;
    }
  };

  //----------------Table -------------------------
  useEffect(() => {
    console.log(tableInst);
    const selectedData = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "selectedData",
      null
    );
    if (selectedData) {
      setRightPane(_.get(selectedData, "file", {}));
    }

    const initTable = () => {
      console.log("table init");
      var columns = getColumns();
      var temp = props.config.savedReportConfig[props.config.currentReport]
        ?.rows
        ? props.config.savedReportConfig[props.config.currentReport]?.rows
        : [];
      var rows = JSON.parse(JSON.stringify(temp));
      if (tableInst == null) {
        console.log("table init1");
        tableInst = new Tabulator(tableRef, {
          layout: "fitDataStretch",
          selectableRows: false,
          dataTree: true,
          dataTreeStartExpanded: (row, level) =>
            dataTreeStartExpanded(row, level),
          //rowHeight: 40,
          height: "100%",
          width: "500px",
          rowContextMenu: getRowContextMenu,
          columns: columns ? columns : [],
          pagination: true, //enable pagination
          paginationMode: "remote", //enable remote pagination
          sortMode: "remote",
          filterMode: "remote",
          ajaxConfig: "POST",
          paginationSize: 25,
          paginationSizeSelector: [10, 25, 50, 100, 200],
          paginationCounter: "rows",
          ajaxURL: metricsURL + "getFileReport",
          ajaxContentType: "json",
          ajaxParams: {
            selectedBuilds: props.buildSpec,
            auth: {
              user: _.get(useConfigStore.getState(), "authLoginUser", ""),
            },
            hiddenBuilds: hiddenBuilds,
            hiddenCheckpoints: _.get(
              props.config,
              ["checkpointsConfig", "hiddenCheckpoints"],
              []
            ),
            // rawQuery: _.get(props.config, "query", ""),
            // variables: _.get(props.config, "wVariables", {}),
          },
          ajaxResponse: (url, params, responseData) => {
            const tabulatorLoreFormat = {
              data: responseData.rows ? responseData.rows : [],
              last_page: responseData.lastPage ? responseData.lastPage : 0,
              last_row: responseData.completeCount
                ? responseData.completeCount
                : 10,
            };
            return tabulatorLoreFormat;
          },
          columnDefaults: {
            headerFilterPlaceholder: "...",
            headerFilterLiveFilter: false,
            tooltip: function (e, cell, onRendered) {
              //e - mouseover event
              //cell - cell component
              //onRendered - onRendered callback registration function

              var el = document.createElement("div");
              el.style.backgroundColor = "rgba(97,97,97)";
              el.style.color = "white";
              el.style.height = "auto";
              el.style.padding = "5px";
              el.style.minHeight = "20px";
              el.style.borderRadius = "10px";
              el.style.opacity = 0.92;
              el.innerText = cell.getValue(); //return cells "field - value";

              return el;
            },
            resizable: true,
          },
        });
        tableInst.on("rowClick", rowClick);
        tableInst.on("dataTreeRowExpanded", dataTreeRowExpanded);
        tableInst.on("dataTreeRowCollapsed", dataTreeRowCollapsed);
      } else {
        console.log("Table replace data");
        tableInst.replaceData(rows);
        // this.resizeTable();
      }
    };

    initTable();
  }, []);

  const getReportMenu = () => {
    return (
      <div id="reportMenu" style={{ width: "100%", height: "30px" }}>
        <ButtonGroup size="small" variant="text">
          <Chip
            label={props.config.currentReportName}
            sx={{ height: "28px" }}
            onClick={() => {
              props.handleReportsPane(true);
            }}
            variant={"outlined"}
          />
          <Button onClick={() => handleOpenBuilds(true)}>Builds</Button>
          <Button onClick={() => props.handleOpenCheckpoint(true)}>
            Checkpoints
          </Button>
        </ButtonGroup>
        <Modal open={openBuilds} container={fileReportRef.current}>
          <Builds
            buildsNomenclature={buildsNomenclature}
            handleBuildsNameCheck={handleBuildsNameCheck}
            handleSaveBuilds={handleSaveBuilds}
            handleCancle={handleBuildsCancel}
            hiddenBuilds={hiddenBuilds}
          />
        </Modal>
        <Modal open={props.openCheckpoints} container={fileReportRef.current}>
          <Checkpoints
            handleSaveCheckpoints={props.handleSaveCheckpoints}
            handleCancel={handleCheckpointCancel}
            checkpoints={props.checkpoints}
            hiddenCheckpoints={_.get(
              props.config,
              ["checkpointsConfig", "hiddenCheckpoints"],
              []
            )}
          />
        </Modal>
      </div>
    );
  };

  return (
    // <h1>I am table</h1>
    <>
      <div
        id="FileReport"
        ref={(ref) => (fileReportRef.current = ref)}
        style={{ width: "100%", height: "100%" }}
      >
        {getReportMenu()}
        <div
          className={styles.fileParent}
          style={{ width: "100%", height: "calc(100% - 30px)" }}
          id="analytics"
        >
          <div
            style={{ width: "500px" }}
            ref={(r) => {
              tableRef = r;
            }}
          ></div>
          <div id="FileReportRightPane" className={styles.rightPane}>
            {getRightPane()}
          </div>
        </div>
      </div>
    </>
  );
}

FileReport.defaultProps = {
  query: "",
  baselineBuild: "",
};

export default FileReport;
