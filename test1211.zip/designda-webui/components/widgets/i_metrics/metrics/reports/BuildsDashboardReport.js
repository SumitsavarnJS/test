import React from "react";
import { useState, useEffect, useRef } from "react";
import { shallow } from "zustand/shallow";
import { produce } from "immer";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import Builds from "../dialogs/BuildsModal";
import axios from "axios";
import { calcCell, _colors } from "../../../../../common/color";
import useConfigStore from "../../../../../store/useConfigStore";
import useGlobalStore from "../../../../../store/useGlobalStore";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

import api from "../../../../../common/api/api";

import * as funcs from "../../../../../common/Funcs";

import {
  customInput,
  customFilter,
  customFilterDisplayValue,
  globFilterDisplayValue,
  dateFromSeconds,
} from "../../../../../common/filter";

import { customFilterDisplayValueTooltip } from "../../../../../common/tooltip";
import { tags } from "../../../../../constants/constants";
import { getBuildsNomenclature } from "../../../../../common/utils/utils";

import {
  addWidgetCommonFunction,
  showWidgetDataUiState,
} from "../../../../../pages/rptdashboard/addWidget/addWidget";

//mui components
import {
  Button,
  ButtonGroup,
  Checkbox,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  InputLabel,
  Menu,
  MenuItem,
  Modal,
  Paper,
  Select,
  Stack,
  Typography,
} from "@mui/material";
import { Box } from "@mui/system";
//mui styles
import { styled, alpha } from "@mui/material/styles";

//icon
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import _ from "lodash";
import Checkpoints from "../dialogs/CheckpointsModal";

const StyledMenu = styled((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 100,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      fontSize: 12,
      "& .MuiSvgIcon-root": {
        // fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

// const mongoURL = "http://10.15.102.250:7634/mongo/";
export default function BuildsDashboardReport(props) {
  // let info = getTableOptionsEvents("xyz");
  // const [columns, setColumns] = useState([]);
  // const [rows, setRows] = useState([]);
  let tableRef = React.createRef();
  let tableInst = null;
  let customContexts = [];
  let prevRowHighlighted = null;
  let selectedRows = [];
  let c = [];
  let r = [];
  const metricsURL =
    useConfigStore.getState().configData.rest_server_url + "/metrics/";

  const isNumber = (value) => {
    return !isNaN(value) && !isNaN(parseFloat(value));
  };

  const [showFormat, setShowFormat] = useState(false);
  const [reportConfig, setReportConfig] = useState(
    props.config.savedReportConfig[props.config.currentReport]
  );
  const [openMetrics, setOpenMetric] = useState(false);
  const [openBuilds, setOpenBuilds] = useState(false);
  const [metrics, setMetrics] = useState(
    _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "metricsConfig",
      {}
    )
  );

  const [buildsNomenclature, setBuildsNomenclature] = useState(
    _.get(props.config.buildsConfig, "buildsNomenclature", {})
  );

  const [openDownloadMenu, setOpenDownloadMenu] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const dashboartRef = useRef(null);

  //-----------------------------------------------------------

  let rowContextMenuSetBaseline = (e, row) => {
    let buildName = row.getData().buildName;
    let block = row.getData().block;

    //------finding ref checkpoints--------
    let refRows = tableInst.getRows().filter((r) => {
      return r.getData().buildName == buildName;
    });
    for (let id in refRows) {
      refRows[id].getElement().style.background = "#ffffe6";
    }
    //-------------------------------------
    //------compare checkpoints of same block with ref checkpoint----
    let rows = tableInst.getRows().filter((r) => {
      return r.getData().buildName != buildName && r.getData().block == block;
    });
    if (rows.length > 0) {
      for (let id in rows) {
        let checkpoint = rows[id].getData().checkpoint;
        var xCells = rows[id].getCells();

        let refRow = refRows.filter((r) => {
          return r.getData().checkpoint == checkpoint;
        });
        if (refRow.length > 0) {
          var refCells = refRow[0].getCells();

          for (let index in xCells) {
            if (
              isNumber(refCells[index].getValue()) &&
              isNumber(xCells[index].getValue())
            ) {
              let improved = false;
              let diff = refCells[index].getValue() - xCells[index].getValue();
              if (diff) {
                // console.log("diff", diff);
                let percDiff =
                  100 * Math.abs(diff / refCells[index].getValue());
                if (refCells[index].getValue() > xCells[index].getValue()) {
                  improved = true;
                }
                if (improved) {
                  if (percDiff > 10) {
                    xCells[index].getElement().style.background =
                      "rgb(128, 255, 128)";
                  } else if (percDiff > 2) {
                    xCells[index].getElement().style.background =
                      "rgb(176, 255, 176)";
                  } else if (percDiff > 0.5) {
                    xCells[index].getElement().style.background =
                      "rgb(224, 255, 224)";
                  }
                } else {
                  if (percDiff > 10) {
                    xCells[index].getElement().style.background =
                      "rgb(255, 128, 128)";
                  } else if (percDiff > 2) {
                    xCells[index].getElement().style.background =
                      "rgb(255, 176, 176)";
                  } else if (percDiff > 0.5) {
                    xCells[index].getElement().style.background =
                      "rgb(255, 128, 128)";
                  }
                }
              }
            }
          }
        } else {
          rows[id].getElement().style.background = "rgb(244, 208, 63)";
        }
      }
    }
    //-------------------------------------
  };
  const handleRowContextMenuSetBaseline = {
    label: "<b> Set baseline </b>",
    action: rowContextMenuSetBaseline,
  };
  //-----------------------------------------------------------

  let rowClick = (e, row) => {
    if (tableInst == null) {
      return;
    }
    row.toggleSelect();

    // if (selectedRows.length != 0) {
    //     const index = selectedRows.indexOf(row);
    //     if (index > -1) {
    //         selectedRows.splice(index, 1); // 2nd parameter means remove one item only
    //     }
    // }

    // selectedRows.push(row);
    // console.log(selectedRows);
  };

  const [hiddenBuilds, setHiddenBuilds] = useState(
    _.get(props.config.buildsConfig, "hiddenBuilds", [])
  );

  const handleSaveBuilds = (hiddenBuildsList = []) => {
    const newConfig = _.cloneDeep(props.config);

    newConfig.buildsConfig = {
      buildsNomenclature: buildsNomenclature,
      hiddenBuilds: hiddenBuildsList,
    };

    props.updateReportConfig(newConfig);
  };

  const handleBuildsNameCheck = (tag, event) => {
    const newBuildsNomenclature = _.cloneDeep(buildsNomenclature);
    newBuildsNomenclature[tag] = { show: event.target.checked };
    setBuildsNomenclature(newBuildsNomenclature);
  };

  const handleOpenBuilds = (flag) => {
    setOpenBuilds(flag);
  };

  const handleBuildsCancel = () => {
    setBuildsNomenclature(
      _.get(props.config.buildsConfig, "buildsNomenclature", {})
    );
    handleOpenBuilds(false);
  };

  const buildColumnFormater = (cell, formatterParams, onRendered) => {
    return getBuildsNomenclature(
      cell.getValue(),
      buildsNomenclature,
      _.get(cell.getData(), "LABEL", "")
    );
  };

  //Plotting
  let addWidgets = (wProps) => {
    console.log(wProps);
    for (let i = 0; i < wProps.widgets.length; i++) {
      const widgetsSettings = produce(wProps.widgets[i], (settingsDraft) => {
        console.log(settingsDraft);
        delete settingsDraft.currentReportName;
        delete settingsDraft.data;
      });

      const data = _.get(wProps.widgets[i], "data", {});
      console.log(data);
      addWidgetCommonFunction(
        props.rptType,
        props.reportKey,
        widgetsSettings,
        data,
        showWidgetDataUiState,
        props.index
      );
    }
  };

  let plot = (e, row) => {
    const buildName = row.getData().buildName;
    const checkpoint = row.getData().checkpoint;
    const clicked = e.target.innerText;
    let titleElement = null;
    // console.log(clicked, checkpoint, buildName);
    let args = null;
    let rows = null;
    let rowsData = [];
    for (let i in customContexts) {
      if (clicked == customContexts[i].label) {
        args = customContexts[i].args;
      }
    }
    console.log(e.target.innerText, args);
    if (args.X == "builds") {
      rows = tableInst.getRows().filter((r) => {
        return r.getData().checkpoint == checkpoint;
      });
      titleElement = "Common Checkpoint: " + checkpoint;
    } else {
      rows = tableInst.getRows().filter((r) => {
        return r.getData().buildName == buildName;
      });
      titleElement = "Common Build: " + buildName;
    }
    // rows = tableInst.getRows();
    for (let id in rows) {
      rowsData.push(rows[id].getData());
    }
    axios
      .post(metricsURL + "calcBarLineCharts/", {
        buildName: buildName,
        checkpoint: checkpoint,
        args: args,
        rows: rowsData,
      })
      .then((response) => {
        let status = _.get(response.data, "status", false);
        if (status) {
          let data = _.get(response.data, "data", []);
          const yCoord = props.widgetProps.y;
          const currentReportName = props.widgetProps;
          // console.log(props.widgetProps);
          let _title = props.widgetprops.config.savedReportConfig[
            props.config.currentReport
          ].title
            ? props.widgetprops.config.savedReportConfig[
                props.config.currentReport
              ].title
            : "Metrics";
          addWidgets({
            widgets: [
              {
                name: "Metrics Group Bar Chart",
                reportName: props.reportKey, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Bar/Line chart : For Metrics-(Parent Widget:${_title}, ${titleElement})`,
                  dataLocation: "dataLocation",
                  bucket: "bucket",
                  data: "",
                  columns: [],
                  // query: _.get(data, "query", defaultQueryBody),
                  groupingAxis: args.X == "Y",
                },
                data: data,
              },
            ],
          });
        } else {
          let message = _.get(response.data, "message", "");
          console.log(message);
        }
      })
      .catch((error) => {
        console.log(error);
      });
    // let data = calculateChartData(buildName, checkpoint, args, rowsData)
  };

  let parseQueryContextMenus = () => {
    let _query =
      props.config.savedReportConfig[props.config.currentReport]?.query;
    // let customMenu = [];
    if (_query != undefined && _query != null) {
      var lines = _query.split("\n");
      var filterred = lines.filter(function (line) {
        return line.indexOf("#") != 0;
      });
      console.log(String(filterred));
      _query = String(filterred).replace(/\s/g, ""); //.replaceAll("'", "|").replaceAll('"', "|");
      const pattern = new RegExp(
        '{"label":"(?<label>[\\w\\/-]+?)","action":"(?<action>\\w+?)","args":{"type":"(?<type>\\w+?)","Y":"(?<Y>\\w+?)","X":"(?<X>\\w+?)"}}',
        "g"
      );
      const cMenus = [..._query.matchAll(pattern)].map((item) => item.groups);
      // console.log(cMenus);
      for (let i in cMenus) {
        if (cMenus[i].action == "plot") {
          if (customContexts.length > 0) {
            let index = customContexts.findIndex(
              (x) => x.label == cMenus[i].label
            );
            index === -1
              ? customContexts.push({
                  label: cMenus[i].label,
                  action: plot,
                  args: {
                    type: cMenus[i].type,
                    Y: cMenus[i].Y,
                    X: cMenus[i].X,
                  },
                })
              : console.log("Exist");
          } else {
            customContexts.push({
              label: cMenus[i].label,
              action: plot,
              args: { type: cMenus[i].type, Y: cMenus[i].Y, X: cMenus[i].X },
            });
          }
        }
        console.log(cMenus[i]);
      }
    }
    return customContexts;
  };

  const getRowContextMenu = () => {
    let plotContextMenu = null;
    plotContextMenu = parseQueryContextMenus(
      props.config.savedReportConfig[props.config.currentReport]?.query
    );
    console.log(plotContextMenu);
    return plotContextMenu;
  };

  let rowMouseEnter = (e, row) => {
    if (tableInst == null) {
      return;
    }
    // Deselect all rows styles
    if (prevRowHighlighted != null) {
      for (let id in prevRowHighlighted) {
        prevRowHighlighted[id].getElement().style.borderColor = "#cccccc";
        // prevRowHighlighted[id].getElement().style.color = "#333333";
      }
    }
    // const selctedRow = tableInst.getSelectedRows();
    // if(selctedRow){
    //     for (let i in selctedRow) {
    //         selctedRow[i].getElement().style.backgroundColor = "pink";
    //     }
    // }

    if (true) {
      let hoverCheckpoint = row.getData().checkpoint;
      let rows = tableInst.getRows().filter((r) => {
        return r.getData().checkpoint == hoverCheckpoint;
      });
      prevRowHighlighted = rows;
      for (let id in rows) {
        rows[id].getElement().style.borderColor = "blue";
        // rows[id].getElement().style.color = "white";
      }
    }
  };

  const addColumn = ({
    rootGroupObj = {},
    col = {},
    groupEnable = false,
    groupNames = [],
    groupContextMenu = [],
    headerAttrObj = {},
  } = {}) => {
    let nextRootGroupObj = _.cloneDeep(rootGroupObj);

    let headerTooltip = col.headerTooltip;

    if (groupEnable == false || groupNames.length == 0) {
      // Group processing NOT needed.
      nextRootGroupObj.columns.push(col);
    } else {
      // Group processing needed.
      let parentGroupObj = nextRootGroupObj;
      let lastGroupObj;

      for (let i = 0; i < groupNames.length; i++) {
        let groupName = groupNames[i];

        let newGroupObj = {
          title: groupName,
          columns: [],
          headerTooltip: headerTooltip,
        };

        if (groupContextMenu.length != 0) {
          newGroupObj.headerContextMenu = groupContextMenu;
        }

        for (let attr in headerAttrObj) {
          newGroupObj[attr] = headerAttrObj[attr];
        }

        if (parentGroupObj.columns.length == 0) {
          parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
        }
        lastGroupObj =
          parentGroupObj.columns[parentGroupObj.columns.length - 1];

        if (i != groupNames.length - 1) {
          // This is NOT the last groupName
          if (
            lastGroupObj.title == groupName &&
            lastGroupObj.hasOwnProperty("columns")
          ) {
          } else {
            parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
            lastGroupObj =
              parentGroupObj.columns[parentGroupObj.columns.length - 1];
          }
          parentGroupObj = lastGroupObj;
        } else {
          // This is the last groupName
          if (
            lastGroupObj.title == groupName &&
            lastGroupObj.hasOwnProperty("columns")
          ) {
          } else {
            parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
            lastGroupObj =
              parentGroupObj.columns[parentGroupObj.columns.length - 1];
          }
          lastGroupObj.columns.push(col);
        }
      }
    }

    return nextRootGroupObj;
  };

  const isSpecialMetric = (name) => {
    let specialMetrics = [];
    specialMetrics.push("__latestCheckpointName");
    specialMetrics.push("__latestCheckpointUser");
    specialMetrics.push("__latestCheckpointDate");

    let match = false;
    for (let specialMetric of specialMetrics) {
      if (name == specialMetric) {
        match = true;
      }
    }
    return match;
  };

  const getGroupNames = (groupName) => {
    let groupNames;
    if (groupName == null || groupName == "") {
      groupNames = [];
    } else {
      let textToSplit = groupName;
      groupNames = [];
      // Note: "^" is the separator char
      // Note: "`" is the blank char
      for (let name of textToSplit.split("^")) {
        if (name == "`") {
          name = "";
        }
        groupNames.push(name);
      }
    }
    return groupNames;
  };

  let dateFormatter = (cell, formatterParams, onRendered) => {
    if (cell.getField() == "timeStop") {
      let seconds = cell.getValue();
      if (seconds) {
        return dateFromSeconds(seconds);
      } else {
        return ".";
      }
    } else {
      return cell.getValue();
    }
  };

  var hideColumn = [
    {
      label: "Hide Column",
      action: function (e, column) {
        e.stopPropagation();
        column.hide();
      },
    },
  ];

  const getColor = (cell) => {
    let element = cell.getElement();
    let field = cell.getColumn().getField();
    let rowData = cell.getRow().getData();

    const colors = { foreground: "#000000", background: "#ffffff" };
    if (rowData.colors) {
      colors.foreground = _.get(rowData.colors[field], "foreground", "#000000");
      colors.background = _.get(rowData.colors[field], "background", "#ffffff");
    }
    return colors;
  };

  const getLinks = (cell) => {
    let field = cell.getField();
    let rowData = cell.getData();

    if (rowData?.links?.[field]) {
      return rowData.links[field];
    }
    return null;
  };

  const cellFormatter = (cell, formatterParams, onRendered) => {
    let element = cell.getElement();

    let cellValue = cell.getValue();

    let displayValue = null;

    if (typeof cellValue == "string") {
      let value = cellValue.split(/\|\|\|/);
      displayValue = value[0];
    } else if (Array.isArray(cellValue)) {
      displayValue = cellValue[0];
    } else {
      displayValue = cellValue;
    }

    // let fg = funcs.palette("Default").fg;
    // let bg = funcs.palette("Default").bg;

    // if (getLinks(cell)) {
    //   var a = document.createElement("i");
    //   var linkText = document.createTextNode(cellValue);
    //   a.appendChild(linkText);
    //   a.title = cellValue;

    //   onRendered(function () {
    //     element.appendChild(a);
    //   });
    // } else {
    // let newDiv = document.createElement("div");
    // newDiv["innerHTML"] = displayValue != undefined ? displayValue : "";
    // onRendered(function () {
    //   element.appendChild(newDiv);
    // });
    // }

    // const colors = getColor(cell);
    // if (colors) {
    //   element.style.color = colors.foreground;
    //   element.style.backgroundColor = colors.background;
    // } else {
    //   element.style.color = "black";
    //   element.style.backgroundColor = "white";
    // }

    let refValue = null;

    const col = cell.getColumn().getDefinition().field.split("__")[1];
    // console.log(value);
    // let defaultColorRule = getDefaultRefValueIfExist(col);
    var colorRules = getColoringRules(
      col,
      cell.getData()["BLOCK"],
      cell.getData()["checkpoint"]
    );
    if (colorRules && colorRules["refValue"] != null) {
      refValue = colorRules["refValue"];
    }
    // console.log(props.config.savedReportConfig[props.config.currentReport].selectedRepSpec);
    if (isNumber(cellValue) && colorRules) {
      // console.log(refValue, colorRules);
      let result = calcCell(
        "",
        cellValue,
        refValue,
        colorRules,
        false,
        "VALUE"
      );
      // console.log(result.colors.bg);
      cell.getElement().style.background = result.colors.bg;
      cell.getElement().style.color = result.colors.fg;
    }

    return displayValue;
  };

  const getColumns = () => {
    let col = null;
    let rootGroupObj = {};
    rootGroupObj.title = null;
    rootGroupObj.columns = [];
    col = {
      title: "Block",
      field: "BLOCK",
      headerSort: false,
      frozen: true,
      visible: true,
      headerFilter: customInput,
      headerFilterFunc: globFilterDisplayValue,
      headerTooltip: customFilterDisplayValueTooltip,
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });
    col = {
      title: "Build",
      field: "buildName",
      headerSort: false,
      frozen: true,
      visible: true,
      headerContextMenu: hideColumn,
      headerFilter: customInput,
      headerFilterFunc: globFilterDisplayValue,
      headerTooltip: customFilterDisplayValueTooltip,
      formatter: buildColumnFormater,
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });
    let Metrics =
      props.reportSpec.reportNames[props.config.currentReport].metrics;

    for (let metricName of Object.keys(Metrics)) {
      let itemM = Metrics[metricName];
      if (itemM) {
        let visible = !itemM.hidden;
        let fieldName = "";
        let temp = itemM["indexList"];
        // console.log(temp);
        let displayName = itemM.displayName;
        if (!displayName) {
          displayName = metricName.includes("|")
            ? metricName.split("|")[1]
            : metricName; // colConfig[col]["displayName"]
        }
        let groupName = itemM.groupName;
        if (temp && temp.length > 7) {
          fieldName = temp[5] + "__" + temp[7];
        } else if (temp && temp.length > 4) {
          fieldName = temp[4].toLowerCase();
        } else {
          if (displayName.toLowerCase() == "user") {
            fieldName = "USER";
            // fieldName = 'system__' + displayName.toLowerCase();
          } else if (displayName.toLowerCase() == "date") {
            fieldName = "timeStop";
            // fieldName = 'system__timeStopHuman';
          } else {
            fieldName = displayName.toLowerCase();
          }
        }

        let groupNames = getGroupNames(groupName);

        if (isSpecialMetric(metricName)) {
          let col = {
            title: displayName,
            field: fieldName,
            sorter: true,
            visible: !_.get(
              _.get(metrics, metricName, { hidden: false }),
              "hidden",
              false
            ),
            headerSort: true,
            headerSortTristate: true,
            headerFilter: customInput,
            headerFilterFunc: customFilterDisplayValue,
            formatter: dateFormatter,
            headerContextMenu: hideColumn,
            headerTooltip: customFilterDisplayValueTooltip,
          };

          rootGroupObj = addColumn({
            rootGroupObj: rootGroupObj,
            col: col,
            groupEnable: true,
            groupNames: groupNames,
          });
        } else {
          let col = {
            title: displayName,
            field: fieldName,
            visible: !_.get(
              _.get(metrics, fieldName.split("__")[1], { hidden: false }),
              "hidden",
              false
            ),
            sorter: true,
            headerSort: true,
            headerSortTristate: true,
            headerFilter: customInput,
            headerFilterFunc: customFilterDisplayValue,
            headerContextMenu: hideColumn,
            formatter: (cell, formatterParams, onRendered) =>
              cellFormatter(cell, formatterParams, onRendered),

            headerTooltip: customFilterDisplayValueTooltip,
          };

          rootGroupObj = addColumn({
            rootGroupObj: rootGroupObj,
            col: col,
            groupEnable: true,
            groupNames: groupNames,

            // groupContextMenu: headerContextMenuGroup,
          });
        }
      }
    }

    return rootGroupObj.columns;
  };

  const getInitialPageSize = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence")
      ? _.get(reportConfig.tablePersistence, "size", 25)
      : 25;
  };

  const getInitialPage = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence")
      ? _.get(reportConfig.tablePersistence, "page", 1)
      : 1;
  };

  const getInitialSorters = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence")
      ? _.get(reportConfig.tablePersistence, "sorters")
      : [];
  };

  const getInitialFilter = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence")
      ? _.get(reportConfig.tablePersistence, "filters")
      : [];
  };

  const persistTable = (filters = [], sorters = [], size = 25, page = 1) => {
    const newReportConfig = _.cloneDeep(
      props.config.savedReportConfig[props.config.currentReport]
    );
    if (!newReportConfig.hasOwnProperty("tablePersistence")) {
      newReportConfig.tablePersistence = {};
    }

    // set filters
    let uniqueFields = [];
    const cleanFilters = filters.map((filter) => {
      const newFilter = { ...filter };
      newFilter.type = "in";
      return newFilter;
    });

    const uniqueFilters = cleanFilters.filter((filter) => {
      if (uniqueFields.includes(_.get(filter, "field", ""))) {
        return false;
      }
      uniqueFields.push(_.get(filter, "field", ""));
      return true;
    });

    newReportConfig.tablePersistence.filters = uniqueFilters;
    //end setting filters

    // set sorters
    uniqueFields = [];
    const cleanSorters = sorters.map((sorter) => {
      const newSorter = { ...sorter };
      delete newSorter.column;
      newSorter.column = newSorter.field;
      delete newSorter.field;
      return newSorter;
    });

    const uniqueSorters = cleanSorters.filter((sorter) => {
      if (uniqueFields.includes(_.get(sorter, "field", ""))) {
        return false;
      }
      uniqueFields.push(_.get(sorter, "field", ""));
      return true;
    });

    newReportConfig.tablePersistence.sorters = uniqueSorters;
    // end setting sorters

    //set size
    newReportConfig.tablePersistence.size = size;

    //set page
    newReportConfig.tablePersistence.page = page;

    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[newConfig.currentReport] = newReportConfig;

    //update report config without rerender
    props.updateReportConfig(newConfig, false);
  };

  const handleDownload = (fileFormat) => {
    const config = props.config;
    const input = {
      selectedBuilds: props.buildSpec,
      report: props.reportSpec.reportNames[config.currentReport],
      reportSpecName: config.reportSpecName,
      reportName: config.currentReport,
      hierSpec: config?.selectedHierSpecData,
      auth: {
        user: _.get(useConfigStore.getState(), "authLoginUser", ""),
      },
      fileFormat: fileFormat,
      hiddenBuilds: hiddenBuilds,
      groupBy: getRowGroupValue(
        props.config.savedReportConfig[props.config.currentReport].rowOrg
      ),
      metricsConfigs: metrics,
      // rawQuery: _.get(props.config, "query", ""),
      // variables: _.get(props.config, "wVariables", {}),
    };
    axios
      .post(metricsURL + "downloadRunMetricsQuery/", input, {
        responseType: "blob",
      })
      .then((responseData) => {
        const blob = new Blob([responseData.data], {
          type: responseData.headers["Content-Type"],
        });

        const url = window.URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.href = url;
        link.setAttribute(
          "download",
          `${props.config.currentReportName}.${fileFormat}`
        );

        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);
      })
      .catch((error) => {
        console.log(error);
      });
    setOpenDownloadMenu(false);
    setAnchorEl(null);
  };

  let getDefaultRefValueIfExist = (col) => {
    let defColumns =
      props.reportSpec.reportNames[props.config.currentReport].coloringRules
        .defaultBlock.defaultCheckpoint;

    if (col in defColumns) {
      return defColumns[col];
    }
    return null;
  };

  const getColoringRules = (col, block, checkpoint) => {
    let coloringRules = _.cloneDeep(funcs.defaultColorRule);
    let metricColoringRule = _.cloneDeep(
      _.get(
        props.reportSpec.reportNames[props.config.currentReport].metrics[col],
        "colorRule",
        funcs.defaultColorRule
      )
    );
    const coloringRulesSection =
      props.reportSpec.reportNames[props.config.currentReport].coloringRules;

    let rulesFromColoringRulesSection = _.cloneDeep(funcs.defaultColorRule);
    // if block and checkpoint is defined in the coloring rules section then apply that
    if (
      coloringRulesSection.hasOwnProperty(block) &&
      Object.keys(coloringRulesSection[block]).length &&
      coloringRulesSection[block].hasOwnProperty(checkpoint) &&
      Object.keys(coloringRulesSection[block][checkpoint]).length &&
      coloringRulesSection[block][checkpoint].hasOwnProperty(col)
    ) {
      rulesFromColoringRulesSection =
        coloringRulesSection[block][checkpoint][col];
      coloringRules = _.merge(
        metricColoringRule,
        rulesFromColoringRulesSection
      );
    }
    //otherwise get default block and default checkpoint colors
    else if (
      coloringRulesSection.hasOwnProperty("defaultBlock") &&
      Object.keys(coloringRulesSection["defaultBlock"]).length &&
      coloringRulesSection["defaultBlock"].hasOwnProperty(
        "defaultCheckpoint"
      ) &&
      Object.keys(coloringRulesSection["defaultBlock"]["defaultCheckpoint"])
        .length &&
      coloringRulesSection["defaultBlock"]["defaultCheckpoint"].hasOwnProperty(
        col
      )
    ) {
      rulesFromColoringRulesSection =
        coloringRulesSection["defaultBlock"]["defaultCheckpoint"][col];
      coloringRules = _.merge(
        metricColoringRule,
        rulesFromColoringRulesSection
      );
    }
    // if default checkpoint also does not exist then return the metric coloring rules
    else {
      coloringRules = metricColoringRule;
    }
    return coloringRules;
  };

  const getRowGroupOptionValues = (rowGroups) => {
    let groupValues = [];
    for (let [rowGroup, rowGroupValue] of Object.entries(rowGroups)) {
      if (rowGroupValue) {
        let groupList = [];
        for (let [group, groupValue] of Object.entries(rowGroupValue)) {
          groupList.push(_.get(groupValue, "fieldName", ""));
        }
        groupValues.push({ value: rowGroup, title: rowGroup });
      } else {
        groupValues.push({ value: [], title: rowGroup });
      }
    }
    return groupValues;
  };

  const getRowGroupValue = (rowGroupOption) => {
    let groupValues = [];
    const rowGroup = _.get(
      props.reportSpec.reportNames[props.config.currentReport].rowGroupOptions,
      rowGroupOption,
      {}
    );
    if (rowGroup) {
      for (let [group, groupValue] of Object.entries(rowGroup)) {
        groupValues.push(_.get(groupValue, "fieldName", ""));
      }
    }
    return groupValues;
  };

  const saveFormatOptions = () => {
    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[props.config.currentReport] = reportConfig;
    props.updateReportConfig(newConfig);
    setShowFormat(false);
  };

  const handleFormatChange = (formatKey, formatValue) => {
    const newReportConfig = _.cloneDeep(reportConfig);
    newReportConfig[formatKey] = formatValue;
    setReportConfig(newReportConfig);
  };

  const getReportMenu = () => {
    return (
      <div id="reportMenu" style={{ width: "100%", height: "30px" }}>
        <ButtonGroup size="small" variant="text">
          <Chip
            label={props.config.currentReportName}
            sx={{ height: "28px" }}
            onClick={() => {
              props.handleReportsPane(true);
            }}
            variant={"outlined"}
          />
          <Button
            // variant="outlined"
            size="small"
            onClick={() => {
              setShowFormat(true);
              setReportConfig(
                props.config.savedReportConfig[props.config.currentReport]
              );
            }}
          >
            Format
          </Button>
          <Button
            id="demo-customized-button"
            aria-controls={
              openDownloadMenu ? "demo-customized-menu" : undefined
            }
            aria-haspopup="true"
            aria-expanded={openDownloadMenu ? "true" : undefined}
            size="small"
            onClick={(event) => {
              setOpenDownloadMenu(true);
              setAnchorEl(event.currentTarget);
            }}
            endIcon={<KeyboardArrowDownIcon />}
          >
            Download
          </Button>
          <StyledMenu
            id="demo-customized-menu"
            MenuListProps={{
              "aria-labelledby": "demo-customized-button",
            }}
            anchorEl={anchorEl}
            open={openDownloadMenu}
            onClose={() => {
              setOpenDownloadMenu(false);
              setAnchorEl(null);
            }}
          >
            <MenuItem
              onClick={() => {
                handleDownload("xlsx");
              }}
              disableRipple
            >
              XLS
            </MenuItem>
            <MenuItem
              onClick={() => {
                handleDownload("csv");
              }}
              disableRipple
            >
              CSV
            </MenuItem>
          </StyledMenu>
          <Button onClick={() => handleOpenMetrics(true)}>Metrics</Button>
          <Button onClick={() => handleOpenBuilds(true)}>Builds</Button>
        </ButtonGroup>
        {
          <Box>
            <Modal open={showFormat} container={dashboartRef.current}>
              <Box
                sx={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  width: "400px",
                  height: "auto",
                  bgcolor: "background.paper",
                  border: "2px solid #000",
                  boxShadow: 24,
                  borderRadius: "15px",
                  p: 2,
                }}
              >
                <Box>
                  <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                    Format Report
                  </Typography>
                </Box>
                <Divider />
                <Stack spacing={2}>
                  <FormControl>
                    <InputLabel>Row Org</InputLabel>
                    <Select
                      value={_.get(reportConfig, "rowOrg", [])}
                      label="Row Org"
                      onChange={(e) => {
                        handleFormatChange("rowOrg", e.target.value);
                      }}
                      size={"small"}
                    >
                      {getRowGroupOptionValues(
                        props.reportSpec.reportNames[props.config.currentReport]
                          .rowGroupOptions
                      ).map((item) => (
                        <MenuItem value={item.value}>{item.title}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Stack>
                <Divider />
                <ButtonGroup
                  size={"small"}
                  variant="contained"
                  sx={{ float: "right", marginTop: "10px" }}
                >
                  <Button onClick={() => saveFormatOptions()}>Save</Button>
                  <Button onClick={() => setShowFormat(false)}>Cancel</Button>
                </ButtonGroup>
              </Box>
            </Modal>
            <Modal open={openBuilds} container={dashboartRef.current}>
              <Builds
                buildsNomenclature={buildsNomenclature}
                handleBuildsNameCheck={handleBuildsNameCheck}
                handleSaveBuilds={handleSaveBuilds}
                handleCancle={handleBuildsCancel}
                hiddenBuilds={hiddenBuilds}
              />
            </Modal>
          </Box>
        }
      </div>
    );
  };

  const handleOpenMetrics = (flag) => {
    setOpenMetric(flag);
  };

  const handleMetricVisibilityCheck = (metric, event) => {
    const newMetrics = _.cloneDeep(metrics);
    newMetrics[metric] = { hidden: !event.target.checked };
    setMetrics(newMetrics);
  };

  const handleSaveMetrics = () => {
    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[newConfig.currentReport].metricsConfig =
      metrics;
    props.updateReportConfig(newConfig);
  };

  const handleAllMetricVisbility = (flag) => {
    const newMetrics = _.cloneDeep(metrics);
    for (let [metricKey, metric] of Object.entries(newMetrics)) {
      newMetrics[metricKey] = { hidden: !flag };
    }
    setMetrics(newMetrics);
  };

  const getModals = () => {
    return (
      <Box>
        <Modal open={openMetrics} container={dashboartRef.current}>
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: "80%",
              height: "100%",
              bgcolor: "background.paper",
              border: "2px solid #000",
              boxShadow: 24,
              borderRadius: "15px",
              p: 2,
            }}
          >
            <Box id="Metrics_Box" sx={{ height: "100%" }}>
              <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                Metrics
              </Typography>
              <Divider />
              <Box sx={{ height: "calc(100% - 93px)" }}>
                <FormGroup sx={{ overflow: "auto", height: "100%" }}>
                  {_.map(metrics, (metric, metricKey) => (
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={!_.get(metric, "hidden", false)}
                          onChange={(event) =>
                            handleMetricVisibilityCheck(metricKey, event)
                          }
                          // defaultChecked={!_.get(metric, "hidden", false)}
                        />
                      }
                      label={
                        _.get(
                          props.reportSpec.reportNames[
                            props.config.currentReport
                          ].metrics[metricKey],
                          "groupName",
                          _.get(
                            _.get(props.reportSpec.metrics, metricKey, {}),
                            "groupName",
                            ""
                          )
                        ) +
                        " || " +
                        _.get(
                          metric,
                          "displayName",
                          _.get(
                            _.get(props.reportSpec.metrics, metricKey, {}),
                            "displayName",
                            metricKey
                          )
                        )
                      }
                    />
                  ))}
                </FormGroup>
              </Box>
              <Divider />
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "left", marginTop: "10px" }}
              >
                <Button
                  onClick={() => {
                    handleAllMetricVisbility(true);
                  }}
                >
                  Show All
                </Button>
                <Button
                  onClick={() => {
                    handleAllMetricVisbility(false);
                  }}
                >
                  Hide All
                </Button>
              </ButtonGroup>
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "right", marginTop: "10px" }}
              >
                <Button
                  onClick={() => {
                    handleSaveMetrics();
                  }}
                >
                  Save
                </Button>
                <Button
                  onClick={() => {
                    setMetrics(
                      _.get(
                        props.config.savedReportConfig[
                          props.config.currentReport
                        ],
                        "metricsConfig",
                        {}
                      )
                    );
                    handleOpenMetrics(false);
                  }}
                >
                  Cancel
                </Button>
              </ButtonGroup>
            </Box>
          </Box>
        </Modal>
      </Box>
    );
  };

  useEffect(() => {
    // console.log(props.config.savedReportConfig[props.config.currentReport]);
    const initTable = async () => {
      var columns = getColumns();
      const config = _.get(props, "config", {});

      const initialFilters = _.cloneDeep(getInitialFilter());
      const initialPageSize = getInitialPageSize();
      const initialPage = getInitialPage();
      const persistentSorters = getInitialSorters();
      const initialSorters = _.cloneDeep(persistentSorters);

      if (tableInst === null) {
        tableInst = new Tabulator(tableRef, {
          // className: "table-sm table-striped table-bordered",
          layout: "fitDataStretch",
          //rowHeight: 40,
          // selectable: true,
          initialHeaderFilter: initialFilters,
          initialSort: initialSorters,
          paginationInitialPage: initialPage,
          pagination: true, //enable pagination
          paginationMode: "remote", //enable remote pagination
          sortMode: "remote",
          filterMode: "remote",
          ajaxConfig: "POST",
          paginationSize: initialPageSize,
          paginationSizeSelector: [10, 25, 50, 100, 200],
          paginationCounter: "rows",
          ajaxURL: metricsURL + "runMetricsQuery/",
          ajaxContentType: "json",
          ajaxParams: {
            metricsConfigs: metrics,
            selectedBuilds: props.buildSpec,
            report: props.reportSpec.reportNames[config.currentReport],
            reportSpecName: config.reportSpecName,
            reportName: config.currentReport,
            hierSpec: config?.selectedHierSpecData,
            auth: {
              user: _.get(useConfigStore.getState(), "authLoginUser", ""),
            },
            groupBy: getRowGroupValue(
              props.config.savedReportConfig[props.config.currentReport].rowOrg
            ),
            metricsConfigs: metrics,
            hiddenBuilds: hiddenBuilds,
            hiddenCheckpoints: _.get(
              props.config,
              ["checkpointsConfig", "hiddenCheckpoints"],
              []
            ),
            // rawQuery: _.get(props.config, "query", ""),
            // variables: _.get(props.config, "wVariables", {}),
          },
          ajaxResponse: (url, params, responseData) => {
            persistTable(
              _.get(params, "filter", []),
              _.get(params, "sort", []),
              _.get(params, "size", 25),
              _.get(params, "page", 1)
            );
            const tabulatorLoreFormat = {
              data: responseData.rows ? responseData.rows : [],
              last_page: responseData.lastPage ? responseData.lastPage : 0,
              last_row: _.get(
                responseData,
                "completeCount",
                _.get(responseData, "lastPage", 0) * 25
              ),
            };
            return tabulatorLoreFormat;
          },

          movableRows: true,
          rowContextMenu: getRowContextMenu,
          columns: columns ? columns : [],
          // data: rows ? rows : [],
          height: "100%",
          width: "100%",
          groupBy: getRowGroupValue(
            props.config.savedReportConfig[props.config.currentReport].rowOrg
          ),
          // groupToggleElement: "header",
          columnDefaults: {
            headerFilterPlaceholder: "...",
            headerFilterLiveFilter: false,
            tooltip: function (e, cell, onRendered) {
              //e - mouseover event
              //cell - cell component
              //onRendered - onRendered callback registration function

              var el = document.createElement("div");
              el.style.backgroundColor = "rgba(97,97,97)";
              el.style.color = "white";
              el.style.height = "auto";
              el.style.padding = "5px";
              el.style.minHeight = "20px";
              el.style.borderRadius = "10px";
              el.style.opacity = 0.92;
              el.innerText = cell.getValue(); //return cells "field - value";

              return el;
            },
            resizable: true,
          },
        });
        // tableInst.on("rowMouseEnter", rowMouseEnter);
        // tableInst.on("rowClick", rowClick);
        // tableInst.on("tableBuilt", afterTableBuilt);
        // tableInst.on("groupVisibilityChanged", afterTableBuilt);
      } else {
        console.log("Table replace data");
        // tableInst.replaceData(rows);
        // this.resizeTable();
      }
    };

    initTable();
  }, []);

  return (
    // <h1>I am table</h1>
    <>
      <div
        id="buildsDashboard"
        ref={(ref) => (dashboartRef.current = ref)}
        style={{ width: "100%", height: "100%" }}
      >
        {getReportMenu()}
        {getModals()}
        <div
          id="analytics"
          style={{ width: "100%", height: "calc(100% - 30px)" }}
        >
          <div
            //   id="divConfigMainTable"
            //   className="divStandardBackgroundColor"
            // className= "table-bordered"
            style={{ width: "inherit" }}
            ref={(r) => {
              tableRef = r;
            }}
          ></div>
        </div>
      </div>
    </>
  );
}
