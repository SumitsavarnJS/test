import React from "react";
import { useState, useEffect, useRef, memo } from "react";
import { shallow } from "zustand/shallow";
import { produce } from "immer";
// import { ReactTabulator } from "react-tabulator";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import Builds from "../dialogs/BuildsModal";

import axios from "axios";
import _ from "lodash";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

//color
import { calcCell, _colors, palette } from "../../../../../common/color";
import {
  dateFromSeconds,
  elapsedTimeFromSeconds,
} from "../../../../../common/time";
import useConfigStore from "../../../../../store/useConfigStore";
import useGlobalStore from "../../../../../store/useGlobalStore";

import * as utils from "../../../../../common/utils/utils";

import { tags } from "../../../../../constants/constants";
import { getBuildsNomenclature } from "../../../../../common/utils/utils";

import {
  Box,
  Button,
  ButtonGroup,
  Checkbox,
  Chip,
  Divider,
  FormControlLabel,
  FormGroup,
  Modal,
  Typography,
} from "@mui/material";

import {
  customInput,
  globMatch,
  customFilterDisplayValue,
  globFilterDisplayValue,
} from "../../../../../common/filter";
import {
  customFilterDisplayValueTooltip,
  globFilterDisplayValueTooltip,
} from "../../../../../common/tooltip";

import {
  addWidgetCommonFunction,
  showConfigUiState,
  showWidgetDataUiState,
  widgets,
} from "../../../../../pages/rptdashboard/addWidget/addWidget";
import Checkpoints from "../dialogs/CheckpointsModal";

function ProfileReport(props) {
  let tableRef = React.createRef();
  let tableInst = null;
  let buildInfo = {};
  let configBuildsWithBuildname = [];
  let [tableData, setTableData] = useState([]);
  let customContexts = [];
  let selectedRows = [];
  let c = [];
  let r = [];
  const metricsURL =
    useConfigStore.getState().configData.rest_server_url + "/metrics/";

  const [openBuilds, setOpenBuilds] = useState(false);
  const [buildsNomenclature, setBuildsNomenclature] = useState(
    _.get(props.config.buildsConfig, "buildsNomenclature", {})
  );

  const isNumber = (value) => {
    return !isNaN(value) && !isNaN(parseFloat(value));
  };

  const profileRef = useRef(null);

  const [hiddenBuilds, setHiddenBuilds] = useState(
    _.get(props.config.buildsConfig, "hiddenBuilds", [])
  );

  const handleSaveBuilds = (hiddenBuildsList = []) => {
    const newConfig = _.cloneDeep(props.config);

    newConfig.buildsConfig = {
      buildsNomenclature: buildsNomenclature,
      hiddenBuilds: hiddenBuildsList,
    };

    props.updateReportConfig(newConfig);
  };
  const handleBuildsNameCheck = (tag, event) => {
    const newBuildsNomenclature = _.cloneDeep(buildsNomenclature);
    newBuildsNomenclature[tag] = { show: event.target.checked };
    setBuildsNomenclature(newBuildsNomenclature);
  };

  const handleOpenBuilds = (flag) => {
    setOpenBuilds(flag);
  };

  const handleBuildsCancel = () => {
    setBuildsNomenclature(
      _.get(props.config.buildsConfig, "buildsNomenclature", {})
    );
    handleOpenBuilds(false);
  };

  const handleCheckpointCancel = () => {
    props.handleOpenCheckpoint(false);
  };

  const addColumn = ({
    rootGroupObj = {},
    col = {},
    groupEnable = false,
    groupNames = [],
    groupContextMenu = [],
    headerAttrObj = {},
  } = {}) => {
    let nextRootGroupObj = _.cloneDeep(rootGroupObj);

    let headerTooltip = col.headerTooltip;

    if (groupEnable == false || groupNames.length == 0) {
      // Group processing NOT needed.
      nextRootGroupObj.columns.push(col);
    } else {
      // Group processing needed.
      let parentGroupObj = nextRootGroupObj;
      let lastGroupObj;

      for (let i = 0; i < groupNames.length; i++) {
        let groupName = groupNames[i];

        let newGroupObj = {
          title: groupName,
          columns: [],
          headerTooltip: headerTooltip,
        };

        if (groupContextMenu.length != 0) {
          newGroupObj.headerContextMenu = groupContextMenu;
        }

        for (let attr in headerAttrObj) {
          newGroupObj[attr] = headerAttrObj[attr];
        }

        if (parentGroupObj.columns.length == 0) {
          parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
        }
        lastGroupObj =
          parentGroupObj.columns[parentGroupObj.columns.length - 1];

        if (i != groupNames.length - 1) {
          // This is NOT the last groupName
          if (
            lastGroupObj.title == groupName &&
            lastGroupObj.hasOwnProperty("columns")
          ) {
          } else {
            parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
            lastGroupObj =
              parentGroupObj.columns[parentGroupObj.columns.length - 1];
          }
          parentGroupObj = lastGroupObj;
        } else {
          // This is the last groupName
          if (
            lastGroupObj.title == groupName &&
            lastGroupObj.hasOwnProperty("columns")
          ) {
          } else {
            parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
            lastGroupObj =
              parentGroupObj.columns[parentGroupObj.columns.length - 1];
          }
          lastGroupObj.columns.push(col);
        }
      }
    }

    return nextRootGroupObj;
  };

  const getGroupNames = (groupName) => {
    let groupNames;
    if (groupName == null || groupName == "") {
      groupNames = [];
    } else {
      let textToSplit = groupName;
      groupNames = [];
      // Note: "^" is the separator char
      // Note: "`" is the blank char
      for (let name of textToSplit.split("^")) {
        if (name == "`") {
          name = "";
        }
        groupNames.push(name);
      }
    }
    return groupNames;
  };

  let globFilterFirstColumn = (headerValue, rowValue, rowData) => {
    let match = false;

    if (rowValue == undefined) {
      return match;
    }

    let pattern = headerValue;
    let cellText = rowValue;
    let options = { nocase: true };

    if (rowData._children != null) {
      match = true;
    } else {
      match = globMatch(pattern, cellText.toString(), options);
    }
    return match;
  };

  let globFilterMetrics = (headerValue, rowValue, rowData) => {
    let match = false;

    if (rowValue == undefined) {
      return match;
    }

    let pattern = headerValue;
    let cellText = rowValue;

    if (rowData._children != null) {
      match = true;
    } else {
      let options = { nocase: true };
      match = globMatch(pattern, cellText.toString(), options);
    }
    return match;
  };

  let cellFormatter = (cell, formatterParams, onRendered) => {
    let fieldName = cell.getField();

    let cellValue = cell.getValue();

    if (fieldName == "checkpoint") {
      const currentRow = cell.getRow();
      let parentRow = currentRow.getTreeParent();
      if (!parentRow) {
        cellValue = getBuildsNomenclature(
          cell.getData()["buildName"],
          buildsNomenclature,
          _.get(cell.getData(), "LABEL", "")
        );
      }
    }
    if (["timeStart", "timeStop"].includes(fieldName)) {
      const date = new Date(cellValue * 1000);
      cellValue = date.toLocaleString();
    }
    if (fieldName == "runTime") {
      function secondsToHms(d) {
        d = Number(d);
        var h = Math.floor(d / 3600);
        var m = Math.floor((d % 3600) / 60);
        var s = Math.floor((d % 3600) % 60);

        var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
        var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
        var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
        return hDisplay + mDisplay + sDisplay;
      }
      cellValue = secondsToHms(cellValue);
    }
    // For some reason, this check is required.
    // if (cellValue == null) {
    //   return null;
    // }

    if (fieldName == "scheduleData") {
      let startPercent = null;
      let widthPercent = null;
      const currentRow = cell.getRow();
      const rowData = currentRow.getData();
      let parentRow = currentRow.getTreeParent();
      if (parentRow) {
        const parentData = parentRow.getData();
        startPercent =
          ((rowData.timeStart - parentData.timeStart) / parentData.runTime) *
          100;
        widthPercent = (rowData.runTime / parentData.runTime) * 100;
      } else {
        startPercent = 0;
        widthPercent = 100;
      }

      let color;
      let bg;
      if (cell.getRow().getData().hasOwnProperty("_children")) {
        // build is green
        color = palette("Green").fg;
        bg = palette("LightGray").bg;
      } else {
        // checkpoint is blue
        color = palette("Blue").fg;
        bg = palette("White").bg;
      }

      let element = cell.getElement();
      element.style.minWidth = "30px";
      element.style.position = "relative";
      element.style.backgroundColor = bg;

      let barEl = document.createElement("div");
      barEl.style.display = "inline-block";
      barEl.style.position = "relative";
      barEl.style.left = startPercent + "%";
      barEl.style.width = widthPercent + "%";
      barEl.style.minWidth = "2px";
      barEl.style.height = "70%";
      barEl.style.top = "2px";
      barEl.style.bottom = "2px";
      barEl.style.backgroundColor = color;

      onRendered(function () {
        element.appendChild(barEl);
      });

      return "";
    } else {
      let fg = palette("Default").fg;
      let bg = palette("Default").bg;

      if (cell.getRow().getData()._children != null) {
        bg = palette("LightGray").bg;
      }

      cell.getElement().style.color = fg;
      cell.getElement().style.backgroundColor = bg;

      return cellValue;
    }
  };

  const getColumns = () => {
    let col = null;
    let rootGroupObj = {};
    rootGroupObj.title = null;
    rootGroupObj.columns = [];

    col = {
      title: "Checkpoint",
      field: "checkpoint",
      frozen: true,
      visible: true,
      headerSort: false,
      headerFilter: customInput,
      headerFilterFunc: globFilterFirstColumn,
      headerTooltip: globFilterDisplayValueTooltip,
      formatter: (cell, formatterParams, onRendered) =>
        cellFormatter(cell, formatterParams, onRendered),
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });
    col = {
      title: "Start Time",
      field: "timeStart",
      headerSort: true,
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: globFilterDisplayValueTooltip,
      headerFilterFunc: globFilterMetrics,
      formatter: (cell, formatterParams, onRendered) =>
        cellFormatter(cell, formatterParams, onRendered),
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });

    col = {
      title: "Stop Time",
      field: "timeStop",
      headerSort: true,
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: globFilterDisplayValueTooltip,
      headerFilterFunc: globFilterMetrics,
      formatter: (cell, formatterParams, onRendered) =>
        cellFormatter(cell, formatterParams, onRendered),
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });

    col = {
      title: "Total Run Time",
      field: "runTime",
      headerSort: true,
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: globFilterDisplayValueTooltip,
      headerFilterFunc: globFilterMetrics,
      formatter: (cell, formatterParams, onRendered) =>
        cellFormatter(cell, formatterParams, onRendered),
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });

    col = {
      title: "Schedule",
      field: "scheduleData",
      headerSort: false,
      // formatter: "schedule",
      formatter: (cell, formatterParams, onRendered) =>
        cellFormatter(cell, formatterParams, onRendered),
      // clickMenu: clickMenu,
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });
    return rootGroupObj.columns;
  };

  let minTime = null;
  let maxTime = null;

  let getRows = () => {
    if (true) {
      for (let itemB of configBuildsWithBuildname) {
        let buildName = itemB.buildName;
        // ADJUST: build
        buildInfo[buildName].pos = buildInfo[buildName].start;
        if ("_children" in itemB) {
          for (let itemC of itemB["_children"]) {
            let checkpointName = itemC.checkpoint;

            let start = buildInfo[buildName].checkpoints[checkpointName].start;
            let stop = buildInfo[buildName].checkpoints[checkpointName].stop;

            // ADJUST: scale
            if (minTime) {
              minTime = Math.min(minTime, start);
            } else {
              minTime = start;
            }
            if (maxTime) {
              maxTime = Math.max(maxTime, stop);
            } else {
              maxTime = stop;
            }

            // ADJUST: checkpoint
            buildInfo[buildName].checkpoints[checkpointName].pos = start;
          }
        }
      }
    }
    // totalTime represents the "width" of the window
    let totalTime = maxTime - minTime;
    ////////////////////////////////////////
    // Calculate Table Rows
    ////////////////////////////////////////

    let rowId = 0;
    let rows = [];

    for (let itemB of configBuildsWithBuildname) {
      let buildName = itemB.buildName;
      let buildDisplayName = buildName;
      // calculate build info
      let start = buildInfo[buildName].start;
      let stop = buildInfo[buildName].stop;
      let elapsed = buildInfo[buildName].elapsed;
      let totalRuntime = buildInfo[buildName].totalRuntime;

      let displayStart = dateFromSeconds(start);
      let displayStop = dateFromSeconds(stop);
      let displayElapsed = elapsedTimeFromSeconds(elapsed);
      let displayTotalRuntime = elapsedTimeFromSeconds(totalRuntime);

      let pos = buildInfo[buildName].pos;

      let startValue = pos - minTime;
      let startPercent = parseInt(100.0 * (startValue / totalTime));
      let widthPercent = parseInt(100.0 * (elapsed / totalTime));
      // if (this.alignMode() == "CHECKPOINT") {
      //     startPercent = 0;
      //     widthPercent = 100;
      // }
      let payload = startPercent + ":" + widthPercent;
      // console.log(pos, minTime, payload, elapsed, totalTime);

      let tooltip = "Build: " + buildName;
      tooltip += "\nStart Time: " + displayStart;
      tooltip += "\nStop Time: " + displayStop;
      // tooltip += "\nElapsed Time: " + displayElapsed;
      tooltip += "\nTotal Runtime: " + displayTotalRuntime;
      // tooltip += "\nPayload: " + payload;

      // create row representing the build
      let cellValueParent = {};
      // cellValueParent.rowId = rowId++;
      cellValueParent.checkpoint = buildDisplayName;
      // cellValueParent.tooltip = tooltip;
      cellValueParent._children = [];
      cellValueParent.timeStart = displayStart;
      cellValueParent.timeStop = displayStop;
      cellValueParent.timeElapsed = displayElapsed;
      cellValueParent.totalRuntime = displayTotalRuntime;
      cellValueParent.scheduleData = payload;
      // cellValueParent.expansionName = buildDisplayName;
      // cellValueParent.buildDisplayName = buildDisplayName;
      // cellValueParent.checkpointName = "";

      if ("_children" in itemB) {
        for (let itemC of itemB["_children"]) {
          let checkpointName = itemC.checkpoint;

          // calculate checkpoint info
          let start = buildInfo[buildName].checkpoints[checkpointName].start;
          let stop = buildInfo[buildName].checkpoints[checkpointName].stop;
          let elapsed =
            buildInfo[buildName].checkpoints[checkpointName].elapsed;

          let displayStart = dateFromSeconds(start);
          let displayStop = dateFromSeconds(stop);
          let displayElapsed = elapsedTimeFromSeconds(elapsed);

          let pos = buildInfo[buildName].checkpoints[checkpointName].pos;
          let startValue = pos - minTime;
          let startPercent = parseInt(100.0 * (startValue / totalTime));
          let widthPercent = parseInt(100.0 * (elapsed / totalTime));
          let payload = startPercent + ":" + widthPercent;

          let tooltip = "Build: " + buildName;
          tooltip += "\nCheckpoint: " + checkpointName;
          tooltip += "\nStart Time: " + displayStart;
          tooltip += "\nStop Time: " + displayStop;
          tooltip += "\nElapsed Time: " + displayElapsed;
          tooltip += "\nTotal Runtime: " + displayElapsed;
          // tooltip += "\nPayload: " + payload;

          // create row representing the checkpoint
          let cellValueChild = {};
          cellValueChild.displayValueFirstColumn = checkpointName;
          // cellValueChild.rowId = rowId++;
          // cellValueChild.tooltip = tooltip;
          cellValueChild.scheduleData = payload;
          cellValueChild.timeStart = displayStart;
          cellValueChild.timeStop = displayStop;
          // cellValueChild.timeElapsed = displayElapsed;
          cellValueChild.totalRuntime = displayElapsed;
          // cellValueChild.buildDisplayName = buildDisplayName;
          cellValueChild.checkpoint = checkpointName;

          cellValueParent["_children"].push(cellValueChild);
        }
      }
      rows.push(cellValueParent);
    }
    // console.log(rows);
    setTableData(rows);
  };

  //----------------Table -------------------------
  useEffect(() => {
    console.log(tableInst);
    const initTable = () => {
      var columns = getColumns();
      if (tableInst == null) {
        console.log("table init1");
        tableInst = new Tabulator(tableRef, {
          layout: "fitDataStretch",
          // selectable: true,
          //rowHeight: 40,
          initialSort: [{ column: "timeStart", dir: "asc" }],
          dataTree: true,
          pagination: true, //enable.
          paginationMode: "remote",
          paginationSize: 25,
          height: "100%",
          width: "100%",
          sortMode: "remote",
          filterMode: "remote",
          ajaxConfig: "POST",
          paginationSizeSelector: [10, 25, 50, 100],
          paginationCounter: "rows",
          // movableRows: true,
          ajaxURL: metricsURL + "getFlowProfile/",
          ajaxContentType: "json",
          ajaxParams: {
            rawQuery: _.get(props.config, "query", ""),
            variables: _.get(props.config, "wVariables", {}),
            hiddenBuilds: hiddenBuilds,
            hiddenCheckpoints: _.get(
              props.config,
              ["checkpointsConfig", "hiddenCheckpoints"],
              []
            ),
            auth: {
              user: _.get(useConfigStore.getState(), "authLoginUser", ""),
            },
          },
          ajaxError: (error) => {
            console.log(error);
          },
          ajaxResponse: (url, params, responseData) => {
            const tabulatorLoreFormat = {
              data: responseData.rows ? responseData.rows : [],
              last_page: responseData.lastPage ? responseData.lastPage : 10,
            };
            return tabulatorLoreFormat;
          },

          // rowContextMenu: getRowContextMenu,
          columns: columns ? columns : [],
          // data: tableData ? tableData : [],
          groupToggleElement: "header",
          columnDefaults: {
            headerFilterPlaceholder: "...",
          },
        });
      } else {
        console.log("Table replace data");
        tableInst.replaceData(tableData);
        // this.resizeTable();
      }
    };
    if (tableData) {
      initTable();
    }
  }, []);

  const getReportMenu = () => {
    return (
      <div id="reportMenu" style={{ width: "100%", height: "30px" }}>
        <ButtonGroup size="small" variant="text">
          <Chip
            label={props.config.currentReportName}
            sx={{ height: "28px" }}
            onClick={() => {
              props.handleReportsPane(true);
            }}
            variant={"outlined"}
          />
          <Button onClick={() => handleOpenBuilds(true)}>Builds</Button>
          <Button onClick={() => props.handleOpenCheckpoint(true)}>
            Checkpoints
          </Button>
        </ButtonGroup>
        <Modal open={openBuilds} container={profileRef.current}>
          <Builds
            buildsNomenclature={buildsNomenclature}
            handleBuildsNameCheck={handleBuildsNameCheck}
            handleSaveBuilds={handleSaveBuilds}
            handleCancle={handleBuildsCancel}
            hiddenBuilds={hiddenBuilds}
          />
        </Modal>
        <Modal open={props.openCheckpoints} container={profileRef.current}>
          <Checkpoints
            handleSaveCheckpoints={props.handleSaveCheckpoints}
            handleCancel={handleCheckpointCancel}
            checkpoints={props.checkpoints}
            hiddenCheckpoints={_.get(
              props.config,
              ["checkpointsConfig", "hiddenCheckpoints"],
              []
            )}
          />
        </Modal>
      </div>
    );
  };

  useEffect(() => {
    function setDataForFlowProfile() {
      props.config.buildSpec.forEach((array) => {
        let arr = _.cloneDeep(array);
        // console.log(arr);
        if (!("_children" in arr)) {
          // arr["buildName"] = `${arr.PROJECT}/${arr.USER}/${arr.BLOCK}/${arr.PHASE}/${arr.RUNTAG}`
        } else {
          let children = [];
          arr["_children"].forEach((_array) => {
            let _arr = _.cloneDeep(_array);
            _arr[
              "buildName"
            ] = `${_arr.PROJECT}/${_arr.USER}/${_arr.BLOCK}/${_arr.PHASE}/${_arr.RUNTAG}`;
            children.push(_arr);
          });
          arr["_children"] = children;
        }
        arr[
          "buildName"
        ] = `${arr.PROJECT}/${arr.USER}/${arr.BLOCK}/${arr.PHASE}/${arr.RUNTAG}`;
        arr[
          "checkpoint"
        ] = `${arr.PROJECT}/${arr.USER}/${arr.BLOCK}/${arr.PHASE}/${arr.RUNTAG}`;
        configBuildsWithBuildname.push(arr);
      });

      // console.log(configBuildsWithBuildname);
      for (let itemB of configBuildsWithBuildname) {
        let buildName = itemB.buildName;
        buildInfo[buildName] = {
          start: null,
          stop: null,
          elapsed: 0,
          totalRuntime: 0,
          checkpoints: {},
        };

        // let buildCheckpointNames = Object.keys(mongoData[buildName]["checkpoints"]);
        if ("_children" in itemB) {
          for (let itemC of itemB["_children"]) {
            // console.log(itemC);
            let checkpointName = itemC.checkpoint;
            let start = itemC.timeStart;
            let stop = itemC.timeStop;

            let elapsed = stop - start;

            if (!buildInfo[buildName].start) {
              buildInfo[buildName].start = start;
            }
            if (!buildInfo[buildName].stop) {
              buildInfo[buildName].stop = stop;
            }
            let allStart = Math.min(buildInfo[buildName].start, start);
            let allStop = Math.max(buildInfo[buildName].stop, stop);
            let allElapsed = allStop - allStart;

            buildInfo[buildName].start = allStart;
            buildInfo[buildName].stop = allStop;
            buildInfo[buildName].elapsed = allElapsed;
            buildInfo[buildName].totalRuntime += elapsed;

            buildInfo[buildName].checkpoints[checkpointName] = {
              start: start,
              stop: stop,
              elapsed: elapsed,
            };
          }
        }
      }
    }
    if (props.config.buildSpec) {
      setDataForFlowProfile();
      getRows();
    }
  }, []);

  return (
    // <h1>I am table</h1>
    <>
      <div
        id="profileReport"
        ref={(ref) => {
          profileRef.current = ref;
        }}
        style={{ width: "100%", height: "100%" }}
      >
        {getReportMenu()}
        <div
          id="analytics"
          style={{ width: "100%", height: "calc(100% - 30px)" }}
        >
          <div
            style={{ width: "inherit" }}
            ref={(r) => {
              tableRef = r;
            }}
          ></div>
        </div>
      </div>
    </>
  );
}

ProfileReport.defaultProps = {
  query: "",
  baselineBuild: "",
};

export default ProfileReport;
