import React, { useEffect, useRef, useState } from "react";
import { produce } from "immer";
// import { ReactTabulator } from "react-tabulator";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import Builds from "../dialogs/BuildsModal";
import axios from "axios";
import _ from "lodash";

import useConfigStore from "../../../../../store/useConfigStore";
import useGlobalStore from "../../../../../store/useGlobalStore";

import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";
import {
  Button,
  ButtonGroup,
  Checkbox,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  InputLabel,
  MenuItem,
  Modal,
  Select,
  Stack,
  Typography,
} from "@mui/material";
import { Box } from "@mui/system";

import { tags } from "../../../../../constants/constants";
import { getBuildsNomenclature } from "../../../../../common/utils/utils";
// import * as utils from "../../../../../common/utils/utils";
// import api from "common/api/api";

// import {
//   customInput,
//   customFilter,
//   customFilterDisplayValue,
//   globFilterDisplayValue,
// } from "../../../../../common/filter";

import * as funcs from "common/Funcs";
import Checkpoints from "../dialogs/CheckpointsModal";

const ImageCompareReport = (props) => {
  let tableRef = React.createRef();
  let tableInst = null;
  let tarnsformedRows = [];
  const metricsURL =
    useConfigStore.getState().configData.rest_server_url + "/metrics/";

  const [showFormat, setShowFormat] = useState(false);
  const [reportConfig, setReportConfig] = useState(
    props.config.savedReportConfig[props.config.currentReport]
  );

  const [openBuilds, setOpenBuilds] = useState(false);
  const [buildsNomenclature, setBuildsNomenclature] = useState(
    _.get(props.config.buildsConfig, "buildsNomenclature", {})
  );

  let imageHeight = 200;
  const imageReportRef = useRef(null);

  const [hiddenBuilds, setHiddenBuilds] = useState(
    _.get(props.config.buildsConfig, "hiddenBuilds", [])
  );

  const handleSaveBuilds = (hiddenBuildsList = []) => {
    const newConfig = _.cloneDeep(props.config);

    newConfig.buildsConfig = {
      buildsNomenclature: buildsNomenclature,
      hiddenBuilds: hiddenBuildsList,
    };

    props.updateReportConfig(newConfig);
  };

  const handleBuildsNameCheck = (tag, event) => {
    const newBuildsNomenclature = _.cloneDeep(buildsNomenclature);
    newBuildsNomenclature[tag] = { show: event.target.checked };
    setBuildsNomenclature(newBuildsNomenclature);
  };

  const handleOpenBuilds = (flag) => {
    setOpenBuilds(flag);
  };

  const handleBuildsCancel = () => {
    setBuildsNomenclature(
      _.get(props.config.buildsConfig, "buildsNomenclature", {})
    );
    handleOpenBuilds(false);
  };

  const handleCheckpointCancel = () => {
    props.handleOpenCheckpoint(false);
  };

  const buildColumnFormater = (cell, formatterParams, onRendered) => {
    let label = _.get(cell.getData(), "LABEL", "");
    return getBuildsNomenclature(cell.getValue(), buildsNomenclature, label);
  };

  const groupHeader = (value, count, data, group) => {
    const orgMode =
      props.config.savedReportConfig[props.config.currentReport].orgMode;
    if (orgMode == "BCxM" && value && value.split("/").length >= 5) {
      let label = _.get(data[0], "LABEL", "");
      return (
        getBuildsNomenclature(value, buildsNomenclature, label) +
        "<span style='margin-left:10px;'>(" +
        count +
        " item)</span>"
      );
    }
    return (
      value + "<span style='margin-left:10px;'>(" + count + " item)</span>"
    );
  };

  const fetchImage = async (bucket, key) => {
    let img = await axios
      .post(
        metricsURL + "downloadFile",
        {
          minio_bucket: bucket,
          minio_key: key,
          ftype: "IMAGE",
        },
        { responseType: "arraybuffer" }
      )
      .then((responseData) => {
        if (responseData.status == 200) {
          return responseData.data;
        } else {
          return null;
        }
      });
    return img;
  };

  const cellFormatter = (cell, formatterParams, onRendered) => {
    let element = cell.getElement();
    let field = cell.getColumn().getField();
    let rowData = cell.getRow().getData();
    let cellValue = rowData[field];

    let displayValue = null;

    let fg = funcs.palette("Default").fg;
    let bg = funcs.palette("Default").bg;

    if (typeof cellValue == "string") {
      displayValue = cellValue;
    }
    if (cellValue) {
      let fileData = cellValue.fileData;
      let colors = cellValue.colors;
      if (colors) {
        fg = colors.foreground;
        bg = colors.background;
      }

      if (fileData == null) {
        let fstatus = "NO_IMAGE";

        let newDiv = document.createElement("div");
        newDiv["className"] = "divCell_" + fstatus;
        newDiv["innerHTML"] = fstatus;
        onRendered(function () {
          element.appendChild(newDiv);
        });
      } else {
        let bucket = _.get(fileData, "minio_bucket", "");
        let key = _.get(fileData, "minio_key", "");
        let newDiv = document.createElement("div");
        newDiv["className"] = "divCell_" + "fstatus";

        let newImg = document.createElement("img");
        newImg["className"] = "imgCellImage";
        newImg.src =
          metricsURL +
          "downloadFile?minio_bucket=" +
          bucket +
          "&minio_key=" +
          key +
          "&ftype=IMAGE";
        newImg.style.height = imageHeight + "px";
        onRendered(() => {
          newDiv.appendChild(newImg);
          element.appendChild(newDiv);
        });
      }
    } else {
      let fstatus = "NULL";

      let newDiv = document.createElement("div");
      newDiv["className"] = "divCell_" + fstatus;
      newDiv["innerHTML"] = fstatus;
      onRendered(function () {
        element.appendChild(newDiv);
      });
    }

    element.style.color = fg;
    element.style.backgroundColor = bg;

    return displayValue;
  };

  const openImage = (bucket, key) => {
    window.open(
      metricsURL +
        "downloadFile?minio_bucket=" +
        bucket +
        "&minio_key=" +
        key +
        "&ftype=IMAGE",
      "_blank",
      "noopener,noreferrer"
    );
  };

  const getData = (rows) => {
    let newRows = [];
    for (let index = 0; index < rows.length; index++) {
      let rowData = {};
      rowData["checkpoint"] = _.get(rows[index], "checkpoint", "");
      rowData["buildName"] = _.get(rows[index], "buildName", "");
      rowData["displayBuildName"] = _.get(rows[index], "displayBuildName", "");
      rowData["metric"] = _.get(rows[index], "metric", "");
      rowData["BLOCK"] = _.get(rows[index], "BLOCK", "");
      rowData["LABEL"] = _.get(rows[index], "LABEL", "");
      if (rows[index] && rows[index].files && rows[index].colors) {
        const files = Object.keys(rows[index].files);
        for (let i = 0; i < files.length; i++) {
          rowData[files[i]] = {
            fileData: _.get(rows[index].files, [files[i]], ""),
            colors: _.get(rows[index].colors, [[files[i]]], ""),
          };
        }
      }
      newRows.push(rowData);
    }
    tarnsformedRows = newRows;
    return newRows;
  };

  const setBaseline = (buildName) => {
    // check it is a different build from current baseline builds
    if (
      !Array.isArray(
        props.config.savedReportConfig[props.config.currentReport]
          .baselineBuilds
      ) ||
      (Array.isArray(
        props.config.savedReportConfig[props.config.currentReport]
          .baselineBuilds
      ) &&
        !props.config.savedReportConfig[
          props.config.currentReport
        ].baselineBuilds.includes(buildName))
    ) {
      let baselines = null;
      // check if baselines is array
      if (
        Array.isArray(
          props.config.savedReportConfig[props.config.currentReport]
            .baselineBuilds
        )
      ) {
        // get all current baselines
        baselines = _.cloneDeep(
          props.config.savedReportConfig[props.config.currentReport]
            .baselineBuilds
        );
        // extract block from the new buildname
        const block = buildName.split("/")[2];
        // search for baseline for new block
        const filteredBaseline = baselines.filter(
          (baseline) => baseline.split("/")[2] == block
        );
        // check if baseline exists for current block
        if (filteredBaseline && filteredBaseline.length) {
          // replace the old baseline for current block with new buildname
          baselines.splice(
            baselines.indexOf(filteredBaseline[0]),
            1,
            buildName
          );
        } else {
          // if no baseline exist for current block then add new buildname
          baselines.push(buildName);
        }
      } else {
        baselines = [buildName];
      }
      props.setBaselineBuild(baselines);
    }
  };

  let rowContextMenuSetBaseline = (e, row) => {
    let rowData = row.getData();
    let buildName = rowData.buildName;
    // extract build name from baseline
    buildName = buildName.split("###")[0];
    let block = rowData.block;
    // if (props.config.savedReportConfig[props.config.currentReport]?.displayMode && props.config.savedReportConfig[props.config.currentReport]?.displayMode != undefined) {
    //   displayMode = props.config.savedReportConfig[props.config.currentReport].displayMode;
    // }
    setBaseline(buildName);
  };

  let rowContextMenuUnsetBaseline = (e, row) => {
    let buildName = row.getData()["buildName"];

    buildName = buildName.split("###")[0];
    // check it is a different build from current baseline builds
    if (
      !Array.isArray(
        props.config.savedReportConfig[props.config.currentReport]
          .baselineBuilds
      ) ||
      (Array.isArray(
        props.config.savedReportConfig[props.config.currentReport]
          .baselineBuilds
      ) &&
        props.config.savedReportConfig[
          props.config.currentReport
        ].baselineBuilds.includes(buildName))
    ) {
      let baselines = null;
      // check if baselines is array
      if (
        Array.isArray(
          props.config.savedReportConfig[props.config.currentReport]
            .baselineBuilds
        )
      ) {
        // get all current baselines
        baselines = _.cloneDeep(
          props.config.savedReportConfig[props.config.currentReport]
            .baselineBuilds
        );
        // extract block from the new buildname
        const block = buildName.split("/")[2];
        // search for baseline for new block
        const filteredBaseline = baselines.filter(
          (baseline) => baseline.split("/")[2] == block
        );
        // check if baseline exists for current block
        if (filteredBaseline && filteredBaseline.length) {
          // replace the old baseline for current block with new buildname
          baselines.splice(baselines.indexOf(filteredBaseline[0]), 1);
        } else {
          // if no baseline exist for current block then add new buildname
          baselines.push(buildName);
        }
      } else {
        baselines = [buildName];
      }
      props.setBaselineBuild(baselines);
    }
  };

  const handleRowContextMenuSetBaseline = {
    label: "Set baseline",
    action: rowContextMenuSetBaseline,
  };
  const handleRowContextMenuUnsetBaseline = {
    label: "Unset baseline",
    action: rowContextMenuUnsetBaseline,
  };

  const getRowContextMenu = (e, rowData) => {
    let rowContextMenu = [];
    let plotContextMenu = null;

    let buildName = rowData["buildName"];

    // extract build name from baseline text
    buildName = buildName.split("###")[0];

    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );
    if (orgMode == "BCxM" || orgMode == "CBxM") {
      if (
        typeof props.config.savedReportConfig[props.config.currentReport]
          .baselineBuilds == "string" ||
        (Array.isArray(
          props.config.savedReportConfig[props.config.currentReport]
            .baselineBuilds
        ) &&
          !props.config.savedReportConfig[
            props.config.currentReport
          ].baselineBuilds.includes(buildName))
      ) {
        rowContextMenu.push(handleRowContextMenuSetBaseline);
      }

      if (
        props.config.savedReportConfig[props.config.currentReport]
          .baselineBuilds != undefined &&
        props.config.savedReportConfig[props.config.currentReport]
          .baselineBuilds != "" &&
        Array.isArray(
          props.config.savedReportConfig[props.config.currentReport]
            .baselineBuilds
        ) &&
        props.config.savedReportConfig[
          props.config.currentReport
        ].baselineBuilds.includes(buildName)
      ) {
        rowContextMenu.push(handleRowContextMenuUnsetBaseline);
      }
    }
    // console.log(rowContextMenu);
    // rowContextMenu.push(JSON.parse(JSON.stringify(plotContextMenu)));
    return rowContextMenu;
  };

  const cellContextMenu = (e, cell) => {
    let contextMenu = [];
    const field = cell._cell.column.field;
    const row = cell._cell.row;
    //open image in new tab
    if (row.data[field] && row.data[field].fileData) {
      const key = row.data[field].fileData.minio_key;
      const bucket = row.data[field].fileData.minio_bucket;
      contextMenu.push({
        label: "Open in new Tab",
        action: (e, row) => openImage(bucket, key),
      });
    }

    contextMenu = contextMenu.concat(getRowContextMenu(e, cell.getData()));

    return contextMenu;
  };

  const hideColumn = (e, column) => {
    return [
      {
        label: "Hide Column",
        action: function (e, column) {
          e.stopPropagation();
          column.hide();
        },
      },
    ];
  };

  const setBaselineHeaderMenu = (e, column) => {
    return [
      {
        label: "Set baseline",
        action: () => setBaseline(column.getDefinition().title.split("###")[0]),
      },
    ];
  };

  const headerContextMenu = (e, column) => {
    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );
    if (orgMode == "BCxM" || orgMode == "CBxM") {
      return hideColumn(e, column);
    } else if (orgMode == "MCxB" || orgMode == "CMxB") {
      return setBaselineHeaderMenu(e, column);
    }
  };

  const getGroupByValue = (
    orgMode,
    hierBlockMode = true,
    hierBuildMode = true
  ) => {
    let groupByValue = null;
    if (orgMode == "BCxM") {
      if (hierBlockMode == true && hierBuildMode == true) {
        groupByValue = ["BLOCK", "displayBuildName"];
      } else if (hierBlockMode == true && hierBuildMode == false) {
        groupByValue = ["BLOCK"];
      } else if (hierBlockMode == false && hierBuildMode == true) {
        groupByValue = ["displayBuildName"];
      } else {
        groupByValue = [];
      }
    } else if (orgMode == "CBxM") {
      if (hierBlockMode == false) {
        groupByValue = "checkpoint";
      } else {
        groupByValue = ["checkpoint", "BLOCK"];
      }
    } else if (orgMode == "CMxB") {
      groupByValue = "checkpoint";
    } else if (orgMode == "MCxB") {
      groupByValue = "metric";
    }
    return groupByValue;
  };

  const getColumns = (cols) => {
    const orgMode =
      props.config.savedReportConfig[props.config.currentReport].orgMode;
    let newCols = [];
    for (let i = 0; i < cols.length; i++) {
      let column = _.cloneDeep(cols[i]);
      if (
        ["displayBuildName", "BLOCK", "metric", "checkpoint"].includes(
          _.get(column, "field", "")
        )
      ) {
        column.headerFilter = "input";
        column.contextMenu = (e, cell) => cellContextMenu(e, cell);
        if (_.get(column, "field", "") == "displayBuildName") {
          column.formatter = buildColumnFormater;
        }
      } else if (column.columns) {
        for (let j = 0; j < column.columns.length; j++) {
          column.columns[j].formatter = (cell, formatterParams, onRendered) =>
            cellFormatter(cell, formatterParams, onRendered);
          column.columns[j].headerSort = false;
          column.columns[j].contextMenu = (e, cell) => cellContextMenu(e, cell);
          column.columns[j].headerContextMenu = headerContextMenu;
        }
      } else {
        column.formatter = (cell, formatterParams, onRendered) =>
          cellFormatter(cell, formatterParams, onRendered);
        column.headerSort = false;
        column.contextMenu = (e, cell) => cellContextMenu(e, cell);
        column.headerContextMenu = headerContextMenu;
      }
      if (
        !["checkpoint", "BLOCK", "buildName", "groupName", "metric"].includes(
          column.field
        ) &&
        ["CMxB", "MCxB", "MxBC"].includes(orgMode)
      ) {
        column.title = getBuildsNomenclature(
          column.title,
          buildsNomenclature,
          _.get(column, "LABEL", "")
        );
      }
      newCols.push(column);
    }
    return newCols;
  };

  const getTableHier = () => {
    let hier = [];
    const reportConfig =
      props.config.savedReportConfig[props.config.currentReport];
    const blockHier = _.get(reportConfig, "hierBlockMode", true);
    const buildHier = _.get(reportConfig, "hierBuildMode", true);
    if (
      blockHier &&
      (reportConfig.orgMode == "BCxM" || reportConfig.orgMode == "CBxM")
    ) {
      hier.push("BLOCK");
    }
    if (buildHier && reportConfig.orgMode == "BCxM") {
      hier.push("buildName");
    }
    return hier;
  };

  let paginationCols = [];

  const isColOrderSame = (cols1, cols2) => {
    if (
      cols1 &&
      cols1.length &&
      cols2 &&
      cols2.length &&
      cols2.length == cols1.length
    ) {
      for (let i = 0; i < cols1.length; i++) {
        if (cols1[i].feild != cols2.feild) {
          return false;
        }
        if (
          cols1[i].hasOwnProperty("columns") ||
          cols2[i].hasOwnProperty("columns")
        ) {
          if (cols1[i].columns.length == cols2[i].columns.length) {
            for (let j = 0; j < cols1[i].columns.length; j++) {
              if (cols1[i].columns[j].feild != cols2[i].columns[j].feild) {
                return false;
              }
            }
          } else {
            return false;
          }
        }
      }
      return true;
    }
    return false;
  };

  const saveFormatOptions = () => {
    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[props.config.currentReport] = reportConfig;
    props.updateReportConfig(newConfig);
    setShowFormat(false);
  };

  const handleFormatChange = (formatKey, formatValue) => {
    const newReportConfig = _.cloneDeep(reportConfig);
    newReportConfig[formatKey] = formatValue;
    setReportConfig(newReportConfig);
  };

  const initTable = () => {
    //   var columns = getColumns();
    if (tableInst == null) {
      tableInst = new Tabulator(tableRef, {
        // className: "table-sm table-striped table-bordered",
        layout: "fitDataStretch",
        columns: getColumns([]),
        // selectable: true,
        pagination: true, //enable pagination
        paginationMode: "remote", //enable remote pagination
        sortMode: "remote",
        filterMode: "remote",
        ajaxConfig: "POST",
        paginationSize: 25,
        paginationSizeSelector: [10, 25, 50, 100, 200],
        paginationCounter: "rows",
        ajaxURL: metricsURL + "getImageReport",
        ajaxContentType: "json",
        ajaxParams: {
          selectedBuilds: props.buildSpec,
          // report: props.config.savedReportConfig[props.config.currentReport]?.report ? props.config.savedReportConfig[props.config.currentReport]?.report : {},
          // hierSpec: props.config.savedReportConfig[props.config.currentReport]?.selectedHierSpecData
          //   ? props.config.savedReportConfig[props.config.currentReport]?.selectedHierSpecData
          //   : [],
          hiddenBuilds: hiddenBuilds,
          hiddenCheckpoints: _.get(
            props.config,
            ["checkpointsConfig", "hiddenCheckpoints"],
            []
          ),
          auth: {
            user: _.get(useConfigStore.getState(), "authLoginUser", ""),
          },
          tableMode: _.get(
            props.config.savedReportConfig[props.config.currentReport],
            "orgMode",
            "BCxM"
          ),

          // displayMode: props.config.savedReportConfig[props.config.currentReport]?.displayMode
          //   ? props.config.savedReportConfig[props.config.currentReport]?.displayMode
          //   : "VALUE",
          // referenceMode: _.get(props.config.savedReportConfig[props.config.currentReport],"displayMode","VALUE") !== "REFS_OFF" ,
          baselines:
            props.config.savedReportConfig[props.config.currentReport]
              ?.baselineBuilds &&
            props.config.savedReportConfig[props.config.currentReport]
              ?.baselineBuilds.length
              ? props.config.savedReportConfig[props.config.currentReport]
                  ?.baselineBuilds
              : [],
          tableHier: getTableHier(),
          // rawQuery: _.get(props.config, "query", ""),
          // variables: _.get(props.config, "wVariables", {}),
        },
        ajaxResponse: (url, params, responseData) => {
          if (tableInst && responseData.cols) {
            const newCols = getColumns(responseData.cols);
            if (
              !isColOrderSame(newCols, paginationCols) &&
              params.filter.length == 0
            ) {
              paginationCols = newCols;
              tableInst.setColumns(getColumns(responseData.cols));
            }
          }
          const tabulatorLoreFormat = {
            data: responseData.rows ? getData(responseData.rows) : [],
            last_page: responseData.lastPage ? responseData.lastPage : 0,
          };
          // rowsColor = responseData.rows ? responseData.rows : [];
          return tabulatorLoreFormat;
        },

        // movableRows: true,
        // rowContextMenu: getRowContextMenu,
        //   columns: columns ? columns : [],
        //   autoColumns: true,
        // data: rows ? rows : [],
        height: "100%",
        width: "100%",
        groupBy: group,
        groupHeader: groupHeader,
        // groupToggleElement: "header",
        columnDefaults: {
          headerFilterPlaceholder: "...",
          headerFilterLiveFilter: false,
          resizable: true,
        },
      });
      // tableInst.on("rowMouseEnter", rowMouseEnter);
      // tableInst.on("rowClick", rowClick);
      // tableInst.on("dataTreeRowExpanded", afterTableBuilt);
      // tableInst.on("groupVisibilityChanged", afterTableBuilt);
      // tableInst.on("pageLoaded", pageLoaded);
      // tableInst.on("renderStarted", renderStarted);
      // tableInst.on("dataFiltered", afterTableBuilt);
      // tableInst.on("dataProcessed", afterTableBuilt);
    } else {
      // this.resizeTable();
    }
  };

  const getReportMenu = () => {
    return (
      <div id="reportMenu" style={{ width: "100%", height: "30px" }}>
        <ButtonGroup size="small" variant="text">
          <Chip
            label={props.config.currentReportName}
            sx={{ height: "28px" }}
            onClick={() => {
              props.handleReportsPane(true);
            }}
            variant={"outlined"}
          />
          <Button
            // variant="outlined"
            size="small"
            onClick={() => {
              setShowFormat(true);
              setReportConfig(
                props.config.savedReportConfig[props.config.currentReport]
              );
            }}
          >
            Format
          </Button>
          <Button
            // variant="outlined"
            size="small"
            onClick={() => {
              if (tableInst) {
                imageHeight = imageHeight + 50;
                tableInst.redraw(true);
              } else {
                initTable();
                imageHeight = imageHeight + 50;
                tableInst.redraw(true);
              }
            }}
          >
            Zoom In
          </Button>
          <Button
            // variant="outlined"
            size="small"
            onClick={() => {
              if (tableInst) {
                imageHeight =
                  imageHeight >= 100 ? imageHeight - 50 : imageHeight;
                tableInst.redraw(true);
              } else {
                initTable();
                imageHeight =
                  imageHeight >= 100 ? imageHeight - 50 : imageHeight;
                tableInst.redraw(true);
              }
            }}
          >
            Zoom out
          </Button>
          <Button onClick={() => handleOpenBuilds(true)}>Builds</Button>
          <Button onClick={() => props.handleOpenCheckpoint(true)}>
            Checkpoints
          </Button>
        </ButtonGroup>
        {
          <Box>
            <Modal open={showFormat} container={imageReportRef.current}>
              <Box
                sx={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  width: "400px",
                  height: "auto",
                  bgcolor: "background.paper",
                  border: "2px solid #000",
                  boxShadow: 24,
                  borderRadius: "15px",
                  p: 2,
                }}
              >
                <Box>
                  <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                    Format Report
                  </Typography>
                </Box>
                <Divider />
                <Stack spacing={2}>
                  <FormControl>
                    <InputLabel>Table Mode</InputLabel>
                    <Select
                      value={_.get(reportConfig, "orgMode", "BCxM")}
                      label="Table Mode"
                      onChange={(e) => {
                        handleFormatChange("orgMode", e.target.value);
                      }}
                      size={"small"}
                    >
                      {[
                        {
                          value: "BCxM",
                          title: "Builds/Checkpoints X Metrics",
                        },
                        {
                          value: "CBxM",
                          title: "Checkpoints/Builds X Metrics",
                        },
                        {
                          value: "CMxB",
                          title: "Checkpoints/Metrics X Builds",
                        },
                        {
                          value: "MCxB",
                          title: "Metrics/Checkpoints X Builds",
                        },
                        {
                          value: "MxBC",
                          title: "Metrics X Builds/Checkpoints",
                        },
                      ].map((item) => (
                        <MenuItem value={item.value}>{item.title}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  {reportConfig.orgMode == "BCxM" ||
                  reportConfig.orgMode == "CBxM" ? (
                    <FormControl>
                      <InputLabel>Block Hier</InputLabel>
                      <Select
                        value={_.get(reportConfig, "hierBlockMode", true)}
                        label="Block Hier"
                        onChange={(e) => {
                          handleFormatChange("hierBlockMode", e.target.value);
                        }}
                        size={"small"}
                      >
                        {[
                          { value: true, title: "On" },
                          { value: false, title: "Off" },
                        ].map((item) => (
                          <MenuItem value={item.value}>{item.title}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  ) : null}
                  {reportConfig.orgMode == "BCxM" ? (
                    <FormControl>
                      <InputLabel>Build hier</InputLabel>
                      <Select
                        value={_.get(reportConfig, "hierBuildMode", true)}
                        label="Build hier"
                        onChange={(e) => {
                          handleFormatChange("hierBuildMode", e.target.value);
                        }}
                        size={"small"}
                      >
                        {[
                          { value: true, title: "On" },
                          { value: false, title: "Off" },
                        ].map((item) => (
                          <MenuItem value={item.value}>{item.title}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  ) : null}
                </Stack>
                <Divider />
                <ButtonGroup
                  size={"small"}
                  variant="contained"
                  sx={{ float: "right", marginTop: "10px" }}
                >
                  <Button onClick={() => saveFormatOptions()}>Save</Button>
                  <Button onClick={() => setShowFormat(false)}>Cancel</Button>
                </ButtonGroup>
              </Box>
            </Modal>
            <Modal open={openBuilds} container={imageReportRef.current}>
              <Builds
                buildsNomenclature={buildsNomenclature}
                handleBuildsNameCheck={handleBuildsNameCheck}
                handleSaveBuilds={handleSaveBuilds}
                handleCancle={handleBuildsCancel}
                hiddenBuilds={hiddenBuilds}
              />
            </Modal>
            <Modal
              open={props.openCheckpoints}
              container={imageReportRef.current}
            >
              <Checkpoints
                handleSaveCheckpoints={props.handleSaveCheckpoints}
                handleCancel={handleCheckpointCancel}
                checkpoints={props.checkpoints}
                hiddenCheckpoints={_.get(
                  props.config,
                  ["checkpointsConfig", "hiddenCheckpoints"],
                  []
                )}
              />
            </Modal>
          </Box>
        }
      </div>
    );
  };
  let group = getGroupByValue(
    _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    ),
    props.config.savedReportConfig[props.config.currentReport].hierBlockMode,
    props.config.savedReportConfig[props.config.currentReport].hierBuildMode
  );

  useEffect(() => {
    initTable();
  }, []);

  return (
    // <h1>I am table</h1>
    <>
      <div
        id="ImageCompareReport"
        ref={(ref) => (imageReportRef.current = ref)}
        style={{ width: "100%", height: "100%" }}
      >
        {getReportMenu()}
        <div
          id="analytics"
          style={{ width: "100%", height: "calc(100% - 30px)" }}
        >
          <div
            style={{ width: "100%", height: "100%" }}
            ref={(r) => {
              tableRef = r;
            }}
          ></div>
        </div>
      </div>
    </>
  );
};

export default ImageCompareReport;
