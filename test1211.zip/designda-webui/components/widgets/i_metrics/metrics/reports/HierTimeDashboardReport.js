import React from "react";
import { useState, useEffect, useRef } from "react";
import { shallow } from "zustand/shallow";
import { produce } from "immer";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import axios from "axios";
import { calcCell, _colors } from "../../../../../common/color";
import useConfigStore from "../../../../../store/useConfigStore";
import useGlobalStore from "../../../../../store/useGlobalStore";
import api from "../../../../../common/api/api";
import {
  addWidgetCommonFunction,
  showWidgetDataUiState,
} from "../../../../../pages/rptdashboard/addWidget/addWidget";

import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

//mui components
import {
  Button,
  ButtonGroup,
  Chip,
  Divider,
  FormControl,
  InputLabel,
  Menu,
  MenuItem,
  Modal,
  Paper,
  Select,
  Stack,
  Typography,
} from "@mui/material";
import { Box } from "@mui/system";

//mui styles
import { styled, alpha } from "@mui/material/styles";

//icon
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

// const mongoURL = "http://10.15.102.250:7634/mongo/";
export default function HierTimeDashboardReport(props) {
  // let info = getTableOptionsEvents("xyz");
  // const [columns, setColumns] = useState([]);
  // const [rows, setRows] = useState([]);
  let tableRef = React.createRef();
  let metricTableRef = React.createRef();
  let tableInst = null;
  let metricTableInst = null;
  const [reportConfig, setReportConfig] = useState(
    props.config.savedReportConfig[props.config.currentReport]
  );
  let prevRowHighlighted = null;
  let _rows = [];
  let _blocks = [];
  let plotSeries = [];
  let c = [];
  let r = [];

  const mongoURL =
    useConfigStore.getState().configData.rest_server_url + "/mongo/";
  const metricsURL =
    useConfigStore.getState().configData.rest_server_url + "/metrics/";

  const isNumber = (value) => {
    return !isNaN(value) && !isNaN(parseFloat(value));
  };
  //-----------------------------------------------------------
  let getFlattenedRows = (allRowsData) => {
    for (let obj of allRowsData) {
      if ("_children" in obj) {
        let tempObj = _.cloneDeep(obj);
        delete tempObj["_children"];
        _rows.push(tempObj);
        _blocks.push(tempObj["block"]);
        getFlattenedRows(obj["_children"]);
      } else {
        _rows.push(obj);
        _blocks.push(obj["block"]);
      }
    }
  };
  //Plotting
  let addWidgets = (wProps) => {
    // console.log(wProps);
    for (let i = 0; i < wProps.widgets.length; i++) {
      const widgetsSettings = produce(wProps.widgets[i], (settingsDraft) => {
        // console.log(settingsDraft);
        delete settingsDraft.currentReportName;
        delete settingsDraft.data;
      });

      const data = _.get(wProps.widgets[i], "data", {});
      // console.log(data);
      addWidgetCommonFunction(
        props.rptType,
        props.reportKey,
        widgetsSettings,
        data,
        showWidgetDataUiState,
        props.index
      );
    }
  };

  let getOptions = () => {
    // console.log(plotSeries);
    return {
      title: {
        text: "Stacked Line",
      },
      tooltip: {
        trigger: "axis",
      },
      legend: {
        data: _blocks,
      },
      grid: {
        left: "100",
        top: "30",
        bottom: "100",
        containLabel: true,
      },
      toolbox: {
        show: true,
        orient: "vertical",
        top: "center",
        right: 0,
        feature: {
          dataZoom: {
            yAxisIndex: "none",
            title: {
              zoom: "Zoom in",
              back: "Zoom out",
            },
          },
          restore: {},
          magicType: {
            show: true,
            type: ["line", "bar", "stack"],
            title: {
              line: "Line",
              bar: "Bar",
              stack: "Stack",
            },
          },
          saveAsImage: {
            show: true,
            name: "senna",
            title: "Save Image",
          },
        },
      },
      xAxis: {
        name: "Weeks",
        type: "category",
        nameLocation: "middle",
        nameGap: 80,
        data: ["Week6", "Week5", "Week4", "Week3", "Week2", "Week1", "Week0"],
      },
      yAxis: {
        name: "Value",
        type: "value",
        nameLocation: "middle",
        nameGap: 80,
      },
      color: [
        "#23f3de",
        "#a7904d",
        "#8df238",
        "#12a681",
        "#3db704",
        "#9c1773",
        "#646139",
        "#41477a",
        "#553859",
        "#058dda",
        "#de1681",
        "#0e25c9",
        "#72d0e9",
        "#ccac3e",
        "#eb212b",
        "#fbf49a",
        "#12a681",
        "#b86cb4",
      ],
      series: plotSeries,
    };
  };

  let series = {
    name: "",
    type: "line",
    stack: "",
    smooth: false,
    itemStyle: { normal: { label: { show: true } } },
    data: [],
    markLine: {
      data: [
        {
          symbol: "none",

          name: "xxxxx",
          yAxis: 0,
          label: {
            formatter: "Past to Present Week",
            position: "end",
            show: true,
          },
          lineStyle: {
            color: "black",
            width: 1,
          },
          position: "insideStartTop",
        },
      ],
    },
  };

  let createSeries = (name, serData) => {
    let tmp = _.cloneDeep(series);
    tmp["name"] = name;
    tmp["data"] = serData;
    plotSeries.push(tmp);
  };

  let sortObject = (obj) => {
    return Object.keys(obj)
      .sort()
      .reduce(function (result, key) {
        result[key] = obj[key];
        return result;
      }, {});
  };

  let plot = (e, row) => {
    _rows = [];
    _blocks = [];
    plotSeries = [];
    let allRowsData = tableInst.getData();
    getFlattenedRows(allRowsData);
    let rowsData = _rows;
    for (let rowData of rowsData) {
      let temp = [];
      rowData = sortObject(rowData);
      for (let [key, value] of Object.entries(rowData)) {
        // console.log(key,"<---->", value);
        if (key.includes("week")) {
          if (value != undefined) {
            temp.push(value.split("/").pop());
          } else {
            temp.push("");
          }
        }
      }
      // console.log("Final:",temp);
      createSeries(rowData.block, temp.reverse());
      // console.log(temp);
    }
    const titleElement = `HierTimeMetrics: ${props.config?.hierTimeMetric.replace(
      "__",
      "|"
    )}`;
    const yCoord = props.widgetProps.y;
    const currentReportName = props.widgetProps;
    // console.log(props.widgetProps);
    let _title = props.widgetProps.config.title
      ? props.widgetProps.config.title
      : "Metrics";
    addWidgets({
      widgets: [
        {
          name: "Metrics Group Bar Chart",
          reportName: props.reportKey, // important
          width: 20,
          height: 12,
          y: yCoord + 1,
          config: {
            title: `Bar/Line chart : For MetricsHierTime-(Parent Widget:${_title}, ${titleElement})`,
            dataLocation: "dataLocation",
            bucket: "bucket",
            data: "",
            columns: [],
            // query: _.get(data, "query", defaultQueryBody),
            groupingAxis: "Y",
          },
          data: getOptions(),
        },
      ],
    });
    // let data = calculateChartData(buildName, checkpoint, args, rowsData)
  };
  const handleRowContextMenuSetBaseline = {
    label: "<b> Open in Chart </b>",
    action: plot,
  };
  //-----------------------------------------------------------

  let rowClick = (e, row) => {
    if (tableInst == null) {
      return;
    }
    row.toggleSelect();

    // if (selectedRows.length != 0) {
    //     const index = selectedRows.indexOf(row);
    //     if (index > -1) {
    //         selectedRows.splice(index, 1); // 2nd parameter means remove one item only
    //     }
    // }

    // selectedRows.push(row);
    // console.log(selectedRows);
  };

  const getRowContextMenu = () => {
    let rowContextMenu = [];
    rowContextMenu.push(handleRowContextMenuSetBaseline);
    return rowContextMenu;
  };

  const getColumns = () => {
    let col = null;
    let tableColumns = [];
    col = {
      title: "Block",
      field: "block",
      frozen: true,
      headerSort: false,
      // formatter: (cell, formatterParams, onRendered) => this.cellFormatter(cell, formatterParams, onRendered),
    };
    tableColumns.push(col);

    col = { title: "Instance", field: "instance", headerSort: false };
    tableColumns.push(col);

    col = {
      title: "Metric",
      field: "metric",
      headerSort: false,
      formatter: getColumnValue,
    };
    tableColumns.push(col);
    //---------------------------
    col = {
      title: `Current Week(Week 0)`,
      field: `lb_week_0`,
      headerSort: false,
      formatter: getValue,
      tooltip: CustomTooltip,
    };
    tableColumns.push(col);

    col = {
      title: `Week 1`,
      field: `lb_week_1`,
      headerSort: false,
      formatter: getValue,
      tooltip: CustomTooltip,
    };
    tableColumns.push(col);

    col = {
      title: `Week 2`,
      field: `lb_week_2`,
      headerSort: false,
      formatter: getValue,
      tooltip: CustomTooltip,
    };
    tableColumns.push(col);

    col = {
      title: `Week 3`,
      field: `lb_week_3`,
      headerSort: false,
      formatter: getValue,
      tooltip: CustomTooltip,
    };
    tableColumns.push(col);

    col = {
      title: `Week 4`,
      field: `lb_week_4`,
      headerSort: false,
      formatter: getValue,
      tooltip: CustomTooltip,
    };
    tableColumns.push(col);

    col = {
      title: `Week 5`,
      field: `lb_week_5`,
      headerSort: false,
      formatter: getValue,
      tooltip: CustomTooltip,
    };
    tableColumns.push(col);

    col = {
      title: `Week 6`,
      field: `lb_week_6`,
      headerSort: false,
      formatter: getValue,
      tooltip: CustomTooltip,
    };
    tableColumns.push(col);

    return tableColumns;
  };

  let getColumnValue = (cell, formatterParams, onRendered) => {
    let val = cell.getValue();
    if (val != undefined) {
      // console.log(val.split("/")[5]);
      return val.replace("__", "|");
    }
  };

  let CustomTooltip = (mPosition, cell, onRendered) => {
    let val = cell.getValue();
    if (val != undefined) {
      val = val.split("/");
      val.pop();
      // console.log(val);
      var el = document.createElement("div");
      el.style.backgroundColor = "black";
      el.style.color = "white";
      el.style.height = "35px";
      el.innerText = val.join("/");

      return el;
      // return val.join("/");
    }
  };

  let getValue = (cell, formatterParams, onRendered) => {
    let val = cell.getValue();
    if (val != undefined) {
      // console.log(val.split("/")[5]);
      return val.split("/")[5].split("|").slice(0)[0];
    }
  };

  const handleCheckpointCancel = () => {
    props.handleOpenCheckpoint(false);
  };

  let afterTableBuilt = () => {
    // let rows = tableInst.getRows();
    // if (rows.length > 0) {
    //     for (let r in rows) {
    //         applyColor(rows[r]);
    //         recursiveCall(rows[r])
    //     }
    // }
  };

  const getReportMenu = () => {
    return (
      <div id="reportMenu" style={{ width: "100%", height: "30px" }}>
        <ButtonGroup size="small" variant="text">
          <Chip
            label={props.config.currentReportName}
            sx={{ height: "28px" }}
            variant={"outlined"}
            onClick={() => {
              props.handleReportsPane(true);
            }}
          />
          {/* <Button onClick={() => props.handleOpenCheckpoint(true)}>Checkpoints</Button> */}
        </ButtonGroup>
      </div>
    );
  };

  const metricFormatter = (cell, params, onRendered) => {
    let metric = cell.getValue();
    let data = cell.getData();
    if (
      _.get(data, "metricKey", "") == _.get(reportConfig, "selectedMetric", "")
    ) {
      const row = cell.getRow();
      console.log(row);
      row.select();
    }
    return _.get(metric, "displayName", "");
  };

  const initTable = async () => {
    let config = props.config;
    let columns = getColumns();
    tableInst = new Tabulator(tableRef, {
      // className: "table-sm table-striped table-bordered",
      layout: "fitDataStretch",
      data: [],
      //rowHeight: 40,
      selectableRows: false,
      // pagination: true, //enable.
      // paginationMode: "remote", //enable remote pagination
      // sortMode: "remote",
      // filterMode: "remote",
      // ajaxConfig: "POST",
      // paginationSize: 25,
      // paginationSizeSelector: [10, 25, 50, 100, 200],
      // paginationCounter: "rows",
      // ajaxURL: metricsURL + "getHierTime/",
      // ajaxContentType: "json",
      // ajaxParams: {
      //   selectedBuilds: props.buildSpec ? props.buildSpec : [],
      //   // report: reportConfig?.report ? reportConfig?.report : {},
      //   reportSpecName: props.config.reportSpecName,
      //   reportName: config.currentReport,
      //   metric: selectedMetric,
      //   hierSpec: props.hierSpec,
      //   auth: {
      //     user: _.get(useConfigStore.getState(), "authLoginUser", ""),
      //   },
      //   // rawQuery: _.get(props.config, "query", ""),
      //   // variables: _.get(props.config, "wVariables", {}),
      // },
      // ajaxResponse: (url, params, responseData) => {
      //   const tabulatorLoreFormat = {
      //     data: responseData.rows ? responseData.rows : [],
      //     last_page: responseData.lastPage ? responseData.lastPage : 0,
      //     last_row: _.get(
      //       responseData,
      //       "completeCount",
      //       _.get(responseData, "lastPage", 0) * 25
      //     ),
      //   };
      //   return tabulatorLoreFormat;
      // },
      // paginationCounter: "rows",
      dataTree: true,
      dataTreeStartExpanded: true,
      // responsiveLayout: true,
      rowContextMenu: getRowContextMenu,
      columns: columns ? columns : [],
      height: "100%",
      width: "100%",
      // groupBy: ["block"],
      groupToggleElement: "header",
      columnDefaults: {
        headerFilterPlaceholder: "...",
      },
    });
    // tableInst.on("rowMouseEnter", rowMouseEnter);
    // tableInst.on("rowClick", rowClick);
    // tableInst.on("tableBuilt", afterTableBuilt);
  };

  const setTableData = async (selectedMetric) => {
    let config = props.config;
    const response = await api(metricsURL + "getHierTime/", {
      // selectedBuilds: props.buildSpec ? props.buildSpec : [],
      // report: reportConfig?.report ? reportConfig?.report : {},
      // reportSpecName: props.config.reportSpecName,
      projects: useConfigStore.getState().metricProjectName,
      // reportName: config.currentReport,
      metric: selectedMetric,
      spec: props.hierSpec,
      auth: {
        user: _.get(useConfigStore.getState(), "authLoginUser", ""),
      },
      // rawQuery: _.get(props.config, "query", ""),
      // variables: _.get(props.config, "wVariables", {}),
    });
    if (response && response.status) {
      if (tableInst == null) {
        initTable();
      }
      tableInst.setData(_.get(response, "rows", []));
    }
  };

  const metricsRowClick = (event, _row) => {
    const data = _row.getData();
    const newReportConfig = _.cloneDeep(reportConfig);
    newReportConfig.selectedMetric = _.get(data, "metricKey", "");
    setReportConfig(newReportConfig);
    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[props.config.currentReport] = newReportConfig;
    // console.log(newConfig);
    props.updateReportConfig(newConfig, false);

    let metric = _.get(data, "metric", {});
    let indexList = _.get(metric, "indexList", []);
    if (indexList && indexList.length && Array.isArray(indexList)) {
      setTableData(indexList[5] + "__" + indexList[7]);
    }
    // initTable(_.get(data, "metricKey", ""));
  };

  useEffect(() => {
    // console.log(props.config);
    const initMetricsTable = async () => {
      let config = props.config;
      let columns = [
        { title: "Metric", field: "metric", formatter: metricFormatter },
        { title: "MetricKey", field: "metricKey", visible: false },
      ];
      const data = Object.entries(
        props.reportSpec.reportNames.dashboard_hier.metrics
      ).map(([key, metric]) => {
        return {
          metric: metric,
          metricKey: key,
        };
      });
      if (metricTableInst === null) {
        metricTableInst = new Tabulator(metricTableRef, {
          // className: "table-sm table-striped table-bordered",
          layout: "fitDataStretch",
          index: "metricKey",
          //rowHeight: 40,
          selectableRows: 1,
          columns: columns ? columns : [],
          data: data,
          height: "100%",
          width: "100%",

          // groupBy: ["block"],
          groupToggleElement: "header",
          columnDefaults: {
            headerFilterPlaceholder: "...",
          },
        });
        // console.log(reportConfig,_.get(reportConfig, "selectedMetric", ""),data);
        // metricTableInst.selectRow(_.get(reportConfig, "selectedMetric", ""));
        metricTableInst.on("rowClick", metricsRowClick);
        metricTableInst.scrollToRow(
          reportConfig.selectedMetric,
          "center",
          false
        );
        // tableInst.on("rowMouseEnter", rowMouseEnter);
        // tableInst.on("tableBuilt", afterTableBuilt);
      } else {
        console.log("Table replace data");
        // this.resizeTable();
      }
    };

    initMetricsTable();
    initTable();
    let metricData = Object.keys(
      props.reportSpec.reportNames.dashboard_hier.metrics
    ).includes(reportConfig.selectedMetric)
      ? props.reportSpec.reportNames.dashboard_hier.metrics[
          reportConfig.selectedMetric
        ]
      : {};
    // let metricData = _.get(
    //   props.reportSpec.reportNames.dashboard_hier.metrics,
    //   reportConfig.selectedMetric,
    //   {}
    // );
    // let metricValue = _.get(metricData, "metric", {});
    let indexList = _.get(metricData, "indexList", []);
    if (indexList && indexList.length && Array.isArray(indexList)) {
      setTableData(indexList[5] + "__" + indexList[7]);
    }
  }, []);

  return (
    <>
      <div id="HierTimeDashboard" style={{ width: "100%", height: "100%" }}>
        {getReportMenu()}
        <div
          id="HierTableArea"
          style={{
            width: "100%",
            height: "calc(100% - 30px)",
            display: "flex",
          }}
        >
          <div id="analytics" style={{ width: "20%", height: "calc(100%)" }}>
            <div
              ref={(r) => {
                metricTableRef = r;
              }}
            ></div>
          </div>
          <div id="analytics" style={{ width: "80%", height: "calc(100%)" }}>
            <div
              //   id="divConfigMainTable"
              //   className="divStandardBackgroundColor"
              // className= "table-bordered"
              ref={(r) => {
                tableRef = r;
              }}
            ></div>
          </div>
        </div>
      </div>
    </>
  );
}
