import React from "react";
import { useState, useEffect, useRef, memo } from "react";
import { shallow } from "zustand/shallow";
import { produce } from "immer";
// import { ReactTabulator } from "react-tabulator";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import Builds from "../dialogs/BuildsModal";

import axios from "axios";
import _ from "lodash";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

//color
import { calcCell, _colors } from "../../../../../common/color";
import useConfigStore from "../../../../../store/useConfigStore";
import useGlobalStore from "../../../../../store/useGlobalStore";

import { tags } from "../../../../../constants/constants";
import { getBuildsNomenclature } from "../../../../../common/utils/utils";
import * as utils from "../../../../../common/utils/utils";
import api from "common/api/api";

import {
  customInput,
  customFilter,
  customFilterDisplayValue,
  globFilterDisplayValue,
  dateFromSeconds,
} from "../../../../../common/filter";
import {
  customFilterDisplayValueTooltip,
  globFilterDisplayValueTooltip,
} from "../../../../../common/tooltip";

//mui components
import {
  Button,
  ButtonGroup,
  Checkbox,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  InputLabel,
  Menu,
  MenuItem,
  Modal,
  Paper,
  Select,
  Stack,
  Typography,
} from "@mui/material";
import { Box } from "@mui/system";

//mui styles
import { styled, alpha } from "@mui/material/styles";

//icon
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

import {
  addWidgetCommonFunction,
  showConfigUiState,
  showWidgetDataUiState,
  widgets,
} from "../../../../../pages/rptdashboard/addWidget/addWidget";
import Checkpoints from "../dialogs/CheckpointsModal";

const StyledMenu = styled((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 100,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      fontSize: 12,
      "& .MuiSvgIcon-root": {
        // fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

let shouldComponentUpdate = (prevProps, nextProps) => {
  console.log("updating TableDetailReport");
  return false;
};

const TableDetailReport = memo(function TableDetailReport(props) {
  let tableRef = React.createRef();
  let tableInst = null;
  let prevRowHighlighted = null;
  let customContexts = [];
  let rowsColor = [];
  let c = [];
  let r = [];
  const metricsURL =
    useConfigStore.getState().configData.rest_server_url + "/metrics/";

  const isNumber = (value) => {
    return !isNaN(value) && !isNaN(parseFloat(value));
  };

  const [showFormat, setShowFormat] = useState(false);
  const [reportConfig, setReportConfig] = useState(
    props.config.savedReportConfig[props.config.currentReport]
  );
  const [openMetrics, setOpenMetric] = useState(false);
  const [metrics, setMetrics] = useState(
    _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "metricsConfig",
      {}
    )
  );

  const [openBuilds, setOpenBuilds] = useState(false);
  const [buildsNomenclature, setBuildsNomenclature] = useState(
    _.get(props.config.buildsConfig, "buildsNomenclature", {})
  );
  const [hiddenBuilds, setHiddenBuilds] = useState(
    _.get(props.config.buildsConfig, "hiddenBuilds", [])
  );

  const [openDownloadMenu, setOpenDownloadMenu] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  let newCols = [];

  //refs
  const tableDetailRef = useRef(null);

  const handleSaveBuilds = (hiddenBuildsList = []) => {
    const newConfig = _.cloneDeep(props.config);

    newConfig.buildsConfig = {
      buildsNomenclature: buildsNomenclature,
      hiddenBuilds: hiddenBuildsList,
    };

    props.updateReportConfig(newConfig);
  };

  const handleBuildsNameCheck = (tag, event) => {
    const newBuildsNomenclature = _.cloneDeep(buildsNomenclature);
    newBuildsNomenclature[tag] = { show: event.target.checked };
    setBuildsNomenclature(newBuildsNomenclature);
  };

  const handleOpenBuilds = (flag) => {
    setOpenBuilds(flag);
  };

  const handleBuildsCancel = () => {
    setBuildsNomenclature(
      _.get(props.config.buildsConfig, "buildsNomenclature", {})
    );
    handleOpenBuilds(false);
  };

  const handleCheckpointCancel = () => {
    props.handleOpenCheckpoint(false);
  };

  const buildColumnFormater = (cell, formatterParams, onRendered) => {
    return getBuildsNomenclature(
      cell.getValue(),
      buildsNomenclature,
      _.get(cell.getData(), "LABEL", "")
    );
  };

  const addColumn = ({
    rootGroupObj = {},
    col = {},
    groupEnable = false,
    groupNames = [],
    groupContextMenu = [],
    headerAttrObj = {},
  } = {}) => {
    let nextRootGroupObj = _.cloneDeep(rootGroupObj);

    let headerTooltip = col.headerTooltip;

    if (groupEnable == false || groupNames.length == 0) {
      // Group processing NOT needed.
      nextRootGroupObj.columns.push(col);
    } else {
      // Group processing needed.
      let parentGroupObj = nextRootGroupObj;
      let lastGroupObj;

      for (let i = 0; i < groupNames.length; i++) {
        let groupName = groupNames[i];

        let newGroupObj = {
          title: groupName,
          columns: [],
          headerTooltip: headerTooltip,
        };

        if (groupContextMenu.length != 0) {
          newGroupObj.headerContextMenu = groupContextMenu;
        }

        for (let attr in headerAttrObj) {
          newGroupObj[attr] = headerAttrObj[attr];
        }

        if (parentGroupObj.columns.length == 0) {
          parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
        }
        lastGroupObj =
          parentGroupObj.columns[parentGroupObj.columns.length - 1];

        if (i != groupNames.length - 1) {
          // This is NOT the last groupName
          if (
            lastGroupObj.title == groupName &&
            lastGroupObj.hasOwnProperty("columns")
          ) {
          } else {
            parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
            lastGroupObj =
              parentGroupObj.columns[parentGroupObj.columns.length - 1];
          }
          parentGroupObj = lastGroupObj;
        } else {
          // This is the last groupName
          if (
            lastGroupObj.title == groupName &&
            lastGroupObj.hasOwnProperty("columns")
          ) {
          } else {
            parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
            lastGroupObj =
              parentGroupObj.columns[parentGroupObj.columns.length - 1];
          }
          lastGroupObj.columns.push(col);
        }
      }
    }

    return nextRootGroupObj;
  };

  const getGroupNames = (groupName) => {
    let groupNames;
    if (groupName == null || groupName == "") {
      groupNames = [];
    } else {
      let textToSplit = groupName;
      groupNames = [];
      // Note: "^" is the separator char
      // Note: "`" is the blank char
      for (let name of textToSplit.split("^")) {
        if (name == "`") {
          name = "";
        }
        groupNames.push(name);
      }
    }
    return groupNames;
  };

  let dateFormatter = (cell, formatterParams, onRendered) => {
    let seconds = cell.getValue();
    return dateFromSeconds(seconds);
  };

  var hideColumn = [
    {
      label: "Hide Column",
      action: function (e, column) {
        e.stopPropagation();
        column.hide();
      },
    },
  ];

  const getColor = (cell) => {
    let element = cell.getElement();
    let field = cell.getColumn().getField();
    let rowData = cell.getRow().getData();

    const colors = { foreground: "#000000", background: "#ffffff" };
    if (rowData.colors) {
      colors.foreground = _.get(rowData.colors[field], "foreground", "#000000");
      colors.background = _.get(rowData.colors[field], "background", "#ffffff");
    }
    return colors;
  };

  const getLinks = (cell) => {
    let field = cell.getField();
    let rowData = cell.getData();

    if (rowData?.links?.[field]) {
      return rowData.links[field];
    }
    return null;
  };

  const cellFormatter = (cell, formatterParams, onRendered) => {
    let element = cell.getElement();

    let cellValue = cell.getValue();

    let displayValue = null;

    if (typeof cellValue == "string") {
      let value = cellValue.split(/\|\|\|/);
      displayValue = value[0];
    } else if (Array.isArray(cellValue)) {
      displayValue = cellValue[0];
    } else {
      displayValue = cellValue;
    }

    // let fg = funcs.palette("Default").fg;
    // let bg = funcs.palette("Default").bg;

    // if (getLinks(cell)) {
    //   var a = document.createElement("i");
    //   var linkText = document.createTextNode(cellValue);
    //   a.appendChild(linkText);
    //   a.title = cellValue;

    //   onRendered(function () {
    //     element.appendChild(a);
    //   });
    // } else {
    //   let newDiv = document.createElement("div");
    //   newDiv["innerHTML"] = displayValue != undefined ? displayValue : "";
    //   onRendered(function () {
    //     element.appendChild(newDiv);
    //   });
    // }

    const colors = getColor(cell);
    if (colors) {
      element.style.color = colors.foreground;
      element.style.backgroundColor = colors.background;
    } else {
      element.style.color = "black";
      element.style.backgroundColor = "white";
    }

    return displayValue;
  };

  const getColumns = (keys = []) => {
    let col = null;
    let rootGroupObj = {};
    rootGroupObj.title = null;
    rootGroupObj.columns = [];

    col = {
      title: "Build",
      field: "buildName",
      headerSort: false,
      frozen: true,
      visible: true,
      // headerContextMenu: hideColumn,
      headerFilter: customInput,
      headerFilterFunc: globFilterDisplayValue,
      resizable: true,
      headerTooltip: customFilterDisplayValueTooltip,
      formatter: buildColumnFormater,
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });

    col = {
      title: "Checkpoint",
      field: "checkpoint",
      frozen: true,
      visible: true,
      headerSort: false,
      headerFilter: customInput,
      headerFilterFunc: globFilterDisplayValue,
      resizable: true,
      headerTooltip: customFilterDisplayValueTooltip,
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });

    col = {
      title: "Time Stamp",
      field: "timeStop",
      frozen: true,
      visible: true,
      headerSort: false,
      formatter: dateFormatter,
      resizable: true,
      // headerFilter: customInput,
      // headerFilterFunc: globFilterDisplayValue,
      headerTooltip: customFilterDisplayValueTooltip,
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });

    if (
      props.config.savedReportConfig[props.config.currentReport] &&
      props.config.savedReportConfig[props.config.currentReport]?.keys
    ) {
      for (let keyItem of props.config.savedReportConfig[
        props.config.currentReport
      ]?.keys) {
        col = {
          title: keyItem,
          field: keyItem,
          sorter: true,
          headerSort: true,
          headerSortTristate: true,
          frozen: true,
          visible: true,
          headerFilter: customInput,
          headerFilterFunc: globFilterDisplayValue,
          resizable: true,
          headerTooltip: customFilterDisplayValueTooltip,
          headerContextMenu: hideColumn,
          formatter: (cell, formatterParams, onRendered) =>
            cellFormatter(cell, formatterParams, onRendered),
        };
        rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });
      }
    }

    console.log(rootGroupObj, keys);
    for (let colIndex = 0; colIndex < keys.length; colIndex++) {
      rootGroupObj = addColumn({
        rootGroupObj: rootGroupObj,
        col: {
          title: keys[colIndex],
          field: keys[colIndex],
          headerSort: false,
          frozen: true,
          visible: true,
          // headerContextMenu: hideColumn,
          headerFilter: customInput,
          headerFilterFunc: globFilterDisplayValue,
          resizable: true,
          headerTooltip: customFilterDisplayValueTooltip,
        },
      });
    }
    let Metrics =
      props.reportSpec.reportNames[props.config.currentReport].metrics;

    for (let metricName of Object.keys(Metrics)) {
      let itemM = Metrics[metricName];
      let visible = !itemM.hidden;
      let fieldName = "";
      let temp = itemM["indexList"];
      // console.log(temp);
      let displayName = itemM?.displayName;
      let groupName = itemM?.groupName;
      if (temp && temp.length > 7) {
        fieldName = temp[5] + "__" + temp[7];
      } else if (temp && temp.length > 4) {
        fieldName = temp[4];
      } else {
        if (displayName.toLowerCase() == "user") {
          fieldName = "system__" + displayName.toLowerCase();
        } else if (displayName.toLowerCase() == "date") {
          fieldName = "system__timeStopHuman";
        } else {
          fieldName = metricName;
        }
      }
      let groupNames = getGroupNames(groupName);
      if (!displayName) {
        displayName = metricName.includes("|")
          ? metricName.split("|")[1]
          : metricName; // colConfig[col]["displayName"]
      }
      let col = {
        title: displayName,
        field: fieldName,
        visible: !_.get(
          _.get(metrics, fieldName, { hidden: false }),
          "hidden",
          false
        ),
        sorter: true,
        headerSort: true,
        headerSortTristate: true,
        headerFilter: customInput,
        headerFilterFunc: customFilterDisplayValue,
        resizable: true,
        headerTooltip: customFilterDisplayValueTooltip,
        headerContextMenu: hideColumn,
        formatter: (cell, formatterParams, onRendered) =>
          cellFormatter(cell, formatterParams, onRendered),
      };

      rootGroupObj = addColumn({
        rootGroupObj: rootGroupObj,
        col: col,
        groupEnable: true,
        groupNames: groupNames,
        //   groupContextMenu: headerContextMenuGroup,
      });
    }
    return rootGroupObj.columns;
  };

  let rowContextMenuSetBaseline = (e, row) => {
    let buildName = row.getData().buildName;
    let chkpt = row.getData().checkpoint;
    let timeStamp = row.getData().timeStop;

    props.setBaselineBuildCheckpoint(buildName, chkpt, timeStamp);
    // props.setBaselineCheckpoint(chkpt);
    const pass = clearColor();
    if (pass) {
      // afterTableBuilt();
    }
  };
  const handleRowContextMenuSetBaseline = {
    label: "Set baseline",
    action: rowContextMenuSetBaseline,
  };
  //-----------------------------------------------------------

  let rowClick = (e, row) => {
    if (tableInst == null) {
      return;
    }
    row.toggleSelect();

    // if (selectedRows.length != 0) {
    //     const index = selectedRows.indexOf(row);
    //     if (index > -1) {
    //         selectedRows.splice(index, 1); // 2nd parameter means remove one item only
    //     }
    // }

    // selectedRows.push(row);
    // console.log(selectedRows);
  };

  //Plotting
  let addWidgets = (wProps) => {
    console.log(wProps);
    for (let i = 0; i < wProps.widgets.length; i++) {
      const widgetsSettings = produce(wProps.widgets[i], (settingsDraft) => {
        console.log(settingsDraft);
        delete settingsDraft.currentReportName;
        delete settingsDraft.data;
      });

      const data = _.get(wProps.widgets[i], "data", {});
      console.log(data);
      addWidgetCommonFunction(
        props.rptType,
        props.reportKey,
        widgetsSettings,
        data,
        showWidgetDataUiState,
        props.index
      );
    }
  };

  let plot = (e, row) => {
    const buildName = row.getData().buildName;
    const checkpoint = row.getData().checkpoint;
    const clicked = e.target.innerText;
    let titleElement = null;
    // console.log(clicked, checkpoint, buildName);
    let args = null;
    let rows = null;
    let rowsData = [];
    for (let i in customContexts) {
      if (clicked == customContexts[i].label) {
        args = customContexts[i].args;
      }
    }
    console.log(e.target.innerText, args);
    if (args.X == "builds") {
      rows = tableInst.getRows().filter((r) => {
        return r.getData().checkpoint == checkpoint;
      });
      titleElement = "Common Checkpoint: " + checkpoint;
    } else {
      rows = tableInst.getRows().filter((r) => {
        return r.getData().buildName == buildName;
      });
      titleElement = "Common Build: " + buildName;
    }
    for (let id in rows) {
      rowsData.push(rows[id].getData());
    }
    axios
      .post(metricsURL + "calcBarLineCharts/", {
        buildName: buildName,
        checkpoint: checkpoint,
        args: args,
        rows: rowsData,
      })
      .then((response) => {
        let status = _.get(response.data, "status", false);
        if (status) {
          let data = _.get(response.data, "data", []);
          const yCoord = props.widgetProps.y;
          const currentReportName = props.widgetProps;
          // console.log(props.widgetProps);
          let _title = props.widgetprops.config.savedReportConfig[
            props.config.currentReport
          ].title
            ? props.widgetprops.config.savedReportConfig[
                props.config.currentReport
              ].title
            : "Metrics";
          addWidgets({
            widgets: [
              {
                name: "Metrics Group Bar Chart",
                reportName: props.reportKey, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Bar/Line chart : For Metrics-(Parent Widget:${_title}, ${titleElement})`,
                  dataLocation: "dataLocation",
                  bucket: "bucket",
                  data: "",
                  columns: [],
                  // query: _.get(data, "query", defaultQueryBody),
                  groupingAxis: args.X == "Y",
                },
                data: data,
              },
            ],
          });
        } else {
          let message = _.get(response.data, "message", "");
          console.log(message);
        }
      })
      .catch((error) => {
        console.log(error);
      });
    // let data = calculateChartData(buildName, checkpoint, args, rowsData)
  };

  //create query which will be prepended
  //this is creating a string which will declare variables in the query
  let createPreQuery = () => {
    let _query =
      props.config.savedReportConfig[props.config.currentReport]?.query;
    let preQuery = "";
    let value = null;
    if (_query != undefined && _query != null) {
      var lines = _query.split("\n");
      var filterred = lines.filter(function (line) {
        return line.indexOf("#") != 0;
      });
      // console.log(filterred);
      for (let line of filterred) {
        _query = String(line).replace(/[\t ]+/g, "");
        const regVariable = 'df\\["(?<key>\\w+)"\\]=\\W*(?<value>[\\w]+)\\W*';
        const pattern = new RegExp(regVariable, "g");
        const variables = [..._query.matchAll(pattern)].map(
          (item) => item.groups
        );
        // console.log(variables);
        if (
          variables.length > 0 &&
          variables[0].key.startsWith("__") &&
          !["__contextMenu", "__obtype", "__object", "__ttype"].includes(
            variables[0].key
          )
        ) {
          if (!isNumber(variables[0].value)) {
            value = `"${variables[0].value}"`;
          } else {
            value = variables[0].value;
          }
          preQuery = preQuery + `${variables[0].key} = ${value}\n`;
        }
      }
    }
    return preQuery;
  };

  //add widget from custom menu
  let addCustomWidget = async (e, row) => {
    const clicked = e.target.innerText;
    const buildNameArray = row.getData().buildName.split("/");
    const checkpoint = row.getData().checkpoint;
    const project = buildNameArray[0];
    const user = buildNameArray[1];
    const block = buildNameArray[2];
    const phase = buildNameArray[3];
    const runTag = buildNameArray[4];
    const timeStamp = row.getData().timeStop;
    let cluster = "c0";

    let args = null;
    for (let i in customContexts) {
      if (clicked == customContexts[i].label) {
        args = customContexts[i].args;
      }
    }
    //new argument copy for config of the widget
    console.log(e, row, args, buildNameArray, timeStamp, checkpoint);
    let argsCopy = _.cloneDeep(args);
    const wid = args.wid;
    delete argsCopy.wid;

    //handling scenario
    let scenario = null;
    if (args.hasOwnProperty("scenario")) {
      scenario = args.scenario;

      //delete sceanrio key as it is not needed in config
      delete argsCopy.scenario;
    }

    //root level data location from aprent widget and not the report
    cluster = await utils.getClusterName(
      user,
      block,
      phase,
      runTag,
      checkpoint,
      timeStamp,
      project
    );
    let dataLocation = `${cluster}#task_reports/${user}/${block}/${phase}/${runTag}/${checkpoint}/${timeStamp}`;
    console.log(dataLocation);

    //change data location if given in argruments
    if (args.hasOwnProperty("dataLocation")) {
      dataLocation = args.dataLocation;
      delete argsCopy.dataLocation;
    }

    let bucket = project; // Project name
    if (args.hasOwnProperty("bucket")) {
      bucket = args.bucket;
      delete argsCopy.bucket;
    }

    // add handle query
    const preQuery = createPreQuery();
    console.log(preQuery);

    // all other arguments left after wid, sceanrio, dataLocation , bucktes are handled
    // this copy of arguments will be merged with config from widget library
    let configCopy = argsCopy;

    //get widget Template from widget Library
    const wTemplate = await utils.getWidgetFromLib(wid);

    //recuntruct the widget settings and config from template
    const settings = utils.getWidgetSettings(wTemplate.widget_name, wTemplate);

    //if scenario is given then add to data location
    if (scenario) {
      dataLocation = dataLocation + "/" + scenario;
    }

    let newConfig = _.cloneDeep(settings.config);

    // merging new config with arguments
    newConfig = { ...newConfig, ...configCopy };

    // over write data location and bucket with values that was handled earlier
    newConfig.dataLocation = dataLocation;
    newConfig.bucket = bucket;

    //handle query if exists
    if (newConfig.hasOwnProperty("query")) {
      newConfig.query = preQuery + newConfig.query;
      console.log(newConfig.query);
    }

    //prepare final widget settings
    settings.config = newConfig;
    settings.h = widgets[wTemplate.widget_name].height;
    settings.w = widgets[wTemplate.widget_name].width;
    settings.y = props.widgetProps.y + 1;
    settings.x = props.widgetProps.x;
    settings.name = wTemplate.widget_name;
    addWidgetCommonFunction(
      props.rptType,
      props.reportKey,
      settings,
      {},
      showConfigUiState,
      props.index
    );
  };

  let parseQueryContextMenus = () => {
    let _query =
      props.config.savedReportConfig[props.config.currentReport]?.query;
    // let customMenu = [];
    if (_query != undefined && _query != null) {
      var lines = _query.split("\n");
      var filterred = lines.filter(function (line) {
        return line.indexOf("#") != 0;
      });
      // console.log(String(filterred));
      _query = String(filterred).replace(/\s/g, ""); //.replaceAll("'", "|").replaceAll('"', "|");
      // console.log(String(_query));
      const pattern = new RegExp(
        '{"label":"(?<label>[\\w\\/-]+?)","action":"(?<action>\\w+?)","args":(?<args>{.*?})}',
        "g"
      );
      const cMenus = [..._query.matchAll(pattern)].map((item) => item.groups);
      // console.log(cMenus);
      for (let i in cMenus) {
        if (cMenus[i].action == "plot") {
          if (customContexts.length > 0) {
            let index = customContexts.findIndex(
              (x) => x.label == cMenus[i].label
            );
            index === -1
              ? customContexts.push({
                  label: cMenus[i].label,
                  action: plot,
                  args: JSON.parse(cMenus[i].args),
                })
              : console.log("Exist");
          } else {
            customContexts.push({
              label: cMenus[i].label,
              action: plot,
              args: JSON.parse(cMenus[i].args),
            });
          }
        } else if (cMenus[i].action == "addWidget") {
          if (customContexts.length > 0) {
            let index = customContexts.findIndex(
              (x) => x.label == cMenus[i].label
            );
            index === -1
              ? customContexts.push({
                  label: cMenus[i].label,
                  action: addCustomWidget,
                  args: JSON.parse(cMenus[i].args),
                })
              : console.log("Exist");
          } else {
            customContexts.push({
              label: cMenus[i].label,
              action: addCustomWidget,
              args: JSON.parse(cMenus[i].args),
            });
          }
        }
        // console.log(cMenus[i]);
      }
    }
    return customContexts;
  };

  const fetchImages = async (checkpoint) => {
    const config = _.get(props, "config", {});

    const input = {
      auth: {
        user: _.get(useConfigStore.getState(), "authLoginUser", ""),
      },
      checkpoint: checkpoint,
      reportSpecName: config?.reportSpecName ? config.reportSpecName : "",
      reportName: _.get(config, "currentReport", ""),
      selectedBuilds: _.get(props, "buildSpec", []),
    };

    const errorUiState = _.cloneDeep(showWidgetDataUiState);

    const responseData = await api(metricsURL + "getImagesForRuns", input);
    if (responseData.status) {
      if (_.get(responseData, "rows", []).length) {
        const widgetsSettings = {
          h: 10,
          w: 20,
          x: 0,
          y: _.get(props.widgetProps, "y", -2) + 1,
          name: "Table Detail Images",
          config: {
            title: "Images for checkpoint: " + checkpoint,
            images: _.get(responseData, "rows", []),
            isRefreshable: false,
          },
        };

        addWidgetCommonFunction(
          props.rptType,
          props.reportKey,
          widgetsSettings,
          {},
          showWidgetDataUiState,
          props.index
        );
      } else {
        errorUiState.isToastOpen = true;
        errorUiState.toastSeverity = "info";
        errorUiState.toastMessage = "No Image found";

        useGlobalStore.getState().setWidgetUiState(props.id, errorUiState);
      }
    } else {
      errorUiState.isToastOpen = true;
      errorUiState.toastSeverity = "error";
      errorUiState.toastMessage = "Failed to fetch image";
      useGlobalStore.getState().setWidgetUiState(props.id, errorUiState);
    }
  };

  const getImagesContextMenu = (rowData) => {
    const checkpoint = _.get(rowData, "checkpoint", "");
    return { label: "Show Images", action: () => fetchImages(checkpoint) };
  };

  const getRowContextMenu = (e, row) => {
    let rowContextMenu = [];
    let plotContextMenu = null;
    const rowData = row.getData();
    rowContextMenu.push(handleRowContextMenuSetBaseline);
    rowContextMenu.push(getImagesContextMenu(rowData));
    plotContextMenu = parseQueryContextMenus(
      props.config.savedReportConfig[props.config.currentReport]?.query
    );
    rowContextMenu = rowContextMenu.concat(plotContextMenu);
    // console.log(rowContextMenu);
    // rowContextMenu.push(JSON.parse(JSON.stringify(plotContextMenu)));
    return rowContextMenu;
  };

  let clearColor = () => {
    let color = _colors["Default"];
    let rows = tableInst.getRows();
    if (rows.length > 0) {
      for (let id in rows) {
        var xCells = rows[id].getCells();
        rows[id].getElement().style.background = color.bg;
        for (let index in xCells) {
          xCells[index].getElement().style.background = color.bg;
          xCells[index].getElement().style.color = color.fg;
        }
      }
    }
    return true;
  };

  const setAdditionalCols = (cols) => {
    //get existing columns
    const existingCols = tableInst.getColumnDefinitions();
    const newColsLength = cols.length;
    if (newColsLength) {
      //get columns after timestamp(index = 2) so we need to get next index
      const prevCols = existingCols.slice(3, 3 + newColsLength);
      //compare if the same columns existed earlier
      let sameColsFlag = true;
      for (let i = 0; i < prevCols.length; i++) {
        if (prevCols[i].field != cols[i]) {
          sameColsFlag = false;
          break;
        }
      }
      // if same columns did not exist then add new columns
      tableInst.setGroupBy(cols);
      if (!sameColsFlag) {
        for (let j = cols.length - 1; j >= 0; j--) {
          tableInst.addColumn(
            {
              title: cols[j],
              field: cols[j],
              sorter: true,
              headerSort: true,
              headerSortTristate: true,
              frozen: true,
              visible: true,
              headerFilter: customInput,
              headerFilterFunc: globFilterDisplayValue,
              resizable: true,
              headerContextMenu: hideColumn,
              formatter: (cell, formatterParams, onRendered) =>
                cellFormatter(cell, formatterParams, onRendered),
            },
            false,
            existingCols[2].field
          );
        }
      }
    }
  };

  const getPersistingProperty = (property) => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence") &&
      reportConfig.tablePersistence.hasOwnProperty(reportConfig.displayMode)
      ? _.get(
          reportConfig.tablePersistence[reportConfig.displayMode],
          property,
          []
        )
      : [];
  };

  const getInitialPageSize = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence")
      ? _.get(reportConfig.tablePersistence, "size", 25)
      : 25;
  };

  const getInitialPage = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence") &&
      reportConfig.tablePersistence.hasOwnProperty(reportConfig.displayMode)
      ? _.get(
          reportConfig.tablePersistence[reportConfig.displayMode],
          "page",
          1
        )
      : 1;
  };

  const persistTable = (
    keys = [],
    filters = [],
    sorters = [],
    size = 25,
    page = 1
  ) => {
    const newReportConfig = _.cloneDeep(
      props.config.savedReportConfig[props.config.currentReport]
    );
    if (newReportConfig.displayMode) {
      if (!newReportConfig.hasOwnProperty("tablePersistence")) {
        newReportConfig.tablePersistence = {};
      }
      if (
        !newReportConfig.tablePersistence.hasOwnProperty(
          newReportConfig.displayMode
        )
      ) {
        newReportConfig.tablePersistence[newReportConfig.displayMode] = {};
      }

      // set filters
      let uniqueFields = [];
      const cleanFilters = filters.map((filter) => {
        const newFilter = { ...filter };
        newFilter.type = "in";
        return newFilter;
      });

      const uniqueFilters = cleanFilters.filter((filter) => {
        if (uniqueFields.includes(_.get(filter, "field", ""))) {
          return false;
        }
        uniqueFields.push(_.get(filter, "field", ""));
        return true;
      });

      newReportConfig.tablePersistence[newReportConfig.displayMode].filters =
        uniqueFilters;
      //end setting filters

      // set sorters
      uniqueFields = [];
      const cleanSorters = sorters.map((sorter) => {
        const newSorter = { ...sorter };
        delete newSorter.column;
        newSorter.column = newSorter.field;
        delete newSorter.field;
        return newSorter;
      });

      const uniqueSorters = cleanSorters.filter((sorter) => {
        if (uniqueFields.includes(_.get(sorter, "field", ""))) {
          return false;
        }
        uniqueFields.push(_.get(sorter, "field", ""));
        return true;
      });

      newReportConfig.tablePersistence[newReportConfig.displayMode].sorters =
        uniqueSorters;
      // end setting sorters

      // set columns
      newReportConfig.tablePersistence[newReportConfig.displayMode].keys = keys;

      //set size
      newReportConfig.tablePersistence[newReportConfig.displayMode].size = size;

      //set page
      newReportConfig.tablePersistence[newReportConfig.displayMode].page = page;

      const newConfig = _.cloneDeep(props.config);
      newConfig.savedReportConfig[newConfig.currentReport] = newReportConfig;

      //update report config without rerender
      props.updateReportConfig(newConfig, false);
    }
  };

  const saveFormatOptions = () => {
    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[props.config.currentReport] = reportConfig;
    props.updateReportConfig(newConfig);
    setShowFormat(false);
  };

  const handleFormatChange = (formatKey, formatValue) => {
    const newReportConfig = _.cloneDeep(reportConfig);
    newReportConfig[formatKey] = formatValue;
    setReportConfig(newReportConfig);
  };

  const handleDownload = (fileFormat) => {
    const config = props.config;
    const input = {
      selectedBuilds: props.buildSpec ? props.buildSpec : [],
      report: {},
      reportSpecName: props.config.reportSpecName,
      reportName: props.config.currentReport,
      filter: getPersistingProperty("filters"),
      sort: getPersistingProperty("sorters"),
      auth: {
        user: _.get(useConfigStore.getState(), "authLoginUser", ""),
      },
      fileFormat: fileFormat,
      displayMode: props.config.savedReportConfig[props.config.currentReport]
        ?.displayMode
        ? props.config.savedReportConfig[props.config.currentReport]
            ?.displayMode
        : "VALUE",
      referenceMode:
        _.get(
          props.config.savedReportConfig[props.config.currentReport],
          "displayMode",
          "VALUE"
        ) !== "REFS_OFF",
      // referenceMode: props.config.savedReportConfig[props.config.currentReport]?.useMetricRefMode,
      baselineBuild: props.config.savedReportConfig[props.config.currentReport]
        ?.baselineBuild
        ? props.config.savedReportConfig[props.config.currentReport]
            ?.baselineBuild
        : "",
      baselineCheckpoint: props.config.savedReportConfig[
        props.config.currentReport
      ]?.baselineCheckpoint
        ? props.config.savedReportConfig[props.config.currentReport]
            ?.baselineCheckpoint
        : "",
      baselineTimestop: props.config.savedReportConfig[
        props.config.currentReport
      ]?.baselineTimestop
        ? props.config.savedReportConfig[props.config.currentReport]
            ?.baselineTimestop
        : "",
      showOnlyDiff: _.get(
        props.config.savedReportConfig[props.config.currentReport],
        "showDiff",
        false
      ),
      hideEmptyRows: !config.savedReportConfig[config.currentReport].showEmpty,
      rawQuery: _.get(props.config, "query", ""),
      variables: _.get(props.config, "wVariables", {}),
      hiddenBuilds: hiddenBuilds,
      metricsConfigs: metrics,
      hiddenCheckpoints: _.get(
        props.config,
        ["checkpointsConfig", "hiddenCheckpoints"],
        []
      ),
    };
    axios
      .post(metricsURL + "downloadDetailReportData/", input, {
        responseType: "blob",
      })
      .then((responseData) => {
        const blob = new Blob([responseData.data], {
          type: responseData.headers["Content-Type"],
        });

        const url = window.URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.href = url;
        link.setAttribute(
          "download",
          `${props.config.currentReportName}.${fileFormat}`
        );

        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);
      })
      .catch((error) => {
        console.log(error);
      });
    setOpenDownloadMenu(false);
    setAnchorEl(null);
  };

  const handleOpenMetrics = (flag) => {
    setOpenMetric(flag);
  };

  const getReportMenu = () => {
    return (
      <div id="reportMenu" style={{ width: "100%", height: "30px" }}>
        <ButtonGroup size="small" variant="text">
          <Chip
            label={props.config.currentReportName}
            sx={{ height: "28px" }}
            onClick={() => {
              props.handleReportsPane(true);
            }}
            variant={"outlined"}
          />
          <Button
            // variant="outlined"
            size="small"
            onClick={() => {
              setShowFormat(true);
              setReportConfig(
                props.config.savedReportConfig[props.config.currentReport]
              );
            }}
          >
            Format
          </Button>
          <Button
            id="demo-customized-button"
            aria-controls={
              openDownloadMenu ? "demo-customized-menu" : undefined
            }
            aria-haspopup="true"
            aria-expanded={openDownloadMenu ? "true" : undefined}
            size="small"
            onClick={(event) => {
              setOpenDownloadMenu(true);
              setAnchorEl(event.currentTarget);
            }}
            endIcon={<KeyboardArrowDownIcon />}
          >
            Download
          </Button>
          <StyledMenu
            id="demo-customized-menu"
            MenuListProps={{
              "aria-labelledby": "demo-customized-button",
            }}
            anchorEl={anchorEl}
            open={openDownloadMenu}
            onClose={() => {
              setOpenDownloadMenu(false);
              setAnchorEl(null);
            }}
          >
            <MenuItem
              onClick={() => {
                handleDownload("xlsx");
              }}
              disableRipple
            >
              XLS
            </MenuItem>
            <MenuItem
              onClick={() => {
                handleDownload("csv");
              }}
              disableRipple
            >
              CSV
            </MenuItem>
          </StyledMenu>
          <Button onClick={() => handleOpenMetrics(true)}>Metrics</Button>
          <Button onClick={() => handleOpenBuilds(true)}>Builds</Button>
          <Button onClick={() => props.handleOpenCheckpoint(true)}>
            Checkpoints
          </Button>
        </ButtonGroup>
        {
          <Box>
            <Modal open={showFormat} container={tableDetailRef.current}>
              <Box
                sx={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  width: "400px",
                  height: "auto",
                  bgcolor: "background.paper",
                  border: "2px solid #000",
                  boxShadow: 24,
                  borderRadius: "15px",
                  p: 2,
                }}
              >
                <Box>
                  <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                    Format Report
                  </Typography>
                </Box>
                <Divider />
                <Stack spacing={2}>
                  <FormControl>
                    <InputLabel>Display Mode</InputLabel>
                    <Select
                      value={_.get(reportConfig, "displayMode", "VALUE")}
                      label="Display Mode"
                      onChange={(e) => {
                        handleFormatChange("displayMode", e.target.value);
                      }}
                      size={"small"}
                    >
                      {[
                        { value: "VALUE", title: "Value" },
                        { value: "DELTAVALUE", title: "Delta Value" },
                        { value: "DELTAPERCENT", title: "Delta %" },
                        {
                          value: "ABS_DELTAVALUE",
                          title: "Absolute (Delta Value)",
                        },
                        {
                          value: "ABS_DELTAPERCENT",
                          title: "Absolute (Delta%)",
                        },
                        {
                          value: "VALUE_DELTAPERCENT",
                          title: "Value (Delta%)",
                        },
                        { value: "REFS_OFF", title: "Refs Off" },
                      ].map((item) => (
                        <MenuItem value={item.value}>{item.title}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl>
                    <InputLabel>Show empty</InputLabel>
                    <Select
                      value={_.get(reportConfig, "showEmpty", true)}
                      label="Show empty"
                      onChange={(e) => {
                        handleFormatChange("showEmpty", e.target.value);
                      }}
                      size={"small"}
                    >
                      {[
                        { value: true, title: "Show" },
                        { value: false, title: "Hide" },
                      ].map((item) => (
                        <MenuItem value={item.value}>{item.title}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl>
                    <InputLabel>Differences</InputLabel>
                    <Select
                      value={_.get(reportConfig, "showDiff", true)}
                      label="Differences"
                      onChange={(e) => {
                        handleFormatChange("showDiff", e.target.value);
                      }}
                      size={"small"}
                    >
                      {[
                        { value: true, title: "Show Diff" },
                        { value: false, title: "Show All" },
                      ].map((item) => (
                        <MenuItem value={item.value}>{item.title}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Stack>
                <Divider />
                <ButtonGroup
                  size={"small"}
                  variant="contained"
                  sx={{ float: "right", marginTop: "10px" }}
                >
                  <Button onClick={() => saveFormatOptions()}>Save</Button>
                  <Button onClick={() => setShowFormat(false)}>Cancel</Button>
                </ButtonGroup>
              </Box>
            </Modal>
            <Modal open={openBuilds} container={tableDetailRef.current}>
              <Builds
                buildsNomenclature={buildsNomenclature}
                handleBuildsNameCheck={handleBuildsNameCheck}
                handleSaveBuilds={handleSaveBuilds}
                handleCancle={handleBuildsCancel}
                hiddenBuilds={hiddenBuilds}
              />
            </Modal>
            <Modal
              open={props.openCheckpoints}
              container={tableDetailRef.current}
            >
              <Checkpoints
                handleSaveCheckpoints={props.handleSaveCheckpoints}
                handleCancel={handleCheckpointCancel}
                checkpoints={props.checkpoints}
                hiddenCheckpoints={_.get(
                  props.config,
                  ["checkpointsConfig", "hiddenCheckpoints"],
                  []
                )}
              />
            </Modal>
          </Box>
        }
      </div>
    );
  };

  const handleMetricVisibilityCheck = (metric, event) => {
    const newMetrics = _.cloneDeep(metrics);
    newMetrics[metric] = { hidden: !event.target.checked };
    setMetrics(newMetrics);
  };

  const handleSaveMetrics = () => {
    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[newConfig.currentReport].metricsConfig =
      metrics;
    props.updateReportConfig(newConfig);
  };

  const handleAllMetricVisbility = (flag) => {
    const newMetrics = _.cloneDeep(metrics);
    for (let [metricKey, metric] of Object.entries(newMetrics)) {
      newMetrics[metricKey] = { hidden: !flag };
    }
    setMetrics(newMetrics);
  };

  const getModals = () => {
    return (
      <Box>
        <Modal open={openMetrics} container={tableDetailRef.current}>
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: "80%",
              height: "100%",
              bgcolor: "background.paper",
              border: "2px solid #000",
              boxShadow: 24,
              borderRadius: "15px",
              p: 2,
            }}
          >
            <Box id="Metrics_Box" sx={{ height: "100%" }}>
              <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                Metrics
              </Typography>
              <Divider />
              <Box sx={{ height: "calc(100% - 93px)" }}>
                <FormGroup sx={{ overflow: "auto", height: "100%" }}>
                  {_.map(metrics, (metric, metricKey) => (
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={!_.get(metric, "hidden", false)}
                          onChange={(event) =>
                            handleMetricVisibilityCheck(metricKey, event)
                          }
                          // defaultChecked={!_.get(metric, "hidden", false)}
                        />
                      }
                      label={
                        // _.get(
                        //   props.reportSpec.reportNames[
                        //     props.config.currentReport
                        //   ].metrics[metricKey],
                        //   "groupName",
                        //   _.get(
                        //     _.get(props.reportSpec.metrics, metricKey, {}),
                        //     "groupName",
                        //     ""
                        //   )
                        // ) +
                        // " || " +
                        _.get(
                          metric,
                          "displayName",
                          _.get(
                            _.get(props.reportSpec.metrics, metricKey, {}),
                            "displayName",
                            metricKey
                          )
                        )
                      }
                    />
                  ))}
                </FormGroup>
              </Box>
              <Divider />
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "left", marginTop: "10px" }}
              >
                <Button
                  onClick={() => {
                    handleAllMetricVisbility(true);
                  }}
                >
                  Show All
                </Button>
                <Button
                  onClick={() => {
                    handleAllMetricVisbility(false);
                  }}
                >
                  Hide All
                </Button>
              </ButtonGroup>
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "right", marginTop: "10px" }}
              >
                <Button
                  onClick={() => {
                    handleSaveMetrics();
                  }}
                >
                  Save
                </Button>
                <Button
                  onClick={() => {
                    setMetrics(
                      _.get(
                        props.config.savedReportConfig[
                          props.config.currentReport
                        ],
                        "metricsConfig",
                        {}
                      )
                    );
                    handleOpenMetrics(false);
                  }}
                >
                  Cancel
                </Button>
              </ButtonGroup>
            </Box>
          </Box>
        </Modal>
      </Box>
    );
  };

  //----------------Table -------------------------
  useEffect(() => {
    const initTable = () => {
      const config = _.get(props, "config", {});
      const persistingKeys = getPersistingProperty("keys");
      console.log(persistingKeys);
      var columns = getColumns(persistingKeys);
      const initialFilters = _.cloneDeep(getPersistingProperty("filters"));
      const initialPageSize = getInitialPageSize();
      const initialPage = getInitialPage();
      const persistentSorters = getPersistingProperty("sorters");
      const initialSorters = _.cloneDeep(persistentSorters);
      if (tableInst == null) {
        console.log("table init1");
        tableInst = new Tabulator(tableRef, {
          // className: "table-sm table-striped table-bordered",
          layout: "fitDataStretch",
          //rowHeight: 40,
          // selectable: true,
          initialHeaderFilter: initialFilters,
          initialSort: initialSorters,
          paginationInitialPage: initialPage,
          pagination: true, //enable pagination
          paginationMode: "remote", //enable remote pagination
          sortMode: "remote",
          filterMode: "remote",
          ajaxConfig: "POST",
          paginationSize: initialPageSize,
          paginationSizeSelector: [10, 25, 50, 100, 200],
          paginationCounter: "rows",
          ajaxURL: metricsURL + "getDetailReportData/",
          ajaxContentType: "json",
          ajaxParams: {
            selectedBuilds: props.buildSpec ? props.buildSpec : [],
            report: {},
            reportSpecName: props.config.reportSpecName,
            reportName: props.config.currentReport,
            auth: {
              user: _.get(useConfigStore.getState(), "authLoginUser", ""),
            },
            displayMode: props.config.savedReportConfig[
              props.config.currentReport
            ]?.displayMode
              ? props.config.savedReportConfig[props.config.currentReport]
                  ?.displayMode
              : "VALUE",
            referenceMode:
              _.get(
                props.config.savedReportConfig[props.config.currentReport],
                "displayMode",
                "VALUE"
              ) !== "REFS_OFF",
            // referenceMode: props.config.savedReportConfig[props.config.currentReport]?.useMetricRefMode,
            baselineBuild: props.config.savedReportConfig[
              props.config.currentReport
            ]?.baselineBuild
              ? props.config.savedReportConfig[props.config.currentReport]
                  ?.baselineBuild
              : "",
            baselineCheckpoint: props.config.savedReportConfig[
              props.config.currentReport
            ]?.baselineCheckpoint
              ? props.config.savedReportConfig[props.config.currentReport]
                  ?.baselineCheckpoint
              : "",
            baselineTimestop: props.config.savedReportConfig[
              props.config.currentReport
            ]?.baselineTimestop
              ? props.config.savedReportConfig[props.config.currentReport]
                  ?.baselineTimestop
              : "",
            showOnlyDiff: _.get(
              props.config.savedReportConfig[props.config.currentReport],
              "showDiff",
              false
            ),
            hideEmptyRows:
              !props.config.savedReportConfig[props.config.currentReport]
                .showEmpty,
            hiddenBuilds: hiddenBuilds,
            hiddenCheckpoints: _.get(
              props.config,
              ["checkpointsConfig", "hiddenCheckpoints"],
              []
            ),
            // rawQuery: _.get(props.config, "query", ""),
            // variables: _.get(props.config, "wVariables", {}),
          },
          ajaxError: (error) => {
            console.log(error);
          },
          ajaxResponse: (url, params, responseData) => {
            const newCols = _.get(responseData, "keys", []);
            if (tableInst && newCols) {
              setAdditionalCols(newCols);
            }
            persistTable(
              _.get(responseData, "keys", []),
              _.get(params, "filter", []),
              _.get(params, "sort", []),
              _.get(params, "size", 25),
              _.get(params, "page", 1)
            );
            const tabulatorLoreFormat = {
              data: responseData.rows ? responseData.rows : [],
              last_page: responseData.lastPage ? responseData.lastPage : 10,
            };
            rowsColor = responseData.rows ? responseData.rows : [];
            return tabulatorLoreFormat;
          },
          // movableRows: true,
          rowContextMenu: getRowContextMenu,
          columns: columns ? columns : [],

          // data: rows ? rows : [],
          height: "100%",
          width: "100%",
          // data: rows ? rows : [],
          // maxHeight: "1000px",
          // width:"100%",
          // groupBy: newCols,  //sp6 did not had any grouping but 23.12 have it. Keeping sp6
          groupToggleElement: "header",
          columnDefaults: {
            headerFilterPlaceholder: "...",
            headerFilterLiveFilter: false,
            tooltip: function (e, cell, onRendered) {
              //e - mouseover event
              //cell - cell component
              //onRendered - onRendered callback registration function

              var el = document.createElement("div");
              el.style.backgroundColor = "rgba(97,97,97)";
              el.style.color = "white";
              el.style.height = "auto";
              el.style.padding = "5px";
              el.style.minHeight = "20px";
              el.style.borderRadius = "10px";
              el.style.opacity = 0.92;
              el.innerText = cell.getValue(); //return cells "field - value";

              return el;
            },
          },
        });
        // tableInst.on("rowMouseEnter", rowMouseEnter);
        // tableInst.on("rowClick", rowClick);
        // this.tableInst.on("dataTreeRowExpanded", this.dataTreeRowExpanded);
        // this.tableInst.on("dataTreeRowCollapsed", this.dataTreeRowCollapsed);
        // tableInst.on("tableBuilt", afterTableBuilt);
        // tableInst.on("groupVisibilityChanged", afterTableBuilt);
        // tableInst.on("dataFiltered", afterTableBuilt);
        // tableInst.on("dataProcessed", afterTableBuilt);
      } else {
        // this.resizeTable();
      }
    };

    initTable();
  }, []);

  return (
    // <h1>I am table</h1>
    <>
      <div
        id="TableDetail"
        ref={(ref) => {
          tableDetailRef.current = ref;
        }}
        style={{ width: "100%", height: "100%" }}
      >
        {getReportMenu()}
        {getModals()}
        <div
          id="analytics"
          style={{ width: "100%", height: "calc(100% - 30px)" }}
        >
          <div
            style={{ width: "inherit" }}
            ref={(r) => {
              tableRef = r;
            }}
          ></div>
        </div>
      </div>
    </>
  );
}, shouldComponentUpdate);

TableDetailReport.defaultProps = {
  query: "",
  baselineBuild: "",
  keys: [],
};

export default TableDetailReport;
