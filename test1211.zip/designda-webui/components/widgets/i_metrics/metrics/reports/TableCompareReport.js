import React from "react";
import { useState, useEffect, useRef, memo } from "react";
import { shallow } from "zustand/shallow";
import { produce } from "immer";
// import { ReactTabulator } from "react-tabulator";
import ReactDOMServer from "react-dom/server";
import { TabulatorFull as Tabulator } from "tabulator-tables";

import Builds from "../dialogs/BuildsModal";
import BuildUserLabel from "../dialogs/BuildsUserLabel";

import axios from "axios";
import _, { indexOf } from "lodash";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

//color
import { calcCell, _colors } from "../../../../../common/color";
import useConfigStore from "../../../../../store/useConfigStore";
import useGlobalStore from "../../../../../store/useGlobalStore";

import * as utils from "../../../../../common/utils/utils";
import api from "../../../../../common/api/api";
import { tags } from "../../../../../constants/constants";

import {
  customInput,
  customFilter,
  customInputForColumn,
  customFilterDisplayValue,
  globFilterDisplayValue,
} from "../../../../../common/filter";
import {
  customFilterDisplayValueTooltip,
  globFilterDisplayValueTooltip,
} from "../../../../../common/tooltip";

import {
  addWidgetCommonFunction,
  showConfigUiState,
  showWidgetDataUiState,
  widgets,
} from "../../../../../pages/rptdashboard/addWidget/addWidget";
import "tabulator-tables/dist/css/tabulator.min.css";
import "tabulator-tables/dist/css/tabulator_bootstrap4.min.css";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";

import * as MetricUtils from "../../MetricUtils";

//mui components
import {
  Button,
  ButtonGroup,
  Checkbox,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  InputLabel,
  Menu,
  MenuItem,
  Modal,
  Paper,
  Select,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import { Box } from "@mui/system";

//mui styles
import { styled, alpha } from "@mui/material/styles";

//icon
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { newReportSpecDoc } from "../../../../../common/Funcs";
import Checkpoints from "../dialogs/CheckpointsModal";

// import "./Resizable.css"; // Make sure to create and import CSS for styling

const StyledMenu = styled((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 100,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      fontSize: 12,
      "& .MuiSvgIcon-root": {
        // fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

const TableCompareReport = (props) => {
  let tableRef = React.createRef();
  const tableInst = React.useRef();
  let prevRowHighlighted = null;
  let customContexts = [];
  let rowsColor = [];
  let c = [];
  let r = [];

  const ALL__BLOCKS__WAIVER = "ALL__BLOCKS__WAIVER";
  const DELETED__BLOCKS__WAIVER = "DELETED__BLOCKS__WAIVER";

  const [showFormat, setShowFormat] = useState(false);
  const [reportConfig, setReportConfig] = useState(
    props.config.savedReportConfig[props.config.currentReport]
  );
  const [openDownloadMenu, setOpenDownloadMenu] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const [openMenu, setOpenMenu] = useState(false);
  const [anchorElMenu, setAnchorElMenu] = useState(null);

  const [showAddWaiver, setShowAddWaiver] = useState(false);
  const [showWaiver, setShowWaiver] = useState(false);
  const [openMetrics, setOpenMetric] = useState(false);
  const [openBuilds, setOpenBuilds] = useState(false);
  const [metrics, setMetrics] = useState(
    _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "metricsConfig",
      {}
    )
  );
  const orgMode = _.get(
    props.config.savedReportConfig[props.config.currentReport],
    "orgMode",
    "BCxM"
  );

  const [openBuildsLabel, setOpenBuildsLabel] = useState(false);
  const [buildLabel, setBuildLabel] = useState("");
  const [selectedBuild, setSelectedBuild] = useState("");
  const [selectedBuildHiddenFlag, setSelectedBuildHiddenFlag] = useState(false);
  const [buildsNomenclature, setBuildsNomenclature] = useState(
    _.get(props.config.buildsConfig, "buildsNomenclature", {})
  );
  const [hiddenBuilds, setHiddenBuilds] = useState(
    _.get(props.config.buildsConfig, "hiddenBuilds", [])
  );

  const [waiverComment, setWaiverComment] = useState("");
  const [waiverMetric, setWaiverMetric] = useState({
    metric: "",
    block: "all",
  });

  //refs
  const compareReportRef = useRef(null);

  const metricsURL =
    useConfigStore.getState().configData.rest_server_url + "/metrics/";

  const isNumber = (value) => {
    return !isNaN(value) && !isNaN(parseFloat(value));
  };

  const [leftWidth, setLeftWidth] = useState(50); // Left div width percentage
  const containerRef = useRef(null);

  const startResize = (e) => {
    e.preventDefault();
    document.addEventListener("mousemove", handleResize);
    document.addEventListener("mouseup", stopResize);
  };

  const handleResize = (e) => {
    if (!containerRef.current) return;
    const containerWidth = containerRef.current.offsetWidth;
    const newLeftWidth = (e.clientX / containerWidth) * 100;
    setLeftWidth(newLeftWidth);
  };

  const stopResize = () => {
    document.removeEventListener("mousemove", handleResize);
    document.removeEventListener("mouseup", stopResize);
  };

  const getWaiverColor = (field, rowData, colorRule) => {
    const colors = colorRule;
    const waiverMetrics = reportConfig.waiverMetrics;
    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );

    let metric = null;
    let block = null;
    if (
      (orgMode == "BCxM" || orgMode == "CBxM") &&
      field.split("__").length == 2
    ) {
      metric = field.split("__")[1];
      block = rowData["BLOCK"];
    } else {
      if (rowData.runMetadata && rowData.runMetadata[field]) {
        metric = rowData.metric;
        block = rowData.runMetadata[field].BLOCK;
      }
    }

    if (Object.keys(waiverMetrics).includes(metric)) {
      if (
        Object.keys(waiverMetrics[metric]).includes(block) ||
        Object.keys(waiverMetrics[metric]).includes(ALL__BLOCKS__WAIVER)
      )
        if (
          waiverMetrics[metric].hasOwnProperty(DELETED__BLOCKS__WAIVER) &&
          waiverMetrics[metric][DELETED__BLOCKS__WAIVER].includes(block)
        ) {
        } else {
          colors.background = "grey";
        }
    }

    return colors;
  };

  const getColor = (cell) => {
    let element = cell.getElement();
    let field = cell.getColumn().getField();
    let rowData = cell.getRow().getData();

    const colors = { foreground: "#000000", background: "#ffffff" };
    if (rowData.colors) {
      colors.foreground = _.get(rowData.colors[field], "foreground", "#000000");
      colors.background = _.get(rowData.colors[field], "background", "#ffffff");
    }
    // override colors if waiver is marked
    if (
      reportConfig.waiverMetrics &&
      Object.keys(reportConfig.waiverMetrics).length
    ) {
      colors.foreground = getWaiverColor(field, rowData, colors).foreground;
      colors.background = getWaiverColor(field, rowData, colors).background;
    }
    return colors;
  };

  const getLinks = (cell) => {
    let field = cell.getField();
    let rowData = cell.getData();

    if (rowData?.links?.[field]) {
      return rowData.links[field];
    }
    return null;
  };

  const getBuildsNomenclature = (value, label = "") => {
    let newBuildNameList = [];
    if (
      Object.keys(buildsNomenclature).length &&
      value &&
      value.split("/").length >= 5
    ) {
      for (let i = 0; i < tags.length; i++) {
        if (_.get(buildsNomenclature[tags[i].field], "show", true)) {
          if (value.split("/")[i]) {
            newBuildNameList.push(value.split("/")[i].split("###").slice(0)[0]);
          }
        }
      }

      let newValue = newBuildNameList.join("/");
      if (_.get(buildsNomenclature["label"], "show", false) && label) {
        newValue = newValue + " ( " + label + " ) ";
      }
      if (
        _.get(buildsNomenclature["baselineMarker"], "show", true) &&
        value.includes("###") &&
        value.split("###").length == 2
      ) {
        newValue = newValue + "###" + value.split("###")[1];
      }
      return newValue;
    }
    return value;
  };

  const cellFormatter = (cell, formatterParams, onRendered) => {
    let element = cell.getElement();

    let cellValue = cell.getValue();

    let displayValue = null;

    let field = cell.getField();

    if (field == "displayBuildName") {
      let label = "";
      if (["BCxM", "CBxM"].includes(orgMode)) {
        label = _.get(cell.getData(), "LABEL", "");
      }
      cellValue = getBuildsNomenclature(cellValue, label);
    }

    // let fg = funcs.palette("Default").fg;
    // let bg = funcs.palette("Default").bg;

    if (getLinks(cell)) {
      var a = document.createElement("i");
      var linkText = document.createTextNode(cellValue);
      a.appendChild(linkText);
      a.title = cellValue;

      onRendered(function () {
        element.appendChild(a);
      });
    } else {
      let newDiv = document.createElement("div");
      newDiv["innerHTML"] = cellValue != undefined ? cellValue : "";
      onRendered(function () {
        element.appendChild(newDiv);
      });
    }

    const colors = getColor(cell);
    if (colors) {
      element.style.color = colors.foreground;
      element.style.backgroundColor = colors.background;
    } else {
      element.style.color = "black";
      element.style.backgroundColor = "white";
    }

    return displayValue;
  };

  const addColumn = ({
    rootGroupObj = {},
    col = {},
    groupEnable = false,
    groupNames = [],
    groupContextMenu = [],
    headerAttrObj = {},
  } = {}) => {
    let nextRootGroupObj = _.cloneDeep(rootGroupObj);

    let headerTooltip = col.headerTooltip;

    if (groupEnable == false || groupNames.length == 0) {
      // Group processing NOT needed.
      nextRootGroupObj.columns.push(col);
    } else {
      // Group processing needed.
      let parentGroupObj = nextRootGroupObj;
      let lastGroupObj;

      for (let i = 0; i < groupNames.length; i++) {
        let groupName = groupNames[i];

        let newGroupObj = {
          title: groupName,
          columns: [],
          // headerTooltip: headerTooltip,
        };

        if (groupContextMenu.length != 0) {
          newGroupObj.headerContextMenu = groupContextMenu;
        }

        for (let attr in headerAttrObj) {
          newGroupObj[attr] = headerAttrObj[attr];
        }

        if (parentGroupObj.columns.length == 0) {
          parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
        }
        lastGroupObj =
          parentGroupObj.columns[parentGroupObj.columns.length - 1];

        if (i != groupNames.length - 1) {
          // This is NOT the last groupName
          if (
            lastGroupObj.title == groupName &&
            lastGroupObj.hasOwnProperty("columns")
          ) {
          } else {
            parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
            lastGroupObj =
              parentGroupObj.columns[parentGroupObj.columns.length - 1];
          }
          parentGroupObj = lastGroupObj;
        } else {
          // This is the last groupName
          if (
            lastGroupObj.title == groupName &&
            lastGroupObj.hasOwnProperty("columns")
          ) {
          } else {
            parentGroupObj.columns.push(_.cloneDeep(newGroupObj));
            lastGroupObj =
              parentGroupObj.columns[parentGroupObj.columns.length - 1];
          }
          lastGroupObj.columns.push(col);
        }
      }
    }

    return nextRootGroupObj;
  };

  const getGroupNames = (groupName) => {
    let groupNames;
    if (groupName == null || groupName == "") {
      groupNames = [];
    } else {
      let textToSplit = groupName;
      groupNames = [];
      // Note: "^" is the separator char
      // Note: "`" is the blank char
      for (let name of textToSplit.split("^")) {
        if (name == "`") {
          name = "";
        }
        groupNames.push(name);
      }
    }
    return groupNames;
  };

  const openLink = (cell) => {
    let link = getLinks(cell);
    if (link) {
      let [file, line] = link.split("|||");
      let fLink = file.replace("F:", "");
      let lineNumber = line ? line.replace("L:", "") : -1;
      let ftype = "TEXT";
      if (
        fLink.endsWith(".jpeg") ||
        fLink.endsWith(".jpg") ||
        fLink.endsWith(".png") ||
        fLink.endsWith(".tiff") ||
        fLink.endsWith(".tif")
      ) {
        ftype = "IMAGE";
      }

      if (ftype == "TEXT") {
        axios
          .post(metricsURL + "downloadFsFile", {
            filePath: fLink,
            ftype: ftype,
          })
          .then((responseData) => {
            if (responseData.status == 200) {
              let theWindow;
              let html;
              let styleNormal = { backgroundColor: "#ffffff", margin: 0 };
              let styleHighlight = { backgroundColor: "#ffff00", margin: 0 };

              let linesBefore = [];
              let linesHighlight = [];
              let linesAfter = [];

              let fields = fLink.split("/");
              let title = fields[fields.length - 1];

              let linesOrg = responseData.data.split("\n");
              let lineCount = 0;
              for (let line of linesOrg) {
                lineCount += 1;
                let newLine = line;
                if (lineCount < lineNumber) {
                  linesBefore.push(newLine);
                } else if (lineCount == lineNumber) {
                  if (line.match(/^$/)) {
                    newLine = " ";
                  }
                  linesHighlight.push(newLine);
                } else {
                  linesAfter.push(newLine);
                }
              }

              let contentsBefore = linesBefore.join("\n");
              let contentsHighlight = linesHighlight.join("\n");
              let contentsAfter = linesAfter.join("\n");

              html = ReactDOMServer.renderToStaticMarkup(
                <html>
                  <head>
                    <title>{title}</title>
                  </head>
                  <body>
                    <div>
                      <pre style={styleNormal}>{contentsBefore}</pre>
                      <pre style={styleHighlight}>{contentsHighlight}</pre>
                      <pre style={styleNormal}>{contentsAfter}</pre>
                    </div>
                  </body>
                </html>
              );

              theWindow = window.open("", title);
              theWindow.document.write(html);
              theWindow.document.close();
            }
          })
          .catch((error) => {
            console.log(error);
          });
      } else if (ftype == "IMAGE") {
        const src = metricsURL + `downloadFsFile?filePath=${fLink}&ftype=IMAGE`;
        window.open(src, "_blank", "noopener,noreferrer");
      }
    }
  };

  const saveWaiver = () => {
    const newConfig = _.cloneDeep(props.config);
    const newReportConfig = _.cloneDeep(reportConfig);

    // checking schema if it doesnt fit then fixing it
    if (!newReportConfig.hasOwnProperty("waiverMetrics")) {
      newReportConfig.waiverMetrics = {};
    }
    if (
      !newReportConfig.waiverMetrics.hasOwnProperty(
        _.get(waiverMetric, "metric", "")
      )
    ) {
      newReportConfig.waiverMetrics[_.get(waiverMetric, "metric", "")] = {};
    }
    // add comment to the metrics
    // block can be ALL__BLOCKS__WAIVER for all blocks
    newReportConfig.waiverMetrics[_.get(waiverMetric, "metric", "")][
      _.get(waiverMetric, "block", "")
    ] = waiverComment;

    newConfig.savedReportConfig[props.config.currentReport] = newReportConfig;
    props.updateReportConfig(newConfig);
  };

  const openAddWaiver = (e, cell, addForAllBlocks) => {
    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );

    let cellMetric = null;
    let block = null;
    if (
      (orgMode == "BCxM" || orgMode == "CBxM") &&
      cell.getField().split("__").length == 2
    ) {
      cellMetric = cell.getField().split("__")[1];
      block = cell.getData()["BLOCK"];
      setShowAddWaiver(true);
    } else if (
      cell.getData().runMetadata &&
      cell.getData().runMetadata[cell.getField()]
    ) {
      setShowAddWaiver(true);
      cellMetric = cell.getData().metric;
      block = cell.getData().runMetadata[cell.getField()].BLOCK;
      //   if (orgMode == "CBxM") {
      // } else if (orgMode == "CMxB") {
      // } else if (orgMode == "MCxB") {}
    }

    if (addForAllBlocks) {
      setWaiverMetric({ metric: cellMetric, block: ALL__BLOCKS__WAIVER });
    } else {
      setWaiverMetric({ metric: cellMetric, block: block });
    }
  };

  const handleShowWaiver = (flag) => {
    setShowWaiver(flag);
  };

  const handleOpenMetrics = (flag) => {
    setOpenMetric(flag);
  };

  const handleOpenBuilds = (flag) => {
    setOpenBuilds(flag);
  };

  /**
   *
   * @param {Object} e
   * @param {Element} cell
   * @param {Boolean} deleteForAllBlocks
   */
  const deleteWaiver = (e, cell, deleteForAllBlocks) => {
    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );

    let cellMetric = null;
    let cellBlock = null;
    if (
      (orgMode == "BCxM" || orgMode == "CBxM") &&
      cell.getField().split("__").length == 2
    ) {
      cellMetric = cell.getField().split("__")[1];
      cellBlock = cell.getData()["BLOCK"];
    } else if (
      cell.getData().runMetadata &&
      cell.getData().runMetadata[cell.getField()]
    ) {
      cellMetric = cell.getData().metric;
      cellBlock = cell.getData().runMetadata[cell.getField()].BLOCK;
    }

    const newConfig = _.cloneDeep(props.config);
    const newReportConfig = _.cloneDeep(reportConfig);

    // checking schema if it doesnt fit then fixing it
    if (!newReportConfig.hasOwnProperty("waiverMetrics")) {
      newReportConfig.waiverMetrics = {};
    }

    // block can have a value ALL__BLOCKS__WAIVER reporesenting all blocks

    // delete if delete all
    if (deleteForAllBlocks) {
      delete newReportConfig.waiverMetrics[cellMetric];
    }

    // check if metric has ALL_BLOCKS key, if it has then some steps are required
    else if (
      newReportConfig.waiverMetrics[cellMetric].hasOwnProperty(
        ALL__BLOCKS__WAIVER
      )
    ) {
      if (newReportConfig.waiverMetrics.hasOwnProperty(cellMetric)) {
        // add deleted blocks if ALL BLOCKS as already present in the keys
        // deleted blocks is an Array

        if (
          !newReportConfig.waiverMetrics[cellMetric].hasOwnProperty(
            DELETED__BLOCKS__WAIVER
          )
        ) {
          newReportConfig.waiverMetrics[cellMetric][DELETED__BLOCKS__WAIVER] =
            [];
        }

        // delete block if DELETED_BLOCKS_WAIVER does not have block
        if (
          !newReportConfig.waiverMetrics[cellMetric][
            DELETED__BLOCKS__WAIVER
          ].includes(cellBlock)
        ) {
          newReportConfig.waiverMetrics[cellMetric][
            DELETED__BLOCKS__WAIVER
          ].push(cellBlock);
        }
      }
    } else {
      // delete a single block
      delete newReportConfig.waiverMetrics[cellMetric][cellBlock];

      // delete metric if no more blocks are associated with it
      if (Object.keys(newReportConfig.waiverMetrics[cellMetric]).length == 0) {
        delete newReportConfig.waiverMetrics[cellMetric];
      }
    }
    newConfig.savedReportConfig[props.config.currentReport] = newReportConfig;
    props.updateReportConfig(newConfig);
  };

  const waiverMenu = (e, cell) => {
    let menu = [];

    menu.push({
      label: "Add Waiver this block",
      action: () => openAddWaiver(e, cell, false),
    });
    menu.push({
      label: "Add Waiver all block",
      action: () => openAddWaiver(e, cell, true),
    });
    menu.push({
      label: "Delete Waiver this block",
      action: () => deleteWaiver(e, cell, false),
    });
    menu.push({
      label: "Delete Waiver all block",
      action: () => deleteWaiver(e, cell, true),
    });
    // menu.push({ label: "Show Waivers", action: () => handleShowWaiver(true) });
    return menu;
  };

  const cellClickMenu = (e, cell) => {
    let menu = [];

    if (getLinks(cell)) {
      menu.push({ label: "Open Link", action: () => openLink(cell) });
    }

    menu = menu.concat(waiverMenu(e, cell));
    if (menu.length) {
      return menu;
    }
  };

  const openAnalyticsReport = (runData) => {
    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );
    let query = null;
    // if (orgMode == "BCxM" || orgMode == "CBxM") {
    query = `project = '${runData["PROJECT"]}' AND username = '${runData["USER"]}' AND block = '${runData["BLOCK"]}' AND phase = '${runData["PHASE"]}' AND run_tag = '${runData["RUNTAG"]}' AND checkpoint = '${runData["checkpoint"]}'`;
    // }
    props.openAnalyticsReport(query);
  };

  const openRowAnalyticsReport = (e, _row) => {
    const rowData = _row.getData();
    openAnalyticsReport(rowData);
  };

  const setBaselineHeaderMenu = (buildName) => {
    return [
      {
        label: "Set baseline",
        action: () => setBaseline(buildName),
      },
    ];
  };

  const handleMetric = (metric, visibility) => {
    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[newConfig.currentReport].metricsConfig[metric] =
      { hidden: !visibility };
    props.updateReportConfig(newConfig);
  };

  const hideMetricHeaderContextMenu = (e, column) => {
    let contextMenu = [];

    const metricGroup = _.get(
      column.getParentColumn().getDefinition(),
      "title",
      ""
    );
    const metricDisplayName = _.get(column.getDefinition(), "title", "");

    for (let [metricKey, metricValue] of Object.entries(
      props.reportSpec.reportNames[props.config.currentReport].metrics
    )) {
      if (
        _.get(
          metricValue,
          "groupName",
          _.get(_.get(props.reportSpec.metrics, metricKey, {}), "groupName", "")
        ) == metricGroup &&
        _.get(
          metricValue,
          "displayName",
          _.get(
            _.get(props.reportSpec.metrics, metricKey, {}),
            "displayName",
            ""
          )
        ) == metricDisplayName
      ) {
        contextMenu.push({
          label: "Hide Metric",
          action: () => handleMetric(metricKey, false),
        });
        break;
      }
    }
    return contextMenu;
  };

  const handleRowContextMenuUnsetBaseline = (baseline) => {
    return {
      label: "Unset baseline",
      action: () => rowContextMenuUnsetBaseline(baseline),
    };
  };

  const buildsContextMenu = (buildName) => {
    if (
      reportConfig.baselineBuilds != undefined &&
      reportConfig.baselineBuilds != "" &&
      Array.isArray(_.get(reportConfig, "baselineBuilds", [])) &&
      _.get(reportConfig, "baselineBuilds", []).includes(buildName)
    ) {
      return [handleRowContextMenuUnsetBaseline(buildName)].concat(
        editBuildsAttribute(buildName)
      );
    }
    return setBaselineHeaderMenu(buildName).concat(
      editBuildsAttribute(buildName)
    );
  };

  const headerContextMenu = (e, column) => {
    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );
    if (orgMode == "BCxM" || orgMode == "CBxM") {
      if (column.getParentColumn()) {
        return hideMetricHeaderContextMenu(e, column);
      } else {
        return hideColumn(e, column);
      }
    } else if (orgMode == "MCxB" || orgMode == "CMxB") {
      e.preventDefault();
      return buildsContextMenu(
        column.getDefinition().field.replace("__DOT__", ".")
      );
    }
  };

  const cellContextMenu = (e, _cell) => {
    let contextMenu = [];

    const cellField = _cell.getField();

    const runMetaData = _.get(_cell.getData(), "runMetadata", {});

    const runData = _.get(runMetaData, cellField, {});
    contextMenu.push({
      label: "Analytics",
      action: () => openAnalyticsReport(runData),
    });

    contextMenu.push({
      label: "Hide Group Complete",
      action: () =>
        handleMetricGroup(_.get(_cell.getData(), "groupName"), false),
    });

    contextMenu.push({
      label: "Hide Group Partial",
      action: () =>
        handleMetricGroup(_.get(_cell.getData(), "groupName"), false, true),
    });

    contextMenu.push({
      label: "Show Group Complete",
      action: () =>
        handleMetricGroup(_.get(_cell.getData(), "groupName"), true),
    });

    return contextMenu;
  };

  const getInitialColumnsFromConfig = (config) => {
    const reportConfig = config.savedReportConfig[config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence") &&
      reportConfig.tablePersistence.hasOwnProperty(reportConfig.orgMode) &&
      reportConfig.tablePersistence[reportConfig.orgMode].hasOwnProperty(
        reportConfig.displayMode
      )
      ? _.get(
          reportConfig.tablePersistence[reportConfig.orgMode][
            reportConfig.displayMode
          ],
          "columns",
          []
        )
      : [];
  };

  const getInitialColumns = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence") &&
      reportConfig.tablePersistence.hasOwnProperty(reportConfig.orgMode) &&
      reportConfig.tablePersistence[reportConfig.orgMode].hasOwnProperty(
        reportConfig.displayMode
      )
      ? _.get(
          reportConfig.tablePersistence[reportConfig.orgMode][
            reportConfig.displayMode
          ],
          "columns",
          []
        )
      : [];
  };

  const getInitialPageSize = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence") &&
      reportConfig.tablePersistence.hasOwnProperty(reportConfig.orgMode) &&
      reportConfig.tablePersistence[reportConfig.orgMode].hasOwnProperty(
        reportConfig.displayMode
      )
      ? _.get(
          reportConfig.tablePersistence[reportConfig.orgMode][
            reportConfig.displayMode
          ],
          "size",
          25
        )
      : 25;
  };

  const getInitialPage = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence") &&
      reportConfig.tablePersistence.hasOwnProperty(reportConfig.orgMode) &&
      reportConfig.tablePersistence[reportConfig.orgMode].hasOwnProperty(
        reportConfig.displayMode
      )
      ? _.get(
          reportConfig.tablePersistence[reportConfig.orgMode][
            reportConfig.displayMode
          ],
          "page",
          1
        )
      : 1;
  };

  const getInitialSorters = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence") &&
      reportConfig.tablePersistence.hasOwnProperty(reportConfig.orgMode) &&
      reportConfig.tablePersistence[reportConfig.orgMode].hasOwnProperty(
        reportConfig.displayMode
      )
      ? _.get(
          reportConfig.tablePersistence[reportConfig.orgMode][
            reportConfig.displayMode
          ],
          "sorters"
        )
      : [];
  };

  const getInitialFilter = () => {
    const config =
      useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
        props.id
      ].config;
    const reportConfig = config.savedReportConfig[props.config.currentReport];
    return reportConfig.hasOwnProperty("tablePersistence") &&
      reportConfig.tablePersistence.hasOwnProperty(reportConfig.orgMode) &&
      reportConfig.tablePersistence[reportConfig.orgMode].hasOwnProperty(
        reportConfig.displayMode
      )
      ? _.get(
          reportConfig.tablePersistence[reportConfig.orgMode][
            reportConfig.displayMode
          ],
          "filters"
        )
      : [];
  };

  const getInitialFilterValue = (field, initialHeaderFilters) => {
    let value = "";
    // get initial filters for persistence

    const filter = initialHeaderFilters.filter(
      (filter) => _.get(filter, "field", "") == field
    );
    if (filter.length) {
      value = _.get(filter[0], "value", "");
    }
    return value;
  };

  const handleMetricGroup = (metricGroup, visibility, partialShow = false) => {
    const reportMetrics =
      props.reportSpec.reportNames[props.config.currentReport].metrics;

    const newConfig = _.cloneDeep(props.config);

    let partailFlag = true;

    for (let [metric, metricValue] of Object.entries(reportMetrics)) {
      if (
        _.get(
          metricValue,
          "groupName",
          _.get(_.get(props.reportSpec.metrics, metric, {}), "groupName", "")
        ) == metricGroup
      ) {
        newConfig.savedReportConfig[newConfig.currentReport].metricsConfig[
          metric
        ] = {
          hidden: !visibility,
        };
        if (partialShow && partailFlag) {
          newConfig.savedReportConfig[newConfig.currentReport].metricsConfig[
            metric
          ] = {
            hidden: visibility,
          };
          partailFlag = false;
        }
      }
    }
    props.updateReportConfig(newConfig);
  };

  const metricGroupHeaderMenu = (e, column) => {
    let headerContextMenu = [];
    headerContextMenu.push({
      label: "Hide Group Complete",
      action: () => handleMetricGroup(column._column.definition.title, false),
    });
    headerContextMenu.push({
      label: "Hide Group Partial",
      action: () =>
        handleMetricGroup(column._column.definition.title, false, true),
    });
    headerContextMenu.push({
      label: "Show Group Complete",
      action: () => handleMetricGroup(column._column.definition.title, true),
    });
    return headerContextMenu;
  };

  const getColumns = (cols) => {
    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );

    const initialHeaderSorters = getInitialSorters();
    //if columns exist then proceed
    if (cols) {
      let formattedCols = [];

      //iterate first level of columns
      for (let i = 0; i < cols.length; i++) {
        const column = cols[i];
        let newFormattedColumn = _.cloneDeep(column);
        //check if a column has child columns/ 2nd level
        if (column.hasOwnProperty("columns")) {
          // newFormattedColumn.download = true;
          if (orgMode == "BCxM" || orgMode == "CBxM") {
            newFormattedColumn.headerContextMenu = metricGroupHeaderMenu;
          } else if (
            ![
              "checkpoint",
              "BLOCK",
              "buildName",
              "groupName",
              "metric",
            ].includes(newFormattedColumn.field)
          ) {
            newFormattedColumn.title = getBuildsNomenclature(
              newFormattedColumn.title,
              _.get(newFormattedColumn, "LABEL", "")
            );
            if (orgMode || "MxBC") {
              newFormattedColumn.headerContextMenu = () =>
                buildsContextMenu(newFormattedColumn.buildName);
            }
          }
          //iterate over 2nd level of columns
          for (let j = 0; j < column.columns.length; j++) {
            // resize every column of 2nd level
            newFormattedColumn.columns[j].resizable = true;
            // newFormattedColumn.columns[j].download = true;

            if (orgMode == "BCxM" || orgMode == "CBxM") {
              newFormattedColumn.columns[j].headerFilter = customInput;
              newFormattedColumn.columns[j].headerTooltip =
                customFilterDisplayValueTooltip;
              newFormattedColumn.columns[j].headerFilterFunc =
                globFilterDisplayValue;
              newFormattedColumn.columns[j].sorter = true;
              newFormattedColumn.columns[j].headerSort = true;
              newFormattedColumn.columns[j].headerSortTristate = true;
              const sorter = initialHeaderSorters.filter(
                (sorter) =>
                  _.get(sorter, "field", "") ==
                  newFormattedColumn.columns[j].field
              );
              if (sorter.length) {
                newFormattedColumn.columns[j].headerSortStartingDir = _.get(
                  sorter[0],
                  "dir",
                  "asc"
                );
              }
            } else {
              newFormattedColumn.columns[j].headerFilter = false;
              newFormattedColumn.columns[j].sorter = false;
              newFormattedColumn.columns[j].headerSort = false;
              newFormattedColumn.columns[j].headerSortTristate = false;
            }
            newFormattedColumn.columns[j].headerContextMenu = headerContextMenu;
            newFormattedColumn.columns[j].formatter = (
              cell,
              formatterParams,
              onRendered
            ) => cellFormatter(cell, formatterParams, onRendered);
            newFormattedColumn.columns[j].clickMenu = cellClickMenu;
            if (["CMxB", "MCxB", "MxBC"].includes(orgMode)) {
              newFormattedColumn.columns[j].contextMenu = cellContextMenu;
            }
          }
        } else {
          // first level of columns properties
          // these are applied to all first level of columns
          // specific fields properties are overwritten later in the code
          newFormattedColumn.resizable = true;
          // newFormattedColumn.download = true;
          newFormattedColumn.formatter = (cell, formatterParams, onRendered) =>
            cellFormatter(cell, formatterParams, onRendered);
          if (orgMode == "BCxM" || orgMode == "CBxM") {
            newFormattedColumn.headerFilter = customInput;
            newFormattedColumn.headerTooltip = customFilterDisplayValueTooltip;
            // newFormattedColumn.headerFilterParams = getInitialFilterValue;
            newFormattedColumn.headerFilterFunc = globFilterDisplayValue;
            newFormattedColumn.sorter = true;
            newFormattedColumn.headerSort = true;
            newFormattedColumn.headerSortTristate = true;
            const sorter = initialHeaderSorters.filter(
              (sorter) => _.get(sorter, "field", "") == newFormattedColumn.field
            );
            if (sorter.length) {
              newFormattedColumn.headerSortStartingDir = _.get(
                sorter[0],
                "dir",
                "asc"
              );
            }
          } else {
            newFormattedColumn.headerFilter = false;
            newFormattedColumn.sorter = false;
            newFormattedColumn.headerSort = false;
            newFormattedColumn.headerSortTristate = false;
          }
          // general fields of first level end
          // apply properties to specific columns
          if (
            newFormattedColumn.field == "displayBuildName" &&
            orgMode == "CBxM"
          ) {
            newFormattedColumn.sorter = false;
            newFormattedColumn.headerSort = false;
            newFormattedColumn.headerSortTristate = false;
          } else if (
            orgMode == "MCxB" &&
            newFormattedColumn.field == "checkpoint"
          ) {
            newFormattedColumn.headerFilter = customInput;
            newFormattedColumn.headerTooltip = customFilterDisplayValueTooltip;
          }
          if (
            [
              "checkpoint",
              "BLOCK",
              "buildName",
              "groupName",
              "metric",
            ].includes(newFormattedColumn.field)
          ) {
            newFormattedColumn.frozen = true;
            newFormattedColumn.headerFilter = customInput;
            newFormattedColumn.headerTooltip = customFilterDisplayValueTooltip;
            if (newFormattedColumn.field == "buildName") {
              newFormattedColumn.headerContextMenu = hideColumn;
              newFormattedColumn.formatter = (
                cell,
                formatterParams,
                onRendered
              ) => cellFormatter(cell, formatterParams, onRendered);
            }
          } else {
            newFormattedColumn.headerContextMenu = headerContextMenu;
            newFormattedColumn.clickMenu = cellClickMenu;
            if (["CMxB", "MCxB", "MxBC"].includes(orgMode)) {
              newFormattedColumn.contextMenu = cellContextMenu;
              newFormattedColumn.title = getBuildsNomenclature(
                newFormattedColumn.title,
                _.get(newFormattedColumn, "LABEL", "")
              );
            }
          }
          //specific columns properties end
          //first level of columns end
        }
        formattedCols.push(newFormattedColumn);
      }
      return formattedCols;
    }
    let col = null;
    let rootGroupObj = {};
    rootGroupObj.title = null;
    rootGroupObj.columns = [];

    col = {
      title: "Checkpoint",
      field: "checkpoint",
      frozen: true,
      visible: true,
      headerSort: false,
      headerFilter: customInput,
      headerFilterFunc: globFilterDisplayValue,
      headerTooltip: customFilterDisplayValueTooltip,
    };
    rootGroupObj = addColumn({ rootGroupObj: rootGroupObj, col: col });

    return rootGroupObj.columns;
  };

  const getCurrentColumnState = () => {
    let columnsState = [];
    if (tableInst && tableInst.current) {
      const columnsDef = tableInst.current.getColumnDefinitions();
      for (let i = 0; i < columnsDef.length; i++) {
        if (columnsDef[i].hasOwnProperty("columns")) {
          let secondLevelColumns = [];
          for (let j = 0; j < columnsDef[i].columns.length; j++) {
            secondLevelColumns.push({
              title: _.get(columnsDef[i].columns[j], "title", ""),
              field: _.get(columnsDef[i].columns[j], "field", ""),
              visible: _.get(columnsDef[i].columns[j], "visible", ""),
            });
          }
          columnsState.push({
            title: _.get(columnsDef[i], "title", ""),
            columns: secondLevelColumns,
            visible: _.get(columnsDef[i], "visible", true),
          });
        } else {
          columnsState.push({
            title: _.get(columnsDef[i], "title", ""),
            field: _.get(columnsDef[i], "field", ""),
            visible: _.get(columnsDef[i], "visible", true),
          });
        }
      }
    }
    return columnsState;
  };

  const persistColumns = () => {
    const newReportConfig = _.cloneDeep(
      props.config.savedReportConfig[props.config.currentReport]
    );
    if (newReportConfig.orgMode && newReportConfig.displayMode) {
      if (!newReportConfig.hasOwnProperty("tablePersistence")) {
        newReportConfig.tablePersistence = {};
      }
      if (
        !newReportConfig.tablePersistence.hasOwnProperty(
          newReportConfig.orgMode
        )
      ) {
        newReportConfig.tablePersistence[newReportConfig.orgMode] = {};
      }
      if (
        !newReportConfig.tablePersistence[
          newReportConfig.orgMode
        ].hasOwnProperty(newReportConfig.displayMode)
      ) {
        newReportConfig.tablePersistence[newReportConfig.orgMode][
          newReportConfig.displayMode
        ] = {};
      }

      newReportConfig.tablePersistence[newReportConfig.orgMode][
        newReportConfig.displayMode
      ].columns = getCurrentColumnState();

      const newConfig = _.cloneDeep(props.config);
      newConfig.savedReportConfig[newConfig.currentReport] = newReportConfig;

      //update report config without rerender
      props.updateReportConfig(newConfig, false);
    }
  };

  const hideColumn = (e, column) => {
    return [
      {
        label: "Hide Column",
        action: function (e, column) {
          e.stopPropagation();
          column.hide();
        },
      },
    ];
  };

  const editBuildsAttribute = (buildName) => {
    return [
      {
        label: "Edit Builds Attribute",
        action: () => openBuildsLabelConextMenu(buildName),
      },
    ];
  };

  const setBaseline = (buildName) => {
    // check it is a different build from current baseline builds
    if (
      !Array.isArray(_.get(reportConfig, "baselineBuilds", [])) ||
      (Array.isArray(_.get(reportConfig, "baselineBuilds", [])) &&
        !_.get(reportConfig, "baselineBuilds", []).includes(buildName))
    ) {
      let baselines = null;
      // check if baselines is array
      if (Array.isArray(_.get(reportConfig, "baselineBuilds", []))) {
        // get all current baselines
        baselines = _.cloneDeep(_.get(reportConfig, "baselineBuilds", []));
        // extract block from the new buildname
        const block = buildName.split("/")[2];
        // search for baseline for new block
        const filteredBaseline = baselines.filter(
          (baseline) => baseline.split("/")[2] == block
        );
        // check if baseline exists for current block
        if (filteredBaseline && filteredBaseline.length) {
          // replace the old baseline for current block with new buildname
          if (
            (!props.config.savedReportConfig[props.config.currentReport]
              .hierBlockMode ||
              !props.config.savedReportConfig[props.config.currentReport]
                .hierBuildMode) &&
            props.config.savedReportConfig[props.config.currentReport]
              .orgMode == "BCxM"
          ) {
            baselines = [buildName];
          } else {
            baselines.splice(
              baselines.indexOf(filteredBaseline[0]),
              1,
              buildName
            );
          }
        } else {
          // if no baseline exist for current block then add new buildname
          baselines.push(buildName);
        }
      } else {
        baselines = [buildName];
      }
      const newConfig = _.cloneDeep(
        useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
          props.id
        ].config
      );
      newConfig.savedReportConfig[newConfig.currentReport].baselineBuilds =
        baselines;

      props.updateReportConfig(newConfig);
    }
  };

  let rowContextMenuSetBaseline = (e, row) => {
    let rowData = row.getData();
    let buildName = rowData.buildName;
    // extract build name from baseline
    buildName = buildName.split("###")[0];
    let block = rowData.block;
    // if (props.config.savedReportConfig[props.config.currentReport]?.displayMode && props.config.savedReportConfig[props.config.currentReport]?.displayMode != undefined) {
    //   displayMode = props.config.savedReportConfig[props.config.currentReport].displayMode;
    // }
    setBaseline(buildName);
  };

  let rowContextMenuUnsetBaseline = (buildName) => {
    // let buildName =;
    buildName = buildName.split("###")[0];
    // check it is a different build from current baseline builds
    if (
      !Array.isArray(_.get(reportConfig, "baselineBuilds", [])) ||
      (Array.isArray(_.get(reportConfig, "baselineBuilds", [])) &&
        _.get(reportConfig, "baselineBuilds", []).includes(buildName))
    ) {
      let baselines = null;
      // check if baselines is array
      if (Array.isArray(_.get(reportConfig, "baselineBuilds", []))) {
        // get all current baselines
        baselines = _.cloneDeep(_.get(reportConfig, "baselineBuilds", []));
        // extract block from the new buildname
        const block = buildName.split("/")[2];
        // search for baseline for new block
        const filteredBaseline = baselines.filter(
          (baseline) => baseline.split("/")[2] == block
        );
        // check if baseline exists for current block
        if (filteredBaseline && filteredBaseline.length) {
          // replace the old baseline for current block with new buildname
          baselines.splice(baselines.indexOf(filteredBaseline[0]), 1);
        } else {
          // if no baseline exist for current block then add new buildname
          baselines.push(buildName);
        }
      } else {
        baselines = [buildName];
      }
      const newConfig = _.cloneDeep(
        useGlobalStore.getState()[props.rptType][props.reportKey].widgets[
          props.id
        ].config
      );
      newConfig.savedReportConfig[newConfig.currentReport].baselineBuilds =
        baselines;

      props.updateReportConfig(newConfig);
    }
  };

  const handleRowContextMenuSetBaseline = {
    label: "Set baseline",
    action: rowContextMenuSetBaseline,
  };
  //-----------------------------------------------------------

  //Plotting
  let addWidgets = (wProps) => {
    for (let i = 0; i < wProps.widgets.length; i++) {
      const widgetsSettings = produce(wProps.widgets[i], (settingsDraft) => {
        delete settingsDraft.currentReportName;
        delete settingsDraft.data;
      });

      const data = _.get(wProps.widgets[i], "data", {});
      addWidgetCommonFunction(
        props.rptType,
        props.reportKey,
        widgetsSettings,
        data,
        showWidgetDataUiState,
        props.index
      );
    }
  };

  let plot = (e, row) => {
    const buildName = row.getData().buildName;
    const checkpoint = row.getData().checkpoint;
    const clicked = e.target.innerText;
    let titleElement = null;
    let args = null;
    let rows = null;
    let rowsData = [];
    for (let i in customContexts) {
      if (clicked == customContexts[i].label) {
        args = customContexts[i].args;
      }
    }
    if (args.X == "builds") {
      rows = tableInst.current.getRows().filter((r) => {
        return r.getData().checkpoint == checkpoint;
      });
      titleElement = "Common Checkpoint: " + checkpoint;
    } else {
      rows = tableInst.current.getRows().filter((r) => {
        return r.getData().buildName == buildName;
      });
      titleElement = "Common Build: " + buildName;
    }
    if (tableInst.getSorters().length) {
      function sortRows(data, field) {
        return data.sort((a, b) => {
          let val1 = a.getData()[field];
          let val2 = b.getData()[field];
          // check if both are numerical
          if (!isNaN(Number(val1)) || !isNaN(Number(val2))) {
            //cast them as num
            val1 = Number(val1);
            val2 = Number(val2);
          }
          if (val1 < val2) {
            return -1;
          } else if (val1 > val2) {
            return 1;
          } else {
            return 0;
          }
        });
      }
      rows = sortRows(rows, tableInst.current.getSorters()[0].field);
    }
    for (let id in rows) {
      rowsData.push(rows[id].getData());
    }
    axios
      .post(metricsURL + "calcBarLineCharts/", {
        buildName: buildName,
        checkpoint: checkpoint,
        args: args,
        rows: rowsData,
      })
      .then((response) => {
        let status = _.get(response.data, "status", false);
        if (status) {
          let data = _.get(response.data, "data", []);
          const yCoord = props.widgetProps.y;
          const currentReportName = props.widgetProps;
          let _title = props.widgetprops.config.savedReportConfig[
            props.config.currentReport
          ].title
            ? props.widgetprops.config.savedReportConfig[
                props.config.currentReport
              ].title
            : "Metrics";
          addWidgets({
            widgets: [
              {
                name: "Metrics Group Bar Chart",
                reportName: props.reportKey, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Bar/Line chart : For Metrics-(Parent Widget:${_title}, ${titleElement})`,
                  dataLocation: "dataLocation",
                  bucket: "bucket",
                  data: "",
                  columns: [],
                  // query: _.get(data, "query", defaultQueryBody),
                  groupingAxis: args.X == "Y",
                },
                data: data,
              },
            ],
          });
        } else {
          let message = _.get(response.data, "message", "");
          console.log(message);
        }
      })
      .catch((error) => {
        console.log(error);
      });
    // let data = calculateChartData(buildName, checkpoint, args, rowsData)
  };

  const openBuildsLabelConextMenu = async (buildName) => {
    setOpenBuildsLabel(true);
    setSelectedBuild(buildName);
    const input = { selectedBuilds: [buildName] };
    const response = await api(metricsURL + "getLabelsOfBuilds", input);
    if (response.status) {
      setBuildLabel(_.get(response.result, buildName, ""));
    }
  };

  const getRowContextMenu = (e, row) => {
    let rowContextMenu = [];
    let plotContextMenu = null;

    const rowData = row.getData();
    const orgMode = _.get(
      props.config.savedReportConfig[props.config.currentReport],
      "orgMode",
      "BCxM"
    );

    if (orgMode == "BCxM" || orgMode == "CBxM") {
      let buildName = rowData["buildName"];

      // extract build name from baseline text
      buildName = buildName.split("###")[0];

      if (
        typeof _.get(reportConfig, "baselineBuilds", []) == "string" ||
        (Array.isArray(_.get(reportConfig, "baselineBuilds", [])) &&
          !_.get(reportConfig, "baselineBuilds", []).includes(buildName))
      ) {
        rowContextMenu.push(handleRowContextMenuSetBaseline);
        rowContextMenu.push({
          label: "Analytics",
          action: openRowAnalyticsReport,
        });
      }

      if (
        reportConfig.baselineBuilds != undefined &&
        reportConfig.baselineBuilds != "" &&
        Array.isArray(_.get(reportConfig, "baselineBuilds", [])) &&
        _.get(reportConfig, "baselineBuilds", []).includes(buildName)
      ) {
        rowContextMenu.push(
          handleRowContextMenuUnsetBaseline(row.getData()["buildName"])
        );
        rowContextMenu.push({
          label: "Analytics",
          action: openRowAnalyticsReport,
        });
      }

      rowContextMenu = rowContextMenu.concat(editBuildsAttribute(buildName));
    }
    // rowContextMenu.push(JSON.parse(JSON.stringify(plotContextMenu)));
    return rowContextMenu;
  };

  let rowMouseEnter = (e, row) => {
    if (tableInst.current == null) {
      return;
    }
    // Deselect all rows styles
    if (prevRowHighlighted != null) {
      for (let id in prevRowHighlighted) {
        if (prevRowHighlighted[id].getElement()) {
          prevRowHighlighted[id].getElement().style.borderColor = "#cccccc";
          // prevRowHighlighted[id].getElement().style.color = "#333333";
        }
      }
    }

    if (true) {
      let hoverCheckpoint = row.getData().checkpoint;
      let rows = tableInst.current.getRows().filter((r) => {
        return r.getData().checkpoint == hoverCheckpoint;
      });
      prevRowHighlighted = rows;
      for (let id in rows) {
        rows[id].getElement().style.borderColor = "blue";
        // rows[id].getElement().style.color = "white";
      }
    }
  };

  const persistTable = (
    columns = [],
    filters = [],
    sorters = [],
    size = 25,
    page = 1
  ) => {
    const newReportConfig = _.cloneDeep(
      props.config.savedReportConfig[props.config.currentReport]
    );
    if (newReportConfig.orgMode && newReportConfig.displayMode) {
      if (!newReportConfig.hasOwnProperty("tablePersistence")) {
        newReportConfig.tablePersistence = {};
      }
      if (
        !newReportConfig.tablePersistence.hasOwnProperty(
          newReportConfig.orgMode
        )
      ) {
        newReportConfig.tablePersistence[newReportConfig.orgMode] = {};
      }
      if (
        !newReportConfig.tablePersistence[
          newReportConfig.orgMode
        ].hasOwnProperty(newReportConfig.displayMode)
      ) {
        newReportConfig.tablePersistence[newReportConfig.orgMode][
          newReportConfig.displayMode
        ] = {};
      }

      // set filters
      let uniqueFields = [];
      const cleanFilters = filters.map((filter) => {
        const newFilter = { ...filter };
        newFilter.type = "in";
        return newFilter;
      });

      const uniqueFilters = cleanFilters.filter((filter) => {
        if (uniqueFields.includes(_.get(filter, "field", ""))) {
          return false;
        }
        uniqueFields.push(_.get(filter, "field", ""));
        return true;
      });

      newReportConfig.tablePersistence[newReportConfig.orgMode][
        newReportConfig.displayMode
      ].filters = uniqueFilters;
      //end setting filters

      // set sorters
      uniqueFields = [];
      const cleanSorters = sorters.map((sorter) => {
        const newSorter = { ...sorter };
        delete newSorter.column;
        newSorter.column = newSorter.field;
        delete newSorter.field;
        return newSorter;
      });

      const uniqueSorters = cleanSorters.filter((sorter) => {
        if (uniqueFields.includes(_.get(sorter, "field", ""))) {
          return false;
        }
        uniqueFields.push(_.get(sorter, "field", ""));
        return true;
      });

      newReportConfig.tablePersistence[newReportConfig.orgMode][
        newReportConfig.displayMode
      ].sorters = uniqueSorters;
      // end setting sorters

      // set columns
      newReportConfig.tablePersistence[newReportConfig.orgMode][
        newReportConfig.displayMode
      ].columns = columns;

      //set size
      newReportConfig.tablePersistence[newReportConfig.orgMode][
        newReportConfig.displayMode
      ].size = size;

      //set page
      newReportConfig.tablePersistence[newReportConfig.orgMode][
        newReportConfig.displayMode
      ].page = page;

      const newConfig = _.cloneDeep(props.config);
      newConfig.savedReportConfig[newConfig.currentReport] = newReportConfig;

      //update report config without rerender
      props.updateReportConfig(newConfig, false);
    }
  };

  const getGroupByValue = (
    orgMode,
    hierBlockMode = true,
    hierBuildMode = true
  ) => {
    let groupByValue = null;
    if (orgMode == "BCxM") {
      if (hierBlockMode == true && hierBuildMode == true) {
        groupByValue = ["BLOCK", "displayBuildName"];
      } else if (hierBlockMode == true && hierBuildMode == false) {
        groupByValue = ["BLOCK"];
      } else if (hierBlockMode == false && hierBuildMode == true) {
        groupByValue = ["displayBuildName"];
      } else {
        groupByValue = [];
      }
    } else if (orgMode == "CBxM") {
      if (hierBlockMode == false) {
        groupByValue = "checkpoint";
      } else {
        groupByValue = ["checkpoint", "BLOCK"];
      }
    } else if (orgMode == "CMxB") {
      groupByValue = "checkpoint";
    } else if (orgMode == "MCxB") {
      groupByValue = "metricGroupDisplayName";
    }
    return groupByValue;
  };

  const groupHeader = (value, count, data, group) => {
    const orgMode =
      props.config.savedReportConfig[props.config.currentReport].orgMode;
    if (orgMode == "BCxM" && value && value.split("/").length >= 5) {
      let label = _.get(data[0], "LABEL", "");
      return (
        getBuildsNomenclature(value, label) +
        "<span style='margin-left:10px;'>(" +
        count +
        " item)</span>"
      );
    }
    return (
      value + "<span style='margin-left:10px;'>(" + count + " item)</span>"
    );
  };

  const getTableHier = () => {
    let hier = [];
    const reportConfig =
      props.config.savedReportConfig[props.config.currentReport];
    const blockHier = _.get(reportConfig, "hierBlockMode", true);
    const buildHier = _.get(reportConfig, "hierBuildMode", true);
    if (blockHier) {
      hier.push("BLOCK");
    }
    if (buildHier) {
      hier.push("buildName");
    }
    return hier;
  };

  const getBaselines = () => {
    let baselines =
      reportConfig?.baselineBuilds && reportConfig?.baselineBuilds.length
        ? reportConfig?.baselineBuilds
        : [];
    if (!getTableHier().includes("BLOCK")) {
      baselines = baselines.slice(-1);
    }
    return baselines;
  };

  const rowHeaderFormatter = (cell, formatterParams, onRendered) => {
    return (
      cell.getRow().getPosition() +
      (tableInst.current.getPage() - 1) * tableInst.current.getPageSize()
    );
  };

  const isColOrderSame = (cols1, cols2) => {
    if (cols1.length !== cols2.length) {
      return false;
    }

    for (let i = 0; i < cols1.length; i++) {
      const column1 = cols1[i];
      const column2 = cols2[i];

      if (column1.field !== column2.field) {
        return false;
      }

      if (column1.visible !== column2.visible) {
        return false;
      }

      if (column1.title !== column2.title) {
        return false;
      }

      if (column1.columns && column2.columns) {
        if (!isColOrderSame(column1.columns, column2.columns)) {
          return false;
        }
      } else if (column1.columns || column2.columns) {
        return false;
      }
    }

    return true;
  };

  const saveFormatOptions = () => {
    const newConfig = _.cloneDeep(props.config);

    const newReportConfig = _.cloneDeep(reportConfig);

    if (
      (!reportConfig.hierBlockMode || !reportConfig.hierBuildMode) &&
      _.get(reportConfig, "baselineBuilds", []).length > 1 &&
      props.config.savedReportConfig[props.config.currentReport].orgMode ==
        "BCxM"
    ) {
      newReportConfig.baselineBuilds = [
        reportConfig.baselineBuilds[reportConfig.baselineBuilds.length - 1],
      ];
    }
    newConfig.savedReportConfig[props.config.currentReport] = newReportConfig;
    props.updateReportConfig(newConfig);
    setShowFormat(false);
  };

  const handleFormatChange = (formatKey, formatValue) => {
    const newReportConfig = _.cloneDeep(reportConfig);
    newReportConfig[formatKey] = formatValue;
    setReportConfig(newReportConfig);
  };

  const handleDownload = (fileFormat) => {
    const config = props.config;
    const input = {
      selectedBuilds: props.buildSpec ? props.buildSpec : [],
      // report: config.savedReportConfig[config.currentReport]?.report ? config.savedReportConfig[config.currentReport]?.report : {},

      reportSpecName: config.reportSpecName,
      reportName: config.currentReport,
      sort: getInitialSorters(),
      filter: getInitialFilter(),
      hierSpec: [],
      auth: {
        user: _.get(useConfigStore.getState(), "authLoginUser", ""),
      },
      tableMode: _.get(
        config.savedReportConfig[config.currentReport],
        "orgMode",
        "BCxM"
      ),
      displayMode: config.savedReportConfig[config.currentReport]?.displayMode
        ? config.savedReportConfig[config.currentReport]?.displayMode
        : "VALUE",
      referenceMode:
        _.get(
          config.savedReportConfig[config.currentReport],
          "displayMode",
          "VALUE"
        ) !== "REFS_OFF",
      metricsConfigs: metrics,
      baselines: getBaselines(),
      tableHier: getTableHier(),
      fileFormat: fileFormat,
      waiver: reportConfig.waiverMetrics,
      hideEmptyRuns: !config.savedReportConfig[config.currentReport].showEmpty,
      rawQuery: _.get(props.config, "query", ""),
      variables: _.get(props.config, "wVariables", {}),
      hiddenBuilds: hiddenBuilds,
      hiddenCheckpoints: _.get(
        props.config,
        ["checkpointsConfig", "hiddenCheckpoints"],
        []
      ),
    };
    axios
      .post(metricsURL + "downloadRunMetricsQuery/", input, {
        responseType: "blob",
      })
      .then((responseData) => {
        const blob = new Blob([responseData.data], {
          type: responseData.headers["Content-Type"],
        });

        const url = window.URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.href = url;
        link.setAttribute(
          "download",
          `${props.config.currentReportName}.${fileFormat}`
        );

        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);
      })
      .catch((error) => {
        console.log(error);
      });
    setOpenDownloadMenu(false);
    setAnchorEl(null);
  };

  const handleDownloadHTML = () => {
    tableInst.current.download(
      "html",
      `${props.config.currentReportName}.html`
    );
    setOpenDownloadMenu(false);
    setAnchorEl(null);
  };

  const createPreQuery = () => {
    let query = "";

    // add runs
    query = query + props.config.query;

    // hide builds
    query =
      query +
      `

hidden_builds_list = ${JSON.stringify(
        _.get(props.config.buildsConfig, "hiddenBuilds", [])
      )}
hidden_checkpoints = ${JSON.stringify(
        _.get(props.config, ["checkpointsConfig", "hiddenCheckpoints"], [])
      )}

all_checkpoints = ${JSON.stringify(_.get(props, ["checkpoints"], []))}
`;

    query =
      query +
      MetricUtils.hideBuildsQuery("hidden_builds_list", "hidden_checkpoints");
    //////////////////////////////////////////////
    // add ranges
    //////////////////////////////////////////////

    // range query

    let rangeQuery = `
# ranges is 2-D List of values and its properties in metaData
`;

    const orgMode = _.get(reportConfig, "orgMode", "BCxM");

    const ranges = tableInst.current.getRanges();
    let rangesArr = [];
    if (orgMode == "BCxM" || orgMode == "CBxM") {
      for (let i = 0; i < ranges.length; i++) {
        const rangeStructRows = ranges[i].getStructuredCells();
        let rangeArr = [];
        for (let j = 0; j < rangeStructRows.length; j++) {
          const rangeRow = rangeStructRows[j];
          let rowArr = [];
          for (let k = 0; k < rangeRow.length; k++) {
            const _cell = rangeRow[k];
            //each cell is added in row
            let value = _cell.getValue();

            try {
              let parsedValue = utils.parseStringToFloat(value);
              if (parsedValue != NaN && typeof parsedValue !== "string") {
                value = parsedValue;
              }
            } catch (error) {
              console.log(error);
            }

            let cellField = _cell.getField();
            let metricValue = "";
            let report = "";
            try {
              const cellFieldArr = cellField.split("__");
              if (cellFieldArr.length == 2) {
                metricValue = cellFieldArr[1];
              }
              report = cellFieldArr[0];
            } catch (error) {
              console.log(error);
            }
            const cellData = _cell.getData();
            rowArr.push({
              value: value,
              metaData: {
                PROJECT: _.get(cellData, "PROJECT", ""),
                USER: _.get(cellData, "USER", ""),
                BLOCK: _.get(cellData, "BLOCK", ""),
                PHASE: _.get(cellData, "PHASE", ""),
                RUNTAG: _.get(cellData, "RUNTAG", ""),
                CHECKPOINT: _.get(cellData, "checkpoint", ""),
                METRIC: metricValue,
                METRIC_TABLE_NAME: report,
              },
            });
          }
          // each row is added in range
          rangeArr.push(rowArr);
        }
        //each range is added in ranges
        rangesArr.push(rangeArr);
      }
    } else if (["MCxB", "CMxB", "MxBC"].includes(orgMode)) {
      for (let i = 0; i < ranges.length; i++) {
        const rangeStructRows = ranges[i].getStructuredCells();
        let rangeArr = [];
        for (let j = 0; j < rangeStructRows.length; j++) {
          const rangeRow = rangeStructRows[j];
          let rowArr = [];
          for (let k = 0; k < rangeRow.length; k++) {
            const _cell = rangeRow[k];
            //each cell is added in row
            let value = _cell.getValue();

            try {
              let parsedValue = utils.parseStringToFloat(value);
              if (parsedValue != NaN && typeof parsedValue !== "string") {
                value = parsedValue;
              }
            } catch (error) {
              console.log(error);
            }
            let cellField = _cell.getField();
            const cellData = _cell.getData();
            let report = _.get(cellData, "metricExternalKey", "").split(
              "__"
            )[0];
            rowArr.push({
              value: value,
              metaData: {
                PROJECT: _.get(
                  cellData,
                  ["runMetadata", cellField, "PROJECT"],
                  ""
                ),
                USER: _.get(cellData, ["runMetadata", cellField, "USER"], ""),
                BLOCK: _.get(cellData, ["runMetadata", cellField, "BLOCK"], ""),
                PHASE: _.get(cellData, ["runMetadata", cellField, "PHASE"], ""),
                RUNTAG: _.get(
                  cellData,
                  ["runMetadata", cellField, "RUNTAG"],
                  ""
                ),
                CHECKPOINT: _.get(
                  cellData,
                  ["runMetadata", cellField, "checkpoint"],
                  ""
                ),
                METRIC: _.get(cellData, "metric", ""),
                METRIC_TABLE_NAME: report,
              },
            });
          }
          // each row is added in range
          rangeArr.push(rowArr);
        }
        //each range is added in ranges
        rangesArr.push(rangeArr);
      }
    }

    rangeQuery = `
null = None
ranges = ${JSON.stringify(rangesArr)}

`;
    query = query + rangeQuery;

    return query;
  };

  const handleAddwidgetMenu = async (widgetId) => {
    const preQuery = createPreQuery();
    props.handleAddWidget(widgetId, preQuery);
  };

  const handleContextMenu = (menu) => {
    const action = _.get(menu, "action", null);
    if (action == "addWidget") {
      handleAddwidgetMenu(_.get(menu, "widgetId", null));
    }
    setOpenMenu(false);
    setAnchorElMenu(null);
  };

  const getReportContextMenu = () => {
    let contextMenu = [];
    const reportContextMenu = _.get(
      props,
      ["reportSpec", "reportNames", props.config.currentReport, "contextMenu"],
      []
    );
    reportContextMenu.forEach((menu) => {
      const menuItem = (
        <Tooltip title={_.get(menu, "tooltip", "")} placement="right-start">
          <MenuItem onClick={() => handleContextMenu(menu)} disableRipple>
            {_.get(menu, "label", "")}{" "}
          </MenuItem>
        </Tooltip>
      );
      contextMenu.push(menuItem);
    });

    return contextMenu;
  };

  const getReportMenu = () => {
    return (
      <div id="reportMenu" style={{ width: "100%", height: "30px" }}>
        <ButtonGroup size="small" variant="text">
          <Chip
            label={props.config.currentReportName}
            sx={{ height: "28px" }}
            variant={"outlined"}
            onClick={() => {
              props.handleReportsPane(true);
            }}
          />
          <Button
            // variant="outlined"
            size="small"
            onClick={() => {
              setShowFormat(true);
              setReportConfig(
                props.config.savedReportConfig[props.config.currentReport]
              );
            }}
          >
            Format
          </Button>
          <Button
            id="demo-customized-button"
            aria-controls={
              openDownloadMenu ? "demo-customized-menu" : undefined
            }
            aria-haspopup="true"
            aria-expanded={openDownloadMenu ? "true" : undefined}
            size="small"
            onClick={(event) => {
              setOpenDownloadMenu(true);
              setAnchorEl(event.currentTarget);
            }}
            endIcon={<KeyboardArrowDownIcon />}
          >
            Download
          </Button>
          <StyledMenu
            id="demo-customized-menu"
            MenuListProps={{
              "aria-labelledby": "demo-customized-button",
            }}
            anchorEl={anchorEl}
            open={openDownloadMenu}
            onClose={() => {
              setOpenDownloadMenu(false);
              setAnchorEl(null);
            }}
          >
            <MenuItem
              onClick={() => {
                handleDownload("xlsx");
              }}
              disableRipple
            >
              XLS
            </MenuItem>
            <MenuItem
              onClick={() => {
                handleDownload("csv");
              }}
              disableRipple
            >
              CSV
            </MenuItem>
            <MenuItem
              onClick={() => {
                handleDownloadHTML();
              }}
              disableRipple
            >
              HTML
            </MenuItem>
          </StyledMenu>
          <Button onClick={() => handleOpenMetrics(true)}>Metrics</Button>
          <Button onClick={() => handleOpenBuilds(true)}>Builds</Button>
          <Button onClick={() => props.handleOpenCheckpoint(true)}>
            Checkpoints
          </Button>
          <Button onClick={() => handleShowWaiver(true)}>Show Waivers</Button>
          <Button
            id="demo-customized-button"
            aria-controls={
              openDownloadMenu ? "demo-customized-menu" : undefined
            }
            aria-haspopup="true"
            aria-expanded={openDownloadMenu ? "true" : undefined}
            size="small"
            onClick={(event) => {
              setOpenMenu(true);
              setAnchorElMenu(event.currentTarget);
            }}
            endIcon={<KeyboardArrowDownIcon />}
          >
            Menu
          </Button>
          <StyledMenu
            id="demo-customized-menu"
            MenuListProps={{
              "aria-labelledby": "demo-customized-button",
            }}
            anchorEl={anchorElMenu}
            open={openMenu}
            onClose={() => {
              setOpenMenu(false);
              setAnchorElMenu(null);
            }}
          >
            {getReportContextMenu()}
          </StyledMenu>
        </ButtonGroup>
        {
          <Modal open={showFormat} container={compareReportRef.current}>
            <Box
              sx={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: "400px",
                height: "auto",
                bgcolor: "background.paper",
                border: "2px solid #000",
                boxShadow: 24,
                borderRadius: "15px",
                p: 2,
              }}
            >
              <Box>
                <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                  Format Report
                </Typography>
              </Box>
              <Divider />
              <Stack spacing={2}>
                <FormControl>
                  <InputLabel>Table Mode</InputLabel>
                  <Select
                    value={_.get(reportConfig, "orgMode", "BCxM")}
                    label="Table Mode"
                    onChange={(e) => {
                      handleFormatChange("orgMode", e.target.value);
                    }}
                    size={"small"}
                  >
                    {[
                      { value: "BCxM", title: "Builds/Checkpoints X Metrics" },
                      { value: "CBxM", title: "Checkpoints/Builds X Metrics" },
                      { value: "CMxB", title: "Checkpoints/Metrics X Builds" },
                      { value: "MCxB", title: "Metrics/Checkpoints X Builds" },
                      { value: "MxBC", title: "Metrics X Builds/Checkpoints" },
                    ].map((item) => (
                      <MenuItem value={item.value}>{item.title}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <FormControl>
                  <InputLabel>Display Mode</InputLabel>
                  <Select
                    value={_.get(reportConfig, "displayMode", "VALUE")}
                    label="Display Mode"
                    onChange={(e) => {
                      handleFormatChange("displayMode", e.target.value);
                    }}
                    size={"small"}
                  >
                    {[
                      { value: "VALUE", title: "Value" },
                      { value: "DELTAVALUE", title: "Delta Value" },
                      { value: "DELTAPERCENT", title: "Delta %" },
                      {
                        value: "ABS_DELTAVALUE",
                        title: "Absolute (Delta Value)",
                      },
                      { value: "ABS_DELTAPERCENT", title: "Absolute (Delta%)" },
                      { value: "VALUE_DELTAPERCENT", title: "Value (Delta%)" },
                      { value: "REFS_OFF", title: "Refs Off" },
                    ].map((item) => (
                      <MenuItem value={item.value}>{item.title}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <FormControl>
                  <InputLabel>Show empty</InputLabel>
                  <Select
                    value={_.get(reportConfig, "showEmpty", true)}
                    label="Show empty"
                    onChange={(e) => {
                      handleFormatChange("showEmpty", e.target.value);
                    }}
                    size={"small"}
                  >
                    {[
                      { value: true, title: "Show" },
                      { value: false, title: "Hide" },
                    ].map((item) => (
                      <MenuItem value={item.value}>{item.title}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
                {reportConfig.orgMode == "BCxM" ||
                reportConfig.orgMode == "CBxM" ? (
                  <FormControl>
                    <InputLabel>Block Hier</InputLabel>
                    <Select
                      value={_.get(reportConfig, "hierBlockMode", true)}
                      label="Block Hier"
                      onChange={(e) => {
                        handleFormatChange("hierBlockMode", e.target.value);
                      }}
                      size={"small"}
                    >
                      {[
                        { value: true, title: "On" },
                        { value: false, title: "Off" },
                      ].map((item) => (
                        <MenuItem value={item.value}>{item.title}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                ) : null}
                {reportConfig.orgMode == "BCxM" ? (
                  <FormControl>
                    <InputLabel>Build hier</InputLabel>
                    <Select
                      value={_.get(reportConfig, "hierBuildMode", true)}
                      label="Build hier"
                      onChange={(e) => {
                        handleFormatChange("hierBuildMode", e.target.value);
                      }}
                      size={"small"}
                    >
                      {[
                        { value: true, title: "On" },
                        { value: false, title: "Off" },
                      ].map((item) => (
                        <MenuItem value={item.value}>{item.title}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                ) : null}
              </Stack>
              <Divider />
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "right", marginTop: "10px" }}
              >
                <Button onClick={() => saveFormatOptions()}>Save</Button>
                <Button onClick={() => setShowFormat(false)}>Cancel</Button>
              </ButtonGroup>
            </Box>
          </Modal>
        }
      </div>
    );
  };

  const handleMetricVisibilityCheck = (metric, event) => {
    const newMetrics = _.cloneDeep(metrics);
    newMetrics[metric] = { hidden: !event.target.checked };
    setMetrics(newMetrics);
  };

  const handleBuildsNameCheck = (tag, event) => {
    const newBuildsNomenclature = _.cloneDeep(buildsNomenclature);
    newBuildsNomenclature[tag] = { show: event.target.checked };
    setBuildsNomenclature(newBuildsNomenclature);
  };

  const handleSaveMetrics = () => {
    const newConfig = _.cloneDeep(props.config);
    newConfig.savedReportConfig[newConfig.currentReport].metricsConfig =
      metrics;
    props.updateReportConfig(newConfig);
  };

  const handleSaveBuilds = (hiddenBuildsList = []) => {
    const newConfig = _.cloneDeep(props.config);

    newConfig.buildsConfig = {
      buildsNomenclature: buildsNomenclature,
      hiddenBuilds: hiddenBuildsList,
    };

    props.updateReportConfig(newConfig);
  };

  const handleBuildsCancel = () => {
    setBuildsNomenclature(
      _.get(props.config.buildsConfig, "buildsNomenclature", {})
    );
    handleOpenBuilds(false);
  };

  const handleCheckpointCancel = () => {
    props.handleOpenCheckpoint(false);
  };

  const handleBuildsLabel = (event) => {
    setBuildLabel(event.target.value);
  };

  const handleBuildsVisibleCheck = (event) => {
    setSelectedBuildHiddenFlag(event.target.checked);
  };

  const cancelBuildLabel = () => {
    setOpenBuildsLabel(false);
    setBuildLabel("");
    setSelectedBuildHiddenFlag(false);
  };

  const saveBuildLabel = async () => {
    const input = {
      buildName: selectedBuild,
      label: buildLabel,
    };
    if (selectedBuild != "" && selectedBuild != "") {
      await api(metricsURL + "labelBuild/", input);
    }

    const newConfig = _.cloneDeep(props.config);
    if (selectedBuildHiddenFlag) {
      const buildIndex = _.get(
        props.config.buildsConfig,
        "hiddenBuilds",
        []
      ).indexOf(selectedBuild);

      // if selected build does not exist in existing hidden builds then proceed
      if (buildIndex == -1) {
        if (!newConfig.hasOwnProperty("buildsConfig")) {
          newConfig.buildsConfig = {
            buildsNomenclature: {},
            hiddenBuilds: [],
          };
        }

        if (!newConfig.buildsConfig.hasOwnProperty("hiddenBuilds")) {
          newConfig.buildsConfig.hiddenBuilds = [];
        }
        newConfig.buildsConfig.hiddenBuilds.push(selectedBuild);
      }
    }

    props.updateReportConfig(newConfig);
    cancelBuildLabel();
  };

  const handleAllMetricVisbility = (flag) => {
    const newMetrics = _.cloneDeep(metrics);
    for (let [metricKey, metric] of Object.entries(newMetrics)) {
      newMetrics[metricKey] = { hidden: !flag };
    }
    setMetrics(newMetrics);
  };

  const getModals = () => {
    return (
      <Box>
        <Modal open={showAddWaiver} container={compareReportRef.current}>
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: "80%",
              height: "auto",
              bgcolor: "background.paper",
              border: "2px solid #000",
              boxShadow: 24,
              borderRadius: "15px",
              p: 2,
            }}
          >
            <Box>
              <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                Waiver Reason
              </Typography>
              <Divider />
              <TextField
                label="Waiver reason"
                size="small"
                fullWidth
                value={waiverComment}
                onChange={(e) => setWaiverComment(e.target.value)}
              />
              <Divider />
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "right", marginTop: "10px" }}
              >
                <Button
                  onClick={() => {
                    saveWaiver();
                    setWaiverComment("");
                  }}
                >
                  Save
                </Button>
                <Button
                  onClick={() => {
                    setShowAddWaiver(false);
                    setWaiverComment("");
                  }}
                >
                  Cancel
                </Button>
              </ButtonGroup>
            </Box>
            <Divider />
            <Stack spacing={2}></Stack>
          </Box>
        </Modal>
        <Modal open={showWaiver} container={compareReportRef.current}>
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: "80%",
              height: "auto",
              bgcolor: "background.paper",
              border: "2px solid #000",
              boxShadow: 24,
              borderRadius: "15px",
              p: 2,
            }}
          >
            <Box>
              <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                Waivers
              </Typography>
              <Divider />
              {reportConfig.waiverMetrics
                ? _.map(reportConfig.waiverMetrics, (metric, metricKey) => (
                    <Box>
                      <Typography>Metric: {metricKey}</Typography>
                      {_.map(metric, (waiverReason, blockKey, blocks) =>
                        ![
                          ALL__BLOCKS__WAIVER,
                          DELETED__BLOCKS__WAIVER,
                        ].includes(blockKey) ? (
                          <Typography sx={{ textIndent: "20px" }}>
                            {blockKey} : {waiverReason}
                          </Typography>
                        ) : blockKey == ALL__BLOCKS__WAIVER &&
                          Object.keys(blocks).includes(
                            DELETED__BLOCKS__WAIVER
                          ) ? (
                          <Typography sx={{ textIndent: "20px" }}>
                            All Blocks(but not{" "}
                            {blocks[DELETED__BLOCKS__WAIVER].join(" ")}):{" "}
                            {waiverReason}
                          </Typography>
                        ) : blockKey == ALL__BLOCKS__WAIVER ? (
                          <Typography sx={{ textIndent: "20px" }}>
                            All Blocks : {waiverReason}
                          </Typography>
                        ) : null
                      )}
                    </Box>
                  ))
                : null}
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "right", marginTop: "10px" }}
              >
                <Button onClick={() => setShowWaiver(false)}>Close</Button>
              </ButtonGroup>
            </Box>
            <Divider />
            <Stack spacing={2}></Stack>
          </Box>
        </Modal>
        <Modal open={openMetrics} container={compareReportRef.current}>
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: "80%",
              height: "100%",
              bgcolor: "background.paper",
              border: "2px solid #000",
              boxShadow: 24,
              borderRadius: "15px",
              p: 2,
            }}
          >
            <Box id="Metrics_Box" sx={{ height: "100%" }}>
              <Typography variant={"h5"} sx={{ marginBottom: "20px" }}>
                Metrics
              </Typography>
              <Divider />
              <Box sx={{ height: "calc(100% - 93px)" }}>
                <FormGroup sx={{ overflow: "auto", height: "100%" }}>
                  {_.map(metrics, (metric, metricKey) => {
                    return (
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={!_.get(metric, "hidden", false)}
                            onChange={(event) =>
                              handleMetricVisibilityCheck(metricKey, event)
                            }
                            // defaultChecked={!_.get(metric, "hidden", false)}
                          />
                        }
                        label={
                          _.get(
                            props.reportSpec.reportNames[
                              props.config.currentReport
                            ].metrics[metricKey],
                            "groupName",
                            _.get(
                              _.get(props.reportSpec.metrics, metricKey, {}),
                              "groupName",
                              ""
                            )
                          ) +
                          " || " +
                          _.get(
                            metric,
                            "displayName",
                            _.get(
                              _.get(props.reportSpec.metrics, metricKey, {}),
                              "displayName",
                              metricKey
                            )
                          )
                        }
                      />
                    );
                  })}
                </FormGroup>
              </Box>
              <Divider />
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "left", marginTop: "10px" }}
              >
                <Button
                  onClick={() => {
                    handleAllMetricVisbility(true);
                  }}
                >
                  Show All
                </Button>
                <Button
                  onClick={() => {
                    handleAllMetricVisbility(false);
                  }}
                >
                  Hide All
                </Button>
              </ButtonGroup>
              <ButtonGroup
                size={"small"}
                variant="contained"
                sx={{ float: "right", marginTop: "10px" }}
              >
                <Button
                  onClick={() => {
                    handleSaveMetrics();
                  }}
                >
                  Save
                </Button>
                <Button
                  onClick={() => {
                    setMetrics(
                      _.get(
                        props.config.savedReportConfig[
                          props.config.currentReport
                        ],
                        "metricsConfig",
                        {}
                      )
                    );
                    handleOpenMetrics(false);
                  }}
                >
                  Cancel
                </Button>
              </ButtonGroup>
            </Box>
          </Box>
        </Modal>
        <Modal open={openBuilds} container={compareReportRef.current}>
          <Builds
            buildsNomenclature={buildsNomenclature}
            handleBuildsNameCheck={handleBuildsNameCheck}
            handleSaveBuilds={handleSaveBuilds}
            handleCancle={handleBuildsCancel}
            hiddenBuilds={hiddenBuilds}
          />
        </Modal>
        <Modal
          open={props.openCheckpoints}
          container={compareReportRef.current}
        >
          <Checkpoints
            handleSaveCheckpoints={props.handleSaveCheckpoints}
            handleCancel={handleCheckpointCancel}
            checkpoints={props.checkpoints}
            hiddenCheckpoints={_.get(
              props.config,
              ["checkpointsConfig", "hiddenCheckpoints"],
              []
            )}
          />
        </Modal>
        <Modal open={openBuildsLabel} container={compareReportRef.current}>
          <BuildUserLabel
            buildLabel={buildLabel}
            handleBuildsLabel={handleBuildsLabel}
            hiddenBuilds={hiddenBuilds}
            selectedBuild={selectedBuild}
            saveBuildLabel={saveBuildLabel}
            cancelBuildLabel={cancelBuildLabel}
            handleBuildsVisibleCheck={handleBuildsVisibleCheck}
            selectedBuildHiddenFlag={selectedBuildHiddenFlag}
          />
        </Modal>
      </Box>
    );
  };

  //----------------Table -------------------------
  useEffect(() => {
    const initTable = () => {
      if (tableInst.current == null) {
        const reportConfig =
          props.config.savedReportConfig[props.config.currentReport];
        const config = _.get(props, "config", {});
        const persistingCols = getInitialColumns();

        var columns = getColumns(persistingCols);

        const initialFilters = _.cloneDeep(getInitialFilter());
        const initialPageSize = getInitialPageSize();
        const initialPage = getInitialPage();
        const persistentSorters = getInitialSorters();
        const initialSorters = _.cloneDeep(persistentSorters);

        tableInst.current = new Tabulator(tableRef, {
          // className: "table-sm table-striped table-bordered",
          layout: "fitDataStretch",
          initialHeaderFilter: initialFilters,
          initialSort: initialSorters,
          paginationInitialPage: initialPage,
          //rowHeight: 40,
          // selectable: true,
          headerSortClickElement: "icon",
          // rowHeader: {
          //   resizable: false,
          //   frozen: true,
          //   width: 40,
          //   hozAlign: "center",
          //   formatter: (cell, formatterParams, onRendered) =>
          //     rowHeaderFormatter(cell, formatterParams, onRendered),
          //   headerSort: false,
          //   cssClass: "range-header-col",
          //   editor: false,
          // },
          editTriggerEvent: "dblclick",
          selectableRange: true,
          selectableRangeColumns: true,
          selectableRangeRows: true,
          pagination: true, //enable pagination
          paginationMode: "remote", //enable remote pagination
          sortMode: "remote",
          filterMode: "remote",
          ajaxConfig: "POST",
          paginationSize: initialPageSize,
          paginationSizeSelector: [10, 25, 50, 100, 200],
          paginationCounter: "rows",
          ajaxURL: metricsURL + "runMetricsQuery/",
          ajaxContentType: "json",
          editTriggerEvent: "dblclick",
          // dataSendParams: (page, size, sorters, filter) => {
          // },
          ajaxParams: {
            selectedBuilds: props.buildSpec ? props.buildSpec : [],
            // report: reportConfig?.report ? reportConfig?.report : {},

            reportSpecName: props.config.reportSpecName,
            reportName: config.currentReport,
            hierSpec: [],
            auth: {
              user: _.get(useConfigStore.getState(), "authLoginUser", ""),
            },
            tableMode: _.get(reportConfig, "orgMode", "BCxM"),
            displayMode: props.config.savedReportConfig[
              props.config.currentReport
            ]?.displayMode
              ? reportConfig?.displayMode
              : "VALUE",
            referenceMode:
              _.get(reportConfig, "displayMode", "VALUE") !== "REFS_OFF",
            baselines: getBaselines(),
            tableHier: getTableHier(),
            hideEmptyRuns: !reportConfig.showEmpty,
            metricsConfigs: metrics,
            hiddenBuilds: hiddenBuilds,
            hiddenCheckpoints: _.get(
              props.config,
              ["checkpointsConfig", "hiddenCheckpoints"],
              []
            ),
            // rawQuery: _.get(props.config, "query", ""),
            // variables: _.get(props.config, "wVariables", {}),
          },
          ajaxResponse: (url, params, responseData) => {
            if (tableInst.current && responseData.cols) {
              const newCols = _.cloneDeep(getColumns(responseData.cols));
              ///////////////////////////////////////////////////////////////////////////
              /// Somehow the props are not giving updated values with tabulator.
              ///  So fetching the config directly from the store.
              ///  Replace the below code if you figure out how to get updated props.
              ////////////////////////////////////////////////////////////////////////////
              const config =
                useGlobalStore.getState()[props.rptType][props.reportKey]
                  .widgets[props.id].config;
              const columns = tableInst.current.getColumnDefinitions(); // getInitialColumnsFromConfig(config);
              ////////////////////////////////////////////////////////////////////////////
              const isColOrderSameFlag = isColOrderSame(
                responseData.cols,
                columns
              );
              if (!isColOrderSameFlag && newCols.length > 0) {
                let cols = getColumns(responseData.cols);
                tableInst.current.setColumns(cols);
              }

              persistTable(
                newCols,
                _.get(params, "filter", []),
                _.get(params, "sort", []),
                _.get(params, "size", 25),
                _.get(params, "page", 1)
              );
            }
            if (!responseData.hasOwnProperty("rows")) {
              throw _.get(responseData, "message", "Server Offline");
            }
            const tabulatorLoreFormat = {
              data: responseData.rows ? responseData.rows : [],
              last_page: responseData.lastPage ? responseData.lastPage : 0,
              last_row: _.get(
                responseData,
                "completeCount",
                _.get(responseData, "lastPage", 0) * 25
              ),
            };
            rowsColor = responseData.rows ? responseData.rows : [];
            return tabulatorLoreFormat;
          },

          // movableRows: true,
          rowContextMenu: getRowContextMenu,
          columns: columns ? columns : [],
          // data: rows ? rows : [],
          height: "100%",
          width: "100%",
          // initialFilter: initialHeaderFilters,
          groupBy: getGroupByValue(
            _.get(reportConfig, "orgMode", "BCxM"),
            reportConfig.hierBlockMode,
            reportConfig.hierBuildMode
          ),
          groupHeader: (value, count, data, group) =>
            groupHeader(value, count, data, group),
          // groupToggleElement: "header",
          columnDefaults: {
            headerFilterPlaceholder: "...",
            headerFilterLiveFilter: false,
            tooltip: function (e, cell, onRendered) {
              //e - mouseover event
              //cell - cell component
              //onRendered - onRendered callback registration function

              var el = document.createElement("div");
              el.style.backgroundColor = "rgba(97,97,97)";
              el.style.color = "white";
              el.style.height = "auto";
              el.style.padding = "5px";
              el.style.minHeight = "20px";
              el.style.borderRadius = "10px";
              el.style.opacity = 0.92;
              el.innerText = cell.getValue(); //return cells "field - value";

              return el;
            },
            resizable: true,
          },
        });
        tableInst.current.on("rowMouseEnter", rowMouseEnter);
        tableInst.current.on("dataLoadError", (error) => {
          tableInst.current.alertManager.alert(error, "error");
        });
        // tableInst.current.on("dataLoaded", handlePageLoaded);
        // tableInst.current.on("rangeAdded", handleRangeAdded);
        // tableInst.current.on("rangeRemoved", handleRangeRemoved);
      } else {
        // this.resizeTable();
      }
    };

    initTable();
  }, []);

  return (
    // <h1>I am table</h1>
    <>
      <div
        id="TableCompareReport"
        ref={(ref) => (compareReportRef.current = ref)}
        style={{ width: "100%", height: "100%" }}
      >
        {getReportMenu()}
        {getModals()}
        <div
          id="analytics"
          style={{ width: "100%", height: "calc(100% - 30px)" }}
        >
          <div
            style={{ width: "100%", height: "100%" }}
            ref={(r) => {
              tableRef = r;
            }}
          ></div>
        </div>
      </div>
    </>
  );
};

TableCompareReport.defaultProps = {
  query: "",
  baselineBuild: "",
};

export default TableCompareReport;
