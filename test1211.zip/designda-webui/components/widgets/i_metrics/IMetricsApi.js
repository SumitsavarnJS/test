import * as funcs from "../../../common/Funcs";
import useGlobalStore from "../../../store/useGlobalStore";
import _ from "lodash";
import { produce } from "immer";

const refreshIMetrics = async (widgetId) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);

  // do nothing, give visual effect of loading
  await funcs.sleep(300);
  useGlobalStore.getState().setWidgetData(widgetId, {});

  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });
  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
};

export default refreshIMetrics;
