export const hideBuildsQuery = (hiddenBuilds, hiddenCheckpoints) => {
  return `

def remove_hidden_runs(runs, hidden_builds, hidden_checkpoints):
    if not (hidden_builds or hidden_checkpoints):
        return runs

    hidden_builds = set(hidden_builds)
    hidden_checkpoints = set(hidden_checkpoints)

    def is_visible(run):
        build_name = "/".join(run.get("runName").split("/")[:-2])
        return (build_name not in hidden_builds) and (run.get("runName").split("/")[-2] not in hidden_checkpoints)

    return list(filter(is_visible, runs))

displayed_runs = remove_hidden_runs(runs, ${hiddenBuilds}, ${hiddenCheckpoints})

`;
};
