// react imports
import React, { useState, useEffect } from "react";
import { Typography } from "@mui/material";
import { ReactTabulator, reactFormatter } from "react-tabulator";
import {
  contextMenuHandler,
} from "./LogMonitorTableApi";
import Config, { statusColors, showToast } from "./Config";
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";
import styles from "./LogMonitorTable.module.css";

const LogMonitorTable = (props) => {
  // component constants
  const widgetId = props.id;
  const theme = useConfigStore.getState().theme;
  const uiState = _.get(useGlobalStore.getState()[widgetId], "uiState", {
    showConfig: true,
  });
  // get data of widget using widget Id, actual data from API
  const logTableDataFromResponse = useGlobalStore.getState()[widgetId].data;

  // initialise states
  const [logTableData, setLogTableData] = useState([]);

  const getRequiredObject = (obj, type) => {
    // if key exists
    if(obj[type]) {
      return obj[type].map((obj) => {
        const [
          tool,
          user,
          project,
          block,
          phase,
          run_tag,
          checkpoint,
          timestamp,
        ] = obj.identifier.split(/_SEP_/);
        return {
          ...obj,
          state: type,
          tool,
          user,
          project,
          block,
          phase,
          run_tag,
          checkpoint,
          timestamp,
        };
      });
    }
    // else return empty array
    return [];
  };

  const getStructuredResponse = (dataObj) => {
    const dataArr = [];
    const stateNames = Object.keys(dataObj).length > 0 ? Object.keys(dataObj) : [];
    if(stateNames.length > 0) {
      stateNames.forEach(stateNameVal => {
        const structuredObj = getRequiredObject(dataObj, stateNameVal, stateNameVal);
        // console.log("structuredObj", structuredObj)
        dataArr.push(...structuredObj)
      })
    }
    // console.log("dataArr", dataArr)
    return [...dataArr];
  };
  // once table data comes in, restructure the data and set logTableData state
  useEffect(() => {
    if (Object.keys(logTableDataFromResponse).length > 0) {
      const structuredResponse = getStructuredResponse(
        logTableDataFromResponse
      );
      console.log({ structuredResponse });
      setLogTableData(structuredResponse);
    }
  }, [logTableDataFromResponse]);

  const applyTheme = (theme) =>
    theme == "dark"
      ? "table-sm table-dark table-striped table-bordered"
      : "table-sm table-striped table-bordered";

  const FormatLogStreamState = (props) => {
    const rowData = props.cell._cell.row.data;
    const stateValue = rowData.state;
    const bgColor = statusColors[stateValue];
    return (
      <div
        className={styles.logStreamState}
        style={{ backgroundColor: bgColor ? bgColor : "#f0f0f0" }}
      >
        {stateValue}
      </div>
    );
  };

  const onContextMenuOptionClick = async (type, status, row) => {
    const rowData = row.getData();
    const identifier = rowData.identifier;
    const reportName = props.currentReportName;
    const respData = await contextMenuHandler(type, identifier, widgetId, reportName, status);
    if (respData) {
      // show a success toast
      const toastMsg = respData.message
        ? respData.message
        : `Request executed successfully`;
      showToast({
        reportName: reportName,
        widgetId: widgetId,
        severity: "success",
        message: toastMsg,
      }, widgetId);
      // error case is handled in API file
    }
  };

  const getRowContextMenu = (e, row) => {
    const rowData = row.getData();
    // always existing options
    const menuArray = [
      {
        label: "Terminate Stream",
        action: (e, row) => {
          onContextMenuOptionClick("terminate", null, row);
        },
      },
      {
        separator: true,
      },
    ];
    // only if state is hung OR unavailable, get "set status to" menu option
    if (rowData.state == 'hung' || rowData.state === 'unavailable') {
      const optionSetStatus = {
        label: "Set Status to",
        menu: [
          {
            label: "Failed",
            action: (e, row) => {
              onContextMenuOptionClick("status", "failed", row);
            },
          },
        ]
      };
      menuArray.push(optionSetStatus);
    }

    // if row->state is "finished" OR row->state is "failed", DO NOT SHOW Terminate Stream option
    if(rowData.state === 'finished' || rowData.state === 'failed') {
      return menuArray.filter(menu => menu.label !== "Terminate Stream")
    }
    return menuArray;
  };

  const logTableOptions = {
    selectable: false,
    // remove browser default right click
    rowContext: function (e, row) {
      e.preventDefault();
    },
    rowContextMenu: getRowContextMenu,
    persistenceID: widgetId,
    pagination: "local",
    paginationSize: 20,
    columnDefaults: {
      headerFilter: true,
      headerFilterLiveFilter: false,
      headerFilterPlaceholder: "Type to search ...",
      tooltip: true,
    },
    persistence: {
      filter: true,
      headerFilter: true,
      page: true,
      columns: ["width"],
    },
    dataTree: true,
  };

  const regexBasedFilter = (headerValue, rowValue, rowData, filterParams) => {
    try {
      return RegExp(headerValue, "i").test(rowValue);
    } catch (error) {
      console.error("Filter cannot be applied");
    }
  };

  const logTableColumns = [
    {
      title: "Tool",
      field: "tool",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
    },
    {
      title: "User",
      field: "user",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
    },
    {
      title: "Project",
      field: "project",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
    },
    {
      title: "Block",
      field: "block",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
    },
    {
      title: "Phase",
      field: "phase",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
    },
    {
      title: "Run Tag",
      field: "run_tag",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
    },
    {
      title: "Checkpoint",
      field: "checkpoint",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
    },
    {
      title: "TimeStamp",
      field: "timestamp",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
    },
    {
      title: "State",
      field: "state",
      headerFilter: "input",
      headerSort: false,
      headerFilterFunc: regexBasedFilter,
      resizable: true,
      formatter: reactFormatter(<FormatLogStreamState />),
    },
    {
      title: "Start Time",
      field: "start_time",
      headerFilter: false,
      headerSort: false,
      resizable: true,
    },
    {
      title: "Last Update",
      field: "last_update",
      headerFilter: false,
      headerSort: false,
      resizable: true,
    },
  ];

  // Function to update config
  const updateConfig = (config, save) => {
    // if user has refreshed, save the data in store
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(props.rptType, props.reportKey, widgetId, config);
    }

    useGlobalStore.getState().setWidgetUiState(widgetId, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  // render components (React tabulator) conditionally depending on data
  return (
    <>
      {uiState.showConfig ? (
        <Config
          updateConfig={updateConfig}
          config={props.config}
          id={widgetId}
        />
      ) : logTableData && logTableData.length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <div id="analytics" className={styles.workflowMonitorParent}>
          <ReactTabulator
            key={theme}
            className={applyTheme(theme)}
            style={{ marginTop: "10px", height: "98%" }}
            layout="fitColumns"
            responsiveLayout="collapse"
            autoResize={false}
            resizableColumnFit={true}
            columns={logTableColumns}
            data={logTableData}
            options={logTableOptions}
          />
        </div>
      )}
    </>
  );
};

export default LogMonitorTable;

LogMonitorTable.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: true,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
