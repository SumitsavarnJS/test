import React, { useState } from "react";
import _ from "lodash";
import { Button, TextField } from "@mui/material";
import useGlobalStore from "../../../store/useGlobalStore";
import refreshLogMonitorTable from "./LogMonitorTableApi";
import { produce } from "immer";
import styles from "./Config.module.css";

export const statusColors = {
  running: "#5797f7",
  hung: "#f7b757",
  unavailable: "#dedede",
  completed: "#57f79c",
  queued: "#cff757",
  finished: "#57f79c",
  terminated: "#fc6c62",
};

export const showToast = (toast, widgetId) => {
  const uiState = produce(
    useGlobalStore.getState()[widgetId].uiState,
    (uiStateDraft) => {
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
      uiStateDraft.toastMessage = _.get(toast, "message", "");
    }
  );
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
};

const Config = (props) => {
  const [title, setTitle] = useState(_.get(props.config, "title", ""));
  // handler when user clicks OK button in Config
  const onOKButtonClick = () => {
    const config = {};
    // config["status"] = statusSelectedList;
    // config["require_all_status"] = isParentCheckboxSelected;
    // config["show_only_available_reports"] = showOnlyAvailableReports;
    // add title only if user has provided it
    if (title.length > 0) {
      config["title"] = title;
    }
    // call a method to update the config
    props.updateConfig(config, true);
    // call 'refresh' functionality i.e api call
    refreshLogMonitorTable(props.id);
  };

  return (
    <div className={styles.outer_div}>
      {/* title textbox */}
      <TextField
        fullWidth
        label="Title"
        size="small"
        value={title}
        InputLabelProps={{
          shrink: true,
        }}
        onChange={(event) => setTitle(event.target.value)}
        variant="outlined"
      />
      <Button
        variant="contained"
        size="small"
        disabled={false}
        onClick={onOKButtonClick}
        // classes={
        //   statusSelectedList.length === 0
        //     ? { root: styles.save_button_disabled }
        //     : { root: styles.save_button }
        // }
        classes={{ root: styles.save_button }}
      >
        OK
      </Button>
      <Button
        variant="contained"
        size="small"
        onClick={() => props.updateConfig({}, false)}
        classes={{ root: styles.cancel_button }}
      >
        Cancel
      </Button>
    </div>
  );
};

export default Config;
