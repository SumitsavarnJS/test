import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { produce } from "immer";
import axios from "axios";
import getApi from "../../../common/api/getApi";
// import { dummyData } from "./dummy";
import { showToast } from "./Config";


// dictionary to hold type and endpoint relation
const endpointDict = {
  terminate: "terminate_stream",
  status: "set_status_to_stream",
};

const fetchWidgetData = async (widgetId) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  // api call to get workflow data
  const fetchData = await getApi(
    useConfigStore.getState().configData.rest_server_url +
    "/api/log_analysis/get_live_streams_status"
  );
  // const fetchData = dummyData;
  // console.log("fetchData", fetchData);
  // stop loading once you have all the necessary data
  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);

  if (fetchData) {
    // update global store with newly fetched data
    useGlobalStore
      .getState()
      .setWidgetData(widgetId, fetchData.data);
  }
};

const refreshLogMonitorTable = (widgetId) => {
  fetchWidgetData(widgetId);
};

// common handler for various menu options (terminate)
export const contextMenuHandler = async (type, identifier, widgetId, reportName, status = "failed") => {
  // based on type change the endpoint
  const endpoint = endpointDict[type];

  const url =
    useConfigStore.getState().configData.rest_server_url +
    `/api/log_analysis/${endpoint}`;

  // based on type, change payload
  const payload = type === 'terminate' ? { identifier } : { identifier, status };
  const apiResponse = await axios
    .post(url, payload)
    .then((response) => {
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response.data;
        // mind the refresh !!
        refreshLogMonitorTable(widgetId);
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        showToast({
          reportName: reportName,
          widgetId: widgetId,
          severity: "error",
          message: toastMsg,
        }, widgetId);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in executing the task";
      showToast({
        reportName: reportName,
        widgetId: widgetId,
        severity: "error",
        message: message,
      }, widgetId);
    });
  return apiResponse;
};


export default refreshLogMonitorTable;
