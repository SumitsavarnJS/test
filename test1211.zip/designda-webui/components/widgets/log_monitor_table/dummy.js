export const dummyData = {
  success: true,
  data: {
    queued: [
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705567740",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705567740",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705556352",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705556352",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705554345",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705554345",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705555889",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705555889",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705556095",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705556095",
      },
    ],
    hung: [
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705559750",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705559750",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705559802",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705559802",
      },
    ],
    unavailable: [
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705560777",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705560777",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705560829",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705560829",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705567687",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705567687",
      },
    ],
    finished: [
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705556545",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705556545",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705557736",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705557736",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705557426",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705557426",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705570328",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705570328",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705570378",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705570378",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705641096",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705641096",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705641149",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705641149",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705571496",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705571496",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705572760",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705572760",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705572811",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705572811",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705667697",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705667697",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705666600",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705666600",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705657139",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705657139",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705657191",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705657191",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705668192",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705668192",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705668243",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705668243",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705666535",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705666535",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705668036",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705668036",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705902846",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705902846",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705902897",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705902897",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705919066",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705919066",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705904913",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705904913",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705904962",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705904962",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705918981",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705918981",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705932757",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705932757",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705932809",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705932809",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705935948",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705935948",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705936000",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705936000",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705940422",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705940422",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705940479",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705940479",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705988652",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705988652",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705989877",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705989877",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705988602",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705988602",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706090222",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706090222",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705989821",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705989821",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706071300",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706071300",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706071351",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706071351",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706103098",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706103098",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706072999",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706072999",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706073049",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706073049",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706092198",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706092198",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706097095",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706097095",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706090155",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706090155",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706092264",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706092264",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706098296",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706098296",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706103158",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706103158",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706097025",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706097025",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706098361",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706098361",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706105938",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706105938",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706106041",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706106041",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706109103",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706109103",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706107571",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706107571",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706107426",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706107426",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706109013",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706109013",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1706174623",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1706174623",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1706174684",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1706174684",
      },
    ],
    failed: [
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705558233",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705558233",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705558285",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705558285",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/init_design/1705558641",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_init_design_SEP_1705558641",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705558692",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705558692",
      },
      {
        task: "public/mpiyush/dhm/base/event_detection_test/compile/1705571547",
        identifier:
          "fc_shell_SEP_mpiyush_SEP_public_SEP_dhm_SEP_base_SEP_event_detection_test_SEP_compile_SEP_1705571547",
      },
    ],
  },
  message: "",
};
