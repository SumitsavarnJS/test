import React from "react";

import Config from "./Config";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";

import styles from "./GenericChartsV1.module.css";
import { Typography } from "@mui/material";

import ErrorCatch from "./ErrorCatch";

const GenericChartsV1 = (props) => {
  const { updateConfig, setWidgetUiState } = useGlobalStore();

  // Function to update config
  const updateWidgetConfig = (config, save) => {
    const nextUiState = {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    };

    if (save) {
      updateConfig(props.rptType, props.reportKey, props.id, config);
      nextUiState.isLoading = true;
    }

    setWidgetUiState(props.id, nextUiState);
  };
  const getChart = () => {
    return <ErrorCatch widgetProps={props.widgetProps} id={props.id} />;
  };

  const getContainer = () => {
    const uiState = _.get(useGlobalStore.getState()[props.id], "uiState", {
      showConfig: false,
    });

    let background = "white";
    if (useConfigStore.getState().theme === "dark") {
      background = "#100c2a";
    }

    if (uiState.showConfig) {
      return (
        <Config
          updateWidgetConfig={updateWidgetConfig}
          id={props.id}
          reportKey={props.reportKey}
          rptType={props.rptType}
          config={props.widgetProps.config}
        />
      );
    } else {
      return Object.keys(_.get(useGlobalStore.getState()[props.id], "data", {}))
        .length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <div
          id="GenericCharts"
          style={{ background: background, height: "100%", width: "100%" }}
        >
          {getChart()}
        </div>
      );
    }
  };

  return getContainer();
};

export default GenericChartsV1;
