import React, { useEffect, useRef } from "react";
import ReactECharts from "echarts-for-react";
import * as echarts from "echarts";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";

import styles from "./Charts.module.css";

const Charts = (props) => {
  const getChart = () => {
    return (
      <ReactECharts
        option={_.get(
          useGlobalStore.getState()[props.id],
          ["data", "data", "options"],
          {}
        )}
        style={{
          height: "100%",
          width: "100%",
        }}
        theme={_.get(
          useGlobalStore.getState()[props.id],
          ["data", "data", "theme"],
          "light"
        )}
        notMerge={true}
      />
    );
  };

  return getChart();
};

export default Charts;
