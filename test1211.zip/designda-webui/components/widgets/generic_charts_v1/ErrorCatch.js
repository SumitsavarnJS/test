import React from "react";

import Charts from "./Charts";

class ErrorCatch extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  componentDidCatch(error, errorInfo) {
    console.log(
      ">>>>>>>>>>>>>>>>>>>>>>>>>>>  Generic Charts Widget Error ",
      error
    );
    console.log(
      ">>>>>>>>>>>>>>>>>>>>>>>>>>> Generic Charts ErrorInfo",
      errorInfo
    );
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div>
          <p>
            Widget chart could not process the data. Please reconfigure the widget
          </p>
        </div>
      );
    }
    return <Charts widgetProps={this.props.widgetProps} id={this.props.id} />;
  }
}

export default ErrorCatch;
