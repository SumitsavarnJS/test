/* eslint-disable*/
import React from "react";
import { CircularProgress, Button, Typography, TextField } from "@mui/material";
import TerminalEditor from "../../terminal_editor/TerminalEditor";
import interactiveWidgetApi from "../../../common/api/interactiveWidgetApi";
import refreshGenericChartV1 from "./GenericChartsV1Apis";
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import PlayCircleOutlineOutlinedIcon from "@mui/icons-material/PlayCircleOutlineOutlined";
import TableViewIcon from "@mui/icons-material/TableView";

// utility imprts
import _ from "lodash";
import styles from "./Config.module.css";
import * as utils from "../../../common/utils/utils";
import dynamic from "next/dynamic";

const AceEditor = dynamic(
  () =>
    import("../../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);

const defaultQueryBody = `# Invoke the cli object to query data and assign required data to 'data' variable with key 'options' for chart ,
# theme in 'theme' key (light/infographic/macarons/roma/vintage/essos/shine/wonderland/dark/purple-passion) 
# Example : data = {{"options": <chartOptions>: "theme": <theme> }}

`;

class Config extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: _.get(this.props.config, "title", ""),
      apiResponse: {},
      showTerminalComponent: true,
      isExecuting: false,
    };
    this.query = _.get(this.props.config, "query", defaultQueryBody);
  }

  componentDidMount() {
    // refresh data list if data location is present
    if (this.state.dataLocation) {
      this.dataLocationChanged(this.state.dataLocation, this.state.bucket);
    }
  }

  handleDataChange = (newData) => {
    if (newData) {
      this.setState({
        dataHelperText: "",
        dataErrorFlag: false,
      });
      this.dataChanged(newData);
    }
  };

  onQueryChange = (newQuery) => {
    this.query = newQuery;
  };

  onExec = async () => {
    try {
      this.setState({
        isExecuting: true,
      });
      const config = {};
      config["query"] = this.query;

      // add title only if user has provided it
      if (this.state.title.length > 0) {
        config["title"] = this.state.title;
      }
      // this.props.updateWidgetConfig(config, true, "execute");
      const input = {
        raw_query: config["query"],
        variables:
          useGlobalStore.getState()[this.props.rptType][this.props.reportKey]
            .variables,
        user: `${useConfigStore.getState().authLoginUser}`,
      };
      const fetchData = await interactiveWidgetApi(
        useConfigStore.getState().configData.rest_server_url +
          "/cli/exec_query",
        input
      );
      if (fetchData) {
        this.setState({ apiResponse: fetchData });
        this.setState({ showTerminalComponent: true });
      }
    } catch (err) {
      console.error(
        "Something went wrong in executing Generic Chart View Query! of title ",
        this.state.title
      );
    } finally {
      this.setState({
        isExecuting: false,
      });
    }
  };

  onGenerateChart = () => {
    const variables =
      useGlobalStore.getState()[this.props.rptType][this.props.reportKey]
        .variables;
    const config = {};
    config["query"] = this.query;
    if (this.state.title.length > 0) {
      config["title"] = this.state.title;
    }
    this.props.updateWidgetConfig(config, true);
    refreshGenericChartV1(this.props.id, config, variables);
  };

  render() {
    return (
      <div className={styles.outer_div}>
        <div>
          <TextField
            fullWidth
            label="Title"
            size="small"
            value={this.state.title}
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(event) => {
              this.setState({ title: event.target.value });
            }}
            variant="outlined"
          />
        </div>

        {/* Select Data Source */}
        <div className={styles.inline}></div>

        {/* Code editor */}
        <Typography variant="subtitle1" className={styles.label}>
          Query Editor
        </Typography>

        <AceEditor
          placeholder="Please modify df object depending on the query."
          mode="python"
          theme="xcode"
          name="code_editor"
          width="100%"
          // onLoad={this.onLoad}
          onChange={(value, event) => {
            this.onQueryChange(value);
          }}
          fontSize={16}
          maxLines={Infinity}
          showPrintMargin={true}
          showGutter={true}
          highlightActiveLine={true}
          value={this.query}
          setOptions={{
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: true,
            enableSnippets: false,
            showLineNumbers: true,
            tabSize: 2,
          }}
        />
        <br />
        {/* <VariableComponent
          locVar={this.state.wVariables}
          updateLocVariable={this.updateLocVariable}
        /> */}

        <div className={styles.widgetButtonContainer}>
          <Button
            variant="contained"
            size="small"
            onClick={this.onGenerateChart}
            classes={{ root: styles.save_button }}
            startIcon={<TableViewIcon />}
          >
            Generate Chart
          </Button>
          <Button
            variant="outlined"
            size="small"
            onClick={() => {
              this.props.updateWidgetConfig({}, false);
            }}
          >
            Cancel
          </Button>

          <Button
            variant="contained"
            size="small"
            onClick={this.onExec}
            classes={{ root: styles.exec_button }}
            disabled={this.state.isExecuting}
            startIcon={
              this.state.isExecuting ? (
                <CircularProgress sx={{ color: "#333" }} size={15} />
              ) : (
                <PlayCircleOutlineOutlinedIcon />
              )
            }
          >
            {this.state.isExecuting ? "Executing ..." : "Execute Query"}
          </Button>
        </div>

        <br />

        {this.state.showTerminalComponent ? (
          <>
            <strong>Output:</strong>
            <TerminalEditor response={this.state.apiResponse} />
          </>
        ) : (
          <></>
        )}
      </div>
    );
  }
}

export default Config;
