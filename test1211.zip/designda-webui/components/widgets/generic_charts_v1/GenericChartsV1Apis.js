import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { produce } from "immer";
// import { toast } from "react-toastify";
import api from "../../../common/api/api";

const uiState = {
  isLoading: false,
  showConfig: false,
  isToastOpen: false,
  toastSeverity: "info",
  toastMessage: "",
  cirlularLoading: false,
};

const getGenericChartV1Payload = (config, variables) => {
  const payload = {
    rawQuery: _.get(config, "query", ""),
    auth: { user: `${useConfigStore.getState().authLoginUser}` },
    variables: variables ? variables : {},
    output: ["data"],
  };
  return payload;
};

const fetchWidgetData = async (widgetId, payload) => {
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  // api call to get scatter plot data
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/metrics/computeVariables",
    payload
  );
  const { status, message } = fetchData;

  //  show error toast if fetchData->status is false
  let newUiState = {};
  if (!status) {
    newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.toastMessage = message;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastSeverity = "error";
    });
  } else {
    newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
  }

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (fetchData && fetchData.result && Object.keys(fetchData.result).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.result);
  }
};

const refreshGenericChartV1 = (widgetId, config, variables) => {
  fetchWidgetData(widgetId, getGenericChartV1Payload(config, variables));
};

export default refreshGenericChartV1;
