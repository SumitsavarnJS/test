// react imports
import React, { useState, useEffect, useMemo } from "react";
import { Menu, MenuItem, Snackbar, Stack, Typography } from "@mui/material";
import ReactEcharts from "echarts-for-react";
import Config from "./Config";
// import { produce } from "immer";
import useGlobalStore from "../../../store/useGlobalStore";
import styles from "./GraphChart.module.css";
import {
  showInIcc2,
  showMultiStageTimingTable,
  showMultiStageTimingGraph,
  addHeatmapLayoutWidget,
  addTimingLayoutWidget,
  addTimingPathSummaryWidget,
  addDataPathDetailsWidget,
  addClockPathDetailsWidget,
} from "./GraphChartApi";
import clipboardCopy from "clipboard-copy";
import _ from "lodash";

const GraphChart = (props) => {
  // component constants
  const widgetId = props.id;
  const widgetStoreData = useGlobalStore.getState()[widgetId];
  const isGraphWidgetLoading = widgetStoreData.uiState.cirlularLoading;

  const [graphData, setGraphData] = useState({});
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [dataType, setDataType] = useState("");
  const [isContextMenuOpen, setContextMenuOpen] = useState(false);
  const [tooltipContent, setTooltipContent] = useState("");
  const [clickedTimingPath, setClickedTimingPath] = useState("");
  const [clickedNodeList, setClickedNodeList] = useState([]);
  const [menuOptions, setMenuOptions] = useState([
    "Show Clock Path Details",
    "Show Data Path Details",
    "Show Timing Path Summary",
    "Show in Layout",
    "Show in Layout with Heatmap",
    "Show in icc2/fc",
    "Show Multistage Timing Table",
    "Show Multistage Timing Graph",
  ]);

  // declare constants here:
  // order of hex codes is important !!DO NOT CHANGE!!
  const positiveColors = [
    "#FFFF00", // yellow
    "#ADFF2F", // greenish yellow
    "#00FF00", // light green
    "#008000", // green
    "#006400", // dark green
  ];
  const negativeColors = [
    "#8B0000", // dark red
    "#FF0000", // red
    "#FA5B3E", // light red
    "#FA8072", // salmon red
    "#F58522", // orange
  ];

  const dataFromProps = widgetStoreData?.data?.data;
  const payloadFromProps = widgetStoreData?.data?.payload;
  // console.log({ dataFromProps, payloadFromProps });

  const uiState = _.get(useGlobalStore.getState()[props.id], "uiState", {
    showConfig: false,
  });

  useEffect(() => {
    // if data exists
    if (dataFromProps && Object.keys(dataFromProps).length > 0) {
      // update style of the edge/link that corresponds to the timing path created [highlight]
      const copyOfData = { ...dataFromProps };
      const link_ = copyOfData.links.map((link) =>
        link.value.timing_path === payloadFromProps.request.timing_path
          ? { ...link, lineStyle: { width: 5, type: "dashed" } }
          : link
      );
      // set graph data state
      const graphData = {
        ...copyOfData,
        links: link_,
      };
      setGraphData(graphData);
      // remove the item. "Show Clock Path Details", if isPre_cts is true
      if (payloadFromProps.isPre_cts) {
        const newMenuOptions = [...menuOptions];
        setMenuOptions(
          newMenuOptions.filter((item) => item !== "Show Clock Path Details")
        );
      }
    }
  }, [dataFromProps]);

  // as component mounts, find the parent div for the graph-chart widget and
  // disable right click on that div
  useEffect(() => {
    const widgetDiv = document.getElementById("graphChart");
    if (widgetDiv) {
      widgetDiv.addEventListener("contextmenu", (e) => {
        e.preventDefault();
      });
    }
  }, []);

  // Function to update config
  const updateConfig = (config, save) => {
    // if user has refreshed, save the data in store
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(props.rptType, props.reportKey, widgetId, config);
    }

    useGlobalStore.getState().setWidgetUiState(widgetId, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  // method to map slack to a certain color
  const mapSlackToColor = (slack, minSlack, maxSlack) => {
    const colorsRange = slack >= 0 ? positiveColors : negativeColors;
    const normalizedSlack = Math.max(minSlack, Math.min(maxSlack, slack));
    const colorIndex = Math.floor(
      (normalizedSlack - minSlack) /
        ((maxSlack - minSlack) / (colorsRange.length - 1))
    );
    // console.log({normalizedSlack, colorIndex})
    return colorsRange[colorIndex];
  };

  const getEchartsOption = (graph) => {
    const newNodes = graph.nodes.map((obj) => {
      return {
        ...obj,
        // if user clicks on a node, shrink its size to 1
        symbolSize: clickedNodeList.includes(obj.value) ? 1 : 10,
        // adding transparency to nodes
        itemStyle: { color: "rgba(34, 99, 201, 0.4)" },
      };
    });

    const newEdges = graph.links.map((obj) => {
      // update only the color for link, rest properties remain intact
      return {
        ...obj,
        lineStyle: {
          ...obj.lineStyle,
          color: mapSlackToColor(
            obj.slack,
            graphData.minSlack,
            graphData.maxSlack
          ),
        },
      };
    });
    const option = {
      title: {
        // text: "Timing Path",
        // // subtext: "Default layout",
        // top: "bottom",
        // left: "right",
      },
      tooltip: {
        responsive: true,
        // backgroundColor: "rgba(247, 227, 250, 0.5)",
        // show: true,
        // trigger: "axis",
        // axisPointer: {
        //   type: 'cross',
        // },
        // showContent: true,
        // formatter: params => {
        //   console.log({params})
        // },
        formatter: function (params) {
          // console.log("from tooltip", { params });
          // params.dataType is node OR edge
          const value = params?.data?.value;
          const dataType = params?.dataType;
          let res = "";
          if (dataType === "node") {
            const Xval = params?.data?.x;
            const Yval = params?.data?.y;
            res =
              `<p>Node: <strong>${value}</strong></p>` +
              `<table><tr><td>X co-ordinate &nbsp;</td><td><b>${Xval}</b></td></tr>` +
              `<tr><td>Y co-ordinate &nbsp;</td><td><b>${Yval}</b></td></tr></table>` +
              "<br/>" +
              "<strong>Click this node to copy its content</strong>" +
              "<br/>" +
              "<strong>Right-click this node to shrink its size</strong>";
            return res;
          } else {
            // dataType is edge
            if (value) {
              const {
                timing_path,
                clock_skew,
                total_cell_delay,
                total_net_delay,
                total_crosstalk_delay,
                total_buff_inv_delay,
                clock_uncertainty,
                path_category,
              } = value;
              const slackVal = params?.data?.slack;

              res =
                `<p>Timing Path: <strong>${timing_path}</strong></p>` +
                `<table><tr><td>clock_skew &nbsp;</td><td><b>${clock_skew}</b></td></tr>` +
                `<tr><td>total_cell_delay &nbsp;</td><td><b>${total_cell_delay}</b></td></tr>` +
                `<tr><td>total_net_delay &nbsp;</td><td><b>${total_net_delay}</b></td></tr>` +
                `<tr><td>total_crosstalk_delay &nbsp;</td><td><b>${total_crosstalk_delay}</b></td></tr>` +
                `<tr><td>total_buff_inv_delay &nbsp;</td><td><b>${total_buff_inv_delay}</b></td></tr>` +
                `<tr><td>clock_uncertainty &nbsp;</td><td><b>${clock_uncertainty}</b></td></tr>` +
                `<tr><td>path_category &nbsp;</td><td><b>${path_category}</b></td></tr>` +
                `<tr><td>slack &nbsp;</td><td><b>${slackVal}</b></td></tr></table>` +
                "<br/>" +
                "<strong>Click this edge to copy its content</strong>";
            }

            return res;
          }
        },
      },
      animationDuration: 800,
      animationEasingUpdate: "quinticInOut",
      series: [
        {
          type: "graph",
          layout: "none",
          data: newNodes,
          links: newEdges,
          // categories: graph.categories,
          // edgeSymbolSize: 100,
          edgeSymbol: ["circle", "arrow"],
          edgeSymbolSize: [4, 11],
          roam: true,
          nodeScaleRatio: 0, // prevent node from scaling on zoom in and zoom out
          // label: {
          //   show: false,
          // },
          lineStyle: {
            curveness: 0,
            type: "solid",
            // color: "#000",
            width: 2,
          },
          // emphasis for hover
          emphasis: {
            focus: "adjacency",
            lineStyle: {
              width: 7,
            },
            label: {
              // position: "right",
              show: false,
            },
          },
        },
      ],
    };
    return option;
  };

  // memoize handler to prevent re-render
  const onContextMenuHandler = useMemo(
    () => (params) => {
      // data here is dege
      const value = params?.data?.value;
      const dataType = params?.dataType;
      const timingPathValue = value?.timing_path;
      // if edge is clicked, show context menu
      if (dataType === "edge") {
        // show context menu for task data only
        const mousePos = {
          x: params.event.event.pageX,
          y: params.event.event.pageY,
        };
        setClickedTimingPath(timingPathValue);
        setMousePosition(mousePos);
        setContextMenuOpen(true);
      }
      // if node is clicked, store the nodes name/value
      else if (dataType === "node") {
        // update the clicked node array -> for every clicked node, size gets smaller
        setClickedNodeList(clickedNodeList => [...clickedNodeList, value]);
      }
    },
    []
  );

  const onContextMenuClose = () => {
    setContextMenuOpen(false);
  };

  // memoize handler to prevent re-render
  const onGraphClick = useMemo(
    () => async (params) => {
      const value = params?.data?.value;
      const dataType = params?.dataType;
      let res = "";
      if (dataType === "node") {
        setDataType("node");
        const Xval = params?.data?.x;
        const Yval = params?.data?.y;
        res = `X: ${Xval}, Y: ${Yval}, Value: ${value}`;
      } else {
        // dataType is edge
        setDataType("edge");
        if (value) {
          const {
            timing_path,
            clock_skew,
            total_cell_delay,
            total_net_delay,
            total_crosstalk_delay,
            total_buff_inv_delay,
            clock_uncertainty,
            path_category,
          } = value;
          const slackVal = params?.data?.slack;
          res = `timing_path: ${timing_path}, clock_skew: ${clock_skew}, total_cell_delay: ${total_cell_delay}, total_net_delay: ${total_net_delay}, total_crosstalk_delay: ${total_crosstalk_delay}, total_buff_inv_delay: ${total_buff_inv_delay}, clock_uncertainty: ${clock_uncertainty}, path_category: ${path_category}, slack: ${slackVal}`;
        }
      }
      setTooltipContent(res);
      // copy the content
      await clipboardCopy(res);
    },
    []
  );

  // using memoization to prevent default reset of component
  // each handler is ALSO memoized
  const eventDict = useMemo(
    () => ({
      contextmenu: onContextMenuHandler,
      click: onGraphClick,
    }),
    [onContextMenuHandler, onGraphClick]
  );

  const onClickMenuOption = (name) => {
    // logic here
    setContextMenuOpen(false);
    switch (name) {
      case "Show Clock Path Details":
        addClockPathDetailsWidget(
          widgetId,
          payloadFromProps.request,
          payloadFromProps.row,
          payloadFromProps.allProps,
          clickedTimingPath,
          props.index,
          payloadFromProps.yCoord
        );
        break;
      case "Show Data Path Details":
        addDataPathDetailsWidget(
          widgetId,
          payloadFromProps.request,
          payloadFromProps.row,
          payloadFromProps.allProps,
          clickedTimingPath,
          props.index,
          payloadFromProps.yCoord
        );
        break;
      case "Show Timing Path Summary":
        addTimingPathSummaryWidget(
          widgetId,
          payloadFromProps.request,
          payloadFromProps.row,
          payloadFromProps.allProps,
          clickedTimingPath,
          props.index,
          payloadFromProps.yCoord
        );
        break;
      case "Show in Layout":
        addTimingLayoutWidget(
          widgetId,
          payloadFromProps.request,
          payloadFromProps.row,
          payloadFromProps.allProps,
          clickedTimingPath,
          props.index,
          payloadFromProps.yCoord
        );
        break;
      case "Show in Layout with Heatmap":
        addHeatmapLayoutWidget(
          widgetId,
          payloadFromProps.request,
          payloadFromProps.row,
          payloadFromProps.allProps,
          clickedTimingPath,
          props.index,
          payloadFromProps.yCoord
        );
        break;
      case "Show in icc2/fc":
        showInIcc2(
          widgetId,
          payloadFromProps.request,
          payloadFromProps.row,
          payloadFromProps.allProps,
          clickedTimingPath
        );
        break;
      case "Show Multistage Timing Table":
        showMultiStageTimingTable(
          widgetId,
          payloadFromProps.request,
          payloadFromProps.row,
          payloadFromProps.allProps,
          clickedTimingPath,
          props.index,
          payloadFromProps.yCoord
        );
        break;
      case "Show Multistage Timing Graph":
        showMultiStageTimingGraph(
          widgetId,
          payloadFromProps.request,
          payloadFromProps.row,
          payloadFromProps.allProps,
          payloadFromProps.isPre_cts,
          clickedTimingPath,
          props.index,
          payloadFromProps.yCoord
        );
        break;
    }
  };

  const onCloseSnack = () => setTooltipContent("");
  // render components (React tabulator) conditionally depending on data
  return (
    <>
      {uiState.showConfig ? (
        <Config
          updateConfig={updateConfig}
          config={props.config}
          id={widgetId}
        />
      ) : graphData && Object.keys(graphData).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          Sorry! This widget is currently not designed to reload data
        </Typography>
      ) : (
        // using prevent-default on the div to make sure browser default context-menu does not appear on Dashboard
        <div
          className={styles.chartParent}
          id="graphChart"
          onContextMenu={(e) => e.preventDefault()}
        >
          {/* get the graph chart component here */}
          <div>
            <div className={styles.legendHeader}>
              Selected Timing Path is represented by a&nbsp;
              <strong>dashed</strong>&nbsp;line
            </div>
            <div className={styles.flexBoxLegend}>
              <div className={styles.legendName}>Most Negative Slack</div>
              <div className={styles.slackRange}></div>
              <div className={styles.legendName}>Most Positive Slack</div>
            </div>
          </div>
          <ReactEcharts
            onEvents={eventDict}
            style={{
              height: "100%",
              width: "100%",
              position: "relative",
              pointerEvents: isGraphWidgetLoading ? "none" : "auto",
            }}
            option={getEchartsOption(graphData)}
          />

          {/* if graph view is loading, show overlay text */}
          {isGraphWidgetLoading ? (
            <div className={styles.loadingTableOverlay}>
              <div className={styles.loadingText}>Fetching Data ...</div>
            </div>
          ) : (
            <></>
          )}
          {/* snack for successful copy to clipboard */}
          {tooltipContent && tooltipContent.length > 0 ? (
            <Snackbar
              open={tooltipContent.length > 0}
              className={styles.snackbar}
              style={{ position: "absolute" }}
              anchorOrigin={{ vertical: "top", horizontal: "right" }}
              autoHideDuration={3000}
              onClose={onCloseSnack}
              message={`Copied ${dataType} content to clipboard !`}
            />
          ) : (
            <></>
          )}
          {/* context-menu */}
          <Menu
            anchorReference="anchorPosition"
            anchorPosition={{
              top: mousePosition.y,
              left: mousePosition.x,
            }}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
            variant="menu"
            keepMounted
            open={isContextMenuOpen}
            style={{ display: "block" }}
            onClose={onContextMenuClose}
          >
            <Stack>
              <div style={{ padding: "0 15px" }}>
                For Timing Path : {clickedTimingPath}
              </div>
              <hr />
              {menuOptions.length > 0 &&
                menuOptions.map((optionName) => (
                  <MenuItem key={optionName} onClick={() => onClickMenuOption(optionName)}>
                    {optionName}
                  </MenuItem>
                ))}
            </Stack>
          </Menu>
        </div>
      )}
    </>
  );
};

export default GraphChart;

GraphChart.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
