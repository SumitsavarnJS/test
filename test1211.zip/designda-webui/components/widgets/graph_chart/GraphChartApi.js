import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { showToast, setLoading } from "./Config";
import { produce } from "immer";
// import { toast } from "react-toastify";
// import api from "../../../common/api/api";
import axios from "axios";
// import { graphData } from "./dummydata";
import {
  addWidgetCommonFunction,
  showConfigUiState,
  showWidgetDataUiState,
  widgets,
} from "../../../pages/rptdashboard/addWidget/addWidget";

const colors = [
  "c47541",
  "107896",
  "829356",
  "bca136",
  "c2571a",
  "e28743",
  "76b5c5",
  "873e23",
  "34eb4f",
  "34ebdf",
];

const addWidgets = (props, allProps, currPropsIndex) => {
  for (let i = 0; i < props.widgets.length; i++) {
    const widgetsSettings = produce(props.widgets[i], (settingsDraft) => {
      delete settingsDraft.currentReportName;
      delete settingsDraft.data;
    });

    const data = _.get(props.widgets[i], "data", {});

    addWidgetCommonFunction(
      allProps.rptType,
      allProps.reportKey,
      widgetsSettings,
      data,
      showWidgetDataUiState,
      currPropsIndex
    );
  }
};

// method to copy to clipboard
const copyToClipboard = () => {
  const copyStr = localStorage.getItem("cell")
    ? JSON.parse(localStorage.getItem("cell"))
    : {};
  // if it is a secured connection (https) then it will write it to sytem clipboard directly
  if (window.isSecureContext && navigator.clipboard !== undefined) {
    navigator.clipboard.writeText(copyStr);
  }

  //otherwise it will copy to web ui clipboard
  else {
    var textarea = document.createElement("textarea");
    textarea.textContent = copyStr;
    document.body.appendChild(textarea);

    var selection = document.getSelection();
    var range = document.createRange();

    range.selectNode(textarea);
    selection.removeAllRanges();
    selection.addRange(range);

    document.execCommand("copy");
    selection.removeAllRanges();

    document.body.removeChild(textarea);
  }
};

const addLaunchClockDetailsWidget = (
  row,
  timing_path,
  stpt,
  stpt_type,
  ept,
  ept_type,
  stpt_clk,
  ept_clk,
  tColor,
  allProps,
  currPropsIndex,
  yCoordVal,
  widgetId
) => {
  const config = allProps.widgetProps.config;

  if (row == null) return;

  let _stpt = stpt_type != "in" ? stpt : "";
  let _ept = ept_type != "out" ? ept : "";

  if (_stpt == "") {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "info",
      message: "Launch clock path Does not exist",
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    )
    return;
  }

  const request = {
    timing_path: timing_path,
    start_point: _stpt,
    end_point: _ept,
    start_point_clock: stpt_clk,
    end_point_clock: ept_clk,
    bucket: config.bucket,
    key: config.dataLocation,
    ttype: row.data.__ttype ? row.data.__ttype : "max",
    scenario: row.data.__object
      ? row.data.__object.split("/")[0]
      : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_launch_clock_details",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const data = _.get(response, "data", {});
      const colors = _.get(data, "colors", {});
      const dataLocation = _.get(data, "dataLocation", "");
      const bucket = _.get(data, "bucket", "");
      const cache_key = _.get(response, "cache_key", "");
      const scenario = _.get(data, "scenario", "");
      const column_list = _.get(data, "column_list", []);
      const version = _.get(response, "version", "1");
      const v1_default_columns = [
        "object_level",
        "object_name",
        "object_type",
        "cell_delay_launch",
        "net_delay_launch",
        "transition_launch",
      ];
      const v2_default_columns = [
        "s_no",
        "obj_name",
        "obj_ref_name",
        "delay",
        "obj_type",
      ];

      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        // get y coord and height of current widget
        const yCoord = yCoordVal;
        // add table view widget below
        addWidgets(
          {
            widgets: [
              {
                name: "Timing Path Details",
                reportName: allProps.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Launch Clock Details for ${_stpt}`,
                  title_color: "#" + tColor,
                  dataLocation: dataLocation,
                  bucket: bucket,
                  cache_key: cache_key,
                  colors: colors,
                  scenario: scenario,
                  column_list: column_list,
                  // persistence: {
                  //   columns: true,
                  // },
                  columns:
                    version === "2" ? v2_default_columns : v1_default_columns,
                },
                data: data,
              },
            ],
          },
          allProps,
          currPropsIndex
        );
      }
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch Launch clock Details",
      });
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

const addCaptureClockDetailsWidget = (
  row,
  timing_path,
  stpt,
  stpt_type,
  ept,
  ept_type,
  stpt_clk,
  ept_clk,
  tColor,
  allProps,
  currPropsIndex,
  yCoordVal,
  widgetId
) => {
  const config = allProps.widgetProps.config;

  if (row == null) return;

  let _stpt = stpt_type != "in" ? stpt : "";
  let _ept = ept_type != "out" ? ept : "";

  if (_ept == "") {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "info",
      message: "Capture clock path Does not exist",
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    )
    return;
  }

  const request = {
    timing_path: timing_path,
    start_point: _stpt,
    end_point: _ept,
    start_point_clock: stpt_clk,
    end_point_clock: ept_clk,
    bucket: config.bucket,
    key: config.dataLocation,
    ttype: row.data.__ttype ? row.data.__ttype : "max",
    scenario: row.data.__object
      ? row.data.__object.split("/")[0]
      : _.get(config, "dataLocation", "").split("/").slice(-1).toString(),
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_capture_clock_details",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const data = _.get(response, "data", {});
      const colors = _.get(data, "colors", {});
      const dataLocation = _.get(data, "dataLocation", "");
      const bucket = _.get(data, "bucket", "");
      const cache_key = _.get(response, "cache_key", "");
      const scenario = _.get(data, "scenario", "");
      const column_list = _.get(data, "column_list", []);
      const version = _.get(response, "version", "1");
      const v1_default_columns = [
        "object_level",
        "object_name",
        "object_type",
        "cell_delay_capture",
        "net_delay_capture",
        "transition_capture",
      ];
      const v2_default_columns = [
        "s_no",
        "obj_name",
        "obj_ref_name",
        "delay",
        "obj_type",
      ];

      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        // get y coord and height of current widget
        const yCoord = yCoordVal;
        // add table view widget below
        addWidgets(
          {
            widgets: [
              {
                name: "Timing Path Details",
                reportName: allProps.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Capture clock Details for ${_ept}`,
                  title_color: "#" + tColor,
                  dataLocation: dataLocation,
                  bucket: bucket,
                  cache_key: cache_key,
                  colors: colors,
                  scenario: scenario,
                  column_list: column_list,
                  columns:
                    version === "2" ? v2_default_columns : v1_default_columns,
                },
                data: data,
              },
            ],
          },
          allProps,
          currPropsIndex
        );
      }
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch Capture Clock Details",
      });
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

// method to add Clock Path Details Widget
export const addClockPathDetailsWidget = (
  widgetId,
  payload,
  row,
  allProps,
  timing_path,
  currPropsIndex,
  yCoordVal
) => {
  setLoading(
    {
      reportName: allProps.currentReportName,
      widgetId,
      cirlularLoading: true,
    },
    allProps
  );
  let i = 7;
  let randomColor = colors[i++];
  if (i == 10) i = 0;

  const config = allProps.widgetProps.config;
  let hold = false;
  if (
    row.data.__ttype == "min" ||
    config.data == "das_timing_path_min_data.ldb"
  ) {
    hold = true;
  }
  if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "error",
      message: '"timing_path" column not found / meta data not found',
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    );
    return;
  }
  // get_clock_path_meta_data
  const request = {
    ...payload,
    hold, //getting hold from above calculation
    timing_path,
    col: [
      "start_point_name",
      "start_point_object_type",
      "end_point_name",
      "end_point_object_type",
      "timing_path",
      "start_point_clock",
      "end_point_clock",
    ],
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_clock_path_meta_data",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const stpt = _.get(response, "start_point_name", "");
      const stpt_type = _.get(response, "start_point_object_type", "");
      const ept = _.get(response, "end_point_name", "");
      const ept_type = _.get(response, "end_point_object_type", "");
      const stpt_clk = _.get(response, "start_point_clock", "");
      const ept_clk = _.get(response, "end_point_clock", "");
      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      }
      if (stpt_type[0] == "in" && ept_type[0] == "out") {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "info",
          message: "Both Launch clock and Capture clock paths Does not exist",
        });
        setLoading(
          {
            reportName: allProps.currentReportName,
            widgetId,
            cirlularLoading: false,
          },
          allProps
        );
      } else {
        addLaunchClockDetailsWidget(
          row,
          timing_path,
          stpt[0],
          stpt_type[0],
          ept[0],
          ept_type[0],
          stpt_clk[0],
          ept_clk[0],
          randomColor,
          allProps,
          currPropsIndex,
          yCoordVal,
          widgetId
        );
        addCaptureClockDetailsWidget(
          row,
          timing_path,
          stpt[0],
          stpt_type[0],
          ept[0],
          ept_type[0],
          stpt_clk[0],
          ept_clk[0],
          randomColor,
          allProps,
          currPropsIndex,
          yCoordVal,
          widgetId
        );
      }
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch meta data for clock Details",
      });
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

// method to add Data Path Details widget
export const addDataPathDetailsWidget = (
  widgetId,
  payload,
  row,
  allProps,
  timing_path,
  currPropsIndex,
  yCoordVal
) => {
  setLoading(
    {
      reportName: allProps.currentReportName,
      widgetId,
      cirlularLoading: true,
    },
    allProps
  );

  const config = allProps.widgetProps.config;

  if (row == null) return;
  let hold = false;
  if (
    row.data.__ttype == "min" ||
    config.data == "das_timing_path_min_data.ldb"
  ) {
    hold = true;
  }

  if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "error",
      message: '"timing_path" column not found / meta data not found',
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    );
    return;
  }

  const request = {
    ...payload,
    hold, //getting hold from above calculation
    timing_path,
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_data_path_details",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const colors = _.get(response, "colors", {});
      const data = _.get(response, "data", {});
      const cache_key = _.get(response, "cache_key", "");
      const dataLocation = _.get(response, "dataLocation", "");
      const bucket = _.get(response, "bucket", "");
      const column_list = _.get(response, "column_list", []);
      const version = _.get(response, "version", "1");
      const v1_default_columns = [
        "point_id",
        "point_type",
        "point_name",
        "cell_ref_name",
        "fanout",
        "incr_delay",
        "path_delay",
      ];
      const v2_default_columns = [
        "s_no",
        "obj_name",
        "obj_ref_name",
        "delay",
        "obj_type",
      ];

      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        // get y coord and height of current widget
        const yCoord = yCoordVal;
        // add table view widget below
        addWidgets(
          {
            widgets: [
              {
                name: "Timing Path Details",
                reportName: allProps.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Data Path Details for ${timing_path}`,
                  dataLocation: dataLocation,
                  bucket: bucket,
                  cache_key: cache_key,
                  colors: colors,
                  column_list: column_list,
                  columns:
                    version === "2" ? v2_default_columns : v1_default_columns,
                },
                data: data,
              },
            ],
          },
          allProps,
          currPropsIndex
        );
      }
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch Data Path Details",
      });
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

// method to add Timing Path Summary widget
export const addTimingPathSummaryWidget = (
  widgetId,
  payload,
  row,
  allProps,
  timing_path,
  currPropsIndex,
  yCoordVal
) => {
  setLoading(
    {
      reportName: allProps.currentReportName,
      widgetId,
      cirlularLoading: true,
    },
    allProps
  );

  const config = allProps.widgetProps.config;

  if (row == null) return;

  let hold = false;
  if (
    row.data.__ttype == "min" ||
    config.data == "das_timing_path_min_data.ldb"
  ) {
    hold = true;
  }

  if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "error",
      message: '"timing_path" column not found / meta data not found',
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    );
    return;
  }

  const request = {
    ...payload,
    hold, //getting hold from above calculation
    timing_path,
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_timing_path_summary",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const data = _.get(response, "data", {});
      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        // get y coord and height of current widget
        const yCoord = yCoordVal;
        // add table view widget below
        addWidgets(
          {
            widgets: [
              {
                name: "Timing Path Summary",
                reportName: allProps.currentReportName, // important
                width: 20,
                height: 12,
                y: yCoord + 1,
                config: {
                  title: `Timing Path Summary for ${timing_path}`,
                },
                data: data,
              },
            ],
          },
          allProps,
          currPropsIndex
        );
      }
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch Timing Summary Data",
      });
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

// method to add Layout widget
export const addTimingLayoutWidget = (
  widgetId,
  payload,
  row,
  allProps,
  timing_path,
  currPropsIndex,
  yCoordVal
) => {
  setLoading(
    {
      reportName: allProps.currentReportName,
      widgetId,
      cirlularLoading: true,
    },
    allProps
  );

  const config = allProps.widgetProps.config;

  if (row == null) return;

  if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "error",
      message: 'Columns should have "timing_path" to fetch Layout View',
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    );
    return;
  }

  const request = {
    bucket: payload.bucket,
    key: payload.key,
    components: ["floorplan", "macros"],
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_task_layout",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const data = _.get(response, "data", {});
      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        if (message !== "No valid response from server") {
          showToast({
            reportName: allProps.currentReportName,
            widgetId,
            severity: "info",
            message: message,
          });
        }
        // get y coord and height of current widget
        const yCoord = yCoordVal;

        //add Layout view widget below
        addWidgets(
          {
            widgets: [
              {
                name: "Layout View",
                reportName: allProps.currentReportName, // important
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${_.get(
                    config,
                    "title",
                    "Timingpath "
                  )} ${timing_path}}`,
                  bucket: _.get(config, "bucket", ""),
                  timingpath: timing_path,
                  dataLocation: _.get(config, "dataLocation", ""),
                  scenario: row.data.__object
                    ? row.data.__object.split("/")[0]
                    : _.get(config, "dataLocation", "")
                        .split("/")
                        .slice(-1)
                        .toString(),
                  timingPathContainer: true,
                },
              },
            ],
          },
          allProps,
          currPropsIndex
        );
      }
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch Layout View Data",
      });
      console.log(error);
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

// method to add Heatmap Layout widget
export const addHeatmapLayoutWidget = (
  widgetId,
  payload,
  row,
  allProps,
  timing_path,
  currPropsIndex,
  yCoordVal
) => {
  setLoading(
    {
      reportName: allProps.currentReportName,
      widgetId,
      cirlularLoading: true,
    },
    allProps
  );

  const config = allProps.widgetProps.config;

  if (row == null) return;

  if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "error",
      message: 'Columns should have "timing_path" to fetch Layout View',
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    );
    return;
  }

  const request = {
    bucket: payload.bucket,
    key: payload.key,
    components: ["floorplan", "macros"],
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_task_layout",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const data = _.get(response, "data", {});
      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        if (message !== "No valid response from server") {
          showToast({
            reportName: allProps.currentReportName,
            widgetId,
            severity: "info",
            message: message,
          });
        }
        // get y coord and height of current widget
        const yCoord = yCoordVal;
        //add Layout view widget below
        addWidgets(
          {
            widgets: [
              {
                name: "Layout View",
                reportName: allProps.currentReportName,
                width: 19,
                height: 12.6,
                y: yCoord + 1,
                data: data,
                config: {
                  data: _.get(config, "data"),
                  title: `{${_.get(
                    config,
                    "title",
                    "Timingpath "
                  )} ${timing_path}}`,
                  bucket: _.get(config, "bucket", ""),
                  timingpath: timing_path,
                  dataLocation: _.get(config, "dataLocation", ""),
                  scenario: row.data.__object
                    ? row.data.__object.split("/")[0]
                    : _.get(config, "dataLocation", "")
                        .split("/")
                        .slice(-1)
                        .toString(),
                },
              },
            ],
          },
          allProps,
          currPropsIndex
        );
      }
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch Layout View Data",
      });
      console.log(error);
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

// method for show in Icc2
export const showInIcc2 = (widgetId, payload, row, allProps, timing_path) => {
  const config = allProps.widgetProps.config;

  if (row == null) return;
  let hold = false;
  if (
    row.data.__ttype == "min" ||
    config.data == "das_timing_path_min_data.ldb"
  ) {
    hold = true;
  }
  const request = {
    ...payload,
    hold, //getting hold from above calculation
    timing_path,
    col: ["timing_path", "start_point", "end_point"],
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_clock_path_meta_data",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const stpt = _.get(response, "start_point", "");
      const ept = _.get(response, "end_point", "");
      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        // string that needs to be copied
        let copyStr = `report_timing -from ${stpt[0]} -to ${ept[0]} -scenarios ${request.scenario}`;
        localStorage.setItem("cell", JSON.stringify(copyStr));
        copyToClipboard();
      }
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch showInIcc2 Details",
      });
    });
};

// method to add Multi Stage Timing Table
export const showMultiStageTimingTable = (
  widgetId,
  payload,
  row,
  allProps,
  timing_path,
  currPropsIndex,
  yCoordVal
) => {
  setLoading(
    {
      reportName: allProps.currentReportName,
      widgetId,
      cirlularLoading: true,
    },
    allProps
  );

  const config = allProps.widgetProps.config;

  if (row == null) return;

  let hold = false;
  if (
    row.data.__ttype == "min" ||
    config.data == "das_timing_path_min_data.ldb"
  ) {
    hold = true;
  }

  if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "error",
      message: '"timing_path" column not found / meta data not found',
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    );
    return;
  }
  const request = {
    ...payload,
    hold, //getting hold from above calculation
    timing_path,
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_multistage_timing_table",
      request
    )
    .then((response) => {
      response = response.data;
      const requestStatus = _.get(response, "status", false);
      const cache_key = _.get(response, "cache_key", {});
      const dataLocation = _.get(response, "dataLocation", "");
      const data = _.get(response, "file", {});
      const bucket = _.get(response, "bucket", {});
      const col = _.get(response, "columns", []);
      const columnsList = _.get(response, "columnsList", []);
      const rows = _.get(response, "rows", []);
      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        const yCoord = yCoordVal;
        // add TableView widget below
        addWidgets(
          {
            widgets: [
              {
                name: "Table View",
                reportName: allProps.currentReportName,
                width: 20,
                height: 12,
                y: yCoord + 2,
                config: {
                  title: `Multi Stage Timing Path for ${timing_path}`,
                  dataLocation: dataLocation,
                  data: data,
                  bucket: bucket,
                  query: "df = df.compute()", //query,
                  columns: columnsList,
                  cache_key: cache_key,
                },
                data: { rows: rows, columns: col },
              },
            ],
          },
          allProps,
          currPropsIndex
        );
      }
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch Multi Stage Timing Path Data",
      });
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

// method to add Multi Stage Timing Graph
export const showMultiStageTimingGraph = (
  widgetId,
  payload,
  row,
  allProps,
  isPre_cts,
  timing_path,
  currPropsIndex,
  yCoordVal
) => {
  setLoading(
    {
      reportName: allProps.currentReportName,
      widgetId,
      cirlularLoading: true,
    },
    allProps
  );

  const config = allProps.widgetProps.config;

  if (row == null) return;

  let hold = false;
  if (
    row.data.__ttype == "min" ||
    config.data == "das_timing_path_min_data.ldb"
  ) {
    hold = true;
  }

  if (!(row.data.__obtype == "timing_path") && !("timing_path" in row.data)) {
    showToast({
      reportName: allProps.currentReportName,
      widgetId,
      severity: "error",
      message: '"timing_path" column not found / meta data not found',
    });
    setLoading(
      {
        reportName: allProps.currentReportName,
        widgetId,
        cirlularLoading: false,
      },
      allProps
    );
    return;
  }

  const request = {
    ...payload,
    hold, //getting hold from above calculation
    timing_path,
  };

  axios
    .post(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/get_multistage_timing_graph",
      request
    )
    .then((response) => {
      response = response?.data;
      const graphData = _.get(response, "graph", {});
      const requestStatus = _.get(response, "status", false);
      const minSlack = _.get(response, "minSlack", 0);
      const maxSlack = _.get(response, "maxSlack", 100);
      const message = _.get(
        response,
        "message",
        "No valid response from server"
      );
      if (!requestStatus) {
        showToast({
          reportName: allProps.currentReportName,
          widgetId,
          severity: "error",
          message: message,
        });
      } else {
        const yCoord = yCoordVal;
        // add Graph Chart View widget below
        addWidgets(
          {
            widgets: [
              {
                name: "Graph Chart",
                reportName: allProps.currentReportName,
                width: 20,
                height: 12,
                y: yCoord + 1,
                // sending required data in 'data' so that its reflected in STORE
                data: {
                  data: { ...graphData, minSlack, maxSlack },
                  payload: {
                    request,
                    isPre_cts,
                    row,
                    allProps,
                    yCoord: yCoord + 1,
                  },
                },
                config: {
                  title: `Multi Stage Timing Graph for ${timing_path}`,
                },
              },
            ],
          },
          allProps,
          currPropsIndex
        );
      }
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    })
    .catch((error) => {
      showToast({
        reportName: allProps.currentReportName,
        widgetId,
        severity: "error",
        message: "Failed to fetch Multi Stage Timing Graph Data",
      });
      setLoading(
        {
          reportName: allProps.currentReportName,
          widgetId,
          cirlularLoading: false,
        },
        allProps
      );
    });
};

const refreshGraphChart = (widgetId, config) => {
  // refresh functionality is not required here as this chart comes from table view
  // fetchWidgetData(widgetId, config);
};

export default refreshGraphChart;
