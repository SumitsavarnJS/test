import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";

import _ from "lodash";

import { produce } from "immer";

import api from "../../../common/api/api";
import * as utils from "../../../common/utils/utils";

const getGroupBarChartInput = (config) => {
  const input = {
    bucket: _.get(config, "bucket", ""),
    cache_key: _.get(config, "cache_key", ""),
    key: _.get(config, "dataLocation", ""),
    ldb_file: _.get(config, "data", ""),
    raw_query: _.get(config, "query", ""),
    user: `${useConfigStore.getState().authLoginUser}`,
  };
  const scenario = utils.getScenarioFromDataLoc(input.key);
  // updating raw_query to have __scenario, __columns, __data
  input.raw_query =
    `__scenario, __columns, __data = '${scenario}', ${JSON.stringify(
      _.get(config, "columns", [])
    )}, '${_.get(config, "data", "")}'\n` + input.raw_query;

  // add columns if provided
  const columns = _.get(config, "columns", []);
  if (columns.length > 0) {
    input["columns"] = config.columns;
  }

  // if data was stacked
  if (config.stack) {
    input["stack"] = _.get(config, "stack", "");
  }

  // get series type
  input["series_type"] = _.get(config, "series_type", "bar");

  if (_.get(config, "groupingAxis", "Y") === "Y") {
    input["chart_type"] = "bar_line";
  } else {
    input["chart_type"] = "bar_stack";
  }

  const disable_cache_regex = /(__disable_cache\s*=\s*True)/i;
  if (disable_cache_regex.test(input.raw_query)) {
    input.cache_key = Date.now().toString()
  }

  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url + "/api/run_query",
    input
  );

  if (fetchData.status) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
    if (fetchData && fetchData.data && Object.keys(fetchData.data).length >0)  {
      useGlobalStore.getState().setWidgetData(widgetId, fetchData.data);
    }
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData.message;
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }


};

const refreshGroupBarChart = (widgetId, config) => {
  fetchWidgetData(widgetId, getGroupBarChartInput(config));
};

export default refreshGroupBarChart;
