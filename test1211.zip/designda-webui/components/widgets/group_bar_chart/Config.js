import React, { useState, useEffect } from "react";
import {
  Autocomplete,
  Box,
  Button,
  FormLabel,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  TextField,
  Typography,
} from "@mui/material";
import { ClickAwayListener } from "@mui/base";
// data source table
// TODO: the below data source path should change once the module location is changed
import DataSource from "../../../pages/rptdashboard/data_source/DataSource";
// utility imprts
import _ from "lodash";
import * as utils from "../../../common/utils/utils";
import refreshGroupBarChart from "./GroupBarChartApi";

import dynamic from "next/dynamic";
import styles from "./Config.module.css";

// INFO: dynamically importing query editor to prevent SSR issues
const AceEditor = dynamic(
  () =>
    import("../../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);

// class Config extends React.Component {
const Config = (props) => {
  const defaultQueryBody = `# Data has been loaded in df variable
# Please modify the df variable to contain data needed for the plot
#
# Grouping axis X -
#   * First 2 columns plot X axis
#   * The last column (numerical) plots Y axis
#
# Grouping axis Y -
#   * 1st column plots X axis
#   * Rest all columns (numerical) plot Y axis
`;

  const [title, setTitle] = useState(_.get(props.config, 'title', ''));
  const [dataLocation, setDataLocation] = useState(
    _.get(props.config, "dataLocation", "")
  );
  const [showDataSource, setShowDataSource] = useState(false);
  const [data, setData] = useState(_.get(props.config, "data", ""));
  const [columns, setColumns] = useState(
    _.get(props.config, "columns", [])
  );
  const [groupingAxis, setGroupingAxis] = useState(
    _.get(props.config, "groupingAxis", "Y")
  );
  const [bucket, setBucket] = useState(_.get(props.config, "bucket", ""));
  const [cache_key, setCache_key] = useState(_.get(props.config, "cache_key", ""));
  const [dataList, setDataList] = useState([]);
  const [columnList, setColumnList] = useState([]);
  const [scenarioList, setScenarioList] = useState([]);
  const [rootDataLocation, setRootDataLocation] = useState("");
  const [scenario, setScenario] = useState(
    utils.getScenarioFromDataLoc(_.get(props.config, "dataLocation", ""))
  );
  const [dataHelperText, setDataHelperText] = useState("");
  const [dataErrorFlag, setDataErrorFlag] = useState(false);
  const [columnHelperText, setColumnHelperText] = useState("");
  const [columnErrorFlag, setColumnErrorFlag] = useState(false);
  const [scenarioHelperText, setScenarioHelperText] = useState("");
  const [scenarioErrorFlag, setScenarioErrorFlag] = useState(false);
  const [query, setQuery] = useState(
    _.get(props.config, "query", defaultQueryBody)
  );

  // handlers and corresponding logic

  const dataChanged = async (newData, newConfig = {}) => {
    const columnObject = await utils.getDataColumnsObject(
      newData,
      newConfig.bucket ? newConfig.bucket : bucket, //take from state if newConfig is not available
      newConfig.dataLocation ? newConfig.dataLocation : dataLocation, //take from state if newConfig is not available
      columns
    );
    setColumnList(columnObject.columnList);
    setColumnHelperText(columnObject.columnHelperText);
    setColumnErrorFlag(columnObject.columnErrorFlag);
    setData(newData);
    setColumns(columns);
  };

  const dataLocationChanged = async (dataLocation, bucket) => {
    const rootDataLocationLocal = utils.getRootDirectory(dataLocation);
    const scenarioListLocal = await utils.getScenarioList(
      bucket,
      rootDataLocationLocal
    );
    let scenarioErrorFlagLocal = false;
    let scenarioHelperTextLocal = "";
    let newDataLocation = dataLocation;
    //if scneario exists but not present in current location
    if (!scenarioListLocal.includes(scenario) && scenario) {
      scenarioErrorFlagLocal = true;
      scenarioHelperTextLocal = "Invalid scenario for the selected Data Source";
    } else if (scenario) {
      //if scenario exists and present in current root level
      newDataLocation = rootDataLocationLocal + "/" + scenario;
    }
    //if only root level data is present but not scenario
    else {
      newDataLocation = rootDataLocationLocal;
    }
    const dataObject = await utils.getDataObject(newDataLocation, bucket, data);
    const newConfig = {
      dataLocation: newDataLocation,
      rootDataLocation: rootDataLocationLocal,
      bucket: bucket,
      scenarioList: scenarioListLocal,
      scenarioErrorFlag: scenarioErrorFlagLocal,
      scenarioHelperText: scenarioHelperTextLocal,
      dataErrorFlag: dataObject.dataErrorFlag,
      dataHelperText: dataObject.dataHelperText,
      dataList: dataObject.dataList,
    };
    const updateStates = () => {
      setDataLocation(newDataLocation);
      setRootDataLocation(rootDataLocationLocal);
      setBucket(bucket);
      setScenarioList(scenarioListLocal);
      setScenarioErrorFlag(scenarioErrorFlagLocal);
      setScenarioHelperText(scenarioHelperTextLocal);
      setDataErrorFlag(dataObject.dataErrorFlag);
      setDataHelperText(dataObject.dataHelperText);
      setDataList(dataObject.dataList);
    };
    updateStates();
    if (data) {
      dataChanged(data, newConfig);
    }
  };

  // on component mount
  useEffect(() => {
    // refresh data list if data location is present
    if (dataLocation) {
      dataLocationChanged(dataLocation, bucket);
    }
  }, []);

  const scenarioChanged = async (dataSource, bucket) => {
    const dataObject = await utils.getDataObject(dataSource, bucket);
    const newConfig = {
      bucket: bucket,
      dataLocation: dataSource,
      scenario: utils.getScenarioFromDataLoc(dataSource),
      scenarioErrorFlag: false,
      scenarioHelperText: "",
      dataErrorFlag: dataObject.dataErrorFlag,
      dataHelperText: dataObject.dataHelperText,
      dataList: dataObject.dataList,
    };
    const updateStates = () => {
      setBucket(bucket);
      setDataLocation(dataSource);
      setScenario(utils.getScenarioFromDataLoc(dataSource));
      setScenarioErrorFlag(false);
      setScenarioHelperText("");
      setDataErrorFlag(dataObject.dataErrorFlag);
      setDataHelperText(dataObject.dataHelperText);
      setDataList(dataObject.dataList);
    };
    updateStates();
    if (data) {
      dataChanged(data, newConfig);
    }
  };

  const handleScenarioChange = (scenario) => {
    // if scenario is selected -> add scenario to root data location path else no
    scenarioChanged(
      scenario ? rootDataLocation + "/" + scenario : rootDataLocation,
      bucket
    );
  };

  const handleDataLocationChange = (newDataLocation, bucket) => {
    dataLocationChanged(utils.getRootDirectory(newDataLocation), bucket);
  };

  const handleDataChange = (newData) => {
    if (newData) {
      setDataHelperText("");
      setDataErrorFlag(false);
      dataChanged(newData);
    }
  };

  const onQueryChange = (newQuery) => {
    setQuery(newQuery);
  };

  const onOKButtonClick = () => {
    // set config from state variables
    const config = {
      dataLocation,
      groupingAxis,
      data,
      columns,
      query,
      bucket,
      cache_key,
    };
    // add title only if user has provided it
    if (title.length > 0) {
      config["title"] = title;
    }
    props.updateConfig(config, true);
    // add a method to call 'refresh' fucntionality i.e api call
    refreshGroupBarChart(props.id, config);
  };

  const onTitleChange = (evt) => {
    setTitle(evt.target.value);
  }

  const onClickDataSource = () => {
    setShowDataSource(true);
  }

  return (
    <div className={styles.outer_div}>
      <div>
        {/* provide a title for the widget */}
        <TextField
          fullWidth
          label="Title"
          size="small"
          value={title}
          InputLabelProps={{
            shrink: true,
          }}
          onChange={(event) => onTitleChange(event)}
          variant="outlined"
        />
      </div>
      {/* Select Data Source */}
      <div className={styles.inline}>
        <Button
          size="small"
          classes={{ root: styles.add_button }}
          onClick={() => onClickDataSource()}
        >
          Data Source
        </Button>
        {showDataSource ? (
          <ClickAwayListener onClickAway={() => setShowDataSource(false)}>
            <Box
              sx={{
                zIndex: "5",
                position: "absolute",
                top: "0px",
                left: "0px",
                width: "100%",
                height: "fit-content",
                backgroundColor: "white",
                padding: "5px",
                boxShadow: "grey 5px 5px 5px",
              }}
            >
              <DataSource
                dataLocationChanged={handleDataLocationChange}
                dataLocation={dataLocation}
                bucket={bucket}
                close={() => {
                  setShowDataSource(false);
                }}
              />
            </Box>
          </ClickAwayListener>
        ) : null}
        <Typography
          variant="body2"
          style={{ marginTop: "15px", marginLeft: "15px" }}
        >
          {dataLocation && dataLocation.includes("#")
            ? dataLocation.split("#")[1]
            : ""}
        </Typography>
      </div>
      <Autocomplete
        id="scenario-input"
        style={{ marginTop: "10px" }}
        value={scenario}
        onChange={(event, newValue) => handleScenarioChange(newValue)}
        classes={{
          option: styles.option,
        }}
        size="small"
        options={scenarioList}
        getOptionLabel={(option) =>
          option.includes("#") ? option.split("#")[1] : option
        }
        renderInput={(params) => (
          <TextField
            {...params}
            error={scenarioErrorFlag}
            helperText={scenarioHelperText}
            label="Scenario"
            variant="outlined"
          />
        )}
      />
      {/* Select Dataframe */}
      <Autocomplete
        id="data-input"
        style={{ marginTop: "10px" }}
        value={data}
        onChange={(event, newValue) => handleDataChange(newValue)}
        classes={{
          option: styles.option,
        }}
        size="small"
        options={dataList}
        getOptionLabel={(option) =>
          option.includes("#") ? option.split("#")[1] : option
        }
        renderInput={(params) => (
          <TextField
            {...params}
            error={dataErrorFlag}
            helperText={dataHelperText}
            label="Data"
            variant="outlined"
          />
        )}
      />
      {/* Select Columns */}
      <Autocomplete
        id="columns-input"
        multiple
        filterSelectedOptions
        style={{ marginTop: "10px" }}
        value={columns}
        onChange={(event, newValue) => setColumns(newValue)}
        classes={{
          option: styles.option,
        }}
        size="small"
        options={columnList}
        renderInput={(params) => (
          <TextField {...params} label="Columns" variant="outlined" />
        )}
      />
      <FormControl component="fieldset">
        <FormLabel component="legend" style={{ marginTop: "10px" }}>
          Grouping axis
        </FormLabel>
        <RadioGroup
          row
          aria-label="grouping_axis"
          name="grouping_axis"
          value={groupingAxis}
          onChange={(evt) => setGroupingAxis(evt.target.value)}
        >
          <FormControlLabel
            value="X"
            control={<Radio color="primary" />}
            label="X"
          />
          <FormControlLabel
            value="Y"
            control={<Radio color="primary" />}
            label="Y"
          />
        </RadioGroup>
      </FormControl>
      {/* Code editor */}
      <Typography variant="subtitle1" className={styles.label}>
        Query Editor
      </Typography>
      <AceEditor
        placeholder="Please modify df object depending on the query."
        mode="python"
        theme="xcode"
        name="code_editor"
        width="100%"
        onChange={(value, event) => onQueryChange(value)}
        fontSize={16}
        maxLines={Infinity}
        showPrintMargin={true}
        showGutter={true}
        highlightActiveLine={true}
        value={query}
        setOptions={{
          enableBasicAutocompletion: true,
          enableLiveAutocompletion: true,
          enableSnippets: false,
          showLineNumbers: true,
          tabSize: 2,
        }}
      />
      <Button
        variant="contained"
        size="small"
        disabled={false}
        onClick={onOKButtonClick}
        classes={
          false
            ? { root: styles.save_button_disabled }
            : { root: styles.save_button }
        }
      >
        OK
      </Button>
      <Button
        variant="contained"
        size="small"
        onClick={() => props.updateConfig({}, false)}
        classes={{ root: styles.cancel_button }}
      >
        Cancel
      </Button>
    </div>
  );
};

export default Config;
