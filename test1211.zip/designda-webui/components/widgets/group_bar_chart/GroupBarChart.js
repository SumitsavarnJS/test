// react imports
import React, { useState, useEffect, useRef, useMemo } from "react";
import { produce } from "immer";
import ReactEcharts from "echarts-for-react";
import { retrieveContextMenuList } from "../../custom_context_menu/customContextMenu";
import { Menu, MenuItem, Typography } from "@mui/material";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";

// utility imprts
import _ from "lodash";
import Config from "./Config";
// css imports
import styles from "./GroupBarChart.module.css";

const theme = useConfigStore.getState().theme;

function GroupBarChart(props) {
  const widgetProps = props.widgetProps;
  const { config } = widgetProps;
  const { id, rptType, reportKey } = props;
  const data = _.get(useGlobalStore.getState()[id], "data", {});
  const uiState = _.get(useGlobalStore.getState()[id], "uiState", {
    showConfig: false,
  });

  const [isContextMenuOpen, setContextMenuOpen] = useState(false);
  const [contextMenuOptions, setContextMenuOptions] = useState([]);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const chartRef = useRef();
  // one ref to handle all underscore related data
  const underscoreData = useRef({});
  const exceptionalColumnList = [
    "__contextMenu",
    "__obtype",
    "__object",
    "__ttype",
  ];

  useEffect(() => {
    // disable right click on that div
    const widgetDiv = document.getElementById("groupBarChartId");
    if (widgetDiv) {
      widgetDiv.addEventListener("contextmenu", (e) => {
        e.preventDefault();
      });
    }

    if (config !== undefined) {
      // to set previous session zoom settings
      if (config.zoom && config.zoom.batch[0] && chartRef && chartRef.current) {
        chartRef.current.getEchartsInstance().dispatchAction({
          type: "dataZoom",
          batch: [
            {
              startValue: config.zoom.batch[0].startValue,
              endValue: config.zoom.batch[0].endValue,
            },
          ],
        });
      }

      // to set previous session legend selected settings
      if (config.legend && chartRef && chartRef.current) {
        let unSelected = [];
        Object.keys(config.legend).forEach((key) => {
          if (config.legend[key] == false) {
            unSelected.push(key);
          }
        });

        for (let i = 0; i < unSelected.length; i++) {
          chartRef.current.getEchartsInstance().dispatchAction({
            type: "legendUnSelect",
            name: unSelected[i],
          });
        }
      }
    }
  }, []);

  // whenever data changes, get contextMenu
  useEffect(() => {
    if (data) {
      underscoreData.current = data.underscore_data
        ? data.underscore_data
        : null;
      // console.log("check underscoreData.current", !!underscoreData.current);
    }
  }, [data]);

  const handleMenuClose = () => {
    setContextMenuOpen(false);
  };

  const getUnderscoredColumns = (obj) =>
    Object.entries(obj).filter(([colName, colValue]) =>
      colName.startsWith("__")
    );

  const getUpdatedClickedMetaData = (arr, obj) => {
    const updatedObj = { ...obj };
    arr.forEach(([_colName, _colValue]) => {
      // columns having __META__ keyword and columns present in exceptionalColumnList should NOT be passed in child widget query
      // so, if _colName is NOT a part of exceptionalColumnList AND _colName does not include __META__ keyword
      if (
        !exceptionalColumnList.includes(_colName) &&
        !_colName.includes("__META__")
      ) {
        // update the clickedMetaData object
        // this will be used to pre-pend query
        updatedObj[_colName] = _colValue;
      }
    });
    return updatedObj;
  };
  // memoize handler to prevent re-render
  const onContextMenuHandler = useMemo(
    () => (params) => {
      try {
        // seriesName is the Y-axis name in default case i.e without swap
        const {
          name: groupName, //name of the GROUP
          seriesType,
          seriesName: yAxisName,
        } = params;

        // get chart_type
        const chart_type =
          config.groupingAxis === "Y" ? "bar_line" : "bar_stack";

        // since X-axis name does not appear in right-click -> params, get the name from 'data' (a.k.a option) itself
        const xAxisName = data?.xAxis?.name;

        // context menu should appear only for bar
        if (seriesType === "bar" && !!underscoreData.current) {
          // get a variable to store meta-data of clicked bar
          const clickedMetaData = {
            // commenting out the X and Y data for now [at rendering prependQuery time]
            // '#' will comment the query line
            [`# x-axis key-value: ${xAxisName}`]: params.name,
            [`# y-axis key-value: ${yAxisName}`]: params.data,
          };

          // declare global vars
          let updatedClickedMetaData = {};
          let interestedSeries = {};
          let columnsStartingWithUnderscore = [];

          // find group corresponding to the right-click
          const interestedGroup = underscoreData.current[groupName]
            ? underscoreData.current[groupName]
            : null;

          // for bar-line a.k.a GROUPED BY Y axis
          if (!!interestedGroup && chart_type === "bar_line") {
            columnsStartingWithUnderscore =
              getUnderscoredColumns(interestedGroup);

            updatedClickedMetaData = getUpdatedClickedMetaData(
              columnsStartingWithUnderscore,
              clickedMetaData
            );
          } else if (!!interestedGroup && chart_type === "bar_stack") {
            // this goes one level deeper

            // interestedGroup is a JS object
            // find the series corresponding to the right-click
            interestedSeries = interestedGroup[yAxisName]
              ? interestedGroup[yAxisName]
              : null; // yAxisName is alias for seriesName

            // if series exists -> proceed
            if (!!interestedSeries) {
              // interestedSeries is a JS object
              // get all the columns along with their values | that start with an underscore
              columnsStartingWithUnderscore =
                getUnderscoredColumns(interestedSeries);

              // iterate through each column
              updatedClickedMetaData = getUpdatedClickedMetaData(
                columnsStartingWithUnderscore,
                clickedMetaData
              );
            }
          }
          // console.log("final clicked data", updatedClickedMetaData);
          // get the mousePos
          const mousePos = {
            x: params.event.event.pageX,
            y: params.event.event.pageY,
          };
          setMousePosition(mousePos);

          // if chart_type is bar line, interestedSeries is EMPTY, so search interestedGroup
          const clickedOnMenu =
            chart_type === "bar_line"
              ? interestedGroup["__contextMenu"]
              : interestedSeries["__contextMenu"];

          const menuOptions = retrieveContextMenuList(clickedOnMenu, {
            props,
            clickedMetaData: updatedClickedMetaData,
          });

          // set the options for context-menu
          setContextMenuOptions(menuOptions);
          // open the context-menu
          setContextMenuOpen(true);
        }
      } catch (error) {
        console.error(
          "Something went wrong on right-click handler of group-bar-chart!",
          error
        );
      }
    },
    []
  );

  // using memoization to prevent default reset of component
  // each handler is ALSO memoized
  const eventDict = useMemo(
    () => ({
      contextmenu: onContextMenuHandler,
    }),
    [onContextMenuHandler]
  );

  const onSwapAxes = () => {
    const graphData = _.get(useGlobalStore.getState()[id], "data", {});
    const gridValue = { ...graphData.grid, containLabel: true };
    let xAxisValue;
    let yAxisValue;

    if (config.groupingAxis === 'X') {
      // get y axis value and store in x
      xAxisValue = {
        ...graphData.yAxis,
        axisLabel: { ...graphData.yAxis.axisLabel, rotate: 25, fontSize: 11 },
      };
      yAxisValue = {
        ...graphData.xAxis,
        axisLabel: { ...graphData.xAxis.axisLabel, rotate: 0, fontSize: 11 },
      };
    }
    else {
      // config.groupingAxis is Y
      // get y axis value and store in x
      xAxisValue = Array.isArray(graphData.yAxis) ? graphData.yAxis : {
        ...graphData.yAxis,
        axisLabel: { ...graphData.yAxis.axisLabel, rotate: 25, fontSize: 11 },
      }
      // axisLabel: { ...graphData.yAxis.axisLabel, rotate: 25, fontSize: 11 },
      yAxisValue = Array.isArray(graphData.xAxis) ? graphData.xAxis : {
        ...graphData.xAxis,
        axisLabel: { ...graphData.xAxis.axisLabel, rotate: 0, fontSize: 11 },
      };
    }
    const updatedGraphData = {
      ...graphData,
      xAxis: xAxisValue,
      yAxis: yAxisValue,
      grid: gridValue,
    };
    // update the global store
    useGlobalStore.getState().setWidgetData(id, updatedGraphData);
  };

  // Function to get update option
  const getEchartsOption = (option) => {
    const swapAxes = {
      show: true,
      title: "Swap Axes",
      //icon: 'image://WidgetIcons/TimingPathMatrix.svg',
      //the SVG below is taken from mui - SwapHorizIcon
      icon: "path://M6.99 11 3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z",
      onclick: function () {
        onSwapAxes();
      },
    };


    const updatedOption = produce(option, (optionDraft) => {
      // push this new object to fetchData -> data
      // set the swap axis button
      // name should start with "my" prefix, else it does not show up / work
      optionDraft["toolbox"]["feature"]["mySwapAxes"] = swapAxes;
      // update styling of tooltip with an extraCssText | this will ensure word-wraps
      optionDraft["tooltip"] = {
        ...optionDraft["tooltip"],
        extraCssText:
          "display: inline-block; width: 300px; overflow-wrap: break-word; word-wrap:break-word; white-space: pre-line; overflow-wrap: break-word;",
      };
      // add legend configuration to make it scrollable
      optionDraft["legend"] = {
        type: "scroll",
        orient: "horizontal",
        top: "20",
      };
      optionDraft["grid"] = { top: "80" };
      if (
        "min_value" in optionDraft &&
        "max_value" in optionDraft &&
        (optionDraft.min_value > 1000 || optionDraft.max_value > 10000)
      ) {
        let multiplier = optionDraft.min_value.toString().length - 1;
        if (multiplier < 3) {
          multiplier = optionDraft.max_value.toString().length - 1;
        }
        optionDraft["yAxis"]["axisLabel"] = {
          formatter: function (value, index) {
            return value / Math.pow(10, multiplier);
          },
        };
        optionDraft["yAxis"]["name"] =
          optionDraft["yAxis"]["name"] + " (10^" + multiplier + ")";
        optionDraft["backgroundColor"] = theme == "dark" ? "rgb(50,50,50)" : "";
      }
    });
    return updatedOption;
  };

  // Function to update config
  const updateConfig = (config, save) => {
    if (save) {
      useGlobalStore.getState().updateConfig(rptType, reportKey, id, config);
    }

    useGlobalStore.getState().setWidgetUiState(id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  // on context menu option click
  const onOptionClick = (optionItem) => {
    try {
      // call action as passed from menu-option
      optionItem.action();
    } catch (err) {
      console.error("Something went wrong on context-menu click!");
    } finally {
      // close context menu
      handleMenuClose();
    }
  };

  return (
    <>
      {uiState.showConfig ? (
        <Config updateConfig={updateConfig} config={config} id={id} />
      ) : data && Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <div
          id="groupBarChartId"
          style={{ height: "100%", width: "100%", position: "relative" }}
        >
          <ReactEcharts
            ref={chartRef}
            style={{
              height: "100%",
              width: "100%",
              backgroundColor: theme == "dark" ? "rgb(50,50,50)" : "",
            }}
            option={getEchartsOption(data)}
            theme={theme}
            // this triggered a re-render onContextMenu right-click
            // commenting this line out
            // notMerge will not be required in this case
            // notMerge={true}
            onEvents={eventDict}
          />
          <Menu
            anchorReference="anchorPosition"
            anchorPosition={{
              top: mousePosition.y,
              left: mousePosition.x,
            }}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
            variant="menu"
            keepMounted
            open={isContextMenuOpen}
            style={{ display: "block" }}
            onClose={handleMenuClose}
          >
            {contextMenuOptions.length > 0 &&
              contextMenuOptions.map((option, index) => (
                <MenuItem
                  key={`${option}_${index}`}
                  onClick={() => onOptionClick(option)}
                >
                  {option.label}
                </MenuItem>
              ))}
          </Menu>
        </div>
      )}
    </>
  );
}

export default GroupBarChart;

GroupBarChart.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
