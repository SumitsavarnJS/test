// react imports
import React, { useState, useEffect, useRef } from "react";
import { produce } from "immer";
import ReactEcharts from "echarts-for-react";
import { Menu, MenuItem, Typography } from "@mui/material";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";

// utility imprts
import _ from "lodash";
import Config from "./Config";
// css imports
import styles from "./GroupBarChart.module.css";

const theme = useConfigStore.getState().theme;

function MetricsGroupBarChart(props) {
  const [contextMenuOpen, setContextMenuOpen] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const chartRef = useRef();

  useEffect(() => {
    if (props.config !== undefined) {
      // to set previous session zoom settings
      if (
        props.config.zoom &&
        props.config.zoom.batch[0] &&
        chartRef &&
        chartRef.current
      ) {
        chartRef.current.getEchartsInstance().dispatchAction({
          type: "dataZoom",
          batch: [
            {
              startValue: props.config.zoom.batch[0].startValue,
              endValue: props.config.zoom.batch[0].endValue,
            },
          ],
        });
      }

      // to set previous session legend selected settings
      if (props.config.legend && chartRef && chartRef.current) {
        let unSelected = [];
        Object.keys(props.config.legend).forEach((key) => {
          if (props.config.legend[key] == false) {
            unSelected.push(key);
          }
        });

        for (let i = 0; i < unSelected.length; i++) {
          chartRef.current.getEchartsInstance().dispatchAction({
            type: "legendUnSelect",
            name: unSelected[i],
          });
        }
      }
    }
  }, []);

  const handleMenuClose = () => {
    setContextMenuOpen(false);
  };

  const showDataHandler = () => {
    props.showToast({
      reportName: props.currentReportName,
      widgetId: props.id,
      severity: "info",
      message: "Work in progress",
    });

    handleMenuClose();
  };

  const onSwapAxes = () => {
    const graphData = _.get(useGlobalStore.getState()[props.id], "data", {});
    const gridValue = { ...graphData.grid, containLabel: true };
    // get y axis value and store in x
    const xAxisValue = {
      ...graphData.yAxis,
      axisLabel: { ...graphData.yAxis.axisLabel, rotate: 25, fontSize: 11 },
    };
    // get x axis value and store in y
    const yAxisValue = {
      ...graphData.xAxis,
      axisLabel: { ...graphData.xAxis.axisLabel, rotate: 0, fontSize: 11 },
    };
    const updatedGraphData = {
      ...graphData,
      xAxis: xAxisValue,
      yAxis: yAxisValue,
      grid: gridValue,
    };
    // update the global store
    useGlobalStore.getState().setWidgetData(props.id, updatedGraphData);
  };

  // Function to get update option
  const getEchartsOption = (option) => {
    const swapAxes = {
      show: true,
      title: "Swap Axes",
      //icon: 'image://WidgetIcons/TimingPathMatrix.svg',
      //the SVG below is taken from mui - SwapHorizIcon
      icon: "path://M6.99 11 3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z",
      onclick: function () {
        onSwapAxes();
      },
    };
    const updatedOption = produce(option, (optionDraft) => {
      // push this new object to fetchData -> data
      // set the swap axis button
      // name should start with "my" prefix, else it does not show up / work
      optionDraft["toolbox"]["feature"]["mySwapAxes"] = swapAxes;
      // update styling of tooltip with an extraCssText | this will ensure word-wraps
      optionDraft["tooltip"] = {
        ...optionDraft["tooltip"],
        extraCssText:
          "display: inline-block; width: 300px; overflow-wrap: break-word; word-wrap:break-word; white-space: pre-line; overflow-wrap: break-word;",
      };
      // add legend configuration to make it scrollable
      optionDraft["legend"] = {
        type: "scroll",
        orient: "horizontal",
        top: "30",
      };
      optionDraft["grid"] = { top: "80", bottom: "30%", left: "25%" };
      if (
        "min_value" in optionDraft &&
        "max_value" in optionDraft &&
        (optionDraft.min_value > 1000 || optionDraft.max_value > 10000)
      ) {
        let multiplier = optionDraft.min_value.toString().length - 1;
        if (multiplier < 3) {
          multiplier = optionDraft.max_value.toString().length - 1;
        }
        optionDraft["yAxis"]["axisLabel"] = {
          formatter: function (value, index) {
            return value / Math.pow(10, multiplier);
          },
        };
        optionDraft["yAxis"]["name"] =
          optionDraft["yAxis"]["name"] + " (10^" + multiplier + ")";
        optionDraft["backgroundColor"] = theme == "dark" ? "rgb(50,50,50)" : "";
      }
    });
    return updatedOption;
  };

  // Function to update config
  const updateConfig = (config, save) => {
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(props.rptType, props.reportKey, props.id, config);
    }

    useGlobalStore.getState().setWidgetUiState(props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  const data = _.get(useGlobalStore.getState()[props.id], "data", {});
  const uiState = _.get(useGlobalStore.getState()[props.id], "uiState", {
    showConfig: false,
  });

  return (
    <>
      {uiState.showConfig ? (
        <Config
          updateConfig={updateConfig}
          config={props.config}
          id={props.id}
        />
      ) : data && Object.keys(data).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          This widget can not be refreshed! Data comes only from context menu of
          Metrics widget.
        </Typography>
      ) : (
        <div style={{ height: "100%", width: "100%", position: "relative" }}>
          <ReactEcharts
            ref={chartRef}
            style={{
              height: "100%",
              width: "100%",
              backgroundColor: theme == "dark" ? "rgb(50,50,50)" : "",
            }}
            option={getEchartsOption(data)}
            theme={theme}
            notMerge={true}
          />
          <Menu
            anchorReference="anchorPosition"
            anchorPosition={{
              top: mousePos.y,
              left: mousePos.x,
            }}
            keepMounted
            open={contextMenuOpen}
            onClose={handleMenuClose}
          >
            <MenuItem onClick={showDataHandler}>Show Data</MenuItem>
          </Menu>
        </div>
      )}
    </>
  );
}

export default MetricsGroupBarChart;

MetricsGroupBarChart.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
