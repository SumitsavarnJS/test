import React, { useState } from "react";
import { Box } from "@mui/material";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowRightIcon from "@mui/icons-material/ArrowRight";
import styles from "./TreeNode.module.css";

const TreeNode = ({ objKey, node, level = 0 }) => {
  const { name, alter_key, is_aligned, is_base_node, children, alter_value } =
    node;

  // state to hold expand/collapse of comparison
  const [isOpen, setIsOpen] = useState(false);

  // method to handle expand/collapse
  const onToggle = () => setIsOpen(!isOpen);

  const isTdRedForRefNode = is_base_node && !is_aligned && name;
  const isTdRedForTargetNode = !is_base_node && !is_aligned && alter_value;
  const isTdGreenForRefNode = is_base_node && !is_aligned && alter_value;
  const isTdGreenForTargetNode = !is_base_node && !is_aligned && name;

  return (
    <>
      <tr
        style={{
          height: "3rem",
          fontWeight: "550",
        }}
      >
        {/* button and compared names to be shown together */}
        {/* <div className={styles.item}> */}
        <td
          style={{
            width: "4%",
            paddingLeft: level * 20,
            border: "0.24px solid #F2F2F2",
          }}
        >
          <button
            onClick={onToggle}
            disabled={children && Object.keys(children).length == 0}
            className={styles.expandCollapseButton}
          >
            {isOpen ? <ArrowDropDownIcon /> : <ArrowRightIcon />}
          </button>
        </td>

        {/* Reference td */}

        <td
          style={{
            width: "48%",
            paddingLeft: level * 20,
            background:
              isTdRedForRefNode || isTdRedForTargetNode ? "#FFF9F9" : "#fff",
            border: "0.24px solid #F2F2F2",
          }}
        >
          {is_base_node ? (
            <Box display="flex" flexDirection="row" gap={2}>
              {!is_aligned && <Box className={styles.removedIcon}>-</Box>}
              <span
                style={
                  is_aligned
                    ? {
                        color: "inherit",
                        background: "inherit",
                      }
                    : {
                        color: "#E41616",
                        background: "#F8D5D5",
                      }
                }
              >
                {name}
              </span>
            </Box>
          ) : alter_key === null ? (
            <></>
          ) : (
            <Box display="flex" flexDirection="row" gap={2}>
              {!is_aligned && <div className={styles.removedIcon}>-</div>}
              <span
                style={
                  is_aligned
                    ? {
                        color: "inherit",
                        background: "inherit",
                      }
                    : {
                        color: "#E41616",
                        background: "#F8D5D5",
                      }
                }
              >
                {alter_value}
              </span>
            </Box>
          )}
        </td>

        {/* Target td */}
        <td
          style={{
            width: "48%",
            paddingLeft: level * 20,
            background:
              isTdGreenForRefNode || isTdGreenForTargetNode
                ? "#FAFFF6"
                : "#fff",
            border: "0.24px solid #F2F2F2",
          }}
        >
          {is_base_node ? (
            alter_key === null ? (
              <></>
            ) : (
              <Box display="flex" flexDirection="row" gap={2}>
                {!is_aligned && <Box className={styles.integratedIcon}>+</Box>}
                <span
                  style={
                    is_aligned
                      ? {
                          color: "inherit",
                          background: "inherit",
                        }
                      : {
                          color: "#4BA51E",
                          background: "#CEE8C0",
                        }
                  }
                >
                  {alter_value}
                </span>
              </Box>
            )
          ) : (
            <Box display="flex" flexDirection="row" gap={2} alignItems="center">
              {!is_aligned && <Box className={styles.integratedIcon}>+</Box>}
              <span
                style={
                  is_aligned
                    ? {
                        color: "inherit",
                        background: "inherit",
                      }
                    : {
                        color: "#4BA51E",
                        background: "#CEE8C0",
                      }
                }
              >
                {name}
              </span>
            </Box>
          )}
        </td>
      </tr>
      {/* if expanded and has children, recursively call TreeNode */}
      {isOpen &&
        children &&
        Object.keys(children).length > 0 &&
        Object.keys(children).map((childKey) => (
          <TreeNode
            objKey={childKey}
            node={children[childKey]}
            level={level + 1}
          />
        ))}
    </>
  );
};

export default TreeNode;
