import React, { useState } from "react";
import {
  Box,
  Button,
  Divider,
  Grid,
  TextField,
  Typography,
} from "@mui/material";
import getConfig from "next/config";
import DataSource from "../../../pages/rptdashboard/data_source/DataSource";
import _ from "lodash";
import { produce } from "immer";
import refreshLogComparator from "./LogComparatorApi";
import TerminalEditor from "../../terminal_editor/TerminalEditor";
import dynamic from "next/dynamic";
import api from "../../../common/api/api";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";
import InsightsOutlinedIcon from "@mui/icons-material/InsightsOutlined";
import { ClickAwayListener } from "@mui/base";
import axios from "axios";

import styles from "./LogComparatorConfig.module.css";

export const showToast = (toast, widgetId) => {
  const uiState = produce(
    useGlobalStore.getState()[widgetId].uiState,
    (uiStateDraft) => {
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
      uiStateDraft.toastMessage = _.get(toast, "message", "");
    }
  );
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
};

const LogComparatorConfig = (props) => {
  const { id, config, rptType, reportKey, updateConfig } = props;
  const { publicRuntimeConfig } = getConfig();
  const imageUrl = publicRuntimeConfig.basePath;
  const [title, setTitle] = useState(_.get(config, "title", "Log Comparator"));
  const [isLoading, setIsLoading] = useState(false);
  const [dataLocation, setDataLocation] = useState({
    reference: _.get(props.config, "reference", ""),
    target: _.get(props.config, "target", ""),
  });
  const [bucket, setBucket] = useState({
    refBucket: _.get(props.config, "refBucket", ""),
    tarBucket: _.get(props.config, "tarBucket", ""),
  });

  const [data, setData] = useState(_.get(props.config, "data", ""));

  const [showDataSource, setShowDataSource] = useState({
    reference: false,
    target: false,
  });
  const sources = ["reference", "target"];

  // handler when user clicks OK button in LogComparatorConfig
  const onOKButtonClick = () => {
    const config = {};
    if (title && title.length > 0) {
      config["title"] = title;
    }
    config["reference"] = dataLocation["reference"];
    config["target"] = dataLocation["target"];
    config["refBucket"] = bucket["refBucket"];
    config["tarBucket"] = bucket["tarBucket"];
    // call a method to update the config
    updateConfig(config, true);
    refreshLogComparator(id, config);
  };

  const dataLocationChanged = (newDataLocation, bucket, sourceName) => {
    const inputData = {
      bucket: bucket,
      key: newDataLocation,
    };
    if (sourceName === "reference") {
      setBucket((prevBucket) => ({ ...prevBucket, refBucket: bucket }));
    } else setBucket((prevBucket) => ({ ...prevBucket, tarBucket: bucket }));
    axios
      .post(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/get_ldb_files",
        inputData
      )
      .then((response) => {
        const dataList = _.get(response.data, "data", {});
        let localData = data; //data from state
        if (localData && !dataList.includes(localData)) {
          localData = "";
        }
        // update states
        setDataLocation({ ...dataLocation, [sourceName]: newDataLocation });
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const clickedReset = () => {
    updateConfig({}, true, true);
    setDataLocation({
      reference: "",
      target: "",
    });
    useGlobalStore.getState().setWidgetData(id, {});
  };

  return (
    <div className={styles.outer_div}>
      {/* title textbox */}
      <TextField
        fullWidth
        label="Title"
        size="small"
        value={title}
        InputLabelProps={{
          shrink: true,
        }}
        onChange={(event) => setTitle(event.target.value)}
        variant="outlined"
      />

      {/* Select Data Source */}
      <Box display="flex" justifyContent="space-evenly">
        {sources.map((sourceName) => (
          <>
            <Box
              display="flex"
              alignItems="center"
              flexDirection="column"
              width="40%"
              gap={1}
            >
              <Typography fontWeight="400" textTransform="capitalize">
                Select {sourceName} Data Source
              </Typography>
              <Button
                className={styles.dataSourceButton}
                onClick={() =>
                  setShowDataSource({ ...showDataSource, [sourceName]: true })
                }
                backgroundColor="#FDFDFD"
                fullWidth
                // disabled
              >
                <Grid container direction="column" alignItems="center">
                  <Grid item>
                    <img src={`${imageUrl}/log_comparator_widget/Upload.svg`} />
                  </Grid>
                  <Grid item>
                    <Typography fontWeight="500" color="#8653EA">
                      Click to upload file source
                    </Typography>
                  </Grid>
                </Grid>
              </Button>
              {/* show data source table if user has clicked Data Source button */}
              {showDataSource[sourceName] ? (
                <ClickAwayListener
                  onClickAway={() => {
                    setShowDataSource({
                      ...showDataSource,
                      [sourceName]: false,
                    });
                  }}
                >
                  <Box
                    sx={{
                      zIndex: "5",
                      position: "absolute",
                      top: "0px",
                      left: "0px",
                      width: "100%",
                      height: "fit-content",
                      backgroundColor: "white",
                      padding: "5px",
                      boxShadow: "grey 5px 5px 5px",
                    }}
                  >
                    <DataSource
                      dataLocationChanged={dataLocationChanged}
                      dataLocation={dataLocation[sourceName]}
                      // bucket={bucket}
                      close={() =>
                        setShowDataSource({
                          ...showDataSource,
                          [sourceName]: false,
                        })
                      }
                      sourceName={sourceName}
                    />
                  </Box>
                </ClickAwayListener>
              ) : null}
              {dataLocation && dataLocation[sourceName] && (
                <Box width="100%" display="flex" alignItems="center" gap={1}>
                  <img
                    src={`${imageUrl}/log_comparator_widget/Document.svg`}
                    height="20px"
                    width="20px"
                  />
                  <Typography width="100%" style={{ wordBreak: "break-word" }}>
                    {dataLocation[sourceName].split("#")[1]}
                  </Typography>
                  <img
                    src={`${imageUrl}/log_comparator_widget/SuccessOutline.svg`}
                    style={{ marginLeft: "20px" }}
                    height="20px"
                    width="20px"
                  />
                </Box>
              )}
            </Box>
            {sourceName === "reference" && (
              <Divider orientation="vertical" flexItem color="#E4E7ED" />
            )}
          </>
        ))}
      </Box>
      <Box display="flex" justifyContent="flex-end">
        <div className={styles.widgetButtonContainer}>
          <Button
            variant="contained"
            size="small"
            onClick={onOKButtonClick}
            classes={{ root: styles.save_button }}
            disabled={
              isLoading.generate ||
              !(dataLocation && dataLocation.reference && dataLocation.target)
            }
          >
            Generate Comparison
          </Button>
          <Button
            variant="outlined"
            size="small"
            onClick={clickedReset}
            classes={{ root: styles.reset_button }}
          >
            Reset
          </Button>
        </div>
      </Box>
      <br />
    </div>
  );
};

export default LogComparatorConfig;
