// react imports
import React, { useState, useEffect } from "react";
import Typography from "@mui/material/Typography";
import LogComparatorConfig from "./LogComparatorConfig";
import useGlobalStore from "../../../store/useGlobalStore";
import TreeNode from "./TreeNode";
import styles from "./LogComparator.module.css";

const LogComparator = (props) => {
  // destructure constants
  const { id: widgetId, rptType, reportKey, widgetProps } = props;

  const logComparatorDataFromResponse = _.get(
    useGlobalStore.getState()[widgetId],
    "data",
    {}
  );
  // state to hold data for the widget
  const [logComparatorData, setLogComparatorData] = useState([]);
  const [showErrorMsg, setShowErrorMsg] = useState(false);

  const uiState = _.get(useGlobalStore.getState()[widgetId], "uiState", {
    showConfig: false,
  });

  // whenever we get a response from the global store, update the local state
  useEffect(() => {
    setLogComparatorData(logComparatorDataFromResponse?.data);
  }, [logComparatorDataFromResponse]);

  // Function to update config
  const updateConfig = (config, save, isReset = false) => {
    // if user has refreshed, save the data in store
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(rptType, reportKey, widgetId, config);
    }
    useGlobalStore.getState().setWidgetUiState(widgetId, {
      isLoading: false,
      showConfig: isReset,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  return (
    <>
      {uiState.showConfig ? (
        <LogComparatorConfig
          updateConfig={updateConfig}
          config={widgetProps.config}
          rptType={rptType}
          reportKey={reportKey}
          id={widgetId}
        />
      ) : logComparatorData && Object.keys(logComparatorData).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to display
        </Typography>
      ) : (
        <div className={styles.chartParent}>
          {showErrorMsg
            ? "Input data is incorrect"
            : logComparatorData &&
              Object.keys(logComparatorData).map((item) => (
                <table className={styles.treeNode}>
                  <TreeNode objKey={item} node={logComparatorData[item]} />
                </table>
              ))}
        </div>
      )}
    </>
  );
};

export default LogComparator;

LogComparator.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
