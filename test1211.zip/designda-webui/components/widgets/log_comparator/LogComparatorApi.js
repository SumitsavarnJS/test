import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { produce } from "immer";
import { response } from "./dummy";
import api from "../../../common/api/api";

const getIWidgetPayload = (config) => {
  const { reference, target, refBucket = "", tarBucket = "" } = config;
  const payload = {
    refTask: `${reference?.split("#")[1]}`, //reference data source
    tarTask: `${target?.split("#")[1]}`, //target data source
    refBucket: refBucket,
    tarBucket: tarBucket,
  };
  return payload;
};

const fetchWidgetData = async (widgetId, apiPayload) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  // api call to get widget data
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/api/log_analysis/get_log_comparision",
    apiPayload
  );

  if (fetchData) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  }

  if (fetchData && fetchData.data && Object.keys(fetchData.data).length) {
    // bow fetchdata is {data: {}, theme: ""}, take the entire data and set in store
    useGlobalStore.getState().setWidgetData(widgetId, fetchData);
  } else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData?.message || "Something went wrong";
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
    useGlobalStore.getState().setWidgetData(widgetId, {});
  }
};

const refreshLogComparator = (widgetId, config) => {
  fetchWidgetData(widgetId, getIWidgetPayload(config));
};

export default refreshLogComparator;
