// react imports
import React from "react";
import _ from "lodash";
import Typography from "@mui/material/Typography";
import Config from "./Config";
import useGlobalStore from "../../../store/useGlobalStore";
import styles from "./ThreeDSurfaceChart.module.css";
import dynamic from "next/dynamic";

// import 3d generic chart component here:
// this needs to be done in order to bypass import error of echarts-gl
const ThreeDGenericChart = dynamic(
    () =>
        import("../../three_d_generic_chart/ThreeDGenericChart").then(
            (mod) => mod.default
        ),
    { ssr: false }
);

function ThreeDSurfaceChart(props) {

    // Function to update config
    const updateConfig = (config, save) => {
        // if user has refreshed, save the data in store
        if (save) {
            useGlobalStore
                .getState()
                .updateConfig(
                    props.rptType,
                    props.reportKey,
                    props.id,
                    config
                );
        }

        useGlobalStore.getState().setWidgetUiState(props.id, {
            isLoading: false,
            showConfig: false,
            isToastOpen: false,
            toastSeverity: "info",
            toastMessage: "",
            cirlularLoading: false,
        });
    };

    // get all required data here

    // get chart json data a.k.a options for ReactECharts
    const data = _.get(useGlobalStore.getState()[props.id], "data", {});

    // get ui-state from global state
    const uiState = _.get(useGlobalStore.getState()[props.id], "uiState", {
        showConfig: false,
    });

    // render components (Config and ReactECharts) conditionally
    return (
        <>
            {
                uiState.showConfig ?
                    <Config updateConfig={updateConfig} config={props.config} id={props.id}/>
                    :
                    data && Object.keys(data).length === 0 ? (
                        <Typography variant="h5" className={styles.text} align="center">
                            No data to view. Please refresh!
                        </Typography>
                    ) : (
                        <div className={styles.chartParent}>
                            {/* get the 3d generic chart component here */}
                            <ThreeDGenericChart optionData={data} />
                        </div>
                    )
            }
        </>
    )
}

export default ThreeDSurfaceChart;

ThreeDSurfaceChart.defaultProps = {
    widgetProps: {},
    data: {},
    uiState: {
        isLoading: false,
        showConfig: false,
        isToastOpen: false,
        toastSeverity: "info",
        toastMessage: "",
    },
};

