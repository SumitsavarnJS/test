/* eslint-disable no-unused-vars*/
// react imports
import React, { useState, useEffect, useMemo } from "react";
import ReactEcharts from "echarts-for-react";
import IWidgetConfig from "./iWidgetConfig";
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import { produce } from "immer";
import { getContextMenuOptions } from "./iWidgetApi";
import styles from "./iWidget.module.css";
import {
  Menu,
  MenuItem,
  Typography,
  Skeleton,
  CircularProgress,
} from "@mui/material";
import { handleContextMenuAction, showToast } from "./contexMenu";
import _ from "lodash";

const IWidget = (props) => {
  const { authLoginUser } = useConfigStore();
  const contextMenuEnabledCharts = ["group_bar", "pie"];
  // console.log("props for generic I widget", props);
  let themeFromReports = "light";
  if (props.rptType === "allReports") {
    const reportInfo = _.cloneDeep(
      useGlobalStore.getState().allReports[props.reportKey]
    );
    themeFromReports = reportInfo.theme;
  }

  // destructure constants
  const { id: widgetId, rptType, reportKey, widgetProps, chartType } = props;
  const iWidgetDataFromResponse = _.get(
    useGlobalStore.getState()[widgetId],
    "data",
    {}
  );
  const { context_menu_func_src, context_menu_vars } =
    useGlobalStore.getState()[widgetId]?.data ?? {};

  // state to hold data for the widget
  const [iWidgetData, setIWidgetData] = useState([]);
  const [showErrorMsg, setShowErrorMsg] = useState(false);
  const [isContextMenuOpen, setContextMenuOpen] = useState(false);
  const [contextMenuOptions, setContextMenuOptions] = useState([]);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [clickedContextMenuArgs, setClickedContextMenuArgs] = useState({});

  const uiState = _.get(useGlobalStore.getState()[widgetId], "uiState", {
    showConfig: false,
  });

  useEffect(() => {
    // disable right click on that div
    const widgetDiv = document.getElementById("iWidgetContainer");
    if (widgetDiv) {
      widgetDiv.addEventListener("contextmenu", (e) => {
        e.preventDefault();
      });
    }
  }, []);
  // whenever we get a response from the global store, update the local state
  useEffect(() => {
    setIWidgetData(iWidgetDataFromResponse);
  }, [iWidgetDataFromResponse]);

  // Function to update config
  const updateConfig = (config, save, typeOfClick = "generate") => {
    // if user has refreshed, save the data in store
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(rptType, reportKey, widgetId, config);
    }
    useGlobalStore.getState().setWidgetUiState(widgetId, {
      isLoading: false,
      showConfig: typeOfClick === "execute",
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  const onSwapAxes = () => {
    const iWidgetDataInStore = _.get(
      useGlobalStore.getState()[widgetId],
      "data",
      {}
    );
    // destructuring data and grouping axis from API response
    // not getting it from state as toggle swap wont happen
    const { data: groupBarData, groupingAxis } = iWidgetDataInStore;
    const gridValue = { ...groupBarData.grid, containLabel: true };
    let xAxisValue;
    let yAxisValue;
    if (groupingAxis === "x") {
      // get y axis value and store in x
      xAxisValue = {
        ...groupBarData.yAxis,
        axisLabel: {
          ...groupBarData.yAxis.axisLabel,
          rotate: 25, //adding a rotate of 25 deg
          fontSize: 11, // assigning font size of 11px
        },
      };
      yAxisValue = {
        ...groupBarData.xAxis,
        axisLabel: {
          ...groupBarData.xAxis.axisLabel,
          rotate: 25,
          fontSize: 11,
        },
      };
    } else {
      // groupingAxis is Y
      // get y axis value and store in x
      xAxisValue = Array.isArray(groupBarData.yAxis)
        ? groupBarData.yAxis
        : {
            ...groupBarData.yAxis,
            axisLabel: {
              ...groupBarData.yAxis.axisLabel,
              rotate: 25,
              fontSize: 11,
            },
          };
      yAxisValue = Array.isArray(groupBarData.xAxis)
        ? groupBarData.xAxis
        : {
            ...groupBarData.xAxis,
            axisLabel: {
              ...groupBarData.xAxis.axisLabel,
              rotate: 25,
              fontSize: 11,
            },
          };
    }
    const updatedGroupBarData = {
      data: {
        ...groupBarData,
        xAxis: xAxisValue,
        yAxis: yAxisValue,
        grid: gridValue,
      },
      theme: iWidgetData.theme ? iWidgetData.theme : "light",
      groupingAxis,
    };
    // update the global store
    useGlobalStore.getState().setWidgetData(widgetId, updatedGroupBarData);
  };

  // in case we need to change some option on the UI, this method will help in doing so
  const getEchartsOption = (optionData, chartType) => {
    try {
      if (chartType === "group_bar") {
        const iWidgetDataInStore = _.get(
          useGlobalStore.getState()[widgetId],
          "data",
          {}
        );
        const { groupingAxis } = iWidgetDataInStore;

        const swapAxes = {
          show: true,
          title: "Swap Axes",
          //the SVG below is taken from mui - SwapHorizIcon
          icon: "path://M6.99 11 3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z",
          onclick: function () {
            onSwapAxes();
          },
        };

        const updatedOption = produce(optionData, (optionDraft) => {
          optionDraft["toolbox"]["feature"]["mySwapAxes"] = swapAxes;
          // based on grouping axes, the logic needs to change for axisLabel formatter
          // considering grouping is done on x-axis, both xAxis and yAxis from API response is an object
          // IF: grouping is done on y-axis, both xAxis and yAxis from API response CAN BE an array

          // call a function that returns an updated option for axisLabel (i.e having a formatter)
          // handle case of array
          const xAxisVal = optionDraft["xAxis"];
          const yAxisVal = optionDraft["yAxis"];
          const formatAxisLabel = (axisValue, isArray = false) => {
            const formattedLabel = {
              rotate: 25,
              fontSize: 11,
              width: axisValue === "yAxis" ? 70 : 140,
              overflow: "truncate",
              ellipsis: "...",
            };
            return !isArray
              ? {
                  ...optionDraft[axisValue]["axisLabel"],
                  ...formattedLabel,
                }
              : {
                  ...optionDraft[axisValue][0]["axisLabel"],
                  ...formattedLabel,
                };
          };
          if (groupingAxis === "x") {
            optionDraft["xAxis"]["axisLabel"] = formatAxisLabel("xAxis");
            optionDraft["yAxis"]["axisLabel"] = formatAxisLabel("yAxis");
          } else if (groupingAxis === "y") {
            if (Array.isArray(xAxisVal)) {
              optionDraft["xAxis"][0]["axisLabel"] = formatAxisLabel(
                "xAxis",
                true
              );
            } else if (!Array.isArray(xAxisVal)) {
              optionDraft["xAxis"]["axisLabel"] = formatAxisLabel("xAxis");
            }
            if (Array.isArray(yAxisVal)) {
              optionDraft["yAxis"][0]["axisLabel"] = formatAxisLabel(
                "yAxis",
                true
              );
            } else if (!Array.isArray(yAxisVal)) {
              optionDraft["yAxis"]["axisLabel"] = formatAxisLabel("yAxis");
            }
          }
        });
        return updatedOption;
      }
      return optionData;
    } catch (err) {
      console.error("Something went wrong in setting chart options");
    }
  };

  const onMenuClose = () => {
    setContextMenuOpen(false);
  };

  const onContextMenuHandler = useMemo(
    () => async (params) => {
      try {
        if (context_menu_func_src && context_menu_vars) {
          const mousePos = {
            x: params.event.event.pageX,
            y: params.event.event.pageY,
          };
          setMousePosition(mousePos);
          setContextMenuOpen(true);

          // console.log("params of chart", chartType, params);
          const context_menu_args = {};
          if (chartType === "pie") {
            context_menu_args["section"] = params.name;
            context_menu_args["value"] = params.value;
          } else if (chartType === "group_bar") {
            // irrespective of grouping by x or y, 'name' -> group | 'seriesName' -> bar | 'value' -> value
            context_menu_args["group"] = params.name;
            context_menu_args["bar"] = params.seriesName;
            context_menu_args["value"] = params.value;
          }
          const payload = {
            user: authLoginUser,
            chart_type: chartType,
            context_menu_func_src,
            context_menu_vars,
            context_menu_args,
          };
          // console.log({ payload });
          setClickedContextMenuArgs(context_menu_args)
          setContextMenuOptions([]);
          const menuOptionsFromApi = await getContextMenuOptions(payload);
          // console.log("menu-options", menuOptionsFromApi);
          if(menuOptionsFromApi) {
            setContextMenuOptions(menuOptionsFromApi.context_menu);
          }
          else {
            onMenuClose();
          }
        } else {
          showToast({
            reportName: props.currentReportName,
            widgetId: props.id,
            severity: "info",
            message: `Context Menu is not defined for the given ${chartType} chart`,
          });
        }
      } catch (error) {
        console.error(
          "Something went wrong on right-click handler of i-widget!",
          error
        );
      }
    },
    []
  );

  // using memoization to prevent default reset of component
  // each handler is ALSO memoized
  const eventDict = useMemo(
    () => ({
      contextmenu: onContextMenuHandler,
    }),
    [onContextMenuHandler]
  );

  // on context menu option click
  const onOptionClick = ({ action, label, args }) => {
    try {
      // call action handler, also pass context_menu_vars
      handleContextMenuAction(action, args, { props }, context_menu_vars, label, clickedContextMenuArgs);
    } catch (err) {
      console.error("Something went wrong on context-menu click!");
    } finally {
      // close context menu
      onMenuClose();
    }
  };

  return (
    <>
      {uiState.showConfig ? (
        <IWidgetConfig
          updateConfig={updateConfig}
          config={widgetProps.config}
          rptType={rptType}
          reportKey={reportKey}
          id={widgetId}
          chartType={chartType}
        />
      ) : iWidgetData && Object.keys(iWidgetData).length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to display
        </Typography>
      ) : (
        <div
          className={styles.chartParent}
          id="iWidgetContainer"
          onContextMenu={(e) => e.preventDefault()}
        >
          {showErrorMsg ? (
            "Input data is incorrect"
          ) : (
            <ReactEcharts
              style={{
                height: "100%",
              }}
              theme={
                iWidgetData.theme
                  ? iWidgetData.theme
                  : themeFromReports
                  ? themeFromReports
                  : "light"
              }
              option={getEchartsOption(iWidgetData.data, chartType)}
              onEvents={
                contextMenuEnabledCharts.includes(chartType) ? eventDict : null
              }
              // onEvents={eventDict}
            />
          )}
          <Menu
            open={isContextMenuOpen}
            anchorReference="anchorPosition"
            anchorPosition={{
              top: mousePosition.y,
              left: mousePosition.x,
            }}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
            variant="menu"
            keepMounted
            style={{ display: "block" }}
            onClose={onMenuClose}
          >
            {contextMenuOptions.length > 0 ? (
              contextMenuOptions.map((optionObj, index) => {
                const { label } = optionObj;
                return (
                  <MenuItem
                    key={`${label}_${index}`}
                    onClick={() => onOptionClick(optionObj)}
                  >
                    {label}
                  </MenuItem>
                );
              })
            ) : (
              <Typography sx={{ padding: "8px" }}>
                <CircularProgress size={13} sx={{ marginRight: "10px" }} />
                Fetching options
              </Typography>
            )}
          </Menu>
        </div>
      )}
    </>
  );
};

export default IWidget;

IWidget.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
