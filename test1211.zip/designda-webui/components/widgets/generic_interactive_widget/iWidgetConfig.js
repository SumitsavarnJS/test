/* eslint-disable no-unused-vars*/
import React, { useState } from "react";
import { Button, CircularProgress, TextField, Typography } from "@mui/material";
import _ from "lodash";
import { produce } from "immer";
import refreshInteractiveWidget from "./iWidgetApi";
import TerminalEditor from "../../terminal_editor/TerminalEditor";
import dynamic from "next/dynamic";
import api from "../../../common/api/api";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";
import InsightsOutlinedIcon from "@mui/icons-material/InsightsOutlined";
import PlayCircleOutlineOutlinedIcon from "@mui/icons-material/PlayCircleOutlineOutlined";
// import IWidgetLocalVariables from "../../CliVariables/TableViewCli/VariableLocal";

import styles from "./iWidgetConfig.module.css";

// INFO: dynamically importing query editor to prevent SSR issues
const AceEditor = dynamic(
  () =>
    import("../../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);

export const statusColors = {
  running: "#5797f7",
  hung: "#f7b757",
  unavailable: "#dedede",
  completed: "#57f79c",
};

export const showToast = (toast, widgetId) => {
  const uiState = produce(
    useGlobalStore.getState()[widgetId].uiState,
    (uiStateDraft) => {
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
      uiStateDraft.toastMessage = _.get(toast, "message", "");
    }
  );
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
};

const IWidgetConfig = (props) => {
  const defaultQueryBody = `# Invoke the cli object to query data and assign required dataframe to df variable
# List of available themes: 
# light
# infographic
# macarons
# roma
# vintage
# essos
# shine
# wonderland
# dark
# purple-passion
# --
# Grouping axis X -
#   * First 2 columns plot X axis
#   * The last column (numerical) plots Y axis
#
# Grouping axis Y -
#   * 1st column plots X axis
#   * Rest all columns (numerical) plot Y axis
`;

  const { id, config, chartType, rptType, reportKey, updateConfig } = props;

  const [title, setTitle] = useState(_.get(config, "title", chartType));
  const defaultQueryStr = chartType === 'group_bar' ? defaultQueryBody : defaultQueryBody.split('# --')[0];
  const [query, setQuery] = useState(_.get(config, "query", defaultQueryStr));
  const [terminalApiResponse, setTerminalApiResponse] = useState("");
  const [showTerminalEditor, setShowTerminalEditor] = useState(false);
  const [isLoading, setIsLoading] = useState({
    generate: false,
    execute: false,
  });
  const [variables, setVariables] = useState(
    useGlobalStore.getState()[rptType][reportKey].variables
  );

  //changes for local variables import
  // const [widgetLocalVariable, setWidgetLocalVariable] = useState(config.wVariables ? config.wVariables : {});
  //Query Change
  const onQueryChange = (newQuery) => {
    setQuery(newQuery);
  };

  // handler when user clicks OK button in IWidgetConfig
  const onGenerateChart = (evt, typeOfClick) => {
    const config = {};
    config["query"] = query;
    if (title && title.length > 0) {
      config["title"] = title;
    }
    // call a method to update the config
    updateConfig(config, true, typeOfClick);
    if (typeOfClick === "generate") {
      refreshInteractiveWidget(id, config, chartType, variables);
    }
  };

  // const updateLocVariable = (locVariables) => {
  //   setWidgetLocalVariable(locVariables);
  // };

  const onExec = async (evt, typeOfClick) => {
    try {
      //  API related task
      setIsLoading({ ...isLoading, execute: true });
      const input = {
        raw_query: query,
        variables: variables,
        user: useConfigStore.getState().authLoginUser,
      };
      const fetchData = await api(
        useConfigStore.getState().configData.rest_server_url +
          "/cli/exec_query",
        input
      );
      if (fetchData) {
        setTerminalApiResponse(fetchData);
      }
    } catch (err) {
      console.error("Something went wrong in executing query !");
    } finally {
      setShowTerminalEditor(true);
      setIsLoading({ ...isLoading, execute: false });
      onGenerateChart(evt, typeOfClick);
    }
  };

  return (
    <div className={styles.outer_div}>
      {/* title textbox */}
      <TextField
        fullWidth
        label="Title"
        size="small"
        value={title}
        InputLabelProps={{
          shrink: true,
        }}
        onChange={(event) => setTitle(event.target.value)}
        variant="outlined"
      />
      <div className={styles.queryEditorContainer}>
        <Typography variant="subtitle1" className={styles.label}>
          Query Editor
        </Typography>
        <AceEditor
          placeholder="Please modify df object depending on the query."
          mode="python"
          theme="xcode"
          name="code_editor"
          width="100%"
          onChange={(value, event) => onQueryChange(value)}
          fontSize={16}
          maxLines={Infinity}
          showPrintMargin={true}
          showGutter={true}
          highlightActiveLine={true}
          value={query}
          setOptions={{
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: true,
            enableSnippets: false,
            showLineNumbers: true,
            tabSize: 2,
          }}
        />
      </div>
      {/* <IWidgetLocalVariables
        locVar={widgetLocalVariable}
        updateLocVariable={updateLocVariable}
      /> */}

      <div className={styles.widgetButtonContainer}>
        <Button
          variant="contained"
          size="small"
          onClick={(e) => onGenerateChart(e, 'generate')}
          classes={{ root: styles.save_button }}
          disabled={isLoading.generate}
          startIcon={
            isLoading.generate ? (
              <CircularProgress sx={{ color: "#fff" }} size={15} />
            ) : (
              <InsightsOutlinedIcon />
            )
          }
        >
          Generate Chart
        </Button>
        <Button
          variant="outlined"
          size="small"
          onClick={() => updateConfig({}, false)}
          classes={{ root: styles.cancel_button }}
        >
          Cancel
        </Button>

        <Button
          variant="contained"
          size="small"
          onClick={(evt) => onExec(evt, 'execute')}
          classes={{ root: styles.exec_button }}
          disabled={isLoading.execute}
          startIcon={
            isLoading.execute ? (
              <CircularProgress sx={{ color: "#333" }} size={15} />
            ) : (
              <PlayCircleOutlineOutlinedIcon />
            )
          }
        >
          {isLoading.execute ? "Executing ..." : "Execute Query"}
        </Button>
      </div>
      <br />
      <div className={styles.terminalContainer}>
        {showTerminalEditor ? (
          <>
            <strong>Output:</strong>
            <TerminalEditor response={terminalApiResponse} />
          </>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
};

export default IWidgetConfig;
