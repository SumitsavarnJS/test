// exact API reponse
const customLabels = ['baseline v/s 17', 'baseline v/s 18'];
export const dummy = {
  data: {
    tooltip: {
      trigger: 'item',
      extraCssText:
        'display: inline-block; width: 300px; word-wrap:break-word; white-space: pre-line; overflow-wrap: break-word;',
      axisPointer: {
        type: 'shadow'
      }
    },
    legend: {
      top: "5%",
      left: 'center',
      type: 'scroll'
    },
    toolbox: {
      show: true,
      orient: 'vertical',
      top: 'center',
      right: 0,
      feature: {
        saveAsImage: {
          show: true,
          name: 'ddash',
          title: 'Save Image'
        }
      }
    },
    dataset: [
      {
        source: [
          [-1, 3, 7, 40, 8, 10, 11, 12, 15, 18],
          [4, 2, 3, 7, 8, 4, 15, 11, -10, 7]
        ]
      },
      {
        transform: {
          type: 'boxplot',
          config: {
            itemNameFormatter: function (params) {
              return customLabels[params.value];
            }
          }
        }
      },
      {
        fromDatasetIndex: 1,
        fromTransformResult: 1
      }
    ],
    grid: {
      left: '10%',
      right: '10%',
      bottom: '15%'
    },
    xAxis: {
      type: 'category',
      boundaryGap: true,
      nameGap: 80,
      splitArea: {
        show: false
      },
      splitLine: {
        show: false
      }
    },
    yAxis: {
      type: 'value',
      name: 'TDV Data',
      nameGap: 80,
      splitArea: {
        show: true
      }
    },
    series: [
      {
        name: 'TDV Data',
        type: 'boxplot',
        datasetIndex: 1
      },
      {
        name: 'outlier',
        type: 'scatter',
        datasetIndex: 2,
        encode: {
          itemName: 'product',
          value: '2012',
          tooltip: '2012'
        }
      }
    ]
  },
  theme: "light",
  labels: ['baseline v/s 17', 'baseline v/s 18']
};
