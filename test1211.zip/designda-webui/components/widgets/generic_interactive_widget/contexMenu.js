import * as utils from "../../../common/utils/utils";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";
import {
  addWidgetCommonFunction,
  showConfigUiState,
  widgets,
} from "../../../pages/rptdashboard/addWidget/addWidget";
import { produce } from "immer";
import refreshWidgetContent from "../../../pages/rptdashboard/wigetWrapper/widgetRefreshData";
import { showReportOnClick } from "../../../components/widgets/workflow_monitor_table/WorkflowMonitorTableApi";
import axios from "axios";
import _ from "lodash";

export const showToast = (toast) => {
  const uiState = produce(
    useGlobalStore.getState()[toast.widgetId].uiState,
    (uiStateDraft) => {
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastSeverity = _.get(toast, "severity", "info");
      uiStateDraft.toastMessage = _.get(toast, "message", "");
    }
  );
  useGlobalStore.getState().setWidgetUiState(toast.widgetId, uiState);
};

//create query which will be prepended
//this is creating a string which will declare variables in the query
const createPreQuery = (preQueryData) => {
  let preQuery = "";
  if (preQueryData && Object.entries(preQueryData).length > 0) {
    for (const [key, value] of Object.entries(preQueryData)) {
      // if (
      //   key.startsWith("__") &&
      //   !["__contextMenu", "__obtype", "__object", "__ttype"].includes(key) &&
      //   !key.includes("__META__")
      // ) {
      const newVal = typeof value === "number" ? value : `'${value}'`;
      preQuery = preQuery + `${key} = ${newVal}\n`;
      // }
    }
  }
  // console.log("----",  preQuery)
  return preQuery;
};

const addCustomWidgetOnClick = async (
  args,
  dataFromParent,
  contextMenuVars
) => {
  // console.log("called addCustomWidgetOnClick", args, dataFromParent);
  //new argument copy for config of the widget
  let argsCopy = _.cloneDeep(args);
  const wid = args.wid;
  delete argsCopy.wid;

  //handling scenario
  let scenario = null;
  if (args.hasOwnProperty("scenario")) {
    scenario = args.scenario;
    //delete sceanrio key as it is not needed in config
    delete argsCopy.scenario;
  }

  //root level data location from aprent widget and not the report
  let dataLocation = utils.getRootDirectory(
    dataFromParent.props.widgetProps.config.dataLocation
  );

  //change data location if given in argruments
  if (args.hasOwnProperty("dataLocation")) {
    dataLocation = args.dataLocation;
    delete argsCopy.dataLocation;
  }

  let bucket = dataFromParent.props.widgetProps.config.bucket;

  if (args.hasOwnProperty("bucket")) {
    bucket = args.bucket;
    delete argsCopy.bucket;
  }

  // add handle query
  const preQuery = createPreQuery(args.preQuery);

  // all other arguments left after wid, sceanrio, dataLocation , bucktes are handled
  // this copy of arguments will be merged with config from widget library
  let configCopy = argsCopy;

  //get widget Template from widget Library
  const wTemplate = await utils.getWidgetFromLib(wid);
  // if widget template exists -> proceed
  if (wTemplate) {
    if (Object.keys(wTemplate).length == 0) {
      const uiState = {
        isLoading: false,
        showConfig: false,
        isToastOpen: true,
        toastSeverity: "error",
        toastMessage:
          "Invalid widget id. Please configure context menu with valid 'wid' from widget library",
        cirlularLoading: false,
      };
      useGlobalStore
        .getState()
        .setWidgetUiState(dataFromParent.props.id, uiState);
      return;
    }

    //recuntruct the widget settings and config from template
    const settings = utils.getWidgetSettings(wTemplate.widget_name, wTemplate);

    //if scenario is given then add to data location
    if (scenario) {
      dataLocation = dataLocation + "/" + scenario;
    }

    let newConfig = _.cloneDeep(settings.config);

    // merging new config with arguments
    newConfig = { ...newConfig, ...configCopy };

    // over write data location and bucket with values that was handled earlier
    newConfig.dataLocation = dataLocation;
    newConfig.bucket = bucket;

    //handle query if exists
    if (newConfig.hasOwnProperty("query")) {
      newConfig.query = preQuery + newConfig.query;
    }

    //prepare final widget settings
    settings.config = newConfig;
    settings.h = widgets[wTemplate.widget_name].height;
    settings.w = widgets[wTemplate.widget_name].width;
    settings.y = dataFromParent.props.widgetProps.y + 1;
    settings.x = dataFromParent.props.widgetProps.x;
    settings.name = wTemplate.widget_name;
    settings.metaData = {
      description: _.get(wTemplate, "description", ""),
      tags: _.get(wTemplate, "tags", ""),
    };

    // add the new widget
    const newIdList = addWidgetCommonFunction(
      dataFromParent.props.rptType,
      dataFromParent.props.reportKey,
      settings,
      {},
      showConfigUiState,
      dataFromParent.props.index
    );

    // auto reload the new widget
    refreshWidgetContent({
      widgetId: newIdList[0],
      widgetName: wTemplate.widget_name,
      config: settings.config,
      reportKey: dataFromParent.props.reportKey,
      rptType: dataFromParent.props.rptType,
      variables: contextMenuVars,
    });

    // inform the user that widget is added
    showToast({
      reportName: dataFromParent.props.currentReportName,
      widgetId: dataFromParent.props.id,
      severity: "info",
      message: "Widget added below",
    });
  } else {
    // inform the user that widget ID does not exists
    showToast({
      reportName: dataFromParent.props.currentReportName,
      widgetId: dataFromParent.props.id,
      severity: "error",
      message:
        "Could not fetch template from widget Library. Please check provided widget ID",
    });
  }
};

const openReportOnClick = async (reportMetaData, childName, combinedVars) => {
  let payload = {
    bucket: reportMetaData.bucket,
    key: reportMetaData.key,
    report_type: reportMetaData.report_type,
    user: useConfigStore.getState().authLoginUser,
    child_name: childName,
  };
  //call for report heson fetch API
  const getReport = await showReportOnClick(payload, 'contextMenu', combinedVars);
};

const runWorkflowsOnClick = async (parentArgs, dataFromParent) => {
  // console.log("running workflows", dataFromParent);
  const url =
    useConfigStore.getState().configData.rest_server_url +
    `/api/workflow/suite/run`;

  // console.log("selected args", parentArgs);
  const payload = {
    ...parentArgs,
    args: { ...parentArgs.args, user: useConfigStore.getState().authLoginUser },
  };
  // const apiResponse = {'message': 'api called'}
  const apiResponse = await axios
    .post(url, payload)
    .then((response) => {
      // console.log("response", response);
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response.data;
        showToast({
          reportName: dataFromParent.props.currentReportName,
          widgetId: dataFromParent.props.id,
          severity: "success",
          message: "Workflow ran successfully",
        });

        return apiData;
      } else {
        showToast({
          reportName: dataFromParent.props.currentReportName,
          widgetId: dataFromParent.props.id,
          severity: "error",
          message: "Could not run workflows. Something went wrong!",
        });
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in executing the task";
      showToast({
        reportName: dataFromParent.props.currentReportName,
        widgetId: dataFromParent.props.id,
        severity: "error",
        message,
      });
    });
};


export const handleContextMenuAction = (
  actionName,
  args,
  propsObj,
  contextMenuVars,
  label,
  clickedContextMenuArgs
) => {

  const reportName = propsObj.props.currentReportName;
  const widgetId = propsObj.props.id;

  const showGenericErrorToast = (message) => {
    showToast({
      reportName,
      widgetId,
      severity: "error",
      message,
    });
  }

  switch (actionName) {
    case "addWidget":
      try{
        addCustomWidgetOnClick(args, propsObj, contextMenuVars);
      }
      catch(err) {
        showGenericErrorToast("Something went wrong in adding reports");
      }
      break;
    case "openReport":
      try {
        const reportKeyString = propsObj.props.reportKey;
        const reportObjInStore = useGlobalStore.getState().allReports[reportKeyString];
        const {report_metaData: reportMetaData, variables: parentVarsFromStore} = reportObjInStore;
        const combinedVars = {...parentVarsFromStore, ...clickedContextMenuArgs }
        openReportOnClick(reportMetaData, args.child_name, combinedVars);
      }
      catch(err) {
        showGenericErrorToast("Something went wrong in opening report");
      }
      break;
    case "runWorkflows":
      try {
        runWorkflowsOnClick(args, propsObj);
      }
      catch(err) {
        showGenericErrorToast("Something went wrong in running workflows");
      }
      break;
    default:
      showGenericErrorToast("Not a valid action");
  }
};
