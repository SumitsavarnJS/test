import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { produce } from "immer";
import { toast } from "react-toastify";
import interactiveWidgetApi from "../../../common/api/interactiveWidgetApi";
// import {dummy} from './dummy';
// import {lineChartData} from "./dummy";
import axios from "axios";
// import api from "../../../common/api/api";

// const { configData } = useConfigStore();
export const toastConfig = {
  position: toast.POSITION.BOTTOM_LEFT,
  style: {
    fontSize: "14px",
    padding: "8px 12px",
  },
};


const getIWidgetPayload = (config, chartType, widgetVariablesFromRefresh) => {
  const payload = {
    chart_type: chartType,
    raw_query: _.get(config, "query", ""),
    user: useConfigStore.getState().authLoginUser,
    variables : widgetVariablesFromRefresh,
    
    // .get(config, "wVariables", {})
  };

  // add columns if provided
  const columns = _.get(config, "columns", []);
  if (columns.length > 0) {
    payload["columns"] = config.columns;
  }
  return payload;
};

const fetchWidgetData = async (widgetId, payload) => {
    const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  // api call to get widget data
  const fetchData = await interactiveWidgetApi(
    useConfigStore.getState().configData.rest_server_url + "/cli/fetch_widget_data",
    payload
  );

  if (fetchData) {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  } 

  if (fetchData && fetchData.data && Object.keys(fetchData.data).length > 0) {
    // bow fetchdata is {data: {}, theme: ""}, take the entire data and set in store
    useGlobalStore.getState().setWidgetData(widgetId, fetchData);
  }
  else {
    const newUiState = produce(uiState, (uiStateDraft) => {
      uiStateDraft.isLoading = false;
      uiStateDraft.isToastOpen = true;
      uiStateDraft.toastMessage = fetchData?.message || 'Something went wrong!'
      uiStateDraft.toastSeverity = "error";
    });
    useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
    useGlobalStore.getState().setWidgetData(widgetId, {});

  }

};

// API to get context menu options
export const getContextMenuOptions = async (payload) => {
  const url = `${useConfigStore.getState().configData.rest_server_url}/cli/get_context_menu`;
  // console.log("calliong api with url", url)
  // console.log("calliong api with payload", payload)
  const apiResponse = await axios
  .post(url, payload)
  .then((response) => {
      // console.log({ response });
    const apiStatus = response.status;
    if (apiStatus === 200) {
      const apiData = response?.data;
      return apiData;
    } else {
      const toastMsg = "Something went wrong !";
      toast.error(toastMsg, toastConfig);
    }
  })
  .catch((err) => {
    const errMsg = err?.response?.data?.message;
    const message = errMsg
      ? errMsg
      : "An error occurred in fetching the data";
    toast.error(message, toastConfig);
  });
  // console.log('apiResponse', apiResponse)
  return apiResponse;
}

const refreshInteractiveWidget = (widgetId, config, chartType, variables) => {
  fetchWidgetData(widgetId, getIWidgetPayload(config, chartType, variables));
};

export default refreshInteractiveWidget;