

export const gantt_data = {
  data: {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow",
      },
      formatter: function (params) {
        // params is an array of objects, each array has 2 objects representing X and Y respectively
        // params.value has the actual value (timestamp)
        // params.axisValue has the axis value associated
        const Yobj = params[0];
        const Xobj = params[1];
        return (
          Yobj.axisValue +
          "<br/>" +
          "Start Time : " +
          convertTimestampToDateTime(Yobj.value) +
          "<br/>" +
          "End Time : " +
          convertTimestampToDateTime(Xobj.value)
        );
      },
    },
    grid: {
      left: "3%",
      right: "4%",
      bottom: "3%",
      containLabel: true,
    },
    yAxis: {
      type: "category",
      splitLine: { show: true },
      // all checkpoints - from API
      data: [
        "pt_signoff5",
        "pt_signoff2",
        "pt_signoff3",
        "pt_signoff1",
        "pt_signoff4",
      ],
    },
    xAxis: {
      type: "value",
      axisLabel: {
        rotate: 20,
        // formatter - convert axis label to a date-time format
        formatter: function (value) {
          return convertTimestampToDateTime(value);
        },
      },
    },
    series: [
      {
        name: "Start Time",
        type: "bar",
        stack: "Total",
        itemStyle: {
          borderColor: "transparent",
          color: "transparent",
        },
        emphasis: {
          itemStyle: {
            borderColor: "transparent",
            color: "transparent",
          },
        },
        // all start times - from API
        data: [1696928655, 1096918655, 1196938655, 696948655, 1616968655],
      },
      {
        name: "End Time",
        type: "bar",
        stack: "Total",
        // label: {
        //   show: false,
        //   position: "inside",
        // },
        // all end times - from API
        data: [1696929449, 1196920449, 1296959449, 796948655, 1636979449],
      },
    ],
  },
};
