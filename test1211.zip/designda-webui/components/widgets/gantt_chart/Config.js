import React, { useState, useEffect } from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import _ from "lodash";
import axios from "axios";
import DataSource from "../../../pages/rptdashboard/data_source/DataSource";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";
import { Box } from "@mui/material";
import { ClickAwayListener } from "@mui/base";
import refreshGanttChart from "./GanttChartApi";
import styles from "./Config.module.css";
// import AddBuildsPopup from "../../../pages/metrics/dialogs/AddBuildsPopup";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import {
  customInput,
  customFilter,
  timeFilter,
  dateFromSeconds,
} from "../../../common/filter";

const Config = (props) => {
  //   let tableRef = React.createRef();
  const preferenceProjectList = useConfigStore.getState().metricProjectName;
  const [tableInst, setTableInst] = useState(null);
  const { authLoginUser } = useConfigStore();
  const [title, setTitle] = useState(_.get(props.config, "title", ""));
  // const [dataLocation, setDataLocation] = useState(
  //   _.get(props.config, "dataLocation", "")
  // );
  // const [data, setData] = useState(_.get(props.config, "data", ""));
  // const [columns, setColumns] = useState(_.get(props.config, "columns", []));
  // const [bucket, setBucket] = useState(_.get(props.config, "bucket", ""));
  // const [showDataSource, setShowDataSource] = useState(false);
  // const [dataList, setDataList] = useState([]);
  // const [columnList, setColumnList] = useState([]);
  // const [isGetBuildsClicked, setGetBuildsClicked] = useState(false);

  const dateFormatter = (cell, formatterParams, onRendered) => {
    let seconds = cell.getValue();
    return dateFromSeconds(seconds);
  };

  // constant set of table columns
  const tableColumns = [
    {
      title: "Project",
      field: "PROJECT",
      sorter: "string",
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "Phase",
      field: "PHASE",
      sorter: "string",
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "Run Tag",
      field: "RUNTAG",
      sorter: "string",
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "Block",
      field: "BLOCK",
      sorter: "string",
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "User",
      field: "USER",
      sorter: "string",
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "User Label",
      field: "LABEL",
      sorter: "string",
      headerSortTristate: true,
      headerFilter: customInput,
      headerTooltip: "Support RegEx Filtering",
    },
    {
      title: "Checkpoint",
      field: "checkpoint",
      headerFilter: customInput,
    },
    {
      title: "Time Start",
      field: "timeStart",
      sorter: "string",
      sorterParams: {
        format: "yyyy-MM-dd HH:mm:ss",
        alignEmptyValues: "top",
      },
      formatter: dateFormatter,
      headerSortTristate: true,
    },
    {
      title: "Time Stop",
      field: "timeStop",
      sorter: "string",
      formatter: dateFormatter,
      headerSortTristate: true,
    },
  ];

  const initTable = () => {
    // if (tableInst === null && bucket.length > 0) {

      console.log("Instantiate Tabulator");
      const tableInstance = new Tabulator("#getBuildsTable", {
        // className: "table-sm table-striped table-bordered",
        layout: "fitDataStretch",
        selectableRows: true,
        // initialHeaderFilter: headerFilters,
        initialSort: [
          { column: "timeStart", dir: "desc" }, //sort by this first
        ],
        pagination: true, //enable pagination
        paginationMode: "remote", //enable remote pagination
        sortMode: "remote",
        filterMode: "remote",
        ajaxConfig: "POST",
        paginationSize: "10",
        paginationInitialPage: 1,
        paginationButtonCount: 5,
        // ajaxURL: metricsURL + "getBuilds/",
        ajaxURL:
          useConfigStore.getState().configData.rest_server_url +
          "/metrics/getBuilds/",
        ajaxContentType: "json",
        ajaxParams: {
          projects: preferenceProjectList,
        },
        ajaxResponse: (url, params, responseData) => {
          const tabulatorLoreFormat = {
            data: responseData.blds ? responseData.blds : [],
            last_page: responseData.lastPage ? responseData.lastPage : 0,
          };
          return tabulatorLoreFormat;
        },

        dataTree: true,
        dataTreeChildIndent: 25,
        paginationSizeSelector: [10, 15, 20, 25],
        dataTreeSort: false, //disable child row sorting
        columns: tableColumns,
        maxHeight: "1000px",
        movableRows: false,
        columnDefaults: {
          headerFilterPlaceholder: "...",
          headerFilterLiveFilter: false,
          headerTooltip: true,
        },
      });
      setTableInst(tableInstance)
  };

  useEffect(() => {
    if(preferenceProjectList.length > 0) {
      setTableInst(null);
      initTable();
    }
  }, [preferenceProjectList])

  // handler when user clicks OK button in Config
  const onOKButtonClick = () => {
    const selectedBuilds = tableInst.getSelectedData();
    console.log({ selectedBuilds });

    const config = {};
    // config["dataLocation"] = dataLocation;
    // config["bucket"] = bucket;
    config["selectedBuilds"] = selectedBuilds;
    config["user"] = authLoginUser;
    // add title only if user has provided it
    if (title.length > 0) {
      config["title"] = title;
    }
    // call a method to update the config
    props.updateConfig(config, true);
    // tableInst.destroy();
    // tableInst = null
    // setTableInst(null)
    // add a method to call 'refresh' fucntionality i.e api call
    refreshGanttChart(props.id, config);
  };

  return (
    <div className={styles.outer_div}>
      <div>
        <TextField
          fullWidth
          label="Title"
          size="small"
          value={title}
          InputLabelProps={{
            shrink: true,
          }}
          onChange={(event) => setTitle(event.target.value)}
          variant="outlined"
        />
      </div>

      {/* Show Project From Preference */}
      <Typography variant="subtitle1" className={styles.label}>
        Selected Project(s) :{" "}
        <strong>{preferenceProjectList.length === 0 ? "None" : preferenceProjectList.join(", ")}</strong>
      </Typography>
      <Typography
        variant="subtitle1"
        className={styles.label}
        style={{ visibility: preferenceProjectList.length > 0 ? "visible" : "hidden" }}
      >
        Builds for selected project(s) :
      </Typography>
      <div
        id="getBuildsTable"
        style={{
          width: "inherit",
          border: "1px solid",
          visibility: preferenceProjectList.length > 0 ? "visible" : "hidden",
          height: preferenceProjectList.length > 0 ? "100%" : 0,
        }}
        //   ref={(r) => {
        //     tableRef = r;
        //   }}
      ></div>

      <Button
        variant="contained"
        size="small"
        disabled={preferenceProjectList.length === 0}
        onClick={onOKButtonClick}
        classes={
          preferenceProjectList.length === 0
            ? { root: styles.save_button_disabled }
            : { root: styles.save_button }
        }
      >
        OK
      </Button>
      <Button
        variant="contained"
        size="small"
        onClick={() => props.updateConfig({}, false)}
        classes={{ root: styles.cancel_button }}
      >
        Cancel
      </Button>
    </div>
  );
};

export default Config;
