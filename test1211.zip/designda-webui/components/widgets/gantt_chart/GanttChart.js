// react imports
import React, { useState, useEffect } from "react";
import ReactEcharts from "echarts-for-react";
import _ from "lodash";
import Typography from "@mui/material/Typography";
import Config from "./Config";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";
import moment from "moment";
import styles from "./GanttChart.module.css";

function GanttChart(props) {
  const widgetId = props.id;
  const theme = useConfigStore.getState().theme;
  const [ganttData, setGanttData] = useState([]);
  const [scale, setScale] = useState({ minStart: 0, maxStop: 1000 });
  const dataFromAPI = _.get(useGlobalStore.getState()[widgetId], "data", {});

  useEffect(() => {
    // if data exists
    if (dataFromAPI && Object.keys(dataFromAPI).length > 0) {
      // console.log("effect", { dataFromAPI });
      // dataFromAPI is an array of objects
      const requiredArr = [];
      let mini = Math.pow(10, 1000);
      let maxi = -1;
      for (let i = 0; i < dataFromAPI.length; i++) {
        const obj = dataFromAPI[i];
        const { system__timeStart, system__timeStop, system__checkpoint } = obj;
        // some faulty data send time as string, so converting it to integer base 10
        const deducedObj = {
          system__timeStart: parseInt(system__timeStart),
          system__timeStop: parseInt(system__timeStop),
          system__interval:
            parseInt(system__timeStop) - parseInt(system__timeStart),
          system__checkpoint,
        };
        requiredArr.push(deducedObj);
        // console.log(deducedObj['system__timeStart'], deducedObj['system__timeStop'])
        if (deducedObj["system__timeStart"] < mini) {
          mini = deducedObj["system__timeStart"];
        }
        if (deducedObj["system__timeStop"] > maxi) {
          maxi = deducedObj["system__timeStop"];
        }
        if (
          obj.system__DMSARuntimeInfo &&
          obj.system__DMSARuntimeInfo !== null
        ) {
          let givenString = obj.system__DMSARuntimeInfo;
          // console.log("given string", obj.system__DMSARuntimeInfo);
          // since the required item is in string format and it CANNOT BE DIRECTLY PARSED
          let res = givenString.replace(/\'/g, '"');
          const parsedArray = JSON.parse(res);
          // console.log("====>", parsedArray);
          // map through parsed array and create new objects
          parsedArray.forEach((item) => {
            const scenarioObj = {};
            scenarioObj["system__timeStart"] = parseInt(item.timeStart);
            scenarioObj["system__timeStop"] = parseInt(item.timeStop);
            scenarioObj["system__interval"] =
              parseInt(item.timeStop) - parseInt(item.timeStart);
            scenarioObj["system__checkpoint"] = item.checkpoint;
            requiredArr.push(scenarioObj);
            if (scenarioObj["system__timeStart"] < mini) {
              mini = scenarioObj["system__timeStart"];
            }
            if (scenarioObj["system__timeStop"] > maxi) {
              maxi = scenarioObj["system__timeStop"];
            }
          });
        }
      }
      // console.log("modified data", requiredArr);
      // console.log(mini, maxi);
      setScale({ minStart: mini, maxStop: maxi });
      setGanttData(requiredArr);
    }
  }, [dataFromAPI]);
  // Function to update config
  const updateConfig = (config, save) => {
    // if user has refreshed, save the data in store
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(props.rptType, props.reportKey, props.id, config);
    }

    useGlobalStore.getState().setWidgetUiState(props.id, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };
  const convertTimestampToDateTime = (val) => {
    // convert unix timestamp to
    const result = moment(val * 1000).format("DD-MM-YYYY h:mm:ss");
    return result;
  };

  const getEchartsOption = (chartData) => {
    // console.log({ chartData });
    const option = {
      tooltip: {
        trigger: "axis",
        responsive: true,
        backgroundColor: "rgb(247, 227, 250)",
        axisPointer: {
          type: "shadow",
        },
        formatter: function (params) {
          // params is an array of objects, each array has 2 objects representing X and Y respectively
          // params.value has the actual value (timestamp)
          // params.axisValue has the axis value associated
          // console.log({params})
          const Yobj = params[0];
          const Xobj = params[1];
          return (
            `<h6><strong>${Yobj.axisValue}</strong></h6>` +
            "<br/>" +
            `<table><tr><td>Start Time &nbsp;</td><td><b>${convertTimestampToDateTime(
              Yobj.data
            )}</b></td></tr>` +
            `<tr><td>End Time &nbsp;</td><td><b>${convertTimestampToDateTime(
              Xobj.data + Yobj.data
            )}</b></td></tr></table>`
          );
        },
      },
      grid: {
        left: "3%",
        right: "4%",
        bottom: "3%",
        containLabel: true,
      },
      yAxis: {
        type: "category",
        splitLine: { show: true },
        // all checkpoints - from API
        // data: [
        //   "pt_signoff5",
        //   "pt_signoff2",
        //   "pt_signoff3",
        //   "pt_signoff1",
        //   "pt_signoff4",
        // ],
        data: chartData.map((obj) => obj.system__checkpoint),
      },
      xAxis: {
        type: "value",
        axisLabel: {
          rotate: 20,
          // formatter - convert axis label to a date-time format
          formatter: function (value) {
            return convertTimestampToDateTime(value);
          },
        },
        min: scale.minStart,
        max: scale.maxStop,
      },
      // dataZoom: [
      //   {
      //     show: true,
      //     // yAxisIndex: 0,
      //     xAxisIndex: 0,
      //   },
      //   // {
      //   //   type: "inside",
      //   //   // yAxisIndex: 0,
      //   //   xAxisIndex: 0,
      //   // },
      // ],
      series: [
        {
          name: "Start Time",
          type: "bar",
          stack: "Total",
          itemStyle: {
            borderColor: "transparent",
            color: "transparent",
          },
          emphasis: {
            itemStyle: {
              borderColor: "transparent",
              color: "transparent",
            },
          },
          // all start times - from API
          // data: [1696928655, 1096918655, 1196938655, 696948655, 1616968655],
          data: chartData.map((obj) => obj.system__timeStart),
        },
        {
          name: "End Time",
          type: "bar",
          stack: "Total",
          // label: {
          //   show: false,
          //   position: "inside",
          // },
          // all end times - from API
          // data: [1696929449, 1196920449, 1296959449, 796948655, 1636979449],
          data: chartData.map((obj) => obj.system__interval),
        },
      ],
    };
    return option;
  };

  // get ui-state from global state
  const uiState = _.get(useGlobalStore.getState()[props.id], "uiState", {
    showConfig: false,
  });

  // render components (Config and ReactECharts) conditionally
  return (
    <>
      {uiState.showConfig ? (
        <Config
          updateConfig={updateConfig}
          config={props.config}
          id={props.id}
        />
      ) : ganttData && ganttData.length === 0 ? (
        <Typography variant="h5" className={styles.text} align="center">
          No data to view. Please refresh!
        </Typography>
      ) : (
        <div className={styles.chartParent}>
          <ReactEcharts
            // ref={chartRef}
            style={{
              height: "100%",
              width: "100%",
              // backgroundColor: theme == "dark" ? "rgb(50,50,50)" : "",
            }}
            option={getEchartsOption(ganttData)}
            // theme={theme}
            notMerge={true}
          />
        </div>
      )}
    </>
  );
}

export default GanttChart;

GanttChart.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
