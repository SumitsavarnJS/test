import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { produce } from "immer";
import { gantt_data } from "./dummydata";

import api from "../../../common/api/api";

const getGanttChartInput = (config) => {
  // console.log("final config", config);
  const selectedBuilds = _.get(config, "selectedBuilds", []);
  const user = _.get(config, "user", "");
  // generate payload
  const input = {
    selectedBuilds: selectedBuilds,
    report: {
      compare_system: {
        reportInfo: {
          menuName: "System",
          menuGroup: "Compare",
          reportClass: "TableCompareReport",
        },
        metrics: {
          "system|timeStart": {
            groupName: "Time",
            indexList: [
              "$buildName",
              "checkpoints",
              "$checkpointName",
              "sum",
              "info",
              "system",
              "data",
              "timeStart",
            ],
          },
          "system|timeStop": {
            groupName: "Time",
            indexList: [
              "$buildName",
              "checkpoints",
              "$checkpointName",
              "sum",
              "info",
              "system",
              "data",
              "timeStop",
            ],
          },
          "system|DMSARuntimeInfo": {
            groupName: "Time",
            indexList: [
              "$buildName",
              "checkpoints",
              "$checkpointName",
              "sum",
              "info",
              "system",
              "data",
              "DMSARuntimeInfo",
            ],
          },
          "system|checkpoint": {
            groupName: "Tags",
            indexList: [
              "$buildName",
              "checkpoints",
              "$checkpointName",
              "sum",
              "info",
              "system",
              "data",
              "checkpoint",
            ],
          },
        },
      },
    },
    hierSpec: [],
    auth: {
      user: user,
    },
    displayMode: "VALUE",
    referenceMode: false,
    baseline: "",
    filter: [],
    page: 1,
    size: 25,
    sort: [],
  };

  return input;
};

const fetchWidgetData = async (widgetId, input) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  console.log({ input });
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  // api call to get gantt chart data [options]
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      "/metrics/runMetricsQuery/",
    input
  );
  // const fetchData = gantt_data;
  // console.log("gantt fetchData", fetchData);
  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);
  if (fetchData && fetchData.rows && Object.keys(fetchData.rows).length) {
    useGlobalStore.getState().setWidgetData(widgetId, fetchData.rows);
  }
};

const refreshGanttChart = (widgetId, config) => {
  fetchWidgetData(widgetId, getGanttChartInput(config));
};

export default refreshGanttChart;
