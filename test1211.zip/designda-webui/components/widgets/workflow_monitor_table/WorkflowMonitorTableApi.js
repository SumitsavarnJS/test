/* eslint-disable no-prototype-builtins*/
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import _ from "lodash";
import { produce } from "immer";
import { toast } from "react-toastify";
import axios from "axios";
import api from "../../../common/api/api";
import refreshWidgetContent from "../../../pages/rptdashboard/wigetWrapper/widgetRefreshData";

const toastConfig = {
  position: toast.POSITION.BOTTOM_LEFT,
  style: {
    fontSize: "14px",
    padding: "8px  12px",
  },
};

// dictionary to hold type and endpoint relation
const endpointDict = {
  kill: "terminate",
  retry: "retry",
  rerun: "rerun",
  delete: "delete",
  run: "run",
};

const fetchWidgetData = async (widgetId, inputData) => {
  const uiState = {
    isLoading: true,
    showConfig: false,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
    cirlularLoading: false,
  };
  useGlobalStore.getState().setWidgetUiState(widgetId, uiState);
  // api call to get workflow data
  const fetchData = await api(
    useConfigStore.getState().configData.rest_server_url +
      // "/api/workflow/suite/status",
      "/api/workflow/monitor_table",
    inputData
  );

  // stop loading once you have all the necessary data
  const newUiState = produce(uiState, (uiStateDraft) => {
    uiStateDraft.isLoading = false;
  });

  useGlobalStore.getState().setWidgetUiState(widgetId, newUiState);

  if (fetchData && fetchData.workflow_suites) {
    // update global store with newly fetched data
    useGlobalStore.getState().setWidgetData(widgetId, fetchData);
  }
};

export const getLogDetails = async (suite_name, log_path) => {
  const url =
    useConfigStore.getState().configData.rest_server_url +
    "/api/workflow/suite/log";
  const payload = { suite_name: suite_name, log_rel_path: log_path };

  const logApiResponse = await axios
    .post(url, payload)
    .then((response) => {
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response.data;
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching the log data";
      toast.error(message, toastConfig);
    });
  return logApiResponse;
};

export const downloadNDMData = async (suite_name, user, workflow_name) => {
  const url =
    useConfigStore.getState().configData.rest_server_url +
    "/api/workflow/download_flow";
  const payload = { suite_name, user, workflow_name };

  const apiResponse = await axios
    .post(url, payload)
    .then((response) => {
      // console.log("apiResponse NDM", response);
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response.data;
        return apiData;
      } else {
        const toastMsg = "Something went wrong in downloading NDM data!";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in downloading NDM data";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

const reportRoute = (reportInfo) => {
  axios
    .post(
      `${
        useConfigStore.getState().configData.rest_server_url
      }/api/update_reports_info`,
      {
        data: reportInfo,
        user: useConfigStore.getState().authLoginUser,
      }
    )
    .then((response) => {
      console.log(response);
    })
    .catch((error) => {
      // Handle error here, e.g. show error message
      console.error(error);
      const errMsg = error?.message ? error.message : "Something went wrong!";
      toast.error(errMsg, toastConfig);
    });
};

export const showReportOnClick = async (
  payload,
  trigger = "primary",
  parentVars = {}
) => {
  const url =
    useConfigStore.getState().configData.rest_server_url +
    "/api/fetch_report_data";

  const clickedReportsApiResponse = await axios
    .post(url, payload)
    .then((response) => {
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response.data;
        if (
          response.data &&
          typeof response.data.data[0] === "object" &&
          response.data.data[0] !== null
        ) {
          // Handle success here, e.g. update state or show success message
          reportRoute(response.data.data[0]);

          const rptName = response.data.data[0].fileName;
          let rptData = response.data.data[0];
          useConfigStore.getState().addClickedJson(rptName);
          toast.info("Report Added To Queue", toastConfig);

          //if widget order is given separately
          if (response.data.data[0].widgetsOrder) {
            const widgetsOrder = response.data.data[0].widgetsOrder;
            //clone rpt data to set new order
            let rptDataClone = _.cloneDeep(rptData);
            delete rptDataClone.widgets;
            rptDataClone["widgets"] = {};

            //add widgets according to the new order given
            for (let index = 0; index < widgetsOrder.length; index++) {
              rptDataClone["widgets"][widgetsOrder[index]] =
                rptData["widgets"][widgetsOrder[index]];
            }

            // set the new ordered data report
            rptData = rptDataClone;
          }
          // update rptData -> variables only when this method is called via contextMenu
          if(trigger === 'contextMenu') {
            rptData["variables"] = {...rptData["variables"], ...parentVars}
          }

          useGlobalStore.getState().updateGlobalObject(rptName, rptData);
          if (rptData.hasOwnProperty("widgets")) {
            for (const Wkey in rptData.widgets) {
              let WkeyObj = {
                data: {},
                uiState: {
                  isLoading: false,
                  showConfig: false,
                  isToastOpen: false,
                  toastSeverity: "info",
                  toastMessage: "",
                  cirlularLoading: false,
                },
              };
              useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
            }
          }

          const widgetArray = Object.keys(rptData.widgets);

          for (let i = 0; i < widgetArray.length; i++) {
            const widgetId = widgetArray[i];
            const config = rptData.widgets[widgetId].config;
            const name = rptData.widgets[widgetId].name;
            const rptType = rptData.widgets[widgetId]?.rptType
              ? rptData.widgets[widgetId]?.rptType
              : "";
            const reportKey = rptData.widgets[widgetId]?.reportKey
              ? rptData.widgets[widgetId]?.reportKey
              : "";
            const rptDataVariablesCheck =
              rptData.hasOwnProperty("variables") && rptData?.variables
                ? rptData.variables
                : {};
            const widgetVariables =
              Object.keys(rptDataVariablesCheck).length > 0
                ? rptDataVariablesCheck
                : {};
            refreshWidgetContent({
              widgetId: widgetId,
              config: config,
              widgetName: name,
              reportKey: reportKey,
              rptType: rptType,
              variables: widgetVariables ? widgetVariables : {}
            });
            //condition to open the clicked report as current report in tabbed view
            if (useGlobalStore.getState().analyticsReportView.view === "tab") {
              useGlobalStore
                .getState()
                .setRootLevelData("analyticsReportView", {
                  view: "tab",
                  currentTab: rptName,
                });
            }

          }
        } else {
          toast.error(response.data.message, toastConfig);
        }
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in fetching the report";
      toast.error(message, toastConfig);
    });
  return clickedReportsApiResponse;
};

const refreshWorkflowMonitorTable = (widgetId, payload, config = {}) => {
  // on the very first load, there won't be any payload
  // so generate payload from config
  // for other calls, payload is always present, hence check payload in params
  const configExists = Object.keys(config).length > 0;
  const payloadFromParamsExists = Object.keys(payload).length > 0;
  if (payloadFromParamsExists) {
    fetchWidgetData(widgetId, payload);
  } else {
    if (configExists) {
      let payloadFromConfig = {
        page_size: 5,
        page: 1,
        states: config.require_all_status ? [] : config.status,
        project: "", // change when filter is applied
        user: "", // change when filter is applied
        with_reports_only: config.show_only_available_reports,
        target_workflows: "", // change when filter is applied
        name: "", // change when filter is applied
      };
      const payloadName = `wmtPayload_${widgetId}`;
      useGlobalStore.getState().setRootLevelData(payloadName, payload);
      fetchWidgetData(widgetId, payloadFromConfig);
    } else {
      console.error("Config and Payload, do not exist");
    }
  }
};

// common handler for various menu options (retry, rerun, kill, delete)
export const contextMenuHandler = async (
  type,
  suite_name,
  user,
  widgetId,
  payloadFromParent
) => {
  // based on type change the endpoint
  const endpoint = endpointDict[type];

  const url =
    useConfigStore.getState().configData.rest_server_url +
    `/api/workflow/suite/${endpoint}`;

  const payload =
    type === "run" ? { suite_name, user, new: false } : { suite_name, user };
  // const apiResponse = {'message': 'api called'}
  const apiResponse = await axios
    .post(url, payload)
    .then((response) => {
      const apiStatus = response.status;
      if (apiStatus === 200) {
        const apiData = response.data;
        // mind the refresh !!
        refreshWorkflowMonitorTable(widgetId, payloadFromParent);
        return apiData;
      } else {
        const toastMsg = "Something went wrong !";
        toast.error(toastMsg, toastConfig);
      }
    })
    .catch((err) => {
      const errMsg = err?.response?.data?.message;
      const message = errMsg
        ? errMsg
        : "An error occurred in executing the task";
      toast.error(message, toastConfig);
    });
  return apiResponse;
};

export default refreshWorkflowMonitorTable;
