import React, { useState } from "react";
import _ from "lodash";
import {
  Button,
  Checkbox,
  FormControlLabel,
  FormLabel,
  FormGroup,
  Switch,
  TextField,
} from "@mui/material";
import refreshWorkflowMonitorTable from "./WorkflowMonitorTableApi";
import useConfigStore from "../../../store/useConfigStore";
import styles from "./Config.module.css";

// colors for various status buttons
export const statusColors = {
  new: "#65e6fc",
  success: "#57f79c",
  failed: "#fc6c62",
  running: "#5797f7",
  queued: "#f7b757",
  killed: "#dedede",
  awaiting_upstream: "#f2b185",
  upstream_failed: "#f78157",
  killing: "#f77257",
  scheduled: "#be89fa",
  skipped: "#fff",
  up_for_retry: "#aff757",
  deferred: "#cff757",
  pending_license: "#f7e757",
};

const Config = (props) => {
  const {
    setRootLevelData,
  } = useConfigStore();

  const [title, setTitle] = useState(_.get(props.config, "title", ""));
  const statusListFromProps = _.get(props.config, "status", []);
  const requireAllStatus = _.get(props.config, "require_all_status", false);
  const [statusSelectedList, setStatusSelectedList] =
    useState(statusListFromProps);
  const [isParentCheckboxSelected, setParentCheckbox] =
    useState(requireAllStatus);
  const [showOnlyAvailableReports, setShowOnlyAvailableReports] = useState(
    _.get(props.config, "show_only_available_reports", true)
  );

  // status'es to be selected by User
  const statusOptions = {
    new: "New",
    success: "Success",
    failed: "Failed",
    running: "Running",
    queued: "Queued",
    killed: "Killed",
    awaiting_upstream: "Awaiting Upstream",
    // following status are not required in selection
    // pending_license: "Pending License",
    // skipped: "Skipped",
    // scheduled: "Scheduled",
    // killing: "Killing",
    // upstream_failed: "Upstream failed",
    // up_for_retry: "Up for retry",
    // up_for_reschedule: "Up for reschedule",
  };

  const onToggle = (event) => {
    setShowOnlyAvailableReports(event.target.checked);
  };
  // handler when user clicks OK button in Config
  const onOKButtonClick = () => {
    const config = {};
    config["status"] = statusSelectedList;
    config["require_all_status"] = isParentCheckboxSelected;
    config["show_only_available_reports"] = showOnlyAvailableReports;
    // add title only if user has provided it
    if (title.length > 0) {
      config["title"] = title;
    }
    // call a method to update the config
    props.updateConfig(config, true);
    // call 'refresh' functionality i.e api call
    const payload = {
      page_size: 5,
      page: 1,
      states: isParentCheckboxSelected ? [] : statusSelectedList,
      project: "", // change when filter is applied
      user: "", // change when filter is applied
      with_reports_only: showOnlyAvailableReports,
      target_workflows: "", // change when filter is applied
      name: "", // change when filter is applied
    }
    const payloadName = `wmtPayload_${props.id}`
    setRootLevelData(payloadName, payload);
    refreshWorkflowMonitorTable(props.id, payload);
  };

  const onChangeStatus = (evt) => {
    const isChecked = evt.target.checked;
    const value = evt.target.value;
    if (isChecked) {
      setStatusSelectedList([...statusSelectedList, evt.target.value]);
    } else {
      setParentCheckbox(false);
      const newStatusList = statusSelectedList.filter(
        (status) => status !== value
      );
      setStatusSelectedList(newStatusList);
    }
  };

  const onCheckParentCheckbox = (evt) => {
    const currBool = !isParentCheckboxSelected;
    setParentCheckbox(!isParentCheckboxSelected);
    // whenever parent checkbox is selected / checked -> select all possible statuses
    if (currBool) {
      // select all the statuses
      const allPossibleStatuses = Object.keys(statusOptions);
      setStatusSelectedList(allPossibleStatuses);
    } else {
      // unselect all statuses
      setStatusSelectedList([]);
    }
  };

  return (
    <div className={styles.outer_div}>
      {/* title textbox */}
      <TextField
        fullWidth
        label="Title"
        size="small"
        value={title}
        InputLabelProps={{
          shrink: true,
        }}
        onChange={(event) => setTitle(event.target.value)}
        variant="outlined"
      />
      {/* checkbox group */}
      <FormLabel className={styles.radio_label}>Select State:</FormLabel>
      <FormGroup row>
        <FormControlLabel
          key="all"
          value="all"
          control={<Checkbox />}
          label="Select all"
          onChange={onCheckParentCheckbox}
          checked={isParentCheckboxSelected}
        />
        {Object.entries(statusOptions).map((optionArr) => (
          <FormControlLabel
            key={optionArr[0]}
            value={optionArr[0]}
            control={<Checkbox />}
            label={optionArr[1]}
            onChange={onChangeStatus}
            checked={statusSelectedList.includes(optionArr[0])}
          />
        ))}
      </FormGroup>
      {/* buttons */}
      {/* switch for available reports */}
      <FormLabel className={styles.radio_label}>Report availability:</FormLabel>
      <FormGroup sx={{width: 'fit-content'}}>
        <FormControlLabel
        className={showOnlyAvailableReports ? '' : styles.show_dimmed_text}
          control={
            <Switch checked={showOnlyAvailableReports} onChange={onToggle} />
          }
          // labelPlacement="start"
          label="Show workflows with available reports"
        />
      </FormGroup>
      <Button
        variant="contained"
        size="small"
        disabled={statusSelectedList.length === 0}
        onClick={onOKButtonClick}
        classes={
          statusSelectedList.length === 0
            ? { root: styles.save_button_disabled }
            : { root: styles.save_button }
        }
      >
        OK
      </Button>
      <Button
        variant="contained"
        size="small"
        onClick={() => props.updateConfig({}, false)}
        classes={{ root: styles.cancel_button }}
      >
        Cancel
      </Button>
    </div>
  );
};

export default Config;
