/*eslint-disable no-unused-vars */
/*eslint-disable no-inner-declarations */
// react imports
import * as React from "react";
import { useState, useEffect, useRef } from "react";
import {
  Button,
  Tooltip,
  Typography,
  Pagination,
  Select,
  MenuItem,
  Skeleton,
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Slide,
} from "@mui/material";
import { ReactTabulator, reactFormatter } from "react-tabulator";
import {
  getLogDetails,
  showReportOnClick,
  contextMenuHandler,
  downloadNDMData,
} from "./WorkflowMonitorTableApi";
import Config, { statusColors } from "./Config";
import CloseIcon from "@mui/icons-material/Close";
import CheckIcon from "@mui/icons-material/Check";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import useGlobalStore from "../../../store/useGlobalStore";
import useConfigStore from "../../../store/useConfigStore";
import "react-tabulator/css/bootstrap/tabulator_bootstrap4.min.css";
import { toast } from "react-toastify";
import api from "../../../common/api/api";
import _ from "lodash";
import clipboardCopy from "clipboard-copy";

import styles from "./WorkflowMonitorTable.module.css";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const WorkflowMonitorTable = (props) => {
  // component constants
  const widgetId = props.id;

  const { authLoginUser, setRootLevelData } = useConfigStore();
  const wmtPayload = useConfigStore.getState()[`wmtPayload_${widgetId}`];
  const theme = useConfigStore.getState().theme;
  const uiState = _.get(useGlobalStore.getState()[widgetId], "uiState", {
    showConfig: true,
  });

  const [showNDMPopup, setShowNDMPopup] = useState(false);
  const [NDMMessage, setNDMMessage] = useState({});
  const [isDownloading, setIsDownloading] = useState(false);
  const [isCopiedToClipboard, setCopiedToClipboard] = useState({});

  // get data of widget using widget Id, actual data from API
  const workflowDataFromResponse = useGlobalStore.getState()[widgetId].data;
  const statusListForWidget = props.config.status ? props.config.status : [];

  const allStatusSelected = props.config.require_all_status
    ? props.config.require_all_status
    : false;

  const showOnlyAvailableReports = props.config.show_only_available_reports;
  const paginationRowsCount = [5, 10, 25, 50];

  // initialise states
  const apiData = workflowDataFromResponse?.workflow_suites;
  const [workflowData, setWorkflowData] = useState(
    apiData ? JSON.parse(JSON.stringify(apiData)) : []
  );
  // before initialising page size and page, check if wmtPayload has it
  const [page, setPage] = useState(wmtPayload?.page ? wmtPayload.page : 1);
  const [rowsPerPage, setRowsPerPage] = useState(
    wmtPayload?.page_size ? wmtPayload.page_size : 5
  );
  const [countPages, setCountPages] = useState(
    Math.ceil(workflowDataFromResponse?.total / rowsPerPage)
  );
  const [isTableLoading, setIsTableLoading] = useState(false);
  const prevPageRef = useRef(page);
  const prevRowsPerPageRef = useRef(rowsPerPage);

  // before initialising filterRef, check if wmtPayload has it
  const filterRef = useRef({
    project: wmtPayload?.project ? wmtPayload.project : "",
    target_workflows: wmtPayload?.target_workflows
      ? wmtPayload.target_workflows
      : "",
    user: wmtPayload?.user ? wmtPayload.user : "",
    name: wmtPayload?.name ? wmtPayload.name : "",
  });

  const toastConfig = {
    position: toast.POSITION.BOTTOM_LEFT,
    style: {
      fontSize: "14px",
      padding: "8px 12px",
    },
  };

  const applyTheme = (theme) =>
    theme == "dark"
      ? "table-sm table-dark table-striped table-bordered"
      : "table-sm table-striped table-bordered";

  const FormatTargetWorkflow = (props) => {
    const rowData = props.cell._cell.row.data;
    return Array.isArray(rowData.target_workflows)
      ? rowData.target_workflows.join(", ")
      : rowData.target_workflows;
  };

  const FormatWorkflowState = (props) => {
    const rowData = props.cell._cell.row.data;
    const stateValue = rowData.state;
    const bgColor = statusColors[stateValue];
    return (
      <div
        className={styles.workflowState}
        style={{ backgroundColor: bgColor ? bgColor : "#f0f0f0" }}
      >
        {stateValue}
      </div>
    );
  };

  const getFileStructure = (arr) => {
    const fileStructure = {};
    if (arr && arr.length > 0) {
      const val = arr.map((item) => {
        const [title, fileName] = item.split("/");
        if (fileStructure[title]) {
          fileStructure[title].push(fileName);
        } else {
          fileStructure[title] = [];
          fileStructure[title].push(fileName);
        }
        return fileStructure;
      });
      return val[val.length - 1];
    }
    return null;
  };

  const onClickReport = async (key, doc_type, node, filePath) => {
    const indexVal = key.indexOf("/");
    const firstPart = key.slice(0, indexVal);
    const secondPart = key.slice(indexVal + 1);
    const reportFinalKey = `${node}#${doc_type}/${secondPart}`;

    let report_type_val = "";
    if (doc_type === "task_reports") {
      report_type_val = "task";
    } else if (doc_type === "flow_reports") {
      report_type_val = "flow";
    } else if (doc_type === "techlib_reports") {
      report_type_val = "techlib";
    } else {
      report_type_val = "custom";
    }

    let payload = {
      bucket: firstPart,
      key: reportFinalKey,
      report_type: report_type_val,
      user: authLoginUser,
      child_name: filePath,
    };
    const getReport = await showReportOnClick(payload);
  };

  const FormatShowReports = (props) => {
    const rowData = props.cell._cell.row.data;
    const reportForRow = rowData.report;
    if (typeof reportForRow === "object") {
      const { children, key, doc_type, node } = reportForRow;
      const storeFileStructure = getFileStructure(children);
      return storeFileStructure === null ? (
        <span>No Reports Found</span>
      ) : (
        <table>
          {Object.entries(storeFileStructure).map((fileArr, index) => {
            return (
              <React.Fragment key={`${key}_${index}`}>
                <thead>
                  <tr className={styles.reportTableRow}>
                    <th>{fileArr[0]}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className={styles.reportTableRow}>
                    {fileArr[1].map((fileName, idx) => {
                      const filePath = `${fileArr[0]}/${fileName}`;
                      return (
                        <td
                          key={`${key}_${fileName}_${idx}`}
                          className={styles.reportTableData}
                          onClick={() =>
                            onClickReport(key, doc_type, node, filePath)
                          }
                        >
                          {fileName}
                        </td>
                      );
                    })}
                  </tr>
                </tbody>
              </React.Fragment>
            );
          })}
        </table>
      );
    }
    return <span>{reportForRow}</span>;
  };

  const FormatProgress = (props) => {
    const rowData = props.cell._cell.row.data;
    if (rowData.progress && rowData.progress !== undefined) {
      const { success, failed, running, queued, awaiting, total } =
        rowData.progress;
      const stats = [
        `Success: ${success}`,
        `Running: ${running}`,
        `Queued: ${queued}`,
        `Awaiting: ${awaiting}`,
        `Failed: ${failed}`,
        `Total: ${total}`,
      ];
      const getProgressVal = (val, tot) => {
        const percentage = (val / tot) * 100;
        return percentage % 1 ? percentage.toFixed(1) : percentage;
      };
      // calculate progress values
      const successProgressVal = getProgressVal(success, total);
      const failedProgressVal = getProgressVal(failed, total);
      const runningProgressVal = getProgressVal(running, total);
      const queuedProgressVal = getProgressVal(queued, total);
      const awaitingProgressVal = getProgressVal(awaiting, total);

      return (
        <Tooltip
          title={
            <div style={{ whiteSpace: "pre-line" }}>{stats.join("\n")}</div>
          }
        >
          <div className={styles.progressDiv}>
            {successProgressVal > 0 ? (
              <div
                className={styles.progressSuccess}
                style={{ width: `${successProgressVal}%` }}
              >
                {successProgressVal}%
              </div>
            ) : (
              <></>
            )}
            {runningProgressVal > 0 ? (
              <div
                className={styles.progressRunning}
                style={{ width: `${runningProgressVal}%` }}
              >
                {runningProgressVal}%
              </div>
            ) : (
              <></>
            )}
            {queuedProgressVal > 0 ? (
              <div
                className={styles.progressQueued}
                style={{ width: `${queuedProgressVal}%` }}
              >
                {queuedProgressVal}%
              </div>
            ) : (
              <></>
            )}
            {awaitingProgressVal > 0 ? (
              <div
                className={styles.progressAwaiting}
                style={{ width: `${awaitingProgressVal}%` }}
              >
                {awaitingProgressVal}%
              </div>
            ) : (
              <></>
            )}
            {failedProgressVal > 0 ? (
              <div
                className={styles.progressFailed}
                style={{ width: `${failedProgressVal}%` }}
              >
                {failedProgressVal}%
              </div>
            ) : (
              <></>
            )}
          </div>
        </Tooltip>
      );
    }
    return <span>-</span>;
  };

  // handlers for context-menu options
  const onOpenLog = async (row, type) => {
    const rowData = row.getData();
    const suiteName = rowData.name;
    let logPath = rowData.log_file;
    let errPath = rowData.state === "failed" ? rowData.err_file : null;
    let workFlowName = Array.isArray(rowData.target_workflows)
      ? rowData.target_workflows.join("|")
      : rowData.target_workflows;

    const logData = await getLogDetails(
      suiteName,
      type === "error-log-btn" ? errPath : logPath
    );
    if (logData) {
      // show a success toast
      const toastMsg = "Log file has been fetched successfully";
      toast.success(toastMsg, toastConfig);
      const documentTitle = `${workFlowName} : ${suiteName}`;
      const newTabLogOpen = window.open("", "_blank");
      newTabLogOpen.document.write(
        `<title>${documentTitle}</title> <pre>${logData}</pre>`
      );
    }
  };

  const onContextMenuOptionClick = async (type, row) => {
    const rowData = row.getData();
    const suiteName = rowData.name;
    const payload = {
      page_size: rowsPerPage,
      page: page,
      states: allStatusSelected ? [] : statusListForWidget,
      project: filterRef.current.project,
      user: filterRef.current.user,
      target_workflows: filterRef.current.target_workflows,
      name: filterRef.current.name,
      with_reports_only: showOnlyAvailableReports,
    };

    const respData = await contextMenuHandler(
      type,
      suiteName,
      authLoginUser,
      widgetId,
      payload
    );
    if (respData) {
      // show a success toast
      const toastMsg = respData.message
        ? respData.message
        : `Request executed successfully`;
      toast.success(toastMsg, toastConfig);
      // error case is handled in API file
    }
  };

  const onDownloadNDM = async (row, type) => {
    try {
      setIsDownloading(true);
      const rowData = row.getData();
      const suiteName = rowData.name;
      const workflowName = rowData.target_workflows;
      // console.log({ rowData, suiteName });
      const ndmData = await downloadNDMData(
        suiteName,
        authLoginUser,
        workflowName
      );
      // console.log("ndmData", ndmData);
      if (ndmData && ndmData.message) {
        setNDMMessage(ndmData);
        setShowNDMPopup(true);
      }
    } catch (err) {
      console.error("NDM download error !");
    } finally {
      setIsDownloading(false);
    }
  };

  const getRowContextMenu = (e, row) => {
    const rowData = row.getData();
    const isWorkflow = !Array.isArray(rowData.target_workflows);
    // this btn will be disabled for non-failed states and parents
    const disableErrorLogBtn =
      rowData.state !== "failed" || rowData._children !== undefined;

    // this btn will be enabled for failed states and stages only
    const enableErrorLogBtn =
      rowData.state === "failed" && rowData._children === undefined;

    // its a suite if it has children but no stages
    const isSuite =
      rowData._children !== undefined && rowData.stages === undefined;

    // Run to be available only for "new" states at a suite level
    const runSuiteCondition = rowData.state === "new" && isSuite;

    // Re-Try and Re-Run to be available only for "failed" | "killed" states at a suite level
    const reTryAndreRunSuiteCondition =
      (rowData.state === "failed" || rowData.state === "killed") && isSuite;

    // Delete to be available only for "success" | "failed" | "killed" states at a suite level
    const deleteSuiteCondition =
      (rowData.state === "failed" ||
        rowData.state === "success" ||
        rowData.state === "killed") &&
      isSuite;

    // Terminate to be available only for "queued" | "running" states aty a suite level
    const terminateSuiteCondition =
      (rowData.state === "queued" || rowData.state === "running") && isSuite;

    // always existing options
    const menuArray = [
      {
        label: "<a href='javascript:void(0)'>Open Log</a>",
        action: (e, row) => {
          onOpenLog(row, "log-btn");
        },
      },
      {
        label: enableErrorLogBtn
          ? "<a href='javascript:void(0)'>Open Error Log</a>"
          : "Open Error Log",
        action: (e, row) => {
          onOpenLog(row, "error-log-btn");
        },
        disabled: disableErrorLogBtn,
      },
      {
        // download NDM data for Process.da
        label: isWorkflow
          ? "<a href='javascript:void(0)'>View Data</a>"
          : "View Data",
        action: (e, row) => {
          onDownloadNDM(row, "ndm");
        },
        disabled: !isWorkflow,
      },
      {
        separator: true,
      },
    ];
    // push into menuArray based on conditions
    if (runSuiteCondition) {
      const optionObj = {
        label: "Run Suite",
        action: (e, row) => {
          onContextMenuOptionClick("run", row);
        },
      };
      menuArray.push(optionObj);
    }
    if (reTryAndreRunSuiteCondition) {
      const optionObjReTry = {
        label: "Re-Try Suite",
        action: (e, row) => {
          onContextMenuOptionClick("retry", row);
        },
      };
      const optionObjReRun = {
        label: "Re-Run Suite",
        action: (e, row) => {
          onContextMenuOptionClick("rerun", row);
        },
      };
      menuArray.push(optionObjReTry, optionObjReRun);
    }
    if (deleteSuiteCondition) {
      const optionObj = {
        label: "Delete Suite",
        action: (e, row) => {
          onContextMenuOptionClick("delete", row);
        },
      };
      menuArray.push(optionObj);
    }
    if (terminateSuiteCondition) {
      const optionObj = {
        label: "Terminate Suite",
        action: (e, row) => {
          onContextMenuOptionClick("kill", row);
        },
      };
      menuArray.push(optionObj);
    }
    // if (isWorkflow) {
    //   const optionObj = {
    //     // download NDM data for Process.da
    //     label: "<a href='javascript:void(0)'>View Data</a>",
    //     action: (e, row) => {
    //       onDownloadNDM(row, "ndm");
    //     },
    //   };
    //   menuArray.push(optionObj);
    // }
    return menuArray;
  };

  const workflowOptions = {
    selectable: false,
    // remove browser default right click
    rowContext: function (e, row) {
      e.preventDefault();
    },
    rowContextMenu: getRowContextMenu,
    persistenceID: widgetId,
    columnDefaults: {
      headerFilterLiveFilter: false,
      tooltip: true,
    },
    persistence: {
      filter: true,
      headerFilter: true,
      page: true,
      columns: ["width"],
    },
    dataTree: true,
    dataTreeFilter: true,
    // dataTreeChildField:"_children", //default
    dataTreeStartExpanded: function (row, level) {
      return row.getData().driver; //expand rows where the "driver" data field is true;
    },
    dataTreeChildIndent: 20,
  };

  const fetchData = async (inputData, setPageToOne = false) => {
    setIsTableLoading(true);
    if (setPageToOne) {
      setPage(1);
    }
    const result = await api(
      useConfigStore.getState().configData.rest_server_url +
        "/api/workflow/monitor_table",
      inputData
    );
    const { workflow_suites, total } = result;
    setWorkflowData(workflow_suites);
    setCountPages(Math.ceil(total / rowsPerPage));
    setIsTableLoading(false);
    // console.log({ result });
  };

  const customFilterEditor = (cell) => {
    try {
      let container = document.createElement("span");
      const columnName = cell.getField();
      const cellValue = cell.getValue();

      //create and style inputs
      let inputBox = document.createElement("input");
      inputBox.setAttribute("type", "text");
      inputBox.setAttribute("placeholder", "Type to filter ...");
      inputBox.style.padding = "4px";
      inputBox.style.width = "100%";
      inputBox.style.boxSizing = "border-box";

      inputBox.value =
        filterRef.current[columnName].length > 0
          ? filterRef.current[columnName]
          : cellValue;

      // functionality of blur and keydown
      function onBlur() {
        filterRef.current[columnName] = inputBox.value;
      }
      function keypress(e) {
        // if enter key is pressed
        if (e.keyCode == 13) {
          // create payload and call API
          const payload = {
            page_size: rowsPerPage,
            page: 1,
            states: allStatusSelected ? [] : statusListForWidget,
            project:
              columnName === "project"
                ? inputBox.value
                : filterRef.current.project,
            user:
              columnName === "user" ? inputBox.value : filterRef.current.user,
            target_workflows:
              columnName === "target_workflows"
                ? inputBox.value
                : filterRef.current.target_workflows,
            name:
              columnName === "name" ? inputBox.value : filterRef.current.name,
            with_reports_only: showOnlyAvailableReports,
          };

          const payloadName = `wmtPayload_${widgetId}`;

          setRootLevelData(payloadName, payload);
          // console.log({ payload }, filterRef.current);
          // call api with payload for pagination
          fetchData(payload, true);
        }
      }
      // adding event listeners for keydown (to be used when Enter key is pressed -> API call)
      // adding event listeners for blur (to be used when filter input box is out of focus -> set the filterRef column to have the value)
      inputBox.addEventListener("keydown", keypress);
      inputBox.addEventListener("blur", onBlur);

      container.appendChild(inputBox);
      return container;
    } catch (err) {
      console.error("Something went wront in filtering");
    }
  };

  const workflowColumns = [
    {
      title: "Project",
      field: "project",
      headerSort: false,
      headerFilter: customFilterEditor,
      resizable: true,
    },
    {
      title: "User",
      field: "user",
      headerSort: false,
      headerFilter: customFilterEditor,
      resizable: true,
    },
    {
      title: "Name",
      field: "name",
      headerFilter: customFilterEditor,
      headerSort: false,
      resizable: true,
    },
    {
      title: "Workflow/Stage",
      field: "target_workflows",
      headerFilter: customFilterEditor,
      formatter: reactFormatter(<FormatTargetWorkflow />),
      headerSort: false,
      resizable: true,
    },
    {
      title: "State",
      field: "state",
      headerFilter: false,
      headerSort: false,
      formatter: reactFormatter(<FormatWorkflowState />),
      resizable: true,
    },
    {
      title: "Report",
      field: "report",
      headerFilter: false,
      formatter: reactFormatter(<FormatShowReports />),
      headerSort: false,
      resizable: true,
      tooltip: false,
    },
    {
      title: "Progress",
      field: "progress",
      headerFilter: false,
      formatter: reactFormatter(<FormatProgress />),
      headerSort: false,
      resizable: true,
      tooltip: false,
      minWidth: 320,
    },
  ];

  // Function to update config
  const updateConfig = (config, save) => {
    // if user has refreshed, save the data in store
    if (save) {
      useGlobalStore
        .getState()
        .updateConfig(props.rptType, props.reportKey, widgetId, config);
    }

    useGlobalStore.getState().setWidgetUiState(widgetId, {
      isLoading: false,
      showConfig: false,
      isToastOpen: false,
      toastSeverity: "info",
      toastMessage: "",
      cirlularLoading: false,
    });
  };

  useEffect(() => {
    if (
      page !== prevPageRef.current ||
      rowsPerPage !== prevRowsPerPageRef.current
    ) {
      const payload = {
        page_size: rowsPerPage,
        page: page,
        states: allStatusSelected ? [] : statusListForWidget,
        project: filterRef.current.project,
        user: filterRef.current.user,
        target_workflows: filterRef.current.target_workflows,
        name: filterRef.current.name,
        with_reports_only: showOnlyAvailableReports,
      };
      const payloadName = `wmtPayload_${widgetId}`;
      setRootLevelData(payloadName, payload);

      // console.log({ payload });
      // call api with payload for pagination
      fetchData(payload);
      prevPageRef.current = page;
      prevRowsPerPageRef.current = rowsPerPage;
    }
  }, [page, rowsPerPage]);

  const onPageNumberChange = (e, value) => {
    // console.log("page number", value);
    setPage(value);
  };

  const onRowsPerPageChange = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10)); // converts to base 10
    // console.log("row", event.target.value);
    setPage(1);
  };

  const onCopyNdm = async (label, valueToCopy) => {
    try {
      setCopiedToClipboard({ [label]: true });
      await clipboardCopy(valueToCopy);
    } catch (err) {
      toast.error("Something went wrong while copying", toastConfig);
    } finally {
      setTimeout(() => {
        setCopiedToClipboard({ [label]: false });
      }, 1500);
    }
  };
  // render components (React tabulator) conditionally depending on data
  return (
    <>
      {uiState.showConfig ? (
        <Config
          updateConfig={updateConfig}
          config={props.config}
          id={widgetId}
        />
      ) : (
        <div id="analytics" className={styles.workflowMonitorParent}>
          {isTableLoading ? (
            <div className={styles.loaderContainer}>
              {[...Array(8)].map((item, index) => (
                <Skeleton
                  key={index}
                  variant="rectangular"
                  animation="wave"
                  className={styles.skeletonTabLoader}
                />
              ))}
            </div>
          ) : (
            <ReactTabulator
              key={theme}
              className={applyTheme(theme)}
              style={{ marginTop: "10px", height: "98%", border: 0 }}
              layout="fitColumns"
              responsiveLayout="collapse"
              autoResize={false}
              resizableColumnFit={true}
              columns={workflowColumns}
              data={workflowData}
              options={workflowOptions}
              placeholder="No data found !"
            />
          )}

          <div
            className={styles.paginationContainer}
            style={{
              pointerEvents: isTableLoading ? "none" : "all",
              opacity: isTableLoading ? "0.4" : "1",
            }}
          >
            Rows per page
            <Select
              value={rowsPerPage}
              label="Rows per page"
              onChange={onRowsPerPageChange}
            >
              {paginationRowsCount.map((val) => (
                <MenuItem key={val} value={val}>
                  {val}
                </MenuItem>
              ))}
            </Select>
            <Pagination
              count={countPages} // total number of pages = ceil(421/10) = 43
              color="primary"
              page={page}
              onChange={onPageNumberChange}
            />
          </div>
          {/* for NDM download show an overlay */}
          {isDownloading ? (
            <div className={styles.loaderOverlay}>Fetching data ...</div>
          ) : (
            <></>
          )}
          <Dialog
            open={showNDMPopup}
            TransitionComponent={Transition}
            onClose={() => setShowNDMPopup(false)}
            maxWidth="md"
          >
            <DialogTitle sx={{ padding: "16px 24px 10px 24px" }}>
              NDM data
            </DialogTitle>
            <IconButton
              aria-label="close"
              onClick={() => setShowNDMPopup(false)}
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
              }}
            >
              <CloseIcon />
            </IconButton>
            <DialogContent>
              <dd>
                {NDMMessage && Object.keys(NDMMessage).length > 0 ? (
                  Object.entries(NDMMessage?.data).map(
                    ([dataKey, dataVal], index) => (
                      <dl key={dataKey}>
                        <dt>{dataKey}:</dt>
                        <dd>
                          {dataVal}
                          <Button
                            variant="outlined"
                            className={styles.copyButton}
                            startIcon={
                              isCopiedToClipboard[dataKey] ? (
                                <CheckIcon />
                              ) : (
                                <ContentCopyIcon />
                              )
                            }
                            onClick={() => onCopyNdm(dataKey, dataVal)}
                          >
                            {isCopiedToClipboard[dataKey]
                              ? "Copied !"
                              : "Copy to clipboard"}
                          </Button>
                        </dd>
                        {/* there will be only two items, show hr after 1st item */}
                        {index === 0 ? <hr /> : <></>}
                      </dl>
                    )
                  )
                ) : (
                  <></>
                )}
              </dd>
            </DialogContent>
          </Dialog>
        </div>
      )}
    </>
  );
};

export default WorkflowMonitorTable;

WorkflowMonitorTable.defaultProps = {
  widgetProps: {},
  data: {},
  uiState: {
    isLoading: false,
    showConfig: true,
    isToastOpen: false,
    toastSeverity: "info",
    toastMessage: "",
  },
};
