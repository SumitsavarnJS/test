import React from "react";
import TabbedWidgetWrapper from "../../pages/rptdashboard/wigetWrapper/tabbedWidgetWrapper";

class TabbedWidgetError extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  componentDidCatch(error, errorInfo) {
    console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>> Widget Error", error);
    console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>> Widget ErrorInfo", errorInfo);
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div>
          <p>Something went wrong with the widget. Kindly report to R&D team </p>
        </div>
      );
    }
    return (
      <TabbedWidgetWrapper
        widgetProps={this.props.widgetProps}
        id={this.props.id}
        handleProps={this.props.handleProps}
        index={this.props.index}
        reportKey={this.props.reportKey}
        report={this.props.report}
        deleteWidget={this.props.deleteWidget}
        endPointUrl={this.props.endPointUrl}
      />
    );
  }
}

export default TabbedWidgetError;
