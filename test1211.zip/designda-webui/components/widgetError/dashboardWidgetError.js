import React from "react";
import WidgetWrapper from "../../pages/search/dashboard/DashboardWidgets";

class DashboardWidgetError extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  componentDidCatch(error, errorInfo) {
    console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>> Widget Error", error);
    console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>> Widget ErrorInfo", errorInfo);
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div>
          <p>Something went wrong with the widget. Kindly report to R&D team </p>
        </div>
      );
    }
    return (
      <WidgetWrapper widgetProps={this.props.widgetProps} id={this.props.id} />
    );
  }
}

export default DashboardWidgetError;
