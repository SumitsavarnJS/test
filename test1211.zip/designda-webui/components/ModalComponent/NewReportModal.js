import React, { useState, useEffect } from "react";
import { TextField, Select, MenuItem, Button, InputLabel } from "@mui/material";
import { styled, alpha } from "@mui/material/styles";
import getConfig from "next/config";
import useConfigStore from "../../store/useConfigStore";
import useGlobalStore from "../../store/useGlobalStore";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { useRouter } from "next/router";

const { publicRuntimeConfig } = getConfig();
const imageUrl = publicRuntimeConfig.basePath;

const NewReportModal = (props) => {
  const router = useRouter();

  const [reportName, setReportName] = useState("");
  const [selectValue, setSelectValue] = useState("light");
  const [showError, setShowError] = useState(false)
  const { isOpen, onClose, param, toggleApi, searchString } = props;
  const themeList = ['light',
    'infographic',
    'macarons',
    'roma',
    'vintage',
    'essos',
    'shine',
    'wonderland',
    'dark',
    'purple-passion']
  const Text = styled(Typography)(({ theme }) => ({
    fontSize: "1rem",
    fontWeight: "600",

    // marginBottom: theme.spacing(1),
  }));

  const {
    configData,
    setConfigData,
    isAuthenticated,
    setAuth,
    authLoginUser,
    setAuthUserVal,
  } = useConfigStore();

  useEffect(() => {
    if (reportName) {
      setShowError(false)
    }
  }, [reportName])
  const handleSave = async (e) => {
    e.preventDefault();
    if (!reportName) {
      setShowError(true)
    }
    else {
      let rptName = reportName;
      let rptData = {
        fileName: reportName,
        theme: selectValue,
        title: reportName,
        widgets: {},
      };
      useGlobalStore.getState().updateGlobalObject(rptName, rptData);
      onClose(true);
    }
  };

  return (
    <>
      <form>
        <div
          style={{
            margin: "0px",
            color: "white",
            border: "2px solid gray",
            backgroundColor: "#5B2C84",
            width: "20%",
            padding: 2,
          }}
        >
          <Typography
            sx={{ fontSize: "1.7rem", padding: "1.5%", margin: "0px" }}
          >
            {" "}
            Create New Report
          </Typography>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: "35%",
              bgcolor: "background.paper",
              boxShadow: 10,
              p: 4,
            }}
          >
            <TextField
              error={showError}
              sx={{ margin: "3% 0px 5%" }}
              label="Report Name"
              value={reportName}
              onChange={(e) => setReportName(e.target.value)}
              fullWidth
              margin="dense"
              InputLabelProps={{ style: { fontSize: "1rem" } }}
              helperText={showError ? "Please enter the report name" : ""}
            />
            <InputLabel
              sx={{ position: "relative", left: "1.3%", fontSize: "1rem" }}
            >
              Select Theme
            </InputLabel>

            <Select
              value={selectValue}
              onChange={(e) => setSelectValue(e.target.value)}
              fullWidth
              margin="dense"
              placeholder="Select Theme"
              InputLabelProps={{ style: { fontSize: "1rem" } }}
            >
              {themeList && themeList.length  >0 && themeList.map((themeName,index)=>
               <MenuItem key={index} sx={{ fontSize: "1rem" }} value={themeName}>
               {themeName}
             </MenuItem>
              )}
            </Select>

            <Button
              variant="contained"
              onClick={handleSave}
              sx={{ margin: "10% 0 0", fontSize: "1rem" }}
            >
              OK
            </Button>
          </Box>
        </div>
      </form>
    </>
  );
};

export default NewReportModal;
