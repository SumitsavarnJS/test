import * as React from "react";
import { styled, alpha } from "@mui/material/styles";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";

import TagIcon from "@mui/icons-material/Tag";
import ProfilePreferences from "./ProfilePreferences";
import SavedDashboardRpts from "./SavedDashboardRpts";
import NewReportModal from "./NewReportModal";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import { useRouter } from "next/router";

import { useState, useEffect, useRef, useContext } from "react";
import axios from "axios";
import StarIcon from "@mui/icons-material/Star";

import { toast } from "react-toastify";
import getConfig from "next/config";

import styles from "../../pages/search/search.module.css";
import TextField from "@mui/material/TextField";
import Divider from "@mui/material/Divider";
import EditIcon from "@mui/icons-material/Edit";
import { Typography, IconButton, Grid, Tooltip } from "@mui/material";
import refreshWidgetContent from "../../pages/rptdashboard/wigetWrapper/widgetRefreshData";
import SavedRpt from "../SavedRpt";
import DataSearch from "../../pages/datasearch";
import RecentComponent from "../layouts/RecentComponent";
import CircularProgress from "@mui/material/CircularProgress";
import {
  StepContent,
  Stepper,
  Step,
  StepLabel,
  MenuItem,
  Menu,
} from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { shallow } from "zustand/shallow";
import _ from "lodash";

const { publicRuntimeConfig } = getConfig();

const KeyValueDivider = styled(Divider)(({ theme }) => ({
  flexGrow: 1,
  marginLeft: theme.spacing(1),
  marginRight: theme.spacing(1),
}));
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "90%",
  height: "90%",

  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
  backgroundColor: "white",
  overflow: "auto",
  borderradius: "30px",
};

const KeyValueDivide = styled(Divider)(({ theme }) => ({
  flexGrow: 1,
  margin: theme.spacing(1),
  backgroundColor: "#C8C8C8",
}));
function ModalComponent(props) {
  const { isOpen, onClose, param, toggleApi, searchString, dataInput } = props;
  const { configData, authLoginUser } = useConfigStore();
  const authUser = authLoginUser;
  const [newRpt, setShowNewRpt] = useState(false);
  const [isPinned, setIsPinned] = useState(false);
  const [editedTags, setEditedTags] = useState({});
  const [isEditing, setIsEditing] = useState({});
  const [showRecentCards, setRecentCards] = useState(false);
  const [showFavCards, setShowFavCards] = useState(false);
  const [showSavedCards, setShowSavedCards] = useState(false);
  const [showDashboardRpt, setshowDashboardRpt] = useState(false);
  const [showDataCards, setShowDataCards] = useState(false);
  const [expanded, setExpanded] = useState({});
  const router = useRouter();
  const [starred, setStarred] = React.useState([]);
  const [recentCard, setRecent] = useState([]);
  const [pinnedCard, setPinnedCard] = useState([]);
  const [unPinnedCard, setUnPinnedCard] = useState([]);
  const { clickedJsons, addClickedJson } = useConfigStore();
  const [showProfileComponent, setShowProfileComponent] = useState(false);
  const [recentComponent, setRecentComponent] = useState([]);
  const [pinnedCardCopy, setPinnedCardCopy] = useState([]);
  const { publicRuntimeConfig } = getConfig();
  const imageUrl = publicRuntimeConfig.basePath;
  const suggestionListRef = useRef(null);
  const searchBoxRef = useRef(null);
  const [post, setPost] = useState([]);
  const [allData, setAllData] = useState([]);
  const [tabbedData, setTabbedData] = useState({});
  const [dashboardState, setDashboardState] = useState(true);
  const [moreOpen, setMoreOpen] = useState(false);
  const [showAllRptData, setShowAllRptData] = useState(false);

  const [formattedValue, setFormattedValue] = useState("");
  const [showDataCard, setDataCard] = useState(false);

  const [activeTab, setActiveTab] = useState({});

  const [showTabs, setShowTabs] = useState(false);

  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState({});

  const { setRootLevelData, analyticsRightPane } = useGlobalStore(
    (state) => ({
      setRootLevelData: state.setRootLevelData,
      analyticsRightPane: state.analyticsRightPane,
    }),
    shallow
  );

  const getJsonLinkStyle = (jsonLink) => {
    return isJsonClicked(jsonLink)
      ? { color: "#5a2a82" }
      : { color: "#0081FE" };
  };
  const isJsonClicked = (jsonLink) => {
    return clickedJsons.includes(jsonLink);
  };
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleQuery = (card) => {
    let str = card.key;
    let indexVal = str.indexOf("/");
    let firstPart = str.slice(0, indexVal);
    let secondPart = str.slice(indexVal + 1);
    let reportFinalKey = `${card.node}#${card.doc_type}/${secondPart}`;
    let report_type_val = "";
    if (card.doc_type === "task_reports") {
      report_type_val = "task";
    } else if (card.doc_type === "flow_reports") {
      report_type_val = "flow";
    } else if (card.doc_type === "techlib_reports") {
      report_type_val = "techlib";
    } else {
      report_type_val = "custom";
    }
    let formedObj = {
      bucket: firstPart,
      key: reportFinalKey,
      report_type: report_type_val,
      user: authUser,
    };
    axios
      .post(`${configData.rest_server_url}/api/fetch_report_data`, formedObj)
      .then((response) => {
        if (
          response.data &&
          typeof response.data.data[0] === "object" &&
          response.data.data[0] !== null
        ) {
          toast.info("Reports Added To Saved Reports", {
            position: toast.POSITION.BOTTOM_LEFT,
          });
          const rightPane = _.cloneDeep(analyticsRightPane);
          rightPane.favouriteRptCount += 1;
          setRootLevelData("analyticsRightPane", rightPane);
        } else {
          toast.error(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error) => {
        toast.error(response.data.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };
  const handleJsonClick = (card, jsonLink) => {
    let str = card.key;
    let indexVal = str.indexOf("/");
    let firstPart = str.slice(0, indexVal);
    let secondPart = str.slice(indexVal + 1);
    let reportFinalKey = `${card.node}#${card.doc_type}/${secondPart}`;
    let report_type_val = "";
    if (card.doc_type === "task_reports") {
      report_type_val = "task";
    } else if (card.doc_type === "flow_reports") {
      report_type_val = "flow";
    } else if (card.doc_type === "techlib_reports") {
      report_type_val = "techlib";
    } else {
      report_type_val = "custom";
    }
    let formedObj = {
      bucket: firstPart,
      key: reportFinalKey,
      report_type: report_type_val,
      user: authUser,
      child_name: jsonLink,
    };
    axios
      .post(`${configData.rest_server_url}/api/fetch_report_data`, formedObj)
      .then((response) => {
        if (
          response.data &&
          typeof response.data.data[0] === "object" &&
          response.data.data[0] !== null
        ) {
          // Handle success here, e.g. update state or show success message
          handlerouteClick(response.data.data[0]);
          let rptName = response.data.data[0].fileName;
          let rptData = response.data.data[0];
          addClickedJson(rptName);
          toast.info("Report Added To Queue", {
            position: toast.POSITION.BOTTOM_LEFT,
          });
          //if widget order is given separately
          if (response.data.data[0].widgetsOrder) {
            const widgetsOrder = response.data.data[0].widgetsOrder;
            //clone rpt data to set new order
            let rptDataClone = _.cloneDeep(rptData);
            delete rptDataClone.widgets;
            rptDataClone["widgets"] = {};
            //add widgets according to the new order given
            for (let index = 0; index < widgetsOrder.length; index++) {
              rptDataClone["widgets"][widgetsOrder[index]] =
                rptData["widgets"][widgetsOrder[index]];
            }
            rptData = rptDataClone;
          }
          useGlobalStore.getState().updateGlobalObject(rptName, rptData);
          if (rptData.hasOwnProperty("widgets")) {
            for (const Wkey in rptData.widgets) {
              let WkeyObj = {
                data: {},
                uiState: {
                  isLoading: false,
                  showConfig: false,
                  isToastOpen: false,
                  toastSeverity: "info",
                  toastMessage: "",
                  cirlularLoading: false,
                },
              };
              useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
            }
          }
          const widgetArray = Object.keys(rptData.widgets);
          for (let i = 0; i < widgetArray.length; i++) {
            const widgetId = widgetArray[i];
            const config = rptData.widgets[widgetId].config;
            const name = rptData.widgets[widgetId].name;
            const rptType = rptData.widgets[widgetId]?.rptType
              ? rptData.widgets[widgetId]?.rptType
              : "";
            const reportKey = rptData.widgets[widgetId]?.reportKey
              ? rptData.widgets[widgetId]?.reportKey
              : "";
            refreshWidgetContent({
              widgetId: widgetId,
              config: config,
              widgetName: name,
              reportKey: reportKey,
              rptType: rptType,
            });

            //condition to open the clicked report as current report in tabbed view
            if (useGlobalStore.getState().analyticsReportView.view === "tab") {
              useGlobalStore
                .getState()
                .setRootLevelData("analyticsReportView", {
                  view: "tab",
                  currentTab: rptName,
                });
            }
          }
        } else {
          toast.error(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error) => {
        // Handle error here, e.g. show error message
        toast.error(response.data.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };
  const handleReportDataSearch = (reportFilter) => {
    if (reportFilter) {
      const copyPinned = [...pinnedCard];
      setPinnedCardCopy(copyPinned);
      const onlyReports = pinnedCard.filter((data) => data.has_report);
      setPinnedCard(onlyReports);
      setShowAllRptData(true);
    } else {
      setPinnedCard(pinnedCardCopy);
      setShowAllRptData(false);
    }
  };
  const handleTabbedData = async (dataInput, uniqueKey, clicked_str) => {
    if (clicked_str === "view_more") {
      setLoading({ ...loading, [uniqueKey]: true });
      axios
        .post(`${configData.rest_server_url}/api/fetch_reports`, {
          project: dataInput.key.split("/")[0],
          report_name: dataInput.key,
          report_type: dataInput.doc_type,
          user: authUser,
        })
        .then((response) => {
          try {
            setLoading({ ...loading, [uniqueKey]: false });
            const reqdResult = {
              ...tabbedData,
              [uniqueKey]: response.data.data,
            };
            setTabbedData(reqdResult);
            const activeTabName = response?.data?.data?.tab_names[0];
            setActiveTab({ ...activeTab, [dataInput.key]: activeTabName });
          } catch (e) {
            setLoading({ ...loading, [uniqueKey]: false });
            toast.error(response.data.message, {
              position: toast.POSITION.BOTTOM_LEFT,
              style: { backgroundColor: "white", color: "gray" },
            });
          }
        })
        .catch((error) => {
          setLoading({ ...loading, [uniqueKey]: false });
          console.error("Error sending data to API:", error);
        });
    }
  };
  const handleExpandClick = (data, key, clicked_str) => {
    handleTabbedData(data, key, clicked_str);
    setExpanded((prevExpandedMap) => {
      return {
        ...prevExpandedMap,
        [data.key]: !prevExpandedMap[data.key],
      };
    });
  };
  const handleTabClick = (name, uniqueKey) => {
    setActiveTab({ ...activeTab, [uniqueKey]: name });
  };
  const addHashtagHandler = (value, cardKey) => {
    let reportTypeCheck = cardKey.split("/").length;
    let report_type_val = "task";
    if (reportTypeCheck === 7) {
      report_type_val = "task";
    } else if (reportTypeCheck === 4) {
      report_type_val = "flow";
    } else {
      report_type_val = "custom";
    }
    let indexValKey = cardKey.indexOf("/");
    let appendKey = cardKey.slice(indexValKey + 1);
    let hashtagVal = value ? value.replace(/\s+/g, ",") : "";
    if (hashtagVal) {
      axios
        .post(`${configData.rest_server_url}/api/add_hashtags`, {
          key: appendKey,
          bucket_name: cardKey.split("/")[0],
          report_type: report_type_val,
          hashtag: hashtagVal,
        })
        .then((response) => {
          //  handleHashtagsChange(cardKey,'')
        })
        .catch((error) => {
          // Handle error here, e.g. show error message
          toast.error(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        });
    } else {
      toast.error("Hashtags canbot be empty", {
        position: toast.POSITION.BOTTOM_LEFT,
        style: { backgroundColor: "red", color: "white" },
      });
    }
  };
  const handleStarClick = (card, key, action, type) => {
    if (action === "pin" && card.has_report) {
      handleQuery(card);
    }
    const index = starred.indexOf(key);
    if (index === -1) {
      setStarred([...starred, key]);
    } else {
      const newStarred = [...starred];
      newStarred.splice(index, 1);
      setStarred(newStarred);
    }
    axios
      .post(`${configData.rest_server_url}/api/update_user_activity`, {
        user: authUser,
        key: key,
        doc_type: type,
        action: action,
      })
      .then((response) => {
        setIsPinned(action === "pin");
        if (action == "unpin") {
          const rightPane = _.cloneDeep(analyticsRightPane);
          rightPane.favouriteRptCount -= 1;
          setRootLevelData("analyticsRightPane", rightPane);
          fetchDataRecent();
        }
      })
      .catch((error) => {
        console.error(error);
        toast.error(response.data.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };
  const handlerouteClick = (reportInfo) => {
    axios
      .post(`${configData.rest_server_url}/api/update_reports_info`, {
        data: reportInfo,
        user: useConfigStore.getState().authLoginUser,
      })
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        // Handle error here, e.g. show error message
        console.error(error);
        toast.error(response.data.message, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });
  };
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        searchBoxRef.current &&
        !searchBoxRef.current.contains(event.target) &&
        suggestionListRef.current &&
        !suggestionListRef.current.contains(event.target) &&
        !event.target.matches(".suggestion-item")
      ) {
        setSuggestionsList(false);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [searchBoxRef, suggestionListRef]);

  const fetchDataRecent = async (type) => {
    axios
      .post(`${configData.rest_server_url}/api/fetch_recent_docs`, {
        user: authUser,
        data_card: true,
      })
      .then((response) => setRecent(response.data.data))
      .catch((error) => {
        console.error("Error sending data to API:", error);
      });
  };

  useEffect(() => {
    if (param === "Newrpt") {
      setShowNewRpt(true);
      setShowProfileComponent(false);
      setRecentComponent(false);
      setShowSavedCards(false);
      setShowFavCards(false);
      setShowDataCards(false);
    }

    if (param === "Fav") {
      fetchDataRecent();
      setShowNewRpt(false);
      setShowProfileComponent(false);
      setRecentComponent(false);
      setShowSavedCards(false);
      setShowFavCards(true);
      setShowDataCards(false);
    }
    if (param === "Rec") {
      // fetchDataRecent();
      setShowProfileComponent(false);
      setRecentComponent(true);
      setShowSavedCards(false);
      setShowFavCards(false);
      setShowDataCards(false);
      setShowNewRpt(false);
    }
    if (param === "Sav") {
      setShowProfileComponent(false);
      setRecentComponent(false);
      setShowSavedCards(true);
      setShowFavCards(false);
      setShowDataCards(false);
      setShowNewRpt(false);
    }
    if (param === "Search") {
      setShowProfileComponent(false);
      setRecentComponent(false);
      setShowSavedCards(false);
      setShowFavCards(false);
      setShowDataCards(true);
      setShowNewRpt(false);
    }
    if (param === "Profile") {
      setShowProfileComponent(true);
      setRecentComponent(false);
      setShowSavedCards(false);
      setShowFavCards(false);
      setShowDataCards(false);
      setShowNewRpt(false);
    }
    if (param === "SavDash") {
      setshowDashboardRpt(true);
      setShowProfileComponent(false);
      setRecentComponent(false);
      setShowSavedCards(false);
      setShowFavCards(false);
      setShowDataCards(false);
      setShowNewRpt(false);
    }
  }, [param, toggleApi]);
  useEffect(() => {
    if (recentCard) {
      if (param === "Newrpt") {
        setShowNewRpt(true);
        setShowProfileComponent(false);
        setRecentComponent(false);
        setShowSavedCards(false);
        setShowFavCards(false);
        setShowDataCards(false);
      }

      if (param === "Fav") {
        const pinnedCards =
          recentCard && recentCard.filter((card) => card.is_pinned === true);
        setPinnedCard(pinnedCards);
        setRecentComponent(false);
        setShowSavedCards(false);
        setShowFavCards(true);
        setShowDataCards(false);
        setShowProfileComponent(false);
        setShowNewRpt(false);
      }
      if (param === "Rec") {
        // console.log("Pinned" + JSON.stringify(pinnedCard));
        setUnPinnedCard(recentCard.filter((card) => card.is_pinned === false));
        setRecentComponent(true);
        setShowSavedCards(false);
        setShowFavCards(false);
        setShowDataCards(false);
        setShowProfileComponent(false);
        setShowNewRpt(false);
      }
    }
  }, [recentCard]);

  // To handle the state For View More and View Less When Modal Is Closed
  useEffect(() => {
    if (!isOpen) {
      setExpanded(false);
    }
  }, [isOpen]);

  return (
    <>
      <Modal
        open={isOpen}
        onClose={onClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div
            id="searchPageParent"
            className={styles.backgroundColorApplication}
          >
            <div id="searchContents" className={styles.searchContents}>
              <div>
                <div></div>
              </div>
              {/* -----Bari Dashboard----------------- */}
              <div
                style={{
                  marginTop: "1rem",
                  marginLeft: "6.5%",
                  // maxHeight: '1000px',
                  width: "80%",
                  alignContent: "center",
                }}
              ></div>
              {showFavCards ? (
                <>
                  <Box
                    sx={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                      width: "100%",
                      height: "100%",
                      bgcolor: "#fbf7fc",
                      border: "1px solid #C8C8C8",
                      boxShadow: 24,
                      p: 4,

                      borderRadius: "6px",
                      overflow: "auto",
                      boxShadow:
                        " 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
                    }}
                  >
                    <div id="header" className={styles.header}>
                      <Typography
                        sx={{
                          fontSize: "36px",
                          color: "#black",
                        }}
                      >
                        Favorite Results :
                      </Typography>
                      <Typography
                        sx={{
                          fontSize: "16px",
                          color: "grey",
                          marginTop: "20px",
                          marginLeft: "5px",
                        }}
                      >
                        You found
                      </Typography>
                      <Typography
                        sx={{
                          marginTop: "20px",
                          color: "#5A2A82",
                          marginLeft: "2px",
                        }}
                      >
                        {pinnedCard && pinnedCard.length}
                      </Typography>
                      <Typography
                        sx={{
                          fontSize: "16px",
                          color: "grey",
                          marginTop: "20px",
                          marginLeft: "2px",
                        }}
                      >
                        results that match
                      </Typography>
                    </div>

                    <div
                      id="datasummarytext"
                      className={styles.datasummarytext}
                    >
                      <div>
                        {showAllRptData ? (
                          <Typography
                            sx={{
                              fontSize: "16px",
                              color: "#5B2C84",
                              cursor: "pointer",
                            }}
                            onClick={() => {
                              handleReportDataSearch(false);
                            }}
                          >
                            <strong>Data Summary : </strong> Show All Results
                          </Typography>
                        ) : (
                          <Typography
                            sx={{
                              fontSize: "16px",
                              color: "#5B2C84",
                              cursor: "pointer",
                            }}
                            onClick={() => {
                              handleReportDataSearch(true);
                            }}
                          >
                            <strong>Data Summary : </strong> Filter Results by
                            Report Availability
                          </Typography>
                        )}
                      </div>

                      <div id="parsedate" className={styles.parsedate}>
                        <div>
                          <Typography
                            sx={{
                              fontSize: "16px",
                              color: "#5B2C84",
                            }}
                          >
                            <strong> Date Created On </strong>
                          </Typography>
                        </div>
                        <div>
                          <IconButton
                            sx={{
                              padding: "2px",
                            }}
                          >
                            <MoreVertIcon />
                          </IconButton>
                        </div>
                      </div>
                    </div>
                    <KeyValueDivider />

                    {pinnedCard.map((data, index) => (
                      <div key={data.key}>
                        <Box
                          sx={{
                            border: "1px solid #C8C8C8",
                            padding: "20px 10px 20px 20px",
                            marginTop: "2%",
                            borderRadius: "6px",
                            backgroundColor: "white",
                          }}
                        >
                          <div id="xon" className={styles.xon}>
                            <div id="nox" className={styles.nox}>
                              <div
                                id="pointedlogo"
                                className={styles.pointedlogo}
                              >
                                {data.data_type === "analytics" ? (
                                  <span
                                    id="pointedanalytics"
                                    className={styles.pointedanalytics}
                                  >
                                    <img
                                      id="chip_1"
                                      src={`${imageUrl}/Data_Analytics_Path.svg`}
                                      alt="Clock Icon"
                                    />
                                  </span>
                                ) : (
                                  <span
                                    id="pointedmetrics"
                                    className={styles.pointedmetrics}
                                  >
                                    <img
                                      id="chip_2"
                                      src={`${imageUrl}/Data_Metrics_Path.svg`}
                                      alt="Clock Icon"
                                    />
                                  </span>
                                )}

                                <div id="path" className={styles.path}>
                                  Path :{" "}
                                </div>

                                <span>
                                  {data.key
                                    .replace(/[/]/g, " ")
                                    .split(" ")
                                    .join(" > ")}
                                </span>
                                {/* </Breadcrumbs> */}
                              </div>
                            </div>

                            <span
                              id="viewless"
                              className={styles.viewless}
                              onClick={() =>
                                handleExpandClick(data, data.key, "view_less")
                              }
                            >
                              {!expanded[data.key] ? " " : "View Less"}
                              {/* {console.log("VIEW_LESS", !expanded[data.key])} */}
                            </span>
                            {/* {console.log("EXPANDED_DATASEARCH", !expanded[data.key])} */}
                            <div
                              id="creationdate"
                              className={styles.creationdate}
                            >
                              <div>
                                <Typography
                                  sx={{
                                    display: "inline",
                                    color: "#646e81",
                                  }}
                                >
                                  {data.creation_date &&
                                    data.creation_date.toString()}
                                </Typography>
                              </div>
                            </div>
                          </div>

                          {expanded[data.key] &&
                          tabbedData[data.key] &&
                          Object.keys(tabbedData).length > 0 ? (
                            <div>
                              <div
                                id="tabbeddata"
                                className={styles.tabbeddata}
                              >
                                {tabbedData &&
                                  tabbedData[data.key]?.tab_names &&
                                  tabbedData[data.key]?.tab_names.map(
                                    (name) => {
                                      return (
                                        <Tooltip placement="top" title={name}>
                                          <div
                                            key={name}
                                            onClick={() =>
                                              handleTabClick(name, data.key)
                                            }
                                            style={{
                                              padding: "12px 6px 12px 6px",
                                              background:
                                                activeTab[data.key] === name
                                                  ? "linear-gradient(to right,white,white)"
                                                  : "linear-gradient(to right,#E3C3E9,white)",
                                              color:
                                                activeTab[data.key] === name
                                                  ? "black"
                                                  : "black",
                                              cursor: "pointer",
                                              border:
                                                activeTab[data.key] === name
                                                  ? "1px solid #E3C3E9"
                                                  : "1px solid #c8c8c8",
                                              borderRadius: "6px 6px 0 0 ",
                                              fontWeight: "500",
                                              minWidth: "4.5rem",
                                              maxWidth: "9rem",

                                              textAlign: "left",
                                              overflow: "hidden",
                                              textOverflow: "ellipsis",
                                            }}
                                          >
                                            {name}
                                          </div>
                                        </Tooltip>
                                      );
                                    }
                                  )}
                              </div>

                              {loading[data.key] ? (
                                <span
                                  id="circularprogress"
                                  className={styles.circularprogress}
                                >
                                  <CircularProgress
                                    sx={{
                                      color: "#5B2A84",
                                    }}
                                  />{" "}
                                </span>
                              ) : (
                                <Box
                                  sx={{
                                    backgroundColor: "#F6F6F6",
                                    padding: "1%",
                                    borderRadius: "6px",
                                    borderTop: "1px solid #E3C3E9",
                                    width: "100%",
                                  }}
                                >
                                  <>
                                    <Typography>
                                      <strong>The Description : </strong>
                                      The Summarization of Workflows is in
                                      Progress, To be Added Soon!
                                    </Typography>
                                    <KeyValueDivider />
                                    <Stepper activeStep={activeStep}>
                                      {tabbedData &&
                                        tabbedData[data.key]?.tab_content &&
                                        tabbedData[data.key]?.tab_content
                                          .filter(
                                            (tabDataObj) =>
                                              tabDataObj.tab_name ===
                                              activeTab[data.key]
                                          )
                                          .map((tabObj) => (
                                            <Step key={tabObj.name}>
                                              <div
                                                id="stepper"
                                                className={styles.stepper}
                                              >
                                                {tabObj.stepper.map(
                                                  (stepObj, index) => (
                                                    <div key={stepObj.name}>
                                                      <div
                                                        id="dd"
                                                        className={styles.dd}
                                                      >
                                                        <div
                                                          id="workflowlogo"
                                                          className={
                                                            styles.workflowlogo
                                                          }
                                                        >
                                                          <img
                                                            id="logo"
                                                            src={`${imageUrl}/IC_Workflow_folder.svg`}
                                                            alt="Clock Icon"
                                                            height={20}
                                                            width={20}
                                                          />
                                                        </div>

                                                        <div
                                                          id="steppername"
                                                          className={
                                                            styles.steppername
                                                          }
                                                        >
                                                          {stepObj.name.toString()}
                                                        </div>
                                                      </div>
                                                      <StepContent>
                                                        <Box
                                                          sx={{
                                                            border:
                                                              "1px solid #C8C8C8",
                                                            padding: "20px",
                                                            marginTop: "2%",
                                                            marginBottom: "3%",
                                                            borderRadius: "6px",
                                                            backgroundColor:
                                                              "white",

                                                            border:
                                                              "1px solid #C8C8C8",
                                                            width: "100%",
                                                          }}
                                                        >
                                                          <>
                                                            {stepObj.description.map(
                                                              (item, index) => (
                                                                <Grid
                                                                  container
                                                                  key={index}
                                                                >
                                                                  <Grid
                                                                    item
                                                                    xs={4}
                                                                  >
                                                                    <div
                                                                      id="reportlogo"
                                                                      className={
                                                                        styles.reportlogo
                                                                      }
                                                                    >
                                                                      <img
                                                                        id="logo"
                                                                        src={`${imageUrl}/IC_File_icon_1.svg`}
                                                                        alt="File Icon"
                                                                        height={
                                                                          30
                                                                        }
                                                                        width={
                                                                          20
                                                                        }
                                                                        style={{
                                                                          color:
                                                                            "black",
                                                                          marginRight:
                                                                            "8.25%",
                                                                        }}
                                                                      />

                                                                      <div
                                                                        id="reportname"
                                                                        className={
                                                                          styles.reportname
                                                                        }
                                                                        onClick={() =>
                                                                          handleJsonClick(
                                                                            item.report,
                                                                            item
                                                                              .report
                                                                              .child_name
                                                                          )
                                                                        }
                                                                      >
                                                                        {item.report.name.toString()}
                                                                      </div>
                                                                    </div>
                                                                    <KeyValueDivide />
                                                                  </Grid>
                                                                </Grid>
                                                              )
                                                            )}
                                                          </>
                                                        </Box>
                                                      </StepContent>
                                                    </div>
                                                  )
                                                )}
                                              </div>
                                            </Step>
                                          ))}
                                    </Stepper>
                                  </>
                                </Box>
                              )}
                            </div>
                          ) : (
                            <>
                              {!showTabs && (
                                <Box
                                  sx={{
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                    whiteSpace: "nowrap",
                                    padding: "0",
                                  }}
                                >
                                  <div id="outer" className={styles.outer}>
                                    <div
                                      id="workflowsummary"
                                      className={styles.workflowsummary}
                                    >
                                      <strong>
                                        Summary of Workflow Overview:
                                      </strong>{" "}
                                      The Cumulative Summary Generation of the
                                      Workflows is in Progress, To be Added
                                      Soon!
                                      {data.has_report && (
                                        <span
                                          id="viewmore"
                                          className={styles.viewmore}
                                          onClick={() =>
                                            handleExpandClick(
                                              data,
                                              data.key,
                                              "view_more"
                                            )
                                          }
                                        >
                                          {!expanded[data.key]
                                            ? "View More Details"
                                            : " "}
                                          {/* {console.log("VIEW_MORE", !expanded[data.key])} */}
                                        </span>
                                      )}
                                    </div>

                                    <IconButton
                                      sx={{
                                        padding: "0",
                                        marginLeft: "1%",
                                        "&:hover": {
                                          backgroundColor: "transparent",
                                        },
                                      }}
                                      disableRipple
                                    >
                                      <StarIcon
                                        onClick={() =>
                                          handleStarClick(
                                            data,
                                            data.key,
                                            "unpin",
                                            data.doc_type
                                          )
                                        }
                                        style={{
                                          color: "gold",
                                          fontSize: "2rem",
                                          marginLeft: "20px",
                                        }}
                                      />
                                    </IconButton>
                                  </div>
                                </Box>
                              )}
                            </>
                          )}

                          <div id="hashtags" className={styles.hashtags}>
                            {data?.hash_tags?.length > 0 &&
                            !isEditing[data.key] ? (
                              <div
                                id="hashtagging"
                                className={styles.hashtagging}
                              >
                                <TextField
                                  sx={{ width: "30%" }}
                                  placeholder="Add Hashtags"
                                  variant="outlined"
                                  size="small"
                                  helperText="Add Space Between Each Tag"
                                  disabled
                                  value={data.hash_tags.replace(/,/g, " ")}
                                />
                                <IconButton
                                  sx={{ color: "black" }}
                                  onClick={(event) => {
                                    const updatedTags = { ...editedTags };
                                    updatedTags[data.key] =
                                      data.hash_tags.replace(/,/g, " ");
                                    setEditedTags(updatedTags);
                                    const updateEdit = { ...isEditing };
                                    updateEdit[data.key] = true;
                                    setIsEditing(updateEdit);
                                  }}
                                >
                                  {" "}
                                  <EditIcon />
                                </IconButton>{" "}
                              </div>
                            ) : (
                              <>
                                <TextField
                                  sx={{ width: "30%" }}
                                  placeholder="Add Hashtags"
                                  variant="outlined"
                                  size="small"
                                  helperText="Add Space Between Each Tag"
                                  value={editedTags[data.key]}
                                  onChange={(event) => {
                                    const updatedTags = { ...editedTags };
                                    updatedTags[data.key] = event.target.value;
                                    setEditedTags(updatedTags);
                                  }}
                                />
                                <IconButton
                                  sx={{ color: "black" }}
                                  onClick={() => {
                                    const updatedTags = editedTags[data.key];
                                    addHashtagHandler(updatedTags, data.key);
                                  }}
                                >
                                  <TagIcon />
                                </IconButton>{" "}
                              </>
                            )}
                          </div>
                        </Box>
                      </div>
                    ))}
                  </Box>
                </>
              ) : null}
              {recentComponent ? <RecentComponent /> : null}
              {showSavedCards ? <SavedRpt /> : null}
              {showDataCards ? <DataSearch dataInput={searchString} /> : null}
              {showProfileComponent ? <ProfilePreferences /> : null}
              {showDashboardRpt ? (
                <SavedDashboardRpts open={isOpen} onClose={onClose} />
              ) : null}

              {newRpt ? (
                <NewReportModal open={isOpen} onClose={onClose} />
              ) : null}
            </div>
          </div>
        </Box>
      </Modal>
    </>
  );
}
export default ModalComponent;
