import React, { useState, useEffect } from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import useGlobalStore from "../../store/useGlobalStore";
import Divider from "@mui/material/Divider";
import { toast } from "react-toastify";
import { makeFixedPostRequest } from "../../common/api/getDefaultDashApi";
import axios, { formToJSON } from "axios";
import useConfigStore from "../../store/useConfigStore";
import Typography from "@mui/material/Typography";
import { useRouter } from "next/router";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import { Skeleton } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import DeleteDashboardModal from "./DeleteDashboardModal";
import styles from "./modalComponent.module.css";

function DashboardTabMenu(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}
function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

const SavedDashboardRpt = (props) => {
  const { isOpen, onClose, param, toggleApi, searchString } = props;
  const { configData, authLoginUser } = useConfigStore();
  const router = useRouter();
  const [dashboardData, setDashboardData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [value, setValue] = useState(0);
  const [commonPath, setCommonPath] = useState("");
  const [publishedPath, setPublishedPath] = useState("");
  const [localDashboards, setLocalDashboards] = useState([]);
  const [publishedDashboards, setPublishedDashboards] = useState([]);
  const [deleteModalStateHandler, setDeleteModalStateHandler] = useState(false);
  const [dashboardName, setDashboardName] = useState(
    useGlobalStore
      .getState()
      .allDashbrdRpts?.dashboardReport?.fileName.toString()
  );
  const [fileName, setFileName] = useState("");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  useEffect(() => {
    fetchDashboardsData();
  }, []);

  async function replaceRelativePath(data) {
    try {
      if (data.local_dashboards) {
        const commonDashboardPath = data.local_dashboards.reduce(
          (common, path) => {
            const match = path.match(/(.+\/dashboards\/)/);
            return match ? match[1] : common;
          },
          ""
        );
        setCommonPath(commonDashboardPath);
        const dashboardNameWithoutPath =
          data.local_dashboards &&
          data.local_dashboards.map((item) => {
            return item.replace(commonDashboardPath, "").replace(".json", "");
          });
        setLocalDashboards(dashboardNameWithoutPath.sort());
        setLoading(false);
      }
      if (data.published_dashboards) {
        const commonDashboardPath = data.published_dashboards.reduce(
          (common, path) => {
            const match = path.match(/(.+\/published_dashboards\/)/);
            return match ? match[1] : common;
          },
          ""
        );
        setPublishedPath(commonDashboardPath);
        const dashboardNameWithoutPath =
          data.published_dashboards &&
          data.published_dashboards.map((item) => {
            return item.replace(commonDashboardPath, "").replace(".json", "");
          });
        setPublishedDashboards(dashboardNameWithoutPath.sort());
        setLoading(false);
      }
    } catch (error) {
      console.error("Error processing data:", error);
      setLoading(false);
    }
  }

  const fetchDashboardsData = async () => {
    try {
      const reportResponse = await axios.post(
        configData.rest_server_url + "/api/get_dashboards",
        {
          user: authLoginUser,
        }
      );

      const response = reportResponse && reportResponse.data.local_dashboards;
      // Check to create default dashboard, if it does not exist
      if (response.some((path) => path.endsWith("/default_dashboard.json"))) {
        // function call to remove the common string and set the Dashboard display List
        setLoading(false);
        replaceRelativePath(reportResponse.data);
      } else {
        //Api to create Default Dashboard
        const responseDash = await makeFixedPostRequest([1]);
        // Handle the response data as needed
        const reportResponse = await axios.post(
          configData.rest_server_url + "/api/get_dashboards",
          {
            user: authLoginUser,
          }
        );
        setLoading(false);
        replaceRelativePath(reportResponse.data);
      }
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  const handleDeleteIconClick = (dashboardDisplayName) => {
    setDeleteModalStateHandler(true);
    setFileName(dashboardDisplayName);
  };

  const handleCloseDeleteIconModalClick = () => {
    setDeleteModalStateHandler(false);
  };

  const handleDelete = async () => {
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/delete_dashboard_report",
        {
          user: useConfigStore.getState().authLoginUser,
          file_name: fileName,
        }
      )
      .then((response) => {
        response = response.data;
        toast.info(`Dashboard named ${fileName} deleted successfully`, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        fetchDashboardsData();
        setDeleteModalStateHandler(false);
        // saveConfig();
      })
      .catch((error) => {
        console.log("Failed to reach Server");
      });
  };

  const handleLogoClick = () => {
    onClose(false);
    router.push({
      pathname: "/Dashboards",
    });
  };

  const onDashboardClick = async (dashData, pathType) => {
    let absoluteDashboardPath = pathType && pathType + dashData + ".json";
    await axios
      .post(configData.rest_server_url + "/api/read_json_from_path", {
        path: absoluteDashboardPath,
        exact_path: true,
      })
      .then((reportResponse) => {
        if (reportResponse?.status === 200) {
          updateDashboardPage(reportResponse.data.data);
        } else {
          toast.error("Failed To Fetch Data!", {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const updateDashboardPage = (dashData) => {
    let rptData = {
      dashboardReport: {
        fileName: "",
        config: { expanded: false },
        widgets: {},
      },
    };
    useGlobalStore.getState().updateDashboardObject(rptData);
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/save_user_config",
        {
          data: dashData,
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          //   Handle success here, e.g. update state or show success message
          useGlobalStore.getState().setDashboardChange(dashData.fileName);
          toast.info(`Current Dashboard Changed to ${dashData.fileName}`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        } else {
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        console.log("Failed to reach Server");
      });
    handleLogoClick();
  };

  return (
    <>
      <Box sx={{ width: "100%" }}>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Tabs value={value} onChange={handleChange} aria-label="Dashboards">
            <Tab label="Saved Dashboards" {...a11yProps(0)} />
            <Tab label="Published Dashboards" {...a11yProps(1)} />
          </Tabs>
        </Box>
        <DashboardTabMenu value={value} index={0}>
          {loading ? (
            <List>
              <div className={styles.skeletonTabLoaderDiv}>
                {[...Array(7)].map((item, index) => (
                  <Skeleton
                    key={index}
                    variant="rectangular"
                    animation="wave"
                    className={styles.skeletonTabLoader}
                  />
                ))}
              </div>
            </List>
          ) : (
            <List
              sx={{
                width: "100%",
                // maxWidth: 460,
                bgcolor: "background.paper",
                position: "relative",
                overflow: "auto",
                "& ul": { padding: "3px" },
              }}
              subheader={<li />}
            >
              {/* <pre>{dashboardData}</pre> */}
              {localDashboards &&
                localDashboards.map((dashboardDisplayName) => (
                  <li key={`section-${dashboardDisplayName}`}>
                    <ul>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "row",
                          justifyContent: "space-between",
                        }}
                      >
                        <div>
                          <ListItem
                            style={{ cursor: "pointer" }}
                            key={dashboardDisplayName}
                            onClick={() =>
                              onDashboardClick(dashboardDisplayName, commonPath)
                            }
                          >
                            {dashboardDisplayName}
                          </ListItem>
                        </div>
                        <div>
                          <DeleteIcon
                            sx={{ color: "#5B2A84", cursor: "pointer" }}
                            onClick={() =>
                              handleDeleteIconClick(dashboardDisplayName)
                            }
                          />
                        </div>
                      </div>

                      <Divider
                        sx={{
                          backgroundColor: "black",
                          flexGrow: 1,
                          marginLeft: 2,
                          marginRight: 2,
                        }}
                      />
                    </ul>
                  </li>
                ))}
            </List>
          )}
        </DashboardTabMenu>
        <DashboardTabMenu value={value} index={1}>
          {loading ? (
            <List>
              <div className={styles.skeletonTabLoaderDiv}>
                {[...Array(7)].map((item, index) => (
                  <Skeleton
                    key={index}
                    variant="rectangular"
                    animation="wave"
                    className={styles.skeletonTabLoader}
                  />
                ))}
              </div>
            </List>
          ) : (
            <List
              sx={{
                width: "100%",
                // maxWidth: 460,
                bgcolor: "background.paper",
                position: "relative",
                overflow: "auto",
                "& ul": { padding: "3px" },
              }}
              subheader={<li />}
            >
              {publishedDashboards &&
                publishedDashboards.map((dashboardDisplayName) => (
                  <li key={`section-${dashboardDisplayName}`}>
                    <ul>
                      <ListItem
                        style={{ cursor: "pointer" }}
                        key={dashboardDisplayName}
                        onClick={() =>
                          onDashboardClick(dashboardDisplayName, publishedPath)
                        }
                      >
                        {dashboardDisplayName}
                      </ListItem>
                      <Divider
                        sx={{
                          backgroundColor: "black",
                          flexGrow: 1,
                          marginLeft: 2,
                          marginRight: 2,
                        }}
                      />
                    </ul>
                  </li>
                ))}
            </List>
          )}
        </DashboardTabMenu>
      </Box>
      {deleteModalStateHandler ? (
        <DeleteDashboardModal
          open={deleteModalStateHandler}
          onClose={handleCloseDeleteIconModalClick}
          handleDelete={handleDelete}
          fileName={fileName}
        />
      ) : null}
    </>
  );
};
export default SavedDashboardRpt;
