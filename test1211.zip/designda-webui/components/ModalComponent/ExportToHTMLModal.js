import React from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Slide,
} from "@mui/material";
import { toast } from "react-toastify";
import * as utils from "../../common/utils/utils";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

function ExportToHTMLModal({
  open,
  onCloseExportDialog,
  interestedElementRef,
  fileName,
}) {
  const showToast = (fileType) => {
    const typeOfFile = fileType;
    toast.info(`Exporting ${typeOfFile} in progress`, {
      position: toast.POSITION.BOTTOM_LEFT,
      style: {
        fontSize: "14px",
        padding: "8px  12px",
      },
    });
  }
  const exportToHTML = () => {
    const requiredRef = fileName === 'Dashboard' ? interestedElementRef.current.elementRef.current : interestedElementRef;
    utils.exportToHTML(requiredRef, fileName);
    onCloseExportDialog();
    showToast(fileName);
  };

  return (
    <Dialog
      open={open}
      onClose={onCloseExportDialog}
      aria-labelledby="export-modal-title"
      aria-describedby="export-modal-description"
      TransitionComponent={Transition}
    >
      <DialogTitle id="export-modal-title">Export to HTML</DialogTitle>
      <DialogContent>
        <DialogContentText id="export-modal-description">
          Please scroll the page to ensure all the required widgets are loaded before exporting
        </DialogContentText>
      </DialogContent>
      <DialogActions id="export-modal-footer">
        <Button
          id="export-modal-cancel-button"
          variant="outlined"
          onClick={onCloseExportDialog}
          sx={{ textTransform: "none" }}
        >
          Cancel
        </Button>
        <Button
          id="export-modal-continue-button"
          variant="contained"
          onClick={exportToHTML}
          sx={{ textTransform: "none" }}
        >
          Export
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default ExportToHTMLModal;
