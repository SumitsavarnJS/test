import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Button,
  Select,
  MenuItem,
  Box,
  Autocomplete,
  Tooltip,
  TextField,
  Typography,
  ClickAwayListener
} from '@mui/material';
import { styled } from "@mui/material/styles";
import * as styles from "../pages/Dashboards/Dashboard.module.css"
import { inputLabelClasses } from "@mui/material/InputLabel";
import DataSource from "../pages/rptdashboard/data_source/DataSource";
import * as utils from "../common/utils/utils";
import api from "../common/api/api";
import useGlobalStore from "../store/useGlobalStore";
import useConfigStore from "../store/useConfigStore";

const DataSourceModal = ({ open, onClose, onDataSourceSelection }) => {
  const [selectedChildSource, setSelectedChildSource] = useState('');
  const [scenariosSelect, setScenariosSelect] = useState("");
  const [widgetForm, setWidgetForm] = useState([]);
  const [tempConfig, setTempConfig] = useState([]);
  const [showDataSource, setShowDataSource] = useState(false);
  const [propbucket, setbucket] = useState("");

  useEffect(() => {
    setTempConfig('');
    setScenariosSelect('')

    setWidgetForm([])

  }, [open])



  const StyledTextField = styled(TextField)`
  & .MuiInputBase-root {
    font-size: 0.8rem; 
  }
`;
  const getScenarioList = async (bucket, dataLocation) => {
    let dataSourceVal = utils.getRootDirectory(dataLocation)
    const originalString = dataSourceVal
    const insertString = bucket
    const parts = originalString.split("/");
    parts[0] = insertString;
    const modifiedString = parts.join("/");
    // condition to formal custom reports, replace _SEP_ with '/'
    let customDataSource
    if (modifiedString.includes('__SEP__')) {
      customDataSource = modifiedString.replaceAll("__SEP__", "/")
      setTempConfig(customDataSource);
      setbucket(bucket);
      onDataSourceSelection({ tempConfig: customDataSource, scenariosSelect: "" });
    }
    else {
      setTempConfig(modifiedString);
      setbucket(bucket);
      onDataSourceSelection({ tempConfig: modifiedString, scenariosSelect: "" });

    }

    const response = await api(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
      "/api/fetch_report_attributes",
      {
        bucket: bucket,
        key: utils.getRootDirectory(dataLocation),
      }
    );
    if (response.status) {
      const data = _.get(response, "data", {});
      if (data.scenarios && data.scenarios.length) {
        // return data.scenarios;
        setWidgetForm(data.scenarios);
      } else {
        setScenariosSelect("");
      }
    } else {
      console.log("sceanrio not found for " + bucket + dataLocation);
      return [];
    }
  };
  const handleScenarioChange = (scenario) => {
    if (scenario) {
      setScenariosSelect(scenario);
      setTempConfig(utils.getRootDirectory(tempConfig));
      // added new in line 83
      onDataSourceSelection({ tempConfig, scenariosSelect: scenario });

    } else {
      setTempConfig(tempConfig);
      onDataSourceSelection({ tempConfig, scenariosSelect: scenario });

      // onDataSourceSelection({ tempConfig});

    }
  };
  const dataLocationChanged = async (rootDataLocation, bucket) => {
    const scenarioList = await getScenarioList(bucket, rootDataLocation);
    let scenarioErrorFlag = false;
    let scenarioHelperText = "";
    let newDataLocation = rootDataLocation;
    if (!scenarioList?.includes(widgetForm) && widgetForm) {
      scenarioErrorFlag = true;
      scenarioHelperText = "Invalid scenario for the selected Data Source";
    } else if (widgetForm) {
      //if scenario exists and present in current root level
      newDataLocation = rootDataLocation + "/" + widgetForm;
    }
    //if only root level data is present but not scenario
    else {
      newDataLocation = rootDataLocation;
    }

    const dataObject = await getDataObject(newDataLocation, bucket);
    if (widgetForm.data) {
    } else {
    }
  };
  const handleSelection = () => {
    // onSelection(tempConfig, scenariosSelect);
    onDataSourceSelection({ tempConfig, scenariosSelect: scenario });
  };

  const getDataObject = async (dataLocation, bucket) => {
    const input = { key: dataLocation, bucket: bucket };
    const response = await api(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
      "/api/get_ldb_files",
      input
    );
    let dataHelperText = "";
    let dataErrorFlag = false;
    let dataList = [];
    if (response.status) {
      dataList = _.get(response, "data", []);
      let data = widgetForm.data;
      if (data && !dataList.includes(data)) {
        dataHelperText = "Data not present in selected Data Location";
        dataErrorFlag = true;
      }
    }
    return {
      dataList: dataList,
      dataHelperText: dataHelperText,
      dataErrorFlag: dataErrorFlag,
    };
  };
  const handleDataLocationChange = (newDataLocation, bucket) => {
    dataLocationChanged(utils.getRootDirectory(newDataLocation), bucket);
  };
  return (
    <>
      <Box>
        <Box className={styles.defaultLocationSource} >
          <Box className={styles.boxDefaultLocation} onClick={() => setShowDataSource(true)} >
            Default Data Source
          </Box>
          <Tooltip title={tempConfig} >
            <Typography className={styles.defaultLocationText}>
              {tempConfig}
            </Typography>
          </Tooltip>
        </Box>
        {showDataSource ? (
          <ClickAwayListener
            onClickAway={() => {
              setShowDataSource(false);
            }}
          >
            <Box className={styles.dataSource}>
              <DataSource
                dataLocationChanged={handleDataLocationChange}
                dataLocation={tempConfig.dataLocation}
                close={() => {
                  setShowDataSource(false);
                }}
              />
            </Box>
          </ClickAwayListener>
        ) : null}

      </Box>
      <Box>
        <Box className={styles.defaultScenarioText}>Default Scenario is</Box>
        <Autocomplete
          id="scenario-input"
          style={{ marginTop: "10px" }}
          value={scenariosSelect}
          onChange={(event, newValue) => {
            handleScenarioChange(newValue);
          }}
          size="small"
          options={widgetForm}
          renderOption={(props, option) => (
            <li key={option} {...props}>
              <Typography style={{ fontSize: '0.75rem' }}>{option}</Typography>
            </li>
          )}
          getOptionLabel={(option) => {
            if (option.includes("#")) {
              let opt = option.split("#");
              return opt[1];
            } else return option;
          }}
          fullWidth
          renderInput={(params) => (
            <StyledTextField
              {...params}
              error={tempConfig.scenarioErrorFlag}
              helperText={tempConfig.scenarioHelperText}
              label="Default Scenario"
              fullWidth
              variant="outlined"
              InputLabelProps={{
                sx: {
                  fontSize: "0.75rem",
                  [`&.${inputLabelClasses.shrink}`]: {
                    background: 'white',
                  }
                }
              }}
            />
          )}
        />
      </Box>
      <Box>
        <b>Default Data Source is :</b>
        <Tooltip title={tempConfig} >
          <p className={styles.dataSourceFooterText}>{tempConfig}
          </p>
        </Tooltip>
      </Box>
      {/* <Button onClick={handleSelection}>Select</Button> */}
    </>

  );
};
export default DataSourceModal;