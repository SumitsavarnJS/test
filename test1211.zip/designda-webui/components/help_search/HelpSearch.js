import React, { useState, useEffect, useRef, useContext } from "react";
import { styled, alpha } from "@mui/material/styles";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import dynamic from "next/dynamic";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import * as utils from "../../common/utils/utils";
import WidgetForm from "../../components/wgt_library_manager/WidgetForm";
import Markdown from 'react-markdown'
import {
  AddTemplateWgtToRpt,
  addWidgetCommonFunction,
  nonDataSpecificWidgets,
} from "../../pages/rptdashboard/addWidget/addWidget";
import useGlobalStore from "../../store/useGlobalStore";
import useConfigStore from "../../store/useConfigStore";
import { useRouter } from "next/router";
import HelpIcon from "@mui/icons-material/Help";
import CircularProgress from "@mui/material/CircularProgress";
// Imports For html Sanity and Help text Typing Effect
// import HtmlRenderer from "../../components/SearchRpt/HtmlRenderer";
// import TypingApiResponse from "../../components/SearchRpt/TypeWrite";
import CloseIcon from '@mui/icons-material/Close';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';

import axios from "axios";
import { toast } from "react-toastify";
import getConfig from "next/config";
import JsonContext from "../../contexts/JsonContext";
import Paper from "@mui/material/Paper";
import styles from "../../pages/search/search.module.css";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import { Typography, IconButton } from "@mui/material";
import * as constants from "../../constants/constants";
import Dialog from '@mui/material/Dialog';
import Slide from '@mui/material/Slide';


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
})

const AceEditor = dynamic(
  () =>
    import("../../components/queryEditor/QueryEditor").then(
      (mod) => mod.default
    ),
  { ssr: false }
);
const { publicRuntimeConfig } = getConfig();
const RootBox = styled(Box)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  height: "100%",
  padding: theme.spacing(3),
}));
const HelpPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  backgroundColor: "#fff",
  boxShadow: "1px 1px 10px 0px rgba(0,0,0,0.2)",
  borderRadius: "8px",
  width: "90%",
  marginLeft: "2%",
  marginBottom: "2%",
  position: "relative",
}));
const Text = styled(Typography)(({ theme }) => ({
  fontSize: "1rem",
  fontWeight: "600",
  marginBottom: theme.spacing(1),
}));
const KeyValueDivider = styled(Divider)(({ theme }) => ({
  flexGrow: 1,
  marginLeft: theme.spacing(1),
  marginRight: theme.spacing(1),
}));

function PrimarySearchAppBar(props) {
  console.log({props})
  const tableRef = useRef(null);
  const { configData, authLoginUser } = useConfigStore();
  const authUser = authLoginUser;
  const [openRptAdd, setOpenRptAdd] = useState(false);
  const [currentReport, setCurrentReport] = useState([]);
  const [formMode, setFormMode] = useState("edit");
  const [showHelpCard, setHelpCard] = useState(false);
  const [isLoadingHelp, setIsLoadingHelp] = useState(true);
  //New Search Params
  const [expanded, setExpanded] = useState({});
  const router = useRouter();
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedCard, setSelectedCard] = useState(null);
  const [helpText, sethelpSearch] = useState("");
  const { clickedJsons, addClickedJson } = useContext(JsonContext);
  const { allReports, allDashbrdRpts } = useGlobalStore();

  const handleMenuOpen = (event, cardId) => {
    setAnchorEl(event.currentTarget);
    setSelectedCard(cardId);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedCard(null);
  };

  const handleAddToRpt = (value) => {
    setOpenRptAdd(true);
    let arrayObj = [];
    arrayObj.push(value);
    setCurrentReport(arrayObj);
    setAnchorEl(null);
    setSelectedCard(null);
  };

  const handleAddToDbrd = async (value) => {
    const widgetSettings = utils.getWidgetSettings(value.widget_name, value);

    if (widgetSettings && widgetSettings.config) {
      let defaultDataLocation = "";
      let defaultBucket = "";
      if (utils.isRootDirectory(widgetSettings.config.dataLocation)) {
        defaultDataLocation = utils.getRootDirectory(
          _.get(allDashbrdRpts[constants.dashboardReport], "dataLocation", "")
        );
      } else {
        defaultDataLocation = _.get(
          allDashbrdRpts[constants.dashboardReport],
          "dataLocation",
          ""
        );
      }
      defaultBucket = _.get(
        allDashbrdRpts[constants.dashboardReport],
        "bucket",
        ""
      );

      if (!nonDataSpecificWidgets.includes(widgetSettings.widgetName)) {
        widgetSettings.config.dataLocation = defaultDataLocation;
        widgetSettings.config.bucket = defaultBucket;
      }
    }

    // add to dashboard
    addWidgetCommonFunction(
      constants.allDashbrdRpts,
      constants.dashboardReport,
      widgetSettings
    );

    // const dbrdInfo = {
    //   data: allDashbrdRpts.dashboardReport,
    //   user: useConfigStore.getState().authLoginUser,
    // };

    // await api(
    //   _.get(configData, "rest_server_url", "") + "/api/save_user_config",
    //   dbrdInfo
    // );

    toast.success(`Widget added to dashboard`, {
      position: toast.POSITION.BOTTOM_LEFT,
      style: {
        fontSize: "14px",
        padding: "8px  12px",
      },
    });

    setAnchorEl(null);
  };

  const handleFullScreen = (isFullScreen) => {
    setIsFullScreen(isFullScreen);
  };
  const updateTable = (data) => {
    tableRef.current.updateOrAddData(data);
  };
  const handleView = (result) => {
    let arrayObj = [];
    arrayObj.push(result);
    setWidgetForm(result);
    setIsFullScreen(true);
    setFormMode("view");
    setAnchorEl(null);
    setSelectedCard(null);
  };
  const handleCloseRpt = (value) => {
    setOpenRptAdd(false);
  };
  const routeToRpt = () => {
    // router.push({
    //   pathname: "/rptdashboard",
    // });
    setOpenRptAdd(false);
  };
  const createWidgetSettings = () => {
    let widgetSettings = [];
    let selectedRows = currentReport;
    for (let i = 0; i < selectedRows.length; i++) {
      widgetSettings.push(
        utils.getWidgetSettings(selectedRows[i].widget_name, selectedRows[i])
      );
    }
    return widgetSettings;
  };
 
  const handleHelpClick = async (searchValueFormatRoute) => {
    console.log({searchValueFormatRoute})
    setIsLoadingHelp(true);
    let payload
    if (searchValueFormatRoute.includes('tag:')) {
      payload = {
        nlt: "",
        // adding replace method
        tags: searchValueFormatRoute.replace(/tag:\s*/g, ""),
        user: authUser,
      }
    }

    else if (searchValueFormatRoute.includes('category:')) {
      payload = {
        nlt: "",
        category: searchValueFormatRoute.replace(/category:\s*/g, ""),
        user: authUser,
      }
    }
    else {
      payload = {
        nlt: searchValueFormatRoute,
        tags: "",
        user: authUser,
      }
    }
    try {
      const response = await axios.post(utils.getMLUrl() + "/api/search", payload);

      const uniqueDocIds = new Set();
      const uniqueResults = response.data.data.results.filter((result) => {
        if (uniqueDocIds.has(result.doc_id)) {
          return false;
        }
        uniqueDocIds.add(result.doc_id);
        return true;
      });

      const updatedResponseObject = {
        ...response.data,
        data: {
          ...response.data.data,
          results: uniqueResults,
        },
      };

      sethelpSearch(updatedResponseObject.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoadingHelp(false);
    }
  };
  const handleExpandClick = (id) => {
    setExpanded((prevExpandedMap) => {
      return {
        ...prevExpandedMap,
        [id]: !prevExpandedMap[id],
      };
    });
  };

  const tagClick = async (type, value) => {
    sethelpSearch("");
    let payload = {
      user: authUser,
    };
    payload[type] = value;

    setIsLoadingHelp(true);

    try {
      const response = await axios.post(
        utils.getMLUrl() + "/api/search",
        payload
      );

      const uniqueDocIds = new Set();
      const uniqueResults = response.data.data.results.filter((result) => {
        if (uniqueDocIds.has(result.doc_id)) {
          return false;
        }
        uniqueDocIds.add(result.doc_id);
        return true;
      });

      const updatedResponseObject = {
        ...response.data,
        data: {
          ...response.data.data,
          results: uniqueResults,
        },
      };

      sethelpSearch(updatedResponseObject.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoadingHelp(false);
    }
  };

  const defaultWidgetForm = {
    category: "widgets_library",
    cluster: "",
    columns: [],
    content: "",
    created_at: "",
    data: "",
    description: "",
    doc_id: "",
    location: "",
    score: 0,
    tags: "",
    title: "",
    updated_at: "",
    dataLocation: "",
    user: "",
  };
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [widgetForm, setWidgetForm] = useState(defaultWidgetForm);

  useEffect(() => {
    console.log(props.helpInputValue)
    // `${configData.rest_server_url}/api/`
    if (props.helpInputValue.length > 0) {
    
        handleHelpClick(props.helpInputValue);
        setHelpCard(true);
      
    }
  }, [props.helpInputValue]);

  return (
    <>
    <Dialog
      fullScreen
      open={props.open}
      onClose={props.onClose}
      TransitionComponent={Transition}
    >

<AppBar sx={{ position: 'relative' }}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={props.onClose}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              Help Search Result

            </Typography>

          </Toolbar>
        </AppBar>
      <div id="searchPageParent" className={styles.backgroundColorApplication}>
        <div id="searchContents" className={styles.searchContents}>
          {/* -----Bari Dashboard----------------- */}
          <div
            style={{
              marginTop: "1rem",
              marginLeft: "6.5%",
              // maxHeight: '1000px',
              width: "89%",
              alignContent: "center",
            }}
          >
          </div>
          <div>
            <>
              <div>
                <div
                  style={{
                    width: "90%",
                    // marginLeft: "2%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "flex-start",
                      marginLeft: "2%",
                    }}
                  >
                    <IconButton
                      sx={{
                        "&:hover": {
                          backgroundColor: "transparent",
                        },
                        marginLeft: "5%",
                      }}
                    >
                      <HelpIcon
                        sx={{
                          fontSize: "2rem",
                          // marginTop:'1px'
                        }}
                      />
                    </IconButton>
                    <Text
                      sx={{
                        marginTop: "0.35em",
                        marginLeft: "0px",
                        fontSize: "1.5em",
                      }}
                      variant="h1"
                      gutterBottom
                    >
                      Help Search Result
                    </Text>
                  </div>
                </div>
                <KeyValueDivider />
              </div>
              {helpText ? (
                <RootBox>
                  {isLoadingHelp ? (
                    <CircularProgress /> // Display CircularProgress spinner when API call is pending
                  ) : (
                    <>
                      <HelpPaper>
                        <Text variant="subtitle1" color="black">
                          {" "}
                          Help AI Response:
                        </Text>
                        {/* <TypingApiResponse apiResponse={helpText.summary} /> */}

                        {helpText?.summary &&
                          helpText?.summary
                            .split("\n")
                            .map((str) => (
                              <p style={{ fontSize: "16px" }}>{str}</p>
                            ))}
                      </HelpPaper>
                      {helpText?.results &&
                        helpText?.results.map((result) => (
                          <HelpPaper
                            key={result.doc_id}
                            style={{ marginBottom: "1rem" }}
                          >
                            {result.category === "manpages" ||
                              result.category === "user_guide" ||
                              result.category === "ddash_manpages" ? (
                              <div>
                                {result.doc_id ? (
                                  <Text variant="subtitle1">Ref Doc:</Text>
                                ) : (
                                  ""
                                )}

                                <Text variant="subtitle1">Category:</Text>
                                <p> {result.category} </p>
                                <Text variant="subtitle1" color="black">
                                  Title: {result.title}
                                </Text>

                                {result.tags && (
                                  <Text
                                    variant="subtitle1"
                                    color="black"
                                    style={{ marginTop: "20px" }}
                                  >
                                    Tags:
                                    {result.tags.split(",").map((item) => (
                                      <Button
                                        sx={{ spacing: 1 }}
                                        variant="outlined"
                                        key={item}
                                      >
                                        {item}
                                      </Button>
                                    ))}
                                  </Text>
                                )}
                                <Text variant="subtitle1" color="black">
                                  Content:
                                </Text>
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html: result.content,
                                  }}
                                />
                              </div>
                            ) : result.category === "widgets_library" ? (
                              <div>
                                <IconButton
                                  onClick={(event) =>
                                    handleMenuOpen(event, result.doc_id)
                                  }
                                  aria-controls={
                                    selectedCard === result.doc_id
                                      ? "menu"
                                      : undefined
                                  }
                                  aria-haspopup="true"
                                  style={{
                                    position: "absolute",
                                    top: "0px",
                                    right: "0px",
                                  }}
                                >
                                  <MoreHorizIcon />
                                </IconButton>
                                <Menu
                                  id="menu"
                                  anchorEl={anchorEl}
                                  open={
                                    Boolean(anchorEl) &&
                                    selectedCard === result.doc_id
                                  }
                                  onClose={handleMenuClose}
                                >
                                  <MenuItem
                                    onClick={() => {
                                      handleAddToDbrd(result);
                                    }}
                                  >
                                    Add To Dashboard
                                  </MenuItem>
                                  <MenuItem
                                    onClick={() => {
                                      handleAddToRpt(result);
                                    }}
                                    disabled={
                                      Object.keys(allReports).length == 0
                                    }
                                  >
                                    {" "}
                                    Add To Report{" "}
                                  </MenuItem>
                                  <MenuItem
                                    onClick={() => {
                                      handleView(result);
                                    }}
                                  >
                                    Preview
                                  </MenuItem>
                                </Menu>
                                <div
                                  style={{ display: "flex", marginTop: "10px" }}
                                >
                                  <Text variant="subtitle1" color="black">
                                    Title:
                                  </Text>
                                  <p style={{ marginRight: "15px" }}>
                                    {result.title}
                                  </p>
                                </div>
                                <Text variant="subtitle1" color="black">
                                  Description:
                                </Text>
                                <p>{result.description}</p>
                                <div
                                  style={{
                                    display: "flex",
                                    flexDirection: "row",
                                    justifyContent: "flex-start",
                                  }}
                                >
                                  <Text variant="subtitle1" color="black">
                                    Query:
                                  </Text>
                                  <IconButton
                                    style={{
                                      background: "#fff",
                                      marginTop: "-10px",
                                    }}
                                    onClick={() =>
                                      handleExpandClick(
                                        result.doc_id.toString()
                                      )
                                    }
                                  >
                                    {expanded[result.doc_id] ? (
                                      <KeyboardArrowUpIcon />
                                    ) : (
                                      <ChevronRightIcon />
                                    )}
                                  </IconButton>
                                </div>
                                {expanded[result.doc_id] && (
                                  <AceEditor
                                    placeholder="Please modify df object depending on the query."
                                    mode="python"
                                    theme="xcode"
                                    name="code_editor"
                                    width="100%"
                                    fontSize={16}
                                    maxLines={Infinity}
                                    showPrintMargin={true}
                                    showGutter={true}
                                    highlightActiveLine={true}
                                    value={result.content}
                                    setOptions={{
                                      enableBasicAutocompletion: true,
                                      enableLiveAutocompletion: true,
                                      enableSnippets: false,
                                      showLineNumbers: true,
                                      tabSize: 2,
                                    }}
                                    readOnly={true}
                                  />
                                )}
                                {result.tags && (
                                  <Text
                                    variant="subtitle1"
                                    color="black"
                                    style={{ marginTop: "20px" }}
                                  >
                                    Tags:
                                    {result.tags.split(",").map((item) => (
                                      <Button
                                        sx={{ spacing: 1 }}
                                        variant="outlined"
                                        key={item}
                                        onClick={() => {
                                          tagClick("tags", item);
                                        }}
                                      >
                                        {item}
                                      </Button>
                                    ))}
                                  </Text>
                                )}

                                <div
                                  style={{ display: "flex", marginTop: "10px" }}
                                >
                                  <Text variant="subtitle1"> Doc ID:</Text>
                                  <p style={{ marginRight: "15px" }}>
                                    {result.doc_id}
                                  </p>
                                  <strong>
                                    <p
                                      style={{ marginRight: "5px" }}
                                      variant="subtitle1"
                                    >
                                      Category:
                                    </p>
                                  </strong>
                                  <p
                                    style={{
                                      marginRight: "10px",
                                      color: "blue",
                                      textDecoration: "underline",
                                      cursor: "pointer",
                                    }}
                                    onClick={() => {
                                      tagClick("category", result.category);
                                    }}
                                  >
                                    {result.category}
                                  </p>
                                  <Text variant="subtitle1" color="black">
                                    Widget Name:
                                  </Text>
                                  <p>{result.widget_name}</p>
                                </div>
                              </div>
                            )
                              : result.category === "workflow" ? (
                                <div>
                                  <div
                                    style={{ display: "flex", marginTop: "10px" }}
                                  >
                                    <Text variant="subtitle1" color="black">
                                      Title:
                                    </Text>
                                    <p style={{ marginRight: "15px" }}>
                                      {result.title}
                                    </p>
                                  </div>
                                  <Text variant="subtitle1" color="black">
                                    Description:
                                  </Text>
                                  {/* <p>{result.description}</p> */}
                                  <Markdown>{result.description}</Markdown>
                                  <div
                                    style={{
                                      display: "flex",
                                      flexDirection: "row",
                                      justifyContent: "flex-start",
                                    }}
                                  >
                                    <Text variant="subtitle1" color="black">
                                      Query:
                                    </Text>
                                    <IconButton
                                      style={{
                                        background: "#fff",
                                        marginTop: "-10px",
                                      }}
                                      onClick={() =>
                                        handleExpandClick(
                                          result.doc_id.toString()
                                        )
                                      }
                                    >
                                      {expanded[result.doc_id] ? (
                                        <KeyboardArrowUpIcon />
                                      ) : (
                                        <ChevronRightIcon />
                                      )}
                                    </IconButton>
                                  </div>
                                  {expanded[result.doc_id] && (
                                    <AceEditor
                                      placeholder="Please modify df object depending on the query."
                                      mode="python"
                                      theme="xcode"
                                      name="code_editor"
                                      width="100%"
                                      fontSize={16}
                                      maxLines={Infinity}
                                      showPrintMargin={true}
                                      showGutter={true}
                                      highlightActiveLine={true}
                                      value={result.content}
                                      setOptions={{
                                        enableBasicAutocompletion: true,
                                        enableLiveAutocompletion: true,
                                        enableSnippets: false,
                                        showLineNumbers: true,
                                        tabSize: 2,
                                      }}
                                      readOnly={true}
                                    />
                                  )}
                                  {result.tags && (
                                    <Text
                                      variant="subtitle1"
                                      color="black"
                                      style={{ marginTop: "20px" }}
                                    >
                                      Tags:
                                      {result.tags.split(",").map((item) => (
                                        <Button
                                          sx={{ spacing: 1 }}
                                          variant="outlined"
                                          key={item}
                                          onClick={() => {
                                            tagClick("tags", item);
                                          }}
                                        >
                                          {item}
                                        </Button>
                                      ))}
                                    </Text>
                                  )}

                                  <div
                                    style={{ display: "flex", marginTop: "10px" }}
                                  >
                                    <Text variant="subtitle1"> Doc ID:</Text>
                                    <p style={{ marginRight: "15px" }}>
                                      {result.doc_id}
                                    </p>
                                    <strong>
                                      <p
                                        style={{ marginRight: "5px" }}
                                        variant="subtitle1"
                                      >
                                        Category:
                                      </p>
                                    </strong>
                                    <p
                                      style={{
                                        marginRight: "10px",
                                        color: "blue",
                                        textDecoration: "underline",
                                        cursor: "pointer",
                                      }}
                                      onClick={() => {
                                        tagClick("category", result.category);
                                      }}
                                    >
                                      {result.category}
                                    </p>
                                    <Text variant="subtitle1" color="black">
                                      Widget Name:
                                    </Text>
                                    <p>{result.widget_name}</p>
                                  </div>
                                </div>
                              )
                                : (
                                  Object.entries(result).map(([key, value]) => (
                                    <HelpPaper key={key}>
                                      <Text variant="subtitle1" color="black">
                                        {key}
                                      </Text>
                                      <Text variant="body1">{value}</Text>
                                    </HelpPaper>
                                  ))
                                )}
                          </HelpPaper>
                        ))}
                    </>
                  )}
                </RootBox>
              ) : (
                <p style={{ marginLeft: "120px" }}>Loading... </p>
              )}
            </>
            )
          </div>
        </div>
      </div>
      <div>
        {isFullScreen ? (
          <WidgetForm
            key={currentReport.doc_id}
            isFullScreen={isFullScreen}
            widgetForm={widgetForm}
            mode={formMode}
            handleFullScreen={handleFullScreen}
            updateTable={updateTable}
          />
        ) : null}
      </div>
      <div>
        {openRptAdd ? (
          <AddTemplateWgtToRpt
            open={openRptAdd}
            widgetSettings={createWidgetSettings()}
            handleClose={handleCloseRpt}
            routeToRpt={routeToRpt}
          />
        ) : null}
      </div>
      </Dialog>
    </>
    
  );
}
export default PrimarySearchAppBar;
