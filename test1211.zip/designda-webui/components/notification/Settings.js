import React from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { toast } from "react-toastify";
import { TabulatorFull as Tabulator } from "tabulator-tables";
import useConfigStore from "../../store/useConfigStore";
import axios from "axios";
import _ from "lodash";

// css imports
import styles from "./Settings.module.css";

class Settings extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      emailError: false,
      userEmailNtfnsEnabled: false,
      userUiNtfnsEnabled: false,
      userEmailNtfnsSeverity: "INFO",
      userUiNtfnsSeverity: "INFO",
      projectEmailNtfnsEnabled: false,
      projectUiNtfnsEnabled: false,
      projectEmailNtfnsSeverity: "INFO",
      projectUiNtfnsSeverity: "INFO",
      othersEmailNtfnsEnabled: false,
      othersUiNtfnsEnabled: false,
      othersEmailNtfnsSeverity: "INFO",
      othersUiNtfnsSeverity: "INFO",
      emailDisabled: true,
      data: [],
    };
    this.tableRef = React.createRef();
    this.columns = [
      { title: "Type", field: "type" },
      {
        title: "Realtime Web UI Notifications",
        field: "realtime_ui_ntfns",
        editor: true,
        editorParams: { tristate: false },
        formatter: "tickCross",
      },
      {
        title: "Email Notifications",
        field: "mail_ntfns",
        editor: true,
        editorParams: { tristate: false },
        formatter: "tickCross",
        cellEdited: this.cellClick

      },
      {
        title: "Web UI Severity",
        field: "ui_severity",
        editor: "select",
        editorParams: {
          values: ["DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"],
        },
      },
      {
        title: "Email Severity",
        field: "mail_severity",
        editor: "select",
        editorParams: {
          values: ["DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"],
        },
      },
    ];
  }

  cellClick = (cell) => {
  const columnName = cell._cell.column.field;
  const mailEnabledArray = cell._cell.column.cells;
  let boolError = this.showEmailError();
  if (cell._cell.value !== cell._cell.oldValue) { // Check if value changed
    if (columnName === "mail_ntfns") {
      const emailDisabled = !( // Check if any email notification is enabled
        mailEnabledArray[0].value ||
        mailEnabledArray[1].value ||
        mailEnabledArray[2].value
      );
      this.setState({
        emailDisabled: emailDisabled,
        emailError: boolError,
      });
    }
  }
};
  afterTableBuilt = () => {
    let boolError = false;
    try {
      boolError = this.showEmailError();
    } catch (error) {
      console.log("Settings Table issue:", error);
    }
    this.setState({ emailError: boolError });
  };

  componentDidMount() {
    this.tabulator = new Tabulator(this.tableRef.current, {
      layout: "fitColumns",
      columns: this.columns,
      cellEdited: this.cellClick,
      tablebuilt: this.afterTableBuilt,
      data: [],
    });
    this.tabulator.on("tableBuilt", () => {
      this.getSettings();
    });
  }

  getSettings = () => {
    axios
      .get(
        `${_.get(
          useConfigStore.getState().configData,
          "rest_server_url"
        )}/api/notification/get_settings/${_.get(
          useConfigStore.getState(),
          "authLoginUser",
          ""
        )}`
      )
      .then((response) => {
        response = response.data;
        const success = _.get(response, "status", false);

        if (!success) {
          const message = _.get(response, "message", "Unknown error");
          toast.error(message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          console.error(message);
          //   this.props.close();
        } else {
          const data = _.get(response, "data", {});
          const tableData = [
            {
              type: "User",
              realtime_ui_ntfns: data.user_ntfn_web_enabled,
              mail_ntfns: data.user_ntfn_mail_enabled,
              ui_severity: data.user_ntfn_web_severity,
              mail_severity: data.user_ntfn_mail_severity,
            },
            {
              type: "Project",
              realtime_ui_ntfns: data.project_ntfn_web_enabled,
              mail_ntfns: data.project_ntfn_mail_enabled,
              ui_severity: data.project_ntfn_web_severity,
              mail_severity: data.project_ntfn_mail_severity,
            },
            {
              type: "Others",
              realtime_ui_ntfns: data.others_ntfn_web_enabled,
              mail_ntfns: data.others_ntfn_mail_enabled,
              ui_severity: data.others_ntfn_web_severity,
              mail_severity: data.others_ntfn_mail_severity,
            },
          ];
          const table = this.tabulator;
          console.log(table, this.tabulator);
          if (table) {
            table.replaceData(tableData);

          }
          this.setState({
            email: data.email,
            userEmailNtfnsEnabled: data.user_ntfn_mail_enabled,
            userUiNtfnsEnabled: data.user_ntfn_web_enabled,
            userEmailNtfnsSeverity: data.user_ntfn_mail_severity,
            userUiNtfnsSeverity: data.user_ntfn_web_severity,
            projectEmailNtfnsEnabled: data.project_ntfn_mail_enabled,
            projectUiNtfnsEnabled: data.project_ntfn_web_enabled,
            projectEmailNtfnsSeverity: data.project_ntfn_mail_severity,
            projectUiNtfnsSeverity: data.project_ntfn_web_severity,

            othersEmailNtfnsEnabled: data.others_ntfn_mail_enabled,
            othersUiNtfnsEnabled: data.others_ntfn_web_enabled,
            othersEmailNtfnsSeverity: data.others_ntfn_mail_severity,
            othersUiNtfnsSeverity: data.others_ntfn_web_severity,

            emailDisabled: !(
              data.user_ntfn_mail_enabled ||
              data.project_ntfn_mail_enabled ||
              data.others_ntfn_mail_enabled
            ),
          });
        }
      })
      .catch((error) => {
        toast.error(error, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        console.error(error);
      });
  };
  isValidEmail = (email) => {
    const re =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
  };
  disableSave = () => {
    if (this.state.email) {
      return this.showEmailError();
    } else {
      return false;
    }
  };
  saveSettings = () => {
    const table = this.tabulator;
    const rowData = table.getData();

    this.setState({
      userEmailNtfnsEnabled: rowData[0].realtime_ui_ntfns,
      userUiNtfnsEnabled: rowData[0].mail_ntfns,
      userEmailNtfnsSeverity: rowData[0].ui_severity,
      userUiNtfnsSeverity: rowData[0].mail_severity,

      projectEmailNtfnsEnabled: rowData[1].realtime_ui_ntfns,
      projectUiNtfnsEnabled: rowData[1].mail_ntfns,
      projectEmailNtfnsSeverity: rowData[1].ui_severity,
      projectUiNtfnsSeverity: rowData[1].mail_severity,

      othersEmailNtfnsEnabled: rowData[2].realtime_ui_ntfns,
      othersUiNtfnsEnabled: rowData[2].mail_ntfns,
      othersEmailNtfnsSeverity: rowData[2].ui_severity,
      othersUiNtfnsSeverity: rowData[2].mail_severity,
    });

    const payload = {
      user: _.get(useConfigStore.getState(), "authLoginUser", ""),
      email: this.state.email,
      user_ntfn_web_enabled: rowData[0].realtime_ui_ntfns,
      user_ntfn_mail_enabled: rowData[0].mail_ntfns,
      user_ntfn_web_severity: rowData[0].ui_severity,
      user_ntfn_mail_severity: rowData[0].mail_severity,

      project_ntfn_web_enabled: rowData[1].realtime_ui_ntfns,
      project_ntfn_mail_enabled: rowData[1].mail_ntfns,
      project_ntfn_web_severity: rowData[1].ui_severity,
      project_ntfn_mail_severity: rowData[1].mail_severity,

      others_ntfn_web_enabled: rowData[2].realtime_ui_ntfns,
      others_ntfn_mail_enabled: rowData[2].mail_ntfns,
      others_ntfn_web_severity: rowData[2].ui_severity,
      others_ntfn_mail_severity: rowData[2].mail_severity,
    };
    axios
      .post(
        `${_.get(
          useConfigStore.getState().configData,
          "rest_server_url",
          ""
        )}/api/notification/save_settings`,
        payload
      )
      .then((response) => {
        response = response.data;
        const success = _.get(response, "status", false);

        if (!success) {
          const message = _.get(response, "message", "Unknown error");
          toast.error(message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          console.error(message);
        } else {
          toast.success("Setting saved", {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        }
      })
      .catch((error) => {
        toast.error(error, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        console.error(error);
      });
  };

  showEmailError = () => {
    if (!this.tabulator) {
      return false;
    }
    const table = this.tabulator;
    if (!table) {
      return false;
    }
    const rowData = table.getData();
    if (rowData.length > 0) {
      if (
        !(
          rowData[0].mail_ntfns ||
          rowData[1].mail_ntfns ||
          rowData[2].mail_ntfns
        )
      ) {
        return false;
      }
    }

    return !this.isValidEmail(this.state.email);
  };
  render() {
    return (
      <div id="ntfsSettings" className={styles.settingsParent}>
        <Typography variant="h5" style={{ marginBottom: "20px" }}>
          Settings
        </Typography>

        <TextField
          // fullWidth
          error={this.showEmailError()}
          disabled={this.state.emailDisabled}
          label="Email"
          size="small"
          style={{ marginBottom: "10px" }}
          value={this.state.email}
          InputLabelProps={{
            shrink: true,
          }}
          onChange={(event) => {
            this.setState({ email: event.target.value });
          }}
          variant="outlined"
        />
        <br />
        <div id="analytics">
          <div ref={(ref) => (this.tableRef.current = ref)} />
        </div>
        <Button
          variant="contained"
          onClick={this.saveSettings}
          disabled={this.disableSave()}
          disableRipple
          className={
            this.disableSave()
              ? styles["save-button-disabled"]
              : styles["save-button"]
          }>Save
        </Button>
      </div>
    );
  }
}
export default Settings;