import React, { useEffect, useState } from 'react';
import { detect } from 'detect-browser';
import { Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button } from '@mui/material';
 
const BrowserCheck = () => {
  const [dialogContent, setDialogContent] = useState('');
  const [dialogTitle, setDialogTitle] = useState('');
 
  useEffect(() => {
    const browser = detect();
    if (browser) {
      const version = parseInt(browser.version, 10);
const name = browser.name;
      if (name === 'chrome' || name === 'firefox') {
        if (version < 93) {
          setDialogTitle('Outdated Browser Version');
          setDialogContent(`You are using an outdated version of ${name}. Please update to the latest or ( minimum 93) version for the best experience.`);
        }
      } else {
        setDialogTitle('Browser Recommendation');
        setDialogContent('You are using an unsupported browser. For the best experience, please use the latest or (minimum 93) version of Chrome or Firefox.');
      }
    }
  }, []);
 
  return (
    <Dialog
      open={!!dialogContent}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle id="alert-dialog-title">{dialogTitle}</DialogTitle>
      <DialogContent>
        <DialogContentText id="alert-dialog-description">
          {dialogContent}
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={() => window.location.reload()}
          color="primary"
          variant="contained"
        >
          Refresh
        </Button>

        <Button
          onClick={() =>setDialogContent('')}
          color="primary"
          variant="contained"
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};
 
export default BrowserCheck;