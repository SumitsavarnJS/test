import React, { useState, useEffect } from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import useGlobalStore from "../../store/useGlobalStore";
import Divider from "@mui/material/Divider";
import { toast } from "react-toastify";
import refreshWidgetContent from "../../pages/rptdashboard/wigetWrapper/widgetRefreshData";
import axios from "axios";
import useConfigStore from "../../store/useConfigStore";
import { useRouter } from "next/router";
import * as constants from "../../constants/constants";

import getConfig from "next/config";

const { publicRuntimeConfig } = getConfig();
const imageUrl = publicRuntimeConfig.basePath;
const RecentComponent = (props) => {
  const { isOpen, onClose, param, toggleApi, searchString } = props;

  const { configData, authLoginUser } = useConfigStore();
  const router = useRouter();
  const [dashboardData, setDashboardData] = useState(null);

  // console.log("dashboard data",dashboardData)
  useEffect(() => {
    // console.log("recent component loaded");
    dashboardClick();
  }, []);

  const dashboardClick = async () => {
    await axios
      .post(configData.rest_server_url + "/api/get_recent_reports_info", {
        user: authLoginUser,
      })
      .then((reportResponse) => {
        // console.log("reportResponse",{ reportResponse });
        const response = reportResponse.data.recent_reports;
        
        // const json = await response.json();
        setDashboardData(response);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const getDashboardData=async(title,dashData)=>{
    await axios
      .post(configData.rest_server_url + "/api/read_json_from_path", {
        path: dashData,
        exact_path:true
      })
      .then((reportResponse) => {
        if (reportResponse.data  && reportResponse.data.data  &&  Object.hasOwn(reportResponse.data.data,"widgets")  &&  Object.keys(reportResponse.data.data.widgets).length >0 ) {
          let rpt = dashData;
          let rptData = reportResponse.data.data;
         
          toast.info("Report Added To Queue", {
            position: toast.POSITION.BOTTOM_LEFT,
          });

          const tempregex = /(template|templates)/i;
          if (tempregex.test(rpt) && rptData.widgetsOrder) {
            const widgetsOrder = rptData.widgetsOrder;

            let rptDataClone = _.cloneDeep(rptData);
            delete rptDataClone.widgets;
            rptDataClone["widgets"] = {};

            //add widgets according to the new order given
            for (let index = 0; index < widgetsOrder.length; index++) {
              rptDataClone["widgets"][widgetsOrder[index]] =
                rptData["widgets"][widgetsOrder[index]];
            }

            // set the new ordered data report
            rptData = rptDataClone;

          }
          useGlobalStore.getState().updateGlobalObject(rptData.fileName, rptData);
          if (rptData.hasOwnProperty("widgets")) {
            // console.log("rptData.widgets",rptData.widgets)
            for (const Wkey in rptData.widgets) {
              let WkeyObj = {
                data: {},
                uiState: {
                  isLoading: false,
                  showConfig: false,
                  isToastOpen: false,
                  toastSeverity: "info",
                  toastMessage: "",
                  cirlularLoading: false,
                },
              };
              useGlobalStore.getState().setRootLevelData(Wkey, WkeyObj);
            }
          }

          const widgetArray =  Object.hasOwn(rptData,"widgets") && Object.keys(rptData.widgets);
          if (!tempregex.test(rpt)) {
            for (let i = 0; i < widgetArray.length; i++) {
              const widgetId = widgetArray[i];
              const config = rptData.widgets[widgetId].config;
              const name = rptData.widgets[widgetId].name;
              const rptType = rptData.widgets[widgetId]?.rptType
                ? rptData.widgets[widgetId]?.rptType
                : constants.allReports;
              const reportKey = rptData.widgets[widgetId]?.reportKey
                ? rptData.widgets[widgetId]?.reportKey
                : "";
                const rptDataVariablesCheck = rptData.hasOwnProperty('variables')  && rptData?.variables  ? rptData.variables : {}
                const widgetVariables = Object.keys(rptDataVariablesCheck).length >0 ? rptDataVariablesCheck :{}
              refreshWidgetContent({
                widgetId: widgetId,
                config: config,
                widgetName: name,
                reportKey: reportKey,
                rptType: rptType,
                variables:widgetVariables ? widgetVariables:{}
              });
            //condition to open the clicked report as current report in tabbed view
            if( useGlobalStore
              .getState().analyticsReportView.view==='tab'){
                useGlobalStore
                .getState()
                .setRootLevelData("analyticsReportView", {
                  view: "tab",
                  currentTab:rptData.fileName,
                });
              }
            }
          }
        } else {
          toast.error(reportResponse?.data?.message? reportResponse?.data?.message:'API Response Error', {
            position: toast.POSITION.BOTTOM_LEFT,
            style: { backgroundColor: "red", color: "white" },
          });
        }
      })
      .catch((error) => {
        toast.error(error, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: { backgroundColor: "red", color: "white" },
        });
      });

  }

  return (
    <>
      <img src={`${imageUrl}/RecentRep.png`} />
      <List
        sx={{
          width: "100%",
          // maxWidth: 360,
          bgcolor: "background.paper",
          position: "relative",
          overflow: "auto",
          maxHeight: 300,
          "& ul": { padding: "3px" },
        }}
        subheader={<li />}
      >
        {dashboardData &&
          Object.keys(dashboardData).map((sectionId) => (
            <li key={`section-${sectionId}`}>
              <ul>
                <ListItem
                  style={{ cursor: "pointer" }}
                  key={sectionId}
                  onClick={() => getDashboardData(sectionId,dashboardData[sectionId])}
                >
                  {sectionId.replace(".json", "")}
                </ListItem>
                <Divider
                  sx={{
                    backgroundColor: "black",
                    flexGrow: 1,
                    marginLeft: 2,
                    marginRight: 2,
                  }}
                />
              </ul>
            </li>
          ))}

        {/* ))} */}
      </List>
    </>
  );
};

export default RecentComponent;
