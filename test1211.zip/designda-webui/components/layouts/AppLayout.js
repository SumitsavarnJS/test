import withPrivateRoute from "../../pages/auth/withPrivateRoute";

import React from 'react'

function AppLayout({children}) {
    return (
        <div> {children}</div>
    )
}

export default withPrivateRoute(AppLayout)
