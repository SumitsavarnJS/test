import React from "react";
import LayoutComponent from "./LayoutComponent";
import { useRouter } from "next/router";
const Layout = ({ children, showAppBar }) => {
  const router = useRouter();
  showAppBar = router.pathname === "/Login";
  return (
    <div>
      {!showAppBar && <LayoutComponent />}
      {children}
    </div>
  );
};

export default Layout;
