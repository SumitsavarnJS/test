import axios from "axios";
import useConfigStore from "../../../store/useConfigStore";
import useGlobalStore from "../../../store/useGlobalStore";
import { useRouter } from "next/router";
import { toast } from "react-toastify";
import { useEffect, useState } from 'react';

const LicenseChecker = () => {

  const router = useRouter();
  const {
    configData,
    setAuth,
    userLicenseId,
  } = useConfigStore();

  const [consecutiveFailures, setConsecutiveFailures] = useState(0);

  useEffect(() => {
    const checkLicense = async () => {
      try {
        const response = await axios.post(
          useConfigStore.getState().configData.rest_server_url + "/license/licenseHeartbeat/",
          {
            licenseId: userLicenseId,
            userName: useConfigStore.getState().authLoginUser,
          }
        )
         if (response.data.success) {
          setConsecutiveFailures(0); // Reset consecutive failures on successful response
        }
        else{
         throw new Error('Request failed');
        }
      } catch (error) {
        console.log(error)
        setConsecutiveFailures(prevFailures => prevFailures + 1);
        if (consecutiveFailures >= 2) {
          // Log out the application after 3 consecutive failures
          logoutFunc()
        }
      }
    };
    const interval = setInterval(checkLicense, 10 * 60 * 1000); // 10 minutes interval
    return () => clearInterval(interval); // Clean up the interval on component unmount
  }, [consecutiveFailures]);

  const logoutFunc = () => {
    let rptData = {
      dashboardReport: {
        fileName: "",
        config: { expanded: false },
        widgets: {},
      },
    };
    axios
      .post(`${configData.rest_server_url}/license/licenseRelease/`, {
        licenseId: userLicenseId,
      })
      .then((response) => {
        // check response for success or failure
        if (response.data.success) {
          toast.info(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          useGlobalStore.getState().updateDashboardObject(rptData);
          setAuth(false);
          // router.reload();
        } else {
          toast.info(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          useGlobalStore.getState().updateDashboardObject(rptData);
          setAuth(false);
          router.push("/Login");
          router.reload();
        }
      })
      .catch((error) => {
        console.log(error);
        useGlobalStore.getState().updateDashboardObject(rptData);
        setAuth(false);
        router.push("/Login");
        router.reload();
      });
  };

  return <></>; // This component doesn't render anything
};

export default LicenseChecker;