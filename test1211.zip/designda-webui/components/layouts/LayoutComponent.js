import React from "react";
import Box from "@mui/material/Box";
import SearchIcon from "@mui/icons-material/Search";
import MuiDrawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import AppBar from "@mui/material/AppBar";
import { useRouter } from "next/router";
import { useState, useEffect, useRef } from "react";
import { useMsal } from '@azure/msal-react';
import getConfig from "next/config";
import Toolbar from "@mui/material/Toolbar";
import { toast } from "react-toastify";
import Divider from "@mui/material/Divider";
import ModalComponent from "../ModalComponent/ModalComponent";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import SettingsIcon from "@mui/icons-material/Settings";
import Joyride from "react-joyride";
import Admin from "../admin/admin";
import HelpSearch from "../../components/help_search/HelpSearch"

import {
  IconButton,
  Collapse,
  Badge,
  Modal,
  Fade,
  Button,
  Card,
  CardContent,
  CardActions,
} from "@mui/material";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import axios from "axios";
import useConfigStore from "../../store/useConfigStore";
import { styled, alpha, useTheme } from "@mui/material/styles";
import styles from "../../pages/search/search.module.css";
import Tooltip from "@mui/material/Tooltip";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import useGlobalStore from "../../store/useGlobalStore";
import {
  faCheckCircle,
  faTimesCircle,
} from "@fortawesome/free-solid-svg-icons";
import Switch from "@mui/material/Switch";
// import question_mark from "../../public/question_mark.png";
// import search_icon from "../../public/search_icon.png";
import HeartBearCheck from "./heartbeat/HeartBeatCheck";
import RefreshSSoToken from './ssorefreshtoken/MsAzureSSORefreshToken'
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import useWebSocket from "react-use-websocket";
import _ from "lodash";
import api from "../../common/api/api";
import { useSnackbar } from "notistack";
// import Notification from "../../common/ntfs_components/NotificationComp";
// import useSound from "use-sound";
import Head from "next/head";
import dynamic from "next/dynamic";
import UserProfile from "../UserProfile";

// import ReportSpecEditorDialog from "./reportSpec/ReportSpecModal";
// import ManageBuildsDialog from "./manage_builds/ManageBuildsModal";

const Markdown = dynamic(
  () => import("@uiw/react-markdown-preview").then((mod) => mod.default),
  { ssr: false }
);
function Preview(props) {
  return (
    <div data-color-mode={useConfigStore.getState().theme}>
      <Markdown disableCopy={false} source={props.text} />
    </div>
  );
}
const MaterialUISwitch = styled(Switch)(() => ({
  width: 62,
  height: 34,
  padding: 7,
  "& .MuiSwitch-switchBase": {
    margin: 1,
    padding: 0,
    transform: "translateX(6px)",
    "&.Mui-checked": {
      color: "#fff",
      width: 32,
      height: 32,
      transform: "translateX(22px)",
      "& .MuiSwitch-thumb:before": {
        // backgroundImage: `url(${question_mark.src})`,
        backgroundSize: "100% 100%",
      },
      "& + .MuiSwitch-track": {
        opacity: 1,
        backgroundColor: "#8796A5",
      },
    },
  },
  "& .MuiSwitch-thumb": {
    backgroundColor: "white",
    width: 32,
    height: 32,
    "&:before": {
      content: "''",
      position: "absolute",
      width: "100%",
      height: "100%",
      left: 0,
      top: 0,
      backgroundRepeat: "no-repeat",
      backgroundPosition: "center",
      // backgroundImage: `url(${search_icon.src})`,
      backgroundSize: "70% 70%",
    },
  },
  "& .MuiSwitch-track": {
    opacity: 1,
    backgroundColor: "#8796A5",
    borderRadius: 20 / 2,
  },
}));

const SearchBox = styled("div")({
  display: "flex",
  alignItems: "center",
  // borderRadius: 30,
  // backgroundColor: alpha("#f2f2f2", 0.75),
  paddingLeft: "10px",
  paddingRight: "1px",
  boxShadow: "2px 3px 3px rgba(0, 0, 0, 0.1)",
  backgroundColor: "white",
  fontSize: "12px",
  lineHeight: "28px",
  borderRadius: "30px",
});
const SearchButton = styled(IconButton)({
  padding: 5,
});

function LayoutComponent() {
  const { instance } = useMsal();
  const { enqueueSnackbar } = useSnackbar();
  // const [playMessageSound] = useSound("sounds/flute.mp3");
  // const [playVibrationSound, { stop, isPlaying }] = useSound(
  //   "sounds/vibration.mp3"
  // );
  const theme = useTheme();
  const { publicRuntimeConfig } = getConfig();
  const {
    isAuthenticated,
    configData,
    setAuth,
    authLoginUser,
    userLicenseId,
    setRootLevelData,
    metricProjectName,
    widLibDataSource,
  } = useConfigStore();
  const [isOpen, setIsOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const searchBoxRef = useRef(null);
  const suggestionListRef = useRef(null);
  const imageUrl = publicRuntimeConfig.basePath;
  const [parameter, setParameter] = useState("");
  const [open, setOpen] = useState(false);
  const [sugList, setSuggestionsList] = useState(false);
  const dashboardData = "";
  const [dataSearch, setDataSearchOn] = useState(true);
  const [queryChange, setQueryChange] = useState(true);
  const [anchorEl, setAnchorEl] = useState(null);
  const [ntfsAnchorEl, setNtfsAnchorEl] = useState(null);
  const [openNtfsModal, setOpenNtfsModal] = useState([]);
  const [toggleApi, setToggleApi] = useState(false);
  const [selectedButton, setSelectedButton] = useState(
    useConfigStore.getState().activeRouteMenu
  );
  const [isPreferenceClickedFromParent, setIsPreferenceClickedFromParent] =
    useState(false);
  const [isRptSpecEditorOpen, setIsRptSpecEditorOpen] = useState(false);
  const [openManageBuilds, setOpenManageBuilds] = useState(false);
  const [helpSearchDialogue, setHelpSearchDialogue] = useState(false)

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    maxWidth: "85%",
    bgcolor: "background.paper",
    border: "1px solid #000",
    boxShadow: 24,
    borderRadius: "5px",
  };
  const [expanded, setExpanded] = React.useState(false);
  const [ntfs, setNtfs] = useState([]);
  const { sendMessage, lastMessage } = useWebSocket(
    _.get(useConfigStore.getState().configData, "rest_server_url", "").replace(
      "http",
      "ws"
    ) +
      "/api/notification/fetch_updates/" +
      _.get(useConfigStore.getState(), "authLoginUser", "")
  );
  const handleTourFlag = async () => {
    setModalOpen(false);
    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/save_profile_config",
        {
          data: {
            checkpoint: "",
            project: metricProjectName,
            bucket: "",
            isTourFlag: false,
            widLibDataSource: { ...widLibDataSource },
          },
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          toast.success(`Preferences saved successfully`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        } else {
          toast.error(`Preferences could not be saved`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          console.log("Failed to save Profile Pref");
        }
      })
      .catch((error) => {
        console.log(error);
        toast.error(`Failed to reach Server`, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        console.log("Failed to reach Server");
      });
  };
  const getNtfs = () => {
    axios
      .get(
        _.get(useConfigStore.getState().configData, "rest_server_url", "") +
          "/api/notification/get_notifications/" +
          _.get(useConfigStore.getState(), "authLoginUser", "")
      )
      .then((response) => {
        if (response.status) {
          if (response.data.status) {
            const data = response.data.data;
            setNtfs(data);
            for (let i = 0; i < data.length; i++) {
              console.log(
                _.get(data[i], "severity", "") == "CRITICAL",
                !data[i].is_read,
                _.get(data[i], "severity", "") == "CRITICAL" && !data[i].is_read
              );
              if (
                _.get(data[i], "severity", "") == "CRITICAL" &&
                !data[i].is_read
              ) {
                setOpenNtfsModal([
                  ...openNtfsModal,
                  {
                    id: _.get(data[i], "id", ""),
                    heading: "CRITICAL",
                    title: _.get(data[i], "title", "NO TITLE"),
                    desc: _.get(data[i], "desc", "NO DESC"),
                  },
                ]);
              }
            }
          }
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const handleClose = () => {
    setModalOpen(false);
  };
  const handleTour = () => {
    setModalOpen(false);
    setEnabled(true);
  };
  const getProfile = async () => {
    const url = configData.rest_server_url + "/api/get_profile_config";
    const input = { user: authLoginUser };
    const response = await api(url, input);

    if (
      response &&
      response?.profile_config &&
      Object.keys(response.profile_config).length > 1
    ) {
      let defaultMetricProject = response.profile_config.project;
      useConfigStore.getState().setMetricProjectName(defaultMetricProject);
    } else {
      const userProjectResponse = await axios.post(
        configData.rest_server_url + "/api/fetch_buckets",
        { user: authLoginUser }
      );
      const userProjectData = userProjectResponse.data;
      let updateProjectVal = userProjectData.data[0];
      useConfigStore.getState().setMetricProjectName(updateProjectVal);
    }

    if (
      response &&
      response.profile_config &&
      response.profile_config.widLibDataSource
    ) {
      const savedDataSource = _.get(
        response.profile_config,
        "widLibDataSource",
        {
          taskData: { dataLocation: "#", bucket: "" },
          flowData: { dataLocation: "#", bucket: "" },
          customData: { dataLocation: "#", bucket: "" },
        }
      );
      setRootLevelData("widLibDataSource", {
        ...widLibDataSource,
        ...savedDataSource,
      });
    }

    if (response && response?.profile_config) {
      if (response.profile_config?.isTourFlag === false) {
        setModalOpen(false);
        setRootLevelData("isTourFlag", false);
      } else {
        setModalOpen(true);
      }
    }
  };
  const getSearchTags = async () => {
    const url =
      useConfigStore.getState().configData.rest_server_url + "/api/get_tags";
    try {
      const response = await axios.get(url);
      if (response && response.data) {
        let tagsValue = response?.data?.data;
        tagsValue && tagsValue.length > 0
          ? setdatasuggestions1(tagsValue.sort())
          : setdatasuggestions1([]);
      }
    } catch (e) {
      console.log(e);
    }
  };

  //added async await to handle initial load of apis successfully
  useEffect(() => {
    if (isAuthenticated) {
      (async () => {
        sendMessage(JSON.stringify({ endpoints: ["notifications_hub"] }));
        await getNtfs();
        await getProfile();
        await getSearchTags();
        if(!Object.hasOwn(useConfigStore.getState().configData, 'rest_server_url')){
          const configResponse = await fetch("/v1/config.json");
                const data = await configResponse.json();
                useConfigStore.getState().setConfigData(data);
        }
      })();
    }
  }, [isAuthenticated]);
  const handleExpand = (notfsArgs) => {
    markAsRead([_.get(notfsArgs, "ntfsId", "")]);
  };
  useEffect(() => {
    if (lastMessage !== null) {
      const data = JSON.parse(lastMessage.data);
      if (data.status) {
        setNtfs([data.data, ...ntfs]);
        if (_.get(data.data, "severity", "") == "CRITICAL") {
          // disable notification sound
          // playVibrationSound();
          setOpenNtfsModal([
            ...openNtfsModal,
            {
              id: _.get(data.data, "id", ""),
              heading: "CRITICAL",
              title: _.get(data.data, "title", "NO TITLE"),
              desc: _.get(data.data, "desc", "NO DESC"),
            },
          ]);
        } else {
          // disable notification sound
          // playMessageSound();
          enqueueSnackbar(_.get(data.data, "title", "NO TITLE"), {
            variant: "ntfs",
            anchorOrigin: { horizontal: "right", vertical: "bottom" },
            autoHideDuration: 10000,
            bgColor: getNtfsColor(_.get(data.data, "severity", "DEBUG")),
            desc: _.get(data.data, "desc", ""),
            ntfsId: _.get(data.data, "id", ""),
            handleExpand: handleExpand,
          });
        }
      }
    }
  }, [lastMessage]);
  const closeNtfsModal = (value, index) => {
    openNtfsModal.splice(index, 1);
    setOpenNtfsModal(openNtfsModal);
    markAsRead([value.id]);
    stop();
  };
  const steps = [
    {
      target: "#profile",
      content:
        "Kindly Select the Necessary Profile Preferences First, In Order to Get Started",
      disableBeacon: true,
      // placement: "left"
    },
    {
      target: "#analyitcs",
      content:
        "Route To Analytics Page, To View Reports, Templates and Related Menus.",
      disableBeacon: true,
      placement: "right",
    },
    {
      target: "#dashboards",
      content:
        "Dashboard Page, Widgets Associated to the dashboards will show at this page ",
      disableBeacon: true,
      placement: "right",
    },
    {
      target: "#logo",
      content: "Click on the Logo to come back on Dashboard page",
      disableBeacon: true,
      placement: "left",
    },
    {
      target: "#help",
      content:
        "You can use this button to toggle between Help search & Data Search",
      disableBeacon: true,
      placement: "right",
    },
    {
      target: "#notificationIcon",
      content: "Notifications will popup over here",
      disableBeacon: true,
      placement: "left",
    },
    {
      target: "#right",
      content:
        "Dashboard Related Menus \n Add Widgets to the Dashboard \n ,Save, \n Add New Dashboard, \n Delete and Share it to other users",
      disableBeacon: true,
      placement: "left",
    },
    {
      target: "#right-one",
      content:
        "You Can Set a Data Location and add corresponding widgets to the Dashboard with the selected Data Location.",
      disableBeacon: true,
      placement: "left",
    },
    {
      target: "#right-two",
      content:
        " Select Dashboard from existing Dashboards, \n Add Widgets from Library of Widgets, \n Copy Link of the Dashboard",
      disableBeacon: true,
      placement: "left",
    },
  ];
  const getUnreadCount = () => {
    let count = 0;
    for (let i = 0; i < ntfs.length; i++) {
      if (!ntfs[i].is_read) {
        count++;
      }
    }
    return count;
  };
  const handleNtfsExpand = (ntfsId, isExpanded) => {
    setExpanded(isExpanded ? ntfsId : false);
    let isIdRead = false;
    for (let i = 0; i < ntfs.length; i++) {
      if (ntfs[i].id == ntfsId && ntfs[i].is_read) {
        isIdRead = true;
      }
    }
    if (!isIdRead) {
      markAsRead([ntfsId]);
    }
  };
  const markAsRead = async (idsArray) => {
    const payload = { ids: idsArray };
    const response = await api(
      _.get(useConfigStore.getState().configData, "rest_server_url", "") +
        "/api/notification/mark_as_read",
      payload
    );
    if (response.status) {
      //mark as read in local state
      console.log(response);
      const readNtfs = _.cloneDeep(ntfs);
      for (let i = 0; i < readNtfs.length; i++) {
        if (idsArray.includes(readNtfs[i].id)) {
          readNtfs[i].is_read = true;
        }
      }
      setNtfs(readNtfs);
    }
  };
  let drawerWidth = 241;
  // let dashboardWidth = dashboardData
  //   ? Math.max(...Object.keys(dashboardData)?.map((item) => item.length * 10))
  //   : "";
  // if (drawerWidth < dashboardWidth) {
  //   drawerWidth = dashboardWidth;
  // }
  const openedMixin = (theme) => ({
    width: 241,
    backgroundColor: "#E7D9F3",
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: "hidden",
    marginTop: "64px",
    border: "1.5px solid grey",
  });
  const closedMixin = (theme) => ({
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: "hidden",
    marginTop: "64px",
    // border:'1.5px solid grey',
    backgroundColor: "#E7D9F3",
    width: 241,
    [theme.breakpoints.up("sm")]: {
      width: `calc(${theme.spacing(8)} + 1px)`,
      // boxShadow: "1px 0px 10px 0px rgba(0,0,0,0.2)",
      // borderRadius: '8px',
    },
  });
  const Drawer = styled(MuiDrawer, {
    shouldForwardProp: (prop) => prop !== "open",
  })(({ theme, open }) => ({
    width: drawerWidth,
    // flexShrink: 0,
    whiteSpace: "nowrap",
    boxSizing: "border-box",
    ...(open && {
      ...openedMixin(theme),
      "& .MuiDrawer-paper": openedMixin(theme),
    }),
    ...(!open && {
      ...closedMixin(theme),
      "& .MuiDrawer-paper": closedMixin(theme),
    }),
  }));

  //New Search Params
  const [dataInputValue, setdataInputValue] = useState("");
  const [helpInputValue, sethelpInputValue] = useState("");
  const [datacurrentStep, setdatacurrentStep] = useState(0);
  const [changeVar, setChangeVar] = useState(null);
  const [datasuggestions1, setdatasuggestions1] = useState([]);
  // const [datasuggestions2, setdatasuggestions2] = useState(["=", "!="]);
  const datasuggestions2 = ["=", "!="];

  const [datasuggestions3, setdatasuggestions3] = useState([]);
  const datasuggestions4 = ["AND", "OR", "(", ")"];
  const [currentSuggestiondataListIndex, setCurrentSuggestiondataListIndex] =
    useState(0);
  const [selectedSuggestion1, setSelectedSuggestion1] = useState("");
  const [formattedValue, setFormattedValue] = useState("");
  const [isValid, setIsValid] = useState(true);

  const router = useRouter();

  const handleModalClick = (param) => {
    setIsOpen(true);
    if (param) {
      setToggleApi((prevState) => !prevState);
      setParameter(param);
      if (param === "Preferences") {
        setAnchorEl(null);
      }
    } else {
      setParameter(param);
    }

    if (param === "Empty_Data_Search_Query") {
      setIsOpen(false);
    }
  };

  const DrawerHeader = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  }));

  const getDashboardData = (dashData) => {
    setOpen(!open);
    let rptData = {
      dashboardReport: {
        fileName: "",
        config: { expanded: false },
        widgets: {},
      },
    };
    useGlobalStore.getState().updateDashboardObject(rptData);
    axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/save_user_config",
        {
          data: dashData,
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          //   Handle success here, e.g. update state or show success message
          useGlobalStore.getState().setDashboardChange(dashData.fileName);
          toast.info(`Current Dashboard Changed to ${dashData.fileName}`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
        } else {
          console.log("Failed to save analytics report");
        }
      })
      .catch((error) => {
        console.log(error);
      });
    handleLogoClick();
  };
  const logoutFunc = () => {
    let rptData = {
      dashboardReport: {
        fileName: "",
        config: { expanded: false },
        widgets: {},
      },
    };
    axios
      .post(`${configData.rest_server_url}/license/licenseRelease/`, {
        licenseId: userLicenseId,
      })
      .then((response) => {
        // check response for success or failure
        if (response.data.success) {
          toast.info(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          useGlobalStore.getState().updateDashboardObject(rptData);
          if(Object.hasOwn(configData, 'sso_azure') ){  
            instance.logoutPopup()({
              // mainWindowRedirectUri:'/Login',
              account:instance.getActiveAccount()
            }).catch((error)=>console.log(error))
            setAuth(false);
            router.reload();
          }
          setAuth(false);
          router.reload();
        } else {
          toast.info(response.data.message, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          useGlobalStore.getState().updateDashboardObject(rptData);
          setAuth(false);
          router.push("/Login");
          router.reload();
        }
      })
      .catch((error) => {
        console.log(error);
        useGlobalStore.getState().updateDashboardObject(rptData);
        setAuth(false);
        router.push("/Login");
        router.reload();
      });
  };

  
  const handleLogoClick = () => {
    setSelectedButton("Dashboard");
    router.push(
      {
        pathname: "/Dashboards",
        // query: { homeClick },
      }
      // "/search" // "as" argument
    );
  };
  //  function to form data search query for multiple projects
  const projectQueryValidation = (projects) => {
    if (projects.length === 1) {
      return `project = '${projects[0]}'`;
    } else {
      return projects.map((item) => `project = '${item}'`).join(" OR ");
    }
  };

  const handleRptClick = () => {
    setSelectedButton("Analytics");
    setQueryChange(!queryChange);

    let queryParams;
    if (dataInputValue) {
      queryParams = dataInputValue;
      router.push(
        {
          pathname: "/rptdashboard",
          query: { queryParams: queryParams, keyProp: queryChange },
        },
        "/rptdashboard"
      );
    } else {
      setRootLevelData("dataSearchActive", false);
      let localQueryString = localStorage.getItem("savedQuery");
      if (localQueryString) {
        queryParams = localQueryString;
      } else {
        let projectsQuery = projectQueryValidation(
          useConfigStore.getState().metricProjectName
        );
        if (projectsQuery) {
          let formedQuery = `username = '${authLoginUser}' AND (${projectsQuery})`;
          localStorage.setItem("savedQuery", formedQuery);
          queryParams = formedQuery;
        }
      }
      router.push(
        {
          pathname: "/rptdashboard",
          query: { queryParams: queryParams },
        },
        "/rptdashboard"
      );
    }
  };

  const onProcessDotDaClick = () => {
    setSelectedButton("ProcessDa");
    router.push("/processda");
  };

  const getValidateGrammarClassName = () => {
    if (dataInputValue === "") {
      return "";
    }
    return isValid ? "valid" : "invalid";
  };
  useEffect(() => {
    if (currentSuggestiondataListIndex === 1) {
      const fetchData = async () => {
        const response = await axios.post(
          `${configData.rest_server_url}/api/tag_autocomplete`,
          {
            tag_name: selectedSuggestion1,
            user: authLoginUser,
          }
        );
        const data = response.data.data;
        const formattedData = data.map((suggestion) => `'${suggestion}'`);
        setdatasuggestions3(formattedData.sort());
      };
      fetchData();
    }
  }, [
    datacurrentStep,
    currentSuggestiondataListIndex,
    selectedSuggestion1,
    dataInputValue,
  ]);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        searchBoxRef.current &&
        !searchBoxRef.current.contains(event.target) &&
        suggestionListRef.current &&
        !suggestionListRef.current.contains(event.target) &&
        !event.target.matches(".suggestion-item")
      ) {
        setSuggestionsList(false);
        // setRecFav(false);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [searchBoxRef, suggestionListRef]);
  const updateSuggestiondataListIndex = (value) => {
    // If the input is empty, reset the suggestion dataList index to 0
    if (value === "") {
      setCurrentSuggestiondataListIndex(0);
      return;
    }
    // If the current step is at the end of the current suggestion dataList,
    // move to the next suggestion dataList
    const currentdataList = getSuggestiondataList(
      currentSuggestiondataListIndex
    );
    let step = datacurrentStep;
    let i = step;
    while (i < value.length) {
      if (value[i] === " " || value[i] === "(" || value[i] === ")") {
        step++;
      } else {
        break;
      }
      i++;
    }
    const currDataListExists =
      currentdataList && currentdataList[currentdataList.length - 1];
    if (currDataListExists && step === currDataListExists.length) {
      setCurrentSuggestiondataListIndex(
        (currentSuggestiondataListIndex + 1) % 4
      );
    }
  };
  const handleInputChange = (event) => {
    setdataInputValue(event.target.value);
    updateSuggestiondataListIndex(event.target.value);
    if (event.target.value.trim() === "") {
      // If the input value is empty, set the validity to true
      setIsValid(true);
    } else {
      setIsValid(validateGrammar(event.target.value));
    }
  };
  const handledatasuggestionselect = (value) => {
    const newdataInputValue = [
      dataInputValue.slice(0, datacurrentStep),
      value,
      " ",
      dataInputValue.slice(datacurrentStep),
    ].join("");
    setdataInputValue(newdataInputValue);
    setdatacurrentStep(datacurrentStep + value.length + 1);
    setCurrentSuggestiondataListIndex((currentSuggestiondataListIndex + 1) % 4);
    if (currentSuggestiondataListIndex === 0) {
      setSelectedSuggestion1(value);
    }
    setIsValid(validateGrammar(newdataInputValue));
  };
  const getSuggestiondataList = (index) => {
    switch (index) {
      case 0:
        return datasuggestions1;
      case 1:
        return datasuggestions2;
      case 2:
        return datasuggestions3;
      case 3:
        return datasuggestions4;
      default:
        return [];
    }
  };

  const onDataSearch = () => {
    setSuggestionsList(false);
    let formattedString = dataInputValue;
    setFormattedValue(formattedString);
    setParameter("Search");
    handleModalClick("Search");

    if (!dataInputValue) {
      handleModalClick("Empty_Data_Search_Query");
      toast.error("Enter a Valid Search Query", {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    } else {
      // route to analytics page
      setRootLevelData("dataSearchActive", true);
      handleRptClick();
    }
  };

  const handleHelpClick = () => {
    if (!helpInputValue) {
      toast.error("Enter a Valid Help Query", {
        position: toast.POSITION.BOTTOM_LEFT,
        style: {
          fontSize: "14px",
          padding: "8px  12px",
        },
      });
    } else {
      setHelpSearchDialogue(true)
    }
  };


  const validateGrammar = (input) => {
    const terms = input.trim().split(" ");
    const firstTerm = terms[0];
    const lastTerm = terms[terms.length - 1];
    const isLastTermValid = datasuggestions3.includes(lastTerm);
    const isFirstTermValid = datasuggestions1.includes(firstTerm);
    const isInputEmpty = input.trim() === "";
    // Additional validation to check if the input value is in suggestion1
    const isInputInSuggestions1 = datasuggestions1.includes(input.trim());
    return (
      (isInputEmpty && isInputInSuggestions1) ||
      (isFirstTermValid && isLastTermValid)
    );
  };
  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleNtfs = (event) => {
    setNtfsAnchorEl(event.currentTarget);
  };
  const IshandleNtfsClose = () => {
    setNtfsAnchorEl(null);
  };
  const getNtfsColor = (severity) => {
    const severityColorMapping = {
      DEBUG: "grey",
      INFO: "#0288d1",
      SUCCESS: "#2e7d32",
      WARNING: "#ed6c02",
      ERROR: "#ef5350",
      CRITICAL: "#d32f2f",
    };
    return severityColorMapping[severity];
  };
  const IshandleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleDataRetention = () => {
    router.push({
      pathname: "/dataretention",
    });
    IshandleMenuClose();
  };

  const handleRptSpecEditorOpen = () => {
    setIsRptSpecEditorOpen(!isRptSpecEditorOpen);
  };
  const handleSpecEditor = () => {
    setIsRptSpecEditorOpen(true);
    IshandleMenuClose();
  };
  const handlePreferences = () => {
    setIsPreferenceClickedFromParent(true);
    IshandleMenuClose();
  };

  const onCloseUserProfile = () => {
    setIsPreferenceClickedFromParent(false);
    IshandleMenuClose();
  };

  const handleManageBuilds = (flag) => {
    setOpenManageBuilds(flag);
    IshandleMenuClose();
  };

  useEffect(() => {
    const validateSearchQuery = (changeVar) => {
      const operatorRegex = /\b(?:AND|OR|and|or)\b/;
      // const tag_list = ["username", "checkpoint"];
      const tags = `^(${datasuggestions1.join("|")})`;
      const pattern = RegExp(`${tags}\\s*!?=\\s*'[\\w\\-\\/\\.\\s]+'$`);
      const r1 = changeVar
        .split(operatorRegex)
        .map((subQuery) => subQuery.trim());
      return r1.every((item) => pattern.test(item));
    };
    if (changeVar) {
      setSuggestionsList(false);
      validateSearchQuery(changeVar) === true
        ? setIsValid(true)
        : setIsValid(false);
    } else {
      setSuggestionsList(changeVar !== null);
    }
  }, [changeVar]);

  return (
    <>
      <Box sx={{ display: "flex" }}>
        <Head>
          <title className="text-transparent">design.da</title>
          <meta name="description" content="Update Widgets with Comments" />
          {/* <link rel="icon" href="Tab_icon_BW.svg" /> */}
        </Head>
        {/* <CssBaseline /> */}
        <AppBar position="fixed" style={{ backgroundColor: "#5B2C84" }}>
          <Toolbar
            sx={{
              paddingLeft: "0px",
            }}
          >
            <div onClick={handleLogoClick} className={styles.logoContainer}>
              <img
                id="logo"
                // src={`${imageUrl}/White_BG.svg`}
                alt="Design Dash logo"
                style={{ height: "45px", width: "160px" }}
              />
            </div>

            <div
              style={{
                display: "flex",
                right: "100px",
                position: "absolute",
                borderRadius: theme.shape.borderRadius,
                backgroundColor: alpha(theme.palette.common.white, 0),
                "&:hover": {
                  backgroundColor: alpha(theme.palette.common.white, 0.25),
                },
              }}
            >
              <MaterialUISwitch
                id="help"
                onClick={() => setDataSearchOn(!dataSearch)}
                sx={{ m: 1 }}
                // defaultChecked
              />
              {dataSearch ? (
                <div style={{ margin: "0 0 0 auto", width: "38vw" }}>
                  <SearchBox>
                    <div className={`${getValidateGrammarClassName()}`}>
                      <div
                        style={{ width: "1.2em" }}
                        className="icon-container"
                      >
                        {isValid ? (
                          <FontAwesomeIcon
                            icon={faCheckCircle}
                            style={{
                              color: "green",
                            }}
                          />
                        ) : (
                          <FontAwesomeIcon
                            icon={faTimesCircle}
                            style={{
                              color: "red",
                            }}
                          />
                        )}
                      </div>
                    </div>
                    <input
                      ref={searchBoxRef}
                      onClick={() => setSuggestionsList(true)}
                      placeholder="Data Search"
                      type="text"
                      style={{
                        marginLeft: "0.4em",
                        border: "none",
                        outline: "none",
                        fontSize: "16px",
                        padding: "10px",
                        width: "100%",
                        boxSizing: "border-box",
                        // borderRadius: "25px",
                        borderRadius: theme.shape.borderRadius,
                        backgroundColor: alpha(
                          theme.palette.common.white,
                          0.15
                        ),
                        "&:hover": {
                          backgroundColor: alpha(
                            theme.palette.common.white,
                            0.25
                          ),
                        },
                        boxShadow: "0px 1px 3px rgba(0, 0, 0, 0.1)",
                        transition: "box-shadow 0.2s ease-in-out",
                      }}
                      value={dataInputValue}
                      onInput={handleInputChange}
                      onChange={(event) => setChangeVar(event.target.value)}
                    />
                    {sugList && (
                      <div className={styles.ddSugg}>
                        <ul
                          ref={suggestionListRef}
                          className={styles.ddSuggList}
                        >
                          {getSuggestiondataList(
                            currentSuggestiondataListIndex
                          ).map((suggestion) => (
                            <li
                              className="suggestion-item"
                              key={suggestion}
                              onClick={() =>
                                handledatasuggestionselect(suggestion)
                              }
                            >
                              {suggestion}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    <SearchButton onClick={onDataSearch}>
                      <SearchIcon />
                    </SearchButton>
                  </SearchBox>
                </div>
              ) : (
                <>
                  <div style={{ margin: "0 0 0 auto", width: "38vw" }}>
                    <SearchBox>
                      <input
                        ref={searchBoxRef}
                        placeholder="Help Search"
                        type="text"
                        style={{
                          border: "none",
                          outline: "none",
                          fontSize: "16px",
                          padding: "10px",
                          width: "100%",
                          boxSizing: "border-box",
                          // borderRadius: "25px",
                          borderRadius: theme.shape.borderRadius,
                          backgroundColor: alpha(
                            theme.palette.common.white,
                            0.15
                          ),
                          "&:hover": {
                            backgroundColor: alpha(
                              theme.palette.common.white,
                              0.25
                            ),
                          },
                          boxShadow: "0px 1px 3px rgba(0, 0, 0, 0.1)",
                          transition: "box-shadow 0.2s ease-in-out",
                          // borderRadius: "15px",
                        }}
                        value={helpInputValue}
                        onChange={(event) =>
                          sethelpInputValue(event.target.value)
                        }
                      />
                      <SearchButton onClick={handleHelpClick}>
                        <SearchIcon />
                      </SearchButton>
                    </SearchBox>
                  </div>
                </>
              )}
            </div>
            <div
              id="notificationIcon"
              style={{ position: "absolute", right: "50px" }}
            >
              <Tooltip title="Notifications">
                <IconButton color="inherit" onClick={handleNtfs}>
                  <Badge badgeContent={getUnreadCount()} color={"error"}>
                    <NotificationsActiveIcon />
                  </Badge>
                </IconButton>
              </Tooltip>
            </div>
            <div id={"notification"}>
              <Menu
                onClose={IshandleNtfsClose}
                id={"id"}
                open={Boolean(ntfsAnchorEl)}
                anchorEl={ntfsAnchorEl}
                PaperProps={{
                  style: {
                    // maxHeight: ITEM_HEIGHT * 4.5,
                    borderRadius: "10px",
                    backgroundColor: "black", //"#7E45AF",
                  },
                }}
              >
                <Box
                  sx={{
                    width: "500px",
                    maxHeight: "70vh",
                  }}
                >
                  <Box
                    sx={{
                      padding: "2px 5px",
                      display: "flex",
                      width: "100%",
                      justifyContent: "space-between",
                    }}
                  >
                    <Typography sx={{ color: "white" }}>
                      Notifications
                    </Typography>
                    <Tooltip title="Customize Notifications">
                      <IconButton
                        onClick={() => {
                          router.push("/notifications");
                          IshandleNtfsClose();
                        }}
                        sx={{ float: "right", padding: "0px", color: "white" }}
                      >
                        <SettingsIcon fontSize={"small"} />
                      </IconButton>
                    </Tooltip>{" "}
                  </Box>
                  {ntfs.map((item) => (
                    <Accordion
                      key={item}
                      expanded={expanded === _.get(item, "id")}
                      onChange={(event, isExpanded) => {
                        handleNtfsExpand(item.id, isExpanded);
                      }}
                      TransitionProps={{ unmountOnExit: true }}
                    >
                      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                        <div
                          id="severityStrip"
                          style={{
                            position: "absolute",
                            left: "0px",
                            top: "0px",
                            width: item.is_read ? "10px" : "100%",
                            height: "100%",
                            backgroundColor: getNtfsColor(
                              _.get(item, "severity", "DEBUG")
                            ),
                          }}
                        ></div>
                        <Typography sx={{ zIndex: 1 }}>
                          {_.get(item, "title", "")}
                        </Typography>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Preview text={_.get(item, "desc", "")} />
                      </AccordionDetails>
                    </Accordion>
                  ))}
                </Box>
              </Menu>
            </div>
            {openNtfsModal.map((modal, index) => (
              <Modal
                key={index}
                open={true}
                onClose={() => {
                  closeNtfsModal(modal, index);
                }}
              >
                <Fade in={true}>
                  <Box
                    style={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                      width: 800,
                      backgroundColor: "#d32f2f",
                      padding: 10,
                      // border: "2px solid #000",
                      boxShadow: 24,
                      borderRadius: 15,
                      p: 4,
                    }}
                  >
                    <Typography variant={"h3"} color={"white"}>
                      {modal.heading}
                    </Typography>
                    <Typography variant={"h3"}>{modal.title}</Typography>
                    <Typography color={"white"}>{modal.desc}</Typography>
                    <Button
                      sx={{ float: "right" }}
                      onClick={() => closeNtfsModal(modal, index)}
                      variant={"contained"}
                    >
                      Okay
                    </Button>
                  </Box>
                </Fade>
              </Modal>
            ))}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                // marginRight: "10px",
              }}
            >
              <Tooltip title="Profile">
                <IconButton
                  color="inherit"
                  onClick={handleMenuOpen}
                  style={{ position: "absolute", right: 0 }}
                  id="profile"
                >
                  <AccountCircleIcon />
                </IconButton>
              </Tooltip>
              <Menu
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={IshandleMenuClose}
                sx={{ width: "200px" }}
              >
                <MenuItem onClick={handlePreferences}>Preference</MenuItem>
                <MenuItem onClick={handleSpecEditor}>
                  Report Spec Editor
                </MenuItem>
                <MenuItem onClick={() => handleManageBuilds(true)}>
                  Manage Builds
                </MenuItem>
                {useConfigStore.getState().isAdminFlag ? (
                  <MenuItem onClick={IshandleMenuClose}>
                    <Admin />
                  </MenuItem>
                ) : null}
                {useConfigStore.getState().isAdminFlag ? (
                  <MenuItem onClick={handleDataRetention}>
                    Data Retention
                  </MenuItem>
                ) : null}
                <Divider
                  sx={{
                    height: "0.05em",
                    backgroundColor: "black",
                    color: "black",
                  }}
                />
                <MenuItem id="contact" onClick={logoutFunc}>
                  Logout
                </MenuItem>
              </Menu>
            </div>
          </Toolbar>
        </AppBar>

        {/* drawer - left - navigation component */}
        <div>
          <Drawer variant="permanent" open={open} className={styles.appLeftNav}>
            <List>
              {/* Dashboard */}
              <ListItem
                id="dashboards"
                key={"Dashboards"}
                disablePadding
                sx={{ display: "block" }}
                style={
                  selectedButton === "Dashboard"
                    ? { backgroundColor: "white" }
                    : { backgroundColor: "default" }
                }
              >
                <Tooltip placement="right" title="Overview of all the runs">
                  <ListItemButton
                    sx={{
                      px: 2.5,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      p: "10px 0px",
                    }}
                    onClick={handleLogoClick}
                    // onClickCapture={() => handleButtonClick(1)}
                  >
                    <img
                      // src={`${imageUrl}/IC_Dashboard_7.svg`}
                      alt="Dashboard"
                      style={{
                        height: "40px",
                        width: "40px",
                      }}
                    />
                    <Typography fontSize={12}>Dashboard</Typography>
                  </ListItemButton>
                </Tooltip>
                <Collapse in={open}>
                  <div>
                    {dashboardData &&
                      Object.keys(dashboardData).map((key) => (
                        <div key={key}>
                          <ListItem
                            key={key}
                            // sx={{ fontSize: "14px" , marginBottom:'2px', marginRight:'10px'}}
                            onClick={() => getDashboardData(dashboardData[key])}
                          >
                            {key}
                          </ListItem>
                        </div>
                      ))}
                  </div>
                </Collapse>
              </ListItem>
              {/* <Divider
                sx={{
                  height: "0.01em",
                  backgroundColor: "black",
                  // color: "black",
                }}
              /> */}
              <Divider />
              <Tooltip placement="right" title="In depth analysis of each task">
                <ListItem
                  id="analyitcs"
                  key={"Analyitcs"}
                  disablePadding
                  sx={{ display: "block" }}
                  style={
                    selectedButton === "Analytics"
                      ? { backgroundColor: "#fff" }
                      : { backgroundColor: "transparent" }
                  }
                >
                  <ListItemButton
                    sx={{
                      px: 2.5,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      p: "10px 0px",
                    }}
                    onClick={handleRptClick}
                    // onClickCapture={() => handleButtonClick(2)}
                  >
                    <img
                      // src={`${imageUrl}/IC_Analytics_7.svg`}
                      alt="Analytics"
                      style={{
                        height: "40px",
                        width: "40px",
                      }}
                    />

                    <Typography fontSize={12}>Analytics</Typography>
                  </ListItemButton>
                </ListItem>
              </Tooltip>
              <Tooltip title="Analysis of all processes">
                <ListItem
                  id="analyitcs"
                  key={"processda"}
                  disablePadding
                  sx={{ display: "block" }}
                  style={
                    selectedButton === "ProcessDa"
                      ? { backgroundColor: "#fff" }
                      : { backgroundColor: "transparent" }
                  }
                >
                  <ListItemButton
                    sx={{
                      px: 2.5,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      p: "10px 0px",
                    }}
                    onClick={onProcessDotDaClick}
                  >
                    <img
                      // src={`${imageUrl}/process_da_icons/process_da.svg`}
                      alt="Process-Data-Analytics"
                      style={{
                        height: "40px",
                        width: "40px",
                      }}
                    />
                    <Typography fontSize={12}>Process</Typography>
                    <Typography fontSize={12}>Data</Typography>
                    <Typography fontSize={12}>Analytics</Typography>
                  </ListItemButton>
                </ListItem>
              </Tooltip>
            </List>
          </Drawer>
        </div>
        <Box component="main" sx={{ flexGrow: 1, p: 0.5 }}>
          <DrawerHeader />
        </Box>
      </Box>
      <>
        {parameter !== "Search" ? (
          <div>
            <ModalComponent
              isOpen={isOpen}
              onClose={() => setIsOpen(false)}
              param={parameter}
              toggleApi={toggleApi}
              searchString={formattedValue}
            />
          </div>
        ) : (
          ""
        )}
      </>
      <HeartBearCheck />
      <RefreshSSoToken />
      <UserProfile
        open={isPreferenceClickedFromParent}
        onClose={onCloseUserProfile}
      />

      {/* <ReportSpecEditorDialog
        handleFullScreen={handleRptSpecEditorOpen}
        isFullScreen={isRptSpecEditorOpen}
      /> */}

      {/* <ManageBuildsDialog
        handleFullScreen={handleManageBuilds}
        isFullScreen={openManageBuilds}
      /> */}
      {/* Help Search Dialogue Component */}
    { helpSearchDialogue && <HelpSearch
      open={helpSearchDialogue}
      onClose={()=>setHelpSearchDialogue(false)}
      helpInputValue={helpInputValue}

      />}
      {/* tour component - Joyride */}
      <Modal
        open={modalOpen}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Card sx={{ minWidth: 275 }}>
            <CardContent>
              <Typography
                sx={{ fontSize: 14 }}
                color="text.secondary"
                gutterBottom
              >
                Welcome to Design.Da Web UI!
              </Typography>
              Would you Like to have a Tour of the Application ?
            </CardContent>
            <CardActions>
              <Button onClick={handleTour} autoFocus>
                Continue
              </Button>
              <Button autoFocus onClick={handleTourFlag}>
                Never See this again ?
              </Button>
            </CardActions>
          </Card>
        </Box>
      </Modal>
      <div>
        <Joyride
          styles={{
            options: {
              zIndex: 10000,
            },
            buttonNext: {
              background: "purple",
            },
            buttonBack: {
              color: "black",
            },
          }}
          // run={enabled}
          continuous
          run={enabled}
          scrollToFirstStep
          showProgress
          showSkipButton
          hideCloseButton
          // stepIndex={stepIndex}
          steps={steps}
          disableCloseOnEsc={true}
          disableOverlayClose={true}
        />
      </div>
      <div style={{ display: "flex" }}>
        <div
          id="right"
          style={{ position: "absolute", right: 0, top: 180 }}
        ></div>
        <div
          id="right-one"
          style={{ position: "absolute", right: 0, top: 250 }}
        ></div>
        <div
          id="right-two"
          style={{ position: "absolute", right: 0, top: 300 }}
        ></div>
      </div>
    </>
  );
}
LayoutComponent.defaultProps = {
  dashboardData: {
    data: {},
  },
};
export default LayoutComponent;
