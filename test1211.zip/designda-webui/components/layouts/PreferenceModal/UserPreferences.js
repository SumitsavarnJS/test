
import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import ListItemText from '@mui/material/ListItemText';
import ListItem from '@mui/material/ListItem';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import CloseIcon from '@mui/icons-material/Close';
import Slide from '@mui/material/Slide';
import { useState, useEffect, useRef } from "react";
import { styled, alpha } from "@mui/material/styles";
import { useTheme } from "@mui/material/styles";
import OutlinedInput from "@mui/material/OutlinedInput";
import getConfig from "next/config";
import axios, { formToJSON } from "axios";
import useConfigStore from "../../../store/useConfigStore";
import DataSource from "../../../pages/rptdashboard/data_source/DataSource";
import { ClickAwayListener } from "@mui/base";
import { toast } from "react-toastify";
import Chip from "@mui/material/Chip";
import {
    TextField,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Box,
  } from "@mui/material";



const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function UserPreferences() {
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };



  const {
    metricProjectName,
    setMetricProjectName,
    widLibDataSource,
    setRootLevelData,
    isTourFlag,
  } = useConfigStore();
  const theme = useTheme();
  const [selectedItem, setSelectedItem] = useState([]);
  const [itemsList, setItemsList] = useState([]);
  const [showTaskDataSource, setShowTaskDataSource] = useState(false);
  const [showFlowDataSource, setShowFlowDataSource] = useState(false);
  const [showCustomDataSource, setShowCustomDataSource] = useState(false);
  const handleChipClick = (item) => {
    // Toggle the item's presence in the selectedItems array
    setSelectedItem((prevSelected) => {
      if (prevSelected.includes(item)) {
        return prevSelected.filter((selectedItem) => selectedItem !== item);
      } else {
        return [...prevSelected, item];
      }
    });
  };

  const Text = styled(Typography)(({ theme }) => ({
    fontSize: "1rem",
    fontWeight: "600",
    // marginBottom: theme.spacing(1),
  }));
  const {
    configData,
    setConfigData,
    isAuthenticated,
    setAuth,
    authLoginUser,
    setAuthUserVal,
  } = useConfigStore();
  useEffect(() => {
    async function fetchItems() {
      try {
        const response = await axios.post(
          configData.rest_server_url + "/api/fetch_buckets",
          {
            user: authLoginUser,
          }
        );
        setItemsList(response.data.data);

        if (metricProjectName) {
          const filteredItem = metricProjectName
            .filter((item) => typeof item === "string") // Filter only string items
            .map((item) => item.trim());

          setSelectedItem(filteredItem);
        }
      } catch (error) {
        console.error("Error fetching items:", error);
      }
    }
    fetchItems();
  }, []);
  const handleTaskDataLocationChange = (dataLocation, bucket) => {
    setRootLevelData("widLibDataSource", {
      ...widLibDataSource,
      taskData: {
        dataLocation: dataLocation,
        bucket: bucket,
      },
    });
  };
  const handleFlowDataLocationChange = (dataLocation, bucket) => {
    setRootLevelData("widLibDataSource", {
      ...widLibDataSource,
      flowData: {
        dataLocation: dataLocation,
        bucket: bucket,
      },
    });
  };
  const handleCustomDataLocationChange = (dataLocation, bucket) => {
    setRootLevelData("widLibDataSource", {
      ...widLibDataSource,
      customData: {
        dataLocation: dataLocation,
        bucket: bucket,
      },
    });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    // Replace with your API endpoint
    await axios
      .post(
        useConfigStore.getState().configData.rest_server_url +
          "/api/save_profile_config",
        {
          data: {
            checkpoint: "",
            project: selectedItem,
            bucket: "",
            isTourFlag: isTourFlag,
            widLibDataSource: {
              taskData: {
                dataLocation: widLibDataSource.taskData.dataLocation,
                bucket: widLibDataSource.taskData.bucket,
              },
              flowData: {
                dataLocation: widLibDataSource.flowData.dataLocation,
                bucket: widLibDataSource.flowData.bucket,
              },
              customData: {
                dataLocation: widLibDataSource.customData.dataLocation,
                bucket: widLibDataSource.customData.bucket,
              },
            },
          },
          user: useConfigStore.getState().authLoginUser,
        }
      )
      .then((response) => {
        response = response.data;
        if (response.success) {
          toast.success(`Preferences saved successfully`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          // console.log(response.success);
          // setMetricProjectName(selectedItem);
          useConfigStore.getState().setMetricProjectName(selectedItem);
        } else {
          toast.error(`Preferences could not be saved`, {
            position: toast.POSITION.BOTTOM_LEFT,
            style: {
              fontSize: "14px",
              padding: "8px  12px",
            },
          });
          console.log("Failed to save Profile Pref");
        }
      })
      .catch((error) => {
        toast.error(`Failed to reach Server`, {
          position: toast.POSITION.BOTTOM_LEFT,
          style: {
            fontSize: "14px",
            padding: "8px  12px",
          },
        });
        console.log("Failed to reach Server");
      });
  };

  return (
<>
<div style = {{
    color: "black",
}}>
      <Typography 
       onClick={handleClickOpen}
     
       sx={{
      
        color: "black",
        textTransform: "capitalize",
        fontSize: "1rem",
       }}
       >
        Preference
      </Typography>
      </div>
      <Dialog
        fullScreen
        open={open}
        onClose={handleClose}
        TransitionComponent={Transition}
      >
        <AppBar sx={{ position: 'relative' }}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              User Preference
            </Typography>
         
          </Toolbar>
        </AppBar>
        <form onSubmit={handleSubmit}>
          <div style={{ display: "flex", flexDirection: "column", marginTop: "10px", padding: "10px" }}>
             <FormControl sx={{ m: 2 }}> 
            
              <InputLabel id="demo-multiple-name-label">Project</InputLabel>
              {/* <InputLabel
              id="demo-multiple-name-label"
         ></InputLabel> */}
              <Select
                labelId="demo-multiple-chip-label"
                id="demo-multiple-chip"
                multiple
                label="Project"
                value={selectedItem}
                input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
                renderValue={(selected) => (
                  <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                    {selected.map((item) => (
                      <Chip
                        key={item}
                        label={item}
                        // onDelete={() => handleChipClick(item)}
                      />
                    ))}
                  </Box>
                )}
              >
                {itemsList.map((name) => (
                  <MenuItem
                    key={name}
                    value={name}
                    onClick={() => handleChipClick(name)}
                  >
                    {name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <div
                style={{
                  padding: "0 10px 0 10px",
                  display: "block",
                  borderStyle: "solid",
                  borderRadius: "10px",
                  borderColor: "grey",
                  marginTop: "15px",
                width: "100%",
                }}
              >
                <Typography>Widget Library Default</Typography>
                {/* Select task Data Source */}
                <div style={{ display: "flex" }}>
                  <Button
                    size="small"
                    sx={{ mt: "10px" }}
                    // classes={{ root: styles.add_button }}
                    onClick={() => setShowTaskDataSource(true)}
                  >
                    Task data source
                  </Button>
                  {showTaskDataSource ? (
                    <ClickAwayListener
                      onClickAway={() => {
                        setShowTaskDataSource(false);
                      }}
                    >
                      <Box
                        sx={{
                          zIndex: "5",
                          position: "absolute",
                          top: "0px",
                          left: "0px",
                          width: "100%",
                          height: "fit-content",
                          backgroundColor: "white",
                          padding: "5px",
                          boxShadow: "grey 5px 5px 5px",
                        }}
                      >
                        <DataSource
                          dataLocationChanged={handleTaskDataLocationChange}
                          dataLocation={widLibDataSource.taskData.dataLocation}
                          bucket={widLibDataSource.taskData.bucket}
                          close={() => {
                            setShowTaskDataSource(false);
                          }}
                        />
                      </Box>
                    </ClickAwayListener>
                  ) : null}
                  <Typography
                    variant="body2"
                    style={{ marginTop: "15px", marginLeft: "15px" }}
                  >
                    {widLibDataSource &&
                    widLibDataSource.taskData &&
                    widLibDataSource.taskData.dataLocation &&
                    widLibDataSource.taskData.dataLocation.split("#")
                      ? widLibDataSource.taskData.dataLocation.split("#")[1]
                      : ""}
                  </Typography>
                </div>
                {/* Select Flow Data Source */}

                <div style={{ display: "flex" }}>
                  <Button
                    size="small"
                    sx={{ mt: "10px" }}
                    // classes={{ root: styles.add_button }}
                    onClick={() => setShowFlowDataSource(true)}
                  >
                    Flow data source
                  </Button>
                  {showFlowDataSource ? (
                    <ClickAwayListener
                      onClickAway={() => {
                        setShowFlowDataSource(false);
                      }}
                    >
                      <Box
                        sx={{
                          zIndex: "5",
                          position: "absolute",
                          top: "0px",
                          left: "0px",
                          width: "100%",
                          height: "fit-content",
                          backgroundColor: "white",
                          padding: "5px",
                          boxShadow: "grey 5px 5px 5px",
                       
                        }}
                      >
                        <DataSource
                          dataLocationChanged={handleFlowDataLocationChange}
                          dataLocation={widLibDataSource.flowData.dataLocation}
                          bucket={widLibDataSource.flowData.bucket}
                          close={() => {
                            setShowFlowDataSource(false);
                          }}
                        />
                      </Box>
                    </ClickAwayListener>
                  ) : null}
                  <Typography
                    variant="body2"
                    style={{ marginTop: "15px", marginLeft: "15px" }}
                  >
                    {widLibDataSource &&
                    widLibDataSource.flowData &&
                    widLibDataSource.flowData.dataLocation &&
                    widLibDataSource.flowData.dataLocation.split("#")
                      ? widLibDataSource.flowData.dataLocation.split("#")[1]
                      : ""}
                  </Typography>
                </div>
                {/* Select Data Source */}
                <div style={{ display: "flex" }}>
                  <Button
                    size="small"
                    sx={{ mt: "10px" }}
                    // classes={{ root: styles.add_button }}
                    onClick={() => setShowCustomDataSource(true)}
                  >
                    custom data source
                  </Button>
                  {showCustomDataSource ? (
                    <ClickAwayListener
                      onClickAway={() => {
                        setShowCustomDataSource(false);
                      }}
                    >
                      <Box
                        sx={{
                          zIndex: "5",
                          position: "absolute",
                          top: "0px",
                          left: "0px",
                          width: "100%",
                          height: "fit-content",
                          backgroundColor: "white",
                          padding: "5px",
                          boxShadow: "grey 5px 5px 5px",
                        }}
                      >
                        <DataSource
                          dataLocationChanged={handleCustomDataLocationChange}
                          dataLocation={
                            widLibDataSource.customData.dataLocation
                          }
                          bucket={widLibDataSource.customData.bucket}
                          close={() => {
                            setShowCustomDataSource(false);
                          }}
                        />
                      </Box>
                    </ClickAwayListener>
                  ) : null}
                  <Typography
                    variant="body2"
                    style={{ marginTop: "15px", marginLeft: "15px" }}
                  >
                    {widLibDataSource &&
                    widLibDataSource.customData &&
                    widLibDataSource.customData.dataLocation &&
                    widLibDataSource.customData.dataLocation.split("#")
                      ? widLibDataSource.customData.dataLocation.split("#")[1]
                      : ""}
                  </Typography>
                </div>
              </div>
            </FormControl>
            <Button
              variant="contained"
              size="small"
              style={{ position: "relative", width: "5%", marginTop: "2%", marginLeft: "10px" }}
              type="submit"
            >
              Submit
            </Button>
          </div>
        </form>
      </Dialog>
  </>
  );
}