import { useEffect } from "react";
import { useMsal } from "@azure/msal-react";

const TokenRefresh = () => {
    const { accounts, instance } = useMsal();

    const refreshToken = async () => {
        const accounts = instance.getAllAccounts();
        if (accounts.length > 0) {
            const request = {
                scopes: ["User.Read"], // Replace with your required scopes
                account: accounts[0]
            };

            try {
                const response = await instance.acquireTokenSilent(request);
                console.log("Token refreshed:", response.accessToken);
            } catch (error) {
                console.error("Failed to refresh token silently:", error);
                if (error.name === "InteractionRequiredAuthError") {
                    await instance.acquireTokenRedirect(request);
                }
            }
        }
    };

    useEffect(() => {
        const isMsalAuthenticated = accounts.length > 0;

        if (isMsalAuthenticated) {
            const refreshInterval = setInterval(refreshToken, 15 * 60 * 1000); // Refresh every 15 minutes

            // Cleanup interval on component unmount
            return () => clearInterval(refreshInterval);
        }
    }, [accounts]);

    return null; // This component does not render anything
};

export default TokenRefresh;