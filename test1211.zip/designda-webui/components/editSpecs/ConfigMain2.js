//////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ConfigMain2.js#29 $
////////////////////////////////////////////////////////////////////////////////

import React from "react";
import ReactDOMServer from "react-dom/server";
// import SplitPane from "react-split-pane";
import { ButtonGroup, Divider } from "@mui/material";
import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";
import { TabulatorFull as Tabulator } from "tabulator-tables-test";
import EditReportSpec2 from "components/editSpecs/EditReportSpec2";
import EditBuildSpec from "components/editSpecs/EditBuildSpec";
import EditHierSpec from "components/editSpecs/EditHierSpec";
import ConfirmPopup from "metrics/dialogs/ConfirmPopup";
import _ from "lodash";
import * as funcs from "common/Funcs";
import * as fastapi from "common/FastApi";

import "./ConfigMain2.module.css";

import iconCurrentReportSpec from "images/arrowBlackLeft.png";
import iconCurrentBuildSpec from "images/arrowGreenLeft.png";
import iconCurrentHierSpec from "images/arrowBlueLeft.png";

import iconEditReportSpec from "images/arrowBlackRight.png";
import iconEditBuildSpec from "images/arrowGreenRight.png";
import iconEditHierSpec from "images/arrowBlueRight.png";

import iconIsReportSpec from "images/arrowBlackRight.png";
import iconIsBuildSpec from "images/arrowGreenRight.png";
import iconIsHierSpec from "images/arrowBlueRight.png";

const COOKIE_NAME = "/metrics/ConfigMain";

const colorBlack = funcs.palette("Black").fg;
const colorWhite = funcs.palette("White").fg;
const colorGreen = funcs.palette("DarkGreen").fg;
const colorBlue = funcs.palette("Blue").fg;
const colorRed = funcs.palette("Red").fg;
const colorSnps = funcs.palette("Snps").fg;

const SpecType = Object.freeze(funcs.SpecType);

// fullName: The entire spec path starting with "Users/userName/" or "Projects/projectName/"
// specName: The part of the fullName following "Users/userName/" or "Projects/projectName/"
// The specName is used to index buildSpecs/reportSpecs in userData/projectData objects.

// This is the schema for the tableRows:
// id: specType + ":" + fullName
// displayName: Value shown in table
// fullName: Full path of directory or file

function menuDataId(specType, fullName) {
  let id = specType + ":" + fullName;
  return id;
}

const dirTemplate = {
  id: menuDataId(SpecType.DIR, null),
  specType: SpecType.DIR,
  fullName: null,
  displayName: null,
  _children: [],
};

const fileTemplate = {
  id: menuDataId(SpecType.NONE, null),
  specType: SpecType.NONE,
  fullName: null,
  displayName: null,
  readOnlyMode: true,
};

class ConfigMain2 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showPane: SpecType.NONE,

      // original & next spec
      editReportSpecDoc: funcs.newReportSpecDoc({ data: this.props.defaultReportSpec }),
      nextReportSpecDoc: funcs.newReportSpecDoc({ data: this.props.defaultReportSpec }),

      // original & next spec
      editBuildSpecDoc: funcs.newBuildSpecDoc(),
      nextBuildSpecDoc: funcs.newBuildSpecDoc(),

      // original & next spec
      editHierSpecDoc: funcs.newHierSpecDoc(),
      nextHierSpecDoc: funcs.newHierSpecDoc(),

      readOnlyMode: true,
      showConfirmPopup: false,
      dataConfirmPopup: { title: "", message: "", specType: "" },
    };
    this.tablebuilt = false;
    this.tableInst = null;
    this.tableRef = React.createRef();

    this.menuData = {
      tableRows: [],
      writableFolders: [],
      fullNameHash: {},
    };

    this.reportSpecDirty = false;
    this.buildSpecDirty = false;
    this.hierSpecDirty = false;

    this.resizeTimeout = false;
  }

  render() {
    this.menuData = this.genMenuData();

    let refreshButton = <ThemedButton text="Refresh Menu" fullWidth onClick={this.handleRefreshButton} />;
    let saveSpecsButton = <ThemedButton text="Save Spec Config" fullWidth onClick={() => this.handleSaveSpecsButton()} />;
    let restoreSpecsButton = <ThemedButton text="Restore Spec Config" fullWidth onClick={() => this.handleRestoreSpecsButton()} />;
    let reportSpecButton = <ThemedButton text="New Report Spec" type="ReportSpec" fullWidth onClick={() => this.handleCreateSpecButton(SpecType.REPORT)} />;
    let buildSpecButton = <ThemedButton text="New Build Spec" type="BuildSpec" fullWidth onClick={() => this.handleCreateSpecButton(SpecType.BUILD)} />;
    let hierSpecButton = <ThemedButton text="New Hier Spec" type="HierSpec" fullWidth onClick={() => this.handleCreateSpecButton(SpecType.HIER)} />;

    let tableDiv = (
      <div
        id="divConfigMainTable"
        className="divStandardBackgroundColor"
        ref={(el) => {
          this.tableRef = el;
        }}
      ></div>
    );

    let leftSide;
    leftSide = (
      <div id="divConfigMainLeft">
        <ButtonGroup fullWidth orientation="vertical" sx={{ marginBottom: "3px" }}>
          {refreshButton}
          {saveSpecsButton}
          {restoreSpecsButton}
        </ButtonGroup>
        <ButtonGroup fullWidth orientation="vertical" sx={{ marginBottom: "3px" }}>
          {reportSpecButton}
          {buildSpecButton}
          {hierSpecButton}
        </ButtonGroup>
        {tableDiv}
      </div>
    );

    let editReportSpecFinal = (
      <EditReportSpec2
        editSpec={this.state.editReportSpecDoc}
        nextSpec={this.state.nextReportSpecDoc}
        updateNextSpec={this.updateNextReportSpec}
        mongoData={this.props.mongoData}
        //
        systemConfig={this.props.systemConfig}
        userData={this.props.userData}
        readOnlyMode={this.state.readOnlyMode}
        fullNameHash={this.menuData.fullNameHash}
        writableFolders={this.menuData.writableFolders}
        saveSpec={this.saveSpec}
        saveSpecAs={this.saveSpecAs}
        renameSpec={this.renameSpec}
        deleteSpec={this.deleteSpec}
        cancelSpec={this.cancelSpec}
        setSpecDirty={this.setReportSpecDirty}
        specDirty={this.props.reportSpecDirty}
        showDirtyMessage={this.showDirtyMessage}
      />
    );

    let editBuildSpecFinal = (
      <EditBuildSpec
        editSpec={this.state.editBuildSpecDoc}
        nextSpec={this.state.nextBuildSpecDoc}
        updateNextSpec={this.updateNextBuildSpec}
        //
        systemConfig={this.props.systemConfig}
        userData={this.props.userData}
        readOnlyMode={this.state.readOnlyMode}
        fullNameHash={this.menuData.fullNameHash}
        writableFolders={this.menuData.writableFolders}
        saveSpec={this.saveSpec}
        saveSpecAs={this.saveSpecAs}
        renameSpec={this.renameSpec}
        deleteSpec={this.deleteSpec}
        cancelSpec={this.cancelSpec}
        setSpecDirty={this.setBuildSpecDirty}
        specDirty={this.props.buildSpecDirty}
        showDirtyMessage={this.showDirtyMessage}
      />
    );

    let editHierSpecFinal = (
      <EditHierSpec
        editSpec={this.state.editHierSpecDoc}
        nextSpec={this.state.nextHierSpecDoc}
        updateNextSpec={this.updateNextHierSpec}
        mongoData={this.props.mongoData}
        //
        systemConfig={this.props.systemConfig}
        userData={this.props.userData}
        readOnlyMode={this.state.readOnlyMode}
        fullNameHash={this.menuData.fullNameHash}
        writableFolders={this.menuData.writableFolders}
        saveSpec={this.saveSpec}
        saveSpecAs={this.saveSpecAs}
        renameSpec={this.renameSpec}
        deleteSpec={this.deleteSpec}
        cancelSpec={this.cancelSpec}
        setSpecDirty={this.setHierSpecDirty}
        specDirty={this.props.hierSpecDirty}
        showDirtyMessage={this.showDirtyMessage}
      />
    );

    let rightSide;
    if (this.state.showPane == SpecType.REPORT) {
      rightSide = <div id="divConfigMainRight">{editReportSpecFinal}</div>;
    } else if (this.state.showPane == SpecType.BUILD) {
      rightSide = <div id="divConfigMainRight">{editBuildSpecFinal} </div>;
    } else if (this.state.showPane == SpecType.HIER) {
      rightSide = <div id="divConfigMainRight">{editHierSpecFinal}</div>;
    } else {
      rightSide = (
        <div id="divConfigMainRight">
          <h3>Getting Started</h3>
          <ul>
            <li>Select a report spec (black) in "Specs" menu, and "Select"</li>
            <li>Select a build spec (green) in "Specs" menu, and "Select"</li>
            <li>Green & black icons show the selected specs</li>
            <li>Select a report from the "Report" menu</li>
          </ul>
          <h3>Saving & Restoring Config</h3>
          <ul>
            <li>Click "Save Config" button to save currently selected report & build specs</li>
            <li>Click "Restore Config" button to restore previously saved report & build specs</li>
          </ul>
          <h3>Editing Specs</h3>
          <ul>
            <li>There are mulitple ways to load spec information into a spec editor:</li>
            <li>Click "New Report Spec" button to edit a fresh report spec</li>
            <li>Click "New Build Spec" button to edit a fresh build spec</li>
            <li>Right-Click spec from "Specs" menu to edit an existing spec</li>
          </ul>
        </div>
      );
    }

    let confirmPopup = <ConfirmPopup show={this.state.showConfirmPopup} data={this.state.dataConfirmPopup} submitAnswer={this.confirmPopupSubmitAnswer} />;

    let theContent = (
      <div id="divConfigMainTop">
        {/* <SplitPane split="vertical" defaultSize={this.splitPos()} onDragFinished={this.onDragFinished}> */}
          {leftSide} 
          <Divider orientation="vertical" />
          {rightSide}
        {/* </SplitPane> */}
        {confirmPopup}
      </div>
    );

    return theContent;
  }

  componentDidMount = () => {
    window.addEventListener("resize", () => this.resizeEvent());
    this.forceUpdate();
  };

  componentDidUpdate() {
    try {
      this.resizeDivs();
      this.updateTable();
    } catch (e) {
      console.log("Could not update:", e)
    }
  }

  componentWillUnmount() { }

  updateTable = () => {
    let tableColumns = [];
    tableColumns.push({
      title: "",
      field: "selectedStatus",
      headerSort: false,
      width: 25,
      formatter: this.cellFormatter,
    });
    tableColumns.push({
      title: "Specs",
      field: "displayName",
      headerSort: false,
      widthGrow: 3,
      formatter: this.cellFormatter,
    });

    let tableData = this.menuData.tableRows;

    if (!this.tableInst) {
      this.tableInst = new Tabulator(this.tableRef, {
        layout: "fitDataStretch",
        height: this.getTableHeight(),
        selectableRows: 1,
        selectableCheck: (row) => this.selectableCheck(row),
        dataTree: true,
        dataTreeElementColumn: "displayName",
        dataTreeBranchElement: false,
        dataTreeStartExpanded: (row, level) => this.dataTreeStartExpanded(row, level),
        columnDefaults: {},
        rowFormatter: (row) => this.rowFormatter(row),
        rowContextMenu: this.rowContextMenu,
        columns: tableColumns,
        data: tableData,
      });
      this.tableInst.on("rowClick", this.rowClick);
      this.tableInst.on("dataTreeRowExpanded", this.dataTreeRowExpanded);
      this.tableInst.on("dataTreeRowCollapsed", this.dataTreeRowCollapsed);
      this.tableInst.on("tableBuilt", this.afterTableBuilt);
    } else {
      try {
        this.tableInst.replaceData(tableData);
        this.resizeTable();
      } catch (e) {
        console.log("Could not replace table data:", e)
      }
    }
  };

  afterTableBuilt = () => {
    this.tablebuilt = true;
    this.resizeTable();
  };

  resizeDivs = () => {
    let divConfigMainRight = document.getElementById("divConfigMainRight");
    if (divConfigMainRight == null) {
      return;
    }

    let windowWidth = document.documentElement.clientWidth;
    let rect = divConfigMainRight.getBoundingClientRect();
    let width = windowWidth - rect.x;

    divConfigMainRight.style.width = width + "px";
  };

  resizeTable = () => {
    try {
      if (this.tableInst && this.tablebuilt) {
        this.tableInst.setHeight(this.getTableHeight());
        this.tableInst.redraw();
      }
    } catch (e) {
      console.log("Could not resize:", e)
    }
  };

  resizeEvent = () => {
    clearTimeout(this.resizeTimeout);
    this.resizeTimeout = setTimeout(this.handleResize, funcs.ResizeDelay);
  };

  handleResize = () => {
    this.resizeDivs();
    this.resizeTable();
  };

  getTableHeight = () => {
    let windowHeight = document.documentElement.clientHeight;
    let tableHeight = windowHeight;

    let divConfigMainTable = document.getElementById("divConfigMainTable");
    if (divConfigMainTable == null) {
      return tableHeight;
    }

    let rect = divConfigMainTable.getBoundingClientRect();
    tableHeight = windowHeight - rect.y;

    return tableHeight;
  };

  ////////////////////////////////////////
  // Dirty Code
  ////////////////////////////////////////

  setReportSpecDirty = (value) => {
    this.props.setReportSpecDirty(value);
  };
  setBuildSpecDirty = (value) => {
    this.props.setBuildSpecDirty(value);
  };
  setHierSpecDirty = (value) => {
    this.props.setHierSpecDirty(value);
  };

  showDirtyMessage = () => {
    let message = "Save or Cancel the spec being edited.";
    funcs.showNotification("Config Specs", message);
  };

  ////////////////////////////////////////
  // Cookie Code
  ////////////////////////////////////////

  setCookie = (cookie) => {
    let options = { expires: 3650 };
    funcs.writeCookie(COOKIE_NAME, cookie, options);
  };

  getCookie = () => {
    let cookie = funcs.readCookie(COOKIE_NAME);

    if (_.isEmpty(cookie)) {
      cookie = {};
    }
    if (!cookie.hasOwnProperty("reportSpecName")) {
      cookie["reportSpecName"] = null;
    }
    if (!cookie.hasOwnProperty("buildSpecName")) {
      cookie["buildSpecName"] = null;
    }
    if (!cookie.hasOwnProperty("rowExpandedInfo")) {
      cookie["rowExpandedInfo"] = {};
    }
    if (!cookie.hasOwnProperty("splitPos")) {
      cookie["splitPos"] = 300;
    }
    return cookie;
  };

  onDragFinished = (size) => {
    let cookie = this.getCookie();
    cookie["splitPos"] = size;
    this.setCookie(cookie);
    this.resizeDivs();
  };

  splitPos = () => {
    let cookie = this.getCookie();
    return cookie["splitPos"];
  };

  handleSaveSpecsButton = () => {
    let reportSpecName = this.props.currentReportSpecDoc.fullName;
    let buildSpecName = this.props.currentBuildSpecDoc.fullName;
    let hierSpecName = this.props.currentHierSpecDoc.fullName;

    if (reportSpecName == null || buildSpecName == null) {
      let message = "Specs are saved/restored in pairs. Please select a Report spec and a Build spec.";
      funcs.showNotification("Config Specs", message);
      return;
    }

    let cookie = this.getCookie();
    cookie.reportSpecName = reportSpecName;
    cookie.buildSpecName = buildSpecName;
    cookie.hierSpecName = hierSpecName;
    this.setCookie(cookie);
  };

  handleRestoreSpecsButton = async () => {
    let cookie = this.getCookie();

    if (_.isEmpty(cookie)) {
      let message = "There are no saved specs to restore.";
      funcs.showNotification("Config Specs", message);
      return;
    }

    let r;
    let specType;
    let fullName;

    // Restore reportSpecDoc
    specType = SpecType.REPORT;
    fullName = cookie.reportSpecName;
    let reportSpecDoc = funcs.newReportSpecDoc({ data: this.props.defaultReportSpec });
    if (fullName) {
      r = await fastapi.readSpecDoc(this.props.systemConfig.dataServer, specType, fullName);
      if (r.success) {
        reportSpecDoc = r.specDoc;
      } else {
        funcs.showNotification("Unable to restore reportSpec", r.message);
      }
    }

    // Restore buildSpecDoc
    specType = SpecType.BUILD;
    fullName = cookie.buildSpecName;
    let buildSpecDoc = funcs.newBuildSpecDoc();
    if (fullName) {
      r = await fastapi.readSpecDoc(this.props.systemConfig.dataServer, specType, fullName);
      if (r.success) {
        buildSpecDoc = r.specDoc;
      } else {
        funcs.showNotification("Unable to restore buildSpec", r.message);
      }
    }

    // Restore hierSpecDoc
    specType = SpecType.HIER;
    fullName = cookie.hierSpecName;
    let hierSpecDoc = funcs.newHierSpecDoc();
    if (fullName) {
      r = await fastapi.readSpecDoc(this.props.systemConfig.dataServer, specType, fullName);
      if (r.success) {
        hierSpecDoc = r.specDoc;
      } else {
        funcs.showNotification("Unable to restore hierSpec", r.message);
      }
    }

    // Check specs
    if (!reportSpecDoc.fullName) {
      let message = "Invalid report spec: " + cookie.reportSpecName;
      funcs.showNotification("Config Specs", message);
      return;
    }

    if (!buildSpecDoc.fullName) {
      let message = "Invalid build spec: " + cookie.buildSpecName;
      funcs.showNotification("Config Specs", message);
      return;
    }

    if (!hierSpecDoc.fullName && cookie.hierSpecName) {
      let message = "Invalid hier spec: " + cookie.buildSpecName;
      funcs.showNotification("Config Specs", message);
      return;
    }

    // Set specs, since all must be OK
    this.props.setCurrentSpecs(reportSpecDoc, buildSpecDoc, hierSpecDoc);
  };

  ////////////////////////////////////////
  // Specs menu expand/collapse state
  ////////////////////////////////////////

  isExpanded = (fullName) => {
    let cookie = this.getCookie();
    let rowExpandedInfo = cookie.rowExpandedInfo;
    let expanded = rowExpandedInfo.hasOwnProperty(fullName) ? rowExpandedInfo[fullName] : false;
    return expanded;
  };

  existsExpanded = (fullName) => {
    let cookie = this.getCookie();
    let rowExpandedInfo = cookie.rowExpandedInfo;
    let exists = rowExpandedInfo.hasOwnProperty(fullName);
    return exists;
  };

  dataTreeStartExpanded = (row, level) => {
    let expanded = false;
    let data = row.getData();
    if (data.hasOwnProperty("_children")) {
      expanded = this.isExpanded(data.fullName);
    }
    return expanded;
  };

  setRowExpandedInfo = (fullName, expanded) => {
    let cookie = this.getCookie();
    let rowExpandedInfo = cookie.rowExpandedInfo;
    rowExpandedInfo[fullName] = expanded;
    cookie.rowExpandedInfo = rowExpandedInfo;
    this.setCookie(cookie);
  };

  dataTreeRowExpanded = (row, level) => {
    let data = row.getData();
    this.setRowExpandedInfo(data.fullName, true);
  };

  dataTreeRowCollapsed = (row, level) => {
    let data = row.getData();
    this.setRowExpandedInfo(data.fullName, false);
  };

  ////////////////////////////////////////
  // Button support
  ////////////////////////////////////////

  handleRefreshButton = async () => {
    this.props.refreshUsersAndProjects();
  };

  handleCreateSpecButton = (specType) => {
    // DIRTY: See if the spec being edited is dirty
    let specDirty = false;
    if (this.state.showPane == SpecType.REPORT) {
      specDirty = this.props.reportSpecDirty;
    } else if (this.state.showPane == SpecType.BUILD) {
      specDirty = this.props.buildSpecDirty;
    } else if (this.state.showPane == SpecType.HIER) {
      specDirty = this.props.hierSpecDirty;
    }

    if (specDirty == true) {
      this.showDirtyMessage();
      return;
    }

    // DIRTY: Edit a new spec & init dirty
    this.setReportSpecDirty(false);
    this.setBuildSpecDirty(false);
    this.setHierSpecDirty(false);

    let theUpdate = {};

    theUpdate.editReportSpecDoc = funcs.newReportSpecDoc({ data: this.props.defaultReportSpec });
    theUpdate.nextReportSpecDoc = funcs.newReportSpecDoc({ data: this.props.defaultReportSpec });

    theUpdate.editBuildSpecDoc = funcs.newBuildSpecDoc();
    theUpdate.nextBuildSpecDoc = funcs.newBuildSpecDoc();

    theUpdate.editHierSpecDoc = funcs.newHierSpecDoc();
    theUpdate.nextHierSpecDoc = funcs.newHierSpecDoc();

    theUpdate.readOnlyMode = false;

    theUpdate.showPane = specType;

    this.setState(theUpdate);
  };

  ////////////////////////////////////////
  // Menu support
  ////////////////////////////////////////

  addToMenu = (menu, menuItem) => {
    let fullName = menuItem.fullName;
    let specType = menuItem.specType;

    let parts = fullName.split("/");

    if (parts[0] == "Admin") {
      // Everything in Admin has "NA" field. Remove it. It is not relevant for the menu.
      parts.splice(1, 1);
    }

    let fileTail = parts[parts.length - 1];

    let dirParts = null;
    if (specType == 1) {
      dirParts = parts;
    } else {
      dirParts = parts.slice(0, -1);
    }

    let objList = menu;

    // Add any needed directory levels
    let targetDirName = null;
    for (let dirPart of dirParts) {
      if (targetDirName == null) {
        targetDirName = dirPart;
      } else {
        targetDirName = targetDirName + "/" + dirPart;
      }

      let foundDirPart = false;

      for (let obj of objList) {
        let objDirName = obj.fullName;
        let parts = objDirName.split("/");
        if (parts[0] == "Admin" && parts[1] == "NA") {
          // Everything in Admin has "NA" field.
          // This must be removed for comparisons with targetDirName, which has no "NA" field.
          parts.splice(1, 1);
        }
        objDirName = parts.join("/");

        if (obj.specType == SpecType.DIR && objDirName == targetDirName) {
          foundDirPart = true;
          // Set objList for next iteration
          objList = obj._children;
          break;
        }
      }

      if (foundDirPart == false) {
        // The dir at this level does not exist, so create it
        let newMenuItem = _.cloneDeep(dirTemplate);
        let chunks = targetDirName.split("/");
        if (chunks[0] == "Admin" && chunks[1] != "NA") {
          // Everything in Admin has "NA" field.
          // This must be added with "NA", since we have handled in above
          chunks.splice(1, 0, "NA");
          targetDirName = chunks.join("/");
        }
        newMenuItem.fullName = targetDirName;
        newMenuItem.displayName = dirPart;
        newMenuItem.id = newMenuItem.specType + ":" + newMenuItem.fullName;
        objList.push(newMenuItem);
        // Set objList for next iteration
        objList = newMenuItem._children;
      }
    }

    // Add the file
    if (specType != SpecType.DIR) {
      let objFound = false;
      for (let obj of objList) {
        if (obj.specType == specType && obj.fullName == fullName) {
          objFound = true;
          break;
        }
      }
      if (objFound == false) {
        let newMenuItem = _.cloneDeep(menuItem);
        newMenuItem.id = newMenuItem.specType + ":" + newMenuItem.fullName;
        newMenuItem.displayName = fileTail;
        objList.push(newMenuItem);
      }
    }
  };

  genMenuData = () => {
    // This is the data in the return data object
    let tableRows = [];
    let writableFolders = [];
    let fullNameHash = {};

    // Build the return data object
    let menuData = {};
    menuData.tableRows = tableRows;
    menuData.writableFolders = writableFolders;
    menuData.fullNameHash = fullNameHash;

    let userData = this.props.userData;
    let userDataObj = this.props.userDataObj;
    let projectDataObj = this.props.projectDataObj;
    let specInfoObj = this.props.specInfoObj;

    if (!userData) {
      return menuData;
    }
    if (!userDataObj || _.isEmpty(userDataObj)) {
      return menuData;
    }
    if (!projectDataObj) {
      return menuData;
    }

    let currentUserName = this.props.userData.userName;

    let userNameList = [];
    for (let index in userDataObj) {
      let userData = userDataObj[index];
      let userName = userData.userName;
      userNameList.push(userName);
    }

    let projectNameList = Object.keys(projectDataObj).sort();

    let writableAdminFolders = {};
    let writableUserFolders = {};
    let writableProjectFolders = {};

    let initialMenuItems = [];
    let menuItems = [];
    let menuDirs = {};

    ////////////////////////////////////////
    // Create the Users, Projects, and CurrentUser dirs to provide menu structure
    ////////////////////////////////////////

    let menuItem;

    // Projects
    let fullNameAdmin = "Admin/NA";
    menuItem = _.cloneDeep(dirTemplate);
    menuItem.fullName = fullNameAdmin;
    menuItem.displayPath = fullNameAdmin;
    menuItem.displayName = fullNameAdmin;
    menuItem.id = menuItem.specType + ":" + menuItem.fullName;
    initialMenuItems.push(menuItem);

    // Projects
    let fullNameProjects = "Projects";
    menuItem = _.cloneDeep(dirTemplate);
    menuItem.fullName = fullNameProjects;
    menuItem.displayPath = fullNameProjects;
    menuItem.displayName = fullNameProjects;
    menuItem.id = menuItem.specType + ":" + menuItem.fullName;
    initialMenuItems.push(menuItem);

    // Users
    let fullNameUsers = "Users";
    menuItem = _.cloneDeep(dirTemplate);
    menuItem.fullName = fullNameUsers;
    menuItem.displayPath = fullNameUsers;
    menuItem.displayName = fullNameUsers;
    menuItem.id = menuItem.specType + ":" + menuItem.fullName;
    initialMenuItems.push(menuItem);

    // Current User
    let fullNameUser = "Users/" + currentUserName;
    menuItem = _.cloneDeep(dirTemplate);
    menuItem.fullName = fullNameUser;
    menuItem.displayPath = fullNameUser;
    menuItem.displayName = currentUserName;
    menuItem.id = menuItem.specType + ":" + menuItem.fullName;
    initialMenuItems.push(menuItem);
    writableUserFolders[fullNameUser] = true;

    // Initial expansion state
    let expandFullNameList = [fullNameUsers, fullNameUser];
    let cookie = this.getCookie();
    let rowExpandedInfo = cookie.rowExpandedInfo;
    if (_.isEmpty(rowExpandedInfo)) {
      for (let fullName of expandFullNameList) {
        this.setRowExpandedInfo(fullName, true);
      }
    }

    ////////////////////////////////////////
    // specInfoObj[mainFolderName][userOrProject] = [
    //   }
    //     specType: specType,
    //     specName: specName,
    //   }
    // ]
    // Where:
    // mainFolderName: "Users" | "Projects" | "Admin"
    // userOrProject: userName | projectName | "NA"
    // specType: SpecType.REPORT | SpecType.BUILD | SpecType.HIER
    ////////////////////////////////////////

    ////////////////////////////////////////
    // Admin specs
    ////////////////////////////////////////

    let readOnlyMode = true;
    if (this.props.userData.adminFlag) {
      readOnlyMode = false;
    }

    if (!readOnlyMode) {
      writableAdminFolders["Admin"] = true;
    }

    let mainFolderName = "Admin";
    let userOrProject = "NA";

    let path = [mainFolderName, userOrProject];
    let specObjList = funcs.getPropValue(specInfoObj, path);

    let specNameList = [];
    let specName2specType = {};
    if (specObjList) {
      for (let specObj of specObjList) {
        specNameList.push(specObj.specName);
        specName2specType[specObj.specName] = specObj.specType;
      }
    }

    for (let specName of specNameList) {
      let specType = specName2specType[specName];
      let fullName = mainFolderName + "/" + userOrProject + "/" + specName;
      fullNameHash[fullName] = true;

      let partsWithNA = fullName.split("/");
      let partsWithoutNA = fullName.split("/");
      partsWithoutNA.splice(1, 1); // This removes the "NA"

      let fileTail = partsWithNA[partsWithNA.length - 1];

      partsWithoutNA = partsWithoutNA.slice(0, -1); // All but fileTail
      let dirNameWithoutNA = partsWithoutNA.join("/");

      partsWithNA = partsWithNA.slice(0, -1); // All but fileTail
      let dirNameWithNA = partsWithNA.join("/");

      if (!menuDirs.hasOwnProperty(dirNameWithoutNA)) {
        // For SPECs, fullName references a full path to a spec
        // For DIRs, fullName needs to the "dir" of the spec (with "NA")

        // Mark dir as visited
        menuDirs[dirNameWithoutNA] = true;
        // Add dir to menuItems
        menuItem = _.cloneDeep(dirTemplate);
        menuItem.fullName = dirNameWithNA;
        menuItem.displayName = fileTail;
        menuItem.id = menuItem.specType + ":" + menuItem.fullName;
        menuItems.push(menuItem);
        // Add dir to folder list
        if (readOnlyMode == false) {
          writableAdminFolders[dirNameWithoutNA] = true;
        }
      }

      menuItem = _.cloneDeep(fileTemplate);
      menuItem.specType = specType;
      menuItem.readOnlyMode = readOnlyMode;
      menuItem.fullName = fullName;
      menuItem.displayName = fileTail;
      menuItem.id = menuItem.specType + ":" + menuItem.fullName;
      menuItems.push(menuItem);
    }

    ////////////////////////////////////////
    // User specs
    ////////////////////////////////////////

    for (let userName of userNameList) {
      let mainFolderName = "Users";
      let userOrProject = userName;

      let readOnlyMode = true;
      if (currentUserName == userName) {
        readOnlyMode = false;
      }

      let path = [mainFolderName, userOrProject];
      let specObjList = funcs.getPropValue(specInfoObj, path);
      if (specObjList == null) {
        continue;
      }

      let specNameList = [];
      let specName2specType = {};
      for (let specObj of specObjList) {
        specNameList.push(specObj.specName);
        specName2specType[specObj.specName] = specObj.specType;
      }

      for (let specName of specNameList) {
        let specType = specName2specType[specName];
        let fullName = mainFolderName + "/" + userOrProject + "/" + specName;
        fullNameHash[fullName] = true;

        let parts = fullName.split("/");
        let dirName = parts.slice(0, -1).join("/");
        let fileTail = parts[parts.length - 1];

        if (!menuDirs.hasOwnProperty(dirName)) {
          // Mark dir as visited
          menuDirs[dirName] = true;
          // Add dir to menuItems
          menuItem = _.cloneDeep(dirTemplate);
          menuItem.fullName = dirName;
          menuItem.displayName = fileTail;
          menuItem.id = menuItem.specType + ":" + menuItem.fullName;
          menuItems.push(menuItem);
          // Add dir to folder list
          if (readOnlyMode == false) {
            writableUserFolders[dirName] = true;
          }
        }

        menuItem = _.cloneDeep(fileTemplate);
        menuItem.specType = specType;
        menuItem.readOnlyMode = readOnlyMode;
        menuItem.fullName = fullName;
        menuItem.displayName = fileTail;
        menuItem.id = menuItem.specType + ":" + menuItem.fullName;
        menuItems.push(menuItem);
      }
    }

    ////////////////////////////////////////
    // Project specs
    ////////////////////////////////////////

    for (let projectName of projectNameList) {
      if (!this.props.userData.projectsMember.includes(projectName)) {
        continue;
      }

      let readOnlyMode = true;
      if (this.props.userData.projectsManager.includes(projectName)) {
        readOnlyMode = false;
      }

      let mainFolderName = "Projects";
      let userOrProject = projectName;

      // Make sure table has folders for each project
      let fullName = mainFolderName + "/" + userOrProject;
      // Add dir to menuItems
      menuItem = _.cloneDeep(dirTemplate);
      menuItem.fullName = fullName;
      menuItem.displayName = projectName;
      menuItem.id = menuItem.specType + ":" + menuItem.fullName;
      menuItems.push(menuItem);
      // Add dir to folder list
      if (readOnlyMode == false) {
        writableProjectFolders[fullName] = true;
      }

      let path = [mainFolderName, userOrProject];
      let specObjList = funcs.getPropValue(specInfoObj, path);
      if (specObjList == null) {
        continue;
      }

      let specNameList = [];
      let specName2specType = {};
      for (let specObj of specObjList) {
        specNameList.push(specObj.specName);
        specName2specType[specObj.specName] = specObj.specType;
      }

      for (let specName of specNameList) {
        let specType = specName2specType[specName];
        let menuItem = _.cloneDeep(fileTemplate);
        let fullName = mainFolderName + "/" + userOrProject + "/" + specName;
        fullNameHash[fullName] = true;

        let parts = fullName.split("/");
        // let dirName = parts.slice(0, -1).join("/");
        let fileTail = parts[parts.length - 1];

        menuItem = _.cloneDeep(fileTemplate);
        menuItem.specType = specType;
        menuItem.readOnlyMode = readOnlyMode;
        menuItem.fullName = fullName;
        menuItem.displayName = fileTail;
        menuItem.id = menuItem.specType + ":" + menuItem.fullName;
        menuItems.push(menuItem);
      }
    }

    ////////////////////////////////////////
    // Build menu
    ////////////////////////////////////////

    menuItems.sort(this.compareMenuItems);

    let allMenuItems = _.cloneDeep(initialMenuItems);
    for (let menuItem of menuItems) {
      allMenuItems.push(menuItem);
    }

    for (let menuItem of allMenuItems) {
      this.addToMenu(tableRows, menuItem);
    }

    ////////////////////////////////////////
    // Fill the return data object
    ////////////////////////////////////////

    for (let folder of Object.keys(writableAdminFolders).sort()) {
      writableFolders.push(folder);
    }
    for (let folder of Object.keys(writableUserFolders).sort()) {
      writableFolders.push(folder);
    }
    for (let folder of Object.keys(writableProjectFolders).sort()) {
      writableFolders.push(folder);
    }

    menuData.tableRows = tableRows;
    menuData.writableFolders = writableFolders;
    menuData.fullNameHash = fullNameHash;
    return menuData;
  };

  compareMenuItems = (a, b) => {
    let compare = 0;
    if (a.id > b.id) {
      compare = 1;
    } else if (a.id < b.id) {
      compare = -1;
    }
    return compare;
  };

  rowClick = (e, row) => {
    let data = row.getData();
    let specType = data.specType;

    let allowSelect = true;
    if (specType == SpecType.BUILD && this.props.currentReportSpecDoc.fullName == null) {
      allowSelect = false;
    }

    if (specType == SpecType.DIR) {
      return;
    } else {
      if (allowSelect) {
        this.actionSelectSpec(e, row);
      } else {
        let message = "Right-click to Select or Edit spec.\nNote: A Report spec must be selected prior to Build spec selection.";
        funcs.showNotification("Config Specs", message);
      }
    }
  };

  rowContextMenu = (e, row) => {
    let menu = [];

    let data = row.getData();
    let specType = data.specType;

    if (data.hasOwnProperty("_children")) {
      return menu;
    }

    let allowSelect = true;
    if (specType == SpecType.BUILD && this.props.currentReportSpecDoc.fullName == null) {
      allowSelect = false;
    }

    if (allowSelect == true) {
      menu.push({
        label: "Select",
        action: this.actionSelectSpec,
      });
    }
    menu.push({
      label: "Edit",
      action: this.actionEditSpec,
    });

    return menu;
  };

  actionSelectSpec = async (e, row) => {
    let data = row.getData();
    let specType = data.specType;
    let fullName = data.fullName;

    let r = await fastapi.readSpecDoc(this.props.systemConfig.dataServer, specType, fullName);

    if (r.success) {
      let specDoc = r.specDoc;
      if (specType == SpecType.REPORT) {
        this.props.setCurrentReportSpecDoc(specDoc);
      } else if (specType == SpecType.BUILD) {
        this.props.setCurrentBuildSpecDoc(specDoc);
      } else if (specType == SpecType.HIER) {
        this.props.setCurrentHierSpecDoc(specDoc);
      }
    } else {
      funcs.showNotification("Unable to read spec", r.message);
    }
  };

  actionEditSpec = async (e, row) => {
    let data = row.getData();
    let specType = data.specType;
    let fullName = data.fullName;

    let theUpdate = {};

    theUpdate.readOnlyMode = data.readOnlyMode;

    // DIRTY: See if the spec being edited is dirty
    let specDirty = false;
    if (this.state.showPane == SpecType.REPORT && this.props.reportSpecDirty) {
      specDirty = true;
    } else if (this.state.showPane == SpecType.BUILD && this.props.buildSpecDirty) {
      specDirty = true;
    } else if (this.state.showPane == SpecType.HIER && this.props.hierSpecDirty) {
      specDirty = true;
    }
    if (specDirty == true) {
      this.showDirtyMessage();
      return;
    }

    let r = await fastapi.readSpecDoc(this.props.systemConfig.dataServer, specType, fullName);

    if (r.success) {
      let specDoc = r.specDoc;

      // DIRTY: Edit a new spec & init dirty
      if (specType == SpecType.REPORT) {
        let nextShowPane = SpecType.REPORT;
        this.setReportSpecDirty(false);
        theUpdate.editReportSpecDoc = specDoc;
        theUpdate.nextReportSpecDoc = specDoc;

        if (this.state.showPane != nextShowPane) {
          // theUpdate.editReportSpecDoc = funcs.newReportSpecDoc({ data: this.props.defaultReportSpec });
          theUpdate.editBuildSpecDoc = funcs.newBuildSpecDoc();
          theUpdate.editHierSpecDoc = funcs.newHierSpecDoc();
          theUpdate.showPane = nextShowPane;
        }
      } else if (specType == SpecType.BUILD) {
        let nextShowPane = SpecType.BUILD;
        this.setBuildSpecDirty(false);
        theUpdate.editBuildSpecDoc = specDoc;
        theUpdate.nextBuildSpecDoc = specDoc;

        if (this.state.showPane != nextShowPane) {
          theUpdate.editReportSpecDoc = funcs.newReportSpecDoc({ data: this.props.defaultReportSpec });
          // theUpdate.editBuildSpecDoc = funcs.newBuildSpecDoc();
          theUpdate.editHierSpecDoc = funcs.newHierSpecDoc();
          theUpdate.showPane = nextShowPane;
        }
      } else if (specType == SpecType.HIER) {
        let nextShowPane = SpecType.HIER;
        this.setHierSpecDirty(false);
        theUpdate.editHierSpecDoc = specDoc;
        theUpdate.nextHierSpecDoc = specDoc;

        if (this.state.showPane != nextShowPane) {
          theUpdate.editReportSpecDoc = funcs.newReportSpecDoc({ data: this.props.defaultReportSpec });
          theUpdate.editBuildSpecDoc = funcs.newBuildSpecDoc();
          // theUpdate.editHierSpecDoc = funcs.newHierSpecDoc();
          theUpdate.showPane = nextShowPane;
        }
      }

      this.setState(theUpdate);
    } else {
      funcs.showNotification("Unable to read spec", r.message);
    }
  };

  cellFormatter = (cell, formatterParams, onRendered) => {
    let columnField = cell.getColumn().getField();
    let data = cell.getRow().getData();
    let specType = data.specType;

    let returnValue = null;

    if (columnField == "displayName") {
      ////////////////////////////////////////
      // This section handles the text column
      ////////////////////////////////////////

      let displayText = cell.getValue();
      let displayIcon = null;

      let fg = colorWhite;
      let bg = colorRed;

      if (specType == SpecType.DIR) {
        fg = colorBlack;
        bg = colorWhite;
      } else if (specType == SpecType.REPORT) {
        fg = colorBlack;
        bg = colorWhite;
        displayIcon = <img src={iconIsReportSpec} alt="indicatorImg" />;
      } else if (specType == SpecType.BUILD) {
        fg = colorGreen;
        bg = colorWhite;
        displayIcon = <img src={iconIsBuildSpec} alt="indicatorImg" />;
      } else if (specType == SpecType.HIER) {
        fg = colorBlue;
        bg = colorWhite;
        displayIcon = <img src={iconIsHierSpec} alt="indicatorImg" />;
      }

      let styleDiv = {
        display: "inline",
        color: fg,
      };

      let content = (
        <div style={styleDiv}>
          {displayIcon}
          {displayText}
        </div>
      );

      returnValue = ReactDOMServer.renderToString(content);
    } else if (columnField == "selectedStatus") {
      ////////////////////////////////////////
      // This section handles the indicator column
      ////////////////////////////////////////

      let indicator = null;

      if (specType == SpecType.REPORT) {
        let currentRptSpec = data.fullName == this.props.currentReportSpecDoc.fullName;
        let currentEditSpec = data.fullName == this.state.editReportSpecDoc.fullName;

        if (currentRptSpec && !currentEditSpec) {
          indicator = (
            <div>
              <img src={iconCurrentReportSpec} alt="indicatorImg" />
            </div>
          );
        } else if (!currentRptSpec && currentEditSpec) {
          indicator = (
            <div>
              <img src={iconEditReportSpec} alt="indicatorImg" />
            </div>
          );
        } else if (currentRptSpec && currentEditSpec) {
          indicator = (
            <div>
              <img src={iconCurrentReportSpec} alt="indicatorImg" />
              <img src={iconEditReportSpec} alt="indicatorImg" />
            </div>
          );
        }
      } else if (specType == SpecType.BUILD) {
        let currentRptSpec = data.fullName == this.props.currentBuildSpecDoc.fullName;
        let currentEditSpec = data.fullName == this.state.editBuildSpecDoc.fullName;

        if (currentRptSpec && !currentEditSpec) {
          indicator = (
            <div>
              <img src={iconCurrentBuildSpec} alt="indicatorImg" />
            </div>
          );
        } else if (!currentRptSpec && currentEditSpec) {
          indicator = (
            <div>
              <img src={iconEditBuildSpec} alt="indicatorImg" />
            </div>
          );
        } else if (currentRptSpec && currentEditSpec) {
          indicator = (
            <div>
              <img src={iconCurrentBuildSpec} alt="indicatorImg" />
              <img src={iconEditBuildSpec} alt="indicatorImg" />
            </div>
          );
        }
      } else if (specType == SpecType.HIER) {
        let currentRptSpec = data.fullName == this.props.currentHierSpecDoc.fullName;
        let currentEditSpec = data.fullName == this.state.editHierSpecDoc.fullName;

        if (currentRptSpec && !currentEditSpec) {
          indicator = (
            <div>
              <img src={iconCurrentHierSpec} alt="indicatorImg" />
            </div>
          );
        } else if (!currentRptSpec && currentEditSpec) {
          indicator = (
            <div>
              <img src={iconEditHierSpec} alt="indicatorImg" />
            </div>
          );
        } else if (currentRptSpec && currentEditSpec) {
          indicator = (
            <div>
              <img src={iconCurrentHierSpec} alt="indicatorImg" />
              <img src={iconEditHierSpec} alt="indicatorImg" />
            </div>
          );
        }
      }

      returnValue = ReactDOMServer.renderToString(indicator);
    }

    return returnValue;
  };

  rowFormatter = (row) => {
    row.getElement().style.backgroundColor = "#ffffff";
  };

  selectableCheck = (row) => {
    let data = row.getData();
    return !data.hasOwnProperty("_children");
  };

  ////////////////////////////////////////
  // Callbacks for Spec Editors
  ////////////////////////////////////////

  saveSpec = async (specType, specDoc) => {
    let copySpecDoc = _.cloneDeep(specDoc);
    if (specType == SpecType.REPORT) {
      copySpecDoc["savedReportStates"] = {};
    }

    await this.updateSpecWrite(specType, copySpecDoc);

    // If we are altering the currently selected specs for the reports,
    // update state that drives spec info into reports
    if (specType == SpecType.REPORT) {
      if (copySpecDoc.fullName == this.props.currentReportSpecDoc.fullName) {
        this.props.setCurrentReportSpecDoc(copySpecDoc);
      }
    } else if (specType == SpecType.BUILD) {
      if (copySpecDoc.fullName == this.props.currentBuildSpecDoc.fullName) {
        this.props.setCurrentBuildSpecDoc(copySpecDoc);
      }
    } else if (specType == SpecType.HIER) {
      if (copySpecDoc.fullName == this.props.currentHierSpecDoc.fullName) {
        this.props.setCurrentHierSpecDoc(copySpecDoc);
      }
    }

    // Update state that drives the original spec info into editors
    if (specType == SpecType.REPORT) {
      this.setState({ editReportSpecDoc: this.state.nextReportSpecDoc });
    } else if (specType == SpecType.BUILD) {
      this.setState({ editBuildSpecDoc: this.state.nextBuildSpecDoc });
    } else if (specType == SpecType.HIER) {
      this.setState({ editHierSpecDoc: this.state.nextHierSpecDoc });
    }
  };

  saveSpecAs = async (specType, specDoc) => {
    let copySpecDoc = _.cloneDeep(specDoc);
    if (specType == SpecType.REPORT) {
      copySpecDoc["savedReportStates"] = {};
    }

    await this.updateSpecWrite(specType, copySpecDoc);

    if (specType == SpecType.REPORT) {
      this.setState({ editReportSpecDoc: copySpecDoc, nextReportSpecDoc: copySpecDoc });
    } else if (specType == SpecType.BUILD) {
      this.setState({ editBuildSpecDoc: copySpecDoc, nextBuildSpecDoc: copySpecDoc });
    } else if (specType == SpecType.HIER) {
      this.setState({ editHierSpecDoc: copySpecDoc, nextHierSpecDoc: copySpecDoc });
    }
  };

  renameSpec = async (specType, newFullName) => {
    let orgSpecDoc;
    if (specType == SpecType.REPORT) {
      orgSpecDoc = this.state.editReportSpecDoc;
    } else if (specType == SpecType.BUILD) {
      orgSpecDoc = this.state.editBuildSpecDoc;
    } else if (specType == SpecType.HIER) {
      orgSpecDoc = this.state.editHierSpecDoc;
    }

    let newSpecDoc = _.cloneDeep(orgSpecDoc);
    newSpecDoc.fullName = newFullName;

    await this.updateSpecRename(specType, orgSpecDoc, newSpecDoc);

    // If we are altering the currently selected specs for the reports,
    // update state that drives spec info into reports
    if (specType == SpecType.REPORT) {
      if (orgSpecDoc.fullName == this.props.currentReportSpecDoc.fullName) {
        this.props.setCurrentReportSpecDoc(newSpecDoc);
      }
    } else if (specType == SpecType.BUILD) {
      if (orgSpecDoc.fullName == this.props.currentBuildSpecDoc.fullName) {
        this.props.setCurrentBuildSpecDoc(newSpecDoc);
      }
    } else if (specType == SpecType.HIER) {
      if (orgSpecDoc.fullName == this.props.currentHierSpecDoc.fullName) {
        this.props.setCurrentHierSpecDoc(newSpecDoc);
      }
    }

    // Update state that drives spec info into editors
    if (specType == SpecType.REPORT) {
      if (orgSpecDoc.fullName == this.state.editReportSpecDoc.fullName) {
        this.setState({ editReportSpecDoc: newSpecDoc, nextReportSpecDoc: newSpecDoc });
      }
    } else if (specType == SpecType.BUILD) {
      if (orgSpecDoc.fullName == this.state.editBuildSpecDoc.fullName) {
        this.setState({ editBuildSpecDoc: newSpecDoc, nextBuildSpecDoc: newSpecDoc });
      }
    } else if (specType == SpecType.HIER) {
      if (orgSpecDoc.fullName == this.state.editHierSpecDoc.fullName) {
        this.setState({ editHierSpecDoc: newSpecDoc, nextHierSpecDoc: newSpecDoc });
      }
    }
  };

  // The deleteSpec & cancelSpec functions require a confirmation before proceesing.
  // The order of operation is:
  // deleteSpec()/cancelSpec():
  //   - Shows ConfirmPopup dialog
  // confirmPopupSubmitAnswer():
  //   - Processes response from ConfirmPopup dialog
  //   - Calls deleteSpecConfirmed()/cancelSpecConfirmed() if response is accepted

  deleteSpec = async (specType) => {
    let fullName;
    if (specType == SpecType.REPORT) {
      fullName = this.state.editReportSpecDoc.fullName;
    } else if (specType == SpecType.BUILD) {
      fullName = this.state.editBuildSpecDoc.fullName;
    } else if (specType == SpecType.HIER) {
      fullName = this.state.editHierSpecDoc.fullName;
    }

    let data = {};
    data.title = "Delete Spec: " + fullName;
    data.message = "Are you sure you want to delete this spec?";
    data.operation = "deleteSpec";
    data.specType = specType;
    this.setState({ showConfirmPopup: true, dataConfirmPopup: data });
  };

  cancelSpec = async (specType) => {
    let confirmClose;
    if (specType == SpecType.REPORT) {
      confirmClose = this.reportSpecDirty;
    } else if (specType == SpecType.BUILD) {
      confirmClose = this.buildSpecDirty;
    } else if (specType == SpecType.HIER) {
      confirmClose = this.hierSpecDirty;
    }

    if (confirmClose == true) {
      let data = {};
      data.title = "Cancel";
      data.message = "Are you sure you want to cancel these edits?";
      data.operation = "cancelSpec";
      data.specType = specType;
      this.setState({ showConfirmPopup: true, dataConfirmPopup: data });
    } else {
      this.cancelSpecConfirmed(specType);

      // this.setState({ showPane: SpecType.NONE });
    }
  };

  confirmPopupSubmitAnswer = (accept, data) => {
    if (accept) {
      if (data.operation == "deleteSpec") {
        this.deleteSpecConfirmed(data.specType);
      } else if (data.operation == "cancelSpec") {
        this.cancelSpecConfirmed(data.specType);
      }
    }
    this.setState({ showConfirmPopup: false });
  };

  deleteSpecConfirmed = async (specType) => {
    let fullName;
    if (specType == SpecType.REPORT) {
      fullName = this.state.editReportSpecDoc.fullName;
    } else if (specType == SpecType.BUILD) {
      fullName = this.state.editBuildSpecDoc.fullName;
    } else if (specType == SpecType.HIER) {
      fullName = this.state.editHierSpecDoc.fullName;
    }

    await this.updateSpecDelete(specType, fullName);

    let emptyReportSpec = funcs.newReportSpecDoc({ data: this.props.defaultReportSpec });
    let emptyBuildSpec = funcs.newBuildSpecDoc();
    let emptyHierSpec = funcs.newHierSpecDoc();

    // If we are altering the currently selected specs for the reports,
    // update state that drives spec info into reports

    if (specType == SpecType.REPORT) {
      if (fullName == this.props.currentReportSpecDoc.fullName) {
        this.props.setCurrentReportSpecDoc(emptyReportSpec);
      }
    } else if (specType == SpecType.BUILD) {
      if (fullName == this.props.currentBuildSpecDoc.fullName) {
        this.props.setCurrentBuildSpecDoc(emptyBuildSpec);
      }
    } else if (specType == SpecType.HIER) {
      if (fullName == this.props.currentHierSpecDoc.fullName) {
        this.props.setCurrentHierSpecDoc(emptyHierSpec);
      }
    }

    let theUpdate = {};
    theUpdate.showPane = SpecType.NONE;
    this.setState(theUpdate);
  };

  cancelSpecConfirmed = async (specType) => {
    let theUpdate = {};
    theUpdate.showPane = SpecType.NONE;
    if (specType == SpecType.REPORT) {
      this.setReportSpecDirty(false);
      theUpdate.editReportSpecDoc = funcs.newReportSpecDoc({ data: this.props.defaultReportSpec });
    } else if (specType == SpecType.BUILD) {
      this.setBuildSpecDirty(false);
      theUpdate.editBuildSpecDoc = funcs.newBuildSpecDoc();
    } else if (specType == SpecType.HIER) {
      this.setHierSpecDirty(false);
      theUpdate.editHierSpecDoc = funcs.newHierSpecDoc();
    }
    this.setState(theUpdate);
  };

  updateNextReportSpec = (specDoc) => {
    this.setState({ nextReportSpecDoc: specDoc });
  };

  updateNextBuildSpec = (specDoc) => {
    this.setState({ nextBuildSpecDoc: specDoc });
  };

  updateNextHierSpec = (specDoc) => {
    this.setState({ nextHierSpecDoc: specDoc });
  };

  updateSpecWrite = async (specType, specDoc) => {
    // Write the specDoc
    let r = await fastapi.writeSpecDoc(this.props.systemConfig.dataServer, specType, specDoc);
    if (!r.success) {
      funcs.showNotification("Config Specs", r.message);
    }

    this.handleRefreshButton();
  };

  updateSpecRename = async (specType, orgSpecDoc, newSpecDoc) => {
    let r;
    // Write the new specDoc
    r = await fastapi.writeSpecDoc(this.props.systemConfig.dataServer, specType, newSpecDoc);
    if (!r.success) {
      funcs.showNotification("Config Specs", r.message);
    }

    // Delete the org specDoc
    r = await fastapi.deleteSpecDoc(this.props.systemConfig.dataServer, specType, orgSpecDoc);
    if (!r.success) {
      funcs.showNotification("Config Specs", r.message);
    }

    this.handleRefreshButton();
  };

  updateSpecDelete = async (specType, fullName) => {
    // Delete the specDoc

    // Note: This specDoc is partial since all we need is fullName
    let specDoc = { fullName: fullName };

    let r = await fastapi.deleteSpecDoc(this.props.systemConfig.dataServer, specType, specDoc);
    if (!r.success) {
      funcs.showNotification("Config Specs", r.message);
    }

    this.handleRefreshButton();
  };
}

export default ConfigMain2;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
