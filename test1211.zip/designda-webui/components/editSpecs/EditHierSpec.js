////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/EditHierSpec.js#22 $
////////////////////////////////////////////////////////////////////////////////

import React from "react";
import RenameSpecPopup from "metrics/dialogs/RenameSpecPopup";
import GetSpecNamePopup from "metrics/dialogs/GetSpecNamePopup";

import { ButtonGroup, FilledInput, FormControl, FormControlLabel, InputAdornment, InputLabel } from "@mui/material";

import { ThemedButton, ThemedFormControlLabel, ThemedLabel } from "components/editSpecs/widgets/ThemedWidgets";

import _ from "lodash";
import * as funcs from "common/Funcs";
import * as fastapi from "common/FastApi";

import "./EditHierSpec.module.css";

const SpecType = Object.freeze(funcs.SpecType);

class EditHierSpec extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showRenameSpecPopup: false,
      showGetSpecNamePopup: false,
    };

    this.specType = SpecType.HIER;

    this.fileInputRef = React.createRef();
    this.addBuildsViaQueryActive = false;
  }

  render() {
    let disabledResetSpec = !this.props.specDirty;
    let disabledSaveSpec = false;
    let disabledSaveSpecAs = false;
    let disabledRenameSpec = false;
    let disabledDeleteSpec = false;
    let disabledUploadSpec = false;
    let disabledDownloadSpec = false;

    let currentEditSpecText = funcs.specDisplayText(this.props.editSpec.fullName);

    if (this.props.editSpec.fullName == null) {
      // disabledResetSpec = true;
      disabledSaveSpec = true;
      disabledRenameSpec = true;
      disabledDeleteSpec = true;
    }

    if (this.props.readOnlyMode == true) {
      disabledResetSpec = true;
      disabledSaveSpec = true;
      disabledRenameSpec = true;
      disabledDeleteSpec = true;
      disabledUploadSpec = true;
    }

    let specLabel = <ThemedLabel text={currentEditSpecText} type="HierSpec" orient="horizontal" />;

    let cancelCloseButtonType = this.props.specDirty ? "alert" : "standard";
    let cancelCloseButtonText = this.props.specDirty ? "Cancel" : "Close";

    let cancelCloseButton = <ThemedButton text={cancelCloseButtonText} type={cancelCloseButtonType} onClick={this.handleCancelButton} />;
    let resetButton = <ThemedButton text="Reset" onClick={this.handleResetSpecButton} disabled={disabledResetSpec} />;
    let saveButton = <ThemedButton text="Save" onClick={this.handleSaveSpecButton} disabled={disabledSaveSpec} />;
    let saveAsButton = <ThemedButton text="Save As" onClick={this.handleSaveSpecAsButton} disabled={disabledSaveSpecAs} />;
    let renameButton = <ThemedButton text="Rename" onClick={this.handleRenameSpecButton} disabled={disabledRenameSpec} />;
    let deleteSpecButton = <ThemedButton text="Delete Spec" type="alert" onClick={this.handleDeleteSpecButton} disabled={disabledDeleteSpec} />;
    let uploadSpecButton = <ThemedButton text="Upload Spec" onClick={this.handleUploadSpecButton} disabled={disabledUploadSpec} />;
    let downloadSpecButton = <ThemedButton text="Download Spec" onClick={this.handleDownloadSpecButton} disabled={disabledDownloadSpec} />;

    let projectName = "";
    let seriesName = "";
    let hierData = [];

    if (this.props.nextSpec != null) {
      if (this.props.nextSpec.projectName != null) {
        projectName = this.props.nextSpec.projectName;
      }
      if (this.props.nextSpec.seriesName != null) {
        seriesName = this.props.nextSpec.seriesName;
      }
      if (this.props.nextSpec.data != null) {
        hierData = this.props.nextSpec.data;
      }
    }

    let inputProjectName = (
      <div>
        <FormControl fullWidth variant="filled">
          <InputLabel>Project Name</InputLabel>
          <FilledInput value={projectName} onChange={this.updateProjectName} />
        </FormControl>
      </div>
    );

    let inputSeriesName = (
      <div>
        <FormControl fullWidth variant="filled">
          <InputLabel>Series Name</InputLabel>
          <FilledInput value={seriesName} onChange={this.updateSeriesName} />
        </FormControl>
      </div>
    );

    let hierDataDisplay = (
      <div>
        <div>Hier Data:</div>
        <pre id="preEditHier">{JSON.stringify(hierData, null, 2)}</pre>
      </div>
    );

    return (
      <div id="divEditHierSpec">
        <div id="divEditHierSpecButtons">
          <div id="divEditHierSpecButtonsRow" className="d-flex flex-row">
            {specLabel}
            <ButtonGroup>
              {resetButton}
              {saveButton}
              {saveAsButton}
              {renameButton}
              {uploadSpecButton}
              {downloadSpecButton}
              {deleteSpecButton}
              {cancelCloseButton}
            </ButtonGroup>
          </div>
        </div>

        <div>
          {inputProjectName}
          {inputSeriesName}
          {hierDataDisplay}
        </div>

        <RenameSpecPopup
          show={this.state.showRenameSpecPopup}
          currentFullName={this.props.editSpec.fullName}
          fullNameHash={this.props.fullNameHash}
          // writableFolders={this.props.writableFolders}
          submitAnswer={this.renameSpecPopupSubmitAnswer}
        />

        <GetSpecNamePopup
          show={this.state.showGetSpecNamePopup}
          currentFullName={this.props.editSpec.fullName}
          fullNameHash={this.props.fullNameHash}
          writableFolders={this.props.writableFolders}
          submitAnswer={this.getSpecNamePopupSubmitAnswer}
        />

        <input id="inputId" ref={this.fileInputRef} type="file" style={{ display: "none" }} onChange={this.handleUploadFile} accept=".json" />
      </div>
    );
  }

  updateSpecDirty = (orgSpecData, nextSpecData) => {
    let dirty = !_.isEqual(orgSpecData, nextSpecData);
    this.props.setSpecDirty(dirty);
  };

  componentDidMount() {
    window.addEventListener("resize", () => this.resizeEvent());
    this.forceUpdate();
  }

  componentDidUpdate() {
    this.handleResize();
  }

  componentWillUnmount() {}

  handleResetSpecButton = () => {
    let editSpecDoc = this.props.editSpec;
    let nextSpecDoc = this.props.editSpec;
    this.updateSpecDirty(editSpecDoc, nextSpecDoc);
    this.props.updateNextSpec(nextSpecDoc);
  };

  handleSaveSpecButton = () => {
    let nextSpec = this.props.nextSpec;
    this.props.saveSpec(this.specType, nextSpec);
    this.props.setSpecDirty(false);
  };

  handleSaveSpecAsButton = () => {
    // Get SaveSpecAs info from user
    this.setState({ showGetSpecNamePopup: true });
  };

  getSpecNamePopupSubmitAnswer = (accept, fullName) => {
    if (accept == true) {
      let specDoc = _.cloneDeep(this.props.nextSpec);
      specDoc.fullName = fullName;
      this.props.saveSpecAs(this.specType, specDoc);
      this.props.setSpecDirty(false);
    }
    this.setState({ showGetSpecNamePopup: false });
  };

  handleRenameSpecButton = () => {
    // Get RenameSpec info from user
    this.setState({ showRenameSpecPopup: true });
  };

  renameSpecPopupSubmitAnswer = (accept, newFullName) => {
    // Use RenameSpec info from user
    if (accept) {
      this.props.renameSpec(this.specType, newFullName);
      this.props.setSpecDirty(false);
    }
    this.setState({ showRenameSpecPopup: false });
  };

  handleUploadSpecButton = () => {
    if (this.props.specDirty == true) {
      this.props.showDirtyMessage();
    } else {
      this.fileInputRef.current?.click();
    }
  };

  handleUploadFile = async () => {
    let theFile = null;
    if (this.fileInputRef.current?.files) {
      theFile = this.fileInputRef.current.files[0];
    }
    // Clear the input value so that onChange will work for re-selection of the same file
    document.getElementById("inputId").value = null;

    if (theFile == null) {
      return;
    }

    let formData = new FormData();
    formData.append("theFile", theFile);

    let r = await fastapi.uploadJsonFile(this.props.systemConfig.dataServer, formData);
    let jsonObj = r.jsonObj;

    if (r.success) {
      let editSpecDoc = this.props.editSpec;
      let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
      nextSpecDoc.data = jsonObj;

      this.updateSpecDirty(editSpecDoc, nextSpecDoc);
      this.props.updateNextSpec(nextSpecDoc);
    } else {
      funcs.showNotification("Upload Spec", r.message);
      return;
    }
  };

  handleDownloadSpecButton = () => {
    let fileName = "hierSpec";
    let specData = this.props.nextSpec.data;
    const blob = new Blob([JSON.stringify(specData, null, 2)], {
      type: "application/json",
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", fileName + ".json");
    document.body.appendChild(link);
    link.click();
  };

  updateProjectName = (event) => {
    let text = event.target.value;
    text.trim();

    let editSpecDoc = this.props.editSpec;
    let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
    nextSpecDoc.projectName = text;

    this.updateSpecDirty(editSpecDoc, nextSpecDoc);
    this.props.updateNextSpec(nextSpecDoc);
  };

  updateSeriesName = (event) => {
    let text = event.target.value;
    text.trim();

    let editSpecDoc = this.props.editSpec;
    let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
    nextSpecDoc.seriesName = text;

    this.updateSpecDirty(editSpecDoc, nextSpecDoc);
    this.props.updateNextSpec(nextSpecDoc);
  };

  handleDeleteSpecButton = () => {
    this.props.deleteSpec(this.specType);
  };

  handleCancelButton = () => {
    this.props.cancelSpec(this.specType);
  };

  resizeEvent = () => {
    clearTimeout(this.resizeTimeout);
    this.resizeTimeout = setTimeout(this.handleResize, funcs.ResizeDelay);
  };

  handleResize = () => {
    let preEditHier = document.getElementById("preEditHier");
    if (preEditHier == null) {
      return;
    }

    let preRect = preEditHier.getBoundingClientRect();
    let windowHeight = document.documentElement.clientHeight;
    let preHeight = windowHeight - preRect.top;
    preEditHier.style.height = preHeight + "px";
  };
}

export default EditHierSpec;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
