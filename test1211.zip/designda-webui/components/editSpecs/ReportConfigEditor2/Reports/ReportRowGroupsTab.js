////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportRowGroupsTab.js#8 $
// HEADER_MSG $Author: banakar $
// HEADER_MSG $DateTime: 2023/06/28 01:12:19 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
// import SplitPane from "react-split-pane";

import { ReactTabulator } from "react-tabulator";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import ReportRowGroupsEdit from "components/editSpecs/ReportConfigEditor2/Reports/ReportRowGroupsEdit";

import styles from "./ReportRowGroupsTab.module.css";
import { Divider } from "@mui/material";

const SectionName = "Row Group";
const SectionElement = "row group";

class ReportRowGroupsTab extends React.Component {
  constructor(props) {
    super(props);

    /**!
     * Props:
     *   reportName     : [String]   - Name of currently selected report
     *   editSpec       : [Object]   - 
     *   nextSpec       : [Object]   - 
     *   updateNextSpec : [Function] - 
     *   updateDirty    : [Function] - 
     */

    this.state = {
      selectedName: null,
      selectedList: [],

      tableKey: 0,
    };

    this.mouseOver = false;
    this.ignoreRowSelection = false;

    this.dirty = false;

    this.tableRef = React.createRef();
  }

  render() {
    let content = null;

    if (this.props.reportName == null) {
      content = (<div>Please select a report on the left</div>);
    } else {
      let tableInfo = this.getTableInfo();

      let currentReportNameLabel = (
        <div id="divEditorTop_ReportRowGroupsTab_Label" className={styles.divEditorTop_ReportRowGroupsTab_Label}>{this.props.reportName}</div>
      );

      let leftPane = (
        <div id="divEditorTop_ReportRowGroupsTab_LeftPane" className={styles.divEditorTop_ReportRowGroupsTab_LeftPane} style={{ float: "left", height: "100%" }}>
          {currentReportNameLabel}
          <ReactTabulator
            key={this.state.tableKey.toString()}
            onRef={(r) => (this.tableRef = r)}
            options={tableInfo.tableOptions}
            events={tableInfo.tableEvents}
          />
        </div>
      );

      let rightPane = (
        <div id="divEditorTop_ReportRowGroupsTab_RightPane" className={styles.divEditorTop_ReportRowGroupsTab_RightPane}>
          <ReportRowGroupsEdit
            reportName={this.props.reportName}
            rowGroupName={this.state.selectedName}
            selectedList={this.state.selectedList}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.props.updateNextSpec}
            insertRow={this.handleInsertRow}
            deleteRow={this.handleDeleteRow}
            deleteRows={this.handleDeleteRows}
            updateDirty={this.handleUpdateDirty}
          />
        </div>
      );

      content = (
        <div id="divEditorTop_ReportRowGroupsTab_Top" className={styles.divEditorTop_ReportRowGroupsTab_Top}>
          {/* {currentReportNameLabel} */}
          {/* <SplitPane split="vertical" defaultSize={"25%"}> */}
            {leftPane}
            <Divider orientation="vertical" />
            {rightPane}
          {/* </SplitPane> */}
        </div>
      );
    }

    return content;
  }

  handleResize = () => {
    let table = this.tableRef.current;
    try {
      if (table) {
        table.setHeight(this.getTableHeight());
      }

      let tablePaneRight = document.getElementById("divEditorTop_ReportRowGroupsTab_RightPane");

      if (tablePaneRight) {
        tablePaneRight.style.height = this.getTableHeight() - 20 + "px";
      }
    } catch (e) {
      console.log("Could not resize:", e)
    }
  }

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      let nextState = {};

      nextState.tableKey = prevState.tableKey + 1;

      if (!_.isNull(prevState.selectedName)) {
        if (!rf.existsReportRowGroupOption(this.props.nextSpec, this.props.reportName, prevState.selectedName)) {
          nextState.selectedName = null;
          nextState.selectedList = [];
        }
      }

      this.setState(nextState);
    }
  }

  componentWillUnmount() {
  }

  getTableHeight = () => {
    let tableHeight = 100;
    let windowHeight = document.documentElement.clientHeight


    let tablePaneLeft = document.getElementById("divEditorTop_ReportRowGroupsTab_LeftPane");
    if (tablePaneLeft == null) {
      return tableHeight;
    }

    let paneLeftRect = tablePaneLeft.getBoundingClientRect();
    let paneLeftTop = paneLeftRect.top;

    tableHeight = windowHeight - paneLeftTop;

    return tableHeight;
  }

  getTableInfo() {
    let r = {};

    r.tableColumns = [];

    // RowGroup Option Name Column
    r.tableColumns.push({
      title: "Option",
      field: "optionName",
      headerSort: false,
      headerFilter: true,
      visible: false,
    });

    // RowGroup Rule Name Column
    r.tableColumns.push({
      title: "Rule",
      field: "ruleName",
      headerFilter: funcs.customInput,
      headerFilterFunc: funcs.globFilter,
      headerTooltip: funcs.globFilterDisplayValueTooltip,
    });

    r.tableData = [];

    rf.gatherReportRowGroups(this.props.nextSpec, this.props.reportName).forEach((rowName) => {
      r.tableData.push({
        optionName: rowName.optionName,
        ruleName: rowName.ruleName,
        key: this.genKeyObj(rowName),
      });
    });

    r.tableOptions = {};
    r.tableOptions.columnDefaults = { headerFilterPlaceholder: funcs.headerFilterPlaceholderText() };
    r.tableOptions.columns = r.tableColumns;
    r.tableOptions.data = r.tableData;
    r.tableOptions.groupBy = ["optionName"];
    r.tableOptions.height = 100;
    r.tableOptions.index = "key";
    r.tableOptions.layout = "fitDataStretch";
    r.tableOptions.movableRows = true;
    r.tableOptions.selectablePersistence = true;
    r.tableOptions.selectableRangeMode = "click";
    r.tableOptions.selectable = true;

    r.tableEvents = {};
    r.tableEvents.rowMouseEnter = this.handleRowMouseEnter;
    r.tableEvents.rowMouseLeave = this.handleRowMouseLeave;
    r.tableEvents.rowSelectionChanged = this.handleRowSelectionChanged;
    r.tableEvents.tableBuilt = this.handleAfterTableBuilt;

    return r;
  }

  genKeyObj(obj) {
    return obj.optionName + "." + obj.ruleName;
  }

  genKeyObjs(array) {
    let keyArray = [];

    array.forEach((obj) => {
      keyArray.push(this.genKeyObj(obj));
    });

    return keyArray;
  }

  handleUpdateDirty = (dirty) => {
    this.dirty = dirty;
    this.props.updateDirty(SectionName, dirty);
  }

  handleInsertRow = (name, position = null) => {
    let table = this.tableRef.current;

    let rowData = {
      optionName: name.optionName,
      ruleName: name.ruleName,
      key: this.genKeyObj(name),
    };

    if (position) {
      table.addRow(rowData, false, position);
    } else {
      table.addRow(rowData, false);
    }

    let selectedList = [name];

    table.deselectRow();
    table.selectRow(this.genKeyObjs(selectedList));

    this.setState({
      selectedName: name,
      selectedList: selectedList,
    });

    this.handleResize();
  }

  handleDeleteRow = (name) => {
    let table = this.tableRef.current;

    table.deleteRow(this.genKeyObj(name));

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  }

  handleDeleteRows = (nameList) => {
    let table = this.tableRef.current;

    nameList.forEach((name) => {
      table.deleteRow(this.genKeyObj(name));
    });

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  }

  handleRowMouseEnter = (e, row) => {
    this.mouseOver = true;
  }

  handleRowMouseLeave = (e, row) => {
    this.mouseOver = false;
  }

  handleRowSelectionChanged = (row) => {

    if (this.ignoreRowSelection) return;

    if (!this.mouseOver && row.length == 0) return; // Ignore empty selections with not set by user.

    let table = this.tableRef.current;

    if (this.dirty) {
      this.ignoreRowSelection = true;
      table.deselectRow();
      table.selectRow(this.genKeyObjs(this.state.selectedList));
      rf.showApplyOrResetNotification(SectionName, SectionElement);
      this.ignoreRowSelection = false;
      return;
    }

    let selectedName = null;

    let selectedRows = table.getSelectedRows();

    if (selectedRows.length == 1) {
      let rowData = selectedRows[0].getData();

      selectedName = {
        optionName: rowData.optionName,
        ruleName: rowData.ruleName,
      };
    }

    let selectedList = [];

    selectedRows.forEach((r) => {
      let rowData = r.getData();

      selectedList.push({
        optionName: rowData.optionName,
        ruleName: rowData.ruleName,
      });
    });

    let nextState = {};

    if (!_.isEqual(selectedName, this.state.selectedName)
      || !_.isEqual(selectedList, this.state.selectedList)) {
      nextState.selectedName = selectedName;
      nextState.selectedList = selectedList;
    }

    this.setState(nextState);
  }

  handleAfterTableBuilt = () => {
    let table = this.tableRef.current;

    table.deselectRow();
    table.selectRow(this.genKeyObjs(this.state.selectedList));

    table.setHeight(this.getTableHeight());

    if (this.state.selectedList.length == 1) {
      table.scrollToRow(this.genKeyObj(this.state.selectedList[0]), "center", false);
    } else {
      table.rowManager.element.scrollTop = 0;
    }
  }
}

export default ReportRowGroupsTab;

////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
