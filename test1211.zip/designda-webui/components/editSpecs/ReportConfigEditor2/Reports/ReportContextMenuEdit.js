import {
  Box,
  ButtonGroup,
  FormControl,
  FormGroup,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import _ from "lodash";
import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";
import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";
import React, { useEffect, useRef, useState } from "react";

import styles from "./ReportContextMenuEdit.module.css";

const defaultContextMenu = Object.freeze({
  label: "",
  widgetId: "",
  action: "addWidget",
  tooltip: "",
});

class ReportContextMenu extends React.Component {
  state = {
    label: _.get(this.props.value, "label", ""),
    action: _.get(this.props.value, "action", "addWidget"),
    widgetId: _.get(this.props.value, "widgetId", ""),
    tooltip: _.get(this.props.value, "tooltip", ""),
    showEditForm: false,
  };

  handleContextMenuValueChange = (e, value) => {
    let nextState = _.cloneDeep(this.state);
    _.set(nextState, e.target.name, e.target.value);
    this.setState(nextState);
  };

  handleDeleteContextMenuButton = () => {
    this.props.deleteRow(this.gatherState().label);

    let nextSpec = rf.deleteReportContextMenu(
      this.props.nextSpec,
      this.props.reportName,
      this.props.index
    );

    this.props.updateNextSpec(nextSpec);
  };

  handleAddNewContextMenuButton = () => {
    if (this.isDirty()) {
      funcs.showNotification(
        "Report Context Menu Editor",
        "Apply or Reset the Menu being edited."
      );
    } else {
      this.props.handleNewContextMenu();
      this.setState(this.gatherState());
    }
  };

  handleResetButton = () => {
    this.setState(this.gatherState());

    this.props.updateDirty(false);
  };
  handleApplyButton = () => {
    let reportName = this.props.reportName;

    let nextSpec = _.cloneDeep(this.props.nextSpec);

    if (this.state.activeReportName !== this.props.reportName) {
    }

    nextSpec = rf.updateReportContextMenu(
      nextSpec,
      reportName,
      {
        label: this.state.label,
        action: this.state.action,
        widgetId: this.state.widgetId,
        tooltip: this.state.tooltip,
      },
      this.props.index
    );


    this.props.updateNextSpec(nextSpec);
    this.props.updateDirty(false);
  };

  gatherValue = () => {
    return rf.gatherReportContextMenuValues(
      this.props.nextSpec,
      this.props.reportName,
      defaultContextMenu,
      this.props.index
    );
  };

  handleResize = () => {
    let divInput = document.getElementById("divEditorTop_ConextMenuEdit_Input");
    let divButtons = document.getElementById(
      "divEditorTop_ConextMenuEdit_Buttons"
    );

    if (divInput == null || divButtons == null) {
      return;
    }

    const winHeight = document.documentElement.clientHeight;

    const rectInput = divInput.getBoundingClientRect();
    const rectButtons = divButtons.getBoundingClientRect();

    const newY = winHeight - rectButtons.height;

    const delta = newY - rectButtons.y;

    const newHeight = rectInput.height + delta - 5;

    divInput.style.height = newHeight + "px";
  };

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    this.handleResize();

    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      const reportChanged = prevProps.reportName !== this.props.reportName;
      const menuChanged = prevProps.index !== this.props.index;
      const valueChanged = !_.isEqual(prevState.value, this.gatherValue());

      if (reportChanged || menuChanged || valueChanged) {
        this.setState(this.gatherState());
      }
    }

    this.props.updateDirty(this.isDirty());
  }

  gatherState() {
    let contextMenuState = {};

    const value = this.gatherValue();

    const labelState = !_.isNull(value.label);
    const actionState = !_.isNull(value.action);
    const tooltipState = !_.isNull(value.tooltip);
    const widgetIdState = !_.isNull(value.widgetId);

    const label = labelState ? value.label : "";
    const action = actionState ? value.action : "";
    const widgetId = widgetIdState ? value.widgetId : "";
    const tooltip = tooltipState ? value.tooltip : "";

    contextMenuState.label = label;
    contextMenuState.action = action;
    contextMenuState.widgetId = widgetId;
    contextMenuState.tooltip = tooltip;

    return contextMenuState;
  }

  isDirty() {
    let state = this.gatherState();

    let clean =
      _.isEqual(state.label, this.state.label) &&
      _.isEqual(state.action, this.state.action) &&
      _.isEqual(state.widgetId, this.state.widgetId) &&
      _.isEqual(state.tooltip, this.state.tooltip);

    return !clean;
  }

  handleNewButton = () => {
    this.props.handleNewContextMenu();
    this.setState({
      showEditForm: true,
      ...defaultContextMenu,
    });
  };

  handleDeleteSelectedButton = () => {
    this.props.deleteRows(this.props.selectedList);

    let nextSpec = rf.deleteReportContextMenu(
      this.props.nextSpec,
      this.props.reportName,
      this.props.selectedList
    );

    this.props.updateNextSpec(nextSpec);
  };

  render() {
    if (this.props.index == null) {
      if (this.props.selectedList.length == 0) {
        return (
          <div style={{ height: "100%" }}>
            <h3>Getting Started</h3>
            <ul>
              <li>
                {
                  <ThemedButton
                    text="New Context Menu"
                    onClick={this.handleNewButton}
                  />
                }
              </li>
              <li>or select a single context menu on the left to edit</li>
              <li>or select a group of context menus to delete</li>
            </ul>
          </div>
        );
      } else {
        return (
          <ThemedButton
            text="Delete Selected"
            type="alert"
            onClick={this.handleDeleteSelectedButton}
          />
        );
      }
    } else {
      const currentReportNameLabel = (
        <div
          id="divEditorTop_ContextMenu_Label"
          className={styles.divEditorTop_ContextMenu_Label}
        >
          {_.get(this.props.value, "label", "")}
        </div>
      );
      return (
        <Box className={styles.divEditorTop_ContextMenu_Top}>
          {/* {currentReportNameLabel} */}
          <div
            id="divEditorTop_ContextMenu_Input"
            className={styles.divEditorTop_ContextMenu_Input}
          >
            <FormGroup sx={{ padding: "5px 0px" }}>
              <FormControl>
                <TextField
                  label={"Label"}
                  value={this.state.label}
                  name={"label"}
                  variant="filled"
                  onChange={this.handleContextMenuValueChange}
                />
              </FormControl>
              <FormControl variant="filled">
                <InputLabel>Action</InputLabel>
                <Select
                  name="action"
                  variant="filled"
                  value={this.state.action}
                  onChange={this.handleContextMenuValueChange}
                >
                  {[
                    {
                      title: "Add widget",
                      value: "addWidget",
                      key: "addWidget",
                    },
                  ].map((item, index) => (
                    <MenuItem key={item.key} value={item.value}>
                      {item.title}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl>
                <TextField
                  label={"Widget Id"}
                  name={"widgetId"}
                  variant="filled"
                  onChange={this.handleContextMenuValueChange}
                  value={this.state.widgetId}
                />
              </FormControl>
              <FormControl>
                <TextField
                  label={"How to use"}
                  name={"tooltip"}
                  variant="filled"
                  onChange={this.handleContextMenuValueChange}
                  value={this.state.tooltip}
                />
              </FormControl>
            </FormGroup>
          </div>

          <div
            id="divEditorTop_ContextMenu_Buttons"
            className={styles.divEditorTop_ContextMenu_Buttons}
          >
            <div
              id="divEditorTop_ContextMenu_JustifyLeft"
              className={styles.divEditorTop_ContextMenu_JustifyLeft}
            >
              <ButtonGroup>
                <ThemedButton
                  text="Delete Menu"
                  type="alert"
                  onClick={this.handleDeleteContextMenuButton}
                />
                <ThemedButton
                  text="Add New Menu"
                  type="info"
                  onClick={this.handleAddNewContextMenuButton}
                />
              </ButtonGroup>
            </div>
            <div
              id="divEditorTop_ContextMenu_JustifyRight"
              className={styles.divEditorTop_ContextMenu_JustifyRight}
            >
              <ButtonGroup>
                <ThemedButton text="Apply" onClick={this.handleApplyButton} />
                <ThemedButton
                  text="Reset"
                  type="alert"
                  onClick={this.handleResetButton}
                />
              </ButtonGroup>
            </div>
          </div>
        </Box>
      );
    }
  }
}

export default ReportContextMenu;
