import { Box, Divider } from "@mui/material";
import React from "react";
import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";
import { ReactTabulator } from "react-tabulator";
import _ from "lodash";
import ReportContextMenu from "./ReportContextMenuEdit";
import styles from "./ReportContextMenuTab.module.css";

const SectionName = "Context menu";
const SectionElement = "contextMenu";

class ReportContextMenuTab extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      contextMenuIndex: null,
      selectedName: null,
      selectedList: [],
      tableKey: 0,
    };
    this.tableRef = React.createRef();
  }

  getTableInfo() {
    let r = {};

    r.tableColumns = [];

    // Row Move Handle Column
    r.tableColumns.push({
      rowHandle: true,
      formatter: "handle",
      headerSort: false,
      frozen: true,
      width: 30,
      minWidth: 30,
    });

    // Comtext Menu Column
    r.tableColumns.push({
      title: "Context Menu",
      field: "contextMenu",
      headerFilter: funcs.customInput,
      headerFilterFunc: funcs.globFilter,
      headerTooltip: funcs.globFilterDisplayValueTooltip,
    });

    r.tableColumns.push({
      title: "Context Menu Data",
      field: "contextMenuData",
      visible: false,
    });

    r.tableData = [];

    rf.gatherContextMenu(this.props.nextSpec, this.props.reportName).forEach(
      (menu) => {
        r.tableData.push({
          contextMenu: _.get(menu, "label", ""),
          contextMenuData: menu,
        });
      }
    );

    r.tableOptions = {};
    r.tableOptions.columnDefaults = {
      headerFilterPlaceholder: funcs.headerFilterPlaceholderText(),
    };
    r.tableOptions.columns = r.tableColumns;
    r.tableOptions.data = r.tableData;
    r.tableOptions.height = 100;
    r.tableOptions.index = "label";
    r.tableOptions.layout = "fitDataStretch";
    r.tableOptions.movableRows = true;
    r.tableOptions.selectablePersistence = true;
    r.tableOptions.selectableRangeMode = "click";
    r.tableOptions.selectable = true;

    r.tableEvents = {};
    r.tableEvents.rowMouseEnter = this.handleRowMouseEnter;
    r.tableEvents.rowMouseLeave = this.handleRowMouseLeave;
    r.tableEvents.rowSelectionChanged = this.handleRowSelectionChanged;
    r.tableEvents.rowMoved = this.handleRowMoved;
    r.tableEvents.tableBuilt = this.handleAfterTableBuilt;

    return r;
  }

  handleResize = () => {
    let table = this.tableRef.current;
    try {
      if (table) {
        table.setHeight(this.getTableHeight());
      }

      let tablePaneRight = document.getElementById(
        "div_ReportContextMenuTab_RightPane"
      );

      if (tablePaneRight) {
        tablePaneRight.style.height = this.getTableHeight() - 20 + "px";
      }
    } catch (e) {
      console.log("Could not resize:", e);
    }
  };

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      let nextState = {};

      nextState.tableKey = prevState.tableKey + 1;

      if (!_.isNull(prevState.selectedName)) {
        if (
          !rf.existsReportMetric(
            this.props.nextSpec,
            this.props.reportName,
            prevState.selectedName
          )
        ) {
          nextState.selectedName = null;
          nextState.selectedList = [];
        }
      }

      this.setState(nextState);
    }

    this.handleResize();
  }

  handleRowMoved = (row) => {
    let table = this.tableRef.current;

    let newOrder = [];

    table.getData().forEach(function (r) {
      newOrder.push(r.contextMenuData);
    });

    const origOrder = rf.gatherReportContextMenu(
      this.props.nextSpec,
      this.props.reportName
    );

    if (_.isEqual(origOrder, newOrder)) return;

    const nextSpec = rf.reorderReportContextMenu(
      this.props.nextSpec,
      this.props.reportName,
      newOrder
    );

    this.props.updateNextSpec(nextSpec);
  };

  handleRowMouseEnter = (e, row) => {
    this.mouseOver = true;
  };

  handleRowMouseLeave = (e, row) => {
    this.mouseOver = false;
  };

  handleRowSelectionChanged = (row) => {
    if (this.ignoreRowSelection) return;

    if (!this.mouseOver && row.length == 0) return; // Ignore empty selections with not set by user.

    let table = this.tableRef.current;

    if (this.dirty) {
      this.ignoreRowSelection = true;
      table.deselectRow();
      table.selectRow(this.state.selectedList);
      rf.showApplyOrResetNotification(SectionName, SectionElement);
      this.ignoreRowSelection = false;
      return;
    }

    let selectedName = null;

    let selectedRows = table.getSelectedRows();

    if (selectedRows.length == 1) {
      selectedName = selectedRows[0].getData().label;
      this.setState({
        contextMenuIndex:
          this.tableRef.current.getRowPosition(selectedRows[0]) - 1,
      });
    }

    let selectedList = [];

    selectedRows.forEach((r) => {
      selectedList.push(r.getData().label);
    });

    let nextState = {};

    if (
      !_.isEqual(selectedName, this.state.selectedName) ||
      !_.isEqual(selectedList, this.state.selectedList)
    ) {
      nextState.selectedName = selectedName;
      nextState.selectedList = selectedList;
    }

    this.setState(nextState);
  };

  getTableHeight = () => {
    let tableHeight = 100;
    let windowHeight = document.documentElement.clientHeight;

    let tablePaneLeft = document.getElementById(
      "div_ReportContextMenuTab_LeftPane"
    );
    if (tablePaneLeft == null) {
      return tableHeight;
    }

    let paneLeftRect = tablePaneLeft.getBoundingClientRect();
    let paneLeftTop = paneLeftRect.top;

    tableHeight = windowHeight - paneLeftTop;

    return tableHeight;
  };

  handleAfterTableBuilt = () => {
    let table = this.tableRef.current;

    table.deselectRow();
    table.selectRow(this.state.selectedList);

    table.setHeight(this.getTableHeight());

    if (this.state.selectedList.length == 1) {
      table.scrollToRow(this.state.selectedList[0], "center", false);
    } else {
      table.rowManager.element.scrollTop = 0;
    }
  };

  handleUpdateDirty = (dirty) => {
    this.dirty = dirty;
    this.props.updateDirty("contextMenu", dirty);
  };

  handleInsertRow = (label, position = null) => {
    let table = this.tableRef.current;

    let rowData = { label: label };

    if (position) {
      table.addRow(rowData, false, position);
    } else {
      table.addRow(rowData, false, true);
    }

    table.deselectRow();
    table.selectRow([label]);

    let selectedList = [label];

    this.setState({
      selectedName: label,
      selectedList: selectedList,
    });

    this.handleResize();
  };

  handleDeleteRow = (label) => {
    let table = this.tableRef.current;

    table.deleteRow(label);

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  };

  handleDeleteRows = (nameList) => {
    let table = this.tableRef.current;

    nameList.forEach((label) => {
      table.deleteRow(label);
    });

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  };

  handleNewContextMenu = () => {
    this.setState({ contextMenuIndex: this.tableRef.current.getData().length });
  };

  render() {
    let tableInfo = this.getTableInfo();

    let leftPane = (
      <div
        id="div_ReportContextMenuTab_LeftPane"
        className={styles.div_ReportContextMenuTab_LeftPane}
        style={{ float: "left", height: "100%" }}
      >
        <div
          id="div_ReportContextMenuTab_Label"
          className={styles.div_ReportContextMenuTab_Label}
        >
          {this.props.reportName}
        </div>
        <ReactTabulator
          key={this.state.tableKey.toString()}
          onRef={(r) => (this.tableRef = r)}
          options={tableInfo.tableOptions}
          events={tableInfo.tableEvents}
        />
      </div>
    );

    let rightPane = (
      <div
        id="div_ReportContextMenuTab_RightPane"
        className={styles.div_ReportContextMenuTab_RightPane}
      >
        <ReportContextMenu
          index={this.state.contextMenuIndex}
          reportName={this.props.reportName}
          selectedList={this.state.selectedList}
          editSpec={this.props.editSpec}
          nextSpec={this.props.nextSpec}
          updateNextSpec={this.props.updateNextSpec}
          handleNewContextMenu={this.handleNewContextMenu}
          insertRow={this.handleInsertRow}
          deleteRow={this.handleDeleteRow}
          deleteRows={this.handleDeleteRows}
          updateDirty={this.handleUpdateDirty}
        />
      </div>
    );

    let content = (
      <div
        id="div_ReportContextMenuTab_Top"
        className={styles.div_ReportContextMenuTab_Top}
      >
        {/* {currentReportNameLabel} */}
        {/* <SplitPane split="vertical" defaultSize={"25%"}> */}
        {leftPane}
        <Divider orientation="vertical" />
        {rightPane}
        {/* </SplitPane> */}
      </div>
    );

    return content;
  }
}

export default ReportContextMenuTab;
