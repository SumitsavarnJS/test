////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportsNewReportDialog.js#6 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/12 13:57:36 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
// //import Modal from "react-bootstrap/Modal";

import {
  ButtonGroup,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Modal,
  Box,
} from "@mui/material";

import _ from "lodash";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import styles from "./ReportsNewReportDialog.module.css";

class ReportsNewReportDialog extends React.Component {
  constructor(props) {
    super(props);

    /*!
     *  Properties:
     *    show           : boolean  - Show/Hide this dialog
     *    suggestedName  : string   - Name to use to pre-fill report name.  (Could be null)
     *    suggestedClass : string   - Name to use to pre-fill report class.  (Could be null)
     *    validNameList  : array    - List of names already in use
     *    validClassList : array    - List of classes {key:<int>, value:<str>, title:<str>}
     *    submitAnswer   : function - Called to return user response. Closes dialog.
     */

    const state = this.gatherState();

    this.state = {
      reportName: state.reportName,
      reportClass: state.reportClass,
      errorState: state.errorState,
      errorText: state.errorText,
    };
  }

  boxStyle = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "auto",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    borderRadius: "15px",
    p: 4,
  };

  render() {
    const reportClassMenuItems = this.props.validClassList.map((item) => (
      <MenuItem key={item.key} value={item.value}>
        {item.title}
      </MenuItem>
    ));

    let reportClassInput = (
      <FormControl variant="filled" fullWidth={true}>
        <InputLabel>Report Class</InputLabel>
        <Select
          name="reportClass"
          value={this.state.reportClass}
          onChange={this.handleClassChanged}
        >
          {reportClassMenuItems}
        </Select>
      </FormControl>
    );

    let reportNameInput = (
      <TextField
        label="Report Name"
        name="reportName"
        fullWidth={true}
        variant="filled"
        value={this.state.reportName}
        onChange={this.handleNameChanged}
        error={this.state.errorState}
        helperText={this.state.errorText}
      />
    );

    let content = (
      <Modal open={this.props.show}>
        <Box sx={this.boxStyle}>
          <Box id="ModalHeader" className={styles.ModalHeader}>
            <h2>Enter name and class of new report</h2>
          </Box>

          <Box>
            <div
              id="divEditorTop_NewReportDialog_Input"
              className={styles.divEditorTop_NewReportDialog_Input}
            >
              {reportClassInput}
              {reportNameInput}
            </div>
          </Box>

          <Box>
            <div
              id="divEditorTop_NewReportDialog_Buttons"
              className={styles.divEditorTop_NewReportDialog_Buttons}
            >
              <ButtonGroup>
                <ThemedButton
                  text="Accept"
                  onClick={this.handleAcceptButton}
                  disabled={this.state.errorState}
                />
                <ThemedButton
                  text="Cancel"
                  type="cancel"
                  onClick={this.handleCancelButton}
                />
              </ButtonGroup>
            </div>
          </Box>
        </Box>
      </Modal>
    );

    return content;
  }

  handleResize = () => {};

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    this.handleResize();

    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      if (
        !_.isEqual(this.props.suggestedName, prevProps.suggestedName) ||
        !_.isEqual(this.props.suggestedClass, prevProps.suggestedClass) ||
        !_.isEqual(this.props.validNameList, prevProps.validNameList) ||
        !_.isEqual(this.props.validClassList, prevProps.validClassList)
      ) {
        this.setState(this.gatherState());
      }
    }
  }

  componentWillUnmount() {}

  gatherState() {
    let state = {};

    state.reportClass = this.props.suggestedClass
      ? this.props.suggestedClass
      : this.props.validClassList[0].value;

    state.reportName = this.props.suggestedName ? this.props.suggestedName : "";

    [state.errorState, state.errorText] = this.checkValidName(state.reportName);

    return state;
  }

  checkValidName(name) {
    let errorState = false;
    let errorText = "Ok";

    if (name.length == 0) {
      errorState = true;
      errorText = "Value cannot be blank";
    } else {
      if (this.props.validNameList.includes(name)) {
        errorState = true;
        errorText = "Report already exists";
      }
    }

    return [errorState, errorText];
  }

  handleClassChanged = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };

  handleNameChanged = (e) => {
    let nextState = {};

    nextState.reportName = e.target.value;

    [nextState.errorState, nextState.errorText] = this.checkValidName(
      nextState.reportName
    );

    this.setState(nextState);
  };

  handleCancelButton = () => {
    this.props.submitAnswer(false, {});

    this.setState({
      reportName: null,
      reportClass: null,
    });
  };

  handleAcceptButton = () => {
    if (this.state.errorState === false) {
      this.props.submitAnswer(true, {
        reportName: this.state.reportName,
        reportClass: this.state.reportClass,
      });
    }

    this.setState({
      reportName: null,
      reportClass: null,
    });
  };
}

export default ReportsNewReportDialog;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
