////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportsNewDialog.js#7 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/12 13:57:36 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
//import Modal from "react-bootstrap/Modal";

import { ButtonGroup, TextField, Modal, Box } from "@mui/material";

import _ from "lodash";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import "./ReportsNewDialog.module.css";

class ReportsNewDialog extends React.Component {
  constructor(props) {
    super(props);

    /*!
     *  Props:
     *    show          :
     *    title         :
     *    itemLabel     :
     *    suggestedName :
     *    validItemList :
     *    submitAnswer  :
     */

    const state = this.gatherState();

    this.state = {
      itemName: state.itemName,
      errorState: state.errorState,
      errorText: state.errorText,
    };
  }

  render() {
    let boxStyle = {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "auto",
      bgcolor: "background.paper",
      border: "2px solid #000",
      boxShadow: 24,
      borderRadius: "15px",
      p: 4,
    };
    let content = (
      <Modal open={this.props.show}>
        <Box sx={boxStyle}>
          <Box id="ModalHeader">
            <h2>{this.props.title}</h2>
          </Box>

          <Box>
            <TextField
              label={this.props.itemLabel}
              fullWidth={true}
              variant="filled"
              value={this.state.itemName}
              onChange={this.handleValueChanged}
              error={this.state.errorState}
              helperText={this.state.errorText}
            />
          </Box>

          <Box>
            <ButtonGroup>
              <ThemedButton
                text="Accept"
                onClick={this.handleAcceptButton}
                disabled={this.state.errorState}
              />
              <ThemedButton
                text="Cancel"
                type="cancel"
                onClick={this.handleCancelButton}
              />
            </ButtonGroup>
          </Box>
        </Box>
      </Modal>
    );

    return content;
  }

  handleResize = () => {};

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    this.handleResize();

    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      if (
        !_.isEqual(this.props.title, prevProps.title) ||
        !_.isEqual(this.props.itemLabel, prevProps.itemLabel) ||
        !_.isEqual(this.props.suggestedName, prevProps.suggestedName) ||
        !_.isEqual(this.props.validItemList, prevProps.validItemList)
      ) {
        this.setState(this.gatherState());
      }
    }
  }

  componentWillUnmount() {}

  gatherState() {
    let state = {};

    state.itemName = this.props.suggestedName ? this.props.suggestedName : "";

    [state.errorState, state.errorText] = this.checkItemName(state.itemName);

    return state;
  }

  checkItemName(itemName) {
    let errorState = false;
    let errorText = "Ok";

    if (!itemName || (itemName && itemName.length == 0)) {
      errorState = true;
      errorText = "Value cannot be blank";
    } else if (this.props.validItemList.includes(itemName)) {
      errorState = true;
      errorText = itemName + " already exists!";
    }

    return [errorState, errorText];
  }

  handleValueChanged = (e) => {
    let nextState = {};

    nextState.itemName = e.target.value;

    [nextState.errorState, nextState.errorText] = this.checkItemName(
      nextState.itemName
    );

    this.setState(nextState);
  };

  handleCancelButton = () => {
    this.props.submitAnswer(false, "");
  };

  handleAcceptButton = () => {
    if (this.state.errorState == false) {
      this.props.submitAnswer(true, this.state.itemName);
    }
  };
}

export default ReportsNewDialog;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
