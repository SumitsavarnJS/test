////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportGeneralTab.js#14 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/10 07:05:18 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";

import {
  Button,
  ButtonGroup,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField
} from "@mui/material";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import ReportsNewReportDialog from "components/editSpecs/ReportConfigEditor2/Reports/ReportsNewReportDialog";

import styles from "./ReportGeneralTab.module.css";

const defaultReportInfo = Object.freeze({
  menuGroup: "",
  menuName: "",
  reportClass: "BuildsDashboardReport",
  docType: "",
  tableName: "",
});

class ReportGeneralTab extends React.Component {
  constructor(props) {
    super(props);

    /**
     * Props:
     *   reportName       : [String]   - Name of the currently selected report
     *   editSpec         : [Object]   - Object containing the original unedited data
     *   nextSpec         : [Object]   - Object containing the currently edited data
     *   updateNextSpec   : [Function] - Command to update data
     *   insertReport     : [Function] - Command to insert new report
     *   deleteReport     : [Function] - Command to delete a report
     *   changeReportName : [Function] - Command to change the report's name
     */

    const state = this.gatherState();

    this.state = {
      activeReportName: state.activeReportName,

      value: state.value,

      showDialog: false,
      modeDialog: null,
    };
  }

  render() {
    let content = null;

    if ( this.props.reportName == null ) {
      content = ( <div>Please select a report on the left</div> );
    } else {
      let buttonGroupLeft = (
        <ButtonGroup>
          <ThemedButton text="Insert Report" onClick={this.handleInsertReportButton} />
          <ThemedButton text="Copy Report" onClick={this.handleCopyReportButton} />
          <ThemedButton text="Delete Report" type="alert" onClick={this.handleDeleteReportButton} />
        </ButtonGroup>
      );

      let buttonGroupRight = (
        <ButtonGroup>
          <ThemedButton text="Apply" onClick={this.handleApplyButton} />
          <ThemedButton text="Reset" type="alert" onClick={this.handleResetButton} />
        </ButtonGroup>
      );

      let currentReportNameLabel = (
        <div id="divEditorTop_ReportGeneralTab_Label" className={styles.divEditorTop_ReportGeneralTab_Label}>{this.props.reportName}</div>
      );

      let reportNameInput = (
        <TextField
          label="Report Name"
          variant="filled"
          fullWidth={true}
          name="activeReportName"
          value={this.state.activeReportName}
          onChange={this.handleReportValueChange}
          InputProps={{readOnly:false}}
        />
      );

      let menuNameInput = (
        <TextField
          label="Menu Name"
          variant="filled"
          fullWidth={true}
          name="value.menuName"
          value={this.state.value.menuName}
          onChange={this.handleReportValueChange}
        />
      );

      let menuGroupInput = (
        <TextField
          label="Menu Group"
          variant="filled"
          fullWidth={true}
          name="value.menuGroup"
          value={this.state.value.menuGroup}
          onChange={this.handleReportValueChange}
        />
      );

      let reportClassInput = (
        <div id="divEditorTop_ReportGeneralTab_ReadOnly" className={styles.divEditorTop_ReportGeneralTab_ReadOnly}>
          <TextField
            label="Report Class"
            variant="filled"
            fullWidth={true}
            value={_.get(rf.reportDefinitionTable,[this.state.value.reportClass,'title'])}
            name="value.reportClass"
            onChange={this.handleReportValueChange}
            InputProps={{readOnly:true}}
          />
        </div>
      );

      const docTypeMenuItems = rf.reportSelectListTable.docTypeList.map((item) =>
        <MenuItem key={item.key} value={item.value}>{item.title}</MenuItem>
      );

      let docTypeInput = ( rf.gatherReportDefinition( this.props.nextSpec, this.props.reportName, 'hasDocType' )
        ? (
            <FormControl
              variant="filled"
              fullWidth={true}
            >
              <InputLabel>Doc Type</InputLabel>
              <Select
                name="value.docType"
                value={this.state.value.docType}
                onChange={this.handleReportValueChange}
              >
                {docTypeMenuItems }
              </Select>
            </FormControl>
          )
        : null
      );

      let tableNameInput = ( rf.gatherReportDefinition( this.props.nextSpec, this.props.reportName, 'hasTableName' )
        ? (
            <TextField
              label="Table Name"
              variant="filled"
              fullWidth={true}
              name="value.tableName"
              value={this.state.value.tableName}
              onChange={this.handleReportValueChange}
            />
          )
        : null
      );

      let newReportDialog = (
        <ReportsNewReportDialog
          show={this.state.showDialog}
          suggestedName={this.state.modeDialog==='Copy'  ? this.state.activeReportName : null}
          suggestedClass={this.state.value.reportClass}
          validNameList={rf.gatherReportNames( this.props.nextSpec )}
          validClassList={rf.gatherReportClasses()}
          submitAnswer={this.handleNewReportSubmitAnswer}
        />
      );

      content = (
        <div id="divEditorTop_ReportGeneralTab_Top" className={styles.divEditorTop_ReportGeneralTab_Top}>
          {currentReportNameLabel}

          <div id="divEditorTop_ReportGeneralTab_Input" className={styles.divEditorTop_ReportGeneralTab_Input}>
            {reportClassInput}
            {reportNameInput}
            {menuNameInput}
            {menuGroupInput}
            {docTypeInput}
            {tableNameInput}
          </div>

          <div id="divEditorTop_ReportGeneralTab_Buttons" className={styles.divEditorTop_ReportGeneralTab_Buttons}>
            <div id="divEditorTop_ReportGeneralTab_JustifyLeft" className={styles.divEditorTop_ReportGeneralTab_JustifyLeft}>
              {buttonGroupLeft}
            </div>
            <div id="divEditorTop_ReportGeneralTab_JustifyRight" className={styles.divEditorTop_ReportGeneralTab_JustifyRight}>
              {buttonGroupRight}
            </div>
          </div>

          {newReportDialog}
        </div>
      );
    }

    return content;
  }

  handleResize = () => {
    let divInput   = document.getElementById( "divEditorTop_ReportGeneralTab_Input" );
    let divButtons = document.getElementById( "divEditorTop_ReportGeneralTab_Buttons" );

    if ( divInput == null || divButtons == null ) {
      return
    }

    const winHeight = document.documentElement.clientHeight;

    const rectInput   = divInput.getBoundingClientRect();
    const rectButtons = divButtons.getBoundingClientRect();

    const newY = winHeight - rectButtons.height;

    const delta = newY - rectButtons.y;

    const newHeight = rectInput.height + delta - 5;

    divInput.style.height = newHeight + "px";
  }

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate( prevProps, prevState ) {
    this.handleResize();

    const isOutsideChange = !_.isEqual( prevProps, this.props );

    if ( isOutsideChange ) {
      const reportChanged    = ( prevProps.reportName !== this.props.reportName );
      const valueChanged     = !_.isEqual( prevState.value, this.gatherValue() );

      if ( reportChanged || valueChanged ) {
        this.setState( this.gatherState() );
      }
    }

    this.props.updateDirty( 'General', this.isDirty() );
  }

  componentWillUnmount() {
  }

  gatherState() {
    let state = {};

    state.value = this.gatherValue();

    state.activeReportName = this.props.reportName;

    return state;
  }

  gatherValue() {
    return rf.gatherReportInfo( this.props.nextSpec, this.props.reportName, defaultReportInfo )
  }

  isDirty() {
    let state = this.gatherState();

    let clean = (    _.isEqual( state.value, this.state.value )
                  && _.isEqual( state.activeReportName, this.state.activeReportName ) );

    return !clean;
  }

  handleReportValueChange = (e) => {
    let nextState = {
      value: _.cloneDeep( this.state.value )
    };

    _.set( nextState, e.target.name, e.target.value );

    this.setState( nextState );
  }

  handleInsertReportButton = () => {
    if ( this.props.isReportDirty() ) {
      this.props.showReportDirtyNotification();
    } else {
      this.setState({
        showDialog: true,
        modeDialog: 'Insert',
      });
    }
  }

  handleCopyReportButton = () => {
    if ( this.props.isReportDirty() ) {
      this.props.showReportDirtyNotification();
    } else {
      this.setState({
        showDialog: true,
        modeDialog: 'Copy',
      });
    }
  }

  handleDeleteReportButton = () => {
    this.props.deleteReport( this.props.reportName );

    let nextSpec = rf.deleteReport( this.props.nextSpec, this.props.reportName );

    this.props.updateNextSpec( nextSpec );
  }

  handleNewReportSubmitAnswer = ( accept, data ) => {
    let nextSpec = null;

    if ( accept ) {
      let newReportName  = data.reportName;
      let newReportClass = data.reportClass;

      switch ( this.state.modeDialog ) {
        case 'Insert':
          nextSpec = rf.insertReport( this.props.nextSpec,
                                      newReportName,
                                      rf.defaultReportData( newReportClass ),
                                      this.props.reportName,
                                      "after" );
          this.props.insertReport( newReportName, this.props.reportName );
          break;

        case 'Copy':
          let newReportData = rf.gatherReport( this.props.nextSpec, this.props.reportName );

          nextSpec = rf.insertReport( this.props.nextSpec,
                                      newReportName,
                                      newReportData,
                                      this.props.reportName,
                                      "after" );
          this.props.insertReport( newReportName, this.props.reportName );
          break;

        default:
          break;
      }

      if ( nextSpec ) this.props.updateNextSpec( nextSpec );
    }

    this.setState({
      showDialog: false,
      modeDialog: null,
    });
  }

  handleApplyButton = () => {
    let value = this.state.value;

    let reportName = this.props.reportName;

    let nextSpec = _.cloneDeep( this.props.nextSpec );

    if ( this.state.activeReportName !== this.props.reportName ) {
      nextSpec = rf.renameReport( nextSpec, this.props.reportName, this.state.activeReportName );

      reportName = this.state.activeReportName;

      this.props.changeReportName( this.props.reportName, reportName );
    }

    nextSpec = rf.updateReportInfo( nextSpec, reportName, value );

    this.props.updateNextSpec( nextSpec );
  }

  handleResetButton = () => {
    this.setState( this.gatherState() );
  }
}

export default ReportGeneralTab;

////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
