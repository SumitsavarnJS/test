////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportsNewRowGroupDialog.js#8 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/12 13:57:36 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
//import Modal from "react-bootstrap/Modal";

import { ButtonGroup, TextField, Modal, Box } from "@mui/material";

import _ from "lodash";

import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import "./ReportsNewRowGroupDialog.module.css";

class ReportsNewRowGroupDialog extends React.Component {
  constructor(props) {
    super(props);

    const state = this.gatherState();

    this.state = {
      optionName: state.optionName,
      optionNameErrorState: state.optionNameErrorState,
      optionNameErrorText: state.optionNameErrorText,

      ruleName: state.ruleName,
      ruleNameErrorState: state.ruleNameErrorState,
      ruleNameErrorText: state.ruleNameErrorText,
    };
  }

  render() {
    let boxStyle = {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "auto",
      bgcolor: "background.paper",
      border: "2px solid #000",
      boxShadow: 24,
      borderRadius: "15px",
      p: 4,
    };
    let content = (
      <Modal open={this.props.show}>
        <Box sx={boxStyle}>
          <Box id="ModalHeader">
            <h2>Enter Row Group</h2>
          </Box>

          <Box>
            <TextField
              label="Option Name"
              fullWidth={true}
              variant="filled"
              name="optionName"
              value={this.state.optionName}
              onChange={this.handleOptionNameChanged}
              error={this.state.optionNameErrorState}
              helperText={this.state.optionNameErrorText}
            />
            <TextField
              label="Rule Name"
              fullWidth={true}
              variant="filled"
              name="ruleName"
              value={this.state.ruleName}
              onChange={this.handleRuleNameChanged}
              error={this.state.ruleNameErrorState}
              helperText={this.state.ruleNameErrorText}
            />
          </Box>

          <Box>
            <ButtonGroup>
              <ThemedButton
                text="Accept"
                onClick={this.handleAcceptButton}
                disabled={
                  this.state.optionNameErrorState ||
                  this.state.ruleNameErrorState
                }
              />
              <ThemedButton
                text="Cancel"
                type="cancel"
                onClick={this.handleCancelButton}
              />
            </ButtonGroup>
          </Box>
        </Box>
      </Modal>
    );

    return content;
  }

  handleResize = () => {};

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    this.handleResize();

    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      if (
        !_.isEqual(this.props.rowGroupName, prevProps.rowGroupName) ||
        !_.isEqual(this.props.dialogMode, prevProps.dialogMode) ||
        !_.isEqual(this.props.reportName, prevProps.reportName)
      ) {
        this.setState(this.gatherState());
      }
    }
  }

  componentWillUnmount() {}

  gatherState() {
    let state = {};

    if (this.props.dialogMode == "Insert") {
      state.optionName = this.props.rowGroupName
        ? this.props.rowGroupName.optionName
        : "";

      [state.optionNameErrorState, state.optionNameErrorText] =
        this.checkOptionName(state.optionName);

      state.ruleName = "";

      [state.ruleNameErrorState, state.ruleNameErrorText] = this.checkRuleName(
        state.ruleName,
        state.optionName
      );
    } else if (this.props.dialogMode == "Copy") {
      state.optionName = this.props.rowGroupName
        ? this.props.rowGroupName.optionName
        : "";

      [state.optionNameErrorState, state.optionNameErrorText] =
        this.checkOptionName(state.optionName);

      state.ruleName = this.props.rowGroupName
        ? this.props.rowGroupName.ruleName
        : "";

      [state.ruleNameErrorState, state.ruleNameErrorText] = this.checkRuleName(
        state.ruleName,
        state.optionName
      );
    } else if (this.props.dialogMode == "New") {
      state.optionName = "";

      [state.optionNameErrorState, state.optionNameErrorText] =
        this.checkOptionName(state.optionName);

      state.ruleName = "";

      [state.ruleNameErrorState, state.ruleNameErrorText] = this.checkRuleName(
        state.ruleName,
        state.optionName
      );
    }

    return state;
  }

  checkOptionName(optionName) {
    let errorState = false;
    let errorText = "Ok";

    if (optionName.length == 0) {
      errorState = true;
      errorText = "Value cannot be blank";
    }

    return [errorState, errorText];
  }

  checkRuleName(ruleName, optionName) {
    let errorState = false;
    let errorText = "Ok";

    if (ruleName.length == 0) {
      errorState = true;
      errorText = "Value cannot be blank";
    } else {
      if (optionName.length > 0) {
        if (
          rf.existsReportRowGroupOptionName(
            this.props.nextSpec,
            this.props.reportName,
            optionName
          )
        ) {
          if (
            rf.existsReportRowGroupOptionRule(
              this.props.nextSpec,
              this.props.reportName,
              optionName,
              ruleName
            )
          ) {
            errorState = true;
            errorText = "Rule name already exists!";
          }
        }
      }
    }

    return [errorState, errorText];
  }

  handleOptionNameChanged = (e) => {
    let nextState = {};

    nextState.optionName = e.target.value;

    [nextState.optionNameErrorState, nextState.optionNameErrorText] =
      this.checkOptionName(nextState.optionName);

    [nextState.ruleNameErrorState, nextState.ruleNameErrorText] =
      this.checkRuleName(
        this.state.ruleName,
        this.props.nextSpec,
        this.props.reportName,
        nextState.optionName
      );

    this.setState(nextState);
  };

  handleRuleNameChanged = (e) => {
    let nextState = {};

    nextState.ruleName = e.target.value;

    [nextState.ruleNameErrorState, nextState.ruleNameErrorText] =
      this.checkRuleName(
        nextState.ruleName,
        this.props.nextSpec,
        this.props.reportName,
        this.state.optionName
      );
    this.setState(nextState);
  };

  handleCancelButton = () => {
    this.props.submitAnswer(false, {});
  };

  okToAccept() {
    return !this.state.optionNameErrorState && !this.state.ruleNameErrorState;
  }

  handleAcceptButton = () => {
    if (this.okToAccept()) {
      this.props.submitAnswer(true, {
        optionName: this.state.optionName,
        ruleName: this.state.ruleName,
      });
    }
  };
}

export default ReportsNewRowGroupDialog;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
