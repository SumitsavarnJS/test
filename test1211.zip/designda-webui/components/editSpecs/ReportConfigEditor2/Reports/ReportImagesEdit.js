////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportImagesEdit.js#10 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/10 07:05:18 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";

import {
  ButtonGroup,
  FilledInput,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
} from "@mui/material";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import ReportsNewDialog from "components/editSpecs/ReportConfigEditor2/Reports/ReportsNewDialog";

import styles from "./ReportImagesEdit.module.css";

/*
 *  imageSpecs: {
 *    <nameN>: {
 *      docName: <str=[sum|aux]>
 *      objName: <str>
 *      imageName: <str>
 *      checkpointName: <str>
 *    }
 *  }
 */

const defaultImageSpecDef = Object.freeze({
  docName: "aux",
  objName: "",
  imageName: "",
  checkpointName: "",
});

class ReportImagesEdit extends React.Component {
  constructor(props) {
    super(props);

    const state = this.gatherState();

    this.state = {
      value: state.value,

      dialogShow: false,
      dialogMode: null,
    };
  }

  render() {
    let content = null;

    let newImageSpecDialog = (
      <ReportsNewDialog
        show={this.state.dialogShow}
        title="Enter Image Spec Name"
        itemLabel="Image Spec Name"
        suggestedName={this.state.dialogMode==='Copy' ? this.props.imageSpecName : null}
        validItemList={rf.gatherReportImageSpecNames( this.props.nextSpec, this.props.reportName )}
        submitAnswer={this.handleNewImageSpecSubmitAnswer}
      />
    );

    if ( this.props.imageSpecName == null ) {
      if ( this.props.selectedList.length == 0 ) {
        let addNewButton = (
          <ThemedButton text="New Image Spec" onClick={this.handleNewImageSpecButton} />
        );

        content = ( <div>
                      <h3>Getting Started</h3>
                      <ul>
                        <li>{addNewButton}</li>
                        <li>or select a single image spec on the left to edit</li>
                        <li>or select a group of image specs to delete</li>
                      </ul>
                      {newImageSpecDialog}
                    </div> );
      } else {
        let deleteSelectedButton = (
          <ThemedButton text="Delete Selected" type="alert" onClick={this.handleDeleteSelectedButton} />
        );

        content = ( <div>
                      <h3>Getting Started</h3>
                      <ul>
                        <li>{deleteSelectedButton}</li>
                      </ul>
                    </div> );
      }
    } else {

      let buttonGroupLeft  = (
        <ButtonGroup>
          <ThemedButton text="Insert Image Spec" onClick={this.handleInsertImageSpecButton} />
          <ThemedButton text="Copy Image Spec" onClick={this.handleCopyImageSpecButton} />
          <ThemedButton text="Delete Image Spec" type="alert" onClick={this.handleDeleteImageSpecButton} />
        </ButtonGroup>
      );

      let buttonGroupRight = (
        <ButtonGroup>
          <ThemedButton text="Apply" onClick={this.handleApplyButton} />
          <ThemedButton text="Reset" type="alert" onClick={this.handleResetButton} />
        </ButtonGroup>
      );

      let currentImageSpecNameLabel = (
        <div id="divEditorTop_ReportImageSpecsEdit_Label" className={styles.divEditorTop_ReportImageSpecsEdit_Label}>{this.props.imageSpecName}</div>
      );

      const docNameMenuItems = rf.reportSelectListTable.docNameList.map((item) =>
        <MenuItem key={item.key} value={item.value}>{item.title}</MenuItem>
      );

      let docNameInput = (
        <FormControl fullWidth variant="filled" >
          <InputLabel>Document Name</InputLabel>
          <Select
            variant="filled"
            name="value.docName"
            value={this.state.value.docName}
            onChange={this.handleValueChange}
          >
            {docNameMenuItems}
          </Select>
        </FormControl>
      );

      const objNameMenuItems = rf.reportSelectListTable.objNameList.map((item) =>
        <MenuItem key={item.key} value={item.value}>{item.title}</MenuItem>
      );

      let objNameInput = (
        <FormControl fullWidth variant="filled" >
          <InputLabel>Object Name</InputLabel>
          <Select
            variant="filled"
            name="value.objName"
            value={this.state.value.objName}
            onChange={this.handleValueChange}
          >
            {objNameMenuItems}
          </Select>
        </FormControl>
      );

      let imageNameInput = (
        <FormControl fullWidth variant="filled" >
          <InputLabel>Image Name</InputLabel>
          <FilledInput
            name="value.imageName"
            value={this.state.value.imageName}
            onChange={this.handleValueChange}
          />
        </FormControl>
      );

      let checkpointNameInput = (
        <FormControl fullWidth variant="filled" >
          <InputLabel>Checkpoint Name</InputLabel>
          <FilledInput
            name="value.checkpointName"
            value={this.state.value.checkpointName}
            onChange={this.handleValueChange}
          />
        </FormControl>
      );

      content = (
        <div id="divEditorTop_ReportImageSpecsEdit_Top" className={styles.divEditorTop_ReportImageSpecsEdit_Top}>
          {currentImageSpecNameLabel}

          <div id="divEditorTop_ReportImageSpecsEdit_Input" className={styles.divEditorTop_ReportImageSpecsEdit_Input}>
            {docNameInput}
            {objNameInput}
            {imageNameInput}
            {checkpointNameInput}
          </div>

          <div id="divEditorTop_ReportImageSpecsEdit_Buttons" className={styles.divEditorTop_ReportImageSpecsEdit_Buttons}>
            <div id="divEditorTop_ReportImageSpecsEdit_JustifyLeft" className={styles.divEditorTop_ReportImageSpecsEdit_JustifyLeft}>
              {buttonGroupLeft}
            </div>
            <div id="divEditorTop_ReportImageSpecsEdit_JustifyRight" className={styles.divEditorTop_ReportImageSpecsEdit_JustifyRight}>
              {buttonGroupRight}
            </div>
          </div>

          {newImageSpecDialog}
        </div>
      );
    }

    return content;
  }

  handleResize = () => {
    let divInput   = document.getElementById( "divEditorTop_ReportImageSpecsEdit_Input" );
    let divButtons = document.getElementById( "divEditorTop_ReportImageSpecsEdit_Buttons" );

    if ( divInput == null || divButtons == null ) {
      return
    }

    const winHeight = document.documentElement.clientHeight;

    const rectInput   = divInput.getBoundingClientRect();
    const rectButtons = divButtons.getBoundingClientRect();

    const newY = winHeight - rectButtons.height;

    const delta = newY - rectButtons.y;

    const newHeight = rectInput.height + delta - 5;

    divInput.style.height = newHeight + "px";
  }

  componentDidMount() {
    window.addEventListener( "resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate( prevProps, prevState ) {
    this.handleResize();

    const isOutsideChange = !_.isEqual( prevProps, this.props );

    if ( isOutsideChange ) {
      const reportChanged    = ( prevProps.reportName !== this.props.reportName );
      const imageSpecChanged = ( prevProps.imageSpecName  !== this.props.imageSpecName );
      const valueChanged     = !_.isEqual( prevState.value, this.gatherValue() );

      if ( reportChanged || imageSpecChanged || valueChanged ) {
        this.setState( this.gatherState() );
      }
    }

    this.props.updateDirty( this.isDirty() );
  }

  componentWillUnmount() {
  }

  gatherState() {
    let state = {};

    state.value = this.gatherValue();

    return state;
  }

  gatherValue() {
    return rf.gatherReportImageSpec( this.props.nextSpec, this.props.reportName, this.props.imageSpecName, defaultImageSpecDef );
  }

  isDirty() {
    let state = this.gatherState();

    let clean = ( _.isEqual( state.value, this.state.value ) );

    return !clean;
  }

  handleValueChange = (e) => {
    let nextState = {
      value: _.cloneDeep( this.state.value )
    };

    _.set( nextState, e.target.name, e.target.value );

    this.setState( nextState );
  }

  handleNewImageSpecSubmitAnswer = ( accept, newImageSpecName ) => {
    if ( accept && newImageSpecName.length > 0 ) {
      let nextSpec = null;

      if ( this.state.dialogMode === 'New' ) {

        this.props.insertRow( newImageSpecName );

        nextSpec = rf.insertReportImageSpec( this.props.nextSpec, this.props.reportName, newImageSpecName, defaultImageSpecDef );

      } else if ( this.state.dialogMode === 'Copy' ) {

        this.props.insertRow( newImageSpecName, this.props.imageSpecName );

        let newImageSpecValue = this.state.value;

        nextSpec = rf.insertReportImageSpec( this.props.nextSpec, this.props.reportName, newImageSpecName, newImageSpecValue, this.props.imageSpecName, "after" );

      } else if ( this.state.dialogMode === 'Insert' ) {

        this.props.insertRow( newImageSpecName, this.props.imageSpecName );

        nextSpec = rf.insertReportImageSpec( this.props.nextSpec, this.props.reportName, newImageSpecName, defaultImageSpecDef, this.props.imageSpecName, "after" );
      }

      if ( nextSpec ) this.props.updateNextSpec( nextSpec );
    }

    this.setState({
      dialogShow: false,
      dialogMode: null,
    });
  }

  handleNewImageSpecButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'New',
    });
  }

  handleInsertImageSpecButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'Insert',
    });
  }

  handleCopyImageSpecButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'Copy',
    });
  }

  handleDeleteSelectedButton = () => {
    this.props.deleteRows( this.props.selectedList );

    let nextSpec = rf.deleteReportImageSpecs( this.props.nextSpec, this.props.reportName, this.props.selectedList );

    this.props.updateNextSpec( nextSpec );
  }

  handleDeleteImageSpecButton = () => {
    this.props.deleteRow( this.props.imageSpecName );

    let nextSpec = rf.deleteReportImageSpec( this.props.nextSpec,
                                             this.props.reportName,
                                             this.props.imageSpecName );

    this.props.updateNextSpec( nextSpec );
  }

  handleApplyButton = () => {
    let nextSpec = rf.updateReportImageSpec( this.props.nextSpec,
                                             this.props.reportName,
                                             this.props.imageSpecName,
                                             this.state.value );
    this.props.updateNextSpec( nextSpec );
  }

  handleResetButton = () => {
    this.setState( this.gatherState() );
  }
}

export default ReportImagesEdit;

////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
