////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportFunctions.js#13 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/04 11:29:22 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import _ from "lodash";

import * as funcs from "common/Funcs"

/*
 * Report Schemea:
 *
 * spec: {
 *   data: {
 *     metrics: {
 *     }
 *     reportNames: {
 *       <report-name>: {
 *         reportInfo: {
 *           menuName: <str>
 *           menuGroup: <str>
 *           reportClass: <str=[TableDetailReport|TableCompareReport|BuildsDashboardReport|ImageCompareReport|ProfileReport|FileReport]>
 *           docType: <str=[sum|aux]>  // Only valid for TableDetailReport
 *           tableName: <str>          // Only valid for TableDetailReport
 *         }
 *         metrics: {
 *           <metricN>: {
 *             display: <str>
 *             indexList: [ <indexN> ]>
 *             groupName: <str>
 *             tooltip: <str>
 *             hidden: <boolean>
 *             colorRule: {
 *               color: <str=[improve_degrade|...>
 *               lightPct: <float>
 *               medPct: <float>
 *               darkPct: <float>
 *               improves: <str>
 *               absThreshold: <int>
 *               refValue: <str> or null
 *             }
 *             defaultCheckpoint: <str> or null
 *             defaultRollup: {
 *               calculate: <str=[no|yes|ifMissing]>
 *               math: <str=[sum|avg|min|max]>
 *               incParent: <str=[no|yes|ifPresent]>
 *             }
 *             defaultSummary: {
 *               calculate: <str=[no|yes]>
 *               math: <str=[sum|avg|min|max]>
 *               incParent: <str=[no|yes]>
 *             }
 *           }
 *         }
 *         coloringRules: {
 *           defaultBlock:{...}
 *           <blockN>: {
 *             defaultCheckpoint: <str> or null
 *             <checkpointN>: {
 *               <metricNameN>: {
 *               }
 *             }
 *           }
 *         }
 *         panels: {
 *           <plotNameN>: {
 *             type: <str=[line, barH, barV, pie]>
 *             incParent: <boolean>
 *             data: [ <metricNameN> ]
 *           }
 *         }
 *         rowGroupOptions: {
 *           <rowGroupOptionNameN>: {
 *             <ruleNameN>: {
 *               fieldName: <str>
 *               rxList: [ <regexpN> ],
 *               defaultGroup: <str>
 *             }
 *           }
 *         }
 *         imageSpecs: {
 *           <nameN>: {
 *             docName: <str=[sum|aux]>
 *             objName: <str>
 *             imageName: <str>
 *             checkpointName: <str>
 *           }
 *         }
 *       }
 *     }
 *   }
 * }
 */

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// Local Functions                                                          ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

function insertKey( newKey, newValue, obj, key=null, pos="before" ) {

  if ( key == null ) {
    let newObj = _.cloneDeep( obj );
    newObj[ newKey ] = newValue;
    return newObj;
  }

  let ndx = ( key === 0 ? 0 : Object.keys( obj ).indexOf( key ) );

  if ( pos == "after" ) { ndx++; }

  let result = Object.keys( obj ).reduce( ( newObj, currentKey, currentIndex ) => {
    if ( currentIndex == ndx ) newObj[ newKey ] = newValue;
    newObj[ currentKey ] = obj[ currentKey ];
    return newObj
  }, {} );

  if ( !_.has( result, newKey ) ) { // If the reduce did not place the newKey then append it here
    result[ newKey ] = newValue;
  }

  return result;
}

function reorderThings( nextSpec, path, reorderList ) {

  let thisSpec = _.cloneDeep( nextSpec );

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    let obj = {};

    reorderList.forEach( function( name ) {
      obj[ name ] = _.cloneDeep( container[ name ] );
    });

    container = obj;
  }

  _.set( thisSpec, path, container );

  return thisSpec;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// Constants                                                                ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export const reportSelectListTable = Object.freeze({
  booleanList: [
    { key: "0",  value: false, title: "No" },
    { key: "1",  value: true,  title: "Yes" },
  ],
  calcList: [
    { key: "0", value: "no",        title: "No" },
    { key: "1", value: "yes",       title: "Yes" },
    { key: "2", value: "ifMissing", title: "If Missing" },
  ],
  colorList: [
    { key: "0",  value: "improve_degrade",      title: "Improve Degrade" },
    { key: "1",  value: "none",                 title: "None" },
    { key: "2",  value: "different",            title: "Different" },
    { key: "3",  value: "different_or_missing", title: "Different or Missing" },
    { key: "4",  value: "missing",              title: "Missing" },
  ],
  docNameList: [
    { key: "0",  value: "aux", title: "Aux" },
    { key: "1",  value: "sum", title: "Sum" },
  ],
  docTypeList: [
    { key: "0", value: "aux", title: "Aux" },
    { key: "1", value: "sum", title: "Sum" },
  ],
  improvesList: [
    { key: "0",  value: "zero",    title: "Zero" },
    { key: "1",  value: "larger",  title: "Larger" },
    { key: "2",  value: "smaller", title: "Smaller" },
  ],
  incParentList: [
    { key: "0", value: "no",        title: "No" },
    { key: "1", value: "yes",       title: "Yes" },
    { key: "2", value: "ifPresent", title: "If Present" },
  ],
  mathList: [
    { key: "0", value: "sum", title: "Summary" },
    { key: "1", value: "avg", title: "Average" },
    { key: "2", value: "min", title: "Minimum" },
    { key: "3", value: "max", title: "Maximum" },
  ],
  objNameList: [
    { key: "0", value: "diskFiles", title: "Disk Files" },
    { key: "1", value: "dbFiles",   title: "DB Files" },
  ],
  plotTypeList: [
    { key: "0",  value: "line",   title: "Line Graph" },
    { key: "1",  value: "barH",   title: "Horizontal Bar Graph" },
    { key: "2",  value: "barV",   title: "Vertical Bar Graph" },
    { key: "3",  value: "pie",    title: "Pie Chart" },
    { key: "4",  value: "spider", title: "Spider Chart" },
  ],
  yesNoList: [
    { key: "0", value: "no",  title: "No" },
    { key: "1", value: "yes", title: "Yes" },
  ],
});

export const reportDefinitionTable = Object.freeze({
  BuildsDashboardReport: {
    title: "Builds Dashboard Report",
    panels: false,
    imageSpecs: false,
    metrics: true,
    coloringRules: true,
    rowGroupOptions: true,
    hasDocType: false,
    hasTableName: false,
    hasRollup: true,
    hasSummary: true,
    hasLimitedMetrics: false,
    hasSpecialMetrics: true,
    contextMenu: false,
  },
  FileReport: {
    title: "File Report",
    panels: false,
    imageSpecs: false,
    metrics: false,
    coloringRules: false,
    rowGroupOptions: false,
    hasDocType: false,
    hasTableName: false,
    hasRollup: false,
    hasSummary: false,
    hasLimitedMetrics: false,
    hasSpecialMetrics: false,
    contextMenu: false,
  },
  HierDashboardReport: {
    title: "Hier Dashboard Report",
    panels: true,
    imageSpecs: false,
    metrics: true,
    coloringRules: true,
    rowGroupOptions: false,
    hasDocType: false,
    hasTableName: false,
    hasRollup: true,
    hasSummary: true,
    hasLimitedMetrics: false,
    hasSpecialMetrics: true,
    contextMenu: false,
  },
  HierTimeDashboardReport: {
    title: "Hier-Time Dashboard Report",
    panels: false,
    imageSpecs: false,
    metrics: false,
    coloringRules: false,
    rowGroupOptions: false,
    hasDocType: false,
    hasTableName: false,
    hasRollup: false,
    hasSummary: false,
    hasLimitedMetrics: false,
    hasSpecialMetrics: false,
    contextMenu: false,
  },
  ImageCompareReport: {
    title: "Image Compare Report",
    panels: false,
    imageSpecs: false,
    metrics: false,
    coloringRules: false,
    rowGroupOptions: false,
    hasDocType: false,
    hasTableName: false,
    hasRollup: false,
    hasSummary: false,
    hasLimitedMetrics: false,
    hasSpecialMetrics: false,
    contextMenu: false,
  },
  ProfileReport: {
    title: "Profile Report",
    panels: false,
    imageSpecs: false,
    metrics: false,
    coloringRules: false,
    rowGroupOptions: false,
    hasDocType: false,
    hasTableName: false,
    hasRollup: false,
    hasSummary: false,
    hasLimitedMetrics: false,
    hasSpecialMetrics: false,
    contextMenu: false,
  },
  TableCompareReport: {
    title: "Table Compare Report",
    panels: false,
    imageSpecs: false,
    metrics: true,
    coloringRules: false,
    rowGroupOptions: false,
    hasDocType: false,
    hasTableName: false,
    hasRollup: false,
    hasSummary: false,
    hasLimitedMetrics: false,
    hasSpecialMetrics: false,
    contextMenu: true,
  },
  TableDetailReport: {
    title: "Table Detail Report",
    panels: false,
    imageSpecs: true,
    metrics: true,
    coloringRules: false,
    rowGroupOptions: false,
    hasDocType: true,
    hasTableName: true,
    hasRollup: false,
    hasSummary: false,
    hasLimitedMetrics: true,
    hasSpecialMetrics: false,
    contextMenu: false,
  },
  DtcoReport: {
    title: "DTCO Report (Alpha)",
    panels: false,
    imageSpecs: false,
    metrics: false,
    coloringRules: false,
    rowGroupOptions: false,
    hasDocType: false,
    hasTableName: false,
    hasRollup: false,
    hasSummary: false,
    hasLimitedMetrics: false,
    hasSpecialMetrics: false,
    contextMenu: false,
  },
});

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// Misc Functions                                                           ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function showApplyOrResetNotification( secName, secElement ) {
  const Title   = "Report " + secName + " Editor";
  const Message = "Apply or Reset the " + secElement + " being edited.";

  funcs.showNotification( Title, Message );
}

export function getNonDefaultValues( obj1, obj2 ) {

  // Make sure an object to compare is provided
  if (!obj2 || Object.prototype.toString.call(obj2) !== '[object Object]') {
    return obj1;
  }

  // Variables
  var diffs = {};
  var key;

  // Methods

  var arraysMatch = function (arr1, arr2) {
    // Check if the arrays are the same length
    if (arr1.length !== arr2.length) return false;

    // Check if all items exist and are in the same order
    for (var i = 0; i < arr1.length; i++) {
      if (arr1[i] !== arr2[i]) return false;
    }

    // Otherwise, return true
    return true;
  };

  var compare = function (item1, item2, key) {
    // Get the object type
    var type1 = Object.prototype.toString.call(item1);
    var type2 = Object.prototype.toString.call(item2);

    // If type2 is undefined it has been removed
    if (type2 === '[object Undefined]') {
      diffs[key] = null;
      return;
    }

    // If items are different types
    if (type1 !== type2) {
      diffs[key] = item2;
      return;
    }

    // If an object, compare recursively
    if (type1 === '[object Object]') {
      var objDiff = getNonDefaultValues(item1, item2);
      if (Object.keys(objDiff).length > 0) {
        diffs[key] = objDiff;
      }
      return;
    }

    // If an array, compare
    if (type1 === '[object Array]') {
      if (!arraysMatch(item1, item2)) {
        diffs[key] = item2;
      }
      return;
    }

    // Else if it's a function, convert to a string and compare
    // Otherwise, just compare
    if (type1 === '[object Function]') {
      if (item1.toString() !== item2.toString()) {
        diffs[key] = item2;
      }
    } else {
      if (item1 !== item2 ) {
        diffs[key] = item2;
      }
    }
  };

  // Compare our objects
  // Loop through the first object
  for (key in obj1) {
    if (obj1.hasOwnProperty(key)) {
      compare(obj1[key], obj2[key], key);
    }
  }

  // Loop through the second object and find missing items
  for (key in obj2) {
    if (obj2.hasOwnProperty(key)) {
      if (!obj1[key] && obj1[key] !== obj2[key] ) {
        diffs[key] = obj2[key];
      }
    }
  }

  // Return the object of differences
  return diffs;
}

export function denullify( obj, dflt="null" ) {
  if ( typeof obj !== 'undefined' && obj !== null ) {
    Object.keys( obj ).forEach( function( key ) {
      if ( obj[key] == null ) {
        obj[key] = dflt;
      } else if ( _.isPlainObject( obj[key] ) ) {
        denullify( obj[key] )
      }
    });
  }
}

export function renullify( obj, nullStr="null" ) {
  if ( typeof obj !== 'undefined' && obj !== null ) {
    Object.keys( obj ).forEach( function( key ) {
      if ( obj[ key ] === nullStr ) {
        obj[ key ] = null;
      } else if ( _.isPlainObject( obj[key] ) ) {
        renullify( obj[key] )
      }
    });
  }
}

function setReportSectionData( reportClass, reportData, sectionName, defaultData ) {
  if ( _.get( reportDefinitionTable, [reportClass, sectionName] ) ) {
    _.set( reportData, sectionName, defaultData );
  }
}

export function gatherReportDefinition( nextSpec, reportName, defn ) {
  let result = false;

  const path = ['data', 'reportNames', reportName, 'reportInfo', 'reportClass'];

  let reportClass = _.get( nextSpec, path, null );

  if ( reportClass ) {
    result = _.get( reportDefinitionTable, [reportClass, defn], false );
  }

  return result;
}

export function defaultReportData( reportClass ) {
  let reportInfo = {
    menuName: "",
    menuGroup: "",
    reportClass: reportClass,
  };

  if ( _.get( reportDefinitionTable, [reportClass, 'hasDocType'], false ) ) {
    _.set( reportInfo, 'docType', 'sum' );
  }

  if ( _.get( reportDefinitionTable, [reportClass, 'hasTableName'], false ) ) {
    _.set( reportInfo, 'tableName', null );
  }

  let reportData = {};

  _.set( reportData, 'reportInfo', reportInfo );

  // let specialMetrics = {};
  // 
  // if ( _.get( reportDefinitionTable, [reportClass, 'hasSpecialMetrics'], false ) ) {
  //   specialMetrics = {
  //     __latestCheckpointName: {
  //       groupName: "Latest",
  //       displayName: "Checkpoint"
  //     },
  //     __latestCheckpointDate: {
  //       groupName: "Latest",
  //       displayName: "Date"
  //     },
  //     __latestCheckpointUser: {
  //       groupName: "Latest",
  //       displayName: "User"
  //     },
  //   };
  // }

  setReportSectionData( reportClass, reportData, 'metrics',         {} );
  setReportSectionData( reportClass, reportData, 'coloringRules',   {} );
  setReportSectionData( reportClass, reportData, 'panels',          {} );
  setReportSectionData( reportClass, reportData, 'rowGroupOptions', {} );
  setReportSectionData( reportClass, reportData, 'imageSpecs',      {} );

  return reportData;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// Global Metrics Functions                                                 ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function insertGlobalMetric( nextSpec, name, data, key=null, pos="before" ) {

  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'metrics'];

  let container = _.get( thisSpec, path, null );

  if ( container )
    _.set( thisSpec, path, insertKey( name, data, container, key, pos ) );

  return thisSpec;
}

export function appendGlobalMetric( nextSpec, name, data ) {
  return insertGlobalMetric( nextSpec, name, data );
}

export function prependGlobalMetric( nextSpec, name, data ) {
  return insertGlobalMetric( nextSpec, name, data, 0, 'before' );
}

export function updateGlobalMetric( nextSpec, name, data ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'metrics', name];

  if ( _.has( thisSpec, path ) ) _.set( thisSpec, path, data );

  return thisSpec;
}

export function reorderGlobalMetrics( nextSpec, reorderList ) {
  return reorderThings( nextSpec, ['data', 'metrics'], reorderList );
}

export function deleteGlobalMetric( nextSpec, name ) {
  let thisSpec = _.cloneDeep( nextSpec );

  _.unset( thisSpec, ['data', 'metrics', name] );

  return thisSpec;
}

export function deleteGlobalMetrics( nextSpec, nameList ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'metrics'];

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    nameList.forEach( ( name ) => {
      if ( container.hasOwnProperty( name ) ) {
        delete container[ name ];
      }
    });
  }

  return thisSpec;
}

export function gatherGlobalMetric( nextSpec, name, defaultData={} ) {
  let data = _.cloneDeep( defaultData );

  let specData = _.get( nextSpec, ['data', 'metrics', name], null );

  if ( specData ) _.merge( data, specData );

  return _.cloneDeep( data );
}

export function existsGlobalMetricName( nextSpec, name ) {
  return _.has( nextSpec, ['data', 'metrics', name] );
}

export function gatherGlobalMetricNames( nextSpec ) {
  let names = _.get( nextSpec, ['data', 'metrics'], null );

  return ( names ? Object.keys( names ) : [] );
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// Report Functions                                                         ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function insertReport( nextSpec, name, data, key=null, pos="before" ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames'];

  let container = _.get( thisSpec, path, null );

  if ( container )
    _.set( thisSpec, path, insertKey( name, data, container, key, pos ) );

  return thisSpec;
}

export function appendReport( nextSpec, name, data ) {
  return insertReport( nextSpec, name, data );
}

export function prependReport( nextSpec, name, data ) {
  return insertReport( nextSpec, name, data, 0, 'before' );
}

export function updateReport( nextSpec, name, data ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', name];

  if ( _.has( thisSpec, path ) ) _.set( thisSpec, path, data );

  return thisSpec;
}

export function renameReport( nextSpec, oldReportName, newReportName ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames'];

  let newReports = {};
  let oldReports = _.get( thisSpec, path, null );

  if ( oldReports !== null ) {
    _.forEach( oldReports, (reportData, reportName) => {
      if ( reportName === oldReportName ) {
        newReports[ newReportName ] = reportData;
      } else {
        newReports[ reportName ] = reportData;
      }
    });
  }

  _.set( thisSpec, path, newReports );

  return thisSpec;
}

export function reorderReports( nextSpec, reorderList ) {
  return reorderThings( nextSpec, ['data', 'reportNames'], reorderList );
}

export function deleteReport( nextSpec, name ) {
  let thisSpec = _.cloneDeep( nextSpec );

  _.unset( thisSpec, ['data', 'reportNames', name] );

  return thisSpec;
}

export function deleteReports( nextSpec, nameList ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames'];

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    nameList.forEach( ( name ) => {
      if ( container.hasOwnProperty( name ) ) {
        delete container[ name ];
      }
    });
  }

  return thisSpec;
}

export function gatherReport( nextSpec, name, defaultData={} ) {
  let data = _.cloneDeep( defaultData );

  let specData = _.get( nextSpec, ['data', 'reportNames', name], null );

  if ( specData ) _.merge( data, specData );

  return _.cloneDeep( data );
}

export function gatherReportNames( nextSpec ) {
  let names = _.get( nextSpec, ['data', 'reportNames'], null );

  return ( names ? Object.keys( names ) : [] );
}

export function gatherReportClasses() {
  let reportNdx = 0;
  let reportClassList = [];

  _.forEach( reportDefinitionTable, (value,key) => {
    reportClassList.push({
      key: reportNdx++,
      value: key,
      title: value.title,
    });
  });

  return reportClassList;
}

export function existsReport( nextSpec, reportName ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName] );
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// ReportInfo Functions                                                     ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function updateReportInfo( nextSpec, reportName, data ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'reportInfo'];

  if ( _.has( thisSpec, path ) ) _.set( thisSpec, path, data );

  return thisSpec;
}

export function gatherReportInfo( nextSpec, reportName, defaultData={} ) {
  let data = _.cloneDeep( defaultData );

  let specData = _.get( nextSpec, ['data', 'reportNames', reportName, 'reportInfo'], null );

  if ( specData ) _.merge( data, specData );

  return _.cloneDeep( data );
}

export function existsReportInfo( nextSpec, reportName ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'reportInfo'] );
}

export function isReportClass( nextSpec, reportName, className ) {
  let specData = _.get( nextSpec, ['data', 'reportNames', reportName, 'reportInfo', 'reportClass'], null );

  return ( specData === className );
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// ColorRules Functions                                                     ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function insertReportColoringRule( nextSpec, reportName, block, checkpoint, name, data, key=null, pos="before" ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint];

  if ( !_.has( thisSpec, path ) ) _.set( thisSpec, path, {} ); // Make sure the block/checkpoint paths exist first.

  let container = _.get( thisSpec, path, null );

  if ( container )
    _.set( thisSpec, path, insertKey( name, data, container, key, pos ) );

  return thisSpec;
}

export function appendReportColoringRule( nextSpec, reportName, block, checkpoint, name, data ) {
  return insertReportColoringRule( nextSpec, reportName, block, checkpoint, name, data );
}

export function prependReportColoringRule( nextSpec, reportName, block, checkpoint, name, data ) {
  return insertReportColoringRule( nextSpec, reportName, block, checkpoint, name, data, 0, 'before' );
}

export function updateReportColoringRule( nextSpec, reportName, block, checkpoint, name, data ) {
  let thisSpec = _.cloneDeep( nextSpec );

  _.set( thisSpec, ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint, name], data );

  return thisSpec;
}

export function reorderReportColoringRules( nextSpec, reportName, block, checkpoint, reorderList ) {
  return reorderThings( nextSpec, ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint], reorderList );
}

export function deleteReportColoringRule( nextSpec, reportName, block, checkpoint, name, deleteEmpty=true ) {
  let thisSpec = _.cloneDeep( nextSpec );

  let path = ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint, name];

  _.unset( thisSpec, path );

  if ( deleteEmpty ) {
    path.pop(); // @checkpoint

    if ( _.size( _.get( thisSpec, path, {} ) ) == 0 ) {
      _.unset( thisSpec, path );
    }

    path.pop(); // @block

    if ( _.size( _.get( thisSpec, path, {} ) ) == 0 ) {
      _.unset( thisSpec, path );
    }
  }

  return thisSpec;
}

export function deleteReportColoringRules( nextSpec, reportName, block, checkpoint, nameList, deleteEmpty=true ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint];

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    nameList.forEach( name => {
      if ( container.hasOwnProperty( name ) ) {
        delete container[ name ];
      }
    });
  }

  if ( deleteEmpty ) {
    if ( _.size( _.get( thisSpec, path, {} ) ) == 0 ) {
      _.unset( thisSpec, path );
    }

    path.pop(); // @block

    if ( _.size( _.get( thisSpec, path, {} ) ) == 0 ) {
      _.unset( thisSpec, path );
    }
  }

  return thisSpec;
}

export function gatherReportColoringRule( nextSpec, reportName, block, checkpoint, name, defaultData={} ) {
  let data = _.cloneDeep( defaultData );

  let specData = _.get( nextSpec, ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint, name], null );

  if ( specData ) _.merge( data, specData );

  // This fixes a bug in the public/defaultReportSpec.json 
  let mediumPct = _.get( data, 'mediumPct', null );
  if ( mediumPct ) {
    _.unset( data, 'mediumPct' );
    _.set( data, 'medPct', mediumPct );
  }

  return _.cloneDeep( data );
}

export function existsReportColoringRule( nextSpec, reportName, name ) {
  let ok = false;

  if ( name !== null ) {
    let path = ['data', 'reportNames', reportName, 'coloringRules'];

    if ( _.has( nextSpec, path ) ) {
      path.push( name.blockName );

      if ( _.has( nextSpec, path ) ) {
        path.push( name.checkpointName );

        if ( _.has( nextSpec, path ) ) {
          path.push( name.metricName );

          ok = _.has( nextSpec, path );
        }
      }
    }
  }

  return ok;
}

export function existsReportColoringRules( nextSpec, reportName ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'coloringRules'] );
}

export function existsReportColoringRuleBlock( nextSpec, reportName, block ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'coloringRules', block] );
}

export function existsReportColoringRuleCheckpoint( nextSpec, reportName, block, checkpoint ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint] );
}

export function existsReportColoringRuleName( nextSpec, reportName, block, checkpoint, name ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint, name] );
}

export function gatherReportColoringRules( nextSpec, reportName ) {
  let list = [];

  let path = ['data', 'reportNames', reportName, 'coloringRules'];

  _.forEach( _.get( nextSpec, path, [] ), (value, block) => {
    path.push( block );

    _.forEach( _.get( nextSpec, path, [] ), (value, checkpoint) => {
      path.push( checkpoint )

      _.forEach( _.get( nextSpec, path, [] ), (value, metric) => {
        list.push({
               blockName: block,
          checkpointName: checkpoint,
              metricName: metric,
        });
      });
      
      path.pop();
    });

    path.pop();
  });

  return list;
}

export function gatherReportColoringRuleBlockNames( nextSpec, reportName ) {

  let names = _.get( nextSpec, ['data', 'reportNames', reportName, 'coloringRules'], null );

  return ( names ? Object.keys( names ) : [] );
}

export function gatherReportColoringRuleCheckpointNames( nextSpec, reportName, block ) {

  let names = _.get( nextSpec, ['data', 'reportNames', reportName, 'coloringRules', block], null );

  return ( names ? Object.keys( names ) : [] );
}

export function gatherReportColoringRuleNames( nextSpec, reportName, block, checkpoint ) {

  let names = _.get( nextSpec, ['data', 'reportNames', reportName, 'coloringRules', block, checkpoint], null );

  return ( names ? Object.keys( names ) : [] );
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// Report Metrics Functions                                                 ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function insertReportMetric( nextSpec, reportName, name, data, key=null, pos="before" ) {

  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'metrics'];

  let container = _.get( thisSpec, path, null );

  if ( container )
    _.set( thisSpec, path, insertKey( name, data, container, key, pos ) );

  return thisSpec;
}

export function appendReportMetric( nextSpec, reportName, name, data ) {
  return insertReportMetric( nextSpec, reportName, name, data );
}

export function prependReportMetric( nextSpec, reportName, name, data ) {
  return insertReportMetric( nextSpec, reportName, name, data, 0, 'before' );
}

export function updateReportMetric( nextSpec, reportName, name, data ) {

  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'metrics', name];

  if ( _.has( thisSpec, path ) ) _.set( thisSpec, path, data );

  return thisSpec;
}

export function reorderReportMetrics( nextSpec, reportName, reorderList ) {
  return reorderThings( nextSpec, ['data', 'reportNames', reportName, 'metrics'], reorderList );
}

export function deleteReportMetric( nextSpec, reportName, name ) {

  let thisSpec = _.cloneDeep( nextSpec );

  _.unset( thisSpec, ['data', 'reportNames', reportName, 'metrics', name] );

  return thisSpec;
}

export function deleteReportMetrics( nextSpec, reportName, nameList ) {

  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'metrics'];

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    nameList.forEach( function( name ) {
      if ( container.hasOwnProperty( name ) ) {
        delete container[ name ];
      }
    });
  }

  return thisSpec;
}

export function gatherReportMetric( nextSpec, reportName, name, defaultData={} ) {

  let data = _.cloneDeep( defaultData );

  let specData = _.get( nextSpec, ['data', 'reportNames', reportName, 'metrics', name], null );

  if ( specData ) _.merge( data, specData );

  return _.cloneDeep( data );
}

export function existsReportMetrics( nextSpec, reportName ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'metrics'] );
}

export function existsReportMetric( nextSpec, reportName, name ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'metrics', name] );
}

export function gatherReportMetricNames( nextSpec, reportName ) {

  let names = _.get( nextSpec, ['data', 'reportNames', reportName, 'metrics'], null );

  return ( names ? Object.keys( names ) : [] );
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// Panels Functions                                                         ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function insertReportPanel( nextSpec, reportName, name, data, key=null, pos="before" ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'panels'];

  let container = _.get( thisSpec, path, null );

  if ( container )
    _.set( thisSpec, path, insertKey( name, data, container, key, pos ) );

  return thisSpec;
}

export function appendReportPanel( nextSpec, reportName, name, data ) {
  return insertReportPanel( nextSpec, reportName, name, data );
}

export function prependReportPanel( nextSpec, reportName, name, data ) {
  return insertReportPanel( nextSpec, reportName, name, data, 0, 'before' );
}

export function updateReportPanel( nextSpec, reportName, name, data ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'panels', name];

  if ( _.has( thisSpec, path ) ) _.set( thisSpec, path, data );

  return thisSpec;
}

export function reorderReportPanels( nextSpec, reportName, reorderList ) {
  return reorderThings( nextSpec, ['data', 'reportNames', reportName, 'panels'], reorderList );
}

export function deleteReportPanel( nextSpec, reportName, name ) {
  let thisSpec = _.cloneDeep( nextSpec );

  _.unset( thisSpec, ['data', 'reportNames', reportName, 'panels', name] );

  return thisSpec;
}

export function deleteReportPanels( nextSpec, reportName, nameList ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'panels'];

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    nameList.forEach( function( name ) {
      if ( container.hasOwnProperty( name ) ) {
        delete container[ name ];
      }
    });
  }

  return thisSpec;
}

export function gatherReportPanel( nextSpec, reportName, name, defaultData={} ) {
  let data = _.cloneDeep( defaultData );

  let specData = _.get( nextSpec, ['data', 'reportNames', reportName, 'panels', name], null );

  if ( specData ) _.merge( data, specData );

  return _.cloneDeep( data );
}

export function existsReportPanels( nextSpec, reportName ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'panels'] );
}

export function existsReportPanel( nextSpec, reportName, name ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'panels', name] );
}

export function gatherReportPanelNames( nextSpec, reportName ) {

  let names = _.get( nextSpec, ['data', 'reportNames', reportName, 'panels'], null );

  return ( names ? Object.keys( names ) : [] );
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// RowGroupOptions Functions                                                ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function insertReportRowGroupOptionRule( nextSpec, reportName, optionName, name, data, key=null, pos="before" ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'rowGroupOptions', optionName];

  let container = _.get( thisSpec, path, {} );

  _.set( thisSpec, path, insertKey( name, data, container, key, pos ) );

  return thisSpec;
}

export function appendReportRowGroupOptionRule( nextSpec, reportName, name, data ) {
  return insertReportRowGroupOptionRule( nextSpec, reportName, name, data );
}

export function prependReportRowGroupOptionRule( nextSpec, reportName, name, data ) {
  return insertReportRowGroupOptionRule( nextSpec, reportName, name, data, 0, 'before' );
}

export function updateReportRowGroupOptionRule( nextSpec, reportName, optionName, name, data ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'rowGroupOptions', optionName, name];

  if ( _.has( thisSpec, path ) ) _.set( thisSpec, path, data );

  return thisSpec;
}

export function reorderReportRowGroupOptionRules( nextSpec, reportName, optionName, reorderList ) {
  return reorderThings( nextSpec, ['data', 'reportNames', reportName, 'rowGroupOptions', optionName], reorderList );
}

export function deleteReportRowGroupOption( nextSpec, reportName, name, ifOnlyEmpty=true ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'rowGroupOptions', name];

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    let size = _.size( container );

    if ( !ifOnlyEmpty || ( ifOnlyEmpty && size === 0 ) ) {
      _.unset( thisSpec, path );
    }
  }

  return thisSpec;
}

export function deleteReportRowGroupOptionRule( nextSpec, reportName, optionName, name, deleteEmpty=true ) {
  let thisSpec = _.cloneDeep( nextSpec );

  let path = ['data', 'reportNames', reportName, 'rowGroupOptions', optionName, name];

  _.unset( thisSpec, path );

  if ( deleteEmpty ) {
    path.pop();
    if ( _.size( _.get( thisSpec, path, {} ) ) == 0 ) {
      _.unset( thisSpec, path );
    }
  }

  return thisSpec;
}

export function deleteReportRowGroupOptionRules( nextSpec, reportName, optionName, nameList, deleteEmpty=true ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'rowGroupOptions', optionName];

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    nameList.forEach( name => {
      if ( container.hasOwnProperty( name ) ) {
        delete container[ name ];
      }
    });
  }

  if ( deleteEmpty ) {
    if ( _.size( _.get( thisSpec, path, {} ) ) == 0 ) {
      _.unset( thisSpec, path );
    }
  }

  return thisSpec;
}

export function gatherReportRowGroupOptionRule( nextSpec, reportName, optionName, name, defaultData={} ) {
  let data = _.cloneDeep( defaultData );

  let specData = _.get( nextSpec,  ['data', 'reportNames', reportName, 'rowGroupOptions', optionName, name], null );

  if ( specData ) _.merge( data, specData );

  return _.cloneDeep( data );
}

export function existsReportRowGroupOption( nextSpec, reportName, name ) {
  let ok = false;

  if ( name !== null ) {
    let path = ['data', 'reportNames', reportName, 'rowGroupOptions'];

    if ( _.has( nextSpec, path ) ) {
      path.push( name.optionName );

      if ( _.has( nextSpec, path ) ) {
        path.push( name.ruleName );

        ok = _.has( nextSpec, path );
      }
    }
  }

  return ok;
}

export function existsReportRowGroupOptions( nextSpec, reportName ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'rowGroupOptions'] );
}

export function existsReportRowGroupOptionName( nextSpec, reportName, optionName ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'rowGroupOptions', optionName] );
}

export function existsReportRowGroupOptionRule( nextSpec, reportName, optionName, name ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'rowGroupOptions', optionName, name] );
}

export function gatherReportRowGroups( nextSpec, reportName ) {
  let list = [];

  let path = ['data', 'reportNames', reportName, 'rowGroupOptions'];

  _.forEach( _.get( nextSpec, path, [] ), (value, option) => {
    path.push( option );

    _.forEach( _.get( nextSpec, path, [] ), (value, rule) => {
      list.push({
        optionName: option,
          ruleName: rule,
      });
    });

    path.pop();
  });

  return list;
}

export function gatherReportRowGroupOptionNames( nextSpec, reportName ) {
  let names = _.get( nextSpec, ['data', 'reportNames', reportName, 'rowGroupOptions'], null );

  return ( names ? Object.keys( names ) : [] );
}

export function gatherReportRowGroupOptionRuleNames( nextSpec, reportName, optionName ) {
  let names = _.get( nextSpec, ['data', 'reportNames', reportName, 'rowGroupOptions', optionName], null );

  return ( names ? Object.keys( names ) : [] );
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// ImageSpecs Functions                                                     ///
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

export function insertReportImageSpec( nextSpec, reportName, name, data, key=null, pos="before" ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'imageSpecs'];

  let container = _.get( thisSpec, path, null );

  if ( container )
    _.set( thisSpec, path, insertKey( name, data, container, key, pos ) );

  return thisSpec;
}

export function appendReportImageSpec( nextSpec, reportName, name, data ) {
  return insertReportImageSpec( nextSpec, reportName, name, data );
}

export function prependReportImageSpec( nextSpec, reportName, name, data ) {
  return insertReportImageSpec( nextSpec, reportName, name, data, 0, 'before' );
}

export function updateReportImageSpec( nextSpec, reportName, name, data ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'imageSpecs', name];

  if ( _.has( thisSpec, path ) ) _.set( thisSpec, path, data );

  return thisSpec;
}

export function reorderReportImageSpecs( nextSpec, reportName, reorderList ) {
  return reorderThings( nextSpec, ['data', 'reportNames', reportName, 'imageSpecs'], reorderList );
}

export function deleteReportImageSpec( nextSpec, reportName, name ) {
  let thisSpec = _.cloneDeep( nextSpec );

  _.unset( thisSpec, ['data', 'reportNames', reportName, 'imageSpecs', name] );

  return thisSpec;
}

export function deleteReportImageSpecs( nextSpec, reportName, nameList ) {
  let thisSpec = _.cloneDeep( nextSpec );

  const path = ['data', 'reportNames', reportName, 'imageSpecs'];

  let container = _.get( thisSpec, path, null );

  if ( container ) {
    nameList.forEach( function( name ) {
      if ( container.hasOwnProperty( name ) ) {
        delete container[ name ];
      }
    });
  }

  return thisSpec;
}

export function gatherReportImageSpec( nextSpec, reportName, name, defaultData={} ) {
  let data = _.cloneDeep( defaultData );

  let specData = _.get( nextSpec, ['data', 'reportNames', reportName, 'imageSpecs', name], null );

  if ( specData ) _.merge( data, specData );

  return _.cloneDeep( data );
}

export function existsReportImageSpecs( nextSpec, reportName ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'imageSpecs'] );
}

export function existsReportImageSpec( nextSpec, reportName, name ) {
  return _.has( nextSpec, ['data', 'reportNames', reportName, 'imageSpecs', name] );
}

export function gatherReportImageSpecNames( nextSpec, reportName ) {
  let names = _.get( nextSpec, ['data', 'reportNames', reportName, 'imageSpecs'], null );

  return ( names ? Object.keys( names ) : [] );
}

export function gatherReportContextMenuValues(
  nextSpec,
  reportName,
  defaultData = {},
  index = 0
) {
  let data = _.cloneDeep(defaultData);

  let specData = _.get(
    nextSpec,
    ["data", "reportNames", reportName, "contextMenu", index],
    null
  );

  if (specData) _.merge(data, specData);

  return _.cloneDeep(data);
}

export function updateReportContextMenu(
  nextSpec,
  reportName,
  data = {},
  index = 0
) {
  let thisSpec = _.cloneDeep(nextSpec);

  const path = ["data", "reportNames", reportName, "contextMenu", index];

   _.set(thisSpec, path, data);

  return thisSpec;
}

export function gatherContextMenu(nextSpec, reportName) {
  const contextMenu = _.get(
    nextSpec,
    ["data", "reportNames", reportName, "contextMenu"],
    []
  );

  return contextMenu;
}

export function gatherReportContextMenu(nextSpec, reportName) {
  let contextMenu = _.get(
    nextSpec,
    ["data", "reportNames", reportName, "contextMenu"],
    []
  );

  return contextMenu ;
}

export function reorderReportContextMenu(
  nextSpec,
  reportName,
  newConextMenuList
) {
  const newNextSpec = _.set(
    _.cloneDeep(nextSpec),
    ["data", "reportNames", reportName, "contextMenu"],
    newConextMenuList
  );

  return newNextSpec
}

export function deleteReportContextMenus(nextSpec, reportName, menuIndexList) {
  let thisSpec = _.cloneDeep(nextSpec);

  for (let i = 0; i < menuIndexList.length; i++) {
    _.unset(thisSpec, ["data", "reportNames", reportName, "contextMenu", i]);
  }
  return thisSpec;
}

export function deleteReportContextMenu(nextSpec, reportName, menuIndex) {
  let thisSpec = _.cloneDeep(nextSpec);

  const contextMenu = _.get(
    thisSpec,
    ["data", "reportNames", reportName, "contextMenu"],
    []
  );

  if (contextMenu) contextMenu.splice(menuIndex, 1);

  return thisSpec;
}


////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
