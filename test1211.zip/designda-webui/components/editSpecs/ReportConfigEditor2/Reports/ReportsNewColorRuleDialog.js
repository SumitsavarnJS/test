////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportsNewColorRuleDialog.js#7 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/12 13:57:36 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
//import Modal from "react-bootstrap/Modal";

import { ButtonGroup, TextField, Modal, Box } from "@mui/material";

import _ from "lodash";

import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import "./ReportsNewColorRuleDialog.module.css";

class ReportsNewColorRuleDialog extends React.Component {
  constructor(props) {
    super(props);

    /*
     * Props:
     *   show           : Boolean: if true show the dialog
     *   reportName     : Name of the current report (should never be null)
     *   colorRuleName  : Name of the color rule {.blockName, .checkpointName, .metricName} (could be null)
     *   dialogMode     : One of 'Insert', 'Copy', or 'New'
     *   nextSpec       : The JSON data that is being worked on
     *   submitAnswer   : Command to submit the answer
     */

    const state = this.gatherState();

    this.state = {
      blockName: state.blockName,
      blockNameErrorState: state.blockNameErrorState,
      blockNameErrorText: state.blockNameErrorText,

      checkpointName: state.checkpointName,
      checkpointNameErrorState: state.checkpointNameErrorState,
      checkpointNameErrorText: state.checkpointNameErrorText,

      metricName: state.metricName,
      metricNameErrorState: state.metricNameErrorState,
      metricNameErrorText: state.metricNameErrorText,
    };
  }

  render() {
    let boxStyle = {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "auto",
      bgcolor: "background.paper",
      border: "2px solid #000",
      boxShadow: 24,
      borderRadius: "15px",
      p: 4,
    };
    let content = (
      <Modal open={this.props.show}>
        <Box sx={boxStyle}>
          <Box id="ModalHeader">
            <h2>Enter Block, Checkpoint and Metric names</h2>
          </Box>

          <Box>
            <TextField
              label="Block Name"
              fullWidth={true}
              variant="filled"
              name="blockName"
              value={this.state.blockName}
              onChange={this.handleBlockNameChanged}
              error={this.state.blockNameErrorState}
              helperText={this.state.blockNameErrorText}
            />
            <TextField
              label="Checkpoint Name"
              fullWidth={true}
              variant="filled"
              name="checkpointName"
              value={this.state.checkpointName}
              onChange={this.handleCheckpointNameChanged}
              error={this.state.checkpointNameErrorState}
              helperText={this.state.checkpointNameErrorText}
              disabled={this.state.blockNameErrorState}
            />
            <TextField
              label="Metric Name"
              fullWidth={true}
              variant="filled"
              name="metricName"
              value={this.state.metricName}
              onChange={this.handleMetricNameChanged}
              error={this.state.metricNameErrorState}
              helperText={this.state.metricNameErrorText}
              disabled={
                this.state.blockNameErrorState ||
                this.state.checkpointNameErrorState
              }
            />
          </Box>

          <Box>
            <ButtonGroup>
              <ThemedButton
                text="Accept"
                onClick={this.handleAcceptButton}
                disabled={
                  this.state.blockNameErrorState ||
                  this.state.checkpointNameErrorState ||
                  this.state.metricNameErrorState
                }
              />
              <ThemedButton
                text="Cancel"
                type="cancel"
                onClick={this.handleCancelButton}
              />
            </ButtonGroup>
          </Box>
        </Box>
      </Modal>
    );

    return content;
  }

  handleResize = () => {};

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    this.handleResize();

    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      if (
        !_.isEqual(this.props.colorRuleName, prevProps.colorRuleName) ||
        !_.isEqual(this.props.dialogMode, prevProps.dialogMode) ||
        !_.isEqual(this.props.reportName, prevProps.reportName)
      ) {
        this.setState(this.gatherState());
      }
    }
  }

  componentWillUnmount() {}

  gatherState() {
    let state = {};

    if (_.isNull(this.props.colorRuleName)) {
      state.blockName = "";
      state.checkpointName = "";
      state.metricName = "";
    } else {
      state.blockName = this.props.colorRuleName.blockName;
      state.checkpointName = this.props.colorRuleName.checkpointName;
      state.metricName =
        this.props.dialogMode == "Copy"
          ? this.props.colorRuleName.metricName
          : "";
    }

    [state.blockNameErrorState, state.blockNameErrorText] = this.checkBlockName(
      state.blockName
    );
    [state.checkpointNameErrorState, state.checkpointNameErrorText] =
      this.checkCheckpointName(state.blockName, state.checkpointName);
    [state.metricNameErrorState, state.metricNameErrorText] =
      this.checkMetricName(
        state.blockName,
        state.checkpointName,
        state.metricName
      );

    return state;
  }

  checkBlockName(blockName) {
    let errorState = false;
    let errorText = "Ok";

    if (blockName.length == 0) {
      errorState = true;
      errorText = "Value cannot be blank";
    }

    return [errorState, errorText];
  }

  checkCheckpointName(blockName, checkpointName) {
    let errorState = false;
    let errorText = "Ok";

    if (blockName.length == 0) {
      errorState = true;
      errorText = "Missing block name";
    } else if (checkpointName.length == 0) {
      errorState = true;
      errorText = "Value cannot be blank";
    }

    return [errorState, errorText];
  }

  checkMetricName(blockName, checkpointName, metricName) {
    let errorState = false;
    let errorText = "Ok";

    if (blockName.length == 0) {
      errorState = true;
      errorText = "Missing block name";
    } else if (checkpointName.length == 0) {
      errorState = true;
      errorText = "Missing checkpoint name";
    } else if (metricName.length == 0) {
      errorState = true;
      errorText = "Value cannot be blank";
    } else if (
      rf.existsReportColoringRuleName(
        this.props.nextSpec,
        this.props.reportName,
        blockName,
        checkpointName,
        metricName
      )
    ) {
      errorState = true;
      errorText = "Color rule name already exists";
    }

    return [errorState, errorText];
  }

  handleBlockNameChanged = (e) => {
    let nextState = {};

    nextState.blockName = e.target.value;

    [nextState.blockNameErrorState, nextState.blockNameErrorText] =
      this.checkBlockName(nextState.blockName);

    [nextState.checkpointNameErrorState, nextState.checkpointNameErrorText] =
      this.checkCheckpointName(nextState.blockName, this.state.checkpointName);

    [nextState.metricNameErrorState, nextState.metricNameErrorText] =
      this.checkMetricName(
        nextState.blockName,
        this.state.checkpointName,
        this.state.metricName
      );
    this.setState(nextState);
  };

  handleCheckpointNameChanged = (e) => {
    let nextState = {};

    nextState.checkpointName = e.target.value;

    [nextState.checkpointNameErrorState, nextState.checkpointNameErrorText] =
      this.checkCheckpointName(this.state.blockName, nextState.checkpointName);

    [nextState.metricNameErrorState, nextState.metricNameErrorText] =
      this.checkMetricName(
        this.state.blockName,
        nextState.checkpointName,
        this.state.metricName
      );
    this.setState(nextState);
  };

  handleMetricNameChanged = (e) => {
    let nextState = {};

    nextState.metricName = e.target.value;

    [nextState.metricNameErrorState, nextState.metricNameErrorText] =
      this.checkMetricName(
        this.state.blockName,
        this.state.checkpointName,
        nextState.metricName
      );
    this.setState(nextState);
  };

  handleCancelButton = () => {
    this.props.submitAnswer(false, {});
  };

  okToAccept() {
    return (
      !this.state.blockNameErrorState &&
      !this.state.checkpointNameErrorState &&
      !this.state.metricNameErrorState
    );
  }

  handleAcceptButton = () => {
    if (this.okToAccept()) {
      this.props.submitAnswer(true, {
        blockName: this.state.blockName,
        checkpointName: this.state.checkpointName,
        metricName: this.state.metricName,
      });
    }
  };
}

export default ReportsNewColorRuleDialog;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
