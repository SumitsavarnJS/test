////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportMetricsNewDialog.js#15 $
// HEADER_MSG $Author: banakar $
// HEADER_MSG $DateTime: 2023/06/28 01:12:19 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
//import Modal from "react-bootstrap/Modal";

import { ReactTabulator } from "react-tabulator";

import { ButtonGroup, TextField, Tooltip, Modal, Box } from "@mui/material";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import "./ReportMetricsNewDialog.module.css";

function checkMetricName(metricName, validItemList) {
  let errorState = false;
  let errorText = "Ok";

  if (!metricName || (metricName && metricName.length == 0)) {
    errorState = true;
    errorText = "Value cannot be blank";
  } else if (validItemList.includes(metricName)) {
    errorState = true;
    errorText = metricName + " already exists!";
  }

  return [errorState, errorText];
}

class ReportMetricsNewDialog extends React.Component {
  constructor(props) {
    super(props);

    /*!
     * Props:
     *   show              : [Boolean]
     *   title             : [String]
     *   reportName        : [String]
     *   suggestedName     : [String]
     *   nextSpec          : [Object]
     *   submitAnswer      : [Function]
     *   selectedList      : [Array]
     *   validMetricsList  : [Array]
     *   enableCreateNew   : [Boolean]   Allow user to provide thier own name for a metric
     *   enableCreateList  : [Boolean]   Allow user to select from a list of metrics
     */

    const state = this.gatherState();

    this.state = {
      metricName: state.metricName,
      selectedList: state.selectedList,
      errorState: state.errorState,
      errorText: state.errorText,
    };

    this.mouseOver = false;

    this.tableRef = React.createRef();
  }

  render() {
    let tableInfo = this.getTableInfo();

    let createNew = (
      <div>
        <div>Enter a name here to create metric from scratch:</div>
        <TextField
          fullWidth
          label="Metric Name"
          name="metricName"
          variant="filled"
          value={this.state.metricName}
          onChange={this.handleValueChange}
          error={this.state.errorState}
          helperText={this.state.errorText}
        />
      </div>
    );

    let createList = (
      <div id="divEditorTop_ReportMetricsNewDialog_Table">
        <ReactTabulator
          onRef={(r) => (this.tableRef = r)}
          options={tableInfo.tableOptions}
          events={tableInfo.tableEvents}
        />
      </div>
    );

    let body = null;

    if (this.props.enableCreateNew && this.props.enableCreateList) {
      body = (
        <div>
          {createNew}
          <div>...or select an existing metric from the list below:</div>
          {createList}
        </div>
      );
    } else if (this.props.enableCreateNew && !this.props.enableCreateList) {
      body = <div>{createNew}</div>;
    } else {
      body = <div>{createList}</div>;
    }

    let boxStyle = {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "auto",
      bgcolor: "background.paper",
      border: "2px solid #000",
      boxShadow: 24,
      borderRadius: "15px",
      p: 4,
    };

    let content = (
      <Modal open={this.props.show}>
        <Box sx={boxStyle}>
          <Box id="ModalHeader">
            <h2>{this.props.title}</h2>
          </Box>

          <Box>{body}</Box>

          <Box>
            <ButtonGroup>
              <ThemedButton
                text="Accept"
                disabled={
                  checkMetricName(
                    this.state.metricName,
                    this.props.validMetricsList
                  )[0] &
                  (this.state.selectedList.length == 0)
                }
                onClick={this.handleAcceptButton}
              />
              <ThemedButton
                text="Cancel"
                type="cancel"
                onClick={this.handleCancelButton}
              />
            </ButtonGroup>
          </Box>
        </Box>
      </Modal>
    );

    return content;
  }

  handleResize = () => {
    try {
      if (this.tableRef) {
        let table = this.tableRef.current;

        if (table) {
          table.setHeight(this.getTableHeight());
        }
      }
    } catch (e) {
      console.log("Could not resize:", e);
    }
  };

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    this.handleResize();

    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      if (
        !_.isEqual(this.props.reportName, prevProps.reportName) ||
        !_.isEqual(this.props.suggestedName, prevProps.suggestedName) ||
        !_.isEqual(this.props.validMetricsList, prevProps.validMetricsList) ||
        !_.isEqual(this.props.selectedList, prevProps.selectedList) ||
        !_.isEqual(this.props.enableCreateNew, prevProps.enableCreateNew) ||
        !_.isEqual(this.props.enableCreateList, prevProps.enableCreateList)
      ) {
        this.setState(this.gatherState());
      }
    }
  }

  componentWillUnmount() {}

  gatherState() {
    let state = {};

    state.metricName = this.props.suggestedName ? this.props.suggestedName : "";

    state.selectedList = this.props.selectedList ? this.props.selectedList : [];

    [state.errorState, state.errorText] = checkMetricName(
      state.metricName,
      this.props.validMetricsList
    );

    return state;
  }

  getTableHeight = () => {
    let tableHeight = 300;
    let windowHeight = document.documentElement.clientHeight;

    let table = document.getElementById(
      "divEditorTop_ReportMetricsNewDialog_Table"
    );
    if (table == null) {
      return tableHeight;
    }

    let modalFooter = document.getElementById("ModalFooter");
    if (modalFooter == null) {
      return tableHeight;
    }

    let tableRect = table.getBoundingClientRect();
    let modalFooterRect = modalFooter.getBoundingClientRect();

    tableHeight = windowHeight - tableRect.top - modalFooterRect.height * 2;

    return tableHeight;
  };

  getTableInfo() {
    let r = {};

    r.tableColumns = [
      {
        title: "Metric",
        field: "name",
        headerFilter: funcs.customInput,
        headerFilterFunc: funcs.globFilter,
        headerTooltip: funcs.globFilterDisplayValueTooltip,
      }, // Metric Name Column
    ];

    r.tableData = [];

    this.props.validMetricsList.forEach(function (name) {
      r.tableData.push({
        name: name,
      });
    });

    r.tableOptions = {};
    r.tableOptions.columnDefaults = {
      headerFilterPlaceholder: funcs.headerFilterPlaceholderText(),
    };
    r.tableOptions.columns = r.tableColumns;
    r.tableOptions.data = r.tableData;
    r.tableOptions.height = 300;
    r.tableOptions.index = "name";
    r.tableOptions.layout = "fitDataStretch";
    r.tableOptions.movableRows = true;
    r.tableOptions.selectablePersistence = true;
    r.tableOptions.selectableRangeMode = "click";
    r.tableOptions.selectable = true;

    r.tableEvents = {};
    r.tableEvents.rowMouseEnter = this.handleRowMouseEnter;
    r.tableEvents.rowMouseLeave = this.handleRowMouseLeave;
    r.tableEvents.rowSelectionChanged = this.handleRowSelectionChanged;
    r.tableEvents.tableBuilt = this.handleAfterTableBuilt;

    return r;
  }

  handleValueChange = (e) => {
    let metricName = e.target.value;

    const [errorState, errorText] = checkMetricName(
      metricName,
      this.props.validMetricsList
    );

    this.setState({
      metricName: e.target.value,
      errorState: errorState,
      errorText: errorText,
    });
  };

  handleCancelButton = () => {
    this.props.submitAnswer(false, "");
  };

  handleAcceptButton = () => {
    let metricsList = this.state.selectedList;

    if (this.props.enableCreateNew) {
      if (this.state.metricName.length > 0) {
        metricsList = [this.state.metricName];
      }
    }

    this.props.submitAnswer(true, metricsList);

    this.setState({
      metricName: null,
      errorState: "Ok",
      errorText: false,
    });
  };
  handleRowMouseEnter = (e, row) => {
    this.mouseOver = true;
  };

  handleRowMouseLeave = (e, row) => {
    this.mouseOver = false;
  };

  handleRowSelectionChanged = (row) => {
    let table = this.tableRef.current;

    if (!this.mouseOver && row.length == 0) return; // Ignore empty selections with not set by user.

    let selectedRows = table.getSelectedRows();

    let selectedList = [];

    selectedRows.forEach(function (row) {
      selectedList.push(row.getData().name);
    });

    if (!_.isEqual(selectedList, this.state.selectedList)) {
      this.setState({
        selectedList: selectedList,
      });
    }
  };

  handleAfterTableBuilt = () => {
    let table = this.tableRef.current;

    table.deselectRow();
    table.selectRow(this.state.selectedList);

    table.setHeight(this.getTableHeight());

    if (this.state.selectedList.length == 1) {
      table.scrollToRow(this.state.selectedList[0], "center", false);
    } else {
      table.rowManager.element.scrollTop = 0;
    }
  };
}

export default ReportMetricsNewDialog;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
