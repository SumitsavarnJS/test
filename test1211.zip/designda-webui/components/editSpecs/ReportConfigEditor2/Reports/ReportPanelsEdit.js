////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportPanelsEdit.js#10 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/10 07:05:18 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";

import {
  ButtonGroup,
  FilledInput,
  FormControl,
  IconButton,
  InputAdornment,
  InputLabel,
  MenuItem,
  Select,
  SvgIcon,
} from "@mui/material";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import ReportsNewDialog from "components/editSpecs/ReportConfigEditor2/Reports/ReportsNewDialog";
import ReportMetricsNewDialog from "components/editSpecs/ReportConfigEditor2/Reports/ReportMetricsNewDialog";

import styles from  "./ReportPanelsEdit.module.css";

/*
 *  panels: {
 *    <plotNameN>: {
 *      type: <str=[line, barH, barV, pie, spider]>
 *      incParent: <boolean>
 *      data: [ <metricNameN> ]
 *    }
 *  }
 */

const defaultPanelDef = Object.freeze({
  type: "line",
  incParent: false,
  data: [],
});

class ReportPanelsEdit extends React.Component {
  constructor(props) {
    super(props);

    const state = this.gatherState();

    this.state = {
      value: state.value,
      metrics: state.metrics,

      validMetricsList: state.validMetricsList,

      dialogPanelShow: false,
      dialogPanelMode: null,

      dialogMetricsShow: false,
    };
  }

  render() {
    let content = null;

    let newMetricDialog = (
      <ReportMetricsNewDialog
        show={this.state.dialogMetricsShow}
        title="Select Metrics to Measure"
        reportName={this.props.reportName}
        nextSpec={this.props.nextSpec}
        submitAnswer={this.handleNewMetricSubmitAnswer}
        selectedList={this.state.value.data}
        validMetricsList={this.state.validMetricsList}
        enableCreateNew={false}
        enableCreateList={true}
      />
    );

    let newPanelDialog = (
      <ReportsNewDialog
        show={this.state.dialogPanelShow}
        title="Enter Panel Name"
        itemLabel="Panel Name"
        suggestedName={this.state.dialogPanelMode==='Copy' ? this.props.panelName : null}
        validItemList={rf.gatherReportPanelNames( this.props.nextSpec, this.props.reportName )}
        submitAnswer={this.handleNewPanelSubmitAnswer}
      />
    );

    if ( this.props.panelName == null ) {
      if ( this.props.selectedList.length == 0 ) {
        let addNewButton = (
          <ThemedButton text="New Panel" onClick={this.handleNewPanelButton} />
        );

        content = ( <div>
                      <h3>Getting Started</h3>
                      <ul>
                        <li>{addNewButton}</li>
                        <li>or select a single panel on the left to edit</li>
                        <li>or select a group of panels to delete</li>
                      </ul>
                      {newPanelDialog}
                      {newMetricDialog}
                    </div> );
      } else {
        let deleteSelectedButton = (
          <ThemedButton text="Delete Selected" type="alert" onClick={this.handleDeleteSelectedButton} />
        );

        content = ( <div>
                      <h3>Getting Started</h3>
                      <ul>
                        <li>{deleteSelectedButton}</li>
                      </ul>
                    </div> );
      }
    } else {

      let buttonGroupLeft  = (
        <ButtonGroup>
          <ThemedButton text="Insert Panel" onClick={this.handleInsertPanelButton} />
          <ThemedButton text="Copy Panel" onClick={this.handleCopyPanelButton} />
          <ThemedButton text="Delete Panel" type="alert" onClick={this.handleDeletePanelButton} />
        </ButtonGroup>
      );

      let buttonGroupRight = (
        <ButtonGroup>
          <ThemedButton text="Apply" onClick={this.handleApplyButton} />
          <ThemedButton text="Reset" type="alert" onClick={this.handleResetButton} />
        </ButtonGroup>
      );

      let currentPanelNameLabel = (
        <div id="divEditorTop_ReportPanelsEdit_Label" className={styles.divEditorTop_ReportPanelsEdit_Label}>{this.props.panelName}</div>
      );

      const plotTypeMenuItems = rf.reportSelectListTable.plotTypeList.map((item) =>
        <MenuItem key={item.key} value={item.value}>{item.title}</MenuItem>
      );

      let plotTypeInput = (
        <FormControl fullWidth variant="filled" >
          <InputLabel>Panel Type</InputLabel>
          <Select
            variant="filled"
            name="value.type"
            value={this.state.value.type}
            onChange={this.handleValueChange}
          >
            {plotTypeMenuItems}
          </Select>
        </FormControl>
      );

      const incParentMenuItems = rf.reportSelectListTable.booleanList.map((item) =>
        <MenuItem key={item.key} value={item.value}>{item.title}</MenuItem>
      );

      let incParentInput = (
        <FormControl fullWidth variant="filled" >
          <InputLabel>Include Parent?</InputLabel>
          <Select
            variant="filled"
            name="value.incParent"
            value={this.state.value.incParent}
            onChange={this.handleValueChange}
          >
            {incParentMenuItems}
          </Select>
        </FormControl>
      );

      let dataInput = (
        <FormControl fullWidth variant="filled">
          <InputLabel>Source Metrics</InputLabel>
          <FilledInput
            name="metrics"
            value={this.state.metrics}
            onChange={this.handleMetricsChange}
            endAdornment={
              <InputAdornment position="end">
                <IconButton onClick={this.handleSelectMetricsButton}>
                  <SvgIcon>
                    <path fill="#6e756e" stroke="#6e756e" strokeWidth="1"
                          d="M 20.41,11.00 C 20.41,12.41 19.26,13.56 17.85,13.56 16.44,13.56 15.29,12.41 15.29,11.00 15.29,9.59 16.44,8.44 17.85,8.44 19.26,8.44 20.41,9.59 20.41,11.00 Z M 13.56,11.00 C 13.56,12.41 12.41,13.56 11.00,13.56 9.59,13.56 8.44,12.41 8.44,11.00 8.44,9.59 9.59,8.44 11.00,8.44 12.41,8.44 13.56,9.59 13.56,11.00 Z M 6.71,11.00 C 6.71,12.41 5.56,13.56 4.15,13.56 2.74,13.56 1.59,12.41 1.59,11.00 1.59,9.59 2.74,8.44 4.15,8.44 5.56,8.44 6.71,9.59 6.71,11.00 Z" />
                  </SvgIcon>
                </IconButton>
              </InputAdornment>
            }
          />
        </FormControl>
      );

      content = (
        <div id="divEditorTop_ReportPanelsEdit_Top" className={styles.divEditorTop_ReportPanelsEdit_Top}>
          
          <div>
          {currentPanelNameLabel}
          <div id="divEditorTop_ReportPanelsEdit_Input" className={styles.divEditorTop_ReportPanelsEdit_Input}>
            {plotTypeInput}
            {incParentInput}
            {dataInput}
          </div>

          <div id="divEditorTop_ReportPanelsEdit_Buttons" className={styles.divEditorTop_ReportPanelsEdit_Buttons}>
            <div id="divEditorTop_ReportPanelsEdit_JustifyLeft" className={styles.divEditorTop_ReportPanelsEdit_JustifyLeft}>
              {buttonGroupLeft}
            </div>
            <div id="divEditorTop_ReportPanelsEdit_JustifyRight" className={styles.divEditorTop_ReportPanelsEdit_JustifyRight}>
              {buttonGroupRight}
            </div>
          </div>
          </div>

          {newPanelDialog}
          {newMetricDialog}
        </div>
      );
    }

    return content;
  }

  handleResize = () => {
    let divInput   = document.getElementById( "divEditorTop_ReportPanelsEdit_Input" );
    let divButtons = document.getElementById( "divEditorTop_ReportPanelsEdit_Buttons" );

    if ( divInput == null || divButtons == null ) {
      return
    }

    const winHeight = document.documentElement.clientHeight;

    const rectInput   = divInput.getBoundingClientRect();
    const rectButtons = divButtons.getBoundingClientRect();

    const newY = winHeight - rectButtons.height;

    const delta = newY - rectButtons.y;

    const newHeight = rectInput.height + delta - 5;

    divInput.style.height = newHeight + "px";
  }

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate( prevProps, prevState ) {
    this.handleResize();

    const isOutsideChange = !_.isEqual( prevProps, this.props );

    if ( isOutsideChange ) {
      const reportChanged = ( prevProps.reportName !== this.props.reportName );
      const panelChanged  = ( prevProps.panelName  !== this.props.panelName );
      const valueChanged  = !_.isEqual( prevState.value, this.gatherValue() );

      if ( reportChanged || panelChanged || valueChanged ) {
        this.setState( this.gatherState() );
      }
    }

    this.props.updateDirty( this.isDirty() );
  }

  componentWillUnmount() {
  }

  gatherState() {
    let state = {};

    state.value = this.gatherValue();
    state.metrics = _.join( state.value.data, ',' );
    state.validMetricsList = this.gatherMetricsList();

    return state;
  }

  gatherValue() {
    let value = _.cloneDeep( defaultPanelDef );

    if ( this.props.reportName && this.props.panelName ) {
      value = rf.gatherReportPanel( this.props.nextSpec, this.props.reportName, this.props.panelName, defaultPanelDef );
    }

    return value;
  }

  gatherMetricsList() {
    return rf.gatherReportMetricNames( this.props.nextSpec, this.props.reportName );
  }

  isDirty() {
    let state = this.gatherState();

    let clean = ( _.isEqual( state.value, this.state.value ) );

    return !clean;
  }

  handleMetricsChange = (e) => {
    let metrics = e.target.value;

    let value = _.cloneDeep( this.state.value );
    value.data = _.split( metrics, ',' );

    let nextState = {};

    nextState.value   = value;
    nextState.metrics = metrics;

    this.setState( nextState );
  }

  handleValueChange = (e) => {
    let nextState = {
      value: _.cloneDeep( this.state.value )
    };

    _.set( nextState, e.target.name, e.target.value );

    this.setState( nextState );
  }

  handleNewPanelSubmitAnswer = ( accept, newPanelName ) => {
    if ( accept && newPanelName.length > 0 ) {
      let nextSpec = null;

      if ( this.state.dialogPanelMode == 'New' ) {

        this.props.insertRow( newPanelName );

        nextSpec = rf.insertReportPanel( this.props.nextSpec, this.props.reportName, newPanelName, defaultPanelDef );

      } else if ( this.state.dialogPanelMode == 'Copy' ) {

        this.props.insertRow( newPanelName, this.props.panelName );

        let newPanelValue = this.state.value;

        nextSpec = rf.insertReportPanel( this.props.nextSpec, this.props.reportName, newPanelName, newPanelValue, this.props.panelName, "after" );

      } else if ( this.state.dialogPanelMode == 'Insert' ) {

        this.props.insertRow( newPanelName, this.props.panelName );

        nextSpec = rf.insertReportPanel( this.props.nextSpec, this.props.reportName, newPanelName, defaultPanelDef, this.props.panelName, "after" );
      }

      if ( nextSpec ) this.props.updateNextSpec( nextSpec );
    }

    this.setState({
      dialogPanelShow: false,
      dialogPanelMode: null,
    });
  }

  handleNewPanelButton = () => {
    this.setState({
      dialogPanelShow: true,
      dialogPanelMode: 'New',
    });
  }

  handleInsertPanelButton = () => {
    this.setState({
      dialogPanelShow: true,
      dialogPanelMode: 'Insert',
    });
  }

  handleCopyPanelButton = () => {
    this.setState({
      dialogPanelShow: true,
      dialogPanelMode: 'Copy',
    });
  }

  handleNewMetricSubmitAnswer = (accept, metricsList) => {
    let nextState = {
      dialogMetricsShow: false
    };

    if ( accept ) {
      let value = _.cloneDeep( this.state.value );

      value.data = metricsList;

      nextState.value = value;
      nextState.metrics = metricsList.join(',');
    }

    this.setState( nextState );
  }

  handleSelectMetricsButton = () => {
    this.setState({
      dialogMetricsShow: true,
    });
  }

  handleDeleteSelectedButton = () => {
    this.props.deleteRows( this.props.selectedList );

    let nextSpec = rf.deleteReportPanels( this.props.nextSpec, this.props.reportName, this.props.selectedList );

    this.props.updateNextSpec( nextSpec );
  }

  handleDeletePanelButton = () => {
    this.props.deleteRow( this.props.panelName );

    let nextSpec = rf.deleteReportPanel( this.props.nextSpec,
                                         this.props.reportName,
                                         this.props.panelName );

    this.props.updateNextSpec( nextSpec );
  }

  handleApplyButton = () => {
    let value = _.cloneDeep( this.state.value );

    value.data = _.split( this.state.metrics, ',' );

    let nextSpec = rf.updateReportPanel( this.props.nextSpec,
                                         this.props.reportName,
                                         this.props.panelName,
                                         value );

    this.props.updateNextSpec( nextSpec );
  }

  handleResetButton = () => {
    this.setState( this.gatherState() );
  }
}

export default ReportPanelsEdit;

////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
