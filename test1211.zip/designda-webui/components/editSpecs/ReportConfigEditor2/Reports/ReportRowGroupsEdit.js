////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportRowGroupsEdit.js#17 $
// HEADER_MSG $Author: banakar $
// HEADER_MSG $DateTime: 2023/06/28 01:12:19 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";

import { ReactTabulator } from "react-tabulator";

import {
  ButtonGroup,
  FilledInput,
  FormControl,
  IconButton,
  InputAdornment,
  InputLabel,
  SvgIcon,
  TextField,
} from "@mui/material";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import ReportsNewRowGroupDialog from "components/editSpecs/ReportConfigEditor2/Reports/ReportsNewRowGroupDialog";

import styles from "./ReportRowGroupsEdit.module.css";

/*
 *  rowGroupOptions: {
 *    <rowGroupOptionNameN>: {
 *      <ruleNameN>: {
 *        fieldName: <str>
 *        rxList: [ <regexpN> ],
 *        defaultGroup: <str>
 *      }
 *    }
 *  }
 */

const defaultRowGroupRuleDef = Object.freeze({
  fieldName: "",
  rxList: [],
  defaultGroup: "",
});

class ReportRowGroupsEdit extends React.Component {
  constructor(props) {
    super(props);

    const state = this.gatherState();

    this.state = {
      value: state.value,

      newRegExp: state.newRegExp,

      dialogShow: false,
      dialogMode: 'New',
    };

    this.tableBuilt = false;
    this.tableRef = React.createRef();
  }

  render() {
    let content = null;

    let newRowGroupDialog = (
      <ReportsNewRowGroupDialog
        show={this.state.dialogShow}
        reportName={this.props.reportName}
        rowGroupName={this.props.rowGroupName}
        dialogMode={this.state.dialogMode}
        nextSpec={this.props.nextSpec}
        submitAnswer={this.handleNewSubmitAnswer}
      />
    );

    if ( this.props.rowGroupName == null ) {
      if ( this.props.selectedList.length == 0 ) {
        let addNewButton = (
          <ThemedButton text="New Row Group" onClick={this.handleNewRowGroup} />
        );

        content = ( <div>
                      <h3>Getting Started</h3>
                      <ul>
                        <li>{addNewButton}</li>
                        <li>or select a single row group rule on the left to edit</li>
                        <li>or select a group of row group rules to delete</li>
                      </ul>

                      {newRowGroupDialog} 
                    </div> );
      } else {
        let deleteSelectedButton = (
          <ThemedButton text="Delete Selected" type="alert" onClick={this.handleDeleteSelectedButton} />
        );

        content = ( <div>
                      <h3>Getting Started</h3>
                      <ul>
                        <li>{deleteSelectedButton}</li>
                      </ul>
                    </div> );
      }
    } else {

      let buttonGroupLeft  = (
        <ButtonGroup>
          <ThemedButton text="Insert Row Group" onClick={this.handleInsertRowGroupButton} />
          <ThemedButton text="Copy Row Group" onClick={this.handleCopyRowGroupButton} />
          <ThemedButton text="Delete Row Group" type="alert" onClick={this.handleDeleteRowGroupButton} />
        </ButtonGroup>
      );

      let buttonGroupRight = (
        <ButtonGroup>
          <ThemedButton text="Apply" onClick={this.handleApplyButton} />
          <ThemedButton text="Reset" type="alert" onClick={this.handleResetButton} />
        </ButtonGroup>
      );

      let currentRowGroupNameLabel = (
        <div id="divEditorTop_ReportRowGroupsEdit_Label" className={styles.divEditorTop_ReportRowGroupsEdit_Label}>{this.props.rowGroupName.optionName}/{this.props.rowGroupName.ruleName}</div>
      );

      let fieldNameInput = (
        <TextField
          label="Field Name"
          fullWidth={true}
          variant="filled"
          name="value.fieldName"
          value={this.state.value.fieldName}
          onChange={this.handleValueChange}
        />
      );


      let info = this.fillTable();

      let rxListInput = (
        <div>
          <FormControl fullWidth variant="filled">
            <InputLabel>Enter Regular Expression here, press + to add to list</InputLabel>
            <FilledInput id="divEditorTop_ReportRowGroupsEdit_Entry"
              className={styles.divEditorTop_ReportRowGroupsEdit_Entry}
              name="newRegExp"
              value={this.state.newRegExp}
              onChange={this.handleValueChange}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton onClick={this.handleInsertNewRegExp}>
                    <SvgIcon>
                      <path fill="#6e756e" stroke="#6e756e" strokeWidth="1"
                            d="M 19.57,12.61 C 19.57,12.61 2.43,12.61 2.43,12.61 2.43,12.61 2.43,9.39 2.43,9.39 2.43,9.39 19.57,9.39 19.57,9.39 19.57,9.39 19.57,12.61 19.57,12.61 Z M 12.61,2.43 C 12.61,2.43 12.61,19.57 12.61,19.57 12.61,19.57 9.39,19.57 9.39,19.57 9.39,19.57 9.39,2.43 9.39,2.43 9.39,2.43 12.61,2.43 12.61,2.43 Z" />
                    </SvgIcon>
                  </IconButton>
                </InputAdornment>
              }
            />
            <div id="divEditorTop_ReportRowGroupsEdit_List" className={styles.divEditorTop_ReportRowGroupsEdit_List}>
              <ReactTabulator
                onRef={(r) => (this.tableRef = r)}
                columns={info.tableColumns}
                data={info.tableData}
                options={info.tableOptions}
                events={info.tableEvents}
              />
            </div>
          </FormControl>
        </div>
      );

      let defaultGroupInput = (
        <TextField
          label="Default Group"
          fullWidth={true}
          variant="filled"
          name="value.defaultGroup"
          value={this.state.value.defaultGroup}
          onChange={this.handleValueChange}
        />
      );

      content = (
        <div id="divEditorTop_ReportRowGroupsEdit_Top" className={styles.divEditorTop_ReportRowGroupsEdit_Top}>
          {currentRowGroupNameLabel}

          <div id="divEditorTop_ReportRowGroupsEdit_Input" className={styles.divEditorTop_ReportRowGroupsEdit_Input}>
            {fieldNameInput}
            {defaultGroupInput}
            {rxListInput}
          </div>

          <div id="divEditorTop_ReportRowGroupsEdit_Buttons" className={styles.divEditorTop_ReportRowGroupsEdit_Buttons}>
            <div id="divEditorTop_ReportRowGroupsEdit_JustifyLeft" className={styles.divEditorTop_ReportRowGroupsEdit_JustifyLeft}>
              {buttonGroupLeft}
            </div>
            <div id="divEditorTop_ReportRowGroupsEdit_JustifyRight" className={styles.divEditorTop_ReportRowGroupsEdit_JustifyRight}>
              {buttonGroupRight}
            </div>
          </div>

          {newRowGroupDialog} 
        </div>
      );
    }

    return content;
  }

  handleResize = () => {
    let divInput   = document.getElementById( "divEditorTop_ReportRowGroupsEdit_Input" );
    let divButtons = document.getElementById( "divEditorTop_ReportRowGroupsEdit_Buttons" );

    if ( divInput == null || divButtons == null ) {
      return
    }

    const winHeight = document.documentElement.clientHeight;

    const rectInput   = divInput.getBoundingClientRect();
    const rectButtons = divButtons.getBoundingClientRect();

    const newY      = winHeight - rectButtons.height;
    const delta     = newY - rectButtons.y;
    const newHeight = rectInput.height + delta - 2;

    divInput.style.height = newHeight + "px";
  }

  componentDidMount() {
    window.addEventListener( "resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate( prevProps, prevState ) {
    this.handleResize();

    const isOutsideChange = !_.isEqual( prevProps, this.props );

    if ( isOutsideChange ) {
      const reportChanged   = ( prevProps.reportName   !== this.props.reportName );
      const rowGroupChanged = ( prevProps.rowGroupName !== this.props.rowGroupName );
      const valueChanged    = !_.isEqual( prevState.value, this.gatherValue() );

      if ( reportChanged || rowGroupChanged || valueChanged ) {
        this.setState( this.gatherState() );
      }
    }

    this.props.updateDirty( this.isDirty() );
  }

  componentWillUnmount() {
  }

  gatherState() {
    let state = {};

    state.value = this.gatherValue();
    state.newRegExp = '';

    return state;
  }

  gatherValue() {
    let value = _.cloneDeep( defaultRowGroupRuleDef );

    if ( this.props.reportName && this.props.rowGroupName ) {
      value = rf.gatherReportRowGroupOptionRule( this.props.nextSpec,
                                                 this.props.reportName, 
                                                 this.props.rowGroupName.optionName, 
                                                 this.props.rowGroupName.ruleName, 
                                                 defaultRowGroupRuleDef );
    }

    return value;
  }

  isDirty() {
    let state = this.gatherState();

    let clean = ( _.isEqual( state.value, this.state.value ) );

    return !clean;
  }

  getTableHeight = () => {
    if ( this.tableRef.current == null ) return 100;

    let divInput   = document.getElementById( "divEditorTop_ReportRowGroupsEdit_Input" );
    let divButtons = document.getElementById( "divEditorTop_ReportRowGroupsEdit_Buttons" );
    let divList    = document.getElementById( "divEditorTop_ReportRowGroupsEdit_List" );

    if ( divInput == null || divButtons == null || divList == null ) {
      return
    }

    const winHeight = document.documentElement.clientHeight;

    const rectInput   = divInput.getBoundingClientRect();
    const rectButtons = divButtons.getBoundingClientRect();

    const newY      = winHeight - rectButtons.height;
    const delta     = newY - rectButtons.y;
    const newHeight = rectInput.height + delta - 5;
    const rectList = divList.getBoundingClientRect();

    const a = newHeight + rectInput.y;
    const b = rectList.y + rectList.height;
    const h = a - b;

    const tableHeight = rectList.height + h - 5;

    return tableHeight;
  }

  fillTable = () => {
    let r = {};

    r.tableColumns = [
      {
        formatter: "buttonCross",
        hozAlign: "center",
        headerSort: false,
        cellClick: (e,cell) => this.handleDeleteNewRegExp( cell.getRow().getData().regexp ),
      },
      {
        title: "Regular Expression",
        field: "regexp",
        editor: "input",
      },
    ];

    r.tableData = [];

    let ndx = 0;

    _.forEach( this.state.value.rxList, (value) => {
      r.tableData.push({
        regexp: value,
        index: ndx++,
      });
    });

    r.tableOptions = {
      layout: "fitDataStretch",
      height: this.getTableHeight(),
      selectable: "highlight",
      index: "regexp",
      columns: r.tableColumns,
      data: r.tableData,
    };

    r.tableEvents = {
      tableBuilt: this.handleAfterTableBuilt,
      cellEdited: this.handleCellEdited,
    };

    return r;
  }

  handleNewRowGroup = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'New',
    });
  }

  handleInsertRowGroupButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'Insert',
    });
  }

  handleCopyRowGroupButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'Copy',
    });
  }

  handleDeleteSelectedButton = () => {
    let obj = {}

    this.props.selectedList.forEach( rowGroup => {
      let oName = rowGroup.optionName;
      let rName = rowGroup.ruleName;
      if ( obj.hasOwnProperty( oName ) ) {
        obj[ oName ].push( rName );
      } else {
        obj[ oName ] = [ rName ];
      }
    });

    let nextSpec = _.cloneDeep( this.props.nextSpec );

    _.forEach( obj, ( ruleNameList, optionName ) => {
      nextSpec = rf.deleteReportRowGroupOptionRules( nextSpec, this.props.reportName, optionName, ruleNameList );
    });

    this.props.deleteRows( this.props.selectedList );
    this.props.updateNextSpec( nextSpec );
  }

  handleDeleteRowGroupButton = () => {
    let nextSpec = rf.deleteReportRowGroupOptionRule( this.props.nextSpec,
                                                      this.props.reportName,
                                                      this.props.rowGroupName.optionName,
                                                      this.props.rowGroupName.ruleName );
    this.props.deleteRow({
      optionName: this.props.rowGroupName.optionName,
        ruleName: this.props.rowGroupName.ruleName
    });

    this.props.updateNextSpec( nextSpec );
  }

  handleNewSubmitAnswer = (accept, rowGroupName) => {
    const optionName = _.get( rowGroupName, 'optionName', null );
    const ruleName   = _.get( rowGroupName, 'ruleName', null );

    if ( accept && optionName && ruleName ) {

      if ( this.state.dialogMode === 'New' ) {
        let nextSpec = rf.insertReportRowGroupOptionRule( this.props.nextSpec, this.props.reportName, optionName, ruleName, defaultRowGroupRuleDef );

        this.props.insertRow( rowGroupName );
        this.props.updateNextSpec( nextSpec );

      } else if ( this.state.dialogMode == 'Insert' ) {
        let nextSpec = rf.insertReportRowGroupOptionRule( this.props.nextSpec, this.props.reportName, optionName, ruleName, defaultRowGroupRuleDef, this.state.ruleName, "after" );

        this.props.insertRow( rowGroupName, this.state.ruleName );
        this.props.updateNextSpec( nextSpec );

      } else if ( this.state.dialogMode == 'Copy' ) {
        let value = rf.gatherReportRowGroupOptionRule( this.props.nextSpec, this.props.reportName, this.props.rowGroupName.optionName, this.props.rowGroupName.ruleName );
        let nextSpec = rf.insertReportRowGroupOptionRule( this.props.nextSpec, this.props.reportName, optionName, ruleName, value, this.state.ruleName, "after" );

        this.props.insertRow( rowGroupName, this.state.ruleName );
        this.props.updateNextSpec( nextSpec );
      }
    }

    this.setState({
      dialogShow: false,
      dialogMode: null,
    })
  }

  handleValueChange = (e) => {
    let nextState = {
      value: _.cloneDeep( this.state.value )
    };

    _.set( nextState, e.target.name, e.target.value );

    this.setState( nextState );
  }

  handleInsertNewRegExp = () => {
    let value = _.cloneDeep( this.state.value );

    if ( !value.rxList.includes( this.state.newRegExp ) ) {
      value.rxList.push( this.state.newRegExp );

      this.setState({
        value: value,
        newRegExp: "",
      });
    }
  }

  handleDeleteNewRegExp = (regexp) => {
    let value = _.cloneDeep( this.state.value );

    if ( value.rxList.includes( regexp ) ) {
      let ndx = value.rxList.indexOf( regexp );

      value.rxList.splice( ndx, 1 );

      this.setState({value: value});
    }
  }

  handleApplyButton = () => {
    let value = this.state.value;

    let nextSpec = rf.updateReportRowGroupOptionRule( this.props.nextSpec,
                                                      this.props.reportName,
                                                      this.props.rowGroupName.optionName,
                                                      this.props.rowGroupName.ruleName,
                                                      value );
    this.props.updateNextSpec( nextSpec );
  }

  handleResetButton = () => {
    this.setState( this.gatherState() );
  }

  handleCellEdited = (cell) => {
    const rowData = cell.getRow().getData();

    let ndx    = rowData.index;
    let regexp = rowData.regexp;

    let value = this.state.value;

    value.rxList[ ndx ] = regexp;

    this.setState({value: value});
  }

  handleAfterTableBuilt = () => {
    this.handleResize();

    if ( !this.tableBuilt ) {
      this.tableBuilt = true;
      this.forceUpdate();
    }
  }
}

export default ReportRowGroupsEdit;

////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
