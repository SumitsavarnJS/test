////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportMetricsEdit.js#20 $
// HEADER_MSG $Author: deepaku $
// HEADER_MSG $DateTime: 2023/02/21 04:16:26 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";

import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  ButtonGroup,
  FormControl,
  InputAdornment,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";

import { ExpandMore } from "@mui/icons-material";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import {
  ThemedButton,
  ThemedCheckbox,
} from "components/editSpecs/widgets/ThemedWidgets";

import ReportMetricsNewDialog from "components/editSpecs/ReportConfigEditor2/Reports/ReportMetricsNewDialog";

import styles from "./ReportMetricsEdit.module.css";

class ReportMetricsEdit extends React.Component {
  constructor(props) {
    super(props);

    /**!
     * Props:
     *   reportName     [String]   -
     *   metricName     [String]   -
     *   selectedList   [Array]    -
     *   editSpec       [Object]   -
     *   nextSpec       [Object]   -
     *   updateNextSpec [Function] -
     *   insertRow      [Function] -
     *   deleteRow      [Function] -
     *   deleteRows     [Function] -
     */

    const state = this.gatherState();

    this.state = {
      value: state.value,

      defaultCheckpointValue: state.defaultCheckpointValue,
      colorRuleRefValueValue: state.colorRuleRefValueValue,

      defaultCheckpointState: state.defaultCheckpointState,
      colorRuleRefValueState: state.colorRuleRefValueState,

      indexListError: state.indexListError,
      indexListText: state.indexListText,

      validMetricsList: state.validMetricsList,

      dialogShow: false,
      dialogMode: null,
    };

    this.hasRollupSection = false;
    this.hasSummarySection = false;
    this.isSpecialMetric = false;
    this.hasLimitedMetrics = false;
  }

  render() {
    let content = null;

    let enableCreateNew = true;
    let enableCreateList = true;

    this.hasRollupSection = false;
    this.hasSummarySection = false;
    this.isSpecialMetric = funcs.isSpecialMetric(this.props.metricName);
    this.hasLimitedMetrics = rf.gatherReportDefinition(
      this.props.nextSpec,
      this.props.reportName,
      "hasLimitedMetrics"
    );

    if (this.hasLimitedMetrics) {
      enableCreateList = false;
    }

    if (!this.isSpecialMetric) {
      this.hasRollupSection = rf.gatherReportDefinition(
        this.props.nextSpec,
        this.props.reportName,
        "hasRollup"
      );
      this.hasSummarySection = rf.gatherReportDefinition(
        this.props.nextSpec,
        this.props.reportName,
        "hasSummary"
      );
    }

    let newMetricDialog = (
      <ReportMetricsNewDialog
        show={this.state.dialogShow}
        title="Select Metrics to Add"
        reportName={this.props.reportName}
        nextSpec={this.props.nextSpec}
        submitAnswer={this.handleNewMetricSubmitAnswer}
        validMetricsList={this.state.validMetricsList}
        enableCreateNew={enableCreateNew}
        enableCreateList={enableCreateList}
      />
    );

    if (this.props.metricName == null) {
      if (this.props.selectedList.length == 0) {
        let addNewButton = (
          <ThemedButton text="New Metric" onClick={this.handleNewButton} />
        );

        content = (
          <div style={{ height: "100%" }}>
            <h3>Getting Started</h3>
            <ul>
              <li>{addNewButton}</li>
              <li>or select a single metric on the left to edit</li>
              <li>or select a group of metrics to delete</li>
            </ul>
            {newMetricDialog}
          </div>
        );
      } else {
        let deleteSelectedButton = (
          <ThemedButton
            text="Delete Selected"
            type="alert"
            onClick={this.handleDeleteSelectedButton}
          />
        );

        content = (
          <div>
            <h3>Getting Started</h3>
            <ul>
              <li>{deleteSelectedButton}</li>
            </ul>
          </div>
        );
      }
    } else {
      let buttonGroupLeft = (
        <ButtonGroup>
          <ThemedButton
            text="Insert Metric"
            onClick={this.handleInsertButton}
          />
          <ThemedButton
            text="Delete Metric"
            type="alert"
            onClick={this.handleDeleteButton}
          />
        </ButtonGroup>
      );

      let buttonGroupRight = (
        <ButtonGroup>
          <ThemedButton text="Apply" onClick={this.handleApplyButton} />
          <ThemedButton
            text="Reset"
            type="alert"
            onClick={this.handleResetButton}
          />
        </ButtonGroup>
      );

      let currentMetricNameLabel = (
        <div
          id="divEditorTop_ReportMetricsEdit_Label"
          className={styles.divEditorTop_ReportMetricsEdit_Label}
        >
          {this.props.metricName}
        </div>
      );

      let displayNameInput = (
        <div>
          <TextField
            fullWidth
            label="Display Name"
            name="value.displayName"
            variant="filled"
            value={this.state.value.displayName}
            onChange={this.handleMetricValueChange}
          />
        </div>
      );

      let groupNameInput = (
        <div>
          <TextField
            fullWidth
            label="Group Name"
            name="value.groupName"
            variant="filled"
            value={this.state.value.groupName}
            onChange={this.handleMetricValueChange}
          />
        </div>
      );

      let tooltipInput = (
        <div>
          <TextField
            fullWidth
            multiline
            label="Tooltip"
            name="value.tooltip"
            variant="filled"
            value={this.state.value.tooltip}
            onChange={this.handleMetricValueChange}
          />
        </div>
      );

      let indexListInput = (
        <div>
          <TextField
            fullWidth
            multiline
            required
            label="Index List"
            name="value.indexList"
            variant="filled"
            value={this.state.value.indexList}
            onChange={this.handleMetricValueChange}
            error={this.state.indexListError}
            helperText={this.state.indexListText}
          />
        </div>
      );

      let defaultCheckpointInput = (
        <div className="d-flex flex-row">
          <ThemedCheckbox
            name="defaultCheckpointState"
            checked={this.state.defaultCheckpointState}
            onChange={this.handleCheckboxChanged}
          />
          <TextField
            fullWidth
            disabled={!this.state.defaultCheckpointState}
            label="Default Checkpoint"
            name="defaultCheckpointValue"
            variant="filled"
            value={this.state.defaultCheckpointValue}
            onChange={this.handleValueChange}
          />
        </div>
      );

      const hiddenMenuItems = rf.reportSelectListTable.booleanList.map(
        (item) => (
          <MenuItem key={item.key} value={item.value}>
            {item.title}
          </MenuItem>
        )
      );

      let hiddenInput = (
        <FormControl fullWidth variant="filled">
          <InputLabel>Hidden?</InputLabel>
          <Select
            variant="filled"
            name="value.hidden"
            value={this.state.value.hidden}
            onChange={this.handleMetricValueChange}
          >
            {hiddenMenuItems}
          </Select>
        </FormControl>
      );

      const colorMenuItems = rf.reportSelectListTable.colorList.map((item) => (
        <MenuItem key={item.key} value={item.value}>
          {item.title}
        </MenuItem>
      ));

      let colorInput = (
        <FormControl fullWidth variant="filled">
          <InputLabel>Color</InputLabel>
          <Select
            variant="filled"
            name="value.colorRule.color"
            value={this.state.value.colorRule.color}
            onChange={this.handleMetricValueChange}
          >
            {colorMenuItems}
          </Select>
        </FormControl>
      );

      let lightPctInput = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group2Light"
          className={styles.divEditorTop_ReportMetricsEdit_Group2Light}
        >
          <TextField
            label="Light"
            type="number"
            name="value.colorRule.lightPct"
            variant="filled"
            value={this.state.value.colorRule.lightPct}
            onChange={this.handleMetricValueChange}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>,
            }}
          />
        </div>
      );

      let medPctInput = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group2Medium"
          className={styles.divEditorTop_ReportMetricsEdit_Group2Medium}
        >
          <TextField
            label="Medium"
            type="number"
            name="value.colorRule.medPct"
            variant="filled"
            value={this.state.value.colorRule.medPct}
            onChange={this.handleMetricValueChange}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>,
            }}
          />
        </div>
      );

      let darkPctInput = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group2Dark"
          className={styles.divEditorTop_ReportMetricsEdit_Group2Dark}
        >
          <TextField
            label="Dark"
            type="number"
            name="value.colorRule.darkPct"
            variant="filled"
            value={this.state.value.colorRule.darkPct}
            onChange={this.handleMetricValueChange}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>,
            }}
          />
        </div>
      );

      let colorPctGroup = (
        <div className="d-flex flex-row">
          {lightPctInput}
          {medPctInput}
          {darkPctInput}
        </div>
      );

      const improvesMenuItems = rf.reportSelectListTable.improvesList.map(
        (item) => (
          <MenuItem key={item.key} value={item.value}>
            {item.title}
          </MenuItem>
        )
      );

      let improvesInput = (
        <FormControl fullWidth variant="filled">
          <InputLabel>Improves</InputLabel>
          <Select
            variant="filled"
            name="value.colorRule.improves"
            value={this.state.value.colorRule.improves}
            onChange={this.handleMetricValueChange}
          >
            {improvesMenuItems}
          </Select>
        </FormControl>
      );

      let absThresholdInput = (
        <FormControl fullWidth variant="filled">
          <TextField
            label="Abs Threshold"
            type="number"
            name="value.colorRule.absThreshold"
            variant="filled"
            value={this.state.value.colorRule.absThreshold}
            onChange={this.handleMetricValueChange}
          />
        </FormControl>
      );

      let refValueInput = (
        <div className="d-flex flex-row">
          <ThemedCheckbox
            name="colorRuleRefValueState"
            checked={this.state.colorRuleRefValueState}
            onChange={this.handleCheckboxChanged}
          />
          <TextField
            fullWidth
            disabled={!this.state.colorRuleRefValueState}
            label="Ref Value"
            name="colorRuleRefValueValue"
            variant="filled"
            value={this.state.colorRuleRefValueValue}
            onChange={this.handleValueChange}
          />
        </div>
      );

      const calcMenuItems = rf.reportSelectListTable.calcList.map((item) => (
        <MenuItem key={item.key} value={item.value}>
          {item.title}
        </MenuItem>
      ));

      let rollupCalculate = (
        <FormControl variant="filled" fullWidth={true}>
          <InputLabel>Calculate</InputLabel>
          <Select
            name="value.defaultRollup.calculate"
            value={this.state.value.defaultRollup.calculate}
            onChange={this.handleMetricValueChange}
          >
            {calcMenuItems}
          </Select>
        </FormControl>
      );

      const incMenuItems = rf.reportSelectListTable.incParentList.map(
        (item) => (
          <MenuItem key={item.key} value={item.value}>
            {item.title}
          </MenuItem>
        )
      );

      let rollupIncParent = (
        <FormControl variant="filled" fullWidth={true}>
          <InputLabel>Include Parent</InputLabel>
          <Select
            name="value.defaultRollup.incParent"
            value={this.state.value.defaultRollup.incParent}
            onChange={this.handleMetricValueChange}
          >
            {incMenuItems}
          </Select>
        </FormControl>
      );

      const mathMenuItems = rf.reportSelectListTable.mathList.map((item) => (
        <MenuItem key={item.key} value={item.value}>
          {item.title}
        </MenuItem>
      ));

      let rollupMath = (
        <FormControl variant="filled" fullWidth={true}>
          <InputLabel>Math</InputLabel>
          <Select
            name="value.defaultRollup.math"
            value={this.state.value.defaultRollup.math}
            onChange={this.handleMetricValueChange}
          >
            {mathMenuItems}
          </Select>
        </FormControl>
      );

      const yesNoMenuItems = rf.reportSelectListTable.yesNoList.map((item) => (
        <MenuItem key={item.key} value={item.value}>
          {item.title}
        </MenuItem>
      ));

      let summaryCalculate = (
        <FormControl variant="filled" fullWidth={true}>
          <InputLabel>Calculate</InputLabel>
          <Select
            name="value.defaultSummary.calculate"
            value={this.state.value.defaultSummary.calculate}
            onChange={this.handleMetricValueChange}
          >
            {yesNoMenuItems}
          </Select>
        </FormControl>
      );

      let summaryIncParent = (
        <FormControl variant="filled" fullWidth={true}>
          <InputLabel>Include Parent</InputLabel>
          <Select
            name="value.defaultSummary.incParent"
            value={this.state.value.defaultSummary.incParent}
            onChange={this.handleMetricValueChange}
          >
            {yesNoMenuItems}
          </Select>
        </FormControl>
      );

      let summaryMath = (
        <FormControl variant="filled" fullWidth={true}>
          <InputLabel>Math</InputLabel>
          <Select
            name="value.defaultSummary.math"
            value={this.state.value.defaultSummary.math}
            onChange={this.handleMetricValueChange}
          >
            {mathMenuItems}
          </Select>
        </FormControl>
      );

      let group1InputSpecial = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group1"
          className={styles.divEditorTop_ReportMetricsEdit_Group1}
        >
          <Accordion defaultExpanded={true}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Typography>General</Typography>
            </AccordionSummary>
            <AccordionDetails>
              {displayNameInput}
              {groupNameInput}
              {tooltipInput}
              {hiddenInput}
            </AccordionDetails>
          </Accordion>
        </div>
      );

      let group1InputLimited = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group1"
          className={styles.divEditorTop_ReportMetricsEdit_Group1}
        >
          <Accordion defaultExpanded={true}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Typography>General</Typography>
            </AccordionSummary>
            <AccordionDetails>
              {displayNameInput}
              {groupNameInput}
              {tooltipInput}
              {hiddenInput}
            </AccordionDetails>
          </Accordion>
        </div>
      );

      let group1InputFull = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group1"
          className={styles.divEditorTop_ReportMetricsEdit_Group1}
        >
          <Accordion defaultExpanded={true}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Typography>General</Typography>
            </AccordionSummary>
            <AccordionDetails>
              {displayNameInput}
              {groupNameInput}
              {indexListInput}
              {tooltipInput}
              {defaultCheckpointInput}
              {hiddenInput}
            </AccordionDetails>
          </Accordion>
        </div>
      );

      let group2InputFull = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group2"
          className={styles.divEditorTop_ReportMetricsEdit_Group2}
        >
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Typography>Color Rule</Typography>
            </AccordionSummary>
            <AccordionDetails>
              {colorInput}
              {colorPctGroup}
              {improvesInput}
              {absThresholdInput}
              {refValueInput}
            </AccordionDetails>
          </Accordion>
        </div>
      );

      let group3InputFull = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group3"
          className={styles.divEditorTop_ReportMetricsEdit_Group3}
        >
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Typography>Default Rollup</Typography>
            </AccordionSummary>
            <AccordionDetails>
              {rollupCalculate}
              {rollupIncParent}
              {rollupMath}
            </AccordionDetails>
          </Accordion>
        </div>
      );

      let group4InputFull = (
        <div
          id="divEditorTop_ReportMetricsEdit_Group4"
          className={styles.divEditorTop_ReportMetricsEdit_Group4}
        >
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Typography>Default Summary</Typography>
            </AccordionSummary>
            <AccordionDetails>
              {summaryCalculate}
              {summaryIncParent}
              {summaryMath}
            </AccordionDetails>
          </Accordion>
        </div>
      );

      let group1Input = this.isSpecialMetric
        ? group1InputSpecial
        : this.hasLimitedMetrics
        ? group1InputLimited
        : group1InputFull;

      let group2Input = !this.isSpecialMetric ? group2InputFull : null;

      let group3Input = this.hasRollupSection ? group3InputFull : null;

      let group4Input = this.hasSummarySection ? group4InputFull : null;

      content = (
        <div
          id="divEditorTop_ReportMetricsEdit_Top"
          className={styles.divEditorTop_ReportMetricsEdit_Top}
        >
          {currentMetricNameLabel}

          <div
            id="divEditorTop_ReportMetricsEdit_Input"
            className={styles.divEditorTop_ReportMetricsEdit_Input}
          >
            {group1Input}
            {group2Input}
            {group3Input}
            {group4Input}
          </div>

          <div
            id="divEditorTop_ReportMetricsEdit_Buttons"
            className={styles.divEditorTop_ReportMetricsEdit_Buttons}
          >
            <div
              id="divEditorTop_ReportMetricsEdit_JustifyLeft"
              className={styles.divEditorTop_ReportMetricsEdit_JustifyLeft}
            >
              {buttonGroupLeft}
            </div>
            <div
              id="divEditorTop_ReportMetricsEdit_JustifyRight"
              className={styles.divEditorTop_ReportMetricsEdit_JustifyRight}
            >
              {buttonGroupRight}
            </div>
          </div>

          {newMetricDialog}
        </div>
      );
    }

    return content;
  }

  handleResize = () => {
    let divInput = document.getElementById(
      "divEditorTop_ReportMetricsEdit_Input"
    );
    let divButtons = document.getElementById(
      "divEditorTop_ReportMetricsEdit_Buttons"
    );

    if (divInput == null || divButtons == null) {
      return;
    }

    const winHeight = document.documentElement.clientHeight;

    const rectInput = divInput.getBoundingClientRect();
    const rectButtons = divButtons.getBoundingClientRect();

    const newY = winHeight - rectButtons.height;

    const delta = newY - rectButtons.y;

    const newHeight = rectInput.height + delta - 5;

    divInput.style.height = newHeight + "px";
  };

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    this.handleResize();

    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      const reportChanged = prevProps.reportName !== this.props.reportName;
      const metricChanged = prevProps.metricName !== this.props.metricName;
      const valueChanged = !_.isEqual(prevState.value, this.gatherValue());

      if (reportChanged || metricChanged || valueChanged) {
        this.setState(this.gatherState());
      }
    }

    this.props.updateDirty(this.isDirty());
  }

  componentWillUnmount() {}

  gatherState() {
    let metricState = {};

    const value = this.gatherValue();

    const defaultCheckpointState = !_.isNull(value.defaultCheckpoint);
    const colorRuleRefValueState = !_.isNull(value.colorRule.refValue);

    const defaultCheckpointValue = defaultCheckpointState
      ? value.defaultCheckpoint
      : "";
    const colorRuleRefValueValue = colorRuleRefValueState
      ? value.colorRule.refValue
      : "";

    const [error, helperText] =
      this.checkForMissingIndexListRequirements(value);

    metricState.value = value;
    metricState.indexListError = error;
    metricState.indexListText = helperText;
    metricState.defaultCheckpointValue = defaultCheckpointValue;
    metricState.colorRuleRefValueValue = colorRuleRefValueValue;
    metricState.defaultCheckpointState = defaultCheckpointState;
    metricState.colorRuleRefValueState = colorRuleRefValueState;
    metricState.validMetricsList = this.gatherMetricsList();

    return metricState;
  }

  gatherValue() {
    let value = _.cloneDeep(funcs.defaultMetricDef);

    if (rf.existsGlobalMetricName(this.props.nextSpec, this.props.metricName)) {
      let globalValue = rf.gatherGlobalMetric(
        this.props.nextSpec,
        this.props.metricName
      );
      _.merge(value, globalValue);
    }

    if (
      rf.existsReportMetric(
        this.props.nextSpec,
        this.props.reportName,
        this.props.metricName
      )
    ) {
      let reportValue = rf.gatherReportMetric(
        this.props.nextSpec,
        this.props.reportName,
        this.props.metricName
      );
      _.merge(value, reportValue);
    }

    return value;
  }

  isDirty() {
    let state = this.gatherState();

    let clean =
      _.isEqual(state.value, this.state.value) &&
      _.isEqual(
        state.defaultCheckpointValue,
        this.state.defaultCheckpointValue
      ) &&
      _.isEqual(
        state.defaultCheckpointState,
        this.state.defaultCheckpointState
      ) &&
      _.isEqual(
        state.colorRuleRefValueValue,
        this.state.colorRuleRefValueValue
      ) &&
      _.isEqual(
        state.colorRuleRefValueState,
        this.state.colorRuleRefValueState
      );

    return !clean;
  }

  checkForMissingIndexListRequirements(value) {
    let errorState = false;
    let errorText = "";

    if (value.indexList.length == 0) {
      errorState = true;
      errorText = "Index List must have a value";
    } else {
      if (_.last(value.indexList) == "sum_or_aux") {
        errorState = true;
        errorText = "Please choose a value of 'sum' or 'aux'";
      }
    }

    return [errorState, errorText];
  }

  gatherMetricsList() {
    let metricsList = [];

    let globalMetricList = rf.gatherGlobalMetricNames(this.props.nextSpec);
    let reportMetricList = rf.gatherReportMetricNames(
      this.props.nextSpec,
      this.props.reportName
    );

    globalMetricList.forEach(function (name) {
      if (reportMetricList.indexOf(name) == -1) {
        metricsList.push(name);
      }
    });

    return metricsList;
  }

  handleCheckboxChanged = (e) => {
    this.setState({
      [e.target.name]: e.target.checked,
    });
  };

  handleValueChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };

  handleMetricValueChange = (e) => {
    let nextState = {
      value: _.cloneDeep(this.state.value),
    };

    if (
      [
        "value.colorRule.medPct",
        "value.colorRule.lightPct",
        "value.colorRule.darkPct",
        "value.colorRule.absThreshold",
      ].includes(e.target.name)
    ) {
      _.set(nextState, e.target.name, parseFloat(e.target.value));
    } else {
      _.set(nextState, e.target.name, e.target.value);
    }

    [nextState.indexListError, nextState.indexListText] =
      this.checkForMissingIndexListRequirements(nextState.value);

    this.setState(nextState);
  };

  handleNewMetricSubmitAnswer = (accept, metricsList) => {
    if (accept && metricsList.length > 0) {
      let prevMetricName = this.props.metricName;

      let nextSpec = this.props.nextSpec;

      metricsList.forEach((metricName) => {
        let value = rf.gatherGlobalMetric(
          this.props.nextSpec,
          metricName,
          funcs.defaultMetricDef
        );

        if (this.state.dialogMode == "New") {
          nextSpec = rf.prependReportMetric(
            nextSpec,
            this.props.reportName,
            metricName,
            value
          );

          this.props.insertRow(metricName);
        } else if (this.state.dialogMode == "Insert") {
          nextSpec = rf.insertReportMetric(
            nextSpec,
            this.props.reportName,
            metricName,
            value,
            prevMetricName,
            "after"
          );

          this.props.insertRow(metricName, prevMetricName);
        }

        prevMetricName = metricName;
      });

      if (nextSpec) this.props.updateNextSpec(nextSpec);
    }

    this.setState({
      dialogShow: false,
      dialogMode: null,
    });
  };

  handleNewButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: "New",
    });
  };

  handleInsertButton = () => {
    if (this.isDirty()) {
      funcs.showNotification(
        "Report Metric Editor",
        "Apply or Reset the metric being edited."
      );
    } else {
      this.setState({
        dialogShow: true,
        dialogMode: "Insert",
      });
    }
  };

  handleDeleteSelectedButton = () => {
    this.props.deleteRows(this.props.selectedList);

    let nextSpec = rf.deleteReportMetrics(
      this.props.nextSpec,
      this.props.reportName,
      this.props.selectedList
    );

    this.props.updateNextSpec(nextSpec);
  };

  handleDeleteButton = () => {
    this.props.deleteRow(this.props.metricName);

    let nextSpec = rf.deleteReportMetric(
      this.props.nextSpec,
      this.props.reportName,
      this.props.metricName
    );

    this.props.updateNextSpec(nextSpec);
  };

  handleApplyButton = () => {
    let ok = !(
      this.state.indexListError &&
      !this.isSpecialMetric &&
      !this.hasLimitedMetrics
    );

    if (ok) {
      let defaultMetricValue = this.gatherValue();

      let currentMetricValue = this.state.value;

      if (this.state.defaultCheckpointState) {
        currentMetricValue.defaultCheckpoint =
          this.state.defaultCheckpointValue;
      } else {
        currentMetricValue.defaultCheckpoint = null;
      }

      if (this.state.colorRuleRefValueState) {
        currentMetricValue.colorRule.refValue =
          this.state.colorRuleRefValueValue;
      } else {
        currentMetricValue.colorRule.refValue = null;
      }

      if (typeof currentMetricValue.indexList == "string") {
        currentMetricValue.indexList = currentMetricValue.indexList.split(",");
      }

      let nonDefaultValue = rf.getNonDefaultValues(
        defaultMetricValue,
        currentMetricValue
      );

      let nextMetricValue = rf.gatherReportMetric(
        this.props.nextSpec,
        this.props.reportName,
        this.props.metricName
      );

      _.merge(nextMetricValue, nonDefaultValue);

      let nextSpec = rf.updateReportMetric(
        this.props.nextSpec,
        this.props.reportName,
        this.props.metricName,
        nextMetricValue
      );

      this.props.updateNextSpec(nextSpec);

      this.props.updateDirty(false);
    }
  };

  handleResetButton = () => {
    this.setState(this.gatherState());

    this.props.updateDirty(false);
  };
}

export default ReportMetricsEdit;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
