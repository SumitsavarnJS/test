////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportColorRulesEdit.js#11 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/10 07:05:18 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";

import {
  ButtonGroup,
  FilledInput,
  FormControl,
  IconButton,
  InputAdornment,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import { ThemedButton, ThemedCheckbox } from "components/editSpecs/widgets/ThemedWidgets";

import ReportsNewColorRuleDialog from "components/editSpecs/ReportConfigEditor2/Reports/ReportsNewColorRuleDialog";

import styles from "./ReportColorRulesEdit.module.css";

/*
 *  coloringRules: {
 *    defaultBlock:{...}
 *    <blockN>: {
 *      defaultCheckpoint: <str> or null
 *      <checkpointN>: {
 *        <metricNameN>: {
 *        }
 *      }
 *    }
 *  }
 */

class ReportColorRulesEdit extends React.Component {
  constructor(props) {
    super(props);

    /*
     * Props:
     *   reportName     : Name of the current report (could be null)
     *   colorRuleName  : Name of the selected color rule (could be null)
     *   selectedList   : List of selected items
     *   nextSpec       : The JSON data that is being worked on
     *   editSpec       : The JSON data that is original
     *   updateNextSpec : Command to update the spec
     *   insertRow      : Command to insert a new color rule
     *   deleteRow      : Command to delete a new color rule
     *   deleteRows     : Command to delete several color rules
     */

    const state = this.gatherState();

    this.state = {
      value: state.value,

      refValueValue: state.refValueValue,
      refValueState: state.refValueState,

      dialogShow: false,
      dialogMode: null,
    };
  }

  render() {
    let content = null;

    let newColorRuleDialog = (
      <ReportsNewColorRuleDialog
        show={this.state.dialogShow}
        reportName={this.props.reportName}
        colorRuleName={this.props.colorRuleName}
        dialogMode={this.state.dialogMode}
        nextSpec={this.props.nextSpec}
        submitAnswer={this.handleNewSubmitAnswer}
      />
    );

    if ( this.props.colorRuleName == null ) {
      if ( this.props.selectedList.length == 0 ) {
        let addNewButton = (
          <ThemedButton text="New Color Rule" onClick={this.handleNewButton} />
        );

        content = ( <div>
                      <h3>Getting Started</h3>
                      <ul>
                        <li>{addNewButton}</li>
                        <li>or select a single color rule on the left to edit</li>
                        <li>or select a group of color rules to delete</li>
                      </ul>

                      {newColorRuleDialog} 
                    </div> );
      } else {
        let deleteSelectedButton = (
          <ThemedButton text="Delete Selected" type="alert" onClick={this.handleDeleteSelectedButton} />
        );

        content = ( <div>
                      <h3>Getting Started</h3>
                      <ul>
                        <li>{deleteSelectedButton}</li>
                      </ul>
                    </div> );
      }
    } else {
      let buttonGroupLeft = (
        <div id="divEditorTop_ReportColorRulesEdit_JustifyLeft" className={styles.divEditorTop_ReportColorRulesEdit_JustifyLeft}>
          <ButtonGroup>
            <ThemedButton text="Insert Color Rule" onClick={this.handleInsertButton} />
            <ThemedButton text="Copy Color Rule" onClick={this.handleCopyButton} />
            <ThemedButton text="Delete Color Rule" type="alert" onClick={this.handleDeleteButton} />
          </ButtonGroup>
        </div>
      );

      let buttonGroupRight = (
        <div id="divEditorTop_ReportColorRulesEdit_JustifyRight" className={styles.divEditorTop_ReportColorRulesEdit_JustifyRight}>
          <ButtonGroup>
            <ThemedButton text="Apply" onClick={this.handleApplyButton} />
            <ThemedButton text="Reset" type="alert" onClick={this.handleResetButton} />
          </ButtonGroup>
        </div>
      );

      let currentColorGroupNameLabel = (
        <div id="divEditorTop_ReportColorRulesEdit_Label" className={styles.divEditorTop_ReportColorRulesEdit_Label}>{this.getNameLabel()}</div>
      );

      const colorMenuItems = rf.reportSelectListTable.colorList.map((item) =>
        <MenuItem key={item.key} value={item.value}>{item.title}</MenuItem>
      );

      let colorInput = (
        <FormControl fullWidth variant="filled" >
          <InputLabel>Color</InputLabel>
          <Select
            variant="filled"
            name="value.color"
            value={this.state.value.color}
            onChange={this.handleValueChange}
          >
            {colorMenuItems}
          </Select>
        </FormControl>
      );

      let lightPctInput = (
        <div id="divEditorTop_ReportColorRulesEdit_Light" className={styles.divEditorTop_ReportColorRulesEdit_Light}>
          <TextField
            label="Light"
            type="number"
            name="value.lightPct"
            variant="filled"
            value={this.state.value.lightPct}
            onChange={this.handleValueChange}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>
            }}
          />
        </div>
      );

      let medPctInput = (
        <div id="divEditorTop_ReportColorRulesEdit_Medium" className={styles.divEditorTop_ReportColorRulesEdit_Medium}>
          <TextField
            label="Medium"
            type="number"
            name="value.medPct"
            variant="filled"
            value={this.state.value.medPct}
            onChange={this.handleValueChange}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>
            }}
          />
        </div>
      );

      let darkPctInput = (
        <div id="divEditorTop_ReportColorRulesEdit_Dark" className={styles.divEditorTop_ReportColorRulesEdit_Dark} >
          <TextField
            label="Dark"
            type="number"
            name="value.darkPct"
            variant="filled"
            value={this.state.value.darkPct}
            onChange={this.handleValueChange}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>
            }}
          />
        </div>
      );

      let colorPctGroup = (
        <div className="d-flex flex-row">
          {lightPctInput}
          {medPctInput}
          {darkPctInput}
        </div>
      );

      const improvesMenuItems = rf.reportSelectListTable.improvesList.map((item) =>
        <MenuItem key={item.key} value={item.value}>{item.title}</MenuItem>
      );

      let improvesInput = (
        <FormControl fullWidth variant="filled" >
          <InputLabel>Improves</InputLabel>
          <Select
            variant="filled"
            name="value.improves"
            value={this.state.value.improves}
            onChange={this.handleValueChange}
          >
            {improvesMenuItems}
          </Select>
        </FormControl>
      );

      let absThresholdInput = (
        <FormControl fullWidth variant="filled">
          <TextField
            label="Abs Threshold"
            type="number"
            name="value.absThreshold"
            variant="filled"
            value={this.state.value.absThreshold}
            onChange={this.handleValueChange}
          />
        </FormControl>
      );

      let refValueInput = (
        <div className="d-flex flex-row">
          <ThemedCheckbox
            name="refValueState"
            checked={this.state.refValueState}
            onChange={this.handleCheckboxChange}
          />
          <TextField
            fullWidth
            disabled={!this.state.refValueState}
            label="Ref Value"
            name="refValueValue"
            variant="filled"
            value={this.state.refValueValue}
            onChange={this.handleValueChange}
          />
        </div>
      );

      content = (
        <div id="divEditorTop_ReportColorRulesEdit_Top" className={styles.divEditorTop_ReportColorRulesEdit_Top}>
          {currentColorGroupNameLabel}

          <div id="divEditorTop_ReportColorRulesEdit_Input" className={styles.divEditorTop_ReportColorRulesEdit_Input}>
            {colorInput}
            {colorPctGroup}
            {improvesInput}
            {absThresholdInput}
            {refValueInput}
          </div>

          <div id="divEditorTop_ReportColorRulesEdit_Buttons" className={styles.divEditorTop_ReportColorRulesEdit_Buttons}>
            <div id="divEditorTop_ReportColorRulesEdit_JustifyLeft" className={styles.divEditorTop_ReportColorRulesEdit_JustifyLeft}>
              {buttonGroupLeft}
            </div>
            <div id="divEditorTop_ReportColorRulesEdit_JustifyRight" className={styles.divEditorTop_ReportColorRulesEdit_JustifyRight}>
              {buttonGroupRight}
            </div>
          </div>

          {newColorRuleDialog} 
        </div>
      );
    }

    return content;
  }

  handleResize = () => {
    let divInput   = document.getElementById( "divEditorTop_ReportColorRulesEdit_Input" );
    let divButtons = document.getElementById( "divEditorTop_ReportColorRulesEdit_Buttons" );

    if ( divInput == null || divButtons == null ) {
      return
    }

    const winHeight = document.documentElement.clientHeight;

    const rectInput   = divInput.getBoundingClientRect();
    const rectButtons = divButtons.getBoundingClientRect();

    const newY = winHeight - rectButtons.height;

    const delta = newY - rectButtons.y;

    const newHeight = rectInput.height + delta - 5;

    divInput.style.height = newHeight + "px";
  }

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate( prevProps, prevState ) {
    this.handleResize();

    const isOutsideChange = !_.isEqual( prevProps, this.props );

    if ( isOutsideChange ) {
      const reportChanged    = ( prevProps.reportName    !== this.props.reportName );
      const colorRuleChanged = ( prevProps.colorRuleName !== this.props.colorRuleName );
      const valueChanged     = !_.isEqual( prevState.value, this.gatherValue() );

      if ( reportChanged || colorRuleChanged || valueChanged ) {
        this.setState( this.gatherState() );
      }
    }

    this.props.updateDirty( this.isDirty() );
  }

  componentWillUnmount() {
  }

  gatherState() {
    let state = {};

    const value = this.gatherValue();

    const refValueState = !_.isNull( value.refValue );
    const refValueValue = ( refValueState ? value.refValue : "" );

    state.value = value;
    state.refValueValue = refValueValue;
    state.refValueState = refValueState;

    return state;
  }

  gatherValue() {
    let value = _.cloneDeep( funcs.defaultColorRule );

    if ( this.props.reportName && this.props.colorRuleName ) {
      value = rf.gatherReportColoringRule( this.props.nextSpec,
                                           this.props.reportName,
                                           this.props.colorRuleName.blockName,
                                           this.props.colorRuleName.checkpointName,
                                           this.props.colorRuleName.metricName,
                                           funcs.defaultColorRule );
    }

    return value;
  }

  isDirty() {
    let state = this.gatherState();

    let clean = (    _.isEqual( state.value, this.state.value )
                  && _.isEqual( state.revValueValue, this.state.revValueValue )
                  && _.isEqual( state.revValueState, this.state.revValueState ) );

    return !clean;
  }

  getNameLabel = () => {
    return this.props.colorRuleName.blockName + "/" + this.props.colorRuleName.checkpointName + "/" + this.props.colorRuleName.metricName;
  }

  handleNewButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'New',
    })
  }

  handleInsertButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'Insert',
    })
  }

  handleCopyButton = () => {
    this.setState({
      dialogShow: true,
      dialogMode: 'Copy',
    })
  }

  handleDeleteSelectedButton = () => {
    let obj = {}

    this.props.selectedList.forEach( colorRuleName => {
      let bName = colorRuleName.blockName;
      let cName = colorRuleName.checkpointName;
      let mName = colorRuleName.metricName;

      const key = bName + "\t" + cName;

      if ( obj.hasOwnProperty( key ) ) {
        obj[ key ].push( mName );
      } else {
        obj[ key ] = [ mName ];
      }
    });

    let nextSpec = _.cloneDeep( this.props.nextSpec );

    _.forEach( obj, ( metricNameList, key ) => {
      const [ blockName, checkpointName ] = key.split( "\t" );

      nextSpec = rf.deleteReportColoringRules( nextSpec,
                                               this.props.reportName,
                                               blockName,
                                               checkpointName,
                                               metricNameList );
    });

    this.props.deleteRows( this.props.selectedList );
    this.props.updateNextSpec( nextSpec );
  }

  handleDeleteButton = () => {
    this.props.deleteRow( this.props.colorRuleName );

    let nextSpec = rf.deleteReportColoringRule( this.props.nextSpec,
                                                this.props.reportName,
                                                this.props.colorRuleName.blockName,
                                                this.props.colorRuleName.checkpointName,
                                                this.props.colorRuleName.metricName );

    this.props.updateNextSpec( nextSpec );
  }

  handleNewSubmitAnswer = (accept, colorRuleName) => {
    const blockName      = _.get( colorRuleName, 'blockName',      null );
    const checkpointName = _.get( colorRuleName, 'checkpointName', null );
    const metricName     = _.get( colorRuleName, 'metricName',     null );

    let nextSpec = null;

    if ( accept && blockName && checkpointName && metricName ) {
      switch ( this.state.dialogMode ) {
        case 'New':
          nextSpec = rf.insertReportColoringRule( this.props.nextSpec,
                                                  this.props.reportName,
                                                  blockName,
                                                  checkpointName,
                                                  metricName,
                                                  funcs.defaultColorRule );
          this.props.insertRow( colorRuleName );
          break;

        case 'Insert':
          nextSpec = rf.insertReportColoringRule( this.props.nextSpec,
                                                  this.props.reportName,
                                                  blockName,
                                                  checkpointName,
                                                  metricName,
                                                  funcs.defaultColorRule,
                                                  this.props.colorRuleName.metricName,
                                                  "after" );
          this.props.insertRow( colorRuleName, this.props.colorRuleName );
          break;

        case 'Copy':
          let value = this.gatherValue();

          nextSpec = rf.insertReportColoringRule( this.props.nextSpec,
                                                  this.props.reportName,
                                                  blockName,
                                                  checkpointName,
                                                  metricName,
                                                  value,
                                                  this.props.colorRuleName.metricName,
                                                  "after" );
          this.props.insertRow( colorRuleName, this.props.colorRuleName );
          break;
      }

      if ( nextSpec ) this.props.updateNextSpec( nextSpec );
    }

    this.setState({
      dialogShow: false,
      dialogMode: null,
    })
  }

  handleCheckboxChange = (e) => {
    this.setState({
      [e.target.name]: e.target.checked,
    });
  }

  handleValueChange = (e) => {
    let nextState = {
      value: _.cloneDeep( this.state.value )
    };

    _.set( nextState, e.target.name, e.target.value );

    this.setState( nextState );
  }

  handleApplyButton = () => {
    let value = this.state.value;

    if ( this.state.refValueState ) {
      value.refValue = this.state.refValueValue;
    } else {
      value.refValue = null;
    }

    let nextSpec = rf.updateReportColoringRule( this.props.nextSpec,
                                                this.props.reportName,
                                                this.props.colorRuleName.blockName,
                                                this.props.colorRuleName.checkpointName,
                                                this.props.colorRuleName.metricName,
                                                value );
    this.props.updateNextSpec( nextSpec );
  }

  handleResetButton = () => {
    this.setState( this.gatherState() );
  }

}

export default ReportColorRulesEdit;

////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
