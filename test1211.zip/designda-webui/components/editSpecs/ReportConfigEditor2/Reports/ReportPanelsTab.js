////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/Reports/ReportPanelsTab.js#10 $
// HEADER_MSG $Author: banakar $
// HEADER_MSG $DateTime: 2023/06/28 01:12:19 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
// import SplitPane from "react-split-pane";

import { ReactTabulator } from "react-tabulator";

import _ from "lodash";

import * as funcs from "common/Funcs";
import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";

import ReportPanelsEdit from "components/editSpecs/ReportConfigEditor2/Reports/ReportPanelsEdit";

import styles from "./ReportPanelsTab.module.css";
import { Divider } from "@mui/material";

const SectionName = "Panels";
const SectionElement = "panel";

class ReportPanelsTab extends React.Component {
  constructor(props) {
    super(props);

    /**!
     * Props:
     *   reportName     : [String]   - Name of currently selected report
     *   editSpec       : [Object]   - 
     *   nextSpec       : [Object]   - 
     *   updateNextSpec : [Function] - 
     *   updateDirty    : [Function] - 
     */

    this.state = {
      selectedName: null,
      selectedList: [],

      tableKey: 0,
    };

    this.mouseOver = false;
    this.ignoreRowSelection = false;

    this.dirty = false;

    this.tableRef = React.createRef();
  }

  render() {
    let content = null;

    if (this.props.reportName == null) {
      content = (<div>Please select a report on the left</div>);
    } else {
      let tableInfo = this.getTableInfo();

      let currentReportNameLabel = (
        <div id="divEditorTop_ReportPanelsTab_Label" className={styles.divEditorTop_ReportPanelsTab_Label}>{this.props.reportName}</div>
      );

      let leftPane = (
        <div id="divEditorTop_ReportPanelsTab_LeftPane" className={styles.divEditorTop_ReportPanelsTab_LeftPane} style={{ float: "left", height: "100%" }}>
          {currentReportNameLabel}
          <ReactTabulator
            key={this.state.tableKey.toString()}
            onRef={(r) => (this.tableRef = r)}
            options={tableInfo.tableOptions}
            events={tableInfo.tableEvents}
          />
        </div>
      );

      let rightPane = (
        <div id="divEditorTop_ReportPanelsTab_RightPane" className={styles.divEditorTop_ReportPanelsTab_RightPane}>
          <ReportPanelsEdit
            reportName={this.props.reportName}
            panelName={this.state.selectedName}
            selectedList={this.state.selectedList}
            editSpec={this.props.editSpec}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.props.updateNextSpec}
            insertRow={this.handleInsertRow}
            deleteRow={this.handleDeleteRow}
            deleteRows={this.handleDeleteRows}
            updateDirty={this.handleUpdateDirty}
          />
        </div>
      );

      content = (
        <div id="divEditorTop_ReportPanelsTab_Top" className={styles.divEditorTop_ReportPanelsTab_Top}>
          
          {/* <SplitPane split="vertical" defaultSize={"25%"}> */}
            {leftPane}
            <Divider orientation="vertical"/>
            {rightPane}
          {/* </SplitPane> */}
        </div>
      );
    }

    return content;
  }

  handleResize = () => {
    let table = this.tableRef.current;
    try {
      if (table) {
        table.setHeight(this.getTableHeight());
      }

      let tablePaneRight = document.getElementById("divEditorTop_ReportPanelsTab_RightPane");

      if (tablePaneRight) {
        tablePaneRight.style.height = this.getTableHeight() - 20 + "px";
      }
    } catch (e) {
      console.log("Could not resize:", e)
    }
  }

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      let nextState = {};

      nextState.tableKey = prevState.tableKey + 1;

      if (!_.isNull(prevState.selectedName)) {
        if (!rf.existsReportPanel(this.props.nextSpec, this.props.reportName, prevState.selectedName)) {
          nextState.selectedName = null;
          nextState.selectedList = [];
        }
      }

      this.setState(nextState);
    }
  }

  componentWillUnmount() {
  }

  getTableHeight = () => {
    let tableHeight = 100;
    let windowHeight = document.documentElement.clientHeight


    let tablePaneLeft = document.getElementById("divEditorTop_ReportPanelsTab_LeftPane");
    if (tablePaneLeft == null) {
      return tableHeight;
    }

    let paneLeftRect = tablePaneLeft.getBoundingClientRect();
    let paneLeftTop = paneLeftRect.top;

    tableHeight = windowHeight - paneLeftTop;

    return tableHeight;
  }

  getTableInfo() {
    let r = {};

    r.tableColumns = [];

    // Row Move Handle Column
    r.tableColumns.push({
      rowHandle: true,
      formatter: "handle",
      headerSort: false,
      frozen: true,
      width: 30,
      minWidth: 30
    });

    // Report Name Column
    r.tableColumns.push({
      title: "Panel",
      field: "name",
      headerFilter: funcs.customInput,
      headerFilterFunc: funcs.globFilter,
      headerTooltip: funcs.globFilterDisplayValueTooltip,
    });

    r.tableData = [];

    rf.gatherReportPanelNames(this.props.nextSpec, this.props.reportName).forEach((name) => {
      r.tableData.push({ name: name });
    });

    r.tableOptions = {};
    r.tableOptions.columnDefaults = { headerFilterPlaceholder: funcs.headerFilterPlaceholderText() };
    r.tableOptions.columns = r.tableColumns;
    r.tableOptions.data = r.tableData;
    r.tableOptions.height = 100;
    r.tableOptions.index = "name";
    r.tableOptions.layout = "fitDataStretch";
    r.tableOptions.movableRows = true;
    r.tableOptions.selectablePersistence = true;
    r.tableOptions.selectableRangeMode = "click";
    r.tableOptions.selectable = true;

    r.tableEvents = {};
    r.tableEvents.rowMouseEnter = this.handleRowMouseEnter;
    r.tableEvents.rowMouseLeave = this.handleRowMouseLeave;
    r.tableEvents.rowSelectionChanged = this.handleRowSelectionChanged;
    r.tableEvents.rowMoved = this.handleRowMoved;
    r.tableEvents.tableBuilt = this.handleAfterTableBuilt;

    return r;
  }

  handleUpdateDirty = (dirty) => {
    this.dirty = dirty;
    this.props.updateDirty(SectionName, dirty);
  }

  handleInsertRow = (name, position = null) => {
    let table = this.tableRef.current;

    let rowData = { name: name };

    if (position) {
      table.addRow(rowData, false, position);
    } else {
      table.addRow(rowData, false, true);
    }

    table.deselectRow();
    table.selectRow([name]);

    let selectedList = [name];

    this.setState({
      selectedName: name,
      selectedList: selectedList,
    });

    this.handleResize();
  }

  handleDeleteRow = (name) => {
    let table = this.tableRef.current;

    table.deleteRow(name);

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  }

  handleDeleteRows = (nameList) => {
    let table = this.tableRef.current;

    nameList.forEach((name) => {
      table.deleteRow(name);
    });

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  }

  handleRowMoved = (row) => {
    let table = this.tableRef.current;

    let newOrder = [];

    table.getData().forEach(function (r) {
      newOrder.push(r.name);
    });

    const origOrder = rf.gatherReportPanelNames(this.props.nextSpec, this.props.reportName);

    if (_.isEqual(origOrder, newOrder)) return;

    const nextSpec = rf.reorderReportPanels(this.props.nextSpec, this.props.reportName, newOrder);

    this.props.updateNextSpec(nextSpec);
  }

  handleRowMouseEnter = (e, row) => {
    this.mouseOver = true;
  }

  handleRowMouseLeave = (e, row) => {
    this.mouseOver = false;
  }

  handleRowSelectionChanged = (row) => {

    if (this.ignoreRowSelection) return;

    if (!this.mouseOver && row.length == 0) return; // Ignore empty selections with not set by user.

    let table = this.tableRef.current;

    if (this.dirty) {
      this.ignoreRowSelection = true;
      table.deselectRow();
      table.selectRow(this.state.selectedList);
      rf.showApplyOrResetNotification(SectionName, SectionElement);
      this.ignoreRowSelection = false;
      return;
    }

    let selectedName = null;

    let selectedRows = table.getSelectedRows();

    if (selectedRows.length == 1) {
      selectedName = selectedRows[0].getData().name;
    }

    let selectedList = [];

    selectedRows.forEach((r) => {
      selectedList.push(r.getData().name);
    });

    let nextState = {};

    if (!_.isEqual(selectedName, this.state.selectedName)
      || !_.isEqual(selectedList, this.state.selectedList)) {
      nextState.selectedName = selectedName;
      nextState.selectedList = selectedList;
    }

    this.setState(nextState);
  }

  handleAfterTableBuilt = () => {
    let table = this.tableRef.current;

    table.deselectRow();
    table.selectRow(this.state.selectedList);

    table.setHeight(this.getTableHeight());

    if (this.state.selectedList.length == 1) {
      table.scrollToRow(this.state.selectedList[0], "center", false);
    } else {
      table.rowManager.element.scrollTop = 0;
    }
  }
}

export default ReportPanelsTab;

////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
