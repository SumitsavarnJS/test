////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/MetricsTab.js#9 $
// HEADER_MSG $Author: banakar $
// HEADER_MSG $DateTime: 2023/06/28 01:12:19 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
// import SplitPane from "react-split-pane";
import { ReactTabulator } from "react-tabulator";

import _ from "lodash";

import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";
import * as funcs from "common/Funcs";

import MetricsEdit from "components/editSpecs/ReportConfigEditor2/Metrics/MetricsEdit";

import styles from  "./MetricsTab.module.css";
import { Divider } from "@mui/material";
import { Stack } from "@mui/system";

class MetricsTab extends React.Component {
  constructor(props) {
    super(props);

    /**!
     * Props:
     *   editSpec       : [Object]   - 
     *   nextSpec       : [Object]   - 
     *   updateNextSpec : [Function] - 
     */

    this.state = {
      selectedName: null,
      selectedList: [],

      tableKey: 0,
    };

    this.dirty = false;

    this.ignoreRowSelection = false;

    this.mouseOver = false;

    this.tableRef = React.createRef();
  }

  render() {
    let tableInfo = this.getTableInfo();

    let leftPane = (
      <div id="divEditorTop_MetricsTab_LeftPane" className={styles.divEditorTop_MetricsTab_LeftPane}>
        <ReactTabulator
          key={this.state.tableKey.toString()}
          onRef={(r) => (this.tableRef = r)}
          options={tableInfo.tableOptions}
          events={tableInfo.tableEvents}
        />
      </div>
    );

    let rightPane = (
      <div id="divEditorTop_MetricsTab_RightPane" className={styles.divEditorTop_MetricsTab_RightPane}>
        <MetricsEdit
          metricName={this.state.selectedName}
          selectedList={this.state.selectedList}
          editSpec={this.props.editSpec}
          nextSpec={this.props.nextSpec}
          updateNextSpec={this.props.updateNextSpec}
          insertMetric={this.handleInsertMetric}
          deleteMetric={this.handleDeleteMetric}
          deleteMetrics={this.handleDeleteMetrics}
          updateDirty={this.handleUpdateDirty}
          showDirtyNotification={this.showDirtyNotification}
        />
      </div>
    );

    let content = (
      <div id="divEditorTop_MetricsTab_Top" className={styles.divEditorTop_MetricsTab_Top}>
        {/* <SplitPane split="vertical" defaultSize={"25%"}> */}
        {/* <Stack> */}
          {leftPane}
          <Divider orientation="vertical" />
          {rightPane}
        {/* </Stack> */}
        {/* </SplitPane> */}
      </div>
    );

    return content;
  }

  handleResize = () => {
    let table = this.tableRef.current;
    try {
      if (table) {
        table.setHeight(this.getTableHeight());
      }

      let tablePaneRight = document.getElementById("divEditorTop_MetricsTab_RightPane");

      if (tablePaneRight) {
        tablePaneRight.style.height = this.getTableHeight() - 20 + "px";
      }
    } catch (e) {
      console.log("Could not resize:", e)
    }
  }

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      let nextState = {};

      nextState.tableKey = prevState.tableKey + 1;

      if (!_.isNull(prevState.selectedName)) {
        if (!rf.existsGlobalMetricName(this.props.nextSpec, prevState.selectedName)) {
          nextState.selectedName = null;
          nextState.selectedList = [];
        }
      }

      this.setState(nextState);
    }

    this.handleResize();
  }

  componentWillUnmount() {
  }

  getTableHeight = () => {
    let tableHeight = 100;
    let windowHeight = document.documentElement.clientHeight

    let leftElem = document.getElementById("divEditorTop_MetricsTab_LeftPane");
    if (leftElem == null) {
      return tableHeight;
    }

    let leftRect = leftElem.getBoundingClientRect();
    let leftTop = leftRect.top;

    tableHeight = windowHeight - leftTop;

    return tableHeight;
  }

  getTableInfo() {
    let r = {};

    r.tableColumns = [];

    // Row Move Handle Column
    r.tableColumns.push({
      rowHandle: true,
      formatter: "handle",
      headerSort: false,
      frozen: true,
      width: 30,
      minWidth: 30
    });

    // Metric Name Column
    r.tableColumns.push({
      title: "Metric",
      field: "name",
      headerFilter: funcs.customInput,
      headerFilterFunc: funcs.globFilter,
      headerTooltip: funcs.globFilterDisplayValueTooltip,
    });

    r.tableData = [];

    rf.gatherGlobalMetricNames(this.props.nextSpec).forEach(function (name) {
      r.tableData.push({ name: name });
    });

    r.tableOptions = {};
    r.tableOptions.columnDefaults = { headerFilterPlaceholder: funcs.headerFilterPlaceholderText() };
    r.tableOptions.columns = r.tableColumns;
    r.tableOptions.data = r.tableData;
    r.tableOptions.height = 100;
    r.tableOptions.index = "name";
    r.tableOptions.layout = "fitDataStretch";
    r.tableOptions.movableRows = true;
    r.tableOptions.selectablePersistence = true;
    r.tableOptions.selectableRangeMode = "click";
    r.tableOptions.selectable = true;

    r.tableEvents = {};
    r.tableEvents.rowMoved = this.handleRowMoved;
    r.tableEvents.rowMouseEnter = this.handleRowMouseEnter;
    r.tableEvents.rowMouseLeave = this.handleRowMouseLeave;
    r.tableEvents.rowSelectionChanged = this.handleRowSelectionChanged;
    r.tableEvents.tableBuilt = this.handleAfterTableBuilt;

    return r;
  }

  isDirty = () => {
    return this.dirty;
  }

  showDirtyNotification = () => {
    const msg = "Apply or Reset the metric currently being edited.";

    funcs.showNotification("Report Spec Editor", msg);
  }

  handleUpdateDirty = (dirty) => {
    this.dirty = dirty;
  }

  handleInsertMetric = (name, position = null) => {
    let table = this.tableRef.current;

    let rowData = { name: name };

    if (position) {
      table.addRow(rowData, false, position);
    } else {
      table.addRow(rowData, false, true);
    }

    let selectedList = [name];

    table.deselectRow();
    table.selectRow(selectedList);

    this.setState({
      selectedName: name,
      selectedList: selectedList,
    });

    this.handleResize();
  }

  handleDeleteMetric = (name) => {
    let table = this.tableRef.current;

    table.deleteRow(name);

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  }

  handleDeleteMetrics = (nameList) => {
    let table = this.tableRef.current;

    for (let i = 0; i < nameList.length; i++) {
      const name = nameList[i];
      table.deleteRow(name);
    }

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  }

  handleRowMoved = (row) => {
    let table = this.tableRef.current;

    let newOrder = [];

    table.getData().forEach(function (r) {
      newOrder.push(r.name);
    });

    const origOrder = rf.gatherGlobalMetricNames(this.props.nextSpec);

    if (_.isEqual(origOrder, newOrder)) return;

    const nextSpec = rf.reorderGlobalMetrics(this.props.nextSpec, newOrder);

    this.props.updateNextSpec(nextSpec);
  }

  handleRowMouseEnter = (e, row) => {
    this.mouseOver = true;
  }

  handleRowMouseLeave = (e, row) => {
    this.mouseOver = false;
  }

  handleRowSelectionChanged = (row) => {

    if (this.ignoreRowSelection) return;

    if (!this.mouseOver && row.length == 0) return; // Ignore empty selections with not set by user.

    let table = this.tableRef.current;

    if (this.isDirty()) {
      this.ignoreRowSelection = true;
      table.deselectRow();
      table.selectRow(this.state.selectedList);
      this.showDirtyNotification();
      this.ignoreRowSelection = false;
      return;
    }

    let selectedName = null;

    let selectedRows = table.getSelectedRows();

    if (selectedRows.length == 1) {
      selectedName = selectedRows[0].getData().name;
    }

    let selectedList = [];

    selectedRows.forEach((r) => {
      selectedList.push(r.getData().name);
    });

    if (!_.isEqual(selectedName, this.state.selectedName)
      || !_.isEqual(selectedList, this.state.selectedList)) {
      this.dirty = false;

      this.setState({
        selectedName: selectedName,
        selectedList: selectedList,
      });
    }
  }

  handleAfterTableBuilt = () => {
    let table = this.tableRef.current;

    table.deselectRow();
    table.selectRow(this.state.selectedList);

    table.setHeight(this.getTableHeight());

    if (this.state.selectedList.length == 1) {
      table.scrollToRow(this.state.selectedList[0], "center", false);
    } else {
      table.rowManager.element.scrollTop = 0;
    }
  }
}

export default MetricsTab;

////////////////////////////////////////////////////////////////////////////////
// End of File                                                                  
////////////////////////////////////////////////////////////////////////////////
