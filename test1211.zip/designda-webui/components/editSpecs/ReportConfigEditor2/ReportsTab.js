////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/ReportsTab.js#14 $
// HEADER_MSG $Author: banakar $
// HEADER_MSG $DateTime: 2023/06/28 01:12:19 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
// import SplitPane from "react-split-pane";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";

import { ReactTabulator } from "react-tabulator";

import _ from "lodash";

import * as rf from "components/editSpecs/ReportConfigEditor2/Reports/ReportFunctions";
import * as funcs from "common/Funcs";

import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

import ReportGeneralTab from "components/editSpecs/ReportConfigEditor2/Reports/ReportGeneralTab";
import ReportMetricsTab from "components/editSpecs/ReportConfigEditor2/Reports/ReportMetricsTab";
import ReportColorRulesTab from "components/editSpecs/ReportConfigEditor2/Reports/ReportColorRulesTab";
import ReportPanelsTab from "components/editSpecs/ReportConfigEditor2/Reports/ReportPanelsTab";
import ReportRowGroupsTab from "components/editSpecs/ReportConfigEditor2/Reports/ReportRowGroupsTab";
import ReportImagesTab from "components/editSpecs/ReportConfigEditor2/Reports/ReportImagesTab";
import ReportsNewReportDialog from "components/editSpecs/ReportConfigEditor2/Reports/ReportsNewReportDialog";

import styles from "./ReportsTab.module.css";
import { Divider } from "@mui/material";
import ReportContextMenuTab from "./Reports/ReportContextMenuTab";

class ReportsTab extends React.Component {
  constructor(props) {
    super(props);

    /**!
     * Props:
     *   editSpec       : [Object]   -
     *   nextSpec       : [Object]   -
     *   updateNextSpec : [Function] -
     */

    this.state = {
      currentTab: "reportInfo",

      selectedName: null,
      selectedList: [],

      showDialog: false,
      modeDialog: null,

      showReportInfoTab: false,
      showMetricsTab: false,
      showColoringRulesTab: false,
      showPanelsTab: false,
      showRowGroupsTab: false,
      showImageSpecsTab: false,
      showContextMenuTab: false,

      tableKey: 0,
    };

    this.dirty = {};
    this.resetDirty();

    this.ignoreRowSelection = false;

    this.mouseOver = false;

    this.tableRef = React.createRef();
  }

  render() {
    let tableInfo = this.getTableInfo();
    let leftPane = (
      <div
        id="divEditorTop_ReportsTab_LeftPane"
        className={styles.divEditorTop_ReportsTab_LeftPane}
      >
        <ReactTabulator
          height={"100%"}
          key={this.state.tableKey.toString()}
          onRef={(r) => (this.tableRef = r)}
          options={tableInfo.tableOptions}
          events={tableInfo.tableEvents}
        />
      </div>
    );

    let reportGeneralTab = null;
    let reportMetricsTab = null;
    let reportColorRulesTab = null;
    let reportPanelsTab = null;
    let reportRowGroupsTab = null;
    let reportImagesTab = null;
    let contextMenuTab = null;

    let newReportDialog = (
      <ReportsNewReportDialog
        show={this.state.showDialog}
        validNameList={rf.gatherReportNames(this.props.nextSpec)}
        validClassList={rf.gatherReportClasses()}
        submitAnswer={this.handleNewReportSubmitAnswer}
      />
    );

    if (this.state.showReportInfoTab) {
      reportGeneralTab = (
        <Tab eventKey="reportInfo" title="General">
          <ReportGeneralTab
            reportName={this.state.selectedName}
            editSpec={this.props.editSpec}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.handleUpdateNextSpec}
            insertReport={this.handleInsertReport}
            deleteReport={this.handleDeleteReport}
            changeReportName={this.handleChangeReportName}
            updateDirty={this.handleUpdateDirty}
            isReportDirty={this.isDirty}
            showReportDirtyNotification={this.showDirtyNotification}
          />
        </Tab>
      );
    }

    if (this.state.showMetricsTab) {
      reportMetricsTab = (
        <Tab eventKey="metrics" title="Metrics">
          <ReportMetricsTab
            reportName={this.state.selectedName}
            editSpec={this.props.editSpec}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.handleUpdateNextSpec}
            updateDirty={this.handleUpdateDirty}
          />
        </Tab>
      );
    }

    if (this.state.showColoringRulesTab) {
      reportColorRulesTab = (
        <Tab eventKey="coloringRules" title="Color Rules">
          <ReportColorRulesTab
            reportName={this.state.selectedName}
            editSpec={this.props.editSpec}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.handleUpdateNextSpec}
            updateDirty={this.handleUpdateDirty}
          />
        </Tab>
      );
    }

    if (this.state.showPanelsTab) {
      reportPanelsTab = (
        <Tab eventKey="panels" title="Panels">
          <ReportPanelsTab
            reportName={this.state.selectedName}
            editSpec={this.props.editSpec}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.handleUpdateNextSpec}
            updateDirty={this.handleUpdateDirty}
          />
        </Tab>
      );
    }

    if (this.state.showRowGroupsTab) {
      reportRowGroupsTab = (
        <Tab eventKey="rowGroupOptions" title="Row Group">
          <ReportRowGroupsTab
            reportName={this.state.selectedName}
            editSpec={this.props.editSpec}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.handleUpdateNextSpec}
            updateDirty={this.handleUpdateDirty}
          />
        </Tab>
      );
    }

    if (this.state.showImageSpecsTab) {
      reportImagesTab = (
        <Tab eventKey="imageSpecs" title="Images">
          <ReportImagesTab
            reportName={this.state.selectedName}
            editSpec={this.props.editSpec}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.handleUpdateNextSpec}
            updateDirty={this.handleUpdateDirty}
          />
        </Tab>
      );
    }

    if (this.state.showContextMenuTab) {
      contextMenuTab = (
        <Tab eventKey="conetxtMenu" title="Context Menu">
          <ReportContextMenuTab
            reportName={this.state.selectedName}
            editSpec={this.props.editSpec}
            nextSpec={this.props.nextSpec}
            updateNextSpec={this.handleUpdateNextSpec}
            updateDirty={this.handleUpdateDirty}
          />
        </Tab>
      );
    }

    let rightPane = null;

    if (this.state.selectedList.length == 0) {
      let newReportButton = (
        <ThemedButton text="New Report" onClick={this.handleNewReportButton} />
      );

      rightPane = (
        <div
          id="divEditorTop_ReportsTab_RightPane"
          className={styles.divEditorTop_ReportsTab_RightPane}
        >
          <h3>Getting Started</h3>
          <ul>
            <li>{newReportButton}</li>
            <li>or select a single report on the left to edit</li>
            <li>or select a group of reports to delete</li>
          </ul>
        </div>
      );
    } else if (this.state.selectedList.length > 1) {
      let deleteSelectedButton = (
        <ThemedButton
          text="Delete Selected Reports"
          type="alert"
          onClick={this.handleDeleteSelectedButton}
        />
      );

      rightPane = (
        <div
          id="divEditorTop_ReportsTab_RightPane"
          className={styles.divEditorTop_ReportsTab_RightPane}
        >
          <h3>Getting Started</h3>
          <ul>
            <li>{deleteSelectedButton}</li>
          </ul>
        </div>
      );
    } else {
      rightPane = (
        <div
          id="divEditorTop_ReportsTab_RightPane"
          className={styles.divEditorTop_ReportsTab_RightPane}
        >
          <Tabs
            className={styles.tabsEditorTop_ReportsTab}
            activeKey={this.state.currentTab}
            transition={false}
            onSelect={this.handleChangeTabs}
          >
            {reportGeneralTab}
            {reportMetricsTab}
            {reportColorRulesTab}
            {reportPanelsTab}
            {reportRowGroupsTab}
            {reportImagesTab}
            {contextMenuTab}
          </Tabs>
        </div>
      );
    }

    let content = (
      <div
        id="divEditorTop_ReportsTab_Top"
        className={styles.divEditorTopReportsTabTop}
      >
        {/* <SplitPane split="vertical" defaultSize={"25%"}> */}
        {leftPane}
        <Divider orientation="vertical" flexItem />
        {rightPane}
        {/* </SplitPane> */}
        {newReportDialog}
      </div>
    );

    return content;
  }

  handleResize = () => {
    let table = this.tableRef.current;
    try {
      if (table) {
        table.setHeight(this.getTableHeight());
      }

      let tablePaneRight = document.getElementById(
        "divEditorTop_ReportsTab_RightPane"
      );

      if (tablePaneRight) {
        tablePaneRight.style.height = this.getTableHeight() - 20 + "px";
      }
    } catch (e) {
      console.log("Could not resize:", e);
    }
  };

  componentDidMount() {
    window.addEventListener("resize", () => this.handleResize());
    this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    const isOutsideChange = !_.isEqual(prevProps, this.props);

    if (isOutsideChange) {
      let nextState = {};

      nextState.tableKey = prevState.tableKey + 1;

      if (!_.isNull(prevState.selectedName)) {
        if (!rf.existsReport(this.props.nextSpec, prevState.selectedName)) {
          nextState.selectedName = null;
          nextState.selectedList = [];
        }
      }

      this.setState(nextState);
    }

    this.handleResize();
  }

  componentWillUnmount() {}

  getReportState(nextSpec, reportName) {
    let state = {};

    state.selectedName = null;
    state.showReportInfoTab = false;
    state.showMetricsTab = false;
    state.showColoringRulesTab = false;
    state.showPanelsTab = false;
    state.showRowGroupsTab = false;
    state.showImageSpecsTab = false;
    state.showContextMenuTab = false;

    if (rf.existsReport(nextSpec, reportName)) {
      let reportData = rf.gatherReport(nextSpec, reportName);

      if (_.has(reportData, "reportInfo")) {
        let reportClass = reportData.reportInfo.reportClass;

        state.selectedName = reportName;
        state.showReportInfoTab = true;
        state.showMetricsTab = _.get(rf.reportDefinitionTable, [
          reportClass,
          "metrics",
        ]);
        state.showColoringRulesTab = _.get(rf.reportDefinitionTable, [
          reportClass,
          "coloringRules",
        ]);
        state.showPanelsTab = _.get(rf.reportDefinitionTable, [
          reportClass,
          "panels",
        ]);
        state.showRowGroupsTab = _.get(rf.reportDefinitionTable, [
          reportClass,
          "rowGroupOptions",
        ]);
        state.showImageSpecsTab = _.get(rf.reportDefinitionTable, [
          reportClass,
          "imageSpecs",
        ]);
        state.showContextMenuTab = _.get(rf.reportDefinitionTable, [
          reportClass,
          "contextMenu"
        ])

        let nextTab = this.state.currentTab;

        if (
          (this.state.currentTab == "metrics" && !state.showMetricsTab) ||
          (this.state.currentTab == "coloringRules" &&
            !state.showColoringRulesTab) ||
          (this.state.currentTab == "panels" && !state.showPanelsTab) ||
          (this.state.currentTab == "rowGroupOptions" &&
            !state.showRowGroupsTab) ||
          (this.state.currentTab == "imageSpecs" && !state.showImageSpecsTab) ||
          (this.state.currentTab == "contextMenu" && !state.showContextMenuTab)
        ) {
          nextTab = "reportInfo";
        }

        state.currentTab = nextTab;
      }
    }

    return state;
  }

  getTableHeight = () => {
    let tableHeight = 100;
    let windowHeight = document.documentElement.clientHeight;

    let tablePaneLeft = document.getElementById(
      "divEditorTop_ReportsTab_LeftPane"
    );
    if (tablePaneLeft == null) {
      return tableHeight;
    }

    let paneLeftRect = tablePaneLeft.getBoundingClientRect();
    let paneLeftTop = paneLeftRect.top;

    tableHeight = windowHeight - paneLeftTop;

    return tableHeight;
  };

  getTableInfo() {
    let r = {};

    r.tableColumns = [];

    // Row Move Handle Column
    r.tableColumns.push({
      rowHandle: true,
      formatter: "handle",
      headerSort: false,
      frozen: true,
      width: 30,
      minWidth: 30,
    });

    // Report Name Column
    r.tableColumns.push({
      title: "Report",
      field: "name",
      headerFilter: funcs.customInput,
      headerFilterFunc: funcs.globFilter,
      headerTooltip: funcs.globFilterDisplayValueTooltip,
    });

    r.tableData = [];

    rf.gatherReportNames(this.props.nextSpec).forEach(function (name) {
      r.tableData.push({
        name: name,
      });
    });

    r.tableOptions = {};
    r.tableOptions.columnDefaults = {
      headerFilterPlaceholder: funcs.headerFilterPlaceholderText(),
    };
    r.tableOptions.columns = r.tableColumns;
    r.tableOptions.data = r.tableData;
    r.tableOptions.height = "100%";
    r.tableOptions.index = "name";
    r.tableOptions.layout = "fitDataStretch";
    r.tableOptions.movableRows = true;
    r.tableOptions.selectablePersistence = true;
    r.tableOptions.selectableRangeMode = "click";
    r.tableOptions.selectable = true;

    r.tableEvents = {};
    r.tableEvents.rowMoved = this.handleRowMoved;
    r.tableEvents.rowMouseEnter = this.handleRowMouseEnter;
    r.tableEvents.rowMouseLeave = this.handleRowMouseLeave;
    r.tableEvents.rowSelectionChanged = this.handleRowSelectionChanged;
    r.tableEvents.tableBuilt = this.handleAfterTableBuilt;

    return r;
  }

  handleChangeReportName = (oldReportName, newReportName) => {
    let table = this.tableRef.current;
    let selectedList = [newReportName];
    table.addRow({ name: newReportName }, false, { name: oldReportName });
    table.selectRow(selectedList);
    this.setState({
      selectedName: newReportName,
      selectedList: selectedList,
    });
  };

  resetDirty() {
    this.dirty = {
      "Color Rules": false,
      Images: false,
      Metrics: false,
      Panels: false,
      "Row Group": false,
    };
  }

  isDirty = () => {
    let dirty = false;

    _.forEach(this.dirty, (value, section) => {
      dirty |= value;
    });

    return dirty;
  };

  showDirtyNotification = () => {
    let editList = _.reduce(
      this.dirty,
      (result, value, key) => {
        if (value) result.push(key);
        return result;
      },
      []
    );

    let msg =
      "Apply or Reset the following section" +
      (editList.length == 1 ? ": " : "s: ") +
      editList.join(", ");

    funcs.showNotification("Report Spec Editor", msg);
  };

  handleUpdateDirty = (section, dirty) => {
    _.set(this.dirty, section, dirty);
  };

  handleUpdateNextSpec = (nextSpec) => {
    let reportData = rf.gatherReport(nextSpec, this.state.selectedName);
    let reportClass = _.get(reportData, "reportInfo.reportClass", null);

    let showReportInfoTab = true;
    let showMetricsTab = _.get(rf.reportDefinitionTable, [
      reportClass,
      "metrics",
    ]);
    let showColoringRulesTab = _.get(rf.reportDefinitionTable, [
      reportClass,
      "coloringRules",
    ]);
    let showPanelsTab = _.get(rf.reportDefinitionTable, [
      reportClass,
      "panels",
    ]);
    let showRowGroupsTab = _.get(rf.reportDefinitionTable, [
      reportClass,
      "rowGroupOptions",
    ]);
    let showImageSpecsTab = _.get(rf.reportDefinitionTable, [
      reportClass,
      "imageSpecs",
    ]);
    let showContextMenuTab = _.get(rf.reportDefinitionTable, [
      reportClass,
      "contextMenu",
    ])

    this.props.updateNextSpec(nextSpec);

    let nextTab = this.state.currentTab;

    if (
      (this.state.currentTab == "metrics" && !showMetricsTab) ||
      (this.state.currentTab == "coloringRules" && !showColoringRulesTab) ||
      (this.state.currentTab == "panels" && !showPanelsTab) ||
      (this.state.currentTab == "rowGroupOptions" && !showRowGroupsTab) ||
      (this.state.currentTab == "imageSpecs" && !showImageSpecsTab) ||
      (this.state.currentTab == "contextMenu" && !showContextMenuTab)
    ) {
      nextTab = "reportInfo";
    }

    this.setState({
      currentTab: nextTab,
      showReportInfoTab: showReportInfoTab,
      showMetricsTab: showMetricsTab,
      showColoringRulesTab: showColoringRulesTab,
      showPanelsTab: showPanelsTab,
      showRowGroupsTab: showRowGroupsTab,
      showImageSpecsTab: showImageSpecsTab,
      showContextMenuTab: showContextMenuTab,
    });

    this.resetDirty();
  };

  handleNewReportButton = () => {
    if (this.isDirty()) {
      this.showDirtyNotification();
    } else {
      this.setState({
        showDialog: true,
        modeDialog: "New",
      });
    }
  };

  handleNewReportSubmitAnswer = (accept, data) => {
    let nextState = {
      showDialog: false,
      modeDialog: null,
    };

    if (accept) {
      let newReportName = data.reportName;
      let newReportClass = data.reportClass;

      let nextSpec = null;

      switch (this.state.modeDialog) {
        case "New":
          nextSpec = rf.prependReport(
            this.props.nextSpec,
            newReportName,
            rf.defaultReportData(newReportClass)
          );

          this.handleInsertReport(newReportName);

          let reportState = this.getReportState(nextSpec, newReportName);

          _.merge(nextState, reportState);
          break;

        default:
          break;
      }

      if (nextSpec) this.props.updateNextSpec(nextSpec);
    }

    this.setState(nextState);
  };

  handleInsertReport = (name, position = null) => {
    if (this.isDirty()) {
      this.showDirtyNotification();
    } else {
      let table = this.tableRef.current;

      let rowData = { name: name };

      if (position) {
        table.addRow(rowData, false, position);
      } else {
        table.addRow(rowData, true);
      }

      table.deselectRow();
      table.selectRow([name]);

      this.setState({
        selectedName: name,
        selectedList: [name],
      });

      this.handleResize();
    }
  };

  handleDeleteReport = (name) => {
    let table = this.tableRef.current;
    table.deleteRow(name);

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  };

  handleDeleteSelectedButton = () => {
    let table = this.tableRef.current;

    let nameList = this.state.selectedList;

    for (let i = 0; i < nameList.length; i++) {
      table.deleteRow(nameList[i]);
    }

    let nextSpec = rf.deleteReports(this.props.nextSpec, nameList);

    this.props.updateNextSpec(nextSpec);

    this.setState({
      selectedName: null,
      selectedList: [],
    });

    this.handleResize();
  };

  handleRowMoved = (row) => {
    let table = this.tableRef.current;

    let newOrder = [];

    table.getData().forEach(function (row) {
      newOrder.push(row.name);
    });

    const origOrder = rf.gatherReportNames(this.props.nextSpec);

    if (_.isEqual(origOrder, newOrder)) return;

    const nextSpec = rf.reorderReports(this.props.nextSpec, newOrder);

    this.props.updateNextSpec(nextSpec);
  };

  handleRowMouseEnter = (e, row) => {
    this.mouseOver = true;
  };

  handleRowMouseLeave = (e, row) => {
    this.mouseOver = false;
  };

  handleRowSelectionChanged = (row) => {
    if (this.ignoreRowSelection) return;

    if (!this.mouseOver && row.length == 0) return; // Ignore empty selections with not set by user.

    let table = this.tableRef.current;

    if (this.isDirty()) {
      this.ignoreRowSelection = true;
      table.deselectRow();
      table.selectRow(this.state.selectedList);
      this.showDirtyNotification();
      this.ignoreRowSelection = false;
      return;
    }

    let selectedName = null;

    let selectedRows = table.getSelectedRows();

    if (selectedRows.length == 1) {
      selectedName = selectedRows[0].getData().name;
    }

    let selectedList = [];

    selectedRows.forEach((r) => {
      selectedList.push(r.getData().name);
    });

    if (
      !_.isEqual(selectedName, this.state.selectedName) ||
      !_.isEqual(selectedList, this.state.selectedList)
    ) {
      let nextState = {};

      nextState.selectedName = selectedName;
      nextState.selectedList = selectedList;

      this.resetDirty();

      let reportState = this.getReportState(this.props.nextSpec, selectedName);

      _.merge(nextState, reportState);

      this.setState(nextState);
    }
  };

  handleChangeTabs = (key) => {
    this.setState({
      currentTab: key,
    });
  };

  handleAfterTableBuilt = () => {
    let table = this.tableRef.current;

    table.deselectRow();
    table.selectRow(this.state.selectedList);

    table.setHeight(this.getTableHeight());

    if (this.state.selectedList.length == 1) {
      table.scrollToRow(this.state.selectedList[0], "center", false);
    } else {
      table.rowManager.element.scrollTop = 0;
    }
  };
}

export default ReportsTab;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
