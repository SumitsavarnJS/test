// -----------------------------------------------------------------------------
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/ReportConfigEditor2/EditorTop.js#8 $
// HEADER_MSG $Author: seustes $
// HEADER_MSG $DateTime: 2023/01/04 11:29:22 $
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
// -----------------------------------------------------------------------------

import React from "react";

import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";

import _ from "lodash";
import * as funcs from "common/Funcs";

import MetricsTab from "components/editSpecs/ReportConfigEditor2/MetricsTab";
import ReportsTab from "components/editSpecs/ReportConfigEditor2/ReportsTab";

import styles from  "./EditorTop.module.css";

class EditorTop extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      currentTab: "reports",
    };
  }

  render() {
    let content = (
      <div id="divEditorTable_Top" className={styles.divEditorTable_Top}>
        <Tabs
          className={styles.tabsEditorTop}
          activeKey={this.state.currentTab}
          transition={false}
          onSelect={this.handleChangeTabs}
        >
          <Tab className={styles.tabEditorTopReports} eventKey="reports" title="Reports">
            <ReportsTab
              editSpec={this.props.editSpec}
              nextSpec={this.props.nextSpec}
              updateNextSpec={this.props.updateNextSpec}
            />
          </Tab>

          <Tab className={styles.tabEditorTopMetrics} eventKey="metrics" title="Metrics">
            <MetricsTab
              editSpec={this.props.editSpec}
              nextSpec={this.props.nextSpec}
              updateNextSpec={this.props.updateNextSpec}
            />
          </Tab>
        </Tabs>
      </div>
    );

    return content;
  }

  handleResize = () => {}

  componentDidMount() {}

  componentDidUpdate() {}

  componentWillUnmount() {}

  handleChangeTabs = (key) => {
    this.setState({ currentTab: key });
  }
}

export default EditorTop;

// -----------------------------------------------------------------------------
// End of File                                                                  
// -----------------------------------------------------------------------------
