////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/dialogs/GetSpecNamePopup.js#7 $
////////////////////////////////////////////////////////////////////////////////

import React from "react";
//import Modal from "react-bootstrap/Modal";
import * as funcs from "common/Funcs";
import _ from "lodash";

import { ButtonGroup, TextField, Modal, Box } from "@mui/material";
import { ThemedButton, ThemedDropdownButton } from "./ThemedWidgets";

import "./GetSpecNamePopup.module.css";

class GetSpecNamePopup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      folderName: "",
      specName: "",
    };
  }

  render() {
    let bottomGap = {
      marginBottom: "10px",
    };

    let selectedText =
      this.state.folderName === ""
        ? ""
        : "    Selected: " + this.state.folderName;

    let folderButton = (
      <div className="d-flex flex-column">
        <ThemedDropdownButton
          text="Folder"
          dropdownTypes={this.props.writableFolders}
          handleSelection={this.handleBaseFolderButton}
          sx={bottomGap}
        />
        {selectedText}
      </div>
    );

    let specNameInput = (
      <TextField
        label="Spec Name (relative to folder)"
        variant="filled"
        fullWidth={true}
        value={this.state.specName}
        onChange={this.updateSpecName}
        sx={bottomGap}
      />
    );

    let [errorState, errorText] = this.checkValidFullName();

    let fullNameInput = (
      <TextField
        label="Full Name"
        variant="filled"
        fullWidth={true}
        value={this.fullName()}
        error={errorState}
        helperText={errorText}
        disabled
      />
    );

    let specDisplayText = funcs.specDisplayText(this.props.currentFullName);

    let boxStyle = {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "auto",
      bgcolor: "background.paper",
      border: "2px solid #000",
      boxShadow: 24,
      borderRadius: "15px",
      p: 4,
    };

    return (
      <Modal open={this.props.show}>
        <Box sx={boxStyle}>
          <Box id="ModalHeader">
            <h2>Save As: {specDisplayText}</h2>
          </Box>

          <Box>
            {folderButton}
            <div>
              {specNameInput}
              {fullNameInput}
            </div>
          </Box>

          <Box>
            <ButtonGroup>
              <ThemedButton
                text="Accept"
                onClick={this.handleAcceptButton}
                disabled={errorState}
              />
              <ThemedButton
                text="Cancel"
                onClick={this.handleCancelButton}
                type="cancel"
              />
            </ButtonGroup>
          </Box>
        </Box>
      </Modal>
    );
  }

  componentDidMount() {}

  componentDidUpdate() {}

  checkValidFullName() {
    let errorState = false;
    let errorText = "";

    if (this.state.folderName === "") {
      errorText = "Please select a folder name";
      errorState = true;
    }

    if (this.state.specName === "") {
      if (errorState) {
        errorText += " and enter a spec name";
      } else {
        errorText = "Please enter a spec name";
      }

      errorState = true;
    }

    return [errorState, errorText];
  }

  fullName = () => {
    let folderName = this.state.folderName;
    if (this.state.folderName == "") {
      folderName = "<Folder>";
    }
    let specName = this.state.specName;
    if (this.state.specName == "") {
      specName = "<Spec Name>";
    }
    return folderName + "/" + specName;
  };

  handleBaseFolderButton = (e) => {
    this.setState({ folderName: e });
  };

  updateSpecName = (event) => {
    let inputValue = event.target.value;
    inputValue.trim();
    let specName = inputValue.replace(/\./g, "");
    this.setState({ specName: specName });
  };

  handleAcceptButton = () => {
    // check for missing input
    if (this.state.folderName == "") {
      let message = "You must select a Folder";
      funcs.showNotification("Spec Name", message);
      return;
    }
    if (this.state.specName == "") {
      let message = "You must provide a Spec Name";
      funcs.showNotification("Spec Name", message);
      return;
    }

    // check for same name
    if (this.fullName() == this.props.currentFullName) {
      let message = "New full name same as old full name";
      funcs.showNotification("Spec Name", message);
      return;
    }

    // overwrite
    if (this.props.fullNameHash.hasOwnProperty(this.fullName())) {
      let message = "The full name already exists";
      funcs.showNotification("Spec Name", message);
      return;
    }

    // For specs in "Admin", add "NA"
    let finalFullName = this.fullName();
    let parts = this.fullName().split("/");
    let mainFolderName = parts[0];
    if (mainFolderName == "Admin") {
      let specName = parts.slice(1).join("/");
      finalFullName = [mainFolderName, "NA", specName].join("/");
    }

    let accept = true;
    this.props.submitAnswer(accept, finalFullName);
    this.setState({ folderName: "", specName: "" });
  };

  handleCancelButton = () => {
    let accept = false;
    let newName = "";
    this.props.submitAnswer(accept, newName);
    this.setState({ folderName: "", fileName: "" });
  };
}

export default GetSpecNamePopup;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
