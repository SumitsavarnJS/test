////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/dialogs/RenameSpecPopup.js#6 $
////////////////////////////////////////////////////////////////////////////////

import React from "react";
//import Modal from "react-bootstrap/Modal";
import * as funcs from "common/Funcs";

import { ButtonGroup, TextField, Modal, Box } from "@mui/material";
import { ThemedButton } from "components/editSpecs/widgets/ThemedWidgets";

class RenameSpecPopup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      specName: "",
    };
  }

  render() {
    let baseFolder = "";
    let specName = "";
    let logicalFullName = "";

    if (this.props.currentFullName != null) {
      let parts = this.props.currentFullName.split("/");
      if (parts[0] == "Admin") {
        baseFolder = parts[0];
      } else {
        baseFolder = parts.slice(0, 2).join("/");
      }
      specName = parts.slice(2).join("/");
      logicalFullName = baseFolder + "/" + specName;
    }

    let specDisplayText = funcs.specDisplayText(this.props.currentFullName);

    let bottomGap = {
      marginBottom: "10px",
    };

    let errorState = false;
    let errorText = "";

    if (this.state.specName === "") {
      errorState = true;
      errorText = "Please enter a spec name";
    }

    let specNameInput = (
      <TextField
        label="New Spec Name"
        variant="filled"
        fullWidth={true}
        value={this.state.specName}
        onChange={this.updateSpecName}
        error={errorState}
        helperText={errorText}
        sx={bottomGap}
      />
    );
    let boxStyle = {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "auto",
      bgcolor: "background.paper",
      border: "2px solid #000",
      boxShadow: 24,
      borderRadius: "15px",
      p: 4,
    };

    return (
      <Modal open={this.props.show}>
        <Box sx={boxStyle}>
          <Box id="ModalHeader">
            <h2>Rename Spec: {specDisplayText}</h2>
          </Box>

          <Box>
            <div>
              <div>Folder: {baseFolder}</div>
              <div>Current Spec Name (relative to Folder): {specName}</div>
              {specNameInput}
            </div>
          </Box>

          <Box>
            <ButtonGroup>
              <ThemedButton
                text="Accept"
                onClick={this.handleAcceptButton}
                disabled={errorState}
              />
              <ThemedButton
                text="Cancel"
                onClick={this.handleCancelButton}
                type="cancel"
              />
            </ButtonGroup>
          </Box>
        </Box>
      </Modal>
    );
  }

  componentDidMount() {}

  componentDidUpdate() {
    if (this.props.show) {
    }
  }

  updateSpecName = (event) => {
    let inputValue = event.target.value;
    inputValue.trim();
    let specName = inputValue.replace(/\./g, "");
    this.setState({ specName: specName });
  };

  handleAcceptButton = () => {
    let parts = this.props.currentFullName.split("/");
    let mainFolderName = parts[0];
    let userOrProject = parts[1];

    let baseList = [mainFolderName, userOrProject];

    if (this.state.specName == "") {
      let message = "Name may not be blank";
      funcs.showNotification("Spec Re-Name", message);
      return;
    }

    baseList.push(this.state.specName);
    let newFullName = baseList.join("/");

    if (newFullName == this.props.currentFullName) {
      let message = "New name same as old name";
      funcs.showNotification("Spec Re-Name", message);
      return;
    }

    if (this.props.fullNameHash.hasOwnProperty(newFullName)) {
      let message = "Name already exists";
      funcs.showNotification("Spec Re-Name", message);
      return;
    }

    let accept = true;
    this.props.submitAnswer(accept, newFullName);
    this.setState({ specName: "" });
  };

  handleCancelButton = () => {
    let accept = false;
    let newFullName = "";
    this.props.submitAnswer(accept, newFullName);
    this.setState({ specName: "" });
  };
}

export default RenameSpecPopup;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
