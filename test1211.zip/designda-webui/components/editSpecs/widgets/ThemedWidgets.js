////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/widgets/ThemedWidgets.js#11 $
////////////////////////////////////////////////////////////////////////////////

import * as React from "react";
import { Box, Button, Checkbox, FormControl, FormControlLabel, InputLabel, Menu, Select, Switch, Tooltip, Typography } from "@mui/material";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { MenuItem } from "@mui/material";
// import { withStyles } from '@mui/styles';
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import _ from "lodash";
import * as funcs from "common/Funcs";

// const MenuItem = withStyles({
//   root: {
//     justifyContent: "flex-start"
//   }
// })(MuiMenuItem);

const EditorTheme = createTheme({
  palette: {
    primary: {
      main: "#007bff",
      darker: "#0056b3",
    },
    secondary: {
      main: "#ffc107",
      darker: "#cc9900",
    },
    info: {
      main: "#e6e6e6",
    },
  },

  typography: {
    fontSize: 14,
    button: {
      textTransform: "none",
    },
  },
});

// -----------------------------------------------------------------------------

function getButtonTypeStyle(type) {
  let textColor = "white";
  let bgColor = "#007bff";
  let hoverColor = "#0056b3";

  switch (type) {
    case "alert":
      textColor = "black";
      bgColor = "#ffc107";
      hoverColor = "#cc9900";
      break;

    case "danger":
      textColor = "white";
      bgColor = "#cc0000";
      hoverColor = "#800000";
      break;

    case "cancel":
      textColor = "white";
      bgColor = "#6c757d";
      hoverColor = "#5a6268";
      break;

    case "ReportSpec":
      textColor = "black";
      bgColor = "#e6e6e6";
      hoverColor = "#bfbfbf";
      break;

    case "BuildSpec":
      textColor = "green";
      bgColor = "#e6e6e6";
      hoverColor = "#bfbfbf";
      break;

    case "HierSpec":
      textColor = "#007bff";
      bgColor = "#e6e6e6";
      hoverColor = "#bfbfbf";
      break;

    default:
      // Use Standard colors
      break;
  }

  let sx = {
    height: "25px",
    margin: "2px",
    paddingBlock: "0px",
    paddingInline: "3px",
    color: textColor,
    backgroundColor: bgColor,
    ":hover": {
      bgcolor: hoverColor,
    },
  };

  return sx;
}

// -----------------------------------------------------------------------------

export const ThemedButton = (props) => {
  const { text = "TEXT-NOT-SET", type = "standard", sx = {}, ...other } = props;

  let this_sx = getButtonTypeStyle(type);

  _.merge(this_sx, sx);

  let content = (
    <ThemeProvider theme={EditorTheme}>
      <Button variant="contained" size="small" disableRipple={false} sx={this_sx} {...other}>
        {text}
      </Button>
    </ThemeProvider>
  );

  return content;
};

// -----------------------------------------------------------------------------

export const ThemedCheckbox = (props) => {
  const { text, ...other } = props;

  let label = text ? text : "";

  let sxCheckbox = {
    "&.Mui-checked": {
      color: funcs.palette("Blue").fg,
    },
  };

  let theControl = <Checkbox size="small" sx={sxCheckbox} {...other} />;

  let theLabel = <Typography sx={{ fontSize: 14 }}>{label}</Typography>;

  let content = (
    <ThemeProvider theme={EditorTheme}>
      <FormControlLabel label={theLabel} control={theControl} sx={{ margin: 0 }} />
    </ThemeProvider>
  );

  return content;
};

// -----------------------------------------------------------------------------

export const ThemedFormControlLabel = (props) => {
  let content = (
    <ThemeProvider theme={EditorTheme}>
      <FormControlLabel {...props} />
    </ThemeProvider>
  );

  return content;
};

// -----------------------------------------------------------------------------

export const ThemedSwitch = (props) => {
  const { text = "TEXT-NOT-SET", checked, onChange, ...other } = props;

  let theLabel = <Typography sx={{ fontSize: 14 }}>{text}</Typography>;
  let theControl = <Switch size="small" checked={checked} onChange={onChange} />;

  let content = (
    <ThemeProvider theme={EditorTheme}>
      <FormControlLabel label={theLabel} control={theControl} sx={{ margin: 0 }} />
    </ThemeProvider>
  );

  return content;
};

// -----------------------------------------------------------------------------

export const ThemedLabel = (props) => {
  const { text = "TEXT-NOT-SET", type = "standard", tooltip = null, fullWidth = false, ...other } = props;

  let bgColor = "#e6e6e6";
  let borderColor = "#000000";
  let textColor = "#000000";

  const tooltipValue = tooltip ? tooltip : null;

  switch (type) {
    case "ReportName":
      bgColor = "#6c767d";
      borderColor = "#6c767d";
      textColor = "#ffffff";
      break;

    case "ReportSpec":
      // Do nothing; use standard
      break;

    case "BuildSpec":
      borderColor = "#008000";
      textColor = "#008000";
      break;

    case "HierSpec":
      borderColor = "#007bff";
      textColor = "#007bff";
      break;

    default:
      // Standard
      break;
  }

  let styleParent = {
    height: "25px",

    backgroundColor: bgColor,
    borderColor: borderColor,
    borderRadius: "5px",

    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",

    margin: "2px",
  };

  if (fullWidth == true) {
    styleParent.width = "100%";
  }

  let styleChild = {
    backgroundColor: bgColor,
    color: textColor,

    fontFamily: "Roboto,Helvetica,Arial,sans-serif",
    fontSize: "13px",

    paddingLeft: "2px",
    paddingRight: "2px",

    overflow: "hidden",
    whiteSpace: "nowrap",
    textOverflow: "ellipsis",
    direction: "rtl",
  };

  let content = (
    <Tooltip title={tooltipValue} placement="bottom-end">
      <div style={styleParent} {...other}>
        <div style={styleChild}>{text}</div>
      </div>
    </Tooltip>
  );

  return content;
};

// -----------------------------------------------------------------------------
// Class: ThemedDropdownButton
// Props:
//   text            - [String]   Name of button
//   dropdownTypes   - [Array]    Array of strings that comprise the dropdown selections.
//   handleSelection - [Function] Called when a selection is made.
//   sx              - [Object]   Optional list if style overrides.
// -----------------------------------------------------------------------------

export class ThemedDropdownButton extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      anchorEl: null,
      open: false,
    };
  }

  render() {
    const menuItems = this.props.dropdownTypes.map((type) => (
      <Box display="flex" flexDirection="column" m={1}>
      <MenuItem
        key={type}
        sx={{ fontSize: "13px" }}
        onClick={() => {
          this.props.handleSelection(type);
          this.handleClose();
        }}
      >
        {type}
      </MenuItem>
      </Box>
    ));

    let dropdownButtonType = "standard";

    let sx = getButtonTypeStyle(dropdownButtonType);

    _.merge(sx, this.props.sx);

    let content = (
      <div>
        <ThemeProvider theme={EditorTheme}>
          <Button variant="contained" size="small" sx={sx} onClick={this.handleClick} endIcon={<KeyboardArrowDownIcon />}>
            {this.props.text}
          </Button>
        </ThemeProvider>

        <Menu
          anchorEl={this.state.anchorEl}
          open={this.state.open}
          onClose={this.handleClose}
          anchorOrigin={{
            vertical: "top",
            horizontal: "left",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "left",
          }}
        >
          {menuItems}
        </Menu>
      </div>
    );

    return content;
  }

  handleClick = (event) => {
    this.setState({
      anchorEl: event.currentTarget,
      open: true,
    });
  };

  handleClose = () => {
    this.setState({
      anchorEl: null,
      open: false,
    });
  };
}

// -----------------------------------------------------------------------------
// Class: ThemedSelect
// Props:
//   name            - [String]   
//   text            - [String]   Select label   
//   value           - [String]   The value
//   onChange        - [Function] Called when a selection is made.
//   selectItems     - [Array]    Array of objects {value,title} that comprise the 'Select' choices.
// -----------------------------------------------------------------------------

export const ThemedSelect = (props) => {
  const {
    name="select-name",
    text="TEXT-NOT-SET",
    value,
    onChange,
    selectItems=[],
    sx={},
    ...other
  } = props;

  function handleChange(e) {
    onChange( e.target.name, e.target.value );
  };

  let key = 0;
  const selectMenuItems = selectItems.map( (item) => <MenuItem key={_.toString(key++)} value={item.value}>{item.title}</MenuItem> );

  let content = (
    <FormControl fullWidth variant="filled" sx={sx}>
      <InputLabel>{text}</InputLabel>
      <Select
        variant="filled"
        name={name}
        value={_.isNull(value)?'':value}
        onChange={handleChange}
        MenuProps={{
          transitionDuration: {
            appear: "0",
            enter: "0",
            exit: "0",
          }
        }}
      >
        {selectMenuItems}
      </Select>
    </FormControl>
  );

  return content;
}

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
