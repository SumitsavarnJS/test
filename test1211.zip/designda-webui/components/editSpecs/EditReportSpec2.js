////////////////////////////////////////////////////////////////////////////////
// HEADER $Id$
// HEADER_MSG $Author$
// HEADER_MSG $DateTime$
// -----------------------------------------------------------------------------
// SYNOPSYS CONFIDENTIAL - This is an unpublished, proprietary work of
// Synopsys, Inc., and is fully protected under copyright and trade
// secret laws. You may not view, use, disclose, copy, or distribute this
// file or any information contained herein except pursuant to a valid
// written license from Synopsys.
////////////////////////////////////////////////////////////////////////////////

import React from "react";
import RenameSpecPopup from "./widgets/RenameSpecPopup";
import GetSpecNamePopup from "./widgets/GetSpecNamePopup";
import EditorTop from "./ReportConfigEditor2/EditorTop";

import _ from "lodash";
import * as funcs from "common/Funcs";

import { ButtonGroup } from "@mui/material";
import { ThemedButton, ThemedLabel } from "./widgets/ThemedWidgets";

import styles from "./EditReportSpec2.module.css";

const SpecType = Object.freeze(funcs.SpecType);

class EditReportSpec2 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      // Steve: orgJson/newJson is the old code

      // orgJson: {},
      // Tthe original specDoc is provided by this.props.editSpec
      // This is only used when updating dirty information
      // Note the use (in old code) of getDerivedStateFromProps(). This is a native method in a React component.
      // This is how the original specDoc, which is actually a prop, was transferred into state
      // This approach is sort of frowned upon as an anti-pattern.
      // It is no longer needed since we have state for both original & next specDocs as properties,
      // and the means to update the next specDoc.
      // I can see some benefit in the old code in that all of the document to be edited is self-contained,
      // and does not rely on external state & methods, but let's keep it simple for now.

      // newJson: {},
      // The next specDoc is provided by this.props.nextSpec
      // You update the next specDoc via this.props.updateNextSpec()
      // You editor reflects the value in this.props.nextSpec

      showRenameSpecPopup: false,
      showGetSpecNamePopup: false,
      resetKey: 1,
    };

    this.specType = SpecType.REPORT;
  }

  render() {
    let disabledResetSpec = !this.props.specDirty;
    let disabledSaveSpec = false;
    let disabledSaveSpecAs = false;
    let disabledRenameSpec = false;
    let disabledDeleteSpec = false;
    let disabledDownloadSpec = false;
    let disabledUploadSpec = false;
    let disabledExtractMetrics = false;

    let currentEditSpecText = funcs.specDisplayText(this.props.editSpec.fullName);

    if (this.props.editSpec.fullName == null) {
      disabledSaveSpec = true;
      disabledRenameSpec = true;
      disabledDeleteSpec = true;
    }

    if (this.props.readOnlyMode == true) {
      disabledResetSpec = true;
      disabledSaveSpec = true;
      disabledRenameSpec = true;
      disabledDeleteSpec = true;
      disabledUploadSpec = true;
      disabledExtractMetrics = true;
    }

    let specLabel = <ThemedLabel text={currentEditSpecText} type="ReportSpec" orient="horizontal" />;

    let cancelCloseButtonType = this.props.specDirty ? "danger" : "standard";
    let cancelCloseButtonText = this.props.specDirty ? "Cancel" : "Close";

    let cancelCloseButton = <ThemedButton text={cancelCloseButtonText} type={cancelCloseButtonType} onClick={this.handleCancelButton} />;
    let resetButton = <ThemedButton text="Reset" onClick={this.handleResetSpecButton} disabled={disabledResetSpec} />;
    let saveButton = <ThemedButton text="Save" onClick={this.handleSaveSpecButton} disabled={disabledSaveSpec} />;
    let saveAsButton = <ThemedButton text="Save As" onClick={this.handleSaveSpecAsButton} disabled={disabledSaveSpecAs} />;
    let renameButton = <ThemedButton text="Rename" onClick={this.handleRenameSpecButton} disabled={disabledRenameSpec} />;
    // let extractButton = <ThemedButton text="Extract" onClick={this.handleExtractMetricsButton} disabled={disabledExtractMetrics} />;
    let uploadSpecButton = <ThemedButton text="Upload Spec" onClick={this.handleUploadSpecButton} disabled={disabledUploadSpec} />;
    let downloadSpecButton = <ThemedButton text="Download Spec" onClick={this.handleDownloadSpecButton} disabled={disabledDownloadSpec} />;
    let deleteSpecButton = <ThemedButton text="Delete Spec" type="alert" onClick={this.handleDeleteSpecButton} disabled={disabledDeleteSpec} />;

    return (
      <div id="divEditReportSpec" className={styles.divEditReportSpec}>
        <div id="divEditReportSpecButtons" className="d-flex flex-row">
          {specLabel}
          <ButtonGroup>
            {resetButton}
            {saveButton}
            {saveAsButton}
            {renameButton}
            {/* {extractButton} */}
            {uploadSpecButton}
            {downloadSpecButton}
            {deleteSpecButton}
            {cancelCloseButton}
          </ButtonGroup>
        </div>

        <EditorTop
          key={this.state.resetKey}
          editSpec={this.props.editSpec}
          nextSpec={this.props.nextSpec}
          updateNextSpec={this.props.updateNextSpec}
          updateSpecDirty={this.updateSpecDirty}
          mongoData={this.props.mongoData}
        />

        <RenameSpecPopup
          show={this.state.showRenameSpecPopup}
          currentFullName={this.props.editSpec.fullName}
          fullNameHash={this.props.fullNameHash}
          // writableFolders={this.props.writableFolders}
          submitAnswer={this.renameSpecPopupSubmitAnswer}
        />
        <GetSpecNamePopup
          show={this.state.showGetSpecNamePopup}
          currentFullName={this.props.editSpec.fullName}
          fullNameHash={this.props.fullNameHash}
          writableFolders={this.props.writableFolders}
          submitAnswer={this.getSpecNamePopupSubmitAnswer}
        />
        <input id="fileInput" type="file" style={{ display: "none" }} onChangeCapture={this.handleFileInput} />
      </div>
    );
  }

  resizeEvent = () => {
    clearTimeout(this.resizeTimeout);
    this.resizeTimeout = setTimeout(this.handleResize, funcs.ResizeDelay);
  };

  handleResize = () => {};

  componentDidMount() {
    window.addEventListener("resize", () => this.resizeEvent());
    // this.forceUpdate();
  }

  componentDidUpdate(prevProps, prevState) {
    this.updateSpecDirty();
  }

  componentWillUnmount() {}

  writeReportSpecData(specData, fileName = "reportSpec") {
    const blob = new Blob([JSON.stringify(specData, null, 2)], {
      type: "application/json",
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", fileName + ".json");
    document.body.appendChild(link);
    link.click();
  }

  updateSpecDirty = () => {
    let dirty = !funcs.isEqualWithArrayOrder(this.props.editSpec, this.props.nextSpec);

    if (dirty != this.props.specDirty) {
      this.props.setSpecDirty(dirty);
    }
  };

  handleResetSpecButton = () => {
    this.setState({resetKey: Date.now()})
    this.props.updateNextSpec(this.props.editSpec);
  };

  handleSaveSpecButton = () => {
    //this.writeReportSpecData( this.props.nextSpec, "saved_report_spec" );
    this.props.saveSpec(this.specType, this.props.nextSpec);
  };

  handleSaveSpecAsButton = () => {
    this.setState({ showGetSpecNamePopup: true });
  };

  getSpecNamePopupSubmitAnswer = (accept, fullName) => {
    if (accept == true) {
      let specDoc = _.cloneDeep(this.props.nextSpec);
      specDoc.fullName = fullName;
      //this.writeReportSpecData( specDoc, "savedas_report_spec" );
      this.props.saveSpecAs(this.specType, specDoc);
    }
    this.setState({ showGetSpecNamePopup: false });
  };

  handleRenameSpecButton = () => {
    this.setState({ showRenameSpecPopup: true });
  };

  renameSpecPopupSubmitAnswer = (accept, newFullName) => {
    if (accept) {
      this.props.renameSpec(this.specType, newFullName);
    }
    this.setState({ showRenameSpecPopup: false });
  };

  handleExtractMetricsButton = () => {
    let mongoData = this.props.mongoData;
    if (mongoData == null) {
      return;
    }

    let metricsOld = {};
    if (funcs.getPropValue(this.props.nextSpec, ["data", "metrics"])) {
      metricsOld = _.cloneDeep(this.props.nextSpec.data.metrics);
    }
    let metricsNew = this.extractMetrics(mongoData, metricsOld);

    let nextSpec = _.cloneDeep(this.props.nextSpec);
    nextSpec.data.metrics = metricsNew;
    this.props.updateNextSpec(nextSpec);
  };

  extractMetrics = (mongoData, metricsOld) => {
    let metricsNew = _.cloneDeep(metricsOld);

    let docType = "aux";

    let buildNames = Object.keys(mongoData);
    for (let buildName of buildNames) {
      let checkpointNames = Object.keys(mongoData[buildName]["checkpoints"]);
      for (let checkpointName of checkpointNames) {
        if (mongoData[buildName]["checkpoints"][checkpointName][docType]["info"] != null) {
          let tableNames = Object.keys(mongoData[buildName]["checkpoints"][checkpointName][docType]["info"]);
          for (let tableName of tableNames) {
            let tableData = mongoData[buildName]["checkpoints"][checkpointName][docType]["info"][tableName]["data"];
            let tableKeys = mongoData[buildName]["checkpoints"][checkpointName][docType]["info"][tableName]["keys"];
            let path = [docType, "info", tableName, "data"];
            this.walkDict(tableData, tableKeys, path, metricsNew);
          }
        }
      }
    }

    return metricsNew;
  };

  walkDict = (tableData, tableKeys, path, metrics) => {
    let thisPath;
    for (let key in tableData) {
      let value = tableData[key];
      thisPath = _.cloneDeep(path);
      thisPath.push(key);
      if (typeof value === "object" && value !== null) {
        this.walkDict(value, tableKeys, thisPath, metrics);
      } else {
        let fullName = thisPath.join("|");
        let pathCount = thisPath.length;
        let displayName = thisPath[pathCount - 1];
        if (!metrics.hasOwnProperty(fullName)) {
          // 0 keys: ["$buildName", "checkpoints", "$checkpointName", "sum/aux", "info", "tableName", "data", [KEYS], "TotRun"]
          // 2 keys: ["$buildName", "checkpoints", "$checkpointName", "sum/aux", "info", "tableName", "data", [KEYS], "VAR_0000", "Value"]
          let value = {};
          value["displayName"] = displayName;
          value["indexList"] = ["$buildName", "checkpoints", "$checkpointName"].concat(thisPath);
          value["tooltip"] = "Metric extracted from database";
          metrics[fullName] = value;
        }
      }
    }
  };

  handleUploadSpecButton = () => {
    if (this.props.specDirty == true) {
      this.props.showDirtyMessage();
    } else {
      document.getElementById("fileInput").click();
    }
  };

  handleDownloadSpecButton = () => {
    this.writeReportSpecData(this.props.nextSpec.data, "downloaded_report_spec");
  };

  handleDeleteSpecButton = () => {
    this.props.deleteSpec(this.specType);
  };

  handleCancelButton = () => {
    this.props.cancelSpec(this.specType);
  };

  handleFileInput = (e) => {
    let fileObj = e.target.files[0];
    if (fileObj.type && fileObj.type != "application/json") {
      return;
    }
    let reader = new FileReader();
    reader.addEventListener("load", this.handleFileRead);
    reader.readAsText(fileObj);
    document.getElementById("fileInput").value = "";
  };

  handleFileRead = (e) => {
    let jsonString = e.target.result;
    let jsonObject = null;

    try {
      jsonObject = JSON.parse(jsonString);
    } catch {
      jsonObject = null;
    }

    if (jsonObject == null) {
      let message = "Syntax error in selected file";
      funcs.showNotification("Upload Report Spec", message);
      return;
    }

    // XXX
    let nextSpec = _.cloneDeep(this.props.editSpec);
    nextSpec.data = jsonObject;
    this.props.updateNextSpec(nextSpec);
  };
}

export default EditReportSpec2;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
