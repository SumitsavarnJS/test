////////////////////////////////////////////////////////////////////////////////
// HEADER $Id: //faa/apps/designdash/mainBranch/react_server/src/metrics/editSpecs/EditBuildSpec.js#53 $
////////////////////////////////////////////////////////////////////////////////

import React from "react";

import { ReactTabulator } from "react-tabulator";

import AddBuildsPopup from "metrics/dialogs/AddBuildsPopup";
import RenameSpecPopup from "metrics/dialogs/RenameSpecPopup";
import GetSpecNamePopup from "metrics/dialogs/GetSpecNamePopup";

import { Button, ButtonGroup, FilledInput, FormControl, FormControlLabel, InputAdornment, InputLabel, Switch } from "@mui/material";

import { ThemedButton, ThemedSwitch, ThemedLabel } from "components/editSpecs/widgets/ThemedWidgets";

import _ from "lodash";
import * as funcs from "common/Funcs";
import * as fastapi from "common/FastApi";

import "./EditBuildSpec.module.css";

const COOKIE_NAME = "/metrics/EditBuilds";

const SpecType = Object.freeze(funcs.SpecType);

class EditBuildSpec extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showAddBuildsPopup: false,
      addBuildsPopupData: [],
      addBuildsPopupTitle: "",
      showRenameSpecPopup: false,
      showGetSpecNamePopup: false,
      includeTime: false,
    };

    this.tableRef = React.createRef();

    this.scrollTop = 0;

    this.specType = SpecType.BUILD;

    this.fileInputRefSpec = React.createRef();
    this.fileInputRefQuery = React.createRef();
    this.addBuildsViaQueryActive = false;
  }

  render() {
    let disabledResetSpec = !this.props.specDirty;
    let disabledSaveSpec = false;
    let disabledSaveSpecAs = false;
    let disabledRenameSpec = false;
    let disabledDeleteSpec = false;
    let disabledDeleteBuilds = false;
    let disabledAddBuild = false;
    let disabledAddBuilds = false;
    let disabledUploadSpec = false;
    let disabledDownloadSpec = false;
    let disabledInputs = false;

    let currentEditSpecText = funcs.specDisplayText(this.props.editSpec.fullName);

    if (this.props.editSpec.fullName == null) {
      // disabledResetSpec = true;
      disabledSaveSpec = true;
      disabledRenameSpec = true;
      disabledDeleteSpec = true;
    }

    if (this.props.readOnlyMode == true) {
      disabledResetSpec = true;
      disabledSaveSpec = true;
      disabledRenameSpec = true;
      disabledDeleteSpec = true;
      disabledDeleteBuilds = true;
      disabledAddBuild = true;
      disabledAddBuilds = true;
      disabledUploadSpec = true;
      disabledInputs = true;
    }

    let specLabel = <ThemedLabel text={currentEditSpecText} type="BuildSpec" orient="horizontal" />;

    let cancelCloseButtonType = this.props.specDirty ? "alert" : "standard";
    let cancelCloseButtonText = this.props.specDirty ? "Cancel" : "Close";

    let cancelCloseButton = <ThemedButton text={cancelCloseButtonText} type={cancelCloseButtonType} onClick={this.handleCancelButton} />;
    let resetButton = <ThemedButton text="Reset" onClick={this.handleResetSpecButton} disabled={disabledResetSpec} />;
    let saveButton = <ThemedButton text="Save" onClick={this.handleSaveSpecButton} disabled={disabledSaveSpec} />;
    let saveAsButton = <ThemedButton text="Save As" onClick={this.handleSaveSpecAsButton} disabled={disabledSaveSpecAs} />;
    let renameButton = <ThemedButton text="Rename" onClick={this.handleRenameSpecButton} disabled={disabledRenameSpec} />;
    let deleteBuildsButton = <ThemedButton text="Delete Builds" onClick={this.handleDeleteBuildsButton} disabled={disabledDeleteBuilds} />;
    let addBuildButton = <ThemedButton text="Add Build" onClick={this.handleAddBuildButton} disabled={disabledAddBuild} />;
    let addBuildsButton = <ThemedButton text="Add Builds" onClick={this.handleAddBuildsButton} disabled={disabledAddBuilds} />;
    let deleteSpecButton = <ThemedButton text="Delete Spec" type="alert" onClick={this.handleDeleteSpecButton} disabled={disabledDeleteSpec} />;
    let uploadSpecButton = <ThemedButton text="Upload Spec" onClick={this.handleUploadSpecButton} disabled={disabledUploadSpec} />;
    let downloadSpecButton = <ThemedButton text="Download Spec" onClick={this.handleDownloadSpecButton} disabled={disabledDownloadSpec} />;

    let includeTimeCheck = <ThemedSwitch text="Include Time Check" checked={this.state.includeTime} onChange={this.handleIncludeTime} />;

    let addBuildsQueryButton = null;
    if (this.props.systemConfig.atSynopsys == true) {
      addBuildsQueryButton = <ThemedButton text="Add Builds (Query)" onClick={this.handleAddBuildsQueryButtonBegin} disabled={disabledAddBuilds} />;
    }
    addBuildsQueryButton = null; // XXX: WTF?

    // Update checkpoint input
    let checkpointsValue = this.getCheckpointsValue();
    let checkpointsText = checkpointsValue.join();

    let checkpointsField = (
      <div>
        <FormControl fullWidth variant="filled">
          <InputLabel>Checkpoints</InputLabel>
          <FilledInput
            id="checkpointsField"
            name="checkpointsField"
            disabled={disabledInputs}
            placeholder="-"
            defaultValue={checkpointsText}
            endAdornment={
              <InputAdornment position="end">
                <ThemedButton text="Apply" onClick={this.handleApplyCheckpoints} />
              </InputAdornment>
            }
          />
        </FormControl>
      </div>
    );

    // Calculate widths & heights
    let windowHeight = document.documentElement.clientHeight;
    let tableHeight = windowHeight;

    // Setup table
    let info = this.getTableInfo(tableHeight);

    let tableDiv = (
      <div id="divEditBuildSpecTable" className="divStandardBackgroundColor">
        <ReactTabulator
          className="ReactTabulatorStandard"
          onRef={(r) => (this.tableRef = r)}
          columns={info.tableColumns}
          data={info.tableData}
          options={info.tableOptions}
          events={info.tableEvents}
        />
      </div>
    );

    return (
      <div id="divEditBuildSpec">
        <div id="divEditBuildSpecButtons" className="center">
          <div id="divEditBuildSpecButtonsRow" className="d-flex flex-row">
            {specLabel}
            <ButtonGroup>
              {resetButton}
              {saveButton}
              {saveAsButton}
              {renameButton}
              {deleteBuildsButton}
              {addBuildButton}
              {addBuildsButton}
            </ButtonGroup>
            {includeTimeCheck}
          </div>
          <div id="divEditBuildSpecButtonsRow">{checkpointsField}</div>
          <div id="divEditBuildSpecButtonsRow">
            <ButtonGroup>
              {addBuildsQueryButton}
              {uploadSpecButton}
              {downloadSpecButton}
              {deleteSpecButton}
              {cancelCloseButton}
            </ButtonGroup>
          </div>
        </div>
        {tableDiv}

        <AddBuildsPopup
          title={this.state.addBuildsPopupTitle}
          show={this.state.showAddBuildsPopup}
          data={this.state.addBuildsPopupData}
          submitAnswer={this.addBuildsPopupSubmitAnswer}
          userData={this.props.userData}
          includeTime={this.state.includeTime}
        />
        <RenameSpecPopup
          show={this.state.showRenameSpecPopup}
          currentFullName={this.props.editSpec.fullName}
          fullNameHash={this.props.fullNameHash}
          // writableFolders={this.props.writableFolders}
          submitAnswer={this.renameSpecPopupSubmitAnswer}
        />
        <GetSpecNamePopup
          show={this.state.showGetSpecNamePopup}
          currentFullName={this.props.editSpec.fullName}
          fullNameHash={this.props.fullNameHash}
          writableFolders={this.props.writableFolders}
          submitAnswer={this.getSpecNamePopupSubmitAnswer}
        />
        <input id="inputIdSpec" ref={this.fileInputRefSpec} type="file" style={{ display: "none" }} onChange={this.handleUploadFileSpec} accept=".json" />
        <input id="inputIdQuery" ref={this.fileInputRefQuery} type="file" style={{ display: "none" }} onChange={this.handleUploadFileQuery} accept=".json" />
      </div>
    );
  }

  componentDidMount() {
    window.addEventListener("resize", () => this.resizeEvent());

    let cookie = this.getCookie();
    let includeTime = cookie.includeTime;

    this.setState({ includeTime: includeTime });
  }

  componentDidUpdate() {}

  componentWillUnmount() {}

  getCheckpointsValue = () => {
    let tableData = this.props.nextSpec.data;

    let checkpointsValue = [];
    for (let dataItem of tableData) {
      if (dataItem.checkpoints) {
        checkpointsValue = dataItem.checkpoints;
      }
      break;
    }

    return checkpointsValue;
  };

  updateCheckpoints = (orgTableData) => {
    let newTableData = _.cloneDeep(orgTableData);

    let checkpointsValue = [];
    let checkpointsText = this.getCheckpointsText("checkpointsField");
    if (this.isValidString(checkpointsText)) {
      checkpointsValue = checkpointsText.split();
    }
    for (let dataItem of newTableData) {
      dataItem.checkpoints = checkpointsValue;
    }

    return newTableData;
  };

  handleApplyCheckpoints = () => {
    let tableData = _.cloneDeep(this.tableRef.current.getData());
    tableData = this.updateCheckpoints(tableData);

    let editSpecDoc = this.props.editSpec;
    let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
    nextSpecDoc.data = tableData;

    this.updateSpecDirty(editSpecDoc, nextSpecDoc);
    this.props.updateNextSpec(nextSpecDoc);
  };

  getTableInfo = (tableHeight) => {
    let r = {};
    r.tableColumns = [];
    r.tableData = [];
    r.tableOptions = {};
    r.tableEvents = {};

    ////////////////////////////////////////
    // Calculate Table Columns
    ////////////////////////////////////////

    let tableColumns = [
      { rowHandle: true, formatter: "handle", headerSort: false, frozen: true, width: 30, minWidth: 30 },
      {
        title: "Project",
        field: "PROJECT",
        sorter: "string",
        editor: "input",
        headerSortTristate: true,
        headerFilter: funcs.customInput,
        headerFilterFunc: funcs.customFilter,
        headerTooltip: funcs.customFilterDisplayValueTooltip,
        formatter: (cell, formatterParams, onRendered) => this.cellFormatter(cell, formatterParams, onRendered),
      },
      {
        title: "Phase",
        field: "PHASE",
        sorter: "string",
        editor: "input",
        headerSortTristate: true,
        headerFilter: funcs.customInput,
        headerFilterFunc: funcs.customFilter,
        headerTooltip: funcs.customFilterDisplayValueTooltip,
        formatter: (cell, formatterParams, onRendered) => this.cellFormatter(cell, formatterParams, onRendered),
      },
      {
        title: "Run Tag",
        field: "RUNTAG",
        sorter: "string",
        editor: "input",
        headerSortTristate: true,
        headerFilter: funcs.customInput,
        headerFilterFunc: funcs.customFilter,
        headerTooltip: funcs.customFilterDisplayValueTooltip,
        formatter: (cell, formatterParams, onRendered) => this.cellFormatter(cell, formatterParams, onRendered),
      },
      {
        title: "Block",
        field: "BLOCK",
        sorter: "string",
        editor: "input",
        headerSortTristate: true,
        headerFilter: funcs.customInput,
        headerFilterFunc: funcs.customFilter,
        headerTooltip: funcs.customFilterDisplayValueTooltip,
        formatter: (cell, formatterParams, onRendered) => this.cellFormatter(cell, formatterParams, onRendered),
      },
      {
        title: "User",
        field: "USER",
        sorter: "string",
        editor: "input",
        headerSortTristate: true,
        headerFilter: funcs.customInput,
        headerFilterFunc: funcs.customFilter,
        headerTooltip: funcs.customFilterDisplayValueTooltip,
        formatter: (cell, formatterParams, onRendered) => this.cellFormatter(cell, formatterParams, onRendered),
      },
      {
        title: "User Label",
        field: "LABEL",
        sorter: "string",
        editor: "input",
        headerSortTristate: true,
        headerFilter: funcs.customInput,
        headerFilterFunc: funcs.customFilter,
        headerTooltip: funcs.customFilterDisplayValueTooltip,
        formatter: (cell, formatterParams, onRendered) => this.cellFormatter(cell, formatterParams, onRendered),
      },
      {
        title: "Time Range",
        field: "TIMERANGE",
        editor: "input",
        validator: [
          {
            type: this.checkTimestamp,
            parameters: {},
          },
        ],
        formatter: (cell, formatterParams, onRendered) => this.cellFormatter(cell, formatterParams, onRendered),
      },
    ];

    ////////////////////////////////////////
    // Calculate Table Rows
    ////////////////////////////////////////

    let tableData = _.cloneDeep(this.props.nextSpec.data);

    ////////////////////////////////////////
    // tableOptions & tableEvents
    ////////////////////////////////////////

    let tableOptions = {};
    let tableEvents = {};

    tableOptions = {
      layout: "fitDataStretch",
      height: tableHeight,
      selectable: true,
      selectableRangeMode: "click",
      movableRows: true,
      columnDefaults: {
        headerFilterPlaceholder: funcs.headerFilterPlaceholderText(),
      },
      validationMode: "highlight",
    };

    tableEvents.tableBuilt = this.afterTableBuilt;
    tableEvents.rowMoved = this.rowMoved;
    tableEvents.cellEdited = this.cellEdited;
    tableEvents.scrollVertical = this.scrollVertical;

    ////////////////////////////////////////
    // Return table info
    ////////////////////////////////////////

    r.tableColumns = tableColumns;
    r.tableData = tableData;
    r.tableOptions = tableOptions;
    r.tableEvents = tableEvents;

    return r;
  };

  afterTableBuilt = () => {
    let tableHeight = this.getTableHeight();
    this.tableRef.current.setHeight(tableHeight);
    this.tableRef.current.rowManager.element.scrollTop = this.scrollTop;
  };

  scrollVertical = (top) => {
    this.scrollTop = top;
  };

  rowMoved = (row) => {
    let tableData = _.cloneDeep(this.tableRef.current.getData());
    tableData = this.updateCheckpoints(tableData);

    let editSpecDoc = this.props.editSpec;
    let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
    nextSpecDoc.data = tableData;

    this.updateSpecDirty(editSpecDoc, nextSpecDoc);
    this.props.updateNextSpec(nextSpecDoc);
  };

  cellEdited = (cell) => {
    let tableData = _.cloneDeep(this.tableRef.current.getData());
    tableData = this.updateCheckpoints(tableData);

    let editSpecDoc = this.props.editSpec;
    let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
    nextSpecDoc.data = tableData;

    this.updateSpecDirty(editSpecDoc, nextSpecDoc);
    this.props.updateNextSpec(nextSpecDoc);
  };

  cellFormatter = (cell, formatterParams, onRendered) => {
    let value = cell.getValue();
    let fieldName = cell.getField();

    let checkFields = ["PROJECT", "PHASE", "RUNTAG", "BLOCK", "USER"];

    let fg = funcs.palette("Default").fg;
    let bg = funcs.palette("Default").bg;

    if (checkFields.includes(fieldName)) {
      let valid = this.isValidString(value);

      if (!valid) {
        bg = funcs.palette("Warning").fg;
      }
    }

    cell.getElement().style.color = fg;
    cell.getElement().style.backgroundColor = bg;

    return value;
  };

  resizeEvent = () => {
    clearTimeout(this.resizeTimeout);
    this.resizeTimeout = setTimeout(this.handleResize, funcs.ResizeDelay);
  };

  handleResize = () => {
    if (this.tableRef.current != null) {
      let tableHeight = this.getTableHeight();
      this.tableRef.current.setHeight(tableHeight);
    }
  };

  getTableHeight = () => {
    let windowHeight = document.documentElement.clientHeight;
    let tableHeight = windowHeight;

    let divContainer = document.getElementById("divEditBuildSpecTable");
    if (divContainer == null) {
      return tableHeight;
    }

    let rectContainer = divContainer.getBoundingClientRect();
    tableHeight = windowHeight - rectContainer.y;

    return tableHeight;
  };

  isValidString = (value) => {
    let isValid = true;

    // check for blank value
    let regex = "^\\s*$";
    let re = new RegExp(regex);
    let reMatch = re.exec(value);
    if (reMatch) {
      isValid = false;
    }

    // check for null
    if (value == null) {
      isValid = false;
    }

    return isValid;
  };

  checkRequiredString = (cell, value, parameters) => {
    let isValid = this.isValidString(value);
    return isValid;
  };

  checkTimestamp = (cell, value, parameters) => {
    let regex;
    let re;
    let reMatch;

    // check for blank value
    regex = "^\\s*$";
    re = new RegExp(regex);
    reMatch = re.exec(value);
    if (reMatch) {
      let isValid = true;
      return isValid;
    }

    // check for time value
    let isValid = false;
    let textMin = null;
    let textMax = null;

    // Check for both textMin and textMax
    regex = "^(\\d\\d\\d\\d-\\d\\d-\\d\\d),(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
    re = new RegExp(regex);
    reMatch = re.exec(value);
    if (reMatch) {
      isValid = true;
      textMin = reMatch[1];
      textMax = reMatch[2];
    } else {
      // Check for only textMin
      regex = "^(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
      re = new RegExp(regex);
      reMatch = re.exec(value);
      if (reMatch) {
        isValid = true;
        textMin = reMatch[1];
      } else {
        // Check for only textMax
        regex = "^,(\\d\\d\\d\\d-\\d\\d-\\d\\d)$";
        re = new RegExp(regex);
        reMatch = re.exec(value);
        if (reMatch) {
          isValid = true;
          textMax = reMatch[1];
        }
      }
    }

    if (isValid) {
      let timeMin = funcs.getSecsFromYearMonthDay(textMin);
      let timeMax = funcs.getSecsFromYearMonthDay(textMax);
      if (timeMin && timeMax) {
        if (timeMin > timeMax) {
          isValid = false;
        }
      }
    }

    return isValid;
  };

  updateSpecDirty = (orgSpecData, nextSpecData) => {
    let orgSpecDataMod = _.cloneDeep(orgSpecData);
    for (let dataItem of orgSpecDataMod.data) {
      if (!dataItem.TIMERANGE) {
        dataItem.TIMERANGE = "";
      }
    }

    let nextSpecDataMod = _.cloneDeep(nextSpecData);
    for (let dataItem of nextSpecDataMod.data) {
      if (!dataItem.TIMERANGE) {
        dataItem.TIMERANGE = "";
      }
    }

    let dirty = !_.isEqual(orgSpecDataMod, nextSpecDataMod);

    this.props.setSpecDirty(dirty);
  };

  handleResetSpecButton = () => {
    let editSpecDoc = this.props.editSpec;
    let nextSpecDoc = this.props.editSpec;
    this.updateSpecDirty(editSpecDoc, nextSpecDoc);
    this.props.updateNextSpec(nextSpecDoc);
  };

  isBuildSpecValid = (tableData) => {
    let requiredAttrs = [];
    requiredAttrs.push("PROJECT");
    requiredAttrs.push("PHASE");
    requiredAttrs.push("RUNTAG");
    requiredAttrs.push("BLOCK");
    requiredAttrs.push("USER");

    let isValid = true;

    for (let dataItem of tableData) {
      for (let attr of requiredAttrs) {
        let value = dataItem[attr];
        if (!this.isValidString(value)) {
          isValid = false;
        }
      }
    }

    return isValid;
  };

  handleSaveSpecButton = () => {
    let tableData = _.cloneDeep(this.props.nextSpec.data);

    if (this.isBuildSpecValid(tableData)) {
      let nextSpec = this.props.nextSpec;
      this.props.saveSpec(this.specType, nextSpec);
      this.props.setSpecDirty(false);
    } else {
      let message = "Spec contains blank entries";
      funcs.showNotification("Edit Build Spec", message);
    }
  };

  handleSaveSpecAsButton = () => {
    let tableData = _.cloneDeep(this.props.nextSpec.data);
    if (this.isBuildSpecValid(tableData)) {
      // Get SaveSpecAs info from user
      this.setState({ showGetSpecNamePopup: true });
    } else {
      let message = "Spec contains blank entries";
      funcs.showNotification("Edit Build Spec", message);
    }
  };

  getSpecNamePopupSubmitAnswer = (accept, fullName) => {
    if (accept == true) {
      let specDoc = _.cloneDeep(this.props.nextSpec);
      specDoc.fullName = fullName;

      this.props.saveSpecAs(this.specType, specDoc);
      this.props.setSpecDirty(false);
    }
    this.setState({ showGetSpecNamePopup: false });
  };

  handleRenameSpecButton = () => {
    // Get RenameSpec info from user
    this.setState({ showRenameSpecPopup: true });
  };

  renameSpecPopupSubmitAnswer = (accept, newFullName) => {
    // Use RenameSpec info from user
    if (accept) {
      this.props.renameSpec(this.specType, newFullName);
      this.props.setSpecDirty(false);
    }
    this.setState({ showRenameSpecPopup: false });
  };

  handleDeleteSpecButton = () => {
    this.props.deleteSpec(this.specType);
  };

  handleCancelButton = () => {
    this.props.cancelSpec(this.specType);
  };

  handleDeleteBuildsButton = () => {
    let selectedRows = this.tableRef.current.getSelectedRows();

    if (selectedRows.length == 0) {
      let message = "You must first select one or more builds";
      funcs.showNotification("Edit Build Spec", message);
    } else {
      for (let row of selectedRows) {
        row.delete();
      }

      let tableData = _.cloneDeep(this.tableRef.current.getData());
      tableData = this.updateCheckpoints(tableData);

      let editSpecDoc = this.props.editSpec;
      let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
      nextSpecDoc.data = tableData;

      this.updateSpecDirty(editSpecDoc, nextSpecDoc);
      this.props.updateNextSpec(nextSpecDoc);
    }
  };

  handleAddBuildButton = () => {
    let blankDataItem = {
      PROJECT: "",
      PHASE: "",
      RUNTAG: "",
      BLOCK: "",
      USER: "",
      LABEL: "",
      TIMERANGE: undefined,
    };

    let tableData = _.cloneDeep(this.tableRef.current.getData());
    tableData.push(blankDataItem);
    tableData = this.updateCheckpoints(tableData);

    let editSpecDoc = this.props.editSpec;
    let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
    nextSpecDoc.data = tableData;

    this.updateSpecDirty(editSpecDoc, nextSpecDoc);
    this.props.updateNextSpec(nextSpecDoc);
  };

  handleAddBuildsButton = async () => {
    let message = "";
    let persistent = false;
    let id = funcs.showBusyNotification("Getting Builds", message, persistent);

    let userFilter = {};
    let userData = this.props.userData;
    let dbAdminMode = false;
    let r = await fastapi.getProjectsBuildsCheckpoints(this.props.systemConfig.dataServer, userData, dbAdminMode, userFilter, this.state.includeTime);
    if (r.success) {
      this.setState({ showAddBuildsPopup: true, addBuildsPopupData: r.buildList, addBuildsPopupTitle: "Add Builds" });
    } else {
      funcs.showNotification("Add Builds", r.message);
    }

    funcs.clearNotification(id);
  };

  addBuildsPopupSubmitAnswer = (accept, buildList) => {
    // Use AddBuilds info from user
    if (accept) {
      let tagList = [];
      tagList.push("PROJECT");
      tagList.push("PHASE");
      tagList.push("RUNTAG");
      tagList.push("BLOCK");
      tagList.push("USER");
      tagList.push("LABEL");

      let tableData = _.cloneDeep(this.tableRef.current.getData());

      for (let build of buildList) {
        if (!this.buildInBuildList(build, tableData)) {
          for (let key in build) {
            if (!tagList.includes(key)) {
              delete build[key];
            }
          }
          tableData.push(build);
        }
      }

      tableData = this.updateCheckpoints(tableData);

      let editSpecDoc = this.props.editSpec;
      let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
      nextSpecDoc.data = tableData;

      this.updateSpecDirty(editSpecDoc, nextSpecDoc);
      this.props.updateNextSpec(nextSpecDoc);
    }

    this.setState({ showAddBuildsPopup: false });
  };

  buildInBuildList = (build, buildList) => {
    let buildInList = false;

    let tagList = [];
    tagList.push("PROJECT");
    tagList.push("PHASE");
    tagList.push("RUNTAG");
    tagList.push("BLOCK");
    tagList.push("USER");

    for (let existingBuild of buildList) {
      let match = true;
      for (let tag of tagList) {
        if (build[tag] != existingBuild[tag]) {
          match = false;
          break;
        }
      }
      if (match) {
        buildInList = true;
        break;
      }
    }
    return buildInList;
  };

  // upload query

  handleAddBuildsQueryButtonBegin = () => {
    // Get query file
    this.fileInputRefQuery.current?.click();
  };

  handleUploadFileQuery = async () => {
    let theFile = null;
    if (this.fileInputRefQuery.current?.files) {
      theFile = this.fileInputRefQuery.current.files[0];
    }
    // Clear the input value so that onChange will work for re-selection of the same file
    document.getElementById("inputIdQuery").value = null;

    if (theFile == null) {
      return;
    }

    let formData = new FormData();
    formData.append("theFile", theFile);

    let r = await fastapi.uploadJsonFile(this.props.systemConfig.dataServer, formData);
    let jsonObj = r.jsonObj;

    if (r.success) {
      this.handleAddBuildsQueryButtonEnd(jsonObj);
    } else {
      funcs.showNotification("Upload Query", r.message);
      return;
    }
  };

  handleAddBuildsQueryButtonEnd = async (jsonDict) => {
    let userFilter = jsonDict;

    // Use query
    this.addBuildsViaQueryActive = true;
    let userData = this.props.userData;
    let dbAdminMode = false;
    let r = await fastapi.getProjectsBuildsCheckpoints(this.props.systemConfig.dataServer, userData, dbAdminMode, userFilter, this.state.includeTime);
    if (r.success) {
      this.setState({
        showAddBuildsPopup: true,
        addBuildsPopupData: r.buildList,
        addBuildsPopupTitle: "Add Builds (via Query)",
      });
    } else {
      funcs.showNotification("Add Builds", r.message);
    }
  };

  ////////////////////////////////////////
  // upload/download spec
  ////////////////////////////////////////

  handleUploadSpecButton = () => {
    if (this.props.specDirty == true) {
      this.props.showDirtyMessage();
    } else {
      this.fileInputRefSpec.current?.click();
    }
  };

  handleUploadFileSpec = async () => {
    let theFile = null;
    if (this.fileInputRefSpec.current?.files) {
      theFile = this.fileInputRefSpec.current.files[0];
    }
    // Clear the input value so that onChange will work for re-selection of the same file
    document.getElementById("inputIdSpec").value = null;

    if (theFile == null) {
      return;
    }

    let formData = new FormData();
    formData.append("theFile", theFile);

    let r = await fastapi.uploadJsonFile(this.props.systemConfig.dataServer, formData);
    let jsonObj = r.jsonObj;

    if (r.success) {
      let editSpecDoc = this.props.editSpec;
      let nextSpecDoc = _.cloneDeep(this.props.nextSpec);
      nextSpecDoc.data = jsonObj;

      this.updateSpecDirty(editSpecDoc, nextSpecDoc);
      this.props.updateNextSpec(nextSpecDoc);
    } else {
      funcs.showNotification("Upload Spec", r.message);
      return;
    }
  };

  handleDownloadSpecButton = () => {
    let fileName = "buildSpec";
    let specData = this.tableRef.current.getData();
    const blob = new Blob([JSON.stringify(specData, null, 2)], {
      type: "application/json",
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", fileName + ".json");
    document.body.appendChild(link);
    link.click();
  };

  // Render Support

  getCheckpointsText = (id) => {
    let inputValue = "";
    let inputElement = document.getElementById(id);
    if (inputElement != null) {
      inputValue = inputElement.value.trim();
    }
    return inputValue;
  };

  setInput = (id, value) => {
    let inputElement = document.getElementById(id);
    if (inputElement != null) {
      inputElement.value = value;
    }
  };

  // Cookie Support

  setCookie = (cookie) => {
    funcs.writeCookie(COOKIE_NAME, cookie);
  };

  getCookie = () => {
    let cookie = funcs.readCookie(COOKIE_NAME);

    if (_.isEmpty(cookie)) {
      cookie = {};
    }
    if (!cookie.hasOwnProperty("includeTime")) {
      cookie["includeTime"] = false;
    }

    return cookie;
  };

  handleIncludeTime = (e) => {
    let includeTime = !this.state.includeTime;

    let cookie = this.getCookie();
    cookie["includeTime"] = includeTime;
    this.setCookie(cookie);

    this.setState({ includeTime: includeTime });
  };
}

export default EditBuildSpec;

////////////////////////////////////////////////////////////////////////////////
// End of File
////////////////////////////////////////////////////////////////////////////////
