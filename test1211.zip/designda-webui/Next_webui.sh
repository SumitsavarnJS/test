#!/bin/sh

# Create a file
filename="$(date +%Y-%m-%d_%H-%M%S).log"

## Run a p4 sync force

p4 sync



echo "Build Process for Next WebUI Started $filename"
rm -rf node_modules/
rm -rf .next/ 


echo "Build and Node Directories Removed $filename"

npm install  

echo "Npm Install Success $filename"


npm run build 

echo "Build Success $filename"

npm run start

echo "Next Webui Project Started $filename"

exit
